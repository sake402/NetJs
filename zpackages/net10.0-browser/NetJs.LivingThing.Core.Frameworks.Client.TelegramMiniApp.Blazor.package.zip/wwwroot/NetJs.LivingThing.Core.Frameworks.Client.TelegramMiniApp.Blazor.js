
//--TRIMMABLE-BOUNDARY-START(15155)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm) {
    "use strict";
    let _;
    let $jEKeqf;
    let $WCYMFd;
    let $OCyNsf;
    let $zxbQVh;
    let $PDupIg;
    let $GGxLil;
    let $QuuXMi;
    let $JzvEmj;
    let $wejnGb;
    let $QNwlYa;
    let $mUXFNc;
    let $Jmisgh;
    let $rhpcQk;
    let $TUghTe;
    let $HzOIJc;
    let $bDCggg;
    let $hRGcyi;
    let $HCvFQi;
    let $TTKzjd;
    let $KShgLg;
    let $LvnuSj;
    let $AOGDTb;
    let $CLAyNh;
    let $gvEdLk;
    let $XTSCui;
    let $LyCLue;
    let $nIldub;
    let $OsDpLe;
    let $bIxdPf;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Client.TelegramMiniApp.Blazor", 
    {
  "h": 15155,
  "f": "LivingThing.Core.Frameworks.Client.TelegramMiniApp.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.TelegramMiniApp.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Client.TelegramMiniApp.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(604979)
        $asm.$cls(`$fycR.LCFCT.IBasePopupButton`, ($self) => class IBasePopupButton
        {
            static $h = 604979;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885506867),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590539571,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21475441459,
        "f": 83886337
      },
      "n": "id",
      "o": "LCFCT$IBasePopupButton$id",
      "d": 604979,
      "h": 12885506867,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885506867)
  ],
  "h": 604979
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.IBasePopupButton`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}IBasePopupButton`; }
        });
        //--TRIMMABLE-BOUNDARY-END(604979)
        
        

        //--TRIMMABLE-BOUNDARY-START(670515)
        $asm.$cls(`$fycR.LCFCT.IDefaultDestructivePopupButton`, ($self) => class IDefaultDestructivePopupButton
        {
            static $h = 670515;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950343475),
    {
      "p": 473907,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180539699,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360408883,
        "f": 83886337
      },
      "n": "type",
      "o": "LCFCT$IDefaultDestructivePopupButton$type",
      "d": 670515,
      "h": 42950343475,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42950343475),
//--TRIMMABLE-BOUNDARY-START(38655376179),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590605107,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25770474291,
        "f": 83886337
      },
      "n": "text",
      "o": "LCFCT$IDefaultDestructivePopupButton$text",
      "d": 670515,
      "h": 38655376179,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38655376179)
  ],
  "h": 670515
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fycR.LCFCT.IBasePopupButton ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.IDefaultDestructivePopupButton`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}IDefaultDestructivePopupButton`; }
        });
        //--TRIMMABLE-BOUNDARY-END(670515)
        
        

        //--TRIMMABLE-BOUNDARY-START(736051)
        $asm.$cls(`$fycR.LCFCT.IOkCloseCancelPopupButton`, ($self) => class IOkCloseCancelPopupButton
        {
            static $h = 736051;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475572531),
    {
      "p": 998195,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590670643,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 17180605235,
        "f": 83886337
      },
      "n": "type",
      "o": "LCFCT$IOkCloseCancelPopupButton$type",
      "d": 736051,
      "h": 21475572531,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475572531)
  ],
  "h": 736051
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fycR.LCFCT.IBasePopupButton ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.IOkCloseCancelPopupButton`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}IOkCloseCancelPopupButton`; }
        });
        //--TRIMMABLE-BOUNDARY-END(736051)
        
        

        //--TRIMMABLE-BOUNDARY-START(1456947)
        $asm.$cls(`$fycR.LCFCT.TelegramAppFactory`, ($self) => class TelegramAppFactory extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181326131)
            /*TelegramWebApps.WebApp?*/ app = null;
            //--TRIMMABLE-BOUNDARY-END(17181326131)
            
            //--TRIMMABLE-BOUNDARY-START(21476293427)
            /*ValueTask<TelegramWebApps.WebApp?> *//*async*/  GetTelegramAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fycR.LCFCT.TelegramWebApps.WebApp), $.$fycR.LCFCT.TelegramWebApps.WebApp, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476293427);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.app !== null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, this.app);
                    }
                    ($t1 = this.assets.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "https://telegram.org/js/telegram-web-app.js" ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.WaitForScriptLoad(this.javaScript, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "window.Telegram.WebApp" ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    /*var*/ let executor = new $.$hDPm.LCFCS.JavaScriptExecutor().$ctor$1(this.javaScript);
                    this.app = $.$TLYN.LT.TypeScript.Interface$1($.$fycR.LCFCT.TelegramWebApps.WebApp, executor, $.$fycR.LCFCT.TelegramAppFactory.$type, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                    ($t3 = ($.$cast(this.app, $.$TLYN.LT.TypeScriptMockBase)).Interceptor.AwaitInitilize(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    ($t4 = ($.$cast(this.app, $.$TLYN.LT.TypeScriptMockBase)).Interceptor.ReadProperties(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    if (this.app.LCFCT$TelegramWebApps$WebApp$version !== null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, this.app);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21476293427)
            
            //--TRIMMABLE-BOUNDARY-START(25771260723)
            /*ValueTask */ UpdateProperties(/*TelegramWebApps.WebApp*/ app)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771260723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ($.$cast(app, $.$TLYN.LT.TypeScriptMockBase)).Interceptor.ReadProperties();
            }
            //--TRIMMABLE-BOUNDARY-END(25771260723)
            
            //Begin primary constructor
            /*IJavaScriptRunner*/ javaScript = null;
            /*IAssetsCollection*/ assets = null;
            $ctor$1(/*IJavaScriptRunner*/javaScript, /*IAssetsCollection*/assets)
            {
                this.javaScript = javaScript;
                this.assets = assets;
                super.$ctor();
                return this
            }
            //End primary constructor
            static $h = 1456947;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476293427),
    {
      "r": $.$$.STT.ValueTask$$($.$fycR.LCFCT.TelegramWebApps.WebApp).$h,
      "n": "GetTelegramAsync",
      "d": 1456947,
      "h": 21476293427,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21476293427),
//--TRIMMABLE-BOUNDARY-START(25771260723),
    {
      "r": 181338113,
      "p": [
        {
          "n": "app",
          "p": 4668211
        }
      ],
      "n": "UpdateProperties",
      "d": 1456947,
      "h": 25771260723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771260723)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591391539),
    {
      "t": 64509610,
      "n": "\u003CjavaScript\u003EP",
      "d": 1456947,
      "h": 8591391539,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591391539),
//--TRIMMABLE-BOUNDARY-START(4296424243),
    {
      "t": 61691562,
      "n": "\u003Cassets\u003EP",
      "d": 1456947,
      "h": 4296424243,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296424243),
//--TRIMMABLE-BOUNDARY-START(17181326131),
    {
      "t": 4668211,
      "n": "app",
      "d": 1456947,
      "h": 17181326131,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181326131)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886358835),
    {
      "p": [
        {
          "n": "javaScript",
          "p": 64509610
        },
        {
          "n": "assets",
          "p": 61691562
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1456947,
      "h": 12886358835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886358835)
  ],
  "h": 1456947
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramAppFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramAppFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1456947)
        
        

        //--TRIMMABLE-BOUNDARY-START(932659)
        $asm.$cls(`$fycR.LCFCT.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295899955)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295899955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.WebApp_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.WebApp_Mocking().$ctor$3(impl);
                }, $WCYMFd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg, $.$fycR.LCFCT.ThemeChangedEventArg_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.ThemeChangedEventArg_Mocking().$ctor$3(impl);
                }, $OCyNsf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_28, $.$fycR.LCFCT.WebApp_Type_28_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.WebApp_Type_28_Mocking().$ctor$3(impl);
                }, $zxbQVh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$fycR.LCFCT.ThemeParams_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.ThemeParams_Mocking().$ctor$3(impl);
                }, $PDupIg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.StoryShareParams, $.$fycR.LCFCT.StoryShareParams_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.StoryShareParams_Mocking().$ctor$3(impl);
                }, $GGxLil ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink, $.$fycR.LCFCT.StoryWidgetLink_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.StoryWidgetLink_Mocking().$ctor$3(impl);
                }, $QuuXMi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.PopupParams, $.$fycR.LCFCT.PopupParams_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.PopupParams_Mocking().$ctor$3(impl);
                }, $JzvEmj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.ScanQrPopupParams, $.$fycR.LCFCT.ScanQrPopupParams_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.ScanQrPopupParams_Mocking().$ctor$3(impl);
                }, $wejnGb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.BackButton, $.$fycR.LCFCT.BackButton_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.BackButton_Mocking().$ctor$3(impl);
                }, $QNwlYa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.MainButton_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.MainButton_Mocking().$ctor$3(impl);
                }, $mUXFNc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$fycR.LCFCT.MainButton_Type_0_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.MainButton_Type_0_Mocking().$ctor$3(impl);
                }, $Jmisgh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$fycR.LCFCT.SettingsButton_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.SettingsButton_Mocking().$ctor$3(impl);
                }, $rhpcQk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.HapticFeedback, $.$fycR.LCFCT.HapticFeedback_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.HapticFeedback_Mocking().$ctor$3(impl);
                }, $TUghTe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$fycR.LCFCT.CloudStorage_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.CloudStorage_Mocking().$ctor$3(impl);
                }, $HzOIJc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$fycR.LCFCT.BiometricManager_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.BiometricManager_Mocking().$ctor$3(impl);
                }, $bDCggg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.BiometricRequestAccessParams, $.$fycR.LCFCT.BiometricRequestAccessParams_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.BiometricRequestAccessParams_Mocking().$ctor$3(impl);
                }, $hRGcyi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.BiometricAuthenticateParams, $.$fycR.LCFCT.BiometricAuthenticateParams_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.BiometricAuthenticateParams_Mocking().$ctor$3(impl);
                }, $HCvFQi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$fycR.LCFCT.WebAppInitData_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.WebAppInitData_Mocking().$ctor$3(impl);
                }, $TTKzjd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$fycR.LCFCT.WebAppUser_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.WebAppUser_Mocking().$ctor$3(impl);
                }, $KShgLg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.WebAppChat, $.$fycR.LCFCT.WebAppChat_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.WebAppChat_Mocking().$ctor$3(impl);
                }, $LvnuSj ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_1, $.$fycR.LCFCT.TelegramWebApps_Type_1_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.TelegramWebApps_Type_1_Mocking().$ctor$3(impl);
                }, $AOGDTb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_2, $.$fycR.LCFCT.TelegramWebApps_Type_2_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.TelegramWebApps_Type_2_Mocking().$ctor$3(impl);
                }, $CLAyNh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3, $.$fycR.LCFCT.TelegramWebApps_Type_3_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.TelegramWebApps_Type_3_Mocking().$ctor$3(impl);
                }, $gvEdLk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_4, $.$fycR.LCFCT.TelegramWebApps_Type_4_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.TelegramWebApps_Type_4_Mocking().$ctor$3(impl);
                }, $XTSCui ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_5, $.$fycR.LCFCT.TelegramWebApps_Type_5_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.TelegramWebApps_Type_5_Mocking().$ctor$3(impl);
                }, $LyCLue ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_6, $.$fycR.LCFCT.TelegramWebApps_Type_6_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.TelegramWebApps_Type_6_Mocking().$ctor$3(impl);
                }, $nIldub ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7, $.$fycR.LCFCT.TelegramWebApps_Type_7_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$fycR.LCFCT.TelegramWebApps_Type_7_Mocking().$ctor$3(impl);
                }, $OsDpLe ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_8, $.$fycR.LCFCT.TelegramWebApps_Type_8_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$fycR.LCFCT.TelegramWebApps_Type_8_Mocking().$ctor$3(impl);
                }, $bIxdPf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":932659,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295899955)
            
            static $h = 932659;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295899955),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 932659,
      "h": 4295899955,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295899955)
  ],
  "h": 932659
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(932659)
        
        

        //--TRIMMABLE-BOUNDARY-START(1522483)
        $asm.$cls(`$fycR.LCFCT.TelegramWebApps`, ($self) => class TelegramWebApps extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4668211)
            static $_WebApp;
            static get WebApp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4668211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp`, ($self) => class WebApp
                {
                    static $h = 4668211;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(227637934899),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120263752499,
        "f": 50331905
      },
      "n": "initData",
      "o": "LCFCT$TelegramWebApps$WebApp$initData",
      "d": 4668211,
      "h": 227637934899,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(227637934899),
//--TRIMMABLE-BOUNDARY-START(231932902195),
    {
      "p": 6503219,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128853687091,
        "f": 50331905
      },
      "n": "initDataUnsafe",
      "o": "LCFCT$TelegramWebApps$WebApp$initDataUnsafe",
      "d": 4668211,
      "h": 231932902195,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(231932902195),
//--TRIMMABLE-BOUNDARY-START(438091332403),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197573163827,
        "f": 50331905
      },
      "n": "version",
      "o": "LCFCT$TelegramWebApps$WebApp$version",
      "d": 4668211,
      "h": 438091332403,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(438091332403),
//--TRIMMABLE-BOUNDARY-START(369371855667),
    {
      "p": 6634291,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171803360051,
        "f": 50331905
      },
      "n": "platform",
      "o": "LCFCT$TelegramWebApps$WebApp$platform",
      "d": 4668211,
      "h": 369371855667,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(369371855667),
//--TRIMMABLE-BOUNDARY-START(30069439283),
    {
      "p": 2702131,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94493948723,
        "f": 50331905
      },
      "n": "colorScheme",
      "o": "LCFCT$TelegramWebApps$WebApp$colorScheme",
      "d": 4668211,
      "h": 30069439283,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30069439283),
//--TRIMMABLE-BOUNDARY-START(433796365107),
    {
      "p": 4471603,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188983229235,
        "f": 50331905
      },
      "n": "themeParams",
      "o": "LCFCT$TelegramWebApps$WebApp$themeParams",
      "d": 4668211,
      "h": 433796365107,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(433796365107),
//--TRIMMABLE-BOUNDARY-START(240522836787),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146033556275,
        "f": 50331905
      },
      "n": "isExpanded",
      "o": "LCFCT$TelegramWebApps$WebApp$isExpanded",
      "d": 4668211,
      "h": 240522836787,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(240522836787),
//--TRIMMABLE-BOUNDARY-START(442386299699),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206163098419,
        "f": 50331905
      },
      "n": "viewportHeight",
      "o": "LCFCT$TelegramWebApps$WebApp$viewportHeight",
      "d": 4668211,
      "h": 442386299699,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(442386299699),
//--TRIMMABLE-BOUNDARY-START(446681266995),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214753033011,
        "f": 50331905
      },
      "n": "viewportStableHeight",
      "o": "LCFCT$TelegramWebApps$WebApp$viewportStableHeight",
      "d": 4668211,
      "h": 446681266995,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(446681266995),
//--TRIMMABLE-BOUNDARY-START(223342967603),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111673817907,
        "f": 50331905
      },
      "n": "headerColor",
      "o": "LCFCT$TelegramWebApps$WebApp$headerColor",
      "d": 4668211,
      "h": 223342967603,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(223342967603),
//--TRIMMABLE-BOUNDARY-START(8594602803),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68724144947,
        "f": 50331905
      },
      "n": "backgroundColor",
      "o": "LCFCT$TelegramWebApps$WebApp$backgroundColor",
      "d": 4668211,
      "h": 8594602803,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8594602803),
//--TRIMMABLE-BOUNDARY-START(236227869491),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137443621683,
        "f": 50331905
      },
      "n": "isClosingConfirmationEnabled",
      "o": "LCFCT$TelegramWebApps$WebApp$isClosingConfirmationEnabled",
      "d": 4668211,
      "h": 236227869491,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(236227869491),
//--TRIMMABLE-BOUNDARY-START(4299635507),
    {
      "p": 2112307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60134210355,
        "f": 50331905
      },
      "n": "BackButton",
      "o": "LCFCT$TelegramWebApps$WebApp$BackButton",
      "d": 4668211,
      "h": 4299635507,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4299635507),
//--TRIMMABLE-BOUNDARY-START(253407738675),
    {
      "p": 3029811,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163213425459,
        "f": 50331905
      },
      "n": "MainButton",
      "o": "LCFCT$TelegramWebApps$WebApp$MainButton",
      "d": 4668211,
      "h": 253407738675,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(253407738675),
//--TRIMMABLE-BOUNDARY-START(403731594035),
    {
      "p": 3488563,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180393294643,
        "f": 50331905
      },
      "n": "SettingsButton",
      "o": "LCFCT$TelegramWebApps$WebApp$SettingsButton",
      "d": 4668211,
      "h": 403731594035,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(403731594035),
//--TRIMMABLE-BOUNDARY-START(219048000307),
    {
      "p": 2767667,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103083883315,
        "f": 50331905
      },
      "n": "HapticFeedback",
      "o": "LCFCT$TelegramWebApps$WebApp$HapticFeedback",
      "d": 4668211,
      "h": 219048000307,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(219048000307),
//--TRIMMABLE-BOUNDARY-START(25774471987),
    {
      "p": 2636595,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85904014131,
        "f": 50331905
      },
      "n": "CloudStorage",
      "o": "LCFCT$TelegramWebApps$WebApp$CloudStorage",
      "d": 4668211,
      "h": 25774471987,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25774471987),
//--TRIMMABLE-BOUNDARY-START(12889570099),
    {
      "p": 2308915,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77314079539,
        "f": 50331905
      },
      "n": "BiometricManager",
      "o": "LCFCT$TelegramWebApps$WebApp$BiometricManager",
      "d": 4668211,
      "h": 12889570099,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12889570099),
//--TRIMMABLE-BOUNDARY-START(249112771379),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154623490867,
        "f": 50331905
      },
      "n": "isVerticalSwipesEnabled",
      "o": "LCFCT$TelegramWebApps$WebApp$isVerticalSwipesEnabled",
      "d": 4668211,
      "h": 249112771379,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(249112771379)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(244817804083),
    {
      "r": 262145,
      "p": [
        {
          "n": "version",
          "p": 1310721
        }
      ],
      "n": "isVersionAtLeast",
      "o": "LCFCT$TelegramWebApps$WebApp$isVersionAtLeast",
      "d": 4668211,
      "h": 244817804083,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(244817804083),
//--TRIMMABLE-BOUNDARY-START(399436626739),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 1310721
        }
      ],
      "n": "setHeaderColor",
      "o": "LCFCT$TelegramWebApps$WebApp$setHeaderColor",
      "d": 4668211,
      "h": 399436626739,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(399436626739),
//--TRIMMABLE-BOUNDARY-START(395141659443),
    {
      "r": 65537,
      "p": [
        {
          "n": "color",
          "p": 1310721
        }
      ],
      "n": "setBackgroundColor",
      "o": "LCFCT$TelegramWebApps$WebApp$setBackgroundColor",
      "d": 4668211,
      "h": 395141659443,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(395141659443),
//--TRIMMABLE-BOUNDARY-START(42954341171),
    {
      "r": 65537,
      "n": "enableClosingConfirmation",
      "o": "LCFCT$TelegramWebApps$WebApp$enableClosingConfirmation",
      "d": 4668211,
      "h": 42954341171,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42954341171),
//--TRIMMABLE-BOUNDARY-START(34364406579),
    {
      "r": 65537,
      "n": "disableClosingConfirmation",
      "o": "LCFCT$TelegramWebApps$WebApp$disableClosingConfirmation",
      "d": 4668211,
      "h": 34364406579,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34364406579),
//--TRIMMABLE-BOUNDARY-START(292062444339),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 4406067
        },
        {
          "n": "eventHandler",
          "p": $.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg).$h
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent",
      "d": 4668211,
      "h": 292062444339,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(292062444339),
//--TRIMMABLE-BOUNDARY-START(296357411635),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 4602675
        },
        {
          "n": "eventHandler",
          "p": 4537139
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$1",
      "d": 4668211,
      "h": 296357411635,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(296357411635),
//--TRIMMABLE-BOUNDARY-START(330717150003),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5978931
        },
        {
          "n": "eventHandler",
          "p": 43122689
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$9",
      "d": 4668211,
      "h": 330717150003,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(330717150003),
//--TRIMMABLE-BOUNDARY-START(335012117299),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 6044467
        },
        {
          "n": "eventHandler",
          "p": 43122689
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$10",
      "d": 4668211,
      "h": 335012117299,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(335012117299),
//--TRIMMABLE-BOUNDARY-START(339307084595),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 6110003
        },
        {
          "n": "eventHandler",
          "p": 43122689
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$11",
      "d": 4668211,
      "h": 339307084595,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(339307084595),
//--TRIMMABLE-BOUNDARY-START(343602051891),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 6175539
        },
        {
          "n": "eventHandler",
          "p": 2964275
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$12",
      "d": 4668211,
      "h": 343602051891,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(343602051891),
//--TRIMMABLE-BOUNDARY-START(347897019187),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 6241075
        },
        {
          "n": "eventHandler",
          "p": 3226419
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$13",
      "d": 4668211,
      "h": 347897019187,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(347897019187),
//--TRIMMABLE-BOUNDARY-START(352191986483),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 6306611
        },
        {
          "n": "eventHandler",
          "p": 3357491
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$14",
      "d": 4668211,
      "h": 352191986483,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(352191986483),
//--TRIMMABLE-BOUNDARY-START(300652378931),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 4733747
        },
        {
          "n": "eventHandler",
          "p": 43122689
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$2",
      "d": 4668211,
      "h": 300652378931,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(300652378931),
//--TRIMMABLE-BOUNDARY-START(304947346227),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 4799283
        },
        {
          "n": "eventHandler",
          "p": 2571059
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$3",
      "d": 4668211,
      "h": 304947346227,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(304947346227),
//--TRIMMABLE-BOUNDARY-START(309242313523),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 4864819
        },
        {
          "n": "eventHandler",
          "p": $.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_13).$h
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$4",
      "d": 4668211,
      "h": 309242313523,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(309242313523),
//--TRIMMABLE-BOUNDARY-START(313537280819),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 4995891
        },
        {
          "n": "eventHandler",
          "p": $.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_15).$h
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$5",
      "d": 4668211,
      "h": 313537280819,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(313537280819),
//--TRIMMABLE-BOUNDARY-START(317832248115),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5126963
        },
        {
          "n": "eventHandler",
          "p": 43122689
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$6",
      "d": 4668211,
      "h": 317832248115,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(317832248115),
//--TRIMMABLE-BOUNDARY-START(322127215411),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5192499
        },
        {
          "n": "eventHandler",
          "p": 2243379
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$7",
      "d": 4668211,
      "h": 322127215411,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(322127215411),
//--TRIMMABLE-BOUNDARY-START(326422182707),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5258035
        },
        {
          "n": "eventHandler",
          "p": 2505523
        }
      ],
      "n": "onEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$onEvent$8",
      "d": 4668211,
      "h": 326422182707,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(326422182707),
//--TRIMMABLE-BOUNDARY-START(257702705971),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5323571
        },
        {
          "n": "eventHandler",
          "p": 43122689
        }
      ],
      "n": "offEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$offEvent",
      "d": 4668211,
      "h": 257702705971,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(257702705971),
//--TRIMMABLE-BOUNDARY-START(261997673267),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5389107
        },
        {
          "n": "eventHandler",
          "p": 4537139
        }
      ],
      "n": "offEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$offEvent$1",
      "d": 4668211,
      "h": 261997673267,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(261997673267),
//--TRIMMABLE-BOUNDARY-START(266292640563),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5454643
        },
        {
          "n": "eventHandler",
          "p": 2964275
        }
      ],
      "n": "offEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$offEvent$2",
      "d": 4668211,
      "h": 266292640563,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(266292640563),
//--TRIMMABLE-BOUNDARY-START(270587607859),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5520179
        },
        {
          "n": "eventHandler",
          "p": 3226419
        }
      ],
      "n": "offEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$offEvent$3",
      "d": 4668211,
      "h": 270587607859,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(270587607859),
//--TRIMMABLE-BOUNDARY-START(274882575155),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5585715
        },
        {
          "n": "eventHandler",
          "p": 3357491
        }
      ],
      "n": "offEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$offEvent$4",
      "d": 4668211,
      "h": 274882575155,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(274882575155),
//--TRIMMABLE-BOUNDARY-START(279177542451),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5651251
        },
        {
          "n": "eventHandler",
          "p": 2571059
        }
      ],
      "n": "offEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$offEvent$5",
      "d": 4668211,
      "h": 279177542451,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(279177542451),
//--TRIMMABLE-BOUNDARY-START(283472509747),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5716787
        },
        {
          "n": "eventHandler",
          "p": 2243379
        }
      ],
      "n": "offEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$offEvent$6",
      "d": 4668211,
      "h": 283472509747,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(283472509747),
//--TRIMMABLE-BOUNDARY-START(287767477043),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 5782323
        },
        {
          "n": "eventHandler",
          "p": 2505523
        }
      ],
      "n": "offEvent",
      "o": "LCFCT$TelegramWebApps$WebApp$offEvent$7",
      "d": 4668211,
      "h": 287767477043,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(287767477043),
//--TRIMMABLE-BOUNDARY-START(390846692147),
    {
      "r": 65537,
      "p": [
        {
          "n": "data",
          "p": 1310721
        }
      ],
      "n": "sendData",
      "o": "LCFCT$TelegramWebApps$WebApp$sendData",
      "d": 4668211,
      "h": 390846692147,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(390846692147),
//--TRIMMABLE-BOUNDARY-START(429501397811),
    {
      "r": 65537,
      "p": [
        {
          "n": "query",
          "p": 1310721
        },
        {
          "n": "choose_chat_types",
          "p": $.$typeArray($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_27).$h
        }
      ],
      "n": "switchInlineQuery",
      "o": "LCFCT$TelegramWebApps$WebApp$switchInlineQuery",
      "d": 4668211,
      "h": 429501397811,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(429501397811),
//--TRIMMABLE-BOUNDARY-START(360781921075),
    {
      "r": 65537,
      "p": [
        {
          "n": "url",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 5913395
        }
      ],
      "n": "openLink",
      "o": "LCFCT$TelegramWebApps$WebApp$openLink",
      "d": 4668211,
      "h": 360781921075,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(360781921075),
//--TRIMMABLE-BOUNDARY-START(365076888371),
    {
      "r": 65537,
      "p": [
        {
          "n": "url",
          "p": 1310721
        }
      ],
      "n": "openTelegramLink",
      "o": "LCFCT$TelegramWebApps$WebApp$openTelegramLink",
      "d": 4668211,
      "h": 365076888371,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(365076888371),
//--TRIMMABLE-BOUNDARY-START(356486953779),
    {
      "r": 65537,
      "p": [
        {
          "n": "url",
          "p": 1310721
        },
        {
          "n": "callback",
          "p": 2964275
        }
      ],
      "n": "openInvoice",
      "o": "LCFCT$TelegramWebApps$WebApp$openInvoice",
      "d": 4668211,
      "h": 356486953779,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(356486953779),
//--TRIMMABLE-BOUNDARY-START(408026561331),
    {
      "r": 65537,
      "p": [
        {
          "n": "media_url",
          "p": 1310721
        },
        {
          "n": "params",
          "p": 3554099
        }
      ],
      "n": "shareToStory",
      "o": "LCFCT$TelegramWebApps$WebApp$shareToStory",
      "d": 4668211,
      "h": 408026561331,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(408026561331),
//--TRIMMABLE-BOUNDARY-START(420911463219),
    {
      "r": 65537,
      "p": [
        {
          "n": "params",
          "p": 3291955
        },
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.String).$h
        }
      ],
      "n": "showPopup",
      "o": "LCFCT$TelegramWebApps$WebApp$showPopup",
      "d": 4668211,
      "h": 420911463219,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(420911463219),
//--TRIMMABLE-BOUNDARY-START(412321528627),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "callback",
          "p": 43122689
        }
      ],
      "n": "showAlert",
      "o": "LCFCT$TelegramWebApps$WebApp$showAlert",
      "d": 4668211,
      "h": 412321528627,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(412321528627),
//--TRIMMABLE-BOUNDARY-START(416616495923),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Boolean).$h
        }
      ],
      "n": "showConfirm",
      "o": "LCFCT$TelegramWebApps$WebApp$showConfirm",
      "d": 4668211,
      "h": 416616495923,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(416616495923),
//--TRIMMABLE-BOUNDARY-START(425206430515),
    {
      "r": 65537,
      "p": [
        {
          "n": "params",
          "p": 3423027
        },
        {
          "n": "callback",
          "p": $.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean).$h
        }
      ],
      "n": "showScanQrPopup",
      "o": "LCFCT$TelegramWebApps$WebApp$showScanQrPopup",
      "d": 4668211,
      "h": 425206430515,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(425206430515),
//--TRIMMABLE-BOUNDARY-START(21479504691),
    {
      "r": 65537,
      "n": "closeScanQrPopup",
      "o": "LCFCT$TelegramWebApps$WebApp$closeScanQrPopup",
      "d": 4668211,
      "h": 21479504691,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21479504691),
//--TRIMMABLE-BOUNDARY-START(373666822963),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.String).$h
        }
      ],
      "n": "readTextFromClipboard",
      "o": "LCFCT$TelegramWebApps$WebApp$readTextFromClipboard",
      "d": 4668211,
      "h": 373666822963,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(373666822963),
//--TRIMMABLE-BOUNDARY-START(386551724851),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Boolean).$h
        }
      ],
      "n": "requestWriteAccess",
      "o": "LCFCT$TelegramWebApps$WebApp$requestWriteAccess",
      "d": 4668211,
      "h": 386551724851,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(386551724851),
//--TRIMMABLE-BOUNDARY-START(382256757555),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Boolean).$h
        }
      ],
      "n": "requestContact",
      "o": "LCFCT$TelegramWebApps$WebApp$requestContact",
      "d": 4668211,
      "h": 382256757555,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(382256757555),
//--TRIMMABLE-BOUNDARY-START(377961790259),
    {
      "r": 262145,
      "n": "ready",
      "o": "LCFCT$TelegramWebApps$WebApp$ready",
      "d": 4668211,
      "h": 377961790259,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(377961790259),
//--TRIMMABLE-BOUNDARY-START(51544275763),
    {
      "r": 65537,
      "n": "expand",
      "o": "LCFCT$TelegramWebApps$WebApp$expand",
      "d": 4668211,
      "h": 51544275763,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51544275763),
//--TRIMMABLE-BOUNDARY-START(17184537395),
    {
      "r": 65537,
      "n": "close",
      "o": "LCFCT$TelegramWebApps$WebApp$close",
      "d": 4668211,
      "h": 17184537395,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17184537395),
//--TRIMMABLE-BOUNDARY-START(47249308467),
    {
      "r": 65537,
      "n": "enableVerticalSwipes",
      "o": "LCFCT$TelegramWebApps$WebApp$enableVerticalSwipes",
      "d": 4668211,
      "h": 47249308467,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47249308467),
//--TRIMMABLE-BOUNDARY-START(38659373875),
    {
      "r": 65537,
      "n": "disableVerticalSwipes",
      "o": "LCFCT$TelegramWebApps$WebApp$disableVerticalSwipes",
      "d": 4668211,
      "h": 38659373875,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38659373875)
  ],
  "d": 1522483,
  "h": 4668211,
  "a": [
    {
      "t": 90535,
      "c": 12884992423,
      "a": [
        {
          "v": "window.Telegram.WebApp",
          "t": 1310721
        }
      ]
    },
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp`; }
                }, $cls, ($v) => $cls.$_WebApp = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4668211)
            
            //--TRIMMABLE-BOUNDARY-START(6634291)
            static $_WebAppPlatform;
            static get WebAppPlatform()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6634291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebAppPlatform ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebAppPlatform`, ($self) => class WebAppPlatform extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12891536179)
                    /*string*/ static android = null;
                    //--TRIMMABLE-BOUNDARY-END(12891536179)
                    
                    //--TRIMMABLE-BOUNDARY-START(17186503475)
                    /*string*/ static android_x = null;
                    //--TRIMMABLE-BOUNDARY-END(17186503475)
                    
                    //--TRIMMABLE-BOUNDARY-START(21481470771)
                    /*string*/ static ios = null;
                    //--TRIMMABLE-BOUNDARY-END(21481470771)
                    
                    //--TRIMMABLE-BOUNDARY-START(25776438067)
                    /*string*/ static macos = null;
                    //--TRIMMABLE-BOUNDARY-END(25776438067)
                    
                    //--TRIMMABLE-BOUNDARY-START(30071405363)
                    /*string*/ static tdesktop = null;
                    //--TRIMMABLE-BOUNDARY-END(30071405363)
                    
                    //--TRIMMABLE-BOUNDARY-START(47251274547)
                    /*string*/ static weba = null;
                    //--TRIMMABLE-BOUNDARY-END(47251274547)
                    
                    //--TRIMMABLE-BOUNDARY-START(51546241843)
                    /*string*/ static webk = null;
                    //--TRIMMABLE-BOUNDARY-END(51546241843)
                    
                    //--TRIMMABLE-BOUNDARY-START(38661339955)
                    /*string*/ static unigram = null;
                    //--TRIMMABLE-BOUNDARY-END(38661339955)
                    
                    //--TRIMMABLE-BOUNDARY-START(42956307251)
                    /*string*/ static unknown = null;
                    //--TRIMMABLE-BOUNDARY-END(42956307251)
                    
                    //--TRIMMABLE-BOUNDARY-START(34366372659)
                    static /*WebAppPlatform */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34366372659);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebAppPlatform().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34366372659)
                    
                    //--TRIMMABLE-BOUNDARY-START(8596568883)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8596568883);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8596568883)
                    
                    //--TRIMMABLE-BOUNDARY-START(4301601587)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4301601587);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12891536179)
                            this.android = "android";
                            //--TRIMMABLE-BOUNDARY-END(12891536179)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17186503475)
                            this.android_x = "android_x";
                            //--TRIMMABLE-BOUNDARY-END(17186503475)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21481470771)
                            this.ios = "ios";
                            //--TRIMMABLE-BOUNDARY-END(21481470771)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(25776438067)
                            this.macos = "macos";
                            //--TRIMMABLE-BOUNDARY-END(25776438067)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30071405363)
                            this.tdesktop = "tdesktop";
                            //--TRIMMABLE-BOUNDARY-END(30071405363)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(47251274547)
                            this.weba = "weba";
                            //--TRIMMABLE-BOUNDARY-END(47251274547)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(51546241843)
                            this.webk = "webk";
                            //--TRIMMABLE-BOUNDARY-END(51546241843)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(38661339955)
                            this.unigram = "unigram";
                            //--TRIMMABLE-BOUNDARY-END(38661339955)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(42956307251)
                            this.unknown = "unknown";
                            //--TRIMMABLE-BOUNDARY-END(42956307251)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4301601587)
                    
                    static $h = 6634291;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12891536179),
    {
      "t": 1310721,
      "n": "android",
      "d": 6634291,
      "h": 12891536179,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12891536179),
//--TRIMMABLE-BOUNDARY-START(17186503475),
    {
      "t": 1310721,
      "n": "android_x",
      "d": 6634291,
      "h": 17186503475,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17186503475),
//--TRIMMABLE-BOUNDARY-START(21481470771),
    {
      "t": 1310721,
      "n": "ios",
      "d": 6634291,
      "h": 21481470771,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21481470771),
//--TRIMMABLE-BOUNDARY-START(25776438067),
    {
      "t": 1310721,
      "n": "macos",
      "d": 6634291,
      "h": 25776438067,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25776438067),
//--TRIMMABLE-BOUNDARY-START(30071405363),
    {
      "t": 1310721,
      "n": "tdesktop",
      "d": 6634291,
      "h": 30071405363,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30071405363),
//--TRIMMABLE-BOUNDARY-START(47251274547),
    {
      "t": 1310721,
      "n": "weba",
      "d": 6634291,
      "h": 47251274547,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47251274547),
//--TRIMMABLE-BOUNDARY-START(51546241843),
    {
      "t": 1310721,
      "n": "webk",
      "d": 6634291,
      "h": 51546241843,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51546241843),
//--TRIMMABLE-BOUNDARY-START(38661339955),
    {
      "t": 1310721,
      "n": "unigram",
      "d": 6634291,
      "h": 38661339955,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38661339955),
//--TRIMMABLE-BOUNDARY-START(42956307251),
    {
      "t": 1310721,
      "n": "unknown",
      "d": 6634291,
      "h": 42956307251,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42956307251)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8596568883),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 6634291,
      "h": 8596568883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8596568883)
  ],
  "d": 1522483,
  "h": 6634291
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebAppPlatform`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebAppPlatform`; }
                }, $cls, ($v) => $cls.$_WebAppPlatform = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6634291)
            
            //--TRIMMABLE-BOUNDARY-START(4406067)
            static $_ThemeChangedEventType;
            static get ThemeChangedEventType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4406067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_ThemeChangedEventType ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.ThemeChangedEventType`, ($self) => class ThemeChangedEventType extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(17184275251)
                    /*string*/ static themeChanged = null;
                    //--TRIMMABLE-BOUNDARY-END(17184275251)
                    
                    //--TRIMMABLE-BOUNDARY-START(21479242547)
                    static /*ThemeChangedEventType */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21479242547);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventType().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21479242547)
                    
                    //--TRIMMABLE-BOUNDARY-START(8594340659)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8594340659);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8594340659)
                    
                    //--TRIMMABLE-BOUNDARY-START(12889307955)
                    /*ThemeChangedEventType*/ static Instance = null;
                    //--TRIMMABLE-BOUNDARY-END(12889307955)
                    
                    //--TRIMMABLE-BOUNDARY-START(4299373363)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4299373363);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(17184275251)
                            this.themeChanged = "themeChanged";
                            //--TRIMMABLE-BOUNDARY-END(17184275251)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12889307955)
                            this.Instance = new $.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventType().$ctor$2($.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventType.themeChanged);
                            //--TRIMMABLE-BOUNDARY-END(12889307955)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4299373363)
                    
                    static $h = 4406067;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17184275251),
    {
      "t": 1310721,
      "n": "themeChanged",
      "d": 4406067,
      "h": 17184275251,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184275251),
//--TRIMMABLE-BOUNDARY-START(12889307955),
    {
      "t": 4406067,
      "n": "Instance",
      "d": 4406067,
      "h": 12889307955,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889307955)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594340659),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4406067,
      "h": 8594340659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594340659)
  ],
  "d": 1522483,
  "h": 4406067
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+ThemeChangedEventType`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}ThemeChangedEventType`; }
                }, $cls, ($v) => $cls.$_ThemeChangedEventType = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4406067)
            
            //--TRIMMABLE-BOUNDARY-START(4340531)
            static $_ThemeChangedEventArg;
            static get ThemeChangedEventArg()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4340531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_ThemeChangedEventArg ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg`, ($self) => class ThemeChangedEventArg
                {
                    static $h = 4340531;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42954013491),
    {
      "p": 4471603,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479177011,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38659046195,
        "f": 83886337
      },
      "n": "themeParams",
      "o": "LCFCT$TelegramWebApps$ThemeChangedEventArg$themeParams",
      "d": 4340531,
      "h": 42954013491,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42954013491),
//--TRIMMABLE-BOUNDARY-START(4299307827),
    {
      "p": 2702131,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12889242419,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30069111603,
        "f": 83886337
      },
      "n": "colorScheme",
      "o": "LCFCT$TelegramWebApps$ThemeChangedEventArg$colorScheme",
      "d": 4340531,
      "h": 4299307827,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4299307827)
  ],
  "d": 1522483,
  "h": 4340531,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+ThemeChangedEventArg`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}ThemeChangedEventArg`; }
                }, $cls, ($v) => $cls.$_ThemeChangedEventArg = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4340531)
            
            //--TRIMMABLE-BOUNDARY-START(4602675)
            static $_ViewportChangedEventType;
            static get ViewportChangedEventType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4602675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_ViewportChangedEventType ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.ViewportChangedEventType`, ($self) => class ViewportChangedEventType extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(21479439155)
                    /*string*/ static viewportChanged = null;
                    //--TRIMMABLE-BOUNDARY-END(21479439155)
                    
                    //--TRIMMABLE-BOUNDARY-START(17184471859)
                    static /*ViewportChangedEventType */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17184471859);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.ViewportChangedEventType().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17184471859)
                    
                    //--TRIMMABLE-BOUNDARY-START(8594537267)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8594537267);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8594537267)
                    
                    //--TRIMMABLE-BOUNDARY-START(12889504563)
                    /*ViewportChangedEventType*/ static Instance = null;
                    //--TRIMMABLE-BOUNDARY-END(12889504563)
                    
                    //--TRIMMABLE-BOUNDARY-START(4299569971)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4299569971);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(21479439155)
                            this.viewportChanged = "viewportChanged";
                            //--TRIMMABLE-BOUNDARY-END(21479439155)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12889504563)
                            this.Instance = new $.$fycR.LCFCT.TelegramWebApps.ViewportChangedEventType().$ctor$2($.$fycR.LCFCT.TelegramWebApps.ViewportChangedEventType.viewportChanged);
                            //--TRIMMABLE-BOUNDARY-END(12889504563)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4299569971)
                    
                    static $h = 4602675;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(21479439155),
    {
      "t": 1310721,
      "n": "viewportChanged",
      "d": 4602675,
      "h": 21479439155,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21479439155),
//--TRIMMABLE-BOUNDARY-START(12889504563),
    {
      "t": 4602675,
      "n": "Instance",
      "d": 4602675,
      "h": 12889504563,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889504563)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594537267),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4602675,
      "h": 8594537267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594537267)
  ],
  "d": 1522483,
  "h": 4602675
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+ViewportChangedEventType`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}ViewportChangedEventType`; }
                }, $cls, ($v) => $cls.$_ViewportChangedEventType = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4602675)
            
            //--TRIMMABLE-BOUNDARY-START(5978931)
            static $_WebApp_Type_4;
            static get WebApp_Type_4()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5978931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_4 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_4`, ($self) => class WebApp_Type_4 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890880819)
                    /*string*/ static mainButtonClicked = null;
                    //--TRIMMABLE-BOUNDARY-END(12890880819)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185848115)
                    static /*WebApp_Type_4 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185848115);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_4().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185848115)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595913523)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595913523);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595913523)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300946227)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300946227);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890880819)
                            this.mainButtonClicked = "mainButtonClicked";
                            //--TRIMMABLE-BOUNDARY-END(12890880819)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300946227)
                    
                    static $h = 5978931;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890880819),
    {
      "t": 1310721,
      "n": "mainButtonClicked",
      "d": 5978931,
      "h": 12890880819,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890880819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595913523),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5978931,
      "h": 8595913523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595913523)
  ],
  "d": 1522483,
  "h": 5978931
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_4`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_4`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_4 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5978931)
            
            //--TRIMMABLE-BOUNDARY-START(6044467)
            static $_WebApp_Type_5;
            static get WebApp_Type_5()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6044467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_5 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_5`, ($self) => class WebApp_Type_5 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890946355)
                    /*string*/ static backButtonClicked = null;
                    //--TRIMMABLE-BOUNDARY-END(12890946355)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185913651)
                    static /*WebApp_Type_5 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185913651);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_5().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185913651)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595979059)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595979059);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595979059)
                    
                    //--TRIMMABLE-BOUNDARY-START(4301011763)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4301011763);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890946355)
                            this.backButtonClicked = "backButtonClicked";
                            //--TRIMMABLE-BOUNDARY-END(12890946355)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4301011763)
                    
                    static $h = 6044467;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890946355),
    {
      "t": 1310721,
      "n": "backButtonClicked",
      "d": 6044467,
      "h": 12890946355,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890946355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595979059),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 6044467,
      "h": 8595979059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595979059)
  ],
  "d": 1522483,
  "h": 6044467
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_5`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_5`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_5 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6044467)
            
            //--TRIMMABLE-BOUNDARY-START(6110003)
            static $_WebApp_Type_6;
            static get WebApp_Type_6()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6110003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_6 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_6`, ($self) => class WebApp_Type_6 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12891011891)
                    /*string*/ static settingsButtonClicked = null;
                    //--TRIMMABLE-BOUNDARY-END(12891011891)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185979187)
                    static /*WebApp_Type_6 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185979187);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_6().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185979187)
                    
                    //--TRIMMABLE-BOUNDARY-START(8596044595)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8596044595);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8596044595)
                    
                    //--TRIMMABLE-BOUNDARY-START(4301077299)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4301077299);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12891011891)
                            this.settingsButtonClicked = "settingsButtonClicked";
                            //--TRIMMABLE-BOUNDARY-END(12891011891)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4301077299)
                    
                    static $h = 6110003;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12891011891),
    {
      "t": 1310721,
      "n": "settingsButtonClicked",
      "d": 6110003,
      "h": 12891011891,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12891011891)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8596044595),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 6110003,
      "h": 8596044595,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8596044595)
  ],
  "d": 1522483,
  "h": 6110003
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_6`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_6`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_6 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6110003)
            
            //--TRIMMABLE-BOUNDARY-START(6175539)
            static $_WebApp_Type_7;
            static get WebApp_Type_7()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6175539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_7 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_7`, ($self) => class WebApp_Type_7 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12891077427)
                    /*string*/ static invoiceClosed = null;
                    //--TRIMMABLE-BOUNDARY-END(12891077427)
                    
                    //--TRIMMABLE-BOUNDARY-START(17186044723)
                    static /*WebApp_Type_7 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17186044723);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_7().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17186044723)
                    
                    //--TRIMMABLE-BOUNDARY-START(8596110131)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8596110131);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8596110131)
                    
                    //--TRIMMABLE-BOUNDARY-START(4301142835)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4301142835);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12891077427)
                            this.invoiceClosed = "invoiceClosed";
                            //--TRIMMABLE-BOUNDARY-END(12891077427)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4301142835)
                    
                    static $h = 6175539;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12891077427),
    {
      "t": 1310721,
      "n": "invoiceClosed",
      "d": 6175539,
      "h": 12891077427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12891077427)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8596110131),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 6175539,
      "h": 8596110131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8596110131)
  ],
  "d": 1522483,
  "h": 6175539
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_7`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_7`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_7 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6175539)
            
            //--TRIMMABLE-BOUNDARY-START(6241075)
            static $_WebApp_Type_8;
            static get WebApp_Type_8()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6241075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_8 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_8`, ($self) => class WebApp_Type_8 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12891142963)
                    /*string*/ static popupClosed = null;
                    //--TRIMMABLE-BOUNDARY-END(12891142963)
                    
                    //--TRIMMABLE-BOUNDARY-START(17186110259)
                    static /*WebApp_Type_8 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17186110259);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_8().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17186110259)
                    
                    //--TRIMMABLE-BOUNDARY-START(8596175667)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8596175667);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8596175667)
                    
                    //--TRIMMABLE-BOUNDARY-START(4301208371)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4301208371);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12891142963)
                            this.popupClosed = "popupClosed";
                            //--TRIMMABLE-BOUNDARY-END(12891142963)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4301208371)
                    
                    static $h = 6241075;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12891142963),
    {
      "t": 1310721,
      "n": "popupClosed",
      "d": 6241075,
      "h": 12891142963,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12891142963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8596175667),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 6241075,
      "h": 8596175667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8596175667)
  ],
  "d": 1522483,
  "h": 6241075
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_8`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_8`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_8 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6241075)
            
            //--TRIMMABLE-BOUNDARY-START(6306611)
            static $_WebApp_Type_9;
            static get WebApp_Type_9()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6306611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_9 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_9`, ($self) => class WebApp_Type_9 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12891208499)
                    /*string*/ static qrTextReceived = null;
                    //--TRIMMABLE-BOUNDARY-END(12891208499)
                    
                    //--TRIMMABLE-BOUNDARY-START(17186175795)
                    static /*WebApp_Type_9 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17186175795);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_9().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17186175795)
                    
                    //--TRIMMABLE-BOUNDARY-START(8596241203)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8596241203);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8596241203)
                    
                    //--TRIMMABLE-BOUNDARY-START(4301273907)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4301273907);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12891208499)
                            this.qrTextReceived = "qrTextReceived";
                            //--TRIMMABLE-BOUNDARY-END(12891208499)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4301273907)
                    
                    static $h = 6306611;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12891208499),
    {
      "t": 1310721,
      "n": "qrTextReceived",
      "d": 6306611,
      "h": 12891208499,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12891208499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8596241203),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 6306611,
      "h": 8596241203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8596241203)
  ],
  "d": 1522483,
  "h": 6306611
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_9`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_9`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_9 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6306611)
            
            //--TRIMMABLE-BOUNDARY-START(4733747)
            static $_WebApp_Type_10;
            static get WebApp_Type_10()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4733747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_10 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_10`, ($self) => class WebApp_Type_10 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12889635635)
                    /*string*/ static scanQrPopupClosed = null;
                    //--TRIMMABLE-BOUNDARY-END(12889635635)
                    
                    //--TRIMMABLE-BOUNDARY-START(17184602931)
                    static /*WebApp_Type_10 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17184602931);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_10().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17184602931)
                    
                    //--TRIMMABLE-BOUNDARY-START(8594668339)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8594668339);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8594668339)
                    
                    //--TRIMMABLE-BOUNDARY-START(4299701043)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4299701043);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12889635635)
                            this.scanQrPopupClosed = "scanQrPopupClosed";
                            //--TRIMMABLE-BOUNDARY-END(12889635635)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4299701043)
                    
                    static $h = 4733747;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12889635635),
    {
      "t": 1310721,
      "n": "scanQrPopupClosed",
      "d": 4733747,
      "h": 12889635635,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889635635)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594668339),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4733747,
      "h": 8594668339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594668339)
  ],
  "d": 1522483,
  "h": 4733747
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_10`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_10`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_10 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4733747)
            
            //--TRIMMABLE-BOUNDARY-START(4799283)
            static $_WebApp_Type_11;
            static get WebApp_Type_11()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4799283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_11 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_11`, ($self) => class WebApp_Type_11 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12889701171)
                    /*string*/ static clipboardTextReceived = null;
                    //--TRIMMABLE-BOUNDARY-END(12889701171)
                    
                    //--TRIMMABLE-BOUNDARY-START(17184668467)
                    static /*WebApp_Type_11 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17184668467);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_11().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17184668467)
                    
                    //--TRIMMABLE-BOUNDARY-START(8594733875)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8594733875);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8594733875)
                    
                    //--TRIMMABLE-BOUNDARY-START(4299766579)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4299766579);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12889701171)
                            this.clipboardTextReceived = "clipboardTextReceived";
                            //--TRIMMABLE-BOUNDARY-END(12889701171)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4299766579)
                    
                    static $h = 4799283;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12889701171),
    {
      "t": 1310721,
      "n": "clipboardTextReceived",
      "d": 4799283,
      "h": 12889701171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889701171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594733875),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4799283,
      "h": 8594733875,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594733875)
  ],
  "d": 1522483,
  "h": 4799283
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_11`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_11`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_11 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4799283)
            
            //--TRIMMABLE-BOUNDARY-START(4864819)
            static $_WebApp_Type_12;
            static get WebApp_Type_12()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4864819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_12 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_12`, ($self) => class WebApp_Type_12 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(17184734003)
                    /*string*/ static writeAccessRequested = null;
                    //--TRIMMABLE-BOUNDARY-END(17184734003)
                    
                    //--TRIMMABLE-BOUNDARY-START(12889766707)
                    static /*WebApp_Type_12 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12889766707);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_12().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12889766707)
                    
                    //--TRIMMABLE-BOUNDARY-START(8594799411)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8594799411);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8594799411)
                    
                    //--TRIMMABLE-BOUNDARY-START(4299832115)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4299832115);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(17184734003)
                            this.writeAccessRequested = "writeAccessRequested";
                            //--TRIMMABLE-BOUNDARY-END(17184734003)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4299832115)
                    
                    static $h = 4864819;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17184734003),
    {
      "t": 1310721,
      "n": "writeAccessRequested",
      "d": 4864819,
      "h": 17184734003,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184734003)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594799411),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4864819,
      "h": 8594799411,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594799411)
  ],
  "d": 1522483,
  "h": 4864819
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_12`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_12`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_12 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4864819)
            
            //--TRIMMABLE-BOUNDARY-START(4930355)
            static $_WebApp_Type_13;
            static get WebApp_Type_13()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4930355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_13 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_13`, ($self) => class WebApp_Type_13 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12889832243)
                    /*string*/ static allowed = null;
                    //--TRIMMABLE-BOUNDARY-END(12889832243)
                    
                    //--TRIMMABLE-BOUNDARY-START(17184799539)
                    /*string*/ static cancelled = null;
                    //--TRIMMABLE-BOUNDARY-END(17184799539)
                    
                    //--TRIMMABLE-BOUNDARY-START(21479766835)
                    static /*WebApp_Type_13 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21479766835);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_13().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21479766835)
                    
                    //--TRIMMABLE-BOUNDARY-START(8594864947)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8594864947);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8594864947)
                    
                    //--TRIMMABLE-BOUNDARY-START(4299897651)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4299897651);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12889832243)
                            this.allowed = "allowed";
                            //--TRIMMABLE-BOUNDARY-END(12889832243)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17184799539)
                            this.cancelled = "cancelled";
                            //--TRIMMABLE-BOUNDARY-END(17184799539)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4299897651)
                    
                    static $h = 4930355;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12889832243),
    {
      "t": 1310721,
      "n": "allowed",
      "d": 4930355,
      "h": 12889832243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889832243),
//--TRIMMABLE-BOUNDARY-START(17184799539),
    {
      "t": 1310721,
      "n": "cancelled",
      "d": 4930355,
      "h": 17184799539,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184799539)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594864947),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4930355,
      "h": 8594864947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594864947)
  ],
  "d": 1522483,
  "h": 4930355
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_13`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_13`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_13 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4930355)
            
            //--TRIMMABLE-BOUNDARY-START(4995891)
            static $_WebApp_Type_14;
            static get WebApp_Type_14()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4995891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_14 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_14`, ($self) => class WebApp_Type_14 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12889897779)
                    /*string*/ static contactRequested = null;
                    //--TRIMMABLE-BOUNDARY-END(12889897779)
                    
                    //--TRIMMABLE-BOUNDARY-START(17184865075)
                    static /*WebApp_Type_14 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17184865075);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_14().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17184865075)
                    
                    //--TRIMMABLE-BOUNDARY-START(8594930483)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8594930483);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8594930483)
                    
                    //--TRIMMABLE-BOUNDARY-START(4299963187)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4299963187);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12889897779)
                            this.contactRequested = "contactRequested";
                            //--TRIMMABLE-BOUNDARY-END(12889897779)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4299963187)
                    
                    static $h = 4995891;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12889897779),
    {
      "t": 1310721,
      "n": "contactRequested",
      "d": 4995891,
      "h": 12889897779,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889897779)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594930483),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4995891,
      "h": 8594930483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594930483)
  ],
  "d": 1522483,
  "h": 4995891
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_14`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_14`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_14 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4995891)
            
            //--TRIMMABLE-BOUNDARY-START(5061427)
            static $_WebApp_Type_15;
            static get WebApp_Type_15()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5061427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_15 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_15`, ($self) => class WebApp_Type_15 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(17184930611)
                    /*string*/ static sent = null;
                    //--TRIMMABLE-BOUNDARY-END(17184930611)
                    
                    //--TRIMMABLE-BOUNDARY-START(12889963315)
                    /*string*/ static cancelled = null;
                    //--TRIMMABLE-BOUNDARY-END(12889963315)
                    
                    //--TRIMMABLE-BOUNDARY-START(21479897907)
                    static /*WebApp_Type_15 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21479897907);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_15().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21479897907)
                    
                    //--TRIMMABLE-BOUNDARY-START(8594996019)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8594996019);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8594996019)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300028723)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300028723);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(17184930611)
                            this.sent = "sent";
                            //--TRIMMABLE-BOUNDARY-END(17184930611)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12889963315)
                            this.cancelled = "cancelled";
                            //--TRIMMABLE-BOUNDARY-END(12889963315)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300028723)
                    
                    static $h = 5061427;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17184930611),
    {
      "t": 1310721,
      "n": "sent",
      "d": 5061427,
      "h": 17184930611,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184930611),
//--TRIMMABLE-BOUNDARY-START(12889963315),
    {
      "t": 1310721,
      "n": "cancelled",
      "d": 5061427,
      "h": 12889963315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889963315)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594996019),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5061427,
      "h": 8594996019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594996019)
  ],
  "d": 1522483,
  "h": 5061427
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_15`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_15`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_15 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5061427)
            
            //--TRIMMABLE-BOUNDARY-START(5126963)
            static $_WebApp_Type_16;
            static get WebApp_Type_16()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5126963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_16 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_16`, ($self) => class WebApp_Type_16 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890028851)
                    /*string*/ static biometricManagerUpdated = null;
                    //--TRIMMABLE-BOUNDARY-END(12890028851)
                    
                    //--TRIMMABLE-BOUNDARY-START(17184996147)
                    static /*WebApp_Type_16 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17184996147);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_16().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17184996147)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595061555)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595061555);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595061555)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300094259)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300094259);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890028851)
                            this.biometricManagerUpdated = "biometricManagerUpdated";
                            //--TRIMMABLE-BOUNDARY-END(12890028851)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300094259)
                    
                    static $h = 5126963;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890028851),
    {
      "t": 1310721,
      "n": "biometricManagerUpdated",
      "d": 5126963,
      "h": 12890028851,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890028851)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595061555),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5126963,
      "h": 8595061555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595061555)
  ],
  "d": 1522483,
  "h": 5126963
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_16`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_16`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_16 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5126963)
            
            //--TRIMMABLE-BOUNDARY-START(5192499)
            static $_WebApp_Type_17;
            static get WebApp_Type_17()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5192499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_17 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_17`, ($self) => class WebApp_Type_17 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890094387)
                    /*string*/ static biometricAuthRequested = null;
                    //--TRIMMABLE-BOUNDARY-END(12890094387)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185061683)
                    static /*WebApp_Type_17 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185061683);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_17().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185061683)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595127091)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595127091);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595127091)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300159795)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300159795);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890094387)
                            this.biometricAuthRequested = "biometricAuthRequested";
                            //--TRIMMABLE-BOUNDARY-END(12890094387)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300159795)
                    
                    static $h = 5192499;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890094387),
    {
      "t": 1310721,
      "n": "biometricAuthRequested",
      "d": 5192499,
      "h": 12890094387,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890094387)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595127091),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5192499,
      "h": 8595127091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595127091)
  ],
  "d": 1522483,
  "h": 5192499
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_17`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_17`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_17 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5192499)
            
            //--TRIMMABLE-BOUNDARY-START(5258035)
            static $_WebApp_Type_18;
            static get WebApp_Type_18()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5258035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_18 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_18`, ($self) => class WebApp_Type_18 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890159923)
                    /*string*/ static biometricTokenUpdated = null;
                    //--TRIMMABLE-BOUNDARY-END(12890159923)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185127219)
                    static /*WebApp_Type_18 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185127219);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_18().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185127219)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595192627)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595192627);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595192627)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300225331)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300225331);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890159923)
                            this.biometricTokenUpdated = "biometricTokenUpdated";
                            //--TRIMMABLE-BOUNDARY-END(12890159923)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300225331)
                    
                    static $h = 5258035;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890159923),
    {
      "t": 1310721,
      "n": "biometricTokenUpdated",
      "d": 5258035,
      "h": 12890159923,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890159923)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595192627),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5258035,
      "h": 8595192627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595192627)
  ],
  "d": 1522483,
  "h": 5258035
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_18`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_18`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_18 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5258035)
            
            //--TRIMMABLE-BOUNDARY-START(5323571)
            static $_WebApp_Type_19;
            static get WebApp_Type_19()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5323571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_19 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_19`, ($self) => class WebApp_Type_19 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(30070094643)
                    /*string*/ static themeChanged = null;
                    //--TRIMMABLE-BOUNDARY-END(30070094643)
                    
                    //--TRIMMABLE-BOUNDARY-START(21480160051)
                    /*string*/ static mainButtonClicked = null;
                    //--TRIMMABLE-BOUNDARY-END(21480160051)
                    
                    //--TRIMMABLE-BOUNDARY-START(12890225459)
                    /*string*/ static backButtonClicked = null;
                    //--TRIMMABLE-BOUNDARY-END(12890225459)
                    
                    //--TRIMMABLE-BOUNDARY-START(25775127347)
                    /*string*/ static settingsButtonClicked = null;
                    //--TRIMMABLE-BOUNDARY-END(25775127347)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185192755)
                    /*string*/ static biometricManagerUpdated = null;
                    //--TRIMMABLE-BOUNDARY-END(17185192755)
                    
                    //--TRIMMABLE-BOUNDARY-START(34365061939)
                    static /*WebApp_Type_19 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34365061939);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_19().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34365061939)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595258163)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595258163);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595258163)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300290867)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300290867);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(30070094643)
                            this.themeChanged = "themeChanged";
                            //--TRIMMABLE-BOUNDARY-END(30070094643)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21480160051)
                            this.mainButtonClicked = "mainButtonClicked";
                            //--TRIMMABLE-BOUNDARY-END(21480160051)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890225459)
                            this.backButtonClicked = "backButtonClicked";
                            //--TRIMMABLE-BOUNDARY-END(12890225459)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(25775127347)
                            this.settingsButtonClicked = "settingsButtonClicked";
                            //--TRIMMABLE-BOUNDARY-END(25775127347)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17185192755)
                            this.biometricManagerUpdated = "biometricManagerUpdated";
                            //--TRIMMABLE-BOUNDARY-END(17185192755)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300290867)
                    
                    static $h = 5323571;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(30070094643),
    {
      "t": 1310721,
      "n": "themeChanged",
      "d": 5323571,
      "h": 30070094643,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30070094643),
//--TRIMMABLE-BOUNDARY-START(21480160051),
    {
      "t": 1310721,
      "n": "mainButtonClicked",
      "d": 5323571,
      "h": 21480160051,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21480160051),
//--TRIMMABLE-BOUNDARY-START(12890225459),
    {
      "t": 1310721,
      "n": "backButtonClicked",
      "d": 5323571,
      "h": 12890225459,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890225459),
//--TRIMMABLE-BOUNDARY-START(25775127347),
    {
      "t": 1310721,
      "n": "settingsButtonClicked",
      "d": 5323571,
      "h": 25775127347,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25775127347),
//--TRIMMABLE-BOUNDARY-START(17185192755),
    {
      "t": 1310721,
      "n": "biometricManagerUpdated",
      "d": 5323571,
      "h": 17185192755,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17185192755)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595258163),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5323571,
      "h": 8595258163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595258163)
  ],
  "d": 1522483,
  "h": 5323571
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_19`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_19`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_19 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5323571)
            
            //--TRIMMABLE-BOUNDARY-START(5389107)
            static $_WebApp_Type_20;
            static get WebApp_Type_20()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5389107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_20 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_20`, ($self) => class WebApp_Type_20 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(17185258291)
                    /*string*/ static viewportChanged = null;
                    //--TRIMMABLE-BOUNDARY-END(17185258291)
                    
                    //--TRIMMABLE-BOUNDARY-START(12890290995)
                    static /*WebApp_Type_20 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12890290995);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_20().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12890290995)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595323699)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595323699);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595323699)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300356403)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300356403);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(17185258291)
                            this.viewportChanged = "viewportChanged";
                            //--TRIMMABLE-BOUNDARY-END(17185258291)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300356403)
                    
                    static $h = 5389107;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17185258291),
    {
      "t": 1310721,
      "n": "viewportChanged",
      "d": 5389107,
      "h": 17185258291,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17185258291)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595323699),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5389107,
      "h": 8595323699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595323699)
  ],
  "d": 1522483,
  "h": 5389107
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_20`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_20`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_20 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5389107)
            
            //--TRIMMABLE-BOUNDARY-START(5454643)
            static $_WebApp_Type_21;
            static get WebApp_Type_21()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5454643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_21 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_21`, ($self) => class WebApp_Type_21 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890356531)
                    /*string*/ static invoiceClosed = null;
                    //--TRIMMABLE-BOUNDARY-END(12890356531)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185323827)
                    static /*WebApp_Type_21 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185323827);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_21().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185323827)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595389235)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595389235);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595389235)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300421939)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300421939);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890356531)
                            this.invoiceClosed = "invoiceClosed";
                            //--TRIMMABLE-BOUNDARY-END(12890356531)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300421939)
                    
                    static $h = 5454643;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890356531),
    {
      "t": 1310721,
      "n": "invoiceClosed",
      "d": 5454643,
      "h": 12890356531,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890356531)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595389235),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5454643,
      "h": 8595389235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595389235)
  ],
  "d": 1522483,
  "h": 5454643
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_21`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_21`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_21 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5454643)
            
            //--TRIMMABLE-BOUNDARY-START(5520179)
            static $_WebApp_Type_22;
            static get WebApp_Type_22()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5520179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_22 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_22`, ($self) => class WebApp_Type_22 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890422067)
                    /*string*/ static popupClosed = null;
                    //--TRIMMABLE-BOUNDARY-END(12890422067)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185389363)
                    static /*WebApp_Type_22 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185389363);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_22().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185389363)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595454771)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595454771);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595454771)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300487475)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300487475);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890422067)
                            this.popupClosed = "popupClosed";
                            //--TRIMMABLE-BOUNDARY-END(12890422067)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300487475)
                    
                    static $h = 5520179;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890422067),
    {
      "t": 1310721,
      "n": "popupClosed",
      "d": 5520179,
      "h": 12890422067,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890422067)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595454771),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5520179,
      "h": 8595454771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595454771)
  ],
  "d": 1522483,
  "h": 5520179
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_22`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_22`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_22 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5520179)
            
            //--TRIMMABLE-BOUNDARY-START(5585715)
            static $_WebApp_Type_23;
            static get WebApp_Type_23()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5585715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_23 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_23`, ($self) => class WebApp_Type_23 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890487603)
                    /*string*/ static qrTextReceived = null;
                    //--TRIMMABLE-BOUNDARY-END(12890487603)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185454899)
                    static /*WebApp_Type_23 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185454899);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_23().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185454899)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595520307)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595520307);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595520307)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300553011)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300553011);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890487603)
                            this.qrTextReceived = "qrTextReceived";
                            //--TRIMMABLE-BOUNDARY-END(12890487603)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300553011)
                    
                    static $h = 5585715;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890487603),
    {
      "t": 1310721,
      "n": "qrTextReceived",
      "d": 5585715,
      "h": 12890487603,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890487603)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595520307),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5585715,
      "h": 8595520307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595520307)
  ],
  "d": 1522483,
  "h": 5585715
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_23`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_23`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_23 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5585715)
            
            //--TRIMMABLE-BOUNDARY-START(5651251)
            static $_WebApp_Type_24;
            static get WebApp_Type_24()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5651251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_24 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_24`, ($self) => class WebApp_Type_24 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890553139)
                    /*string*/ static clipboardTextReceived = null;
                    //--TRIMMABLE-BOUNDARY-END(12890553139)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185520435)
                    static /*WebApp_Type_24 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185520435);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_24().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185520435)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595585843)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595585843);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595585843)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300618547)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300618547);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890553139)
                            this.clipboardTextReceived = "clipboardTextReceived";
                            //--TRIMMABLE-BOUNDARY-END(12890553139)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300618547)
                    
                    static $h = 5651251;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890553139),
    {
      "t": 1310721,
      "n": "clipboardTextReceived",
      "d": 5651251,
      "h": 12890553139,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890553139)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595585843),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5651251,
      "h": 8595585843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595585843)
  ],
  "d": 1522483,
  "h": 5651251
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_24`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_24`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_24 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5651251)
            
            //--TRIMMABLE-BOUNDARY-START(5716787)
            static $_WebApp_Type_25;
            static get WebApp_Type_25()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5716787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_25 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_25`, ($self) => class WebApp_Type_25 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890618675)
                    /*string*/ static biometricAuthRequested = null;
                    //--TRIMMABLE-BOUNDARY-END(12890618675)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185585971)
                    static /*WebApp_Type_25 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185585971);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_25().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185585971)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595651379)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595651379);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595651379)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300684083)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300684083);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890618675)
                            this.biometricAuthRequested = "biometricAuthRequested";
                            //--TRIMMABLE-BOUNDARY-END(12890618675)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300684083)
                    
                    static $h = 5716787;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890618675),
    {
      "t": 1310721,
      "n": "biometricAuthRequested",
      "d": 5716787,
      "h": 12890618675,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890618675)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595651379),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5716787,
      "h": 8595651379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595651379)
  ],
  "d": 1522483,
  "h": 5716787
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_25`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_25`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_25 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5716787)
            
            //--TRIMMABLE-BOUNDARY-START(5782323)
            static $_WebApp_Type_26;
            static get WebApp_Type_26()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5782323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_26 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_26`, ($self) => class WebApp_Type_26 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12890684211)
                    /*string*/ static biometricTokenUpdated = null;
                    //--TRIMMABLE-BOUNDARY-END(12890684211)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185651507)
                    static /*WebApp_Type_26 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17185651507);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_26().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17185651507)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595716915)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595716915);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595716915)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300749619)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300749619);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890684211)
                            this.biometricTokenUpdated = "biometricTokenUpdated";
                            //--TRIMMABLE-BOUNDARY-END(12890684211)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300749619)
                    
                    static $h = 5782323;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890684211),
    {
      "t": 1310721,
      "n": "biometricTokenUpdated",
      "d": 5782323,
      "h": 12890684211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890684211)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595716915),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5782323,
      "h": 8595716915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595716915)
  ],
  "d": 1522483,
  "h": 5782323
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_26`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_26`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_26 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5782323)
            
            //--TRIMMABLE-BOUNDARY-START(5847859)
            static $_WebApp_Type_27;
            static get WebApp_Type_27()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5847859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_27 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_27`, ($self) => class WebApp_Type_27 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(30070618931)
                    /*string*/ static users = null;
                    //--TRIMMABLE-BOUNDARY-END(30070618931)
                    
                    //--TRIMMABLE-BOUNDARY-START(12890749747)
                    /*string*/ static bots = null;
                    //--TRIMMABLE-BOUNDARY-END(12890749747)
                    
                    //--TRIMMABLE-BOUNDARY-START(21480684339)
                    /*string*/ static groups = null;
                    //--TRIMMABLE-BOUNDARY-END(21480684339)
                    
                    //--TRIMMABLE-BOUNDARY-START(17185717043)
                    /*string*/ static channels = null;
                    //--TRIMMABLE-BOUNDARY-END(17185717043)
                    
                    //--TRIMMABLE-BOUNDARY-START(25775651635)
                    static /*WebApp_Type_27 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25775651635);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_27().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25775651635)
                    
                    //--TRIMMABLE-BOUNDARY-START(8595782451)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8595782451);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8595782451)
                    
                    //--TRIMMABLE-BOUNDARY-START(4300815155)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4300815155);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(30070618931)
                            this.users = "users";
                            //--TRIMMABLE-BOUNDARY-END(30070618931)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12890749747)
                            this.bots = "bots";
                            //--TRIMMABLE-BOUNDARY-END(12890749747)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21480684339)
                            this.groups = "groups";
                            //--TRIMMABLE-BOUNDARY-END(21480684339)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17185717043)
                            this.channels = "channels";
                            //--TRIMMABLE-BOUNDARY-END(17185717043)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4300815155)
                    
                    static $h = 5847859;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(30070618931),
    {
      "t": 1310721,
      "n": "users",
      "d": 5847859,
      "h": 30070618931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30070618931),
//--TRIMMABLE-BOUNDARY-START(12890749747),
    {
      "t": 1310721,
      "n": "bots",
      "d": 5847859,
      "h": 12890749747,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890749747),
//--TRIMMABLE-BOUNDARY-START(21480684339),
    {
      "t": 1310721,
      "n": "groups",
      "d": 5847859,
      "h": 21480684339,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21480684339),
//--TRIMMABLE-BOUNDARY-START(17185717043),
    {
      "t": 1310721,
      "n": "channels",
      "d": 5847859,
      "h": 17185717043,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17185717043)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595782451),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5847859,
      "h": 8595782451,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595782451)
  ],
  "d": 1522483,
  "h": 5847859
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_27`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_27`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_27 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5847859)
            
            //--TRIMMABLE-BOUNDARY-START(5913395)
            static $_WebApp_Type_28;
            static get WebApp_Type_28()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5913395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebApp_Type_28 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebApp_Type_28`, ($self) => class WebApp_Type_28
                {
                    static $h = 5913395;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21480749875),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8595847987,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 17185782579,
        "f": 83886337
      },
      "n": "try_instant_view",
      "o": "LCFCT$TelegramWebApps$WebApp_Type_28$try_instant_view",
      "d": 5913395,
      "h": 21480749875,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21480749875)
  ],
  "d": 1522483,
  "h": 5913395,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebApp_Type_28`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebApp_Type_28`; }
                }, $cls, ($v) => $cls.$_WebApp_Type_28 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(5913395)
            
            //--TRIMMABLE-BOUNDARY-START(4471603)
            static $_ThemeParams;
            static get ThemeParams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4471603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_ThemeParams ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.ThemeParams`, ($self) => class ThemeParams
                {
                    static $h = 4471603;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8594406195),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38659177267,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188983032627,
        "f": 83886337
      },
      "n": "bg_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$bg_color",
      "d": 4471603,
      "h": 8594406195,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8594406195),
//--TRIMMABLE-BOUNDARY-START(300652182323),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141738392371,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292062247731,
        "f": 83886337
      },
      "n": "text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$text_color",
      "d": 4471603,
      "h": 300652182323,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(300652182323),
//--TRIMMABLE-BOUNDARY-START(150328326963),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81608850227,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231932705587,
        "f": 83886337
      },
      "n": "hint_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$hint_color",
      "d": 4471603,
      "h": 150328326963,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(150328326963),
//--TRIMMABLE-BOUNDARY-START(154623294259),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90198784819,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240522640179,
        "f": 83886337
      },
      "n": "link_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$link_color",
      "d": 4471603,
      "h": 154623294259,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(154623294259),
//--TRIMMABLE-BOUNDARY-START(12889373491),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47249111859,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197572967219,
        "f": 83886337
      },
      "n": "button_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$button_color",
      "d": 4471603,
      "h": 12889373491,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12889373491),
//--TRIMMABLE-BOUNDARY-START(17184340787),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55839046451,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206162901811,
        "f": 83886337
      },
      "n": "button_text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$button_text_color",
      "d": 4471603,
      "h": 17184340787,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17184340787),
//--TRIMMABLE-BOUNDARY-START(158918261555),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98788719411,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249112574771,
        "f": 83886337
      },
      "n": "secondary_bg_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$secondary_bg_color",
      "d": 4471603,
      "h": 158918261555,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(158918261555),
//--TRIMMABLE-BOUNDARY-START(146033359667),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73018915635,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223342770995,
        "f": 83886337
      },
      "n": "header_bg_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$header_bg_color",
      "d": 4471603,
      "h": 146033359667,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(146033359667),
//--TRIMMABLE-BOUNDARY-START(4299438899),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069242675,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180393098035,
        "f": 83886337
      },
      "n": "accent_text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$accent_text_color",
      "d": 4471603,
      "h": 4299438899,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4299438899),
//--TRIMMABLE-BOUNDARY-START(163213228851),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107378654003,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257702509363,
        "f": 83886337
      },
      "n": "section_bg_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$section_bg_color",
      "d": 4471603,
      "h": 163213228851,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(163213228851),
//--TRIMMABLE-BOUNDARY-START(167508196147),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115968588595,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266292443955,
        "f": 83886337
      },
      "n": "section_header_text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$section_header_text_color",
      "d": 4471603,
      "h": 167508196147,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(167508196147),
//--TRIMMABLE-BOUNDARY-START(171803163443),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124558523187,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274882378547,
        "f": 83886337
      },
      "n": "section_separator_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$section_separator_color",
      "d": 4471603,
      "h": 171803163443,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(171803163443),
//--TRIMMABLE-BOUNDARY-START(296357215027),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133148457779,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283472313139,
        "f": 83886337
      },
      "n": "subtitle_text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$subtitle_text_color",
      "d": 4471603,
      "h": 296357215027,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(296357215027),
//--TRIMMABLE-BOUNDARY-START(21479308083),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64428981043,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214752836403,
        "f": 83886337
      },
      "n": "destructive_text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$destructive_text_color",
      "d": 4471603,
      "h": 21479308083,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21479308083)
  ],
  "d": 1522483,
  "h": 4471603,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+ThemeParams`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}ThemeParams`; }
                }, $cls, ($v) => $cls.$_ThemeParams = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4471603)
            
            //--TRIMMABLE-BOUNDARY-START(3554099)
            static $_StoryShareParams;
            static get StoryShareParams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3554099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_StoryShareParams ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.StoryShareParams`, ($self) => class StoryShareParams
                {
                    static $h = 3554099;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38658259763),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593488691,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25773357875,
        "f": 83886337
      },
      "n": "text",
      "o": "LCFCT$TelegramWebApps$StoryShareParams$text",
      "d": 3554099,
      "h": 38658259763,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38658259763),
//--TRIMMABLE-BOUNDARY-START(42953227059),
    {
      "p": 3619635,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183423283,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34363292467,
        "f": 83886337
      },
      "n": "widget_link",
      "o": "LCFCT$TelegramWebApps$StoryShareParams$widget_link",
      "d": 3554099,
      "h": 42953227059,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42953227059)
  ],
  "d": 1522483,
  "h": 3554099,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+StoryShareParams`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}StoryShareParams`; }
                }, $cls, ($v) => $cls.$_StoryShareParams = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3554099)
            
            //--TRIMMABLE-BOUNDARY-START(3619635)
            static $_StoryWidgetLink;
            static get StoryWidgetLink()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3619635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_StoryWidgetLink ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.StoryWidgetLink`, ($self) => class StoryWidgetLink
                {
                    static $h = 3619635;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42953292595),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183488819,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38658325299,
        "f": 83886337
      },
      "n": "url",
      "o": "LCFCT$TelegramWebApps$StoryWidgetLink$url",
      "d": 3619635,
      "h": 42953292595,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42953292595),
//--TRIMMABLE-BOUNDARY-START(21478456115),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593554227,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30068390707,
        "f": 83886337
      },
      "n": "name",
      "o": "LCFCT$TelegramWebApps$StoryWidgetLink$name",
      "d": 3619635,
      "h": 21478456115,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21478456115)
  ],
  "d": 1522483,
  "h": 3619635,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+StoryWidgetLink`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}StoryWidgetLink`; }
                }, $cls, ($v) => $cls.$_StoryWidgetLink = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3619635)
            
            //--TRIMMABLE-BOUNDARY-START(3291955)
            static $_PopupParams;
            static get PopupParams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3291955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_PopupParams ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.PopupParams`, ($self) => class PopupParams
                {
                    static $h = 3291955;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64427801395),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068063027,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132834099,
        "f": 83886337
      },
      "n": "title",
      "o": "LCFCT$TelegramWebApps$PopupParams$title",
      "d": 3291955,
      "h": 64427801395,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64427801395),
//--TRIMMABLE-BOUNDARY-START(34363030323),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478128435,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51542899507,
        "f": 83886337
      },
      "n": "message",
      "o": "LCFCT$TelegramWebApps$PopupParams$message",
      "d": 3291955,
      "h": 34363030323,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34363030323),
//--TRIMMABLE-BOUNDARY-START(4298259251),
    {
      "p": $.$typeArray($.$fycR.LCFCT.TelegramWebApps.PopupButton).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888193843,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42952964915,
        "f": 83886337
      },
      "n": "buttons",
      "o": "LCFCT$TelegramWebApps$PopupParams$buttons",
      "d": 3291955,
      "h": 4298259251,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4298259251)
  ],
  "d": 1522483,
  "h": 3291955,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+PopupParams`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}PopupParams`; }
                }, $cls, ($v) => $cls.$_PopupParams = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3291955)
            
            //--TRIMMABLE-BOUNDARY-START(3423027)
            static $_ScanQrPopupParams;
            static get ScanQrPopupParams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3423027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_ScanQrPopupParams ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.ScanQrPopupParams`, ($self) => class ScanQrPopupParams
                {
                    static $h = 3423027;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478259507),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593357619,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 17183292211,
        "f": 83886337
      },
      "n": "text",
      "o": "LCFCT$TelegramWebApps$ScanQrPopupParams$text",
      "d": 3423027,
      "h": 21478259507,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21478259507)
  ],
  "d": 1522483,
  "h": 3423027,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+ScanQrPopupParams`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}ScanQrPopupParams`; }
                }, $cls, ($v) => $cls.$_ScanQrPopupParams = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3423027)
            
            //--TRIMMABLE-BOUNDARY-START(3160883)
            static $_PopupButton;
            static get PopupButton()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3160883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_PopupButton ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.PopupButton`, ($self) => class PopupButton extends $.$TLYN.LTDU.TypeAlias
                {
                    //--TRIMMABLE-BOUNDARY-START(4298128179)
                    $ctor$2(/*Union<IDefaultDestructivePopupButton, IOkCloseCancelPopupButton>*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298128179);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298128179)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593095475)
                    static /*PopupButton */ op_Implicit(/*Union<IDefaultDestructivePopupButton, IOkCloseCancelPopupButton>*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8593095475);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.PopupButton().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8593095475)
                    
                    static $h = 3160883;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.TypeAlias; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298128179),
    {
      "p": [
        {
          "n": "value",
          "p": $.$TLYN.LTDU.Union$$$($.$fycR.LCFCT.IDefaultDestructivePopupButton, $.$fycR.LCFCT.IOkCloseCancelPopupButton).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3160883,
      "h": 4298128179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298128179)
  ],
  "d": 1522483,
  "h": 3160883
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+PopupButton`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}PopupButton`; }
                }, $cls, ($v) => $cls.$_PopupButton = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3160883)
            
            //--TRIMMABLE-BOUNDARY-START(2112307)
            static $_BackButton;
            static get BackButton()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2112307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_BackButton ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.BackButton`, ($self) => class BackButton
                {
                    static $h = 2112307;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181981491),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592046899,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34361850675,
        "f": 83886337
      },
      "n": "isVisible",
      "o": "LCFCT$TelegramWebApps$BackButton$isVisible",
      "d": 2112307,
      "h": 17181981491,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17181981491)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771916083),
    {
      "r": 2112307,
      "p": [
        {
          "n": "callback",
          "p": 43122689
        }
      ],
      "n": "onClick",
      "o": "LCFCT$TelegramWebApps$BackButton$onClick",
      "d": 2112307,
      "h": 25771916083,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25771916083),
//--TRIMMABLE-BOUNDARY-START(21476948787),
    {
      "r": 2112307,
      "p": [
        {
          "n": "callback",
          "p": 43122689
        }
      ],
      "n": "offClick",
      "o": "LCFCT$TelegramWebApps$BackButton$offClick",
      "d": 2112307,
      "h": 21476948787,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476948787),
//--TRIMMABLE-BOUNDARY-START(38656817971),
    {
      "r": 2112307,
      "n": "show",
      "o": "LCFCT$TelegramWebApps$BackButton$show",
      "d": 2112307,
      "h": 38656817971,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38656817971),
//--TRIMMABLE-BOUNDARY-START(12887014195),
    {
      "r": 2112307,
      "n": "hide",
      "o": "LCFCT$TelegramWebApps$BackButton$hide",
      "d": 2112307,
      "h": 12887014195,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12887014195)
  ],
  "d": 1522483,
  "h": 2112307,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+BackButton`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}BackButton`; }
                }, $cls, ($v) => $cls.$_BackButton = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2112307)
            
            //--TRIMMABLE-BOUNDARY-START(3029811)
            static $_MainButton;
            static get MainButton()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3029811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_MainButton ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.MainButton`, ($self) => class MainButton
                {
                    static $h = 3029811;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158916819763),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837604659,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128852048691,
        "f": 83886337
      },
      "n": "text",
      "o": "LCFCT$TelegramWebApps$MainButton$text",
      "d": 3029811,
      "h": 158916819763,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(158916819763),
//--TRIMMABLE-BOUNDARY-START(4297997107),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477866291,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103082244915,
        "f": 83886337
      },
      "n": "color",
      "o": "LCFCT$TelegramWebApps$MainButton$color",
      "d": 3029811,
      "h": 4297997107,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4297997107),
//--TRIMMABLE-BOUNDARY-START(163211787059),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427539251,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137441983283,
        "f": 83886337
      },
      "n": "textColor",
      "o": "LCFCT$TelegramWebApps$MainButton$textColor",
      "d": 3029811,
      "h": 163211787059,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(163211787059),
//--TRIMMABLE-BOUNDARY-START(85902375731),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247670067,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120262114099,
        "f": 83886337
      },
      "n": "isVisible",
      "o": "LCFCT$TelegramWebApps$MainButton$isVisible",
      "d": 3029811,
      "h": 85902375731,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(85902375731),
//--TRIMMABLE-BOUNDARY-START(77312441139),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067800883,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111672179507,
        "f": 83886337
      },
      "n": "isActive",
      "o": "LCFCT$TelegramWebApps$MainButton$isActive",
      "d": 3029811,
      "h": 77312441139,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(77312441139),
//--TRIMMABLE-BOUNDARY-START(81607408435),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657735475,
        "f": 50331905
      },
      "n": "isProgressVisible",
      "o": "LCFCT$TelegramWebApps$MainButton$isProgressVisible",
      "d": 3029811,
      "h": 81607408435,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(81607408435)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146031917875),
    {
      "r": 3029811,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "setText",
      "o": "LCFCT$TelegramWebApps$MainButton$setText",
      "d": 3029811,
      "h": 146031917875,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(146031917875),
//--TRIMMABLE-BOUNDARY-START(94492310323),
    {
      "r": 3029811,
      "p": [
        {
          "n": "callback",
          "p": 43122689
        }
      ],
      "n": "onClick",
      "o": "LCFCT$TelegramWebApps$MainButton$onClick",
      "d": 3029811,
      "h": 94492310323,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(94492310323),
//--TRIMMABLE-BOUNDARY-START(90197343027),
    {
      "r": 3029811,
      "p": [
        {
          "n": "callback",
          "p": 43122689
        }
      ],
      "n": "offClick",
      "o": "LCFCT$TelegramWebApps$MainButton$offClick",
      "d": 3029811,
      "h": 90197343027,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(90197343027),
//--TRIMMABLE-BOUNDARY-START(150326885171),
    {
      "r": 3029811,
      "n": "show",
      "o": "LCFCT$TelegramWebApps$MainButton$show",
      "d": 3029811,
      "h": 150326885171,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(150326885171),
//--TRIMMABLE-BOUNDARY-START(68722506547),
    {
      "r": 3029811,
      "n": "hide",
      "o": "LCFCT$TelegramWebApps$MainButton$hide",
      "d": 3029811,
      "h": 68722506547,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(68722506547),
//--TRIMMABLE-BOUNDARY-START(12887931699),
    {
      "r": 3029811,
      "n": "enable",
      "o": "LCFCT$TelegramWebApps$MainButton$enable",
      "d": 3029811,
      "h": 12887931699,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12887931699),
//--TRIMMABLE-BOUNDARY-START(8592964403),
    {
      "r": 3029811,
      "n": "disable",
      "o": "LCFCT$TelegramWebApps$MainButton$disable",
      "d": 3029811,
      "h": 8592964403,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8592964403),
//--TRIMMABLE-BOUNDARY-START(154621852467),
    {
      "r": 3029811,
      "p": [
        {
          "n": "leaveActive",
          "p": 262145
        }
      ],
      "n": "showProgress",
      "o": "LCFCT$TelegramWebApps$MainButton$showProgress",
      "d": 3029811,
      "h": 154621852467,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(154621852467),
//--TRIMMABLE-BOUNDARY-START(73017473843),
    {
      "r": 3029811,
      "n": "hideProgress",
      "o": "LCFCT$TelegramWebApps$MainButton$hideProgress",
      "d": 3029811,
      "h": 73017473843,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(73017473843),
//--TRIMMABLE-BOUNDARY-START(141736950579),
    {
      "r": 3029811,
      "p": [
        {
          "n": "params",
          "p": 3095347
        }
      ],
      "n": "setParams",
      "o": "LCFCT$TelegramWebApps$MainButton$setParams",
      "d": 3029811,
      "h": 141736950579,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(141736950579)
  ],
  "d": 1522483,
  "h": 3029811,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+MainButton`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}MainButton`; }
                }, $cls, ($v) => $cls.$_MainButton = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3029811)
            
            //--TRIMMABLE-BOUNDARY-START(3095347)
            static $_MainButton_Type_0;
            static get MainButton_Type_0()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3095347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_MainButton_Type_0 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.MainButton_Type_0`, ($self) => class MainButton_Type_0
                {
                    static $h = 3095347;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103082310451),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247735603,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98787343155,
        "f": 83886337
      },
      "n": "text",
      "o": "LCFCT$TelegramWebApps$MainButton_Type_0$text",
      "d": 3095347,
      "h": 103082310451,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103082310451),
//--TRIMMABLE-BOUNDARY-START(4298062643),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887997235,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427604787,
        "f": 83886337
      },
      "n": "color",
      "o": "LCFCT$TelegramWebApps$MainButton_Type_0$color",
      "d": 3095347,
      "h": 4298062643,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4298062643),
//--TRIMMABLE-BOUNDARY-START(107377277747),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657801011,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90197408563,
        "f": 83886337
      },
      "n": "text_color",
      "o": "LCFCT$TelegramWebApps$MainButton_Type_0$text_color",
      "d": 3095347,
      "h": 107377277747,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(107377277747),
//--TRIMMABLE-BOUNDARY-START(51542702899),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477931827,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017539379,
        "f": 83886337
      },
      "n": "is_active",
      "o": "LCFCT$TelegramWebApps$MainButton_Type_0$is_active",
      "d": 3095347,
      "h": 51542702899,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51542702899),
//--TRIMMABLE-BOUNDARY-START(55837670195),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067866419,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607473971,
        "f": 83886337
      },
      "n": "is_visible",
      "o": "LCFCT$TelegramWebApps$MainButton_Type_0$is_visible",
      "d": 3095347,
      "h": 55837670195,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(55837670195)
  ],
  "d": 1522483,
  "h": 3095347,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+MainButton_Type_0`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}MainButton_Type_0`; }
                }, $cls, ($v) => $cls.$_MainButton_Type_0 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3095347)
            
            //--TRIMMABLE-BOUNDARY-START(3488563)
            static $_SettingsButton;
            static get SettingsButton()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3488563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_SettingsButton ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.SettingsButton`, ($self) => class SettingsButton
                {
                    static $h = 3488563;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183357747),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593423155,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34363226931,
        "f": 83886337
      },
      "n": "isVisible",
      "o": "LCFCT$TelegramWebApps$SettingsButton$isVisible",
      "d": 3488563,
      "h": 17183357747,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17183357747)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25773292339),
    {
      "r": 3488563,
      "p": [
        {
          "n": "callback",
          "p": 43122689
        }
      ],
      "n": "onClick",
      "o": "LCFCT$TelegramWebApps$SettingsButton$onClick",
      "d": 3488563,
      "h": 25773292339,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25773292339),
//--TRIMMABLE-BOUNDARY-START(21478325043),
    {
      "r": 3488563,
      "p": [
        {
          "n": "callback",
          "p": 43122689
        }
      ],
      "n": "offClick",
      "o": "LCFCT$TelegramWebApps$SettingsButton$offClick",
      "d": 3488563,
      "h": 21478325043,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21478325043),
//--TRIMMABLE-BOUNDARY-START(38658194227),
    {
      "r": 3488563,
      "n": "show",
      "o": "LCFCT$TelegramWebApps$SettingsButton$show",
      "d": 3488563,
      "h": 38658194227,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38658194227),
//--TRIMMABLE-BOUNDARY-START(12888390451),
    {
      "r": 3488563,
      "n": "hide",
      "o": "LCFCT$TelegramWebApps$SettingsButton$hide",
      "d": 3488563,
      "h": 12888390451,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12888390451)
  ],
  "d": 1522483,
  "h": 3488563,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+SettingsButton`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}SettingsButton`; }
                }, $cls, ($v) => $cls.$_SettingsButton = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3488563)
            
            //--TRIMMABLE-BOUNDARY-START(2767667)
            static $_HapticFeedback;
            static get HapticFeedback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2767667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_HapticFeedback ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.HapticFeedback`, ($self) => class HapticFeedback
                {
                    static $h = 2767667;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297734963),
    {
      "r": 2767667,
      "p": [
        {
          "n": "style",
          "p": 2833203
        }
      ],
      "n": "impactOccurred",
      "o": "LCFCT$TelegramWebApps$HapticFeedback$impactOccurred",
      "d": 2767667,
      "h": 4297734963,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297734963),
//--TRIMMABLE-BOUNDARY-START(8592702259),
    {
      "r": 2767667,
      "p": [
        {
          "n": "type",
          "p": 2898739
        }
      ],
      "n": "notificationOccurred",
      "o": "LCFCT$TelegramWebApps$HapticFeedback$notificationOccurred",
      "d": 2767667,
      "h": 8592702259,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8592702259),
//--TRIMMABLE-BOUNDARY-START(12887669555),
    {
      "r": 2767667,
      "n": "selectionChanged",
      "o": "LCFCT$TelegramWebApps$HapticFeedback$selectionChanged",
      "d": 2767667,
      "h": 12887669555,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12887669555)
  ],
  "d": 1522483,
  "h": 2767667,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+HapticFeedback`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}HapticFeedback`; }
                }, $cls, ($v) => $cls.$_HapticFeedback = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2767667)
            
            //--TRIMMABLE-BOUNDARY-START(2833203)
            static $_HapticFeedback_Type_0;
            static get HapticFeedback_Type_0()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2833203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_HapticFeedback_Type_0 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.HapticFeedback_Type_0`, ($self) => class HapticFeedback_Type_0 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(17182702387)
                    /*string*/ static light = null;
                    //--TRIMMABLE-BOUNDARY-END(17182702387)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477669683)
                    /*string*/ static medium = null;
                    //--TRIMMABLE-BOUNDARY-END(21477669683)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887735091)
                    /*string*/ static heavy = null;
                    //--TRIMMABLE-BOUNDARY-END(12887735091)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772636979)
                    /*string*/ static rigid = null;
                    //--TRIMMABLE-BOUNDARY-END(25772636979)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067604275)
                    /*string*/ static soft = null;
                    //--TRIMMABLE-BOUNDARY-END(30067604275)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362571571)
                    static /*HapticFeedback_Type_0 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362571571);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.HapticFeedback_Type_0().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362571571)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592767795)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592767795);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592767795)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297800499)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4297800499);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(17182702387)
                            this.light = "light";
                            //--TRIMMABLE-BOUNDARY-END(17182702387)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21477669683)
                            this.medium = "medium";
                            //--TRIMMABLE-BOUNDARY-END(21477669683)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12887735091)
                            this.heavy = "heavy";
                            //--TRIMMABLE-BOUNDARY-END(12887735091)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(25772636979)
                            this.rigid = "rigid";
                            //--TRIMMABLE-BOUNDARY-END(25772636979)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30067604275)
                            this.soft = "soft";
                            //--TRIMMABLE-BOUNDARY-END(30067604275)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297800499)
                    
                    static $h = 2833203;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182702387),
    {
      "t": 1310721,
      "n": "light",
      "d": 2833203,
      "h": 17182702387,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182702387),
//--TRIMMABLE-BOUNDARY-START(21477669683),
    {
      "t": 1310721,
      "n": "medium",
      "d": 2833203,
      "h": 21477669683,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477669683),
//--TRIMMABLE-BOUNDARY-START(12887735091),
    {
      "t": 1310721,
      "n": "heavy",
      "d": 2833203,
      "h": 12887735091,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887735091),
//--TRIMMABLE-BOUNDARY-START(25772636979),
    {
      "t": 1310721,
      "n": "rigid",
      "d": 2833203,
      "h": 25772636979,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772636979),
//--TRIMMABLE-BOUNDARY-START(30067604275),
    {
      "t": 1310721,
      "n": "soft",
      "d": 2833203,
      "h": 30067604275,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067604275)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592767795),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2833203,
      "h": 8592767795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592767795)
  ],
  "d": 1522483,
  "h": 2833203
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+HapticFeedback_Type_0`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}HapticFeedback_Type_0`; }
                }, $cls, ($v) => $cls.$_HapticFeedback_Type_0 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2833203)
            
            //--TRIMMABLE-BOUNDARY-START(2898739)
            static $_HapticFeedback_Type_1;
            static get HapticFeedback_Type_1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2898739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_HapticFeedback_Type_1 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.HapticFeedback_Type_1`, ($self) => class HapticFeedback_Type_1 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(12887800627)
                    /*string*/ static error = null;
                    //--TRIMMABLE-BOUNDARY-END(12887800627)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182767923)
                    /*string*/ static success = null;
                    //--TRIMMABLE-BOUNDARY-END(17182767923)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772702515)
                    /*string*/ static warning = null;
                    //--TRIMMABLE-BOUNDARY-END(25772702515)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477735219)
                    static /*HapticFeedback_Type_1 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477735219);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.HapticFeedback_Type_1().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477735219)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592833331)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592833331);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592833331)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297866035)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4297866035);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(12887800627)
                            this.error = "error";
                            //--TRIMMABLE-BOUNDARY-END(12887800627)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17182767923)
                            this.success = "success";
                            //--TRIMMABLE-BOUNDARY-END(17182767923)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(25772702515)
                            this.warning = "warning";
                            //--TRIMMABLE-BOUNDARY-END(25772702515)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297866035)
                    
                    static $h = 2898739;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887800627),
    {
      "t": 1310721,
      "n": "error",
      "d": 2898739,
      "h": 12887800627,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887800627),
//--TRIMMABLE-BOUNDARY-START(17182767923),
    {
      "t": 1310721,
      "n": "success",
      "d": 2898739,
      "h": 17182767923,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182767923),
//--TRIMMABLE-BOUNDARY-START(25772702515),
    {
      "t": 1310721,
      "n": "warning",
      "d": 2898739,
      "h": 25772702515,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772702515)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592833331),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2898739,
      "h": 8592833331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592833331)
  ],
  "d": 1522483,
  "h": 2898739
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+HapticFeedback_Type_1`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}HapticFeedback_Type_1`; }
                }, $cls, ($v) => $cls.$_HapticFeedback_Type_1 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2898739)
            
            //--TRIMMABLE-BOUNDARY-START(2636595)
            static $_CloudStorage;
            static get CloudStorage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2636595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_CloudStorage ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.CloudStorage`, ($self) => class CloudStorage
                {
                    static $h = 2636595;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772440371),
    {
      "r": 2636595,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "callback",
          "p": $.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$$.S.Boolean)).$h
        }
      ],
      "n": "setItem",
      "o": "LCFCT$TelegramWebApps$CloudStorage$setItem",
      "d": 2636595,
      "h": 25772440371,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25772440371),
//--TRIMMABLE-BOUNDARY-START(4297603891),
    {
      "r": 2636595,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "callback",
          "p": $.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$$.S.String)).$h
        }
      ],
      "n": "getItem",
      "o": "LCFCT$TelegramWebApps$CloudStorage$getItem",
      "d": 2636595,
      "h": 4297603891,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297603891),
//--TRIMMABLE-BOUNDARY-START(8592571187),
    {
      "r": 2636595,
      "p": [
        {
          "n": "keys",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "callback",
          "p": $.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$typeArray($.$$.S.String))).$h
        }
      ],
      "n": "getItems",
      "o": "LCFCT$TelegramWebApps$CloudStorage$getItems",
      "d": 2636595,
      "h": 8592571187,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8592571187),
//--TRIMMABLE-BOUNDARY-START(17182505779),
    {
      "r": 2636595,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "callback",
          "p": $.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$$.S.Boolean)).$h
        }
      ],
      "n": "removeItem",
      "o": "LCFCT$TelegramWebApps$CloudStorage$removeItem",
      "d": 2636595,
      "h": 17182505779,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17182505779),
//--TRIMMABLE-BOUNDARY-START(21477473075),
    {
      "r": 2636595,
      "p": [
        {
          "n": "keys",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "callback",
          "p": $.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$$.S.Boolean)).$h
        }
      ],
      "n": "removeItems",
      "o": "LCFCT$TelegramWebApps$CloudStorage$removeItems",
      "d": 2636595,
      "h": 21477473075,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21477473075),
//--TRIMMABLE-BOUNDARY-START(12887538483),
    {
      "r": 2636595,
      "p": [
        {
          "n": "callback",
          "p": $.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$typeArray($.$$.S.String))).$h
        }
      ],
      "n": "getKeys",
      "o": "LCFCT$TelegramWebApps$CloudStorage$getKeys",
      "d": 2636595,
      "h": 12887538483,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12887538483)
  ],
  "d": 1522483,
  "h": 2636595,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+CloudStorage`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}CloudStorage`; }
                }, $cls, ($v) => $cls.$_CloudStorage = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2636595)
            
            //--TRIMMABLE-BOUNDARY-START(2308915)
            static $_BiometricManager;
            static get BiometricManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2308915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_BiometricManager ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.BiometricManager`, ($self) => class BiometricManager
                {
                    static $h = 2308915;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98786556723),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016752947,
        "f": 50331905
      },
      "n": "isInited",
      "o": "LCFCT$TelegramWebApps$BiometricManager$isInited",
      "d": 2308915,
      "h": 98786556723,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98786556723),
//--TRIMMABLE-BOUNDARY-START(90196622131),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836883763,
        "f": 50331905
      },
      "n": "isBiometricAvailable",
      "o": "LCFCT$TelegramWebApps$BiometricManager$isBiometricAvailable",
      "d": 2308915,
      "h": 90196622131,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90196622131),
//--TRIMMABLE-BOUNDARY-START(8592243507),
    {
      "p": 2374451,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477145395,
        "f": 50331905
      },
      "n": "biometricType",
      "o": "LCFCT$TelegramWebApps$BiometricManager$biometricType",
      "d": 2308915,
      "h": 8592243507,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8592243507),
//--TRIMMABLE-BOUNDARY-START(85901654835),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246949171,
        "f": 50331905
      },
      "n": "isAccessRequested",
      "o": "LCFCT$TelegramWebApps$BiometricManager$isAccessRequested",
      "d": 2308915,
      "h": 85901654835,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(85901654835),
//--TRIMMABLE-BOUNDARY-START(81606687539),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657014579,
        "f": 50331905
      },
      "n": "isAccessGranted",
      "o": "LCFCT$TelegramWebApps$BiometricManager$isAccessGranted",
      "d": 2308915,
      "h": 81606687539,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(81606687539),
//--TRIMMABLE-BOUNDARY-START(94491589427),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426818355,
        "f": 50331905
      },
      "n": "isBiometricTokenSaved",
      "o": "LCFCT$TelegramWebApps$BiometricManager$isBiometricTokenSaved",
      "d": 2308915,
      "h": 94491589427,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94491589427),
//--TRIMMABLE-BOUNDARY-START(12887210803),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067079987,
        "f": 50331905
      },
      "n": "deviceId",
      "o": "LCFCT$TelegramWebApps$BiometricManager$deviceId",
      "d": 2308915,
      "h": 12887210803,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12887210803)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77311720243),
    {
      "r": 2308915,
      "p": [
        {
          "n": "callback",
          "p": 43122689
        }
      ],
      "n": "init",
      "o": "LCFCT$TelegramWebApps$BiometricManager$init",
      "d": 2308915,
      "h": 77311720243,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(77311720243),
//--TRIMMABLE-BOUNDARY-START(107376491315),
    {
      "r": 2308915,
      "p": [
        {
          "n": "params",
          "p": 2439987
        },
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Boolean).$h
        }
      ],
      "n": "requestAccess",
      "o": "LCFCT$TelegramWebApps$BiometricManager$requestAccess",
      "d": 2308915,
      "h": 107376491315,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(107376491315),
//--TRIMMABLE-BOUNDARY-START(4297276211),
    {
      "r": 2308915,
      "p": [
        {
          "n": "params",
          "p": 2177843
        },
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Boolean).$h
        }
      ],
      "n": "authenticate",
      "o": "LCFCT$TelegramWebApps$BiometricManager$authenticate",
      "d": 2308915,
      "h": 4297276211,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297276211),
//--TRIMMABLE-BOUNDARY-START(111671458611),
    {
      "r": 2308915,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Boolean).$h
        }
      ],
      "n": "updateBiometricToken",
      "o": "LCFCT$TelegramWebApps$BiometricManager$updateBiometricToken",
      "d": 2308915,
      "h": 111671458611,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(111671458611),
//--TRIMMABLE-BOUNDARY-START(103081524019),
    {
      "r": 2308915,
      "n": "openSettings",
      "o": "LCFCT$TelegramWebApps$BiometricManager$openSettings",
      "d": 2308915,
      "h": 103081524019,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(103081524019)
  ],
  "d": 1522483,
  "h": 2308915,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+BiometricManager`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}BiometricManager`; }
                }, $cls, ($v) => $cls.$_BiometricManager = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2308915)
            
            //--TRIMMABLE-BOUNDARY-START(2374451)
            static $_BiometricManager_Type_0;
            static get BiometricManager_Type_0()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2374451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_BiometricManager_Type_0 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.BiometricManager_Type_0`, ($self) => class BiometricManager_Type_0 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(17182243635)
                    /*string*/ static finger = null;
                    //--TRIMMABLE-BOUNDARY-END(17182243635)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887276339)
                    /*string*/ static face = null;
                    //--TRIMMABLE-BOUNDARY-END(12887276339)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772178227)
                    /*string*/ static unknown = null;
                    //--TRIMMABLE-BOUNDARY-END(25772178227)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477210931)
                    static /*BiometricManager_Type_0 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477210931);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.BiometricManager_Type_0().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477210931)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592309043)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592309043);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592309043)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297341747)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4297341747);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(17182243635)
                            this.finger = "finger";
                            //--TRIMMABLE-BOUNDARY-END(17182243635)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12887276339)
                            this.face = "face";
                            //--TRIMMABLE-BOUNDARY-END(12887276339)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(25772178227)
                            this.unknown = "unknown";
                            //--TRIMMABLE-BOUNDARY-END(25772178227)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297341747)
                    
                    static $h = 2374451;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182243635),
    {
      "t": 1310721,
      "n": "finger",
      "d": 2374451,
      "h": 17182243635,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182243635),
//--TRIMMABLE-BOUNDARY-START(12887276339),
    {
      "t": 1310721,
      "n": "face",
      "d": 2374451,
      "h": 12887276339,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887276339),
//--TRIMMABLE-BOUNDARY-START(25772178227),
    {
      "t": 1310721,
      "n": "unknown",
      "d": 2374451,
      "h": 25772178227,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772178227)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592309043),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2374451,
      "h": 8592309043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592309043)
  ],
  "d": 1522483,
  "h": 2374451
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+BiometricManager_Type_0`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}BiometricManager_Type_0`; }
                }, $cls, ($v) => $cls.$_BiometricManager_Type_0 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2374451)
            
            //--TRIMMABLE-BOUNDARY-START(2439987)
            static $_BiometricRequestAccessParams;
            static get BiometricRequestAccessParams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2439987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_BiometricRequestAccessParams ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.BiometricRequestAccessParams`, ($self) => class BiometricRequestAccessParams
                {
                    static $h = 2439987;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887341875),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592374579,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21477276467,
        "f": 83886337
      },
      "n": "reason",
      "o": "LCFCT$TelegramWebApps$BiometricRequestAccessParams$reason",
      "d": 2439987,
      "h": 12887341875,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12887341875)
  ],
  "d": 1522483,
  "h": 2439987,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+BiometricRequestAccessParams`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}BiometricRequestAccessParams`; }
                }, $cls, ($v) => $cls.$_BiometricRequestAccessParams = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2439987)
            
            //--TRIMMABLE-BOUNDARY-START(2177843)
            static $_BiometricAuthenticateParams;
            static get BiometricAuthenticateParams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2177843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_BiometricAuthenticateParams ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.BiometricAuthenticateParams`, ($self) => class BiometricAuthenticateParams
                {
                    static $h = 2177843;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887079731),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592112435,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21477014323,
        "f": 83886337
      },
      "n": "reason",
      "o": "LCFCT$TelegramWebApps$BiometricAuthenticateParams$reason",
      "d": 2177843,
      "h": 12887079731,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12887079731)
  ],
  "d": 1522483,
  "h": 2177843,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+BiometricAuthenticateParams`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}BiometricAuthenticateParams`; }
                }, $cls, ($v) => $cls.$_BiometricAuthenticateParams = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2177843)
            
            //--TRIMMABLE-BOUNDARY-START(6503219)
            static $_WebAppInitData;
            static get WebAppInitData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6503219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebAppInitData ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebAppInitData`, ($self) => class WebAppInitData
                {
                    static $h = 6503219;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115970620211),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81610881843,
        "f": 50331905
      },
      "n": "query_id",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$query_id",
      "d": 6503219,
      "h": 115970620211,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(115970620211),
//--TRIMMABLE-BOUNDARY-START(128855522099),
    {
      "p": 6699827,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107380685619,
        "f": 50331905
      },
      "n": "user",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$user",
      "d": 6503219,
      "h": 128855522099,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(128855522099),
//--TRIMMABLE-BOUNDARY-START(120265587507),
    {
      "p": 6699827,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90200816435,
        "f": 50331905
      },
      "n": "receiver",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$receiver",
      "d": 6503219,
      "h": 120265587507,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(120265587507),
//--TRIMMABLE-BOUNDARY-START(12891405107),
    {
      "p": 6372147,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64431012659,
        "f": 50331905
      },
      "n": "chat",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$chat",
      "d": 6503219,
      "h": 12891405107,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12891405107),
//--TRIMMABLE-BOUNDARY-START(21481339699),
    {
      "p": 6568755,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55841078067,
        "f": 50331905
      },
      "n": "chat_type",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$chat_type",
      "d": 6503219,
      "h": 21481339699,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21481339699),
//--TRIMMABLE-BOUNDARY-START(17186372403),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47251143475,
        "f": 50331905
      },
      "n": "chat_instance",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$chat_instance",
      "d": 6503219,
      "h": 17186372403,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17186372403),
//--TRIMMABLE-BOUNDARY-START(124560554803),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98790751027,
        "f": 50331905
      },
      "n": "start_param",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$start_param",
      "d": 6503219,
      "h": 124560554803,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(124560554803),
//--TRIMMABLE-BOUNDARY-START(8596437811),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38661208883,
        "f": 50331905
      },
      "n": "can_send_after",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$can_send_after",
      "d": 6503219,
      "h": 8596437811,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8596437811),
//--TRIMMABLE-BOUNDARY-START(4301470515),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30071274291,
        "f": 50331905
      },
      "n": "auth_date",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$auth_date",
      "d": 6503219,
      "h": 4301470515,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4301470515),
//--TRIMMABLE-BOUNDARY-START(111675652915),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73020947251,
        "f": 50331905
      },
      "n": "hash",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$hash",
      "d": 6503219,
      "h": 111675652915,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(111675652915)
  ],
  "d": 1522483,
  "h": 6503219,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebAppInitData`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebAppInitData`; }
                }, $cls, ($v) => $cls.$_WebAppInitData = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6503219)
            
            //--TRIMMABLE-BOUNDARY-START(6568755)
            static $_WebAppInitData_Type_0;
            static get WebAppInitData_Type_0()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6568755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebAppInitData_Type_0 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebAppInitData_Type_0`, ($self) => class WebAppInitData_Type_0 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(25776372531)
                    /*string*/ static sender = null;
                    //--TRIMMABLE-BOUNDARY-END(25776372531)
                    
                    //--TRIMMABLE-BOUNDARY-START(21481405235)
                    /*string*/ static $private = null;
                    //--TRIMMABLE-BOUNDARY-END(21481405235)
                    
                    //--TRIMMABLE-BOUNDARY-START(17186437939)
                    /*string*/ static group = null;
                    //--TRIMMABLE-BOUNDARY-END(17186437939)
                    
                    //--TRIMMABLE-BOUNDARY-START(30071339827)
                    /*string*/ static supergroup = null;
                    //--TRIMMABLE-BOUNDARY-END(30071339827)
                    
                    //--TRIMMABLE-BOUNDARY-START(12891470643)
                    /*string*/ static channel = null;
                    //--TRIMMABLE-BOUNDARY-END(12891470643)
                    
                    //--TRIMMABLE-BOUNDARY-START(34366307123)
                    static /*WebAppInitData_Type_0 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34366307123);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebAppInitData_Type_0().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34366307123)
                    
                    //--TRIMMABLE-BOUNDARY-START(8596503347)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8596503347);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8596503347)
                    
                    //--TRIMMABLE-BOUNDARY-START(4301536051)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4301536051);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(25776372531)
                            this.sender = "sender";
                            //--TRIMMABLE-BOUNDARY-END(25776372531)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21481405235)
                            this.$private = "private";
                            //--TRIMMABLE-BOUNDARY-END(21481405235)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17186437939)
                            this.group = "group";
                            //--TRIMMABLE-BOUNDARY-END(17186437939)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30071339827)
                            this.supergroup = "supergroup";
                            //--TRIMMABLE-BOUNDARY-END(30071339827)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12891470643)
                            this.channel = "channel";
                            //--TRIMMABLE-BOUNDARY-END(12891470643)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4301536051)
                    
                    static $h = 6568755;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(25776372531),
    {
      "t": 1310721,
      "n": "sender",
      "d": 6568755,
      "h": 25776372531,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25776372531),
//--TRIMMABLE-BOUNDARY-START(21481405235),
    {
      "t": 1310721,
      "n": "private",
      "o": "$private",
      "d": 6568755,
      "h": 21481405235,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21481405235),
//--TRIMMABLE-BOUNDARY-START(17186437939),
    {
      "t": 1310721,
      "n": "group",
      "d": 6568755,
      "h": 17186437939,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17186437939),
//--TRIMMABLE-BOUNDARY-START(30071339827),
    {
      "t": 1310721,
      "n": "supergroup",
      "d": 6568755,
      "h": 30071339827,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30071339827),
//--TRIMMABLE-BOUNDARY-START(12891470643),
    {
      "t": 1310721,
      "n": "channel",
      "d": 6568755,
      "h": 12891470643,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12891470643)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8596503347),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 6568755,
      "h": 8596503347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8596503347)
  ],
  "d": 1522483,
  "h": 6568755
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebAppInitData_Type_0`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebAppInitData_Type_0`; }
                }, $cls, ($v) => $cls.$_WebAppInitData_Type_0 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6568755)
            
            //--TRIMMABLE-BOUNDARY-START(6699827)
            static $_WebAppUser;
            static get WebAppUser()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6699827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebAppUser ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebAppUser`, ($self) => class WebAppUser
                {
                    static $h = 6699827;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103085914931),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47251340083,
        "f": 50331905
      },
      "n": "id",
      "o": "LCFCT$TelegramWebApps$WebAppUser$id",
      "d": 6699827,
      "h": 103085914931,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103085914931),
//--TRIMMABLE-BOUNDARY-START(107380882227),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55841274675,
        "f": 50331905
      },
      "n": "is_bot",
      "o": "LCFCT$TelegramWebApps$WebAppUser$is_bot",
      "d": 6699827,
      "h": 107380882227,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(107380882227),
//--TRIMMABLE-BOUNDARY-START(12891601715),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38661405491,
        "f": 50331905
      },
      "n": "first_name",
      "o": "LCFCT$TelegramWebApps$WebAppUser$first_name",
      "d": 6699827,
      "h": 12891601715,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12891601715),
//--TRIMMABLE-BOUNDARY-START(120265784115),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81611078451,
        "f": 50331905
      },
      "n": "last_name",
      "o": "LCFCT$TelegramWebApps$WebAppUser$last_name",
      "d": 6699827,
      "h": 120265784115,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(120265784115),
//--TRIMMABLE-BOUNDARY-START(128855718707),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98790947635,
        "f": 50331905
      },
      "n": "username",
      "o": "LCFCT$TelegramWebApps$WebAppUser$username",
      "d": 6699827,
      "h": 128855718707,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(128855718707),
//--TRIMMABLE-BOUNDARY-START(115970816819),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73021143859,
        "f": 50331905
      },
      "n": "language_code",
      "o": "LCFCT$TelegramWebApps$WebAppUser$language_code",
      "d": 6699827,
      "h": 115970816819,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(115970816819),
//--TRIMMABLE-BOUNDARY-START(111675849523),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64431209267,
        "f": 50331905
      },
      "n": "is_premium",
      "o": "LCFCT$TelegramWebApps$WebAppUser$is_premium",
      "d": 6699827,
      "h": 111675849523,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(111675849523),
//--TRIMMABLE-BOUNDARY-START(4301667123),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21481536307,
        "f": 50331905
      },
      "n": "added_to_attachment_menu",
      "o": "LCFCT$TelegramWebApps$WebAppUser$added_to_attachment_menu",
      "d": 6699827,
      "h": 4301667123,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4301667123),
//--TRIMMABLE-BOUNDARY-START(8596634419),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30071470899,
        "f": 50331905
      },
      "n": "allows_write_to_pm",
      "o": "LCFCT$TelegramWebApps$WebAppUser$allows_write_to_pm",
      "d": 6699827,
      "h": 8596634419,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8596634419),
//--TRIMMABLE-BOUNDARY-START(124560751411),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90201013043,
        "f": 50331905
      },
      "n": "photo_url",
      "o": "LCFCT$TelegramWebApps$WebAppUser$photo_url",
      "d": 6699827,
      "h": 124560751411,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(124560751411)
  ],
  "d": 1522483,
  "h": 6699827,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebAppUser`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebAppUser`; }
                }, $cls, ($v) => $cls.$_WebAppUser = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6699827)
            
            //--TRIMMABLE-BOUNDARY-START(6372147)
            static $_WebAppChat;
            static get WebAppChat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6372147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebAppChat ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebAppChat`, ($self) => class WebAppChat
                {
                    static $h = 6372147;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47251012403),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8596306739,
        "f": 50331905
      },
      "n": "id",
      "o": "LCFCT$TelegramWebApps$WebAppChat$id",
      "d": 6372147,
      "h": 47251012403,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47251012403),
//--TRIMMABLE-BOUNDARY-START(60135914291),
    {
      "p": 6437683,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34366110515,
        "f": 50331905
      },
      "n": "type",
      "o": "LCFCT$TelegramWebApps$WebAppChat$type",
      "d": 6372147,
      "h": 60135914291,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60135914291),
//--TRIMMABLE-BOUNDARY-START(55840946995),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25776175923,
        "f": 50331905
      },
      "n": "title",
      "o": "LCFCT$TelegramWebApps$WebAppChat$title",
      "d": 6372147,
      "h": 55840946995,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(55840946995),
//--TRIMMABLE-BOUNDARY-START(64430881587),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42956045107,
        "f": 50331905
      },
      "n": "username",
      "o": "LCFCT$TelegramWebApps$WebAppChat$username",
      "d": 6372147,
      "h": 64430881587,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64430881587),
//--TRIMMABLE-BOUNDARY-START(51545979699),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17186241331,
        "f": 50331905
      },
      "n": "photo_url",
      "o": "LCFCT$TelegramWebApps$WebAppChat$photo_url",
      "d": 6372147,
      "h": 51545979699,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51545979699)
  ],
  "d": 1522483,
  "h": 6372147,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebAppChat`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebAppChat`; }
                }, $cls, ($v) => $cls.$_WebAppChat = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6372147)
            
            //--TRIMMABLE-BOUNDARY-START(6437683)
            static $_WebAppChat_Type_0;
            static get WebAppChat_Type_0()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(6437683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_WebAppChat_Type_0 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.WebAppChat_Type_0`, ($self) => class WebAppChat_Type_0 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(17186306867)
                    /*string*/ static group = null;
                    //--TRIMMABLE-BOUNDARY-END(17186306867)
                    
                    //--TRIMMABLE-BOUNDARY-START(21481274163)
                    /*string*/ static supergroup = null;
                    //--TRIMMABLE-BOUNDARY-END(21481274163)
                    
                    //--TRIMMABLE-BOUNDARY-START(12891339571)
                    /*string*/ static channel = null;
                    //--TRIMMABLE-BOUNDARY-END(12891339571)
                    
                    //--TRIMMABLE-BOUNDARY-START(25776241459)
                    static /*WebAppChat_Type_0 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25776241459);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.WebAppChat_Type_0().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25776241459)
                    
                    //--TRIMMABLE-BOUNDARY-START(8596372275)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8596372275);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8596372275)
                    
                    //--TRIMMABLE-BOUNDARY-START(4301404979)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4301404979);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(17186306867)
                            this.group = "group";
                            //--TRIMMABLE-BOUNDARY-END(17186306867)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21481274163)
                            this.supergroup = "supergroup";
                            //--TRIMMABLE-BOUNDARY-END(21481274163)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12891339571)
                            this.channel = "channel";
                            //--TRIMMABLE-BOUNDARY-END(12891339571)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4301404979)
                    
                    static $h = 6437683;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17186306867),
    {
      "t": 1310721,
      "n": "group",
      "d": 6437683,
      "h": 17186306867,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17186306867),
//--TRIMMABLE-BOUNDARY-START(21481274163),
    {
      "t": 1310721,
      "n": "supergroup",
      "d": 6437683,
      "h": 21481274163,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21481274163),
//--TRIMMABLE-BOUNDARY-START(12891339571),
    {
      "t": 1310721,
      "n": "channel",
      "d": 6437683,
      "h": 12891339571,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12891339571)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8596372275),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 6437683,
      "h": 8596372275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8596372275)
  ],
  "d": 1522483,
  "h": 6437683
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+WebAppChat_Type_0`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}WebAppChat_Type_0`; }
                }, $cls, ($v) => $cls.$_WebAppChat_Type_0 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(6437683)
            
            //--TRIMMABLE-BOUNDARY-START(2702131)
            static $_ColorScheme;
            static get ColorScheme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2702131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_ColorScheme ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.ColorScheme`, ($self) => class ColorScheme extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(17182571315)
                    /*string*/ static light = null;
                    //--TRIMMABLE-BOUNDARY-END(17182571315)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887604019)
                    /*string*/ static dark = null;
                    //--TRIMMABLE-BOUNDARY-END(12887604019)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477538611)
                    static /*ColorScheme */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477538611);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.ColorScheme().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477538611)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592636723)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592636723);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592636723)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297669427)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4297669427);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(17182571315)
                            this.light = "light";
                            //--TRIMMABLE-BOUNDARY-END(17182571315)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12887604019)
                            this.dark = "dark";
                            //--TRIMMABLE-BOUNDARY-END(12887604019)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297669427)
                    
                    static $h = 2702131;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182571315),
    {
      "t": 1310721,
      "n": "light",
      "d": 2702131,
      "h": 17182571315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182571315),
//--TRIMMABLE-BOUNDARY-START(12887604019),
    {
      "t": 1310721,
      "n": "dark",
      "d": 2702131,
      "h": 12887604019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887604019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592636723),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2702131,
      "h": 8592636723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592636723)
  ],
  "d": 1522483,
  "h": 2702131
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+ColorScheme`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}ColorScheme`; }
                }, $cls, ($v) => $cls.$_ColorScheme = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2702131)
            
            //--TRIMMABLE-BOUNDARY-START(3685171)
            static $_TelegramWebApps_Type_1;
            static get TelegramWebApps_Type_1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3685171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_TelegramWebApps_Type_1 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_1`, ($self) => class TelegramWebApps_Type_1
                {
                    static $h = 3685171;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478521651),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593619763,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 17183554355,
        "f": 83886337
      },
      "n": "viewportHeight",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_1$viewportHeight",
      "d": 3685171,
      "h": 21478521651,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21478521651)
  ],
  "d": 1522483,
  "h": 3685171,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+TelegramWebApps_Type_1`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}TelegramWebApps_Type_1`; }
                }, $cls, ($v) => $cls.$_TelegramWebApps_Type_1 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3685171)
            
            //--TRIMMABLE-BOUNDARY-START(3750707)
            static $_TelegramWebApps_Type_2;
            static get TelegramWebApps_Type_2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3750707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_TelegramWebApps_Type_2 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_2`, ($self) => class TelegramWebApps_Type_2
                {
                    static $h = 3750707;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12888652595),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593685299,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21478587187,
        "f": 83886337
      },
      "n": "isStateStable",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_2$isStateStable",
      "d": 3750707,
      "h": 12888652595,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12888652595)
  ],
  "d": 1522483,
  "h": 3750707,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+TelegramWebApps_Type_2`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}TelegramWebApps_Type_2`; }
                }, $cls, ($v) => $cls.$_TelegramWebApps_Type_2 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3750707)
            
            //--TRIMMABLE-BOUNDARY-START(4537139)
            static $_ViewportChangedEventHandler;
            static get ViewportChangedEventHandler()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4537139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_ViewportChangedEventHandler ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.ViewportChangedEventHandler`, ($self) => class ViewportChangedEventHandler extends $.$TLYN.LTDU.TypeAlias
                {
                    //--TRIMMABLE-BOUNDARY-START(4299504435)
                    $ctor$2(/*Action<TelegramWebApps_Type_1, TelegramWebApps_Type_2>*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4299504435);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4299504435)
                    
                    //--TRIMMABLE-BOUNDARY-START(8594471731)
                    static /*ViewportChangedEventHandler */ op_Implicit(/*Action<TelegramWebApps_Type_1, TelegramWebApps_Type_2>*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8594471731);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.ViewportChangedEventHandler().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8594471731)
                    
                    static $h = 4537139;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.TypeAlias; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299504435),
    {
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Action$$$($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_1, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_2).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4537139,
      "h": 4299504435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299504435)
  ],
  "d": 1522483,
  "h": 4537139
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+ViewportChangedEventHandler`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}ViewportChangedEventHandler`; }
                }, $cls, ($v) => $cls.$_ViewportChangedEventHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4537139)
            
            //--TRIMMABLE-BOUNDARY-START(3816243)
            static $_TelegramWebApps_Type_3;
            static get TelegramWebApps_Type_3()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3816243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_TelegramWebApps_Type_3 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3`, ($self) => class TelegramWebApps_Type_3
                {
                    static $h = 3816243;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42953489203),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183685427,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34363554611,
        "f": 83886337
      },
      "n": "url",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_3$url",
      "d": 3816243,
      "h": 42953489203,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42953489203),
//--TRIMMABLE-BOUNDARY-START(38658521907),
    {
      "p": 3881779,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8593750835,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25773620019,
        "f": 83886337
      },
      "n": "status",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_3$status",
      "d": 3816243,
      "h": 38658521907,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38658521907)
  ],
  "d": 1522483,
  "h": 3816243,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+TelegramWebApps_Type_3`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}TelegramWebApps_Type_3`; }
                }, $cls, ($v) => $cls.$_TelegramWebApps_Type_3 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3816243)
            
            //--TRIMMABLE-BOUNDARY-START(3881779)
            static $_TelegramWebApps_Type_3_Type_0;
            static get TelegramWebApps_Type_3_Type_0()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3881779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_TelegramWebApps_Type_3_Type_0 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3_Type_0`, ($self) => class TelegramWebApps_Type_3_Type_0 extends $.$TLYN.LTDU.Enumerated
                {
                    //--TRIMMABLE-BOUNDARY-START(21478718259)
                    /*string*/ static paid = null;
                    //--TRIMMABLE-BOUNDARY-END(21478718259)
                    
                    //--TRIMMABLE-BOUNDARY-START(12888783667)
                    /*string*/ static cancelled = null;
                    //--TRIMMABLE-BOUNDARY-END(12888783667)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183750963)
                    /*string*/ static failed = null;
                    //--TRIMMABLE-BOUNDARY-END(17183750963)
                    
                    //--TRIMMABLE-BOUNDARY-START(25773685555)
                    /*string*/ static pending = null;
                    //--TRIMMABLE-BOUNDARY-END(25773685555)
                    
                    //--TRIMMABLE-BOUNDARY-START(30068652851)
                    static /*TelegramWebApps_Type_3_Type_0 */ op_Implicit(/*string*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30068652851);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3_Type_0().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30068652851)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593816371)
                    $ctor$2(/*object*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8593816371);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8593816371)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298849075)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4298849075);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(21478718259)
                            this.paid = "paid";
                            //--TRIMMABLE-BOUNDARY-END(21478718259)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12888783667)
                            this.cancelled = "cancelled";
                            //--TRIMMABLE-BOUNDARY-END(12888783667)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17183750963)
                            this.failed = "failed";
                            //--TRIMMABLE-BOUNDARY-END(17183750963)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(25773685555)
                            this.pending = "pending";
                            //--TRIMMABLE-BOUNDARY-END(25773685555)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298849075)
                    
                    static $h = 3881779;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(21478718259),
    {
      "t": 1310721,
      "n": "paid",
      "d": 3881779,
      "h": 21478718259,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478718259),
//--TRIMMABLE-BOUNDARY-START(12888783667),
    {
      "t": 1310721,
      "n": "cancelled",
      "d": 3881779,
      "h": 12888783667,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888783667),
//--TRIMMABLE-BOUNDARY-START(17183750963),
    {
      "t": 1310721,
      "n": "failed",
      "d": 3881779,
      "h": 17183750963,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183750963),
//--TRIMMABLE-BOUNDARY-START(25773685555),
    {
      "t": 1310721,
      "n": "pending",
      "d": 3881779,
      "h": 25773685555,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773685555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593816371),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3881779,
      "h": 8593816371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593816371)
  ],
  "d": 1522483,
  "h": 3881779
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+TelegramWebApps_Type_3_Type_0`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}TelegramWebApps_Type_3_Type_0`; }
                }, $cls, ($v) => $cls.$_TelegramWebApps_Type_3_Type_0 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3881779)
            
            //--TRIMMABLE-BOUNDARY-START(2964275)
            static $_InvoiceClosedEventHandler;
            static get InvoiceClosedEventHandler()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2964275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_InvoiceClosedEventHandler ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.InvoiceClosedEventHandler`, ($self) => class InvoiceClosedEventHandler extends $.$TLYN.LTDU.TypeAlias
                {
                    //--TRIMMABLE-BOUNDARY-START(4297931571)
                    $ctor$2(/*Action<TelegramWebApps_Type_3>*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297931571);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297931571)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592898867)
                    static /*InvoiceClosedEventHandler */ op_Implicit(/*Action<TelegramWebApps_Type_3>*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8592898867);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.InvoiceClosedEventHandler().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592898867)
                    
                    static $h = 2964275;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.TypeAlias; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297931571),
    {
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2964275,
      "h": 4297931571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297931571)
  ],
  "d": 1522483,
  "h": 2964275
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+InvoiceClosedEventHandler`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}InvoiceClosedEventHandler`; }
                }, $cls, ($v) => $cls.$_InvoiceClosedEventHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2964275)
            
            //--TRIMMABLE-BOUNDARY-START(3947315)
            static $_TelegramWebApps_Type_4;
            static get TelegramWebApps_Type_4()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3947315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_TelegramWebApps_Type_4 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_4`, ($self) => class TelegramWebApps_Type_4
                {
                    static $h = 3947315;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4298914611),
    {
      "p": $.$TLYN.LTDU.Union$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888849203,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21478783795,
        "f": 83886337
      },
      "n": "button_id",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_4$button_id",
      "d": 3947315,
      "h": 4298914611,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4298914611)
  ],
  "d": 1522483,
  "h": 3947315,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+TelegramWebApps_Type_4`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}TelegramWebApps_Type_4`; }
                }, $cls, ($v) => $cls.$_TelegramWebApps_Type_4 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3947315)
            
            //--TRIMMABLE-BOUNDARY-START(3226419)
            static $_PopupClosedEventHandler;
            static get PopupClosedEventHandler()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3226419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_PopupClosedEventHandler ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.PopupClosedEventHandler`, ($self) => class PopupClosedEventHandler extends $.$TLYN.LTDU.TypeAlias
                {
                    //--TRIMMABLE-BOUNDARY-START(4298193715)
                    $ctor$2(/*Action<TelegramWebApps_Type_4>*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298193715);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298193715)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593161011)
                    static /*PopupClosedEventHandler */ op_Implicit(/*Action<TelegramWebApps_Type_4>*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8593161011);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.PopupClosedEventHandler().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8593161011)
                    
                    static $h = 3226419;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.TypeAlias; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298193715),
    {
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_4).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3226419,
      "h": 4298193715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298193715)
  ],
  "d": 1522483,
  "h": 3226419
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+PopupClosedEventHandler`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}PopupClosedEventHandler`; }
                }, $cls, ($v) => $cls.$_PopupClosedEventHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3226419)
            
            //--TRIMMABLE-BOUNDARY-START(4012851)
            static $_TelegramWebApps_Type_5;
            static get TelegramWebApps_Type_5()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4012851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_TelegramWebApps_Type_5 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_5`, ($self) => class TelegramWebApps_Type_5
                {
                    static $h = 4012851;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4298980147),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888914739,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21478849331,
        "f": 83886337
      },
      "n": "data",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_5$data",
      "d": 4012851,
      "h": 4298980147,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4298980147)
  ],
  "d": 1522483,
  "h": 4012851,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+TelegramWebApps_Type_5`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}TelegramWebApps_Type_5`; }
                }, $cls, ($v) => $cls.$_TelegramWebApps_Type_5 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4012851)
            
            //--TRIMMABLE-BOUNDARY-START(3357491)
            static $_QrTextReceivedEventHandler;
            static get QrTextReceivedEventHandler()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3357491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_QrTextReceivedEventHandler ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.QrTextReceivedEventHandler`, ($self) => class QrTextReceivedEventHandler extends $.$TLYN.LTDU.TypeAlias
                {
                    //--TRIMMABLE-BOUNDARY-START(4298324787)
                    $ctor$2(/*Action<TelegramWebApps_Type_5>*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4298324787);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298324787)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593292083)
                    static /*QrTextReceivedEventHandler */ op_Implicit(/*Action<TelegramWebApps_Type_5>*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8593292083);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.QrTextReceivedEventHandler().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8593292083)
                    
                    static $h = 3357491;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.TypeAlias; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298324787),
    {
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_5).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3357491,
      "h": 4298324787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298324787)
  ],
  "d": 1522483,
  "h": 3357491
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+QrTextReceivedEventHandler`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}QrTextReceivedEventHandler`; }
                }, $cls, ($v) => $cls.$_QrTextReceivedEventHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3357491)
            
            //--TRIMMABLE-BOUNDARY-START(4078387)
            static $_TelegramWebApps_Type_6;
            static get TelegramWebApps_Type_6()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4078387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_TelegramWebApps_Type_6 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_6`, ($self) => class TelegramWebApps_Type_6
                {
                    static $h = 4078387;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4299045683),
    {
      "p": $.$TLYN.LTDU.Union$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888980275,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21478914867,
        "f": 83886337
      },
      "n": "data",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_6$data",
      "d": 4078387,
      "h": 4299045683,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4299045683)
  ],
  "d": 1522483,
  "h": 4078387,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+TelegramWebApps_Type_6`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}TelegramWebApps_Type_6`; }
                }, $cls, ($v) => $cls.$_TelegramWebApps_Type_6 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4078387)
            
            //--TRIMMABLE-BOUNDARY-START(2571059)
            static $_ClipboardTextReceivedEventHandler;
            static get ClipboardTextReceivedEventHandler()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2571059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_ClipboardTextReceivedEventHandler ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.ClipboardTextReceivedEventHandler`, ($self) => class ClipboardTextReceivedEventHandler extends $.$TLYN.LTDU.TypeAlias
                {
                    //--TRIMMABLE-BOUNDARY-START(4297538355)
                    $ctor$2(/*Action<TelegramWebApps_Type_6>*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297538355);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297538355)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592505651)
                    static /*ClipboardTextReceivedEventHandler */ op_Implicit(/*Action<TelegramWebApps_Type_6>*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8592505651);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.ClipboardTextReceivedEventHandler().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592505651)
                    
                    static $h = 2571059;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.TypeAlias; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297538355),
    {
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_6).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2571059,
      "h": 4297538355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297538355)
  ],
  "d": 1522483,
  "h": 2571059
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+ClipboardTextReceivedEventHandler`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}ClipboardTextReceivedEventHandler`; }
                }, $cls, ($v) => $cls.$_ClipboardTextReceivedEventHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2571059)
            
            //--TRIMMABLE-BOUNDARY-START(4143923)
            static $_TelegramWebApps_Type_7;
            static get TelegramWebApps_Type_7()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4143923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_TelegramWebApps_Type_7 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7`, ($self) => class TelegramWebApps_Type_7
                {
                    static $h = 4143923;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25773947699),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478980403,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42953816883,
        "f": 83886337
      },
      "n": "isAuthenticated",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_7$isAuthenticated",
      "d": 4143923,
      "h": 25773947699,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25773947699),
//--TRIMMABLE-BOUNDARY-START(4299111219),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12889045811,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34363882291,
        "f": 83886337
      },
      "n": "biometricToken",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_7$biometricToken",
      "d": 4143923,
      "h": 4299111219,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4299111219)
  ],
  "d": 1522483,
  "h": 4143923,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+TelegramWebApps_Type_7`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}TelegramWebApps_Type_7`; }
                }, $cls, ($v) => $cls.$_TelegramWebApps_Type_7 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4143923)
            
            //--TRIMMABLE-BOUNDARY-START(4209459)
            static $_TelegramWebApps_Type_8;
            static get TelegramWebApps_Type_8()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4209459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_TelegramWebApps_Type_8 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_8`, ($self) => class TelegramWebApps_Type_8
                {
                    static $h = 4209459;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12889111347),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8594144051,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21479045939,
        "f": 83886337
      },
      "n": "isAuthenticated",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_8$isAuthenticated",
      "d": 4209459,
      "h": 12889111347,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12889111347)
  ],
  "d": 1522483,
  "h": 4209459,
  "a": [
    {
      "t": $.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h,
      "c": Number(BigInt($.$zHIt.LCFCM.MockAttribute$$($.$TLYN.LT.TypeScriptMockBase).$h)|0x100000000n)
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+TelegramWebApps_Type_8`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}TelegramWebApps_Type_8`; }
                }, $cls, ($v) => $cls.$_TelegramWebApps_Type_8 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4209459)
            
            //--TRIMMABLE-BOUNDARY-START(2243379)
            static $_BiometricAuthRequestedEventHandler;
            static get BiometricAuthRequestedEventHandler()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2243379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_BiometricAuthRequestedEventHandler ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.BiometricAuthRequestedEventHandler`, ($self) => class BiometricAuthRequestedEventHandler extends $.$TLYN.LTDU.TypeAlias
                {
                    //--TRIMMABLE-BOUNDARY-START(4297210675)
                    $ctor$2(/*Action<Union<TelegramWebApps_Type_7, TelegramWebApps_Type_8>>*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297210675);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297210675)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592177971)
                    static /*BiometricAuthRequestedEventHandler */ op_Implicit(/*Action<Union<TelegramWebApps_Type_7, TelegramWebApps_Type_8>>*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8592177971);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.BiometricAuthRequestedEventHandler().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592177971)
                    
                    static $h = 2243379;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.TypeAlias; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297210675),
    {
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Action$$($.$TLYN.LTDU.Union$$$($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_8)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2243379,
      "h": 4297210675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297210675)
  ],
  "d": 1522483,
  "h": 2243379
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+BiometricAuthRequestedEventHandler`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}BiometricAuthRequestedEventHandler`; }
                }, $cls, ($v) => $cls.$_BiometricAuthRequestedEventHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2243379)
            
            //--TRIMMABLE-BOUNDARY-START(4274995)
            static $_TelegramWebApps_Type_9;
            static get TelegramWebApps_Type_9()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4274995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_TelegramWebApps_Type_9 ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_9`, ($self) => class TelegramWebApps_Type_9
                {
                    static $h = 4274995;
                    static $f = 0b10000000000100101;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12889176883),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8594209587,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21479111475,
        "f": 83886337
      },
      "n": "isUpdated",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_9$isUpdated",
      "d": 4274995,
      "h": 12889176883,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12889176883)
  ],
  "d": 1522483,
  "h": 4274995
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+TelegramWebApps_Type_9`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}TelegramWebApps_Type_9`; }
                }, $cls, ($v) => $cls.$_TelegramWebApps_Type_9 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(4274995)
            
            //--TRIMMABLE-BOUNDARY-START(2505523)
            static $_BiometricTokenUpdatedEventHandler;
            static get BiometricTokenUpdatedEventHandler()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2505523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fycR.LCFCT.TelegramWebApps;
                return $cls.$_BiometricTokenUpdatedEventHandler ??= $asm.$ncls(`$fycR.LCFCT.TelegramWebApps.BiometricTokenUpdatedEventHandler`, ($self) => class BiometricTokenUpdatedEventHandler extends $.$TLYN.LTDU.TypeAlias
                {
                    //--TRIMMABLE-BOUNDARY-START(4297472819)
                    $ctor$2(/*Action<TelegramWebApps_Type_9>*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297472819);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297472819)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592440115)
                    static /*BiometricTokenUpdatedEventHandler */ op_Implicit(/*Action<TelegramWebApps_Type_9>*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8592440115);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$fycR.LCFCT.TelegramWebApps.BiometricTokenUpdatedEventHandler().$ctor$2(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592440115)
                    
                    static $h = 2505523;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$TLYN.LTDU.TypeAlias; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297472819),
    {
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_9).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2505523,
      "h": 4297472819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297472819)
  ],
  "d": 1522483,
  "h": 2505523
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps+BiometricTokenUpdatedEventHandler`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps${separator}BiometricTokenUpdatedEventHandler`; }
                }, $cls, ($v) => $cls.$_BiometricTokenUpdatedEventHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2505523)
            
            //--TRIMMABLE-BOUNDARY-START(4296489779)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296489779);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296489779)
            
            //--TRIMMABLE-BOUNDARY-START(4296489779)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296489779)
            
            static $h = 1522483;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296489779),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1522483,
      "h": 4296489779,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296489779)
  ],
  "h": 1522483
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.WebAppPlatform, $.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventType, $.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg, $.$fycR.LCFCT.TelegramWebApps.ViewportChangedEventType, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_4, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_5, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_6, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_7, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_8, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_9, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_10, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_11, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_12, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_13, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_14, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_15, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_16, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_17, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_18, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_19, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_20, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_21, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_22, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_23, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_24, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_25, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_26, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_27, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_28, $.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$fycR.LCFCT.TelegramWebApps.StoryShareParams, $.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink, $.$fycR.LCFCT.TelegramWebApps.PopupParams, $.$fycR.LCFCT.TelegramWebApps.ScanQrPopupParams, $.$fycR.LCFCT.TelegramWebApps.PopupButton, $.$fycR.LCFCT.TelegramWebApps.BackButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$fycR.LCFCT.TelegramWebApps.HapticFeedback, $.$fycR.LCFCT.TelegramWebApps.HapticFeedback_Type_0, $.$fycR.LCFCT.TelegramWebApps.HapticFeedback_Type_1, $.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$fycR.LCFCT.TelegramWebApps.BiometricManager_Type_0, $.$fycR.LCFCT.TelegramWebApps.BiometricRequestAccessParams, $.$fycR.LCFCT.TelegramWebApps.BiometricAuthenticateParams, $.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$fycR.LCFCT.TelegramWebApps.WebAppInitData_Type_0, $.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$fycR.LCFCT.TelegramWebApps.WebAppChat, $.$fycR.LCFCT.TelegramWebApps.WebAppChat_Type_0, $.$fycR.LCFCT.TelegramWebApps.ColorScheme, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_1, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_2, $.$fycR.LCFCT.TelegramWebApps.ViewportChangedEventHandler, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3_Type_0, $.$fycR.LCFCT.TelegramWebApps.InvoiceClosedEventHandler, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_4, $.$fycR.LCFCT.TelegramWebApps.PopupClosedEventHandler, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_5, $.$fycR.LCFCT.TelegramWebApps.QrTextReceivedEventHandler, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_6, $.$fycR.LCFCT.TelegramWebApps.ClipboardTextReceivedEventHandler, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_8, $.$fycR.LCFCT.TelegramWebApps.BiometricAuthRequestedEventHandler, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_9, $.$fycR.LCFCT.TelegramWebApps.BiometricTokenUpdatedEventHandler ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1522483)
        
        

        //--TRIMMABLE-BOUNDARY-START(1194803)
        $asm.$cls(`$fycR.LCFCT.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591129395)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591129395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fycR.LCFCT.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$fycR.LCFCT.TelegramAppFactory, services);
                $.$fycR.LCFCT.MockingFactoryExtension.AddGeneratedMockedServices(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591129395)
            
            //--TRIMMABLE-BOUNDARY-START(12886096691)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886096691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_TelegramAppFactory(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$fycR.LCFCT.TelegramAppFactory().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$hDPm.LCFCI.IJavaScriptRunner, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$hDPm.LCFCH.IAssetsCollection, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fycR.LCFCT.TelegramAppFactory.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$fycR.LCFCT.ServiceRegistrar, Get_TelegramAppFactory, $jEKeqf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_TelegramAppFactory","d":1194803,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12886096691)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fycR.LCFCT.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296162099)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296162099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296162099)
            
            //--TRIMMABLE-BOUNDARY-START(4296162099)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296162099)
            
            static $h = 1194803;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591129395),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1194803,
      "h": 8591129395,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591129395),
//--TRIMMABLE-BOUNDARY-START(12886096691),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 1194803,
      "h": 12886096691,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886096691)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296162099),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1194803,
      "h": 4296162099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296162099)
  ],
  "h": 1194803
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1194803)
        
        

        //--TRIMMABLE-BOUNDARY-START(7224115)
        $asm.$cls(`$fycR.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4302191411)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4302191411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4302191411)
            
            //--TRIMMABLE-BOUNDARY-START(4302191411)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4302191411)
            
            static $h = 7224115;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4302191411),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 7224115,
      "h": 4302191411,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4302191411)
  ],
  "h": 7224115
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7224115)
        
        

        //--TRIMMABLE-BOUNDARY-START(473907)
        $asm.$cls(`$fycR.LCFCT.DefaultDestructivePopupButtonType`, ($self) => class DefaultDestructivePopupButtonType extends $.$TLYN.LTDU.Enumerated
        {
            //--TRIMMABLE-BOUNDARY-START(12885375795)
            /*string*/ static $default = null;
            //--TRIMMABLE-BOUNDARY-END(12885375795)
            
            //--TRIMMABLE-BOUNDARY-START(17180343091)
            /*string*/ static destructive = null;
            //--TRIMMABLE-BOUNDARY-END(17180343091)
            
            //--TRIMMABLE-BOUNDARY-START(21475310387)
            static /*DefaultDestructivePopupButtonType */ op_Implicit(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475310387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$fycR.LCFCT.DefaultDestructivePopupButtonType().$ctor$2(value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475310387)
            
            //--TRIMMABLE-BOUNDARY-START(8590408499)
            $ctor$2(/*object*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590408499);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590408499)
            
            //--TRIMMABLE-BOUNDARY-START(4295441203)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295441203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885375795)
                    this.$default = "default";
                    //--TRIMMABLE-BOUNDARY-END(12885375795)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180343091)
                    this.destructive = "destructive";
                    //--TRIMMABLE-BOUNDARY-END(17180343091)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295441203)
            
            static $h = 473907;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885375795),
    {
      "t": 1310721,
      "n": "default",
      "o": "$default",
      "d": 473907,
      "h": 12885375795,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885375795),
//--TRIMMABLE-BOUNDARY-START(17180343091),
    {
      "t": 1310721,
      "n": "destructive",
      "d": 473907,
      "h": 17180343091,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180343091)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590408499),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 473907,
      "h": 8590408499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590408499)
  ],
  "h": 473907
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.DefaultDestructivePopupButtonType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}DefaultDestructivePopupButtonType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(473907)
        
        

        //--TRIMMABLE-BOUNDARY-START(7289651)
        $asm.$cls(`$fycR.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4302256947)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4302256947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4302256947)
            
            //--TRIMMABLE-BOUNDARY-START(4302256947)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4302256947)
            
            static $h = 7289651;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4302256947),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 7289651,
      "h": 4302256947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4302256947)
  ],
  "h": 7289651,
  "a": [
    {
      "t": 7224115,
      "c": 4302191411
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7289651)
        
        

        //--TRIMMABLE-BOUNDARY-START(998195)
        $asm.$cls(`$fycR.LCFCT.OkCloseCancelPopupButtonType`, ($self) => class OkCloseCancelPopupButtonType extends $.$TLYN.LTDU.Enumerated
        {
            //--TRIMMABLE-BOUNDARY-START(21475834675)
            /*string*/ static ok = null;
            //--TRIMMABLE-BOUNDARY-END(21475834675)
            
            //--TRIMMABLE-BOUNDARY-START(17180867379)
            /*string*/ static close = null;
            //--TRIMMABLE-BOUNDARY-END(17180867379)
            
            //--TRIMMABLE-BOUNDARY-START(12885900083)
            /*string*/ static cancel = null;
            //--TRIMMABLE-BOUNDARY-END(12885900083)
            
            //--TRIMMABLE-BOUNDARY-START(25770801971)
            static /*OkCloseCancelPopupButtonType */ op_Implicit(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770801971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$fycR.LCFCT.OkCloseCancelPopupButtonType().$ctor$2(value);
            }
            //--TRIMMABLE-BOUNDARY-END(25770801971)
            
            //--TRIMMABLE-BOUNDARY-START(8590932787)
            $ctor$2(/*object*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590932787);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590932787)
            
            //--TRIMMABLE-BOUNDARY-START(4295965491)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295965491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(21475834675)
                    this.ok = "ok";
                    //--TRIMMABLE-BOUNDARY-END(21475834675)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180867379)
                    this.close = "close";
                    //--TRIMMABLE-BOUNDARY-END(17180867379)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885900083)
                    this.cancel = "cancel";
                    //--TRIMMABLE-BOUNDARY-END(12885900083)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295965491)
            
            static $h = 998195;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LTDU.Enumerated; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475834675),
    {
      "t": 1310721,
      "n": "ok",
      "d": 998195,
      "h": 21475834675,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475834675),
//--TRIMMABLE-BOUNDARY-START(17180867379),
    {
      "t": 1310721,
      "n": "close",
      "d": 998195,
      "h": 17180867379,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180867379),
//--TRIMMABLE-BOUNDARY-START(12885900083),
    {
      "t": 1310721,
      "n": "cancel",
      "d": 998195,
      "h": 12885900083,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885900083)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590932787),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 998195,
      "h": 8590932787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590932787)
  ],
  "h": 998195
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.OkCloseCancelPopupButtonType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}OkCloseCancelPopupButtonType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(998195)
        
        

        //--TRIMMABLE-BOUNDARY-START(80691)
        $asm.$cls(`$fycR.LCFCT._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590015283)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590015283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590015283)
            
            //--TRIMMABLE-BOUNDARY-START(4295047987)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295047987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295047987)
            
            //--TRIMMABLE-BOUNDARY-START(4295047987)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295047987)
            
            static $h = 80691;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590015283),
    {
      "r": 65537,
      "n": "Execute",
      "d": 80691,
      "h": 8590015283,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590015283)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295047987),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 80691,
      "h": 4295047987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295047987)
  ],
  "h": 80691
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(80691)
        
        

        //--TRIMMABLE-BOUNDARY-START(1129267)
        $asm.$cls(`$fycR.LCFCT.ScanQrPopupParams_Mocking`, ($self) => class ScanQrPopupParams_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296096563)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296096563);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296096563)
            
            //--TRIMMABLE-BOUNDARY-START(25770933043)
            /*string */ get LCFCT$TelegramWebApps$ScanQrPopupParams$text()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886031155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ScanQrPopupParams.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_text";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ScanQrPopupParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ScanQrPopupParams$text(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475965747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ScanQrPopupParams.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_text";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ScanQrPopupParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770933043)
            
            static $h = 1129267;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770933043),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886031155,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21475965747,
        "f": 83886082
      },
      "n": "{3423027}.text",
      "o": "LCFCT$TelegramWebApps$ScanQrPopupParams$text",
      "d": 1129267,
      "h": 25770933043,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25770933043)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296096563),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1129267,
      "h": 4296096563,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296096563)
  ],
  "h": 1129267
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.ScanQrPopupParams ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.ScanQrPopupParams_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}ScanQrPopupParams_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1129267)
        
        

        //--TRIMMABLE-BOUNDARY-START(539443)
        $asm.$cls(`$fycR.LCFCT.HapticFeedback_Mocking`, ($self) => class HapticFeedback_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295506739)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295506739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295506739)
            
            //--TRIMMABLE-BOUNDARY-START(8590474035)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.HapticFeedback */ LCFCT$TelegramWebApps$HapticFeedback$impactOccurred(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.HapticFeedback_Type_0*/ style)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590474035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.HapticFeedback.$type;
                    $i1.ReturnType = $.$fycR.LCFCT.TelegramWebApps.HapticFeedback.$type;
                    $i1.MethodName = "impactOccurred";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.HapticFeedback, $.$fycR.LCFCT.TelegramWebApps.HapticFeedback, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.HapticFeedback_Type_0.$type, style) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590474035)
            
            //--TRIMMABLE-BOUNDARY-START(12885441331)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.HapticFeedback */ LCFCT$TelegramWebApps$HapticFeedback$notificationOccurred(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.HapticFeedback_Type_1*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885441331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.HapticFeedback.$type;
                    $i2.ReturnType = $.$fycR.LCFCT.TelegramWebApps.HapticFeedback.$type;
                    $i2.MethodName = "notificationOccurred";
                    return $i2;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.HapticFeedback, $.$fycR.LCFCT.TelegramWebApps.HapticFeedback, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.HapticFeedback_Type_1.$type, type) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885441331)
            
            //--TRIMMABLE-BOUNDARY-START(17180408627)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.HapticFeedback */ LCFCT$TelegramWebApps$HapticFeedback$selectionChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180408627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.HapticFeedback.$type;
                    $i3.ReturnType = $.$fycR.LCFCT.TelegramWebApps.HapticFeedback.$type;
                    $i3.MethodName = "selectionChanged";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.HapticFeedback, $.$fycR.LCFCT.TelegramWebApps.HapticFeedback, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180408627)
            
            static $h = 539443;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295506739),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 539443,
      "h": 4295506739,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295506739)
  ],
  "h": 539443
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.HapticFeedback ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.HapticFeedback_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}HapticFeedback_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(539443)
        
        

        //--TRIMMABLE-BOUNDARY-START(1915699)
        $asm.$cls(`$fycR.LCFCT.TelegramWebApps_Type_6_Mocking`, ($self) => class TelegramWebApps_Type_6_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296882995)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296882995);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296882995)
            
            //--TRIMMABLE-BOUNDARY-START(8591850291)
            /*LivingThing.TSCS.Definitions.Util.Union<string, object> */ get LCFCT$TelegramWebApps$TelegramWebApps_Type_6$data()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181784883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_6.$type;
                    $i1.ReturnType = $.$TLYN.LTDU.Union$$$($.$$.S.String, $.$$.S.Object).$type;
                    $i1.MethodName = "get_data";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_6, $.$TLYN.LTDU.Union$$$($.$$.S.String, $.$$.S.Object), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*LivingThing.TSCS.Definitions.Util.Union<string, object> */ set LCFCT$TelegramWebApps$TelegramWebApps_Type_6$data(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771719475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_6.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_data";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_6, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TLYN.LTDU.Union$$$($.$$.S.String, $.$$.S.Object).$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591850291)
            
            static $h = 1915699;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591850291),
    {
      "p": $.$TLYN.LTDU.Union$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181784883,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25771719475,
        "f": 83886082
      },
      "n": "{4078387}.data",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_6$data",
      "d": 1915699,
      "h": 8591850291,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8591850291)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296882995),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1915699,
      "h": 4296882995,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296882995)
  ],
  "h": 1915699
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_6 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps_Type_6_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps_Type_6_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1915699)
        
        

        //--TRIMMABLE-BOUNDARY-START(1260339)
        $asm.$cls(`$fycR.LCFCT.SettingsButton_Mocking`, ($self) => class SettingsButton_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296227635)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296227635);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296227635)
            
            //--TRIMMABLE-BOUNDARY-START(21476096819)
            /*bool */ get LCFCT$TelegramWebApps$SettingsButton$isVisible()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886162227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i1.ReturnType = $.$$.S.Boolean.$type;
                    $i1.MethodName = "get_isVisible";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*bool */ set LCFCT$TelegramWebApps$SettingsButton$isVisible(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655966003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_isVisible";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(value, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476096819)
            
            //--TRIMMABLE-BOUNDARY-START(30066031411)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.SettingsButton */ LCFCT$TelegramWebApps$SettingsButton$onClick(/*System.Action*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066031411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i3.ReturnType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i3.MethodName = "onClick";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30066031411)
            
            //--TRIMMABLE-BOUNDARY-START(25771064115)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.SettingsButton */ LCFCT$TelegramWebApps$SettingsButton$offClick(/*System.Action*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771064115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i4.ReturnType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i4.MethodName = "offClick";
                    return $i4;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771064115)
            
            //--TRIMMABLE-BOUNDARY-START(42950933299)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.SettingsButton */ LCFCT$TelegramWebApps$SettingsButton$show()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950933299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i5.ReturnType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i5.MethodName = "show";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(42950933299)
            
            //--TRIMMABLE-BOUNDARY-START(17181129523)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.SettingsButton */ LCFCT$TelegramWebApps$SettingsButton$hide()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181129523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i6.ReturnType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i6.MethodName = "hide";
                    return $i6;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181129523)
            
            static $h = 1260339;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476096819),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886162227,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38655966003,
        "f": 83886082
      },
      "n": "{3488563}.isVisible",
      "o": "LCFCT$TelegramWebApps$SettingsButton$isVisible",
      "d": 1260339,
      "h": 21476096819,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21476096819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296227635),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1260339,
      "h": 4296227635,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296227635)
  ],
  "h": 1260339
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.SettingsButton ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.SettingsButton_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}SettingsButton_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1260339)
        
        

        //--TRIMMABLE-BOUNDARY-START(1588019)
        $asm.$cls(`$fycR.LCFCT.TelegramWebApps_Type_1_Mocking`, ($self) => class TelegramWebApps_Type_1_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296555315)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296555315);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296555315)
            
            //--TRIMMABLE-BOUNDARY-START(25771391795)
            /*double */ get LCFCT$TelegramWebApps$TelegramWebApps_Type_1$viewportHeight()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886489907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_1.$type;
                    $i1.ReturnType = $.$$.S.Double.$type;
                    $i1.MethodName = "get_viewportHeight";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_1, $.$$.S.Double, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*double */ set LCFCT$TelegramWebApps$TelegramWebApps_Type_1$viewportHeight(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476424499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_1.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_viewportHeight";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_1, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(value, $.$$.S.Double)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771391795)
            
            static $h = 1588019;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771391795),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886489907,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21476424499,
        "f": 83886082
      },
      "n": "{3685171}.viewportHeight",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_1$viewportHeight",
      "d": 1588019,
      "h": 25771391795,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25771391795)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296555315),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1588019,
      "h": 4296555315,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296555315)
  ],
  "h": 1588019
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_1 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps_Type_1_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps_Type_1_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1588019)
        
        

        //--TRIMMABLE-BOUNDARY-START(146227)
        $asm.$cls(`$fycR.LCFCT.BackButton_Mocking`, ($self) => class BackButton_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295113523)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295113523);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295113523)
            
            //--TRIMMABLE-BOUNDARY-START(21474982707)
            /*bool */ get LCFCT$TelegramWebApps$BackButton$isVisible()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885048115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i1.ReturnType = $.$$.S.Boolean.$type;
                    $i1.MethodName = "get_isVisible";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BackButton, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*bool */ set LCFCT$TelegramWebApps$BackButton$isVisible(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654851891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_isVisible";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.BackButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(value, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21474982707)
            
            //--TRIMMABLE-BOUNDARY-START(30064917299)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BackButton */ LCFCT$TelegramWebApps$BackButton$onClick(/*System.Action*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064917299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i3.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i3.MethodName = "onClick";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BackButton, $.$fycR.LCFCT.TelegramWebApps.BackButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30064917299)
            
            //--TRIMMABLE-BOUNDARY-START(25769950003)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BackButton */ LCFCT$TelegramWebApps$BackButton$offClick(/*System.Action*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769950003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i4.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i4.MethodName = "offClick";
                    return $i4;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BackButton, $.$fycR.LCFCT.TelegramWebApps.BackButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25769950003)
            
            //--TRIMMABLE-BOUNDARY-START(42949819187)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BackButton */ LCFCT$TelegramWebApps$BackButton$show()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949819187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i5.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i5.MethodName = "show";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BackButton, $.$fycR.LCFCT.TelegramWebApps.BackButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(42949819187)
            
            //--TRIMMABLE-BOUNDARY-START(17180015411)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BackButton */ LCFCT$TelegramWebApps$BackButton$hide()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180015411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i6.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i6.MethodName = "hide";
                    return $i6;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BackButton, $.$fycR.LCFCT.TelegramWebApps.BackButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180015411)
            
            static $h = 146227;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474982707),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885048115,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38654851891,
        "f": 83886082
      },
      "n": "{2112307}.isVisible",
      "o": "LCFCT$TelegramWebApps$BackButton$isVisible",
      "d": 146227,
      "h": 21474982707,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21474982707)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295113523),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 146227,
      "h": 4295113523,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295113523)
  ],
  "h": 146227
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.BackButton ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.BackButton_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}BackButton_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(146227)
        
        

        //--TRIMMABLE-BOUNDARY-START(1850163)
        $asm.$cls(`$fycR.LCFCT.TelegramWebApps_Type_5_Mocking`, ($self) => class TelegramWebApps_Type_5_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296817459)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296817459);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296817459)
            
            //--TRIMMABLE-BOUNDARY-START(8591784755)
            /*string */ get LCFCT$TelegramWebApps$TelegramWebApps_Type_5$data()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181719347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_5.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_data";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_5, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$TelegramWebApps_Type_5$data(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771653939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_5.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_data";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_5, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591784755)
            
            static $h = 1850163;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591784755),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181719347,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25771653939,
        "f": 83886082
      },
      "n": "{4012851}.data",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_5$data",
      "d": 1850163,
      "h": 8591784755,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8591784755)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296817459),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1850163,
      "h": 4296817459,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296817459)
  ],
  "h": 1850163
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_5 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps_Type_5_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps_Type_5_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1850163)
        
        

        //--TRIMMABLE-BOUNDARY-START(1325875)
        $asm.$cls(`$fycR.LCFCT.StoryShareParams_Mocking`, ($self) => class StoryShareParams_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296293171)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296293171);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296293171)
            
            //--TRIMMABLE-BOUNDARY-START(42950998835)
            /*string */ get LCFCT$TelegramWebApps$StoryShareParams$text()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886227763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.StoryShareParams.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_text";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.StoryShareParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$StoryShareParams$text(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066096947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.StoryShareParams.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_text";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.StoryShareParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(42950998835)
            
            //--TRIMMABLE-BOUNDARY-START(47245966131)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.StoryWidgetLink */ get LCFCT$TelegramWebApps$StoryShareParams$widget_link()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476162355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.StoryShareParams.$type;
                    $i3.ReturnType = $.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink.$type;
                    $i3.MethodName = "get_widget_link";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.StoryShareParams, $.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.StoryWidgetLink */ set LCFCT$TelegramWebApps$StoryShareParams$widget_link(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656031539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.StoryShareParams.$type;
                    $i4.ReturnType = $.$$.S.Void.$type;
                    $i4.MethodName = "set_widget_link";
                    return $i4;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.StoryShareParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(47245966131)
            
            static $h = 1325875;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950998835),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886227763,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066096947,
        "f": 83886082
      },
      "n": "{3554099}.text",
      "o": "LCFCT$TelegramWebApps$StoryShareParams$text",
      "d": 1325875,
      "h": 42950998835,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42950998835),
//--TRIMMABLE-BOUNDARY-START(47245966131),
    {
      "p": 3619635,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476162355,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38656031539,
        "f": 83886082
      },
      "n": "{3554099}.widget_link",
      "o": "LCFCT$TelegramWebApps$StoryShareParams$widget_link",
      "d": 1325875,
      "h": 47245966131,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47245966131)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296293171),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1325875,
      "h": 4296293171,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296293171)
  ],
  "h": 1325875
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.StoryShareParams ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.StoryShareParams_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}StoryShareParams_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1325875)
        
        

        //--TRIMMABLE-BOUNDARY-START(1784627)
        $asm.$cls(`$fycR.LCFCT.TelegramWebApps_Type_4_Mocking`, ($self) => class TelegramWebApps_Type_4_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296751923)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296751923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296751923)
            
            //--TRIMMABLE-BOUNDARY-START(8591719219)
            /*LivingThing.TSCS.Definitions.Util.Union<string, object> */ get LCFCT$TelegramWebApps$TelegramWebApps_Type_4$button_id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181653811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_4.$type;
                    $i1.ReturnType = $.$TLYN.LTDU.Union$$$($.$$.S.String, $.$$.S.Object).$type;
                    $i1.MethodName = "get_button_id";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_4, $.$TLYN.LTDU.Union$$$($.$$.S.String, $.$$.S.Object), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*LivingThing.TSCS.Definitions.Util.Union<string, object> */ set LCFCT$TelegramWebApps$TelegramWebApps_Type_4$button_id(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771588403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_4.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_button_id";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_4, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TLYN.LTDU.Union$$$($.$$.S.String, $.$$.S.Object).$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591719219)
            
            static $h = 1784627;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591719219),
    {
      "p": $.$TLYN.LTDU.Union$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181653811,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25771588403,
        "f": 83886082
      },
      "n": "{3947315}.button_id",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_4$button_id",
      "d": 1784627,
      "h": 8591719219,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8591719219)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296751923),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1784627,
      "h": 4296751923,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296751923)
  ],
  "h": 1784627
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_4 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps_Type_4_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps_Type_4_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1784627)
        
        

        //--TRIMMABLE-BOUNDARY-START(6961971)
        $asm.$cls(`$fycR.LCFCT.WebApp_Type_28_Mocking`, ($self) => class WebApp_Type_28_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4301929267)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301929267);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301929267)
            
            //--TRIMMABLE-BOUNDARY-START(25776765747)
            /*bool */ get LCFCT$TelegramWebApps$WebApp_Type_28$try_instant_view()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891863859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_28.$type;
                    $i1.ReturnType = $.$$.S.Boolean.$type;
                    $i1.MethodName = "get_try_instant_view";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_28, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*bool */ set LCFCT$TelegramWebApps$WebApp_Type_28$try_instant_view(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21481798451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_28.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_try_instant_view";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_28, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(value, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25776765747)
            
            static $h = 6961971;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25776765747),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12891863859,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21481798451,
        "f": 83886082
      },
      "n": "{5913395}.try_instant_view",
      "o": "LCFCT$TelegramWebApps$WebApp_Type_28$try_instant_view",
      "d": 6961971,
      "h": 25776765747,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25776765747)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301929267),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 6961971,
      "h": 4301929267,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4301929267)
  ],
  "h": 6961971
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.WebApp_Type_28 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.WebApp_Type_28_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}WebApp_Type_28_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6961971)
        
        

        //--TRIMMABLE-BOUNDARY-START(342835)
        $asm.$cls(`$fycR.LCFCT.BiometricRequestAccessParams_Mocking`, ($self) => class BiometricRequestAccessParams_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295310131)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295310131);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295310131)
            
            //--TRIMMABLE-BOUNDARY-START(17180212019)
            /*string */ get LCFCT$TelegramWebApps$BiometricRequestAccessParams$reason()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885244723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricRequestAccessParams.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_reason";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricRequestAccessParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$BiometricRequestAccessParams$reason(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770146611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricRequestAccessParams.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_reason";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.BiometricRequestAccessParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180212019)
            
            static $h = 342835;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180212019),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885244723,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25770146611,
        "f": 83886082
      },
      "n": "{2439987}.reason",
      "o": "LCFCT$TelegramWebApps$BiometricRequestAccessParams$reason",
      "d": 342835,
      "h": 17180212019,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17180212019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295310131),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 342835,
      "h": 4295310131,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295310131)
  ],
  "h": 342835
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.BiometricRequestAccessParams ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.BiometricRequestAccessParams_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}BiometricRequestAccessParams_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(342835)
        
        

        //--TRIMMABLE-BOUNDARY-START(1981235)
        $asm.$cls(`$fycR.LCFCT.TelegramWebApps_Type_7_Mocking`, ($self) => class TelegramWebApps_Type_7_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296948531)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296948531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296948531)
            
            //--TRIMMABLE-BOUNDARY-START(30066752307)
            /*bool */ get LCFCT$TelegramWebApps$TelegramWebApps_Type_7$isAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771785011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7.$type;
                    $i1.ReturnType = $.$$.S.Boolean.$type;
                    $i1.MethodName = "get_isAuthenticated";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*bool */ set LCFCT$TelegramWebApps$TelegramWebApps_Type_7$isAuthenticated(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246621491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_isAuthenticated";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(value, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30066752307)
            
            //--TRIMMABLE-BOUNDARY-START(8591915827)
            /*string */ get LCFCT$TelegramWebApps$TelegramWebApps_Type_7$biometricToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181850419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7.$type;
                    $i3.ReturnType = $.$$.S.String.$type;
                    $i3.MethodName = "get_biometricToken";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$TelegramWebApps_Type_7$biometricToken(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656686899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7.$type;
                    $i4.ReturnType = $.$$.S.Void.$type;
                    $i4.MethodName = "set_biometricToken";
                    return $i4;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591915827)
            
            static $h = 1981235;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066752307),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771785011,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246621491,
        "f": 83886082
      },
      "n": "{4143923}.isAuthenticated",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_7$isAuthenticated",
      "d": 1981235,
      "h": 30066752307,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30066752307),
//--TRIMMABLE-BOUNDARY-START(8591915827),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181850419,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38656686899,
        "f": 83886082
      },
      "n": "{4143923}.biometricToken",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_7$biometricToken",
      "d": 1981235,
      "h": 8591915827,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8591915827)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296948531),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1981235,
      "h": 4296948531,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296948531)
  ],
  "h": 1981235
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_7 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps_Type_7_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps_Type_7_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1981235)
        
        

        //--TRIMMABLE-BOUNDARY-START(1653555)
        $asm.$cls(`$fycR.LCFCT.TelegramWebApps_Type_2_Mocking`, ($self) => class TelegramWebApps_Type_2_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296620851)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296620851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296620851)
            
            //--TRIMMABLE-BOUNDARY-START(17181522739)
            /*bool */ get LCFCT$TelegramWebApps$TelegramWebApps_Type_2$isStateStable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886555443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_2.$type;
                    $i1.ReturnType = $.$$.S.Boolean.$type;
                    $i1.MethodName = "get_isStateStable";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_2, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*bool */ set LCFCT$TelegramWebApps$TelegramWebApps_Type_2$isStateStable(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771457331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_2.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_isStateStable";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_2, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(value, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181522739)
            
            static $h = 1653555;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181522739),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886555443,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25771457331,
        "f": 83886082
      },
      "n": "{3750707}.isStateStable",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_2$isStateStable",
      "d": 1653555,
      "h": 17181522739,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17181522739)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296620851),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1653555,
      "h": 4296620851,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296620851)
  ],
  "h": 1653555
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_2 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps_Type_2_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps_Type_2_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1653555)
        
        

        //--TRIMMABLE-BOUNDARY-START(211763)
        $asm.$cls(`$fycR.LCFCT.BiometricAuthenticateParams_Mocking`, ($self) => class BiometricAuthenticateParams_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295179059)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295179059);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295179059)
            
            //--TRIMMABLE-BOUNDARY-START(17180080947)
            /*string */ get LCFCT$TelegramWebApps$BiometricAuthenticateParams$reason()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885113651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricAuthenticateParams.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_reason";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricAuthenticateParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$BiometricAuthenticateParams$reason(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770015539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricAuthenticateParams.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_reason";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.BiometricAuthenticateParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180080947)
            
            static $h = 211763;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180080947),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885113651,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25770015539,
        "f": 83886082
      },
      "n": "{2177843}.reason",
      "o": "LCFCT$TelegramWebApps$BiometricAuthenticateParams$reason",
      "d": 211763,
      "h": 17180080947,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17180080947)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295179059),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 211763,
      "h": 4295179059,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295179059)
  ],
  "h": 211763
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.BiometricAuthenticateParams ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.BiometricAuthenticateParams_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}BiometricAuthenticateParams_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(211763)
        
        

        //--TRIMMABLE-BOUNDARY-START(2046771)
        $asm.$cls(`$fycR.LCFCT.TelegramWebApps_Type_8_Mocking`, ($self) => class TelegramWebApps_Type_8_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297014067)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297014067);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297014067)
            
            //--TRIMMABLE-BOUNDARY-START(17181915955)
            /*bool */ get LCFCT$TelegramWebApps$TelegramWebApps_Type_8$isAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886948659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_8.$type;
                    $i1.ReturnType = $.$$.S.Boolean.$type;
                    $i1.MethodName = "get_isAuthenticated";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_8, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*bool */ set LCFCT$TelegramWebApps$TelegramWebApps_Type_8$isAuthenticated(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771850547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_8.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_isAuthenticated";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_8, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(value, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181915955)
            
            static $h = 2046771;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181915955),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886948659,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25771850547,
        "f": 83886082
      },
      "n": "{4209459}.isAuthenticated",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_8$isAuthenticated",
      "d": 2046771,
      "h": 17181915955,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17181915955)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297014067),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2046771,
      "h": 4297014067,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297014067)
  ],
  "h": 2046771
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_8 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps_Type_8_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps_Type_8_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2046771)
        
        

        //--TRIMMABLE-BOUNDARY-START(6765363)
        $asm.$cls(`$fycR.LCFCT.ThemeChangedEventArg_Mocking`, ($self) => class ThemeChangedEventArg_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4301732659)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301732659);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301732659)
            
            //--TRIMMABLE-BOUNDARY-START(47251405619)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ThemeParams */ get LCFCT$TelegramWebApps$ThemeChangedEventArg$themeParams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25776569139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg.$type;
                    $i1.ReturnType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i1.MethodName = "get_themeParams";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg, $.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ThemeParams */ set LCFCT$TelegramWebApps$ThemeChangedEventArg$themeParams(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42956438323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_themeParams";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(47251405619)
            
            //--TRIMMABLE-BOUNDARY-START(8596699955)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ColorScheme */ get LCFCT$TelegramWebApps$ThemeChangedEventArg$colorScheme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186634547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg.$type;
                    $i3.ReturnType = $.$fycR.LCFCT.TelegramWebApps.ColorScheme.$type;
                    $i3.MethodName = "get_colorScheme";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg, $.$fycR.LCFCT.TelegramWebApps.ColorScheme, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ColorScheme */ set LCFCT$TelegramWebApps$ThemeChangedEventArg$colorScheme(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34366503731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg.$type;
                    $i4.ReturnType = $.$$.S.Void.$type;
                    $i4.MethodName = "set_colorScheme";
                    return $i4;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.ColorScheme.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8596699955)
            
            static $h = 6765363;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47251405619),
    {
      "p": 4471603,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25776569139,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42956438323,
        "f": 83886082
      },
      "n": "{4340531}.themeParams",
      "o": "LCFCT$TelegramWebApps$ThemeChangedEventArg$themeParams",
      "d": 6765363,
      "h": 47251405619,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47251405619),
//--TRIMMABLE-BOUNDARY-START(8596699955),
    {
      "p": 2702131,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17186634547,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34366503731,
        "f": 83886082
      },
      "n": "{4340531}.colorScheme",
      "o": "LCFCT$TelegramWebApps$ThemeChangedEventArg$colorScheme",
      "d": 6765363,
      "h": 8596699955,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8596699955)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301732659),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 6765363,
      "h": 4301732659,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4301732659)
  ],
  "h": 6765363
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.ThemeChangedEventArg_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}ThemeChangedEventArg_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6765363)
        
        

        //--TRIMMABLE-BOUNDARY-START(1719091)
        $asm.$cls(`$fycR.LCFCT.TelegramWebApps_Type_3_Mocking`, ($self) => class TelegramWebApps_Type_3_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296686387)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296686387);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296686387)
            
            //--TRIMMABLE-BOUNDARY-START(47246359347)
            /*string */ get LCFCT$TelegramWebApps$TelegramWebApps_Type_3$url()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476555571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_url";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$TelegramWebApps_Type_3$url(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656424755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_url";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(47246359347)
            
            //--TRIMMABLE-BOUNDARY-START(42951392051)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.TelegramWebApps_Type_3_Type_0 */ get LCFCT$TelegramWebApps$TelegramWebApps_Type_3$status()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886620979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3.$type;
                    $i3.ReturnType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3_Type_0.$type;
                    $i3.MethodName = "get_status";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3_Type_0, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.TelegramWebApps_Type_3_Type_0 */ set LCFCT$TelegramWebApps$TelegramWebApps_Type_3$status(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066490163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3.$type;
                    $i4.ReturnType = $.$$.S.Void.$type;
                    $i4.MethodName = "set_status";
                    return $i4;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3_Type_0.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(42951392051)
            
            static $h = 1719091;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246359347),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476555571,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38656424755,
        "f": 83886082
      },
      "n": "{3816243}.url",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_3$url",
      "d": 1719091,
      "h": 47246359347,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47246359347),
//--TRIMMABLE-BOUNDARY-START(42951392051),
    {
      "p": 3881779,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886620979,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066490163,
        "f": 83886082
      },
      "n": "{3816243}.status",
      "o": "LCFCT$TelegramWebApps$TelegramWebApps_Type_3$status",
      "d": 1719091,
      "h": 42951392051,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42951392051)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296686387),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1719091,
      "h": 4296686387,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296686387)
  ],
  "h": 1719091
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.TelegramWebApps_Type_3 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps_Type_3_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}TelegramWebApps_Type_3_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1719091)
        
        

        //--TRIMMABLE-BOUNDARY-START(1391411)
        $asm.$cls(`$fycR.LCFCT.StoryWidgetLink_Mocking`, ($self) => class StoryWidgetLink_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296358707)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296358707);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296358707)
            
            //--TRIMMABLE-BOUNDARY-START(47246031667)
            /*string */ get LCFCT$TelegramWebApps$StoryWidgetLink$url()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476227891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_url";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$StoryWidgetLink$url(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951064371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_url";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(47246031667)
            
            //--TRIMMABLE-BOUNDARY-START(25771195187)
            /*string */ get LCFCT$TelegramWebApps$StoryWidgetLink$name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886293299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink.$type;
                    $i3.ReturnType = $.$$.S.String.$type;
                    $i3.MethodName = "get_name";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$StoryWidgetLink$name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361129779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink.$type;
                    $i4.ReturnType = $.$$.S.Void.$type;
                    $i4.MethodName = "set_name";
                    return $i4;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771195187)
            
            static $h = 1391411;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246031667),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476227891,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951064371,
        "f": 83886082
      },
      "n": "{3619635}.url",
      "o": "LCFCT$TelegramWebApps$StoryWidgetLink$url",
      "d": 1391411,
      "h": 47246031667,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47246031667),
//--TRIMMABLE-BOUNDARY-START(25771195187),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886293299,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34361129779,
        "f": 83886082
      },
      "n": "{3619635}.name",
      "o": "LCFCT$TelegramWebApps$StoryWidgetLink$name",
      "d": 1391411,
      "h": 25771195187,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25771195187)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296358707),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1391411,
      "h": 4296358707,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296358707)
  ],
  "h": 1391411
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.StoryWidgetLink ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.StoryWidgetLink_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}StoryWidgetLink_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1391411)
        
        

        //--TRIMMABLE-BOUNDARY-START(7093043)
        $asm.$cls(`$fycR.LCFCT.WebAppInitData_Mocking`, ($self) => class WebAppInitData_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4302060339)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4302060339);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4302060339)
            
            //--TRIMMABLE-BOUNDARY-START(120266177331)
            /*string */ get LCFCT$TelegramWebApps$WebAppInitData$query_id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85906438963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_query_id";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(120266177331)
            
            //--TRIMMABLE-BOUNDARY-START(133151079219)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebAppUser */ get LCFCT$TelegramWebApps$WebAppInitData$user()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111676242739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i2.ReturnType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i2.MethodName = "get_user";
                    return $i2;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(133151079219)
            
            //--TRIMMABLE-BOUNDARY-START(124561144627)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebAppUser */ get LCFCT$TelegramWebApps$WebAppInitData$receiver()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94496373555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i3.ReturnType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i3.MethodName = "get_receiver";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(124561144627)
            
            //--TRIMMABLE-BOUNDARY-START(17186962227)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebAppChat */ get LCFCT$TelegramWebApps$WebAppInitData$chat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68726569779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i4.ReturnType = $.$fycR.LCFCT.TelegramWebApps.WebAppChat.$type;
                    $i4.MethodName = "get_chat";
                    return $i4;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$fycR.LCFCT.TelegramWebApps.WebAppChat, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17186962227)
            
            //--TRIMMABLE-BOUNDARY-START(25776896819)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebAppInitData_Type_0 */ get LCFCT$TelegramWebApps$WebAppInitData$chat_type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60136635187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i5.ReturnType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData_Type_0.$type;
                    $i5.MethodName = "get_chat_type";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$fycR.LCFCT.TelegramWebApps.WebAppInitData_Type_0, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25776896819)
            
            //--TRIMMABLE-BOUNDARY-START(21481929523)
            /*string */ get LCFCT$TelegramWebApps$WebAppInitData$chat_instance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51546700595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i6.ReturnType = $.$$.S.String.$type;
                    $i6.MethodName = "get_chat_instance";
                    return $i6;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21481929523)
            
            //--TRIMMABLE-BOUNDARY-START(128856111923)
            /*string */ get LCFCT$TelegramWebApps$WebAppInitData$start_param()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103086308147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i7.ReturnType = $.$$.S.String.$type;
                    $i7.MethodName = "get_start_param";
                    return $i7;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(128856111923)
            
            //--TRIMMABLE-BOUNDARY-START(12891994931)
            /*double */ get LCFCT$TelegramWebApps$WebAppInitData$can_send_after()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42956766003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i8.ReturnType = $.$$.S.Double.$type;
                    $i8.MethodName = "get_can_send_after";
                    return $i8;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$$.S.Double, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12891994931)
            
            //--TRIMMABLE-BOUNDARY-START(8597027635)
            /*double */ get LCFCT$TelegramWebApps$WebAppInitData$auth_date()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34366831411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t9 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Mock = this;
                    $i9.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i9.ReturnType = $.$$.S.Double.$type;
                    $i9.MethodName = "get_auth_date";
                    return $i9;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$$.S.Double, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8597027635)
            
            //--TRIMMABLE-BOUNDARY-START(115971210035)
            /*string */ get LCFCT$TelegramWebApps$WebAppInitData$hash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77316504371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t10 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Mock = this;
                    $i10.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i10.ReturnType = $.$$.S.String.$type;
                    $i10.MethodName = "get_hash";
                    return $i10;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(115971210035)
            
            static $h = 7093043;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120266177331),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85906438963,
        "f": 50331650
      },
      "n": "{6503219}.query_id",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$query_id",
      "d": 7093043,
      "h": 120266177331,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(120266177331),
//--TRIMMABLE-BOUNDARY-START(133151079219),
    {
      "p": 6699827,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111676242739,
        "f": 50331650
      },
      "n": "{6503219}.user",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$user",
      "d": 7093043,
      "h": 133151079219,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(133151079219),
//--TRIMMABLE-BOUNDARY-START(124561144627),
    {
      "p": 6699827,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94496373555,
        "f": 50331650
      },
      "n": "{6503219}.receiver",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$receiver",
      "d": 7093043,
      "h": 124561144627,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(124561144627),
//--TRIMMABLE-BOUNDARY-START(17186962227),
    {
      "p": 6372147,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68726569779,
        "f": 50331650
      },
      "n": "{6503219}.chat",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$chat",
      "d": 7093043,
      "h": 17186962227,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17186962227),
//--TRIMMABLE-BOUNDARY-START(25776896819),
    {
      "p": 6568755,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60136635187,
        "f": 50331650
      },
      "n": "{6503219}.chat_type",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$chat_type",
      "d": 7093043,
      "h": 25776896819,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25776896819),
//--TRIMMABLE-BOUNDARY-START(21481929523),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51546700595,
        "f": 50331650
      },
      "n": "{6503219}.chat_instance",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$chat_instance",
      "d": 7093043,
      "h": 21481929523,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21481929523),
//--TRIMMABLE-BOUNDARY-START(128856111923),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103086308147,
        "f": 50331650
      },
      "n": "{6503219}.start_param",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$start_param",
      "d": 7093043,
      "h": 128856111923,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(128856111923),
//--TRIMMABLE-BOUNDARY-START(12891994931),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42956766003,
        "f": 50331650
      },
      "n": "{6503219}.can_send_after",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$can_send_after",
      "d": 7093043,
      "h": 12891994931,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12891994931),
//--TRIMMABLE-BOUNDARY-START(8597027635),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34366831411,
        "f": 50331650
      },
      "n": "{6503219}.auth_date",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$auth_date",
      "d": 7093043,
      "h": 8597027635,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8597027635),
//--TRIMMABLE-BOUNDARY-START(115971210035),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77316504371,
        "f": 50331650
      },
      "n": "{6503219}.hash",
      "o": "LCFCT$TelegramWebApps$WebAppInitData$hash",
      "d": 7093043,
      "h": 115971210035,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(115971210035)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4302060339),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 7093043,
      "h": 4302060339,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4302060339)
  ],
  "h": 7093043
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.WebAppInitData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.WebAppInitData_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}WebAppInitData_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7093043)
        
        

        //--TRIMMABLE-BOUNDARY-START(801587)
        $asm.$cls(`$fycR.LCFCT.MainButton_Mocking`, ($self) => class MainButton_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295768883)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295768883);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295768883)
            
            //--TRIMMABLE-BOUNDARY-START(163209558835)
            /*string */ get LCFCT$TelegramWebApps$MainButton$text()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130343731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_text";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$MainButton$text(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144787763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_text";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(163209558835)
            
            //--TRIMMABLE-BOUNDARY-START(8590736179)
            /*string */ get LCFCT$TelegramWebApps$MainButton$color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770605363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i3.ReturnType = $.$$.S.String.$type;
                    $i3.MethodName = "get_color";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$MainButton$color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374983987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i4.ReturnType = $.$$.S.Void.$type;
                    $i4.MethodName = "set_color";
                    return $i4;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590736179)
            
            //--TRIMMABLE-BOUNDARY-START(167504526131)
            /*string */ get LCFCT$TelegramWebApps$MainButton$textColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720278323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i5.ReturnType = $.$$.S.String.$type;
                    $i5.MethodName = "get_textColor";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$MainButton$textColor(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734722355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i6.ReturnType = $.$$.S.Void.$type;
                    $i6.MethodName = "set_textColor";
                    return $i6;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(167504526131)
            
            //--TRIMMABLE-BOUNDARY-START(90195114803)
            /*bool */ get LCFCT$TelegramWebApps$MainButton$isVisible()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540409139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i7.ReturnType = $.$$.S.Boolean.$type;
                    $i7.MethodName = "get_isVisible";
                    return $i7;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*bool */ set LCFCT$TelegramWebApps$MainButton$isVisible(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554853171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i8.ReturnType = $.$$.S.Void.$type;
                    $i8.MethodName = "set_isVisible";
                    return $i8;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(value, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(90195114803)
            
            //--TRIMMABLE-BOUNDARY-START(81605180211)
            /*bool */ get LCFCT$TelegramWebApps$MainButton$isActive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360539955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t9 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Mock = this;
                    $i9.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i9.ReturnType = $.$$.S.Boolean.$type;
                    $i9.MethodName = "get_isActive";
                    return $i9;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*bool */ set LCFCT$TelegramWebApps$MainButton$isActive(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964918579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t10 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Mock = this;
                    $i10.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i10.ReturnType = $.$$.S.Void.$type;
                    $i10.MethodName = "set_isActive";
                    return $i10;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(value, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(81605180211)
            
            //--TRIMMABLE-BOUNDARY-START(85900147507)
            /*bool */ get LCFCT$TelegramWebApps$MainButton$isProgressVisible()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950474547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t11 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i11 = new $t11();
                    $i11.$ctor$2();
                    $i11.Mock = this;
                    $i11.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i11.ReturnType = $.$$.S.Boolean.$type;
                    $i11.MethodName = "get_isProgressVisible";
                    return $i11;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(85900147507)
            
            //--TRIMMABLE-BOUNDARY-START(150324656947)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ LCFCT$TelegramWebApps$MainButton$setText(/*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324656947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t12 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i12 = new $t12();
                    $i12.$ctor$2();
                    $i12.Mock = this;
                    $i12.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i12.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i12.MethodName = "setText";
                    return $i12;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, text) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(150324656947)
            
            //--TRIMMABLE-BOUNDARY-START(98785049395)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ LCFCT$TelegramWebApps$MainButton$onClick(/*System.Action*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785049395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t13 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i13 = new $t13();
                    $i13.$ctor$2();
                    $i13.Mock = this;
                    $i13.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i13.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i13.MethodName = "onClick";
                    return $i13;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(98785049395)
            
            //--TRIMMABLE-BOUNDARY-START(94490082099)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ LCFCT$TelegramWebApps$MainButton$offClick(/*System.Action*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490082099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t14 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i14 = new $t14();
                    $i14.$ctor$2();
                    $i14.Mock = this;
                    $i14.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i14.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i14.MethodName = "offClick";
                    return $i14;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(94490082099)
            
            //--TRIMMABLE-BOUNDARY-START(154619624243)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ LCFCT$TelegramWebApps$MainButton$show()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619624243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t15 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i15 = new $t15();
                    $i15.$ctor$2();
                    $i15.Mock = this;
                    $i15.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i15.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i15.MethodName = "show";
                    return $i15;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(154619624243)
            
            //--TRIMMABLE-BOUNDARY-START(73015245619)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ LCFCT$TelegramWebApps$MainButton$hide()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015245619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t16 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i16 = new $t16();
                    $i16.$ctor$2();
                    $i16.Mock = this;
                    $i16.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i16.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i16.MethodName = "hide";
                    return $i16;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(73015245619)
            
            //--TRIMMABLE-BOUNDARY-START(17180670771)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ LCFCT$TelegramWebApps$MainButton$enable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180670771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t17 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i17 = new $t17();
                    $i17.$ctor$2();
                    $i17.Mock = this;
                    $i17.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i17.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i17.MethodName = "enable";
                    return $i17;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180670771)
            
            //--TRIMMABLE-BOUNDARY-START(12885703475)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ LCFCT$TelegramWebApps$MainButton$disable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885703475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t18 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i18 = new $t18();
                    $i18.$ctor$2();
                    $i18.Mock = this;
                    $i18.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i18.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i18.MethodName = "disable";
                    return $i18;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885703475)
            
            //--TRIMMABLE-BOUNDARY-START(158914591539)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ LCFCT$TelegramWebApps$MainButton$showProgress(/*bool*/ leaveActive)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914591539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t19 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i19 = new $t19();
                    $i19.$ctor$2();
                    $i19.Mock = this;
                    $i19.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i19.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i19.MethodName = "showProgress";
                    return $i19;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(leaveActive, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(158914591539)
            
            //--TRIMMABLE-BOUNDARY-START(77310212915)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ LCFCT$TelegramWebApps$MainButton$hideProgress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310212915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t20 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i20 = new $t20();
                    $i20.$ctor$2();
                    $i20.Mock = this;
                    $i20.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i20.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i20.MethodName = "hideProgress";
                    return $i20;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(77310212915)
            
            //--TRIMMABLE-BOUNDARY-START(146029689651)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ LCFCT$TelegramWebApps$MainButton$setParams(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton_Type_0*/ params)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029689651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t21 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i21 = new $t21();
                    $i21.$ctor$2();
                    $i21.Mock = this;
                    $i21.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i21.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i21.MethodName = "setParams";
                    return $i21;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type, params) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(146029689651)
            
            static $h = 801587;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(163209558835),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130343731,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144787763,
        "f": 83886082
      },
      "n": "{3029811}.text",
      "o": "LCFCT$TelegramWebApps$MainButton$text",
      "d": 801587,
      "h": 163209558835,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(163209558835),
//--TRIMMABLE-BOUNDARY-START(8590736179),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770605363,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374983987,
        "f": 83886082
      },
      "n": "{3029811}.color",
      "o": "LCFCT$TelegramWebApps$MainButton$color",
      "d": 801587,
      "h": 8590736179,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8590736179),
//--TRIMMABLE-BOUNDARY-START(167504526131),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720278323,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734722355,
        "f": 83886082
      },
      "n": "{3029811}.textColor",
      "o": "LCFCT$TelegramWebApps$MainButton$textColor",
      "d": 801587,
      "h": 167504526131,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(167504526131),
//--TRIMMABLE-BOUNDARY-START(90195114803),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540409139,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554853171,
        "f": 83886082
      },
      "n": "{3029811}.isVisible",
      "o": "LCFCT$TelegramWebApps$MainButton$isVisible",
      "d": 801587,
      "h": 90195114803,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90195114803),
//--TRIMMABLE-BOUNDARY-START(81605180211),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360539955,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964918579,
        "f": 83886082
      },
      "n": "{3029811}.isActive",
      "o": "LCFCT$TelegramWebApps$MainButton$isActive",
      "d": 801587,
      "h": 81605180211,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(81605180211),
//--TRIMMABLE-BOUNDARY-START(85900147507),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950474547,
        "f": 50331650
      },
      "n": "{3029811}.isProgressVisible",
      "o": "LCFCT$TelegramWebApps$MainButton$isProgressVisible",
      "d": 801587,
      "h": 85900147507,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(85900147507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295768883),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 801587,
      "h": 4295768883,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295768883)
  ],
  "h": 801587
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.MainButton ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.MainButton_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}MainButton_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(801587)
        
        

        //--TRIMMABLE-BOUNDARY-START(277299)
        $asm.$cls(`$fycR.LCFCT.BiometricManager_Mocking`, ($self) => class BiometricManager_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295244595)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295244595);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295244595)
            
            //--TRIMMABLE-BOUNDARY-START(103079492403)
            /*bool */ get LCFCT$TelegramWebApps$BiometricManager$isInited()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309688627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i1.ReturnType = $.$$.S.Boolean.$type;
                    $i1.MethodName = "get_isInited";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(103079492403)
            
            //--TRIMMABLE-BOUNDARY-START(94489557811)
            /*bool */ get LCFCT$TelegramWebApps$BiometricManager$isBiometricAvailable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129819443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i2.ReturnType = $.$$.S.Boolean.$type;
                    $i2.MethodName = "get_isBiometricAvailable";
                    return $i2;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(94489557811)
            
            //--TRIMMABLE-BOUNDARY-START(12885179187)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricManager_Type_0 */ get LCFCT$TelegramWebApps$BiometricManager$biometricType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770081075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i3.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager_Type_0.$type;
                    $i3.MethodName = "get_biometricType";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$fycR.LCFCT.TelegramWebApps.BiometricManager_Type_0, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885179187)
            
            //--TRIMMABLE-BOUNDARY-START(90194590515)
            /*bool */ get LCFCT$TelegramWebApps$BiometricManager$isAccessRequested()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539884851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i4.ReturnType = $.$$.S.Boolean.$type;
                    $i4.MethodName = "get_isAccessRequested";
                    return $i4;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(90194590515)
            
            //--TRIMMABLE-BOUNDARY-START(85899623219)
            /*bool */ get LCFCT$TelegramWebApps$BiometricManager$isAccessGranted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949950259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i5.ReturnType = $.$$.S.Boolean.$type;
                    $i5.MethodName = "get_isAccessGranted";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(85899623219)
            
            //--TRIMMABLE-BOUNDARY-START(98784525107)
            /*bool */ get LCFCT$TelegramWebApps$BiometricManager$isBiometricTokenSaved()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719754035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i6.ReturnType = $.$$.S.Boolean.$type;
                    $i6.MethodName = "get_isBiometricTokenSaved";
                    return $i6;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(98784525107)
            
            //--TRIMMABLE-BOUNDARY-START(17180146483)
            /*string */ get LCFCT$TelegramWebApps$BiometricManager$deviceId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360015667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i7.ReturnType = $.$$.S.String.$type;
                    $i7.MethodName = "get_deviceId";
                    return $i7;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180146483)
            
            //--TRIMMABLE-BOUNDARY-START(81604655923)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricManager */ LCFCT$TelegramWebApps$BiometricManager$init(/*System.Action*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604655923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i8.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i8.MethodName = "init";
                    return $i8;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(81604655923)
            
            //--TRIMMABLE-BOUNDARY-START(111669426995)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricManager */ LCFCT$TelegramWebApps$BiometricManager$requestAccess(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricRequestAccessParams*/ params, /*System.Action<bool>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669426995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t9 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Mock = this;
                    $i9.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i9.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i9.MethodName = "requestAccess";
                    return $i9;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.BiometricRequestAccessParams.$type, params), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$$.S.Boolean).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(111669426995)
            
            //--TRIMMABLE-BOUNDARY-START(8590211891)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricManager */ LCFCT$TelegramWebApps$BiometricManager$authenticate(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricAuthenticateParams*/ params, /*System.Action<bool>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590211891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t10 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Mock = this;
                    $i10.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i10.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i10.MethodName = "authenticate";
                    return $i10;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.BiometricAuthenticateParams.$type, params), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$$.S.Boolean).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590211891)
            
            //--TRIMMABLE-BOUNDARY-START(115964394291)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricManager */ LCFCT$TelegramWebApps$BiometricManager$updateBiometricToken(/*string*/ token, /*System.Action<bool>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964394291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t11 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i11 = new $t11();
                    $i11.$ctor$2();
                    $i11.Mock = this;
                    $i11.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i11.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i11.MethodName = "updateBiometricToken";
                    return $i11;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, token), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$$.S.Boolean).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(115964394291)
            
            //--TRIMMABLE-BOUNDARY-START(107374459699)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricManager */ LCFCT$TelegramWebApps$BiometricManager$openSettings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374459699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t12 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i12 = new $t12();
                    $i12.$ctor$2();
                    $i12.Mock = this;
                    $i12.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i12.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i12.MethodName = "openSettings";
                    return $i12;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(107374459699)
            
            static $h = 277299;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079492403),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309688627,
        "f": 50331650
      },
      "n": "{2308915}.isInited",
      "o": "LCFCT$TelegramWebApps$BiometricManager$isInited",
      "d": 277299,
      "h": 103079492403,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(103079492403),
//--TRIMMABLE-BOUNDARY-START(94489557811),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129819443,
        "f": 50331650
      },
      "n": "{2308915}.isBiometricAvailable",
      "o": "LCFCT$TelegramWebApps$BiometricManager$isBiometricAvailable",
      "d": 277299,
      "h": 94489557811,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(94489557811),
//--TRIMMABLE-BOUNDARY-START(12885179187),
    {
      "p": 2374451,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770081075,
        "f": 50331650
      },
      "n": "{2308915}.biometricType",
      "o": "LCFCT$TelegramWebApps$BiometricManager$biometricType",
      "d": 277299,
      "h": 12885179187,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12885179187),
//--TRIMMABLE-BOUNDARY-START(90194590515),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539884851,
        "f": 50331650
      },
      "n": "{2308915}.isAccessRequested",
      "o": "LCFCT$TelegramWebApps$BiometricManager$isAccessRequested",
      "d": 277299,
      "h": 90194590515,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(90194590515),
//--TRIMMABLE-BOUNDARY-START(85899623219),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949950259,
        "f": 50331650
      },
      "n": "{2308915}.isAccessGranted",
      "o": "LCFCT$TelegramWebApps$BiometricManager$isAccessGranted",
      "d": 277299,
      "h": 85899623219,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(85899623219),
//--TRIMMABLE-BOUNDARY-START(98784525107),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719754035,
        "f": 50331650
      },
      "n": "{2308915}.isBiometricTokenSaved",
      "o": "LCFCT$TelegramWebApps$BiometricManager$isBiometricTokenSaved",
      "d": 277299,
      "h": 98784525107,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98784525107),
//--TRIMMABLE-BOUNDARY-START(17180146483),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360015667,
        "f": 50331650
      },
      "n": "{2308915}.deviceId",
      "o": "LCFCT$TelegramWebApps$BiometricManager$deviceId",
      "d": 277299,
      "h": 17180146483,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17180146483)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295244595),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 277299,
      "h": 4295244595,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295244595)
  ],
  "h": 277299
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.BiometricManager ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.BiometricManager_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}BiometricManager_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(277299)
        
        

        //--TRIMMABLE-BOUNDARY-START(6830899)
        $asm.$cls(`$fycR.LCFCT.ThemeParams_Mocking`, ($self) => class ThemeParams_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4301798195)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301798195);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301798195)
            
            //--TRIMMABLE-BOUNDARY-START(12891732787)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$bg_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42956503859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_bg_color";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$bg_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193280359219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_bg_color";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12891732787)
            
            //--TRIMMABLE-BOUNDARY-START(304949508915)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$text_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146035718963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i3.ReturnType = $.$$.S.String.$type;
                    $i3.MethodName = "get_text_color";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$text_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296359574323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i4.ReturnType = $.$$.S.Void.$type;
                    $i4.MethodName = "set_text_color";
                    return $i4;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(304949508915)
            
            //--TRIMMABLE-BOUNDARY-START(154625653555)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$hint_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85906176819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i5.ReturnType = $.$$.S.String.$type;
                    $i5.MethodName = "get_hint_color";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$hint_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236230032179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i6.ReturnType = $.$$.S.Void.$type;
                    $i6.MethodName = "set_hint_color";
                    return $i6;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(154625653555)
            
            //--TRIMMABLE-BOUNDARY-START(158920620851)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$link_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94496111411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i7.ReturnType = $.$$.S.String.$type;
                    $i7.MethodName = "get_link_color";
                    return $i7;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$link_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244819966771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i8.ReturnType = $.$$.S.Void.$type;
                    $i8.MethodName = "set_link_color";
                    return $i8;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(158920620851)
            
            //--TRIMMABLE-BOUNDARY-START(17186700083)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$button_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51546438451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t9 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Mock = this;
                    $i9.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i9.ReturnType = $.$$.S.String.$type;
                    $i9.MethodName = "get_button_color";
                    return $i9;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$button_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201870293811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t10 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Mock = this;
                    $i10.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i10.ReturnType = $.$$.S.Void.$type;
                    $i10.MethodName = "set_button_color";
                    return $i10;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17186700083)
            
            //--TRIMMABLE-BOUNDARY-START(21481667379)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$button_text_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60136373043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t11 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i11 = new $t11();
                    $i11.$ctor$2();
                    $i11.Mock = this;
                    $i11.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i11.ReturnType = $.$$.S.String.$type;
                    $i11.MethodName = "get_button_text_color";
                    return $i11;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$button_text_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210460228403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t12 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i12 = new $t12();
                    $i12.$ctor$2();
                    $i12.Mock = this;
                    $i12.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i12.ReturnType = $.$$.S.Void.$type;
                    $i12.MethodName = "set_button_text_color";
                    return $i12;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21481667379)
            
            //--TRIMMABLE-BOUNDARY-START(163215588147)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$secondary_bg_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103086046003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t13 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i13 = new $t13();
                    $i13.$ctor$2();
                    $i13.Mock = this;
                    $i13.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i13.ReturnType = $.$$.S.String.$type;
                    $i13.MethodName = "get_secondary_bg_color";
                    return $i13;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$secondary_bg_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253409901363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t14 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i14 = new $t14();
                    $i14.$ctor$2();
                    $i14.Mock = this;
                    $i14.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i14.ReturnType = $.$$.S.Void.$type;
                    $i14.MethodName = "set_secondary_bg_color";
                    return $i14;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(163215588147)
            
            //--TRIMMABLE-BOUNDARY-START(150330686259)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$header_bg_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77316242227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t15 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i15 = new $t15();
                    $i15.$ctor$2();
                    $i15.Mock = this;
                    $i15.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i15.ReturnType = $.$$.S.String.$type;
                    $i15.MethodName = "get_header_bg_color";
                    return $i15;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$header_bg_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227640097587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t16 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i16 = new $t16();
                    $i16.$ctor$2();
                    $i16.Mock = this;
                    $i16.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i16.ReturnType = $.$$.S.Void.$type;
                    $i16.MethodName = "set_header_bg_color";
                    return $i16;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(150330686259)
            
            //--TRIMMABLE-BOUNDARY-START(8596765491)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$accent_text_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34366569267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t17 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i17 = new $t17();
                    $i17.$ctor$2();
                    $i17.Mock = this;
                    $i17.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i17.ReturnType = $.$$.S.String.$type;
                    $i17.MethodName = "get_accent_text_color";
                    return $i17;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$accent_text_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184690424627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t18 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i18 = new $t18();
                    $i18.$ctor$2();
                    $i18.Mock = this;
                    $i18.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i18.ReturnType = $.$$.S.Void.$type;
                    $i18.MethodName = "set_accent_text_color";
                    return $i18;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8596765491)
            
            //--TRIMMABLE-BOUNDARY-START(167510555443)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$section_bg_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111675980595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t19 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i19 = new $t19();
                    $i19.$ctor$2();
                    $i19.Mock = this;
                    $i19.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i19.ReturnType = $.$$.S.String.$type;
                    $i19.MethodName = "get_section_bg_color";
                    return $i19;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$section_bg_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261999835955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t20 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i20 = new $t20();
                    $i20.$ctor$2();
                    $i20.Mock = this;
                    $i20.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i20.ReturnType = $.$$.S.Void.$type;
                    $i20.MethodName = "set_section_bg_color";
                    return $i20;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(167510555443)
            
            //--TRIMMABLE-BOUNDARY-START(171805522739)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$section_header_text_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120265915187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t21 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i21 = new $t21();
                    $i21.$ctor$2();
                    $i21.Mock = this;
                    $i21.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i21.ReturnType = $.$$.S.String.$type;
                    $i21.MethodName = "get_section_header_text_color";
                    return $i21;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$section_header_text_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270589770547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t22 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i22 = new $t22();
                    $i22.$ctor$2();
                    $i22.Mock = this;
                    $i22.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i22.ReturnType = $.$$.S.Void.$type;
                    $i22.MethodName = "set_section_header_text_color";
                    return $i22;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(171805522739)
            
            //--TRIMMABLE-BOUNDARY-START(176100490035)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$section_separator_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128855849779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t23 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i23 = new $t23();
                    $i23.$ctor$2();
                    $i23.Mock = this;
                    $i23.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i23.ReturnType = $.$$.S.String.$type;
                    $i23.MethodName = "get_section_separator_color";
                    return $i23;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$section_separator_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279179705139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t24 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i24 = new $t24();
                    $i24.$ctor$2();
                    $i24.Mock = this;
                    $i24.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i24.ReturnType = $.$$.S.Void.$type;
                    $i24.MethodName = "set_section_separator_color";
                    return $i24;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(176100490035)
            
            //--TRIMMABLE-BOUNDARY-START(300654541619)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$subtitle_text_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137445784371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t25 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i25 = new $t25();
                    $i25.$ctor$2();
                    $i25.Mock = this;
                    $i25.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i25.ReturnType = $.$$.S.String.$type;
                    $i25.MethodName = "get_subtitle_text_color";
                    return $i25;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$subtitle_text_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287769639731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t26 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i26 = new $t26();
                    $i26.$ctor$2();
                    $i26.Mock = this;
                    $i26.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i26.ReturnType = $.$$.S.Void.$type;
                    $i26.MethodName = "set_subtitle_text_color";
                    return $i26;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(300654541619)
            
            //--TRIMMABLE-BOUNDARY-START(25776634675)
            /*string */ get LCFCT$TelegramWebApps$ThemeParams$destructive_text_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68726307635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t27 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i27 = new $t27();
                    $i27.$ctor$2();
                    $i27.Mock = this;
                    $i27.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i27.ReturnType = $.$$.S.String.$type;
                    $i27.MethodName = "get_destructive_text_color";
                    return $i27;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$ThemeParams$destructive_text_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219050162995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t28 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i28 = new $t28();
                    $i28.$ctor$2();
                    $i28.Mock = this;
                    $i28.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i28.ReturnType = $.$$.S.Void.$type;
                    $i28.MethodName = "set_destructive_text_color";
                    return $i28;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25776634675)
            
            static $h = 6830899;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12891732787),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42956503859,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193280359219,
        "f": 83886082
      },
      "n": "{4471603}.bg_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$bg_color",
      "d": 6830899,
      "h": 12891732787,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12891732787),
//--TRIMMABLE-BOUNDARY-START(304949508915),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146035718963,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296359574323,
        "f": 83886082
      },
      "n": "{4471603}.text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$text_color",
      "d": 6830899,
      "h": 304949508915,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(304949508915),
//--TRIMMABLE-BOUNDARY-START(154625653555),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85906176819,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236230032179,
        "f": 83886082
      },
      "n": "{4471603}.hint_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$hint_color",
      "d": 6830899,
      "h": 154625653555,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(154625653555),
//--TRIMMABLE-BOUNDARY-START(158920620851),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94496111411,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244819966771,
        "f": 83886082
      },
      "n": "{4471603}.link_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$link_color",
      "d": 6830899,
      "h": 158920620851,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(158920620851),
//--TRIMMABLE-BOUNDARY-START(17186700083),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51546438451,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201870293811,
        "f": 83886082
      },
      "n": "{4471603}.button_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$button_color",
      "d": 6830899,
      "h": 17186700083,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17186700083),
//--TRIMMABLE-BOUNDARY-START(21481667379),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60136373043,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210460228403,
        "f": 83886082
      },
      "n": "{4471603}.button_text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$button_text_color",
      "d": 6830899,
      "h": 21481667379,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21481667379),
//--TRIMMABLE-BOUNDARY-START(163215588147),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103086046003,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253409901363,
        "f": 83886082
      },
      "n": "{4471603}.secondary_bg_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$secondary_bg_color",
      "d": 6830899,
      "h": 163215588147,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(163215588147),
//--TRIMMABLE-BOUNDARY-START(150330686259),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77316242227,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227640097587,
        "f": 83886082
      },
      "n": "{4471603}.header_bg_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$header_bg_color",
      "d": 6830899,
      "h": 150330686259,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(150330686259),
//--TRIMMABLE-BOUNDARY-START(8596765491),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34366569267,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184690424627,
        "f": 83886082
      },
      "n": "{4471603}.accent_text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$accent_text_color",
      "d": 6830899,
      "h": 8596765491,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8596765491),
//--TRIMMABLE-BOUNDARY-START(167510555443),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111675980595,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261999835955,
        "f": 83886082
      },
      "n": "{4471603}.section_bg_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$section_bg_color",
      "d": 6830899,
      "h": 167510555443,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(167510555443),
//--TRIMMABLE-BOUNDARY-START(171805522739),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120265915187,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270589770547,
        "f": 83886082
      },
      "n": "{4471603}.section_header_text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$section_header_text_color",
      "d": 6830899,
      "h": 171805522739,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(171805522739),
//--TRIMMABLE-BOUNDARY-START(176100490035),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128855849779,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279179705139,
        "f": 83886082
      },
      "n": "{4471603}.section_separator_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$section_separator_color",
      "d": 6830899,
      "h": 176100490035,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(176100490035),
//--TRIMMABLE-BOUNDARY-START(300654541619),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137445784371,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287769639731,
        "f": 83886082
      },
      "n": "{4471603}.subtitle_text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$subtitle_text_color",
      "d": 6830899,
      "h": 300654541619,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(300654541619),
//--TRIMMABLE-BOUNDARY-START(25776634675),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68726307635,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219050162995,
        "f": 83886082
      },
      "n": "{4471603}.destructive_text_color",
      "o": "LCFCT$TelegramWebApps$ThemeParams$destructive_text_color",
      "d": 6830899,
      "h": 25776634675,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25776634675)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301798195),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 6830899,
      "h": 4301798195,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4301798195)
  ],
  "h": 6830899
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.ThemeParams ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.ThemeParams_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}ThemeParams_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6830899)
        
        

        //--TRIMMABLE-BOUNDARY-START(7027507)
        $asm.$cls(`$fycR.LCFCT.WebAppChat_Mocking`, ($self) => class WebAppChat_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4301994803)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301994803);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301994803)
            
            //--TRIMMABLE-BOUNDARY-START(51546635059)
            /*double */ get LCFCT$TelegramWebApps$WebAppChat$id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891929395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppChat.$type;
                    $i1.ReturnType = $.$$.S.Double.$type;
                    $i1.MethodName = "get_id";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppChat, $.$$.S.Double, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(51546635059)
            
            //--TRIMMABLE-BOUNDARY-START(64431536947)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebAppChat_Type_0 */ get LCFCT$TelegramWebApps$WebAppChat$type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38661733171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppChat.$type;
                    $i2.ReturnType = $.$fycR.LCFCT.TelegramWebApps.WebAppChat_Type_0.$type;
                    $i2.MethodName = "get_type";
                    return $i2;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppChat, $.$fycR.LCFCT.TelegramWebApps.WebAppChat_Type_0, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(64431536947)
            
            //--TRIMMABLE-BOUNDARY-START(60136569651)
            /*string */ get LCFCT$TelegramWebApps$WebAppChat$title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30071798579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppChat.$type;
                    $i3.ReturnType = $.$$.S.String.$type;
                    $i3.MethodName = "get_title";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppChat, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(60136569651)
            
            //--TRIMMABLE-BOUNDARY-START(68726504243)
            /*string */ get LCFCT$TelegramWebApps$WebAppChat$username()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47251667763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppChat.$type;
                    $i4.ReturnType = $.$$.S.String.$type;
                    $i4.MethodName = "get_username";
                    return $i4;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppChat, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(68726504243)
            
            //--TRIMMABLE-BOUNDARY-START(55841602355)
            /*string */ get LCFCT$TelegramWebApps$WebAppChat$photo_url()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21481863987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppChat.$type;
                    $i5.ReturnType = $.$$.S.String.$type;
                    $i5.MethodName = "get_photo_url";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppChat, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(55841602355)
            
            static $h = 7027507;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51546635059),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12891929395,
        "f": 50331650
      },
      "n": "{6372147}.id",
      "o": "LCFCT$TelegramWebApps$WebAppChat$id",
      "d": 7027507,
      "h": 51546635059,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51546635059),
//--TRIMMABLE-BOUNDARY-START(64431536947),
    {
      "p": 6437683,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38661733171,
        "f": 50331650
      },
      "n": "{6372147}.type",
      "o": "LCFCT$TelegramWebApps$WebAppChat$type",
      "d": 7027507,
      "h": 64431536947,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64431536947),
//--TRIMMABLE-BOUNDARY-START(60136569651),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30071798579,
        "f": 50331650
      },
      "n": "{6372147}.title",
      "o": "LCFCT$TelegramWebApps$WebAppChat$title",
      "d": 7027507,
      "h": 60136569651,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60136569651),
//--TRIMMABLE-BOUNDARY-START(68726504243),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47251667763,
        "f": 50331650
      },
      "n": "{6372147}.username",
      "o": "LCFCT$TelegramWebApps$WebAppChat$username",
      "d": 7027507,
      "h": 68726504243,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(68726504243),
//--TRIMMABLE-BOUNDARY-START(55841602355),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21481863987,
        "f": 50331650
      },
      "n": "{6372147}.photo_url",
      "o": "LCFCT$TelegramWebApps$WebAppChat$photo_url",
      "d": 7027507,
      "h": 55841602355,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55841602355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301994803),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 7027507,
      "h": 4301994803,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4301994803)
  ],
  "h": 7027507
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.WebAppChat ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.WebAppChat_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}WebAppChat_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7027507)
        
        

        //--TRIMMABLE-BOUNDARY-START(408371)
        $asm.$cls(`$fycR.LCFCT.CloudStorage_Mocking`, ($self) => class CloudStorage_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295375667)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295375667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295375667)
            
            //--TRIMMABLE-BOUNDARY-START(30065179443)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.CloudStorage */ LCFCT$TelegramWebApps$CloudStorage$setItem(/*string*/ key, /*string*/ value, /*LivingThing.TSCS.Definitions.Util.Union<System.Action<LivingThing.TSCS.Definitions.Javascript.Error>, System.Action<object, bool>>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065179443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i1.ReturnType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i1.MethodName = "setItem";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, key), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$$.S.Boolean)).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30065179443)
            
            //--TRIMMABLE-BOUNDARY-START(8590342963)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.CloudStorage */ LCFCT$TelegramWebApps$CloudStorage$getItem(/*string*/ key, /*LivingThing.TSCS.Definitions.Util.Union<System.Action<LivingThing.TSCS.Definitions.Javascript.Error>, System.Action<object, string>>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590342963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i2.ReturnType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i2.MethodName = "getItem";
                    return $i2;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, key), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$$.S.String)).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590342963)
            
            //--TRIMMABLE-BOUNDARY-START(12885310259)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.CloudStorage */ LCFCT$TelegramWebApps$CloudStorage$getItems(/*string[]*/ keys, /*LivingThing.TSCS.Definitions.Util.Union<System.Action<LivingThing.TSCS.Definitions.Javascript.Error>, System.Action<object, string[]>>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885310259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i3.ReturnType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i3.MethodName = "getItems";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$$.S.String).$type, keys), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$typeArray($.$$.S.String))).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885310259)
            
            //--TRIMMABLE-BOUNDARY-START(21475244851)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.CloudStorage */ LCFCT$TelegramWebApps$CloudStorage$removeItem(/*string*/ key, /*LivingThing.TSCS.Definitions.Util.Union<System.Action<LivingThing.TSCS.Definitions.Javascript.Error>, System.Action<object, bool>>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475244851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i4.ReturnType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i4.MethodName = "removeItem";
                    return $i4;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, key), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$$.S.Boolean)).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475244851)
            
            //--TRIMMABLE-BOUNDARY-START(25770212147)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.CloudStorage */ LCFCT$TelegramWebApps$CloudStorage$removeItems(/*string[]*/ keys, /*LivingThing.TSCS.Definitions.Util.Union<System.Action<LivingThing.TSCS.Definitions.Javascript.Error>, System.Action<object, bool>>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770212147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i5.ReturnType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i5.MethodName = "removeItems";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$$.S.String).$type, keys), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$$.S.Boolean)).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770212147)
            
            //--TRIMMABLE-BOUNDARY-START(17180277555)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.CloudStorage */ LCFCT$TelegramWebApps$CloudStorage$getKeys(/*LivingThing.TSCS.Definitions.Util.Union<System.Action<LivingThing.TSCS.Definitions.Javascript.Error>, System.Action<object, string[]>>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180277555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i6.ReturnType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i6.MethodName = "getKeys";
                    return $i6;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$TLYN.LTDU.Union$$$($.$$.S.Action$$($.$TLYN.LTDJ.Error), $.$$.S.Action$$$($.$$.S.Object, $.$typeArray($.$$.S.String))).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180277555)
            
            static $h = 408371;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295375667),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 408371,
      "h": 4295375667,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295375667)
  ],
  "h": 408371
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.CloudStorage ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.CloudStorage_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}CloudStorage_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(408371)
        
        

        //--TRIMMABLE-BOUNDARY-START(7158579)
        $asm.$cls(`$fycR.LCFCT.WebAppUser_Mocking`, ($self) => class WebAppUser_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4302125875)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4302125875);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4302125875)
            
            //--TRIMMABLE-BOUNDARY-START(107381340979)
            /*double */ get LCFCT$TelegramWebApps$WebAppUser$id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51546766131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i1.ReturnType = $.$$.S.Double.$type;
                    $i1.MethodName = "get_id";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$$.S.Double, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(107381340979)
            
            //--TRIMMABLE-BOUNDARY-START(111676308275)
            /*bool */ get LCFCT$TelegramWebApps$WebAppUser$is_bot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60136700723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i2.ReturnType = $.$$.S.Boolean.$type;
                    $i2.MethodName = "get_is_bot";
                    return $i2;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(111676308275)
            
            //--TRIMMABLE-BOUNDARY-START(17187027763)
            /*string */ get LCFCT$TelegramWebApps$WebAppUser$first_name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42956831539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i3.ReturnType = $.$$.S.String.$type;
                    $i3.MethodName = "get_first_name";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17187027763)
            
            //--TRIMMABLE-BOUNDARY-START(124561210163)
            /*string */ get LCFCT$TelegramWebApps$WebAppUser$last_name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85906504499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i4.ReturnType = $.$$.S.String.$type;
                    $i4.MethodName = "get_last_name";
                    return $i4;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(124561210163)
            
            //--TRIMMABLE-BOUNDARY-START(133151144755)
            /*string */ get LCFCT$TelegramWebApps$WebAppUser$username()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103086373683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i5.ReturnType = $.$$.S.String.$type;
                    $i5.MethodName = "get_username";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(133151144755)
            
            //--TRIMMABLE-BOUNDARY-START(120266242867)
            /*string */ get LCFCT$TelegramWebApps$WebAppUser$language_code()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77316569907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i6.ReturnType = $.$$.S.String.$type;
                    $i6.MethodName = "get_language_code";
                    return $i6;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(120266242867)
            
            //--TRIMMABLE-BOUNDARY-START(115971275571)
            /*bool */ get LCFCT$TelegramWebApps$WebAppUser$is_premium()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68726635315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i7.ReturnType = $.$$.S.Boolean.$type;
                    $i7.MethodName = "get_is_premium";
                    return $i7;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(115971275571)
            
            //--TRIMMABLE-BOUNDARY-START(8597093171)
            /*bool */ get LCFCT$TelegramWebApps$WebAppUser$added_to_attachment_menu()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25776962355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i8.ReturnType = $.$$.S.Boolean.$type;
                    $i8.MethodName = "get_added_to_attachment_menu";
                    return $i8;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8597093171)
            
            //--TRIMMABLE-BOUNDARY-START(12892060467)
            /*bool */ get LCFCT$TelegramWebApps$WebAppUser$allows_write_to_pm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34366896947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t9 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Mock = this;
                    $i9.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i9.ReturnType = $.$$.S.Boolean.$type;
                    $i9.MethodName = "get_allows_write_to_pm";
                    return $i9;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12892060467)
            
            //--TRIMMABLE-BOUNDARY-START(128856177459)
            /*string */ get LCFCT$TelegramWebApps$WebAppUser$photo_url()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94496439091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t10 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Mock = this;
                    $i10.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebAppUser.$type;
                    $i10.ReturnType = $.$$.S.String.$type;
                    $i10.MethodName = "get_photo_url";
                    return $i10;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebAppUser, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(128856177459)
            
            static $h = 7158579;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107381340979),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51546766131,
        "f": 50331650
      },
      "n": "{6699827}.id",
      "o": "LCFCT$TelegramWebApps$WebAppUser$id",
      "d": 7158579,
      "h": 107381340979,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(107381340979),
//--TRIMMABLE-BOUNDARY-START(111676308275),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60136700723,
        "f": 50331650
      },
      "n": "{6699827}.is_bot",
      "o": "LCFCT$TelegramWebApps$WebAppUser$is_bot",
      "d": 7158579,
      "h": 111676308275,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(111676308275),
//--TRIMMABLE-BOUNDARY-START(17187027763),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42956831539,
        "f": 50331650
      },
      "n": "{6699827}.first_name",
      "o": "LCFCT$TelegramWebApps$WebAppUser$first_name",
      "d": 7158579,
      "h": 17187027763,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17187027763),
//--TRIMMABLE-BOUNDARY-START(124561210163),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85906504499,
        "f": 50331650
      },
      "n": "{6699827}.last_name",
      "o": "LCFCT$TelegramWebApps$WebAppUser$last_name",
      "d": 7158579,
      "h": 124561210163,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(124561210163),
//--TRIMMABLE-BOUNDARY-START(133151144755),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103086373683,
        "f": 50331650
      },
      "n": "{6699827}.username",
      "o": "LCFCT$TelegramWebApps$WebAppUser$username",
      "d": 7158579,
      "h": 133151144755,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(133151144755),
//--TRIMMABLE-BOUNDARY-START(120266242867),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77316569907,
        "f": 50331650
      },
      "n": "{6699827}.language_code",
      "o": "LCFCT$TelegramWebApps$WebAppUser$language_code",
      "d": 7158579,
      "h": 120266242867,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(120266242867),
//--TRIMMABLE-BOUNDARY-START(115971275571),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68726635315,
        "f": 50331650
      },
      "n": "{6699827}.is_premium",
      "o": "LCFCT$TelegramWebApps$WebAppUser$is_premium",
      "d": 7158579,
      "h": 115971275571,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(115971275571),
//--TRIMMABLE-BOUNDARY-START(8597093171),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25776962355,
        "f": 50331650
      },
      "n": "{6699827}.added_to_attachment_menu",
      "o": "LCFCT$TelegramWebApps$WebAppUser$added_to_attachment_menu",
      "d": 7158579,
      "h": 8597093171,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8597093171),
//--TRIMMABLE-BOUNDARY-START(12892060467),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34366896947,
        "f": 50331650
      },
      "n": "{6699827}.allows_write_to_pm",
      "o": "LCFCT$TelegramWebApps$WebAppUser$allows_write_to_pm",
      "d": 7158579,
      "h": 12892060467,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12892060467),
//--TRIMMABLE-BOUNDARY-START(128856177459),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94496439091,
        "f": 50331650
      },
      "n": "{6699827}.photo_url",
      "o": "LCFCT$TelegramWebApps$WebAppUser$photo_url",
      "d": 7158579,
      "h": 128856177459,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(128856177459)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4302125875),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 7158579,
      "h": 4302125875,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4302125875)
  ],
  "h": 7158579
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.WebAppUser ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.WebAppUser_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}WebAppUser_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7158579)
        
        

        //--TRIMMABLE-BOUNDARY-START(1063731)
        $asm.$cls(`$fycR.LCFCT.PopupParams_Mocking`, ($self) => class PopupParams_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296031027)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296031027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296031027)
            
            //--TRIMMABLE-BOUNDARY-START(68720540467)
            /*string */ get LCFCT$TelegramWebApps$PopupParams$title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360802099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.PopupParams.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_title";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.PopupParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$PopupParams$title(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425573171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.PopupParams.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_title";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.PopupParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(68720540467)
            
            //--TRIMMABLE-BOUNDARY-START(38655769395)
            /*string */ get LCFCT$TelegramWebApps$PopupParams$message()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770867507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.PopupParams.$type;
                    $i3.ReturnType = $.$$.S.String.$type;
                    $i3.MethodName = "get_message";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.PopupParams, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$PopupParams$message(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835638579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.PopupParams.$type;
                    $i4.ReturnType = $.$$.S.Void.$type;
                    $i4.MethodName = "set_message";
                    return $i4;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.PopupParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(38655769395)
            
            //--TRIMMABLE-BOUNDARY-START(8590998323)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.PopupButton[] */ get LCFCT$TelegramWebApps$PopupParams$buttons()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180932915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.PopupParams.$type;
                    $i5.ReturnType = $.$typeArray($.$fycR.LCFCT.TelegramWebApps.PopupButton).$type;
                    $i5.MethodName = "get_buttons";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.PopupParams, $.$typeArray($.$fycR.LCFCT.TelegramWebApps.PopupButton), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.PopupButton[] */ set LCFCT$TelegramWebApps$PopupParams$buttons(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245703987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.PopupParams.$type;
                    $i6.ReturnType = $.$$.S.Void.$type;
                    $i6.MethodName = "set_buttons";
                    return $i6;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.PopupParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$fycR.LCFCT.TelegramWebApps.PopupButton).$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590998323)
            
            static $h = 1063731;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720540467),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360802099,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425573171,
        "f": 83886082
      },
      "n": "{3291955}.title",
      "o": "LCFCT$TelegramWebApps$PopupParams$title",
      "d": 1063731,
      "h": 68720540467,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(68720540467),
//--TRIMMABLE-BOUNDARY-START(38655769395),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770867507,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835638579,
        "f": 83886082
      },
      "n": "{3291955}.message",
      "o": "LCFCT$TelegramWebApps$PopupParams$message",
      "d": 1063731,
      "h": 38655769395,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38655769395),
//--TRIMMABLE-BOUNDARY-START(8590998323),
    {
      "p": $.$typeArray($.$fycR.LCFCT.TelegramWebApps.PopupButton).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180932915,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245703987,
        "f": 83886082
      },
      "n": "{3291955}.buttons",
      "o": "LCFCT$TelegramWebApps$PopupParams$buttons",
      "d": 1063731,
      "h": 8590998323,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8590998323)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296031027),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1063731,
      "h": 4296031027,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296031027)
  ],
  "h": 1063731
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.PopupParams ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.PopupParams_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}PopupParams_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1063731)
        
        

        //--TRIMMABLE-BOUNDARY-START(867123)
        $asm.$cls(`$fycR.LCFCT.MainButton_Type_0_Mocking`, ($self) => class MainButton_Type_0_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295834419)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295834419);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295834419)
            
            //--TRIMMABLE-BOUNDARY-START(107375049523)
            /*string */ get LCFCT$TelegramWebApps$MainButton_Type_0$text()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540474675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_text";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$MainButton_Type_0$text(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080082227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_text";
                    return $i2;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(107375049523)
            
            //--TRIMMABLE-BOUNDARY-START(8590801715)
            /*string */ get LCFCT$TelegramWebApps$MainButton_Type_0$color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180736307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type;
                    $i3.ReturnType = $.$$.S.String.$type;
                    $i3.MethodName = "get_color";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$MainButton_Type_0$color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720343859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type;
                    $i4.ReturnType = $.$$.S.Void.$type;
                    $i4.MethodName = "set_color";
                    return $i4;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590801715)
            
            //--TRIMMABLE-BOUNDARY-START(111670016819)
            /*string */ get LCFCT$TelegramWebApps$MainButton_Type_0$text_color()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950540083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type;
                    $i5.ReturnType = $.$$.S.String.$type;
                    $i5.MethodName = "get_text_color";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*string */ set LCFCT$TelegramWebApps$MainButton_Type_0$text_color(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490147635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type;
                    $i6.ReturnType = $.$$.S.Void.$type;
                    $i6.MethodName = "set_text_color";
                    return $i6;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, value) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(111670016819)
            
            //--TRIMMABLE-BOUNDARY-START(55835441971)
            /*bool */ get LCFCT$TelegramWebApps$MainButton_Type_0$is_active()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770670899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type;
                    $i7.ReturnType = $.$$.S.Boolean.$type;
                    $i7.MethodName = "get_is_active";
                    return $i7;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*bool */ set LCFCT$TelegramWebApps$MainButton_Type_0$is_active(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310278451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type;
                    $i8.ReturnType = $.$$.S.Void.$type;
                    $i8.MethodName = "set_is_active";
                    return $i8;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(value, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(55835441971)
            
            //--TRIMMABLE-BOUNDARY-START(60130409267)
            /*bool */ get LCFCT$TelegramWebApps$MainButton_Type_0$is_visible()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360605491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t9 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Mock = this;
                    $i9.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type;
                    $i9.ReturnType = $.$$.S.Boolean.$type;
                    $i9.MethodName = "get_is_visible";
                    return $i9;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*bool */ set LCFCT$TelegramWebApps$MainButton_Type_0$is_visible(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900213043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t10 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Mock = this;
                    $i10.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0.$type;
                    $i10.ReturnType = $.$$.S.Void.$type;
                    $i10.MethodName = "set_is_visible";
                    return $i10;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(value, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(60130409267)
            
            static $h = 867123;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107375049523),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540474675,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080082227,
        "f": 83886082
      },
      "n": "{3095347}.text",
      "o": "LCFCT$TelegramWebApps$MainButton_Type_0$text",
      "d": 867123,
      "h": 107375049523,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(107375049523),
//--TRIMMABLE-BOUNDARY-START(8590801715),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180736307,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720343859,
        "f": 83886082
      },
      "n": "{3095347}.color",
      "o": "LCFCT$TelegramWebApps$MainButton_Type_0$color",
      "d": 867123,
      "h": 8590801715,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8590801715),
//--TRIMMABLE-BOUNDARY-START(111670016819),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950540083,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490147635,
        "f": 83886082
      },
      "n": "{3095347}.text_color",
      "o": "LCFCT$TelegramWebApps$MainButton_Type_0$text_color",
      "d": 867123,
      "h": 111670016819,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(111670016819),
//--TRIMMABLE-BOUNDARY-START(55835441971),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770670899,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310278451,
        "f": 83886082
      },
      "n": "{3095347}.is_active",
      "o": "LCFCT$TelegramWebApps$MainButton_Type_0$is_active",
      "d": 867123,
      "h": 55835441971,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(55835441971),
//--TRIMMABLE-BOUNDARY-START(60130409267),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360605491,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900213043,
        "f": 83886082
      },
      "n": "{3095347}.is_visible",
      "o": "LCFCT$TelegramWebApps$MainButton_Type_0$is_visible",
      "d": 867123,
      "h": 60130409267,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60130409267)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295834419),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 867123,
      "h": 4295834419,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295834419)
  ],
  "h": 867123
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.MainButton_Type_0 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.MainButton_Type_0_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}MainButton_Type_0_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(867123)
        
        

        //--TRIMMABLE-BOUNDARY-START(6896435)
        $asm.$cls(`$fycR.LCFCT.WebApp_Mocking`, ($self) => class WebApp_Mocking extends $.$TLYN.LT.TypeScriptMockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4301863731)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301863731);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301863731)
            
            //--TRIMMABLE-BOUNDARY-START(231935130419)
            /*string */ get LCFCT$TelegramWebApps$WebApp$initData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124560948019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i1.ReturnType = $.$$.S.String.$type;
                    $i1.MethodName = "get_initData";
                    return $i1;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(231935130419)
            
            //--TRIMMABLE-BOUNDARY-START(236230097715)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebAppInitData */ get LCFCT$TelegramWebApps$WebApp$initDataUnsafe()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133150882611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i2.ReturnType = $.$fycR.LCFCT.TelegramWebApps.WebAppInitData.$type;
                    $i2.MethodName = "get_initDataUnsafe";
                    return $i2;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.WebAppInitData, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(236230097715)
            
            //--TRIMMABLE-BOUNDARY-START(442388527923)
            /*string */ get LCFCT$TelegramWebApps$WebApp$version()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201870359347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i3.ReturnType = $.$$.S.String.$type;
                    $i3.MethodName = "get_version";
                    return $i3;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(442388527923)
            
            //--TRIMMABLE-BOUNDARY-START(373669051187)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebAppPlatform */ get LCFCT$TelegramWebApps$WebApp$platform()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176100555571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i4.ReturnType = $.$fycR.LCFCT.TelegramWebApps.WebAppPlatform.$type;
                    $i4.MethodName = "get_platform";
                    return $i4;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.WebAppPlatform, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(373669051187)
            
            //--TRIMMABLE-BOUNDARY-START(34366634803)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ColorScheme */ get LCFCT$TelegramWebApps$WebApp$colorScheme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98791144243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i5.ReturnType = $.$fycR.LCFCT.TelegramWebApps.ColorScheme.$type;
                    $i5.MethodName = "get_colorScheme";
                    return $i5;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.ColorScheme, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34366634803)
            
            //--TRIMMABLE-BOUNDARY-START(438093560627)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ThemeParams */ get LCFCT$TelegramWebApps$WebApp$themeParams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193280424755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i6.ReturnType = $.$fycR.LCFCT.TelegramWebApps.ThemeParams.$type;
                    $i6.MethodName = "get_themeParams";
                    return $i6;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.ThemeParams, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(438093560627)
            
            //--TRIMMABLE-BOUNDARY-START(244820032307)
            /*bool */ get LCFCT$TelegramWebApps$WebApp$isExpanded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150330751795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i7.ReturnType = $.$$.S.Boolean.$type;
                    $i7.MethodName = "get_isExpanded";
                    return $i7;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(244820032307)
            
            //--TRIMMABLE-BOUNDARY-START(446683495219)
            /*double */ get LCFCT$TelegramWebApps$WebApp$viewportHeight()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210460293939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i8.ReturnType = $.$$.S.Double.$type;
                    $i8.MethodName = "get_viewportHeight";
                    return $i8;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.Double, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(446683495219)
            
            //--TRIMMABLE-BOUNDARY-START(450978462515)
            /*double */ get LCFCT$TelegramWebApps$WebApp$viewportStableHeight()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219050228531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t9 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Mock = this;
                    $i9.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i9.ReturnType = $.$$.S.Double.$type;
                    $i9.MethodName = "get_viewportStableHeight";
                    return $i9;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.Double, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(450978462515)
            
            //--TRIMMABLE-BOUNDARY-START(227640163123)
            /*string */ get LCFCT$TelegramWebApps$WebApp$headerColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115971013427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t10 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Mock = this;
                    $i10.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i10.ReturnType = $.$$.S.String.$type;
                    $i10.MethodName = "get_headerColor";
                    return $i10;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(227640163123)
            
            //--TRIMMABLE-BOUNDARY-START(12891798323)
            /*string */ get LCFCT$TelegramWebApps$WebApp$backgroundColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73021340467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t11 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i11 = new $t11();
                    $i11.$ctor$2();
                    $i11.Mock = this;
                    $i11.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i11.ReturnType = $.$$.S.String.$type;
                    $i11.MethodName = "get_backgroundColor";
                    return $i11;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.String, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12891798323)
            
            //--TRIMMABLE-BOUNDARY-START(240525065011)
            /*bool */ get LCFCT$TelegramWebApps$WebApp$isClosingConfirmationEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141740817203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t12 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i12 = new $t12();
                    $i12.$ctor$2();
                    $i12.Mock = this;
                    $i12.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i12.ReturnType = $.$$.S.Boolean.$type;
                    $i12.MethodName = "get_isClosingConfirmationEnabled";
                    return $i12;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(240525065011)
            
            //--TRIMMABLE-BOUNDARY-START(8596831027)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BackButton */ get LCFCT$TelegramWebApps$WebApp$BackButton()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64431405875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t13 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i13 = new $t13();
                    $i13.$ctor$2();
                    $i13.Mock = this;
                    $i13.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i13.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BackButton.$type;
                    $i13.MethodName = "get_BackButton";
                    return $i13;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.BackButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8596831027)
            
            //--TRIMMABLE-BOUNDARY-START(257704934195)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.MainButton */ get LCFCT$TelegramWebApps$WebApp$MainButton()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167510620979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t14 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i14 = new $t14();
                    $i14.$ctor$2();
                    $i14.Mock = this;
                    $i14.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i14.ReturnType = $.$fycR.LCFCT.TelegramWebApps.MainButton.$type;
                    $i14.MethodName = "get_MainButton";
                    return $i14;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.MainButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(257704934195)
            
            //--TRIMMABLE-BOUNDARY-START(408028789555)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.SettingsButton */ get LCFCT$TelegramWebApps$WebApp$SettingsButton()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184690490163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t15 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i15 = new $t15();
                    $i15.$ctor$2();
                    $i15.Mock = this;
                    $i15.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i15.ReturnType = $.$fycR.LCFCT.TelegramWebApps.SettingsButton.$type;
                    $i15.MethodName = "get_SettingsButton";
                    return $i15;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.SettingsButton, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(408028789555)
            
            //--TRIMMABLE-BOUNDARY-START(223345195827)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.HapticFeedback */ get LCFCT$TelegramWebApps$WebApp$HapticFeedback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107381078835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t16 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i16 = new $t16();
                    $i16.$ctor$2();
                    $i16.Mock = this;
                    $i16.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i16.ReturnType = $.$fycR.LCFCT.TelegramWebApps.HapticFeedback.$type;
                    $i16.MethodName = "get_HapticFeedback";
                    return $i16;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.HapticFeedback, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(223345195827)
            
            //--TRIMMABLE-BOUNDARY-START(30071667507)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.CloudStorage */ get LCFCT$TelegramWebApps$WebApp$CloudStorage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90201209651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t17 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i17 = new $t17();
                    $i17.$ctor$2();
                    $i17.Mock = this;
                    $i17.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i17.ReturnType = $.$fycR.LCFCT.TelegramWebApps.CloudStorage.$type;
                    $i17.MethodName = "get_CloudStorage";
                    return $i17;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.CloudStorage, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30071667507)
            
            //--TRIMMABLE-BOUNDARY-START(17186765619)
            /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricManager */ get LCFCT$TelegramWebApps$WebApp$BiometricManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81611275059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t18 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i18 = new $t18();
                    $i18.$ctor$2();
                    $i18.Mock = this;
                    $i18.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i18.ReturnType = $.$fycR.LCFCT.TelegramWebApps.BiometricManager.$type;
                    $i18.MethodName = "get_BiometricManager";
                    return $i18;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$fycR.LCFCT.TelegramWebApps.BiometricManager, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17186765619)
            
            //--TRIMMABLE-BOUNDARY-START(253409966899)
            /*bool */ get LCFCT$TelegramWebApps$WebApp$isVerticalSwipesEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158920686387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t19 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i19 = new $t19();
                    $i19.$ctor$2();
                    $i19.Mock = this;
                    $i19.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i19.ReturnType = $.$$.S.Boolean.$type;
                    $i19.MethodName = "get_isVerticalSwipesEnabled";
                    return $i19;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(253409966899)
            
            //--TRIMMABLE-BOUNDARY-START(249114999603)
            /*bool */ LCFCT$TelegramWebApps$WebApp$isVersionAtLeast(/*string*/ version)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249114999603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t20 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i20 = new $t20();
                    $i20.$ctor$2();
                    $i20.Mock = this;
                    $i20.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i20.ReturnType = $.$$.S.Boolean.$type;
                    $i20.MethodName = "isVersionAtLeast";
                    return $i20;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, version) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(249114999603)
            
            //--TRIMMABLE-BOUNDARY-START(403733822259)
            /*void */ LCFCT$TelegramWebApps$WebApp$setHeaderColor(/*string*/ color)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403733822259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t21 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i21 = new $t21();
                    $i21.$ctor$2();
                    $i21.Mock = this;
                    $i21.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i21.ReturnType = $.$$.S.Void.$type;
                    $i21.MethodName = "setHeaderColor";
                    return $i21;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, color) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(403733822259)
            
            //--TRIMMABLE-BOUNDARY-START(399438854963)
            /*void */ LCFCT$TelegramWebApps$WebApp$setBackgroundColor(/*string*/ color)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399438854963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t22 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i22 = new $t22();
                    $i22.$ctor$2();
                    $i22.Mock = this;
                    $i22.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i22.ReturnType = $.$$.S.Void.$type;
                    $i22.MethodName = "setBackgroundColor";
                    return $i22;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, color) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(399438854963)
            
            //--TRIMMABLE-BOUNDARY-START(47251536691)
            /*void */ LCFCT$TelegramWebApps$WebApp$enableClosingConfirmation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47251536691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t23 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i23 = new $t23();
                    $i23.$ctor$2();
                    $i23.Mock = this;
                    $i23.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i23.ReturnType = $.$$.S.Void.$type;
                    $i23.MethodName = "enableClosingConfirmation";
                    return $i23;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(47251536691)
            
            //--TRIMMABLE-BOUNDARY-START(38661602099)
            /*void */ LCFCT$TelegramWebApps$WebApp$disableClosingConfirmation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38661602099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t24 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i24 = new $t24();
                    $i24.$ctor$2();
                    $i24.Mock = this;
                    $i24.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i24.ReturnType = $.$$.S.Void.$type;
                    $i24.MethodName = "disableClosingConfirmation";
                    return $i24;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(38661602099)
            
            //--TRIMMABLE-BOUNDARY-START(296359639859)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ThemeChangedEventType*/ eventType, /*System.Action<LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ThemeChangedEventArg>*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296359639859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t25 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i25 = new $t25();
                    $i25.$ctor$2();
                    $i25.Mock = this;
                    $i25.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i25.ReturnType = $.$$.S.Void.$type;
                    $i25.MethodName = "onEvent";
                    return $i25;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventType.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.ThemeChangedEventArg).$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(296359639859)
            
            //--TRIMMABLE-BOUNDARY-START(300654607155)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$1(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ViewportChangedEventType*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ViewportChangedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300654607155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t26 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i26 = new $t26();
                    $i26.$ctor$2();
                    $i26.Mock = this;
                    $i26.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i26.ReturnType = $.$$.S.Void.$type;
                    $i26.MethodName = "onEvent";
                    return $i26;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.ViewportChangedEventType.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.ViewportChangedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(300654607155)
            
            //--TRIMMABLE-BOUNDARY-START(335014345523)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$9(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_4*/ eventType, /*System.Action*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335014345523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t27 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i27 = new $t27();
                    $i27.$ctor$2();
                    $i27.Mock = this;
                    $i27.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i27.ReturnType = $.$$.S.Void.$type;
                    $i27.MethodName = "onEvent";
                    return $i27;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_4.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(335014345523)
            
            //--TRIMMABLE-BOUNDARY-START(339309312819)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$10(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_5*/ eventType, /*System.Action*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339309312819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t28 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i28 = new $t28();
                    $i28.$ctor$2();
                    $i28.Mock = this;
                    $i28.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i28.ReturnType = $.$$.S.Void.$type;
                    $i28.MethodName = "onEvent";
                    return $i28;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_5.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(339309312819)
            
            //--TRIMMABLE-BOUNDARY-START(343604280115)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$11(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_6*/ eventType, /*System.Action*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343604280115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t29 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i29 = new $t29();
                    $i29.$ctor$2();
                    $i29.Mock = this;
                    $i29.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i29.ReturnType = $.$$.S.Void.$type;
                    $i29.MethodName = "onEvent";
                    return $i29;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_6.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(343604280115)
            
            //--TRIMMABLE-BOUNDARY-START(347899247411)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$12(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_7*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.InvoiceClosedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347899247411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t30 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i30 = new $t30();
                    $i30.$ctor$2();
                    $i30.Mock = this;
                    $i30.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i30.ReturnType = $.$$.S.Void.$type;
                    $i30.MethodName = "onEvent";
                    return $i30;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_7.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.InvoiceClosedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(347899247411)
            
            //--TRIMMABLE-BOUNDARY-START(352194214707)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$13(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_8*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.PopupClosedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352194214707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t31 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i31 = new $t31();
                    $i31.$ctor$2();
                    $i31.Mock = this;
                    $i31.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i31.ReturnType = $.$$.S.Void.$type;
                    $i31.MethodName = "onEvent";
                    return $i31;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_8.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.PopupClosedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(352194214707)
            
            //--TRIMMABLE-BOUNDARY-START(356489182003)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$14(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_9*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.QrTextReceivedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356489182003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t32 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i32 = new $t32();
                    $i32.$ctor$2();
                    $i32.Mock = this;
                    $i32.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i32.ReturnType = $.$$.S.Void.$type;
                    $i32.MethodName = "onEvent";
                    return $i32;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_9.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.QrTextReceivedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(356489182003)
            
            //--TRIMMABLE-BOUNDARY-START(304949574451)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$2(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_10*/ eventType, /*System.Action*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304949574451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t33 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i33 = new $t33();
                    $i33.$ctor$2();
                    $i33.Mock = this;
                    $i33.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i33.ReturnType = $.$$.S.Void.$type;
                    $i33.MethodName = "onEvent";
                    return $i33;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_10.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(304949574451)
            
            //--TRIMMABLE-BOUNDARY-START(309244541747)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$3(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_11*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ClipboardTextReceivedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309244541747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t34 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i34 = new $t34();
                    $i34.$ctor$2();
                    $i34.Mock = this;
                    $i34.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i34.ReturnType = $.$$.S.Void.$type;
                    $i34.MethodName = "onEvent";
                    return $i34;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_11.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.ClipboardTextReceivedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(309244541747)
            
            //--TRIMMABLE-BOUNDARY-START(313539509043)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$4(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_12*/ eventType, /*System.Action<LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_13>*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313539509043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t35 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i35 = new $t35();
                    $i35.$ctor$2();
                    $i35.Mock = this;
                    $i35.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i35.ReturnType = $.$$.S.Void.$type;
                    $i35.MethodName = "onEvent";
                    return $i35;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_12.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_13).$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(313539509043)
            
            //--TRIMMABLE-BOUNDARY-START(317834476339)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$5(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_14*/ eventType, /*System.Action<LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_15>*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317834476339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t36 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i36 = new $t36();
                    $i36.$ctor$2();
                    $i36.Mock = this;
                    $i36.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i36.ReturnType = $.$$.S.Void.$type;
                    $i36.MethodName = "onEvent";
                    return $i36;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_14.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_15).$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(317834476339)
            
            //--TRIMMABLE-BOUNDARY-START(322129443635)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$6(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_16*/ eventType, /*System.Action*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322129443635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t37 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i37 = new $t37();
                    $i37.$ctor$2();
                    $i37.Mock = this;
                    $i37.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i37.ReturnType = $.$$.S.Void.$type;
                    $i37.MethodName = "onEvent";
                    return $i37;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_16.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(322129443635)
            
            //--TRIMMABLE-BOUNDARY-START(326424410931)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$7(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_17*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricAuthRequestedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326424410931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t38 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i38 = new $t38();
                    $i38.$ctor$2();
                    $i38.Mock = this;
                    $i38.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i38.ReturnType = $.$$.S.Void.$type;
                    $i38.MethodName = "onEvent";
                    return $i38;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_17.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.BiometricAuthRequestedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(326424410931)
            
            //--TRIMMABLE-BOUNDARY-START(330719378227)
            /*void */ LCFCT$TelegramWebApps$WebApp$onEvent$8(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_18*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricTokenUpdatedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330719378227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t39 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i39 = new $t39();
                    $i39.$ctor$2();
                    $i39.Mock = this;
                    $i39.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i39.ReturnType = $.$$.S.Void.$type;
                    $i39.MethodName = "onEvent";
                    return $i39;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_18.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.BiometricTokenUpdatedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(330719378227)
            
            //--TRIMMABLE-BOUNDARY-START(261999901491)
            /*void */ LCFCT$TelegramWebApps$WebApp$offEvent(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_19*/ eventType, /*System.Action*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261999901491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t40 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i40 = new $t40();
                    $i40.$ctor$2();
                    $i40.Mock = this;
                    $i40.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i40.ReturnType = $.$$.S.Void.$type;
                    $i40.MethodName = "offEvent";
                    return $i40;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_19.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(261999901491)
            
            //--TRIMMABLE-BOUNDARY-START(266294868787)
            /*void */ LCFCT$TelegramWebApps$WebApp$offEvent$1(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_20*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ViewportChangedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266294868787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t41 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i41 = new $t41();
                    $i41.$ctor$2();
                    $i41.Mock = this;
                    $i41.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i41.ReturnType = $.$$.S.Void.$type;
                    $i41.MethodName = "offEvent";
                    return $i41;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_20.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.ViewportChangedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(266294868787)
            
            //--TRIMMABLE-BOUNDARY-START(270589836083)
            /*void */ LCFCT$TelegramWebApps$WebApp$offEvent$2(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_21*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.InvoiceClosedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270589836083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t42 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i42 = new $t42();
                    $i42.$ctor$2();
                    $i42.Mock = this;
                    $i42.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i42.ReturnType = $.$$.S.Void.$type;
                    $i42.MethodName = "offEvent";
                    return $i42;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_21.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.InvoiceClosedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(270589836083)
            
            //--TRIMMABLE-BOUNDARY-START(274884803379)
            /*void */ LCFCT$TelegramWebApps$WebApp$offEvent$3(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_22*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.PopupClosedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274884803379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t43 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i43 = new $t43();
                    $i43.$ctor$2();
                    $i43.Mock = this;
                    $i43.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i43.ReturnType = $.$$.S.Void.$type;
                    $i43.MethodName = "offEvent";
                    return $i43;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_22.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.PopupClosedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(274884803379)
            
            //--TRIMMABLE-BOUNDARY-START(279179770675)
            /*void */ LCFCT$TelegramWebApps$WebApp$offEvent$4(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_23*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.QrTextReceivedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279179770675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t44 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i44 = new $t44();
                    $i44.$ctor$2();
                    $i44.Mock = this;
                    $i44.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i44.ReturnType = $.$$.S.Void.$type;
                    $i44.MethodName = "offEvent";
                    return $i44;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_23.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.QrTextReceivedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(279179770675)
            
            //--TRIMMABLE-BOUNDARY-START(283474737971)
            /*void */ LCFCT$TelegramWebApps$WebApp$offEvent$5(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_24*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ClipboardTextReceivedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283474737971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t45 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i45 = new $t45();
                    $i45.$ctor$2();
                    $i45.Mock = this;
                    $i45.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i45.ReturnType = $.$$.S.Void.$type;
                    $i45.MethodName = "offEvent";
                    return $i45;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_24.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.ClipboardTextReceivedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(283474737971)
            
            //--TRIMMABLE-BOUNDARY-START(287769705267)
            /*void */ LCFCT$TelegramWebApps$WebApp$offEvent$6(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_25*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricAuthRequestedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287769705267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t46 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i46 = new $t46();
                    $i46.$ctor$2();
                    $i46.Mock = this;
                    $i46.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i46.ReturnType = $.$$.S.Void.$type;
                    $i46.MethodName = "offEvent";
                    return $i46;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_25.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.BiometricAuthRequestedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(287769705267)
            
            //--TRIMMABLE-BOUNDARY-START(292064672563)
            /*void */ LCFCT$TelegramWebApps$WebApp$offEvent$7(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_26*/ eventType, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.BiometricTokenUpdatedEventHandler*/ eventHandler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292064672563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t47 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i47 = new $t47();
                    $i47.$ctor$2();
                    $i47.Mock = this;
                    $i47.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i47.ReturnType = $.$$.S.Void.$type;
                    $i47.MethodName = "offEvent";
                    return $i47;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_26.$type, eventType), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.BiometricTokenUpdatedEventHandler.$type, eventHandler) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(292064672563)
            
            //--TRIMMABLE-BOUNDARY-START(395143887667)
            /*void */ LCFCT$TelegramWebApps$WebApp$sendData(/*string*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395143887667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t48 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i48 = new $t48();
                    $i48.$ctor$2();
                    $i48.Mock = this;
                    $i48.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i48.ReturnType = $.$$.S.Void.$type;
                    $i48.MethodName = "sendData";
                    return $i48;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, data) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(395143887667)
            
            //--TRIMMABLE-BOUNDARY-START(433798593331)
            /*void */ LCFCT$TelegramWebApps$WebApp$switchInlineQuery(/*string*/ query, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_27[]*/ choose_chat_types)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433798593331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t49 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i49 = new $t49();
                    $i49.$ctor$2();
                    $i49.Mock = this;
                    $i49.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i49.ReturnType = $.$$.S.Void.$type;
                    $i49.MethodName = "switchInlineQuery";
                    return $i49;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, query), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_27).$type, choose_chat_types) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(433798593331)
            
            //--TRIMMABLE-BOUNDARY-START(365079116595)
            /*void */ LCFCT$TelegramWebApps$WebApp$openLink(/*string*/ url, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.WebApp_Type_28*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365079116595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t50 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i50 = new $t50();
                    $i50.$ctor$2();
                    $i50.Mock = this;
                    $i50.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i50.ReturnType = $.$$.S.Void.$type;
                    $i50.MethodName = "openLink";
                    return $i50;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, url), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.WebApp_Type_28.$type, options) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(365079116595)
            
            //--TRIMMABLE-BOUNDARY-START(369374083891)
            /*void */ LCFCT$TelegramWebApps$WebApp$openTelegramLink(/*string*/ url)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369374083891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t51 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i51 = new $t51();
                    $i51.$ctor$2();
                    $i51.Mock = this;
                    $i51.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i51.ReturnType = $.$$.S.Void.$type;
                    $i51.MethodName = "openTelegramLink";
                    return $i51;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, url) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(369374083891)
            
            //--TRIMMABLE-BOUNDARY-START(360784149299)
            /*void */ LCFCT$TelegramWebApps$WebApp$openInvoice(/*string*/ url, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.InvoiceClosedEventHandler*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360784149299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t52 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i52 = new $t52();
                    $i52.$ctor$2();
                    $i52.Mock = this;
                    $i52.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i52.ReturnType = $.$$.S.Void.$type;
                    $i52.MethodName = "openInvoice";
                    return $i52;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, url), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.InvoiceClosedEventHandler.$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(360784149299)
            
            //--TRIMMABLE-BOUNDARY-START(412323756851)
            /*void */ LCFCT$TelegramWebApps$WebApp$shareToStory(/*string*/ media_url, /*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.StoryShareParams*/ params)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412323756851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t53 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i53 = new $t53();
                    $i53.$ctor$2();
                    $i53.Mock = this;
                    $i53.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i53.ReturnType = $.$$.S.Void.$type;
                    $i53.MethodName = "shareToStory";
                    return $i53;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, media_url), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.StoryShareParams.$type, params) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(412323756851)
            
            //--TRIMMABLE-BOUNDARY-START(425208658739)
            /*void */ LCFCT$TelegramWebApps$WebApp$showPopup(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.PopupParams*/ params, /*System.Action<string>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425208658739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t54 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i54 = new $t54();
                    $i54.$ctor$2();
                    $i54.Mock = this;
                    $i54.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i54.ReturnType = $.$$.S.Void.$type;
                    $i54.MethodName = "showPopup";
                    return $i54;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.PopupParams.$type, params), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$$.S.String).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(425208658739)
            
            //--TRIMMABLE-BOUNDARY-START(416618724147)
            /*void */ LCFCT$TelegramWebApps$WebApp$showAlert(/*string*/ message, /*System.Action*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416618724147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t55 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i55 = new $t55();
                    $i55.$ctor$2();
                    $i55.Mock = this;
                    $i55.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i55.ReturnType = $.$$.S.Void.$type;
                    $i55.MethodName = "showAlert";
                    return $i55;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, message), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action.$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(416618724147)
            
            //--TRIMMABLE-BOUNDARY-START(420913691443)
            /*void */ LCFCT$TelegramWebApps$WebApp$showConfirm(/*string*/ message, /*System.Action<bool>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420913691443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t56 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i56 = new $t56();
                    $i56.$ctor$2();
                    $i56.Mock = this;
                    $i56.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i56.ReturnType = $.$$.S.Void.$type;
                    $i56.MethodName = "showConfirm";
                    return $i56;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, message), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$$.S.Boolean).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(420913691443)
            
            //--TRIMMABLE-BOUNDARY-START(429503626035)
            /*void */ LCFCT$TelegramWebApps$WebApp$showScanQrPopup(/*LivingThing.Core.Frameworks.Client.TelegramMiniApp.TelegramWebApps.ScanQrPopupParams*/ params, /*System.Func<string, bool>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429503626035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t57 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i57 = new $t57();
                    $i57.$ctor$2();
                    $i57.Mock = this;
                    $i57.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i57.ReturnType = $.$$.S.Void.$type;
                    $i57.MethodName = "showScanQrPopup";
                    return $i57;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fycR.LCFCT.TelegramWebApps.ScanQrPopupParams.$type, params), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(429503626035)
            
            //--TRIMMABLE-BOUNDARY-START(25776700211)
            /*void */ LCFCT$TelegramWebApps$WebApp$closeScanQrPopup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25776700211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t58 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i58 = new $t58();
                    $i58.$ctor$2();
                    $i58.Mock = this;
                    $i58.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i58.ReturnType = $.$$.S.Void.$type;
                    $i58.MethodName = "closeScanQrPopup";
                    return $i58;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25776700211)
            
            //--TRIMMABLE-BOUNDARY-START(377964018483)
            /*void */ LCFCT$TelegramWebApps$WebApp$readTextFromClipboard(/*System.Action<string>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377964018483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t59 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i59 = new $t59();
                    $i59.$ctor$2();
                    $i59.Mock = this;
                    $i59.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i59.ReturnType = $.$$.S.Void.$type;
                    $i59.MethodName = "readTextFromClipboard";
                    return $i59;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$$.S.String).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(377964018483)
            
            //--TRIMMABLE-BOUNDARY-START(390848920371)
            /*void */ LCFCT$TelegramWebApps$WebApp$requestWriteAccess(/*System.Action<bool>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390848920371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t60 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i60 = new $t60();
                    $i60.$ctor$2();
                    $i60.Mock = this;
                    $i60.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i60.ReturnType = $.$$.S.Void.$type;
                    $i60.MethodName = "requestWriteAccess";
                    return $i60;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$$.S.Boolean).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(390848920371)
            
            //--TRIMMABLE-BOUNDARY-START(386553953075)
            /*void */ LCFCT$TelegramWebApps$WebApp$requestContact(/*System.Action<bool>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386553953075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t61 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i61 = new $t61();
                    $i61.$ctor$2();
                    $i61.Mock = this;
                    $i61.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i61.ReturnType = $.$$.S.Void.$type;
                    $i61.MethodName = "requestContact";
                    return $i61;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Action$$($.$$.S.Boolean).$type, callback) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(386553953075)
            
            //--TRIMMABLE-BOUNDARY-START(382258985779)
            /*bool */ LCFCT$TelegramWebApps$WebApp$ready()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382258985779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t62 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i62 = new $t62();
                    $i62.$ctor$2();
                    $i62.Mock = this;
                    $i62.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i62.ReturnType = $.$$.S.Boolean.$type;
                    $i62.MethodName = "ready";
                    return $i62;
                })();
                return this.Invoke($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$$.S.Boolean, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(382258985779)
            
            //--TRIMMABLE-BOUNDARY-START(55841471283)
            /*void */ LCFCT$TelegramWebApps$WebApp$expand()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55841471283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t63 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i63 = new $t63();
                    $i63.$ctor$2();
                    $i63.Mock = this;
                    $i63.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i63.ReturnType = $.$$.S.Void.$type;
                    $i63.MethodName = "expand";
                    return $i63;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(55841471283)
            
            //--TRIMMABLE-BOUNDARY-START(21481732915)
            /*void */ LCFCT$TelegramWebApps$WebApp$close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21481732915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t64 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i64 = new $t64();
                    $i64.$ctor$2();
                    $i64.Mock = this;
                    $i64.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i64.ReturnType = $.$$.S.Void.$type;
                    $i64.MethodName = "close";
                    return $i64;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21481732915)
            
            //--TRIMMABLE-BOUNDARY-START(51546503987)
            /*void */ LCFCT$TelegramWebApps$WebApp$enableVerticalSwipes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51546503987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t65 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i65 = new $t65();
                    $i65.$ctor$2();
                    $i65.Mock = this;
                    $i65.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i65.ReturnType = $.$$.S.Void.$type;
                    $i65.MethodName = "enableVerticalSwipes";
                    return $i65;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(51546503987)
            
            //--TRIMMABLE-BOUNDARY-START(42956569395)
            /*void */ LCFCT$TelegramWebApps$WebApp$disableVerticalSwipes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42956569395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t66 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i66 = new $t66();
                    $i66.$ctor$2();
                    $i66.Mock = this;
                    $i66.DeclaringType = $.$fycR.LCFCT.TelegramWebApps.WebApp.$type;
                    $i66.ReturnType = $.$$.S.Void.$type;
                    $i66.MethodName = "disableVerticalSwipes";
                    return $i66;
                })();
                this.Invoke$1($.$fycR.LCFCT.TelegramWebApps.WebApp, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(42956569395)
            
            static $h = 6896435;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TLYN.LT.TypeScriptMockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(231935130419),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124560948019,
        "f": 50331650
      },
      "n": "{4668211}.initData",
      "o": "LCFCT$TelegramWebApps$WebApp$initData",
      "d": 6896435,
      "h": 231935130419,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(231935130419),
//--TRIMMABLE-BOUNDARY-START(236230097715),
    {
      "p": 6503219,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133150882611,
        "f": 50331650
      },
      "n": "{4668211}.initDataUnsafe",
      "o": "LCFCT$TelegramWebApps$WebApp$initDataUnsafe",
      "d": 6896435,
      "h": 236230097715,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(236230097715),
//--TRIMMABLE-BOUNDARY-START(442388527923),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201870359347,
        "f": 50331650
      },
      "n": "{4668211}.version",
      "o": "LCFCT$TelegramWebApps$WebApp$version",
      "d": 6896435,
      "h": 442388527923,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(442388527923),
//--TRIMMABLE-BOUNDARY-START(373669051187),
    {
      "p": 6634291,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176100555571,
        "f": 50331650
      },
      "n": "{4668211}.platform",
      "o": "LCFCT$TelegramWebApps$WebApp$platform",
      "d": 6896435,
      "h": 373669051187,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(373669051187),
//--TRIMMABLE-BOUNDARY-START(34366634803),
    {
      "p": 2702131,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98791144243,
        "f": 50331650
      },
      "n": "{4668211}.colorScheme",
      "o": "LCFCT$TelegramWebApps$WebApp$colorScheme",
      "d": 6896435,
      "h": 34366634803,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(34366634803),
//--TRIMMABLE-BOUNDARY-START(438093560627),
    {
      "p": 4471603,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193280424755,
        "f": 50331650
      },
      "n": "{4668211}.themeParams",
      "o": "LCFCT$TelegramWebApps$WebApp$themeParams",
      "d": 6896435,
      "h": 438093560627,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(438093560627),
//--TRIMMABLE-BOUNDARY-START(244820032307),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150330751795,
        "f": 50331650
      },
      "n": "{4668211}.isExpanded",
      "o": "LCFCT$TelegramWebApps$WebApp$isExpanded",
      "d": 6896435,
      "h": 244820032307,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(244820032307),
//--TRIMMABLE-BOUNDARY-START(446683495219),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210460293939,
        "f": 50331650
      },
      "n": "{4668211}.viewportHeight",
      "o": "LCFCT$TelegramWebApps$WebApp$viewportHeight",
      "d": 6896435,
      "h": 446683495219,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(446683495219),
//--TRIMMABLE-BOUNDARY-START(450978462515),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219050228531,
        "f": 50331650
      },
      "n": "{4668211}.viewportStableHeight",
      "o": "LCFCT$TelegramWebApps$WebApp$viewportStableHeight",
      "d": 6896435,
      "h": 450978462515,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(450978462515),
//--TRIMMABLE-BOUNDARY-START(227640163123),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115971013427,
        "f": 50331650
      },
      "n": "{4668211}.headerColor",
      "o": "LCFCT$TelegramWebApps$WebApp$headerColor",
      "d": 6896435,
      "h": 227640163123,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(227640163123),
//--TRIMMABLE-BOUNDARY-START(12891798323),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73021340467,
        "f": 50331650
      },
      "n": "{4668211}.backgroundColor",
      "o": "LCFCT$TelegramWebApps$WebApp$backgroundColor",
      "d": 6896435,
      "h": 12891798323,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12891798323),
//--TRIMMABLE-BOUNDARY-START(240525065011),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141740817203,
        "f": 50331650
      },
      "n": "{4668211}.isClosingConfirmationEnabled",
      "o": "LCFCT$TelegramWebApps$WebApp$isClosingConfirmationEnabled",
      "d": 6896435,
      "h": 240525065011,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(240525065011),
//--TRIMMABLE-BOUNDARY-START(8596831027),
    {
      "p": 2112307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64431405875,
        "f": 50331650
      },
      "n": "{4668211}.BackButton",
      "o": "LCFCT$TelegramWebApps$WebApp$BackButton",
      "d": 6896435,
      "h": 8596831027,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8596831027),
//--TRIMMABLE-BOUNDARY-START(257704934195),
    {
      "p": 3029811,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167510620979,
        "f": 50331650
      },
      "n": "{4668211}.MainButton",
      "o": "LCFCT$TelegramWebApps$WebApp$MainButton",
      "d": 6896435,
      "h": 257704934195,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(257704934195),
//--TRIMMABLE-BOUNDARY-START(408028789555),
    {
      "p": 3488563,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184690490163,
        "f": 50331650
      },
      "n": "{4668211}.SettingsButton",
      "o": "LCFCT$TelegramWebApps$WebApp$SettingsButton",
      "d": 6896435,
      "h": 408028789555,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(408028789555),
//--TRIMMABLE-BOUNDARY-START(223345195827),
    {
      "p": 2767667,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107381078835,
        "f": 50331650
      },
      "n": "{4668211}.HapticFeedback",
      "o": "LCFCT$TelegramWebApps$WebApp$HapticFeedback",
      "d": 6896435,
      "h": 223345195827,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(223345195827),
//--TRIMMABLE-BOUNDARY-START(30071667507),
    {
      "p": 2636595,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90201209651,
        "f": 50331650
      },
      "n": "{4668211}.CloudStorage",
      "o": "LCFCT$TelegramWebApps$WebApp$CloudStorage",
      "d": 6896435,
      "h": 30071667507,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30071667507),
//--TRIMMABLE-BOUNDARY-START(17186765619),
    {
      "p": 2308915,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81611275059,
        "f": 50331650
      },
      "n": "{4668211}.BiometricManager",
      "o": "LCFCT$TelegramWebApps$WebApp$BiometricManager",
      "d": 6896435,
      "h": 17186765619,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17186765619),
//--TRIMMABLE-BOUNDARY-START(253409966899),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158920686387,
        "f": 50331650
      },
      "n": "{4668211}.isVerticalSwipesEnabled",
      "o": "LCFCT$TelegramWebApps$WebApp$isVerticalSwipesEnabled",
      "d": 6896435,
      "h": 253409966899,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(253409966899)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301863731),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 6896435,
      "h": 4301863731,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4301863731)
  ],
  "h": 6896435
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$fycR.LCFCT.TelegramWebApps.WebApp ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Client.TelegramMiniApp.WebApp_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Client${separator}TelegramMiniApp${separator}WebApp_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6896435)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(15155)
