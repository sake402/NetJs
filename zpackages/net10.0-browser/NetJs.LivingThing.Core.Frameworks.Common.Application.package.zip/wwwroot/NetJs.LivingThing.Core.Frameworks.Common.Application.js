
//--TRIMMABLE-BOUNDARY-START(40416)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU) {
    "use strict";
    let _;
    let $RsBJua;
    let $bcgead;
    let $eolTzg;
    let $EGfNOb;
    let $JGPMZf;
    let $WiMnij;
    let $BTzpqf;
    let $zhTFck;
    let $MRMuQh;
    let $mMlRrc;
    let $OMGQlb;
    let $UkSzEk;
    let $oDukQe;
    let $kFaWrf;
    let $XfdZba;
    let $WQoYJk;
    let $ygZYDe;
    let $MTmUve;
    let $dmhAee;
    let $ohyeTd;
    let $PYeVmk;
    let $AAOyLd;
    let $wwsAoc;
    let $sQRpYh;
    let $btkftk;
    let $miQXdj;
    let $aISYWk;
    let $RZhfGb;
    let $YjMMtd;
    let $ByZmMe;
    let $EvZMtd;
    let $RMADGb;
    let $rrLpdi;
    let $ksPAWc;
    let $cCsPQb;
    let $YEOGng;
    let $hodGIa;
    let $BqItQf;
    let $aJLUci;
    let $qhMMck;
    let $LkYrTi;
    let $XEKuEi;
    let $yuZtke;
    let $SBvYib;
    let $ZELNVg;
    let $sCdgZi;
    let $FGAcJg;
    let $Pptmwa;
    let $EWkcdl;
    let $VIjvub;
    let $bEjInf;
    let $VMBIFh;
    let $hrKlhe;
    let $CGzXbj;
    let $RGmQRk;
    let $pagKHj;
    let $FqWgPi;
    let $bHDYmj;
    let $FWqMXc;
    let $ROJWEd;
    let $rjAUYg;
    let $jbNHcd;
    let $aJvlvb;
    let $EvNzuj;
    let $kgGZFf;
    let $uKAvdk;
    let $jdCrvd;
    let $erhDoc;
    let $Aznlck;
    let $REQAqf;
    let $oConnf;
    let $YLYYoe;
    let $ozqMki;
    let $wsHpBe;
    let $oUSTXi;
    let $wtRvXb;
    let $BSDBpc;
    let $JoFHac;
    let $xGicef;
    let $RNVSdg;
    let $xPSOge;
    let $UsKHZb;
    let $CnpVha;
    let $nLscPd;
    let $mzOLUe;
    let $yFpMTi;
    let $FYaFVg;
    let $CmEMLh;
    let $leZJyh;
    let $jvoWyf;
    let $SGnGsb;
    let $mbuPPj;
    let $Oyxeej;
    let $JzEmnb;
    let $yNRJgg;
    let $JLoZGc;
    let $vfPCrj;
    let $oneije;
    let $PVWYPh;
    let $HcBANb;
    let $vSQfkd;
    let $uIUUSg;
    let $WwFaJd;
    let $qHFsJi;
    let $vhUMfi;
    let $eAjgna;
    let $asEuNk;
    let $RkiNtj;
    let $bQBNOa;
    let $XMWvbb;
    let $TrzzLe;
    let $hWbHza;
    let $zDuhlg;
    let $jIHCMd;
    let $NQQWzh;
    let $VfWWck;
    let $MxeUrd;
    let $DFKRak;
    let $ICegTk;
    let $Xoogmd;
    let $emKDIa;
    let $tqzxCi;
    let $SwQwId;
    let $xlUwuc;
    let $qMznPd;
    let $mraONb;
    let $IslkXb;
    let $IhalHe;
    let $dZpSMd;
    let $SpEata;
    let $Uucvhk;
    let $Makeic;
    let $mQancd;
    let $QKgzfg;
    let $ZCvVqa;
    let $ISYSpa;
    let $nQdThf;
    let $NyJxti;
    let $MqRSte;
    let $dTqflf;
    let $vouPjc;
    let $kORCxk;
    let $AjjIJd;
    let $mHlprc;
    let $gyArta;
    let $kBfbPk;
    let $xHckec;
    let $hDWdHc;
    let $DdlmTg;
    let $IrzKNa;
    let $PJLvwd;
    let $PVXScd;
    let $XQtmYk;
    let $bvpOkg;
    let $iYoYcb;
    let $SBsqYc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Application", 
    {
  "h": 40416,
  "f": "LivingThing.Core.Frameworks.Common.Application",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Application",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Application",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2137568)
        $asm.$cls(`$yleQ.LCFCA.IApplicationServiceModuleProvider`, ($self) => class IApplicationServiceModuleProvider
        {
            static $h = 2137568;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887039456),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592072160,
        "f": 50331905
      },
      "n": "ServiceModules",
      "o": "LCFCA$IApplicationServiceModuleProvider$ServiceModules",
      "d": 2137568,
      "h": 12887039456,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12887039456)
  ],
  "h": 2137568
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationServiceModuleProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationServiceModuleProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2137568)
        
        

        //--TRIMMABLE-BOUNDARY-START(1678816)
        $asm.$cls(`$yleQ.LCFCA.IApplicationRootEntryProvider`, ($self) => class IApplicationRootEntryProvider
        {
            static $h = 1678816;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656384480),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361417184,
        "f": 50331905
      },
      "n": "SplashScreen",
      "o": "LCFCA$IApplicationRootEntryProvider$SplashScreen",
      "d": 1678816,
      "h": 38656384480,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38656384480),
//--TRIMMABLE-BOUNDARY-START(4296646112),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181548000,
        "f": 50331905
      },
      "n": "AppEntryType",
      "o": "LCFCA$IApplicationRootEntryProvider$AppEntryType",
      "d": 1678816,
      "h": 4296646112,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296646112),
//--TRIMMABLE-BOUNDARY-START(8591613408),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SR.Assembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771482592,
        "f": 50331905
      },
      "n": "ApplicationAssemblies",
      "o": "LCFCA$IApplicationRootEntryProvider$ApplicationAssemblies",
      "d": 1678816,
      "h": 8591613408,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591613408)
  ],
  "h": 1678816
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationRootEntryProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationRootEntryProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1678816)
        
        

        //--TRIMMABLE-BOUNDARY-START(2072032)
        $asm.$cls(`$yleQ.LCFCA.IApplicationServiceHasYoutubeHelps`, ($self) => class IApplicationServiceHasYoutubeHelps
        {
            static $h = 2072032;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886973920),
    {
      "p": 20981078,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592006624,
        "f": 50331905
      },
      "n": "YoutubeSettings",
      "o": "LCFCA$IApplicationServiceHasYoutubeHelps$YoutubeSettings",
      "d": 2072032,
      "h": 12886973920,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886973920)
  ],
  "h": 2072032
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationServiceHasYoutubeHelps`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationServiceHasYoutubeHelps`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2072032)
        
        

        //--TRIMMABLE-BOUNDARY-START(1547744)
        $asm.$cls(`$yleQ.LCFCA.IApplicationRemoteService`, ($self) => class IApplicationRemoteService
        {
            static $h = 1547744;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591482336),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.String)).$h,
      "p": [
        {
          "n": "moduleName",
          "p": 1310721
        },
        {
          "n": "callerRuntime",
          "p": 57575766
        }
      ],
      "n": "GetDependencies",
      "o": "LCFCA$IApplicationRemoteService$GetDependencies",
      "d": 1547744,
      "h": 8591482336,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591482336),
//--TRIMMABLE-BOUNDARY-START(4296515040),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$yleQ.LCFCA.ApplicationsDescriptor)).$h,
      "p": [
        {
          "n": "callerRuntime",
          "p": 57575766
        },
        {
          "n": "optimizedForSpecificApplications",
          "p": 262145
        },
        {
          "n": "filterToApps",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "GetApplicationsDescriptor",
      "o": "LCFCA$IApplicationRemoteService$GetApplicationsDescriptor",
      "d": 1547744,
      "h": 4296515040,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296515040)
  ],
  "h": 1547744,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1547744)
        
        

        //--TRIMMABLE-BOUNDARY-START(1744352)
        $asm.$cls(`$yleQ.LCFCA.IApplicationRootService`, ($self) => class IApplicationRootService
        {
            //--TRIMMABLE-BOUNDARY-START(21476580832)
            /*ClientUserPreference */ get LCFCC$IClientRootService$Preferences()
            {
                return this.LCFCA$IApplicationRootService$Preferences;
            }
            //--TRIMMABLE-BOUNDARY-END(21476580832)
            
            static $h = 1744352;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771548128),
    {
      "p": 105952,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591678944,
        "f": 50331905
      },
      "n": "Preferences",
      "o": "LCFCA$IApplicationRootService$Preferences",
      "d": 1744352,
      "h": 25771548128,
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(25771548128),
//--TRIMMABLE-BOUNDARY-START(21476580832),
    {
      "p": 941480,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181613536,
        "f": 50331650
      },
      "n": "{2645416}.Preferences",
      "o": "LCFCC$IClientRootService$Preferences",
      "d": 1744352,
      "h": 21476580832,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21476580832)
  ],
  "h": 1744352
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationRootService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationRootService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1744352)
        
        

        //--TRIMMABLE-BOUNDARY-START(1809888)
        $asm.$cls(`$yleQ.LCFCA.IApplicationService`, ($self) => class IApplicationService
        {
            static $h = 1809888;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296777184),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886711776,
        "f": 50331905
      },
      "n": "Features",
      "o": "LCFCA$IApplicationService$Features",
      "d": 1809888,
      "h": 4296777184,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296777184)
  ],
  "h": 1809888
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1809888)
        
        

        //--TRIMMABLE-BOUNDARY-START(2006496)
        $asm.$cls(`$yleQ.LCFCA.IApplicationServiceHasUrlShare`, ($self) => class IApplicationServiceHasUrlShare
        {
            static $h = 2006496;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886908384),
    {
      "p": $.$fPer.LCFCR.ReactiveObservable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591941088,
        "f": 50331905
      },
      "n": "ShareUrl",
      "o": "LCFCA$IApplicationServiceHasUrlShare$ShareUrl",
      "d": 2006496,
      "h": 12886908384,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886908384)
  ],
  "h": 2006496
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationServiceHasUrlShare`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationServiceHasUrlShare`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2006496)
        
        

        //--TRIMMABLE-BOUNDARY-START(1875424)
        $asm.$cls(`$yleQ.LCFCA.IApplicationServiceHasPreference`, ($self) => class IApplicationServiceHasPreference
        {
            static $h = 1875424;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771679200),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591810016,
        "f": 50331905
      },
      "n": "UserPreferenceType",
      "o": "LCFCA$IApplicationServiceHasPreference$UserPreferenceType",
      "d": 1875424,
      "h": 25771679200,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25771679200)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886777312),
    {
      "r": $.$$.STT.ValueTask$$($.$yleQ.LCFCA.ApplicationBaseUserPreference).$h,
      "n": "GetUserPreference",
      "o": "LCFCA$IApplicationServiceHasPreference$GetUserPreference",
      "d": 1875424,
      "h": 12886777312,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886777312),
//--TRIMMABLE-BOUNDARY-START(17181744608),
    {
      "r": 181338113,
      "n": "ResetUserPreference",
      "o": "LCFCA$IApplicationServiceHasPreference$ResetUserPreference",
      "d": 1875424,
      "h": 17181744608,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181744608),
//--TRIMMABLE-BOUNDARY-START(21476711904),
    {
      "r": 181338113,
      "n": "UpdateUserPreference",
      "o": "LCFCA$IApplicationServiceHasPreference$UpdateUserPreference",
      "d": 1875424,
      "h": 21476711904,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476711904)
  ],
  "h": 1875424
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationServiceHasPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationServiceHasPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1875424)
        
        

        //--TRIMMABLE-BOUNDARY-START(1940960)
        $asm.$cls(`$yleQ.LCFCA.IApplicationServiceHasPreference<>`, (TUserPreference) => $asm.$gt(`$yleQ.LCFCA.IApplicationServiceHasPreference<>`, [TUserPreference], ($self) => class IApplicationServiceHasPreference$$
        {
            static $H = 1940960;
            static $h = 1940960;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181810144),
    {
      "p": TUserPreference?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 8591875552,
        "h": Number(BigInt(this.$h)|0x200000000n),
        "f": 50331905
      },
      "n": "UserPreference",
      "o": "LCFCA$IApplicationServiceHasPreference$$$UserPreference",
      "d": this.$h,
      "H": 17181810144,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17181810144)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886842848),
    {
      "r": 181338113,
      "p": [
        {
          "n": "preference",
          "p": TUserPreference?.$h??1572864
        }
      ],
      "n": "SaveUserPreference",
      "o": "LCFCA$IApplicationServiceHasPreference$$$SaveUserPreference",
      "d": this.$h,
      "H": 12886842848,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886842848)
  ],
  "s": [
    {
      "h": TUserPreference?.$h??1572864,
      "n": "TUserPreference",
      "c": [105952
      ]
    }
  ],
  "r": 1,
  "H": 1940960,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationServiceHasPreference, $.$yleQ.LCFCA.IApplicationService, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationServiceHasPreference<${TUserPreference?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationServiceHasPreference$${TUserPreference?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1940960)
        
        

        //--TRIMMABLE-BOUNDARY-START(1482208)
        $asm.$cls(`$yleQ.LCFCA.IApplicationProxy`, ($self) => class IApplicationProxy
        {
            static $h = 1482208;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296449504),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181351392,
        "f": 50331905
      },
      "n": "Domains",
      "o": "LCFCA$IApplicationProxy$Domains",
      "d": 1482208,
      "h": 4296449504,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296449504),
//--TRIMMABLE-BOUNDARY-START(55836057056),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361220576,
        "f": 50331905
      },
      "n": "Paths",
      "o": "LCFCA$IApplicationProxy$Paths",
      "d": 1482208,
      "h": 55836057056,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(55836057056),
//--TRIMMABLE-BOUNDARY-START(8591416800),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771285984,
        "f": 50331905
      },
      "n": "Features",
      "o": "LCFCA$IApplicationProxy$Features",
      "d": 1482208,
      "h": 8591416800,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591416800),
//--TRIMMABLE-BOUNDARY-START(64425991648),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541089760,
        "f": 50331905
      },
      "n": "ServiceType",
      "o": "LCFCA$IApplicationProxy$ServiceType",
      "d": 1482208,
      "h": 64425991648,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64425991648),
//--TRIMMABLE-BOUNDARY-START(60131024352),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951155168,
        "f": 50331905
      },
      "n": "Services",
      "o": "LCFCA$IApplicationProxy$Services",
      "d": 1482208,
      "h": 60131024352,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60131024352)
  ],
  "h": 1482208
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationProxy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationProxy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1482208)
        
        

        //--TRIMMABLE-BOUNDARY-START(2203104)
        $asm.$cls(`$yleQ.LCFCA.IApplicationServiceProxy`, ($self) => class IApplicationServiceProxy
        {
            static $h = 2203104;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85901549024),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246843360,
        "f": 50331905
      },
      "n": "Id",
      "o": "LCFCA$IApplicationServiceProxy$Id",
      "d": 2203104,
      "h": 85901549024,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(85901549024),
//--TRIMMABLE-BOUNDARY-START(90196516320),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836777952,
        "f": 50331905
      },
      "n": "MainAssemblies",
      "o": "LCFCA$IApplicationServiceProxy$MainAssemblies",
      "d": 2203104,
      "h": 90196516320,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90196516320),
//--TRIMMABLE-BOUNDARY-START(8592137696),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066974176,
        "f": 50331905
      },
      "n": "Dependencies",
      "o": "LCFCA$IApplicationServiceProxy$Dependencies",
      "d": 2203104,
      "h": 8592137696,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8592137696),
//--TRIMMABLE-BOUNDARY-START(98786450912),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016647136,
        "f": 50331905
      },
      "n": "Type",
      "o": "LCFCA$IApplicationServiceProxy$Type",
      "d": 2203104,
      "h": 98786450912,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98786450912),
//--TRIMMABLE-BOUNDARY-START(103081418208),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606581728,
        "f": 50331905
      },
      "n": "UIEntryType",
      "o": "LCFCA$IApplicationServiceProxy$UIEntryType",
      "d": 2203104,
      "h": 103081418208,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103081418208),
//--TRIMMABLE-BOUNDARY-START(4297170400),
    {
      "p": 1482208,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477039584,
        "f": 50331905
      },
      "n": "Application",
      "o": "LCFCA$IApplicationServiceProxy$Application",
      "d": 2203104,
      "h": 4297170400,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4297170400),
//--TRIMMABLE-BOUNDARY-START(12887104992),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656908768,
        "f": 50331905
      },
      "n": "Features",
      "o": "LCFCA$IApplicationServiceProxy$Features",
      "d": 2203104,
      "h": 12887104992,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12887104992),
//--TRIMMABLE-BOUNDARY-START(94491483616),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426712544,
        "f": 50331905
      },
      "n": "Paths",
      "o": "LCFCA$IApplicationServiceProxy$Paths",
      "d": 2203104,
      "h": 94491483616,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94491483616)
  ],
  "h": 2203104
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationServiceProxy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2203104)
        
        

        //--TRIMMABLE-BOUNDARY-START(2334176)
        $asm.$cls(`$yleQ.LCFCA.ICreatorApplicationProxy`, ($self) => class ICreatorApplicationProxy
        {
            static $h = 2334176;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592268768),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772137952,
        "f": 50331905
      },
      "n": "CreateLink",
      "o": "LCFCA$ICreatorApplicationProxy$CreateLink",
      "d": 2334176,
      "h": 8592268768,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8592268768),
//--TRIMMABLE-BOUNDARY-START(4297301472),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182203360,
        "f": 50331905
      },
      "n": "CreateLabel",
      "o": "LCFCA$ICreatorApplicationProxy$CreateLabel",
      "d": 2334176,
      "h": 4297301472,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4297301472)
  ],
  "h": 2334176
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ICreatorApplicationProxy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ICreatorApplicationProxy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2334176)
        
        

        //--TRIMMABLE-BOUNDARY-START(2268640)
        $asm.$cls(`$yleQ.LCFCA.IApplicationSubService`, ($self) => class IApplicationSubService
        {
            //--TRIMMABLE-BOUNDARY-START(60131810784)
            /*IEnumerable<ApplicationAssembly>? */ get LCFCA$IApplicationServiceProxy$MainAssemblies()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(60131810784)
            
            //--TRIMMABLE-BOUNDARY-START(21477105120)
            /*IEnumerable<ApplicationAssembly>? */ get LCFCA$IApplicationServiceProxy$Dependencies()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21477105120)
            
            //--TRIMMABLE-BOUNDARY-START(64426778080)
            /*string? */ get LCFCA$IApplicationServiceProxy$UIEntryType()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(64426778080)
            
            //--TRIMMABLE-BOUNDARY-START(17182137824)
            /*IApplicationProxy? */ get LCFCA$IApplicationServiceProxy$Application()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(17182137824)
            
            //--TRIMMABLE-BOUNDARY-START(4297235936)
            /*Type? */ get LCFCA$IApplicationSubService$ApplicationViewType()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4297235936)
            
            static $h = 2268640;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131810784),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246908896,
        "f": 50331650
      },
      "n": "{2203104}.MainAssemblies",
      "o": "LCFCA$IApplicationServiceProxy$MainAssemblies",
      "d": 2268640,
      "h": 60131810784,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60131810784),
//--TRIMMABLE-BOUNDARY-START(21477105120),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656974304,
        "f": 50331650
      },
      "n": "{2203104}.Dependencies",
      "o": "LCFCA$IApplicationServiceProxy$Dependencies",
      "d": 2268640,
      "h": 21477105120,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21477105120),
//--TRIMMABLE-BOUNDARY-START(64426778080),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836843488,
        "f": 50331650
      },
      "n": "{2203104}.UIEntryType",
      "o": "LCFCA$IApplicationServiceProxy$UIEntryType",
      "d": 2268640,
      "h": 64426778080,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64426778080),
//--TRIMMABLE-BOUNDARY-START(17182137824),
    {
      "p": 1482208,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067039712,
        "f": 50331650
      },
      "n": "{2203104}.Application",
      "o": "LCFCA$IApplicationServiceProxy$Application",
      "d": 2268640,
      "h": 17182137824,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17182137824),
//--TRIMMABLE-BOUNDARY-START(4297235936),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887170528,
        "f": 50331777
      },
      "n": "ApplicationViewType",
      "o": "LCFCA$IApplicationSubService$ApplicationViewType",
      "d": 2268640,
      "h": 4297235936,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(4297235936)
  ],
  "h": 2268640
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationSubService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationSubService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2268640)
        
        

        //--TRIMMABLE-BOUNDARY-START(2727392)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestIcon`, ($self) => class ApplicationManifestIcon extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81607106016)
            /*string*/ Source = null;
            //--TRIMMABLE-BOUNDARY-END(81607106016)
            
            //--TRIMMABLE-BOUNDARY-START(77312138720)
            /*string*/ Sizes = null;
            //--TRIMMABLE-BOUNDARY-END(77312138720)
            
            //--TRIMMABLE-BOUNDARY-START(47247367648)
            /*string*/ MimeType = null;
            //--TRIMMABLE-BOUNDARY-END(47247367648)
            
            //--TRIMMABLE-BOUNDARY-START(17182596576)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182596576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182596576)
            
            //--TRIMMABLE-BOUNDARY-START(17182596576)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17182596576)
            
            static $h = 2727392;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81607106016),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952400352,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017171424,
        "f": 83886081
      },
      "n": "Source",
      "d": 2727392,
      "h": 81607106016,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "src",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81607106016),
//--TRIMMABLE-BOUNDARY-START(77312138720),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362465760,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427236832,
        "f": 83886081
      },
      "n": "Sizes",
      "d": 2727392,
      "h": 77312138720,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312138720),
//--TRIMMABLE-BOUNDARY-START(47247367648),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772531168,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837302240,
        "f": 83886081
      },
      "n": "MimeType",
      "d": 2727392,
      "h": 47247367648,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "type",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247367648)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182596576),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2727392,
      "h": 17182596576,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182596576)
  ],
  "h": 2727392,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    },
    {
      "t": 44665174,
      "c": 4339632470
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIcon`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestIcon`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2727392)
        
        

        //--TRIMMABLE-BOUNDARY-START(2989536)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestScreenShot`, ($self) => class ApplicationManifestScreenShot extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(107377171936)
            /*string*/ Source = null;
            //--TRIMMABLE-BOUNDARY-END(107377171936)
            
            //--TRIMMABLE-BOUNDARY-START(103082204640)
            /*string*/ Sizes = null;
            //--TRIMMABLE-BOUNDARY-END(103082204640)
            
            //--TRIMMABLE-BOUNDARY-START(64427498976)
            /*string*/ MimeType = null;
            //--TRIMMABLE-BOUNDARY-END(64427498976)
            
            //--TRIMMABLE-BOUNDARY-START(25772793312)
            /*string*/ FormFactor = null;
            //--TRIMMABLE-BOUNDARY-END(25772793312)
            
            //--TRIMMABLE-BOUNDARY-START(21477826016)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477826016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477826016)
            
            //--TRIMMABLE-BOUNDARY-START(21477826016)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21477826016)
            
            static $h = 2989536;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107377171936),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132531680,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98787237344,
        "f": 83886081
      },
      "n": "Source",
      "d": 2989536,
      "h": 107377171936,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "src",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107377171936),
//--TRIMMABLE-BOUNDARY-START(103082204640),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542597088,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90197302752,
        "f": 83886081
      },
      "n": "Sizes",
      "d": 2989536,
      "h": 103082204640,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "sizes",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103082204640),
//--TRIMMABLE-BOUNDARY-START(64427498976),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952662496,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607368160,
        "f": 83886081
      },
      "n": "MimeType",
      "d": 2989536,
      "h": 64427498976,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "type",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427498976),
//--TRIMMABLE-BOUNDARY-START(25772793312),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362727904,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017433568,
        "f": 83886081
      },
      "n": "FormFactor",
      "d": 2989536,
      "h": 25772793312,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "form_factor",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772793312)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477826016),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2989536,
      "h": 21477826016,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477826016)
  ],
  "h": 2989536,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    },
    {
      "t": 44665174,
      "c": 4339632470
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShot`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestScreenShot`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2989536)
        
        

        //--TRIMMABLE-BOUNDARY-START(2530784)
        $asm.$cls(`$yleQ.LCFCA.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297498080)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297498080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptorBuilder.Register();
                $.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptorBuilder.Register();
                $.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptorBuilder.Register();
                $.$yleQ.LCFCP.ApplicationManifestTypeDescriptorBuilder.Register();
                $.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptorBuilder.Register();
                $.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptorBuilder.Register();
                $.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297498080)
            
            static $h = 2530784;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297498080),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2530784,
      "h": 4297498080,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297498080)
  ],
  "h": 2530784
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2530784)
        
        

        //--TRIMMABLE-BOUNDARY-START(1351136)
        $asm.$cls(`$yleQ.LCFCA.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296318432)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296318432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yleQ.LCFCA.ApplicationBaseUserPreference.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yleQ.LCFCA.ApplicationBaseUserPreferenceCustomAttributesProvider, $.$yleQ.LCFCA.ApplicationBaseUserPreferenceCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yleQ.LCFCP.ApplicationManifestIcon.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yleQ.LCFCP.ApplicationManifestIconCustomAttributesProvider, $.$yleQ.LCFCP.ApplicationManifestIconCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yleQ.LCFCP.ApplicationManifest.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yleQ.LCFCP.ApplicationManifestCustomAttributesProvider, $.$yleQ.LCFCP.ApplicationManifestCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yleQ.LCFCP.ApplicationManifestScreenShot.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yleQ.LCFCP.ApplicationManifestScreenShotCustomAttributesProvider, $.$yleQ.LCFCP.ApplicationManifestScreenShotCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$yleQ.LCFCA.ApplicationServiceFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$yleQ.LCFCA.ApplicationServiceFeaturesCustomAttributesProvider, $.$yleQ.LCFCA.ApplicationServiceFeaturesCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4296318432)
            
            static $h = 1351136;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296318432),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 1351136,
      "h": 4296318432,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296318432)
  ],
  "h": 1351136
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1351136)
        
        

        //--TRIMMABLE-BOUNDARY-START(1220064)
        $asm.$cls(`$yleQ.LCFCA.ApplicationUtility`, ($self) => class ApplicationUtility
        {
            //--TRIMMABLE-BOUNDARY-START(25771023840)
            /*RuntimeType*/ static RuntimeType = 0;
            //--TRIMMABLE-BOUNDARY-END(25771023840)
            
            //--TRIMMABLE-BOUNDARY-START(17181089248)
            static /*Stringy */ GetApplicationNameFromSubdomain(/*this string*/ authority)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181089248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let auth = $.$fPer.LCFC.DomainAuthority.Parse(authority);
                /*var*/ let subdomain = auth.SubDomainName;
                return subdomain;
            }
            //--TRIMMABLE-BOUNDARY-END(17181089248)
            
            //--TRIMMABLE-BOUNDARY-START(21476056544)
            static /*string? */ GetDisplayName(/*this Type*/ type, /*IApplicationProxy?*/ app, /*bool*/ pluralize, /*bool*/ readable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476056544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let name = null;
                /*var*/ let attribute = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributeFast$5($.$sca.SCD.DisplayAttribute, type, null, false, true);
                if ((attribute?.Name ?? null) !== null)
                {
                    name = attribute.Name;
                }
                else 
                {
                    /*var*/ let schema = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributeFast$5($.$fPer.LCFCA$1.SchemaAttribute, type, null, false, true);
                    if (!readable && (schema?.Key ?? null) !== null)
                    {
                        name = schema.Key;
                    }
                    else if (readable && (schema?.Title ?? null) !== null)
                    {
                        name = schema.Title;
                    }
                    else 
                    {
                        name = $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call(type.Name, "Community", ""), "Post", ""), "Model", "");
                        if (app !== null)
                        {
                            if (name !== app.LCFC$INamed$Name)
                            {
                                name = $.$$.S.String.Replace$3.call(name, app.LCFC$INamed$Name, "");
                            }
                        }
                    }
                }
                if (pluralize)
                {
                    name = $.$fPer.LCFCS$6.StringExtension.Pluralize(name);
                }
                if (readable)
                {
                    name = $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle(name);
                }
                return name;
            }
            //--TRIMMABLE-BOUNDARY-END(21476056544)
            
            static $h = 1220064;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771023840),
    {
      "p": 57575766,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886121952,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360958432,
        "f": 83886120
      },
      "n": "RuntimeType",
      "d": 1220064,
      "h": 25771023840,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25771023840)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181089248),
    {
      "r": 64915798,
      "p": [
        {
          "n": "authority",
          "p": 1310721
        }
      ],
      "n": "GetApplicationNameFromSubdomain",
      "d": 1220064,
      "h": 17181089248,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181089248),
//--TRIMMABLE-BOUNDARY-START(21476056544),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "app",
          "p": 1482208,
          "f": 65
        },
        {
          "n": "pluralize",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "readable",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "GetDisplayName",
      "d": 1220064,
      "h": 21476056544,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476056544)
  ],
  "h": 1220064
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1220064)
        
        

        //--TRIMMABLE-BOUNDARY-START(1416672)
        $asm.$cls(`$yleQ.LCFCA.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296383968)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296383968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4296383968)
            
            static $h = 1416672;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296383968),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 1416672,
      "h": 4296383968,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296383968)
  ],
  "h": 1416672
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1416672)
        
        

        //--TRIMMABLE-BOUNDARY-START(2596320)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifest`, ($self) => class ApplicationManifest extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(197571091936)
            /*string?*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(197571091936)
            
            //--TRIMMABLE-BOUNDARY-START(206161026528)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(206161026528)
            
            //--TRIMMABLE-BOUNDARY-START(330715078112)
            /*string?*/ ShortName = null;
            //--TRIMMABLE-BOUNDARY-END(330715078112)
            
            //--TRIMMABLE-BOUNDARY-START(73017040352)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(73017040352)
            
            //--TRIMMABLE-BOUNDARY-START(335010045408)
            /*string*/ StartUrl = null;
            //--TRIMMABLE-BOUNDARY-END(335010045408)
            
            //--TRIMMABLE-BOUNDARY-START(77312007648)
            /*string*/ Display = null;
            //--TRIMMABLE-BOUNDARY-END(77312007648)
            
            //--TRIMMABLE-BOUNDARY-START(64427105760)
            /*string?*/ BackgroundColor = null;
            //--TRIMMABLE-BOUNDARY-END(64427105760)
            
            //--TRIMMABLE-BOUNDARY-START(339305012704)
            /*string?*/ ThemeColor = null;
            //--TRIMMABLE-BOUNDARY-END(339305012704)
            
            //--TRIMMABLE-BOUNDARY-START(210455993824)
            /*bool*/ PreferRelatedApplications = false;
            //--TRIMMABLE-BOUNDARY-END(210455993824)
            
            //--TRIMMABLE-BOUNDARY-START(201866059232)
            /*string?*/ Language = null;
            //--TRIMMABLE-BOUNDARY-END(201866059232)
            
            //--TRIMMABLE-BOUNDARY-START(68722073056)
            /*string[]?*/ Categories = null;
            //--TRIMMABLE-BOUNDARY-END(68722073056)
            
            //--TRIMMABLE-BOUNDARY-START(193276124640)
            /*ApplicationManifestIcon[]*/ Icons = null;
            //--TRIMMABLE-BOUNDARY-END(193276124640)
            
            //--TRIMMABLE-BOUNDARY-START(214750961120)
            /*ApplicationManifestScreenShot[]?*/ ScreenShots = null;
            //--TRIMMABLE-BOUNDARY-END(214750961120)
            
            //--TRIMMABLE-BOUNDARY-START(60132138464)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132138464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60132138464)
            
            //--TRIMMABLE-BOUNDARY-START(60132138464)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(60132138464)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(335010045408)
                this.StartUrl = "./";
                //--TRIMMABLE-BOUNDARY-END(335010045408)
                
                //--TRIMMABLE-BOUNDARY-START(77312007648)
                this.Display = "standalone";
                //--TRIMMABLE-BOUNDARY-END(77312007648)
                
            }
            static $h = 2596320;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(197571091936),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851615200,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266290568672,
        "f": 83886081
      },
      "n": "Id",
      "d": 2596320,
      "h": 197571091936,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197571091936),
//--TRIMMABLE-BOUNDARY-START(206161026528),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146031484384,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283470437856,
        "f": 83886081
      },
      "n": "Name",
      "d": 2596320,
      "h": 206161026528,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206161026528),
//--TRIMMABLE-BOUNDARY-START(330715078112),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171801288160,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309240241632,
        "f": 83886081
      },
      "n": "ShortName",
      "d": 2596320,
      "h": 330715078112,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "short_name",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(330715078112),
//--TRIMMABLE-BOUNDARY-START(73017040352),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081811424,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240520764896,
        "f": 83886081
      },
      "n": "Description",
      "d": 2596320,
      "h": 73017040352,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73017040352),
//--TRIMMABLE-BOUNDARY-START(335010045408),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180391222752,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317830176224,
        "f": 83886081
      },
      "n": "StartUrl",
      "d": 2596320,
      "h": 335010045408,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "start_url",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335010045408),
//--TRIMMABLE-BOUNDARY-START(77312007648),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671746016,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249110699488,
        "f": 83886081
      },
      "n": "Display",
      "d": 2596320,
      "h": 77312007648,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312007648),
//--TRIMMABLE-BOUNDARY-START(64427105760),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901942240,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223340895712,
        "f": 83886081
      },
      "n": "BackgroundColor",
      "d": 2596320,
      "h": 64427105760,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "background_color",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427105760),
//--TRIMMABLE-BOUNDARY-START(339305012704),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188981157344,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326420110816,
        "f": 83886081
      },
      "n": "ThemeColor",
      "d": 2596320,
      "h": 339305012704,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "theme_color",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(339305012704),
//--TRIMMABLE-BOUNDARY-START(210455993824),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154621418976,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292060372448,
        "f": 83886081
      },
      "n": "PreferRelatedApplications",
      "d": 2596320,
      "h": 210455993824,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "prefer_related_applications",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210455993824),
//--TRIMMABLE-BOUNDARY-START(201866059232),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137441549792,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274880503264,
        "f": 83886081
      },
      "n": "Language",
      "d": 2596320,
      "h": 201866059232,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201866059232),
//--TRIMMABLE-BOUNDARY-START(68722073056),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491876832,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231930830304,
        "f": 83886081
      },
      "n": "Categories",
      "d": 2596320,
      "h": 68722073056,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722073056),
//--TRIMMABLE-BOUNDARY-START(193276124640),
    {
      "p": $.$typeArray($.$yleQ.LCFCP.ApplicationManifestIcon).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261680608,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257700634080,
        "f": 83886081
      },
      "n": "Icons",
      "d": 2596320,
      "h": 193276124640,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193276124640),
//--TRIMMABLE-BOUNDARY-START(214750961120),
    {
      "p": $.$typeArray($.$yleQ.LCFCP.ApplicationManifestScreenShot).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163211353568,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300650307040,
        "f": 83886081
      },
      "n": "ScreenShots",
      "d": 2596320,
      "h": 214750961120,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "screenshots",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214750961120)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(60132138464),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2596320,
      "h": 60132138464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60132138464)
  ],
  "h": 2596320,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    },
    {
      "t": 44665174,
      "c": 4339632470
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifest`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2596320)
        
        

        //--TRIMMABLE-BOUNDARY-START(2792928)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestIconCustomAttributesProvider`, ($self) => class ApplicationManifestIconCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297760224)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297760224)
            
            //--TRIMMABLE-BOUNDARY-START(8592727520)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592727520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$yleQ.LCFCP.ApplicationManifestIconCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Source", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("src");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("MimeType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("type");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$yleQ.LCFCP.ApplicationManifestIconCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $MRMuQh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2792928,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $mMlRrc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2792928,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592727520)
            
            static $h = 2792928;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592727520),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2792928,
      "h": 8592727520,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592727520)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297760224),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2792928,
      "h": 4297760224,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297760224)
  ],
  "h": 2792928
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIconCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestIconCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2792928)
        
        

        //--TRIMMABLE-BOUNDARY-START(1088992)
        $asm.$cls(`$yleQ.LCFCA.ApplicationServiceFeaturesCustomAttributesProvider`, ($self) => class ApplicationServiceFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296056288)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296056288)
            
            //--TRIMMABLE-BOUNDARY-START(8591023584)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591023584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$yleQ.LCFCA.ApplicationServiceFeaturesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$yleQ.LCFCA.ApplicationServiceFeaturesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $RsBJua ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1088992,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $bcgead ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1088992,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591023584)
            
            static $h = 1088992;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591023584),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1088992,
      "h": 8591023584,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591023584)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296056288),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1088992,
      "h": 4296056288,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296056288)
  ],
  "h": 1088992
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationServiceFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationServiceFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1088992)
        
        

        //--TRIMMABLE-BOUNDARY-START(2661856)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestCustomAttributesProvider`, ($self) => class ApplicationManifestCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297629152)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297629152)
            
            //--TRIMMABLE-BOUNDARY-START(8592596448)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592596448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$yleQ.LCFCP.ApplicationManifestCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ShortName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("short_name");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("StartUrl", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("start_url");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BackgroundColor", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t5 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("background_color");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ThemeColor", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t6 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$3("theme_color");
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PreferRelatedApplications", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t7 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$3("prefer_related_applications");
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ScreenShots", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t8 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$3("screenshots");
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$yleQ.LCFCP.ApplicationManifestCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $BTzpqf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2661856,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $zhTFck ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2661856,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592596448)
            
            static $h = 2661856;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592596448),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2661856,
      "h": 8592596448,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592596448)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297629152),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2661856,
      "h": 4297629152,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297629152)
  ],
  "h": 2661856
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2661856)
        
        

        //--TRIMMABLE-BOUNDARY-START(2924000)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestIconTypeDescriptorBuilder`, ($self) => class ApplicationManifestIconTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592858592)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592858592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor()
                        const $t1 = $.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIcon");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $kFaWrf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2924000,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yleQ.LCFCP.ApplicationManifestIcon.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592858592)
            
            //--TRIMMABLE-BOUNDARY-START(4297891296)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297891296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297891296)
            
            //--TRIMMABLE-BOUNDARY-START(4297891296)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297891296)
            
            static $h = 2924000;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592858592),
    {
      "r": 65537,
      "n": "Register",
      "d": 2924000,
      "h": 8592858592,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592858592)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297891296),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2924000,
      "h": 4297891296,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297891296)
  ],
  "h": 2924000
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIconTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestIconTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2924000)
        
        

        //--TRIMMABLE-BOUNDARY-START(171488)
        $asm.$cls(`$yleQ.LCFCA.ApplicationBaseUserPreferenceCustomAttributesProvider`, ($self) => class ApplicationBaseUserPreferenceCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295138784)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295138784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$vWqU.LCFCC.ClientUserPreferenceCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295138784)
            
            static $h = 171488;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295138784),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 171488,
      "h": 4295138784,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295138784)
  ],
  "h": 171488
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationBaseUserPreferenceCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationBaseUserPreferenceCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(171488)
        
        

        //--TRIMMABLE-BOUNDARY-START(630240)
        $asm.$cls(`$yleQ.LCFCA.ApplicationsDescriptor`, ($self) => class ApplicationsDescriptor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(73015074272)
            /*bool*/ LazyLoadingEnabled = false;
            //--TRIMMABLE-BOUNDARY-END(73015074272)
            
            //--TRIMMABLE-BOUNDARY-START(25770434016)
            /*IEnumerable<ApplicationDescriptor>?*/ Applications = null;
            //--TRIMMABLE-BOUNDARY-END(25770434016)
            
            //--TRIMMABLE-BOUNDARY-START(30065401312)
            /*IEnumerable<ApplicationDomainMapping>?*/ DomainMappings = null;
            //--TRIMMABLE-BOUNDARY-END(30065401312)
            
            //--TRIMMABLE-BOUNDARY-START(111669779936)
            /*GlobalSettings?*/ Settings = null;
            //--TRIMMABLE-BOUNDARY-END(111669779936)
            
            //--TRIMMABLE-BOUNDARY-START(68720106976)
            /*IApplicationServiceProxy? */ GetServiceAssemblyModule(/*Uri?*/ uri, /*string?*/ appName, /*string?*/ pathPrefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720106976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let authority = $.$spu.S.Uri.op_Inequality(uri, null) ? $.$fPer.LCFC.DomainAuthority.Parse(uri.Authority) : new $.$fPer.LCFC.DomainAuthority();
                appName ??= $.$fPer.LCFC.Stringy.op_Implicit$1(authority.SubDomainName);
                if ((uri?.Query ?? null) !== null)
                {
                    /*var*/ let query = $.$swh.SW.HttpUtility.ParseQueryString$1(uri.Query);
                    /*var*/ let uriFromQuery = query.get_Item$2("domain");
                    if (uriFromQuery !== null)
                    {
                        uri = new $.$spu.S.Uri().$ctor$5($.$strNN($.$strNN($.$strNN(uri.Scheme) + "://") + $.$strNN(uriFromQuery)) + $.$strNN(uri.PathAndQuery));
                        authority = $.$fPer.LCFC.DomainAuthority.Parse(uri.Authority);
                        appName ??= $.$fPer.LCFC.Stringy.op_Implicit$1(authority.SubDomainName);
                    }
                    else 
                    {
                        /*var*/ let appFromUri = query.get_Item$2("app");
                        if (appFromUri !== null)
                        {
                            pathPrefix = !$.$$.S.String.IsNullOrEmpty(appFromUri) ? appFromUri : null;
                        }
                    }
                }
                /*System.Uri?*/ let __ca1__;
                pathPrefix ??= ($.$spu.S.Uri.op_Inequality((__ca1__ = uri), null) ? $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$1.call($.$$.S.String.Trim$1.call(__ca1__.AbsolutePath, /*/*/ 47), /*/*/ 47, 0), 0) : null);
                /*IApplicationServiceProxy?*/ let descriptor = null;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor>?*/ let __ca2__;
                /*var*/ let allAppsAndServices = $.$sl.SL.Enumerable.Concat($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.N.InterfaceVarianceStubHandler.Create(($.$$.N.InterfaceVarianceStubHandler.Create(this.Applications ?? $.$sl.SL.Enumerable.Empty($.$yleQ.LCFCA.ApplicationDescriptor), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy))), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy)), ((__ca2__ = this.Applications) !== null ? ($.$sl.SL.Enumerable.SelectMany$2($.$yleQ.LCFCA.ApplicationDescriptor, $.$yleQ.LCFCA.IApplicationServiceProxy, __ca2__, new ($.$$.S.Func$$$($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy)))().$ctor(this,  (/**/ a) =>
                {
                    return a.ServiceModules ?? $.$sl.SL.Enumerable.Empty($.$yleQ.LCFCA.IApplicationServiceProxy);
                }, $AAOyLd ??= {"r":$.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy).$h,"p":[{"n":"a","p":368096}],"n":"","d":630240,"h":0,"f":17825794})) ?? $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.Empty($.$yleQ.LCFCA.ApplicationServiceDescriptor), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy))) : $.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.Empty($.$yleQ.LCFCA.ApplicationServiceDescriptor), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy))));
                /*var*/ let applicationsMatchingDomain = $.$sl.SL.Enumerable.Where($.$yleQ.LCFCA.ApplicationDescriptor, (this.Applications ?? $.$sl.SL.Enumerable.Empty($.$yleQ.LCFCA.ApplicationDescriptor)), new ($.$$.S.Func$$$($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    /*string[]?*/ let __ca3__;
                    return $.$spu.S.Uri.op_Inequality(uri, null) && (((__ca3__ = a.Domains) !== null ? $.$$.S.MemoryExtensions.Contains$2($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(__ca3__), uri.Authority) : false));
                }, $wwsAoc ??= {"r":262145,"p":[{"n":"a","p":368096}],"n":"","d":630240,"h":0,"f":17825794}));
                /*var*/ let servicesMatchingDomain = $.$sl.SL.Enumerable.SelectMany$2($.$yleQ.LCFCA.ApplicationDescriptor, $.$yleQ.LCFCA.IApplicationServiceProxy, applicationsMatchingDomain, new ($.$$.S.Func$$$($.$yleQ.LCFCA.ApplicationDescriptor, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy)))().$ctor(this,  (/*a*/ a) =>
                {
                    return a.ServiceModules ?? $.$sl.SL.Enumerable.Empty($.$yleQ.LCFCA.IApplicationServiceProxy);
                }, $sQRpYh ??= {"r":$.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy).$h,"p":[{"n":"a","p":368096}],"n":"","d":630240,"h":0,"f":17825794}));
                /*var*/ let allAppsAndServicesMatchingDomain = $.$sl.SL.Enumerable.Concat($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.N.InterfaceVarianceStubHandler.Create(applicationsMatchingDomain, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy)), servicesMatchingDomain);
                if ($.$spu.S.Uri.op_Inequality(uri, null))
                {
                    /*LivingThing.Core.Frameworks.Common.Models.Settings.GlobalSettings?*/ let __ca4__;
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationDomainMapping>?*/ let __ca7__;
                    /*var*/ let mapping = ((__ca4__ = this.Settings) !== null ? ((__ca7__ = __ca4__.DomainMappings) !== null ? $.$sl.SL.Enumerable.Where($.$fPer.LCFCA.ApplicationDomainMapping, __ca7__, new ($.$$.S.Func$$$($.$fPer.LCFCA.ApplicationDomainMapping, $.$$.S.Boolean))().$ctor(this,  (/*d*/ d) =>
                    {
                        /*string?*/ let __ca5__;
                        /*string[]*/ let __ca6__;
                        return ((__ca5__ = d.Domains) !== null ? ((__ca6__ = $.$$.S.String.Split$1.call(__ca5__, /*,*/ 44, 0)) !== null ? $.$$.S.MemoryExtensions.Contains$1($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(__ca6__), uri.Authority, $.$$.S.StringComparer.InvariantCultureIgnoreCase) : false) : false);
                    }, $btkftk ??= {"r":262145,"p":[{"n":"d","p":887126}],"n":"","d":630240,"h":0,"f":17825794})) : null) : null);
                    if (mapping !== null)
                    {
                        descriptor = $.$sl.SL.Enumerable.FirstOrDefault$1($.$yleQ.LCFCA.IApplicationServiceProxy, allAppsAndServices, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.Boolean))().$ctor(this,  (/*app*/ app) =>
                        {
                            return $.$sl.SL.Enumerable.Any($.$fPer.LCFCA.ApplicationDomainMapping, mapping, new ($.$$.S.Func$$$($.$fPer.LCFCA.ApplicationDomainMapping, $.$$.S.Boolean))().$ctor(this,  (/*mapping*/ mapping) =>
                            {
                                /*string?*/ let __ca8__;
                                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca9__;
                                /*string?*/ let __ca10__;
                                return (((__ca8__ = mapping.Application) !== null ? $.$$.S.String.Equals$2.call(__ca8__, $.$fPer.LCFCA.ApplicationAssembly.op_Implicit((__ca9__ = app.LCFCA$IApplicationServiceProxy$MainAssemblies) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA.ApplicationAssembly, __ca9__) : null), 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)) || (((__ca10__ = mapping.Application) !== null ? $.$$.S.String.Equals$2.call(__ca10__, app.LCFC$INamed$Name, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false));
                            }, $miQXdj ??= {"r":262145,"p":[{"n":"mapping","p":887126}],"n":"","d":630240,"h":0,"f":17825794}));
                        }, $aISYWk ??= {"r":262145,"p":[{"n":"app","p":2203104}],"n":"","d":630240,"h":0,"f":17825794}));
                        if (descriptor !== null)
                        {
                            return descriptor;
                        }
                    }
                }
                if (appName !== null)
                {
                    descriptor = $.$sl.SL.Enumerable.FirstOrDefault$1($.$yleQ.LCFCA.IApplicationServiceProxy, allAppsAndServicesMatchingDomain, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        /*string?*/ let __ca11__;
                        /*string[]?*/ let __ca12__;
                        return (((__ca11__ = s.LCFC$INamed$Name) !== null ? $.$$.S.String.Equals$2.call(__ca11__, appName, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)) || (((__ca12__ = s.LCFCA$IApplicationServiceProxy$Paths) !== null ? $.$$.S.MemoryExtensions.Contains$1($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(__ca12__), appName, $.$$.S.StringComparer.InvariantCultureIgnoreCase) : false));
                    }, $RZhfGb ??= {"r":262145,"p":[{"n":"s","p":2203104}],"n":"","d":630240,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.FirstOrDefault$1($.$yleQ.LCFCA.IApplicationServiceProxy, allAppsAndServices, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        /*string?*/ let __ca13__;
                        /*string[]?*/ let __ca14__;
                        return (((__ca13__ = s.LCFC$INamed$Name) !== null ? $.$$.S.String.Equals$2.call(__ca13__, appName, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false)) || (((__ca14__ = s.LCFCA$IApplicationServiceProxy$Paths) !== null ? $.$$.S.MemoryExtensions.Contains$1($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(__ca14__), appName, $.$$.S.StringComparer.InvariantCultureIgnoreCase) : false));
                    }, $YjMMtd ??= {"r":262145,"p":[{"n":"s","p":2203104}],"n":"","d":630240,"h":0,"f":17825794}));
                    if (descriptor !== null)
                    {
                        return descriptor;
                    }
                }
                if (!$.$$.S.String.IsNullOrEmpty(pathPrefix))
                {
                    descriptor = $.$sl.SL.Enumerable.FirstOrDefault$1($.$yleQ.LCFCA.IApplicationServiceProxy, allAppsAndServicesMatchingDomain, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        /*string[]?*/ let __ca15__;
                        return ((__ca15__ = s.LCFCA$IApplicationServiceProxy$Paths) !== null ? $.$$.S.MemoryExtensions.Contains$1($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(__ca15__), pathPrefix, $.$$.S.StringComparer.InvariantCultureIgnoreCase) : false);
                    }, $ByZmMe ??= {"r":262145,"p":[{"n":"s","p":2203104}],"n":"","d":630240,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.FirstOrDefault$1($.$yleQ.LCFCA.IApplicationServiceProxy, allAppsAndServices, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        /*string[]?*/ let __ca16__;
                        return ((__ca16__ = s.LCFCA$IApplicationServiceProxy$Paths) !== null ? $.$$.S.MemoryExtensions.Contains$1($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(__ca16__), pathPrefix, $.$$.S.StringComparer.InvariantCultureIgnoreCase) : false);
                    }, $EvZMtd ??= {"r":262145,"p":[{"n":"s","p":2203104}],"n":"","d":630240,"h":0,"f":17825794}));
                    if (descriptor !== null)
                    {
                        return descriptor;
                    }
                    descriptor = $.$sl.SL.Enumerable.FirstOrDefault$1($.$yleQ.LCFCA.IApplicationServiceProxy, allAppsAndServicesMatchingDomain, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.Boolean))().$ctor(this,  (/**/ s) =>
                    {
                        /*string?*/ let __ca17__;
                        return ((__ca17__ = s.LCFC$INamed$Name) !== null ? $.$$.S.String.Equals$2.call(__ca17__, pathPrefix, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false);
                    }, $RMADGb ??= {"r":262145,"p":[{"n":"s","p":2203104}],"n":"","d":630240,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.FirstOrDefault$1($.$yleQ.LCFCA.IApplicationServiceProxy, allAppsAndServices, new ($.$$.S.Func$$$($.$yleQ.LCFCA.IApplicationServiceProxy, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        /*string?*/ let __ca18__;
                        return ((__ca18__ = s.LCFC$INamed$Name) !== null ? $.$$.S.String.Equals$2.call(__ca18__, pathPrefix, 3/*StringComparison.InvariantCultureIgnoreCase*/) : false);
                    }, $rrLpdi ??= {"r":262145,"p":[{"n":"s","p":2203104}],"n":"","d":630240,"h":0,"f":17825794}));
                    if (descriptor !== null)
                    {
                        return descriptor;
                    }
                }
                return $.$sl.SL.Enumerable.FirstOrDefault$3($.$yleQ.LCFCA.ApplicationDescriptor, applicationsMatchingDomain);
            }
            //--TRIMMABLE-BOUNDARY-END(68720106976)
            
            //--TRIMMABLE-BOUNDARY-START(21475466720)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475466720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475466720)
            
            //--TRIMMABLE-BOUNDARY-START(21475466720)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475466720)
            
            static $h = 630240;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015074272),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835205088,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784878048,
        "f": 83886081
      },
      "n": "LazyLoadingEnabled",
      "d": 630240,
      "h": 73015074272,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015074272),
//--TRIMMABLE-BOUNDARY-START(25770434016),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655335904,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605008864,
        "f": 83886081
      },
      "n": "Applications",
      "d": 630240,
      "h": 25770434016,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770434016),
//--TRIMMABLE-BOUNDARY-START(30065401312),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationDomainMapping).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245270496,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194943456,
        "f": 83886081
      },
      "n": "DomainMappings",
      "d": 630240,
      "h": 30065401312,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065401312),
//--TRIMMABLE-BOUNDARY-START(111669779936),
    {
      "p": 19539286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425139680,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374812640,
        "f": 83886081
      },
      "n": "Settings",
      "d": 630240,
      "h": 111669779936,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669779936)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720106976),
    {
      "r": 2203104,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        },
        {
          "n": "appName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "pathPrefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetServiceAssemblyModule",
      "d": 630240,
      "h": 68720106976,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720106976)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475466720),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 630240,
      "h": 21475466720,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475466720)
  ],
  "h": 630240,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationsDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(630240)
        
        

        //--TRIMMABLE-BOUNDARY-START(3186144)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptorBuilder`, ($self) => class ApplicationManifestScreenShotTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593120736)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593120736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor()
                        const $t1 = $.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShot");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ksPAWc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3186144,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yleQ.LCFCP.ApplicationManifestScreenShot.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593120736)
            
            //--TRIMMABLE-BOUNDARY-START(4298153440)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298153440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298153440)
            
            //--TRIMMABLE-BOUNDARY-START(4298153440)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298153440)
            
            static $h = 3186144;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593120736),
    {
      "r": 65537,
      "n": "Register",
      "d": 3186144,
      "h": 8593120736,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593120736)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298153440),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3186144,
      "h": 4298153440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298153440)
  ],
  "h": 3186144
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShotTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestScreenShotTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3186144)
        
        

        //--TRIMMABLE-BOUNDARY-START(3317216)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestTypeDescriptorBuilder`, ($self) => class ApplicationManifestTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593251808)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593251808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yleQ.LCFCP.ApplicationManifestTypeDescriptor()
                        const $t1 = $.$yleQ.LCFCP.ApplicationManifestTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pagKHj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3317216,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yleQ.LCFCP.ApplicationManifest.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593251808)
            
            //--TRIMMABLE-BOUNDARY-START(4298284512)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298284512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298284512)
            
            //--TRIMMABLE-BOUNDARY-START(4298284512)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298284512)
            
            static $h = 3317216;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593251808),
    {
      "r": 65537,
      "n": "Register",
      "d": 3317216,
      "h": 8593251808,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593251808)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298284512),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3317216,
      "h": 4298284512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298284512)
  ],
  "h": 3317216
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3317216)
        
        

        //--TRIMMABLE-BOUNDARY-START(499168)
        $asm.$cls(`$yleQ.LCFCA.ApplicationDescriptorTypeDescriptorBuilder`, ($self) => class ApplicationDescriptorTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590433760)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590433760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor()
                        const $t1 = $.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nLscPd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":499168,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yleQ.LCFCA.ApplicationDescriptor.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590433760)
            
            //--TRIMMABLE-BOUNDARY-START(4295466464)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295466464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295466464)
            
            //--TRIMMABLE-BOUNDARY-START(4295466464)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295466464)
            
            static $h = 499168;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590433760),
    {
      "r": 65537,
      "n": "Register",
      "d": 499168,
      "h": 8590433760,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590433760)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295466464),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 499168,
      "h": 4295466464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295466464)
  ],
  "h": 499168
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptorTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationDescriptorTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(499168)
        
        

        //--TRIMMABLE-BOUNDARY-START(3055072)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestScreenShotCustomAttributesProvider`, ($self) => class ApplicationManifestScreenShotCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298022368)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298022368)
            
            //--TRIMMABLE-BOUNDARY-START(8592989664)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592989664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$yleQ.LCFCP.ApplicationManifestScreenShotCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Source", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("src");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Sizes", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("sizes");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("MimeType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t5 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("type");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FormFactor", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t6 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$3("form_factor");
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$yleQ.LCFCP.ApplicationManifestScreenShotCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $UkSzEk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3055072,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $oDukQe ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3055072,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592989664)
            
            static $h = 3055072;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592989664),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3055072,
      "h": 8592989664,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592989664)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298022368),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3055072,
      "h": 4298022368,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298022368)
  ],
  "h": 3055072
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShotCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestScreenShotCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3055072)
        
        

        //--TRIMMABLE-BOUNDARY-START(2399712)
        $asm.$cls(`$yleQ.LCFCA.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297367008)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297367008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$yleQ.LCFCA.IApplicationRemoteService, $.$yleQ.LCFCA.IApplicationRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$yleQ.LCFCA.IApplicationRemoteService_Mocking().$ctor$3(impl);
                }, $OMGQlb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":2399712,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4297367008)
            
            static $h = 2399712;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297367008),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 2399712,
      "h": 4297367008,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297367008)
  ],
  "h": 2399712
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2399712)
        
        

        //--TRIMMABLE-BOUNDARY-START(1154528)
        $asm.$cls(`$yleQ.LCFCA.ApplicationServiceProxyExtension`, ($self) => class ApplicationServiceProxyExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296121824)
            static /*ApplicationRuntimeConfiguration */ ToRuntime(/*this IApplicationServiceProxy*/ serviceDescriptor, /*RuntimeType*/ runTimeType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296121824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string[]?*/ let __ca1__;
                return (() =>
                {
                    //new $.$fPer.LCFCA.ApplicationRuntimeConfiguration()
                    const $t1 = $.$fPer.LCFCA.ApplicationRuntimeConfiguration;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.AppId = serviceDescriptor.LCFCA$IApplicationServiceProxy$Id;
                    $i1.AppType = serviceDescriptor.LCFCA$IApplicationServiceProxy$Type;
                    $i1.MainAssemblies = serviceDescriptor.LCFCA$IApplicationServiceProxy$MainAssemblies;
                    $i1.Dependencies = serviceDescriptor.LCFCA$IApplicationServiceProxy$Dependencies;
                    $i1.AppName = serviceDescriptor.LCFC$INamed$Name;
                    $i1.Authorize = ((serviceDescriptor.LCFCA$IApplicationServiceProxy$Features & (8/*ApplicationServiceFeatures.Authorize*/)) == (8/*ApplicationServiceFeatures.Authorize*/));
                    $i1.UseRouter = ((serviceDescriptor.LCFCA$IApplicationServiceProxy$Features & (16/*ApplicationServiceFeatures.UseRouter*/)) == (16/*ApplicationServiceFeatures.UseRouter*/));
                    $i1.StartUrl = ((__ca1__ = serviceDescriptor.LCFCA$IApplicationServiceProxy$Paths) !== null ? ($.$sl.SL.Enumerable.FirstOrDefault$3($.$$.S.String, __ca1__) ?? serviceDescriptor.LCFC$INamed$Name) : serviceDescriptor.LCFC$INamed$Name);
                    $i1.StartupOptions = (() =>
                    {
                        //new $.$fPer.LCFCS$3.StartupOptions()
                        const $t2 = $.$fPer.LCFCS$3.StartupOptions;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.Runtime = runTimeType;
                        return $i2;
                    })();
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(4296121824)
            
            static $h = 1154528;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296121824),
    {
      "r": 1083734,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 2203104
        },
        {
          "n": "runTimeType",
          "p": 57575766
        }
      ],
      "n": "ToRuntime",
      "d": 1154528,
      "h": 4296121824,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296121824)
  ],
  "h": 1154528
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationServiceProxyExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationServiceProxyExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1154528)
        
        

        //--TRIMMABLE-BOUNDARY-START(761312)
        $asm.$cls(`$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptorBuilder`, ($self) => class ApplicationsDescriptorTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590695904)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590695904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor()
                        const $t1 = $.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptor");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $sCdgZi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":761312,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yleQ.LCFCA.ApplicationsDescriptor.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590695904)
            
            //--TRIMMABLE-BOUNDARY-START(4295728608)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295728608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295728608)
            
            //--TRIMMABLE-BOUNDARY-START(4295728608)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295728608)
            
            static $h = 761312;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590695904),
    {
      "r": 65537,
      "n": "Register",
      "d": 761312,
      "h": 8590695904,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590695904)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295728608),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 761312,
      "h": 4295728608,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295728608)
  ],
  "h": 761312
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptorTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationsDescriptorTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(761312)
        
        

        //--TRIMMABLE-BOUNDARY-START(302560)
        $asm.$cls(`$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptorBuilder`, ($self) => class ApplicationBaseUserPreferenceTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590237152)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590237152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptor()
                        const $t1 = $.$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Application.ApplicationBaseUserPreference");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SBvYib ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":302560,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yleQ.LCFCA.ApplicationBaseUserPreference.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590237152)
            
            //--TRIMMABLE-BOUNDARY-START(4295269856)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295269856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295269856)
            
            //--TRIMMABLE-BOUNDARY-START(4295269856)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295269856)
            
            static $h = 302560;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590237152),
    {
      "r": 65537,
      "n": "Register",
      "d": 302560,
      "h": 8590237152,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590237152)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295269856),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 302560,
      "h": 4295269856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295269856)
  ],
  "h": 302560
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationBaseUserPreferenceTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationBaseUserPreferenceTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(302560)
        
        

        //--TRIMMABLE-BOUNDARY-START(957920)
        $asm.$cls(`$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptorBuilder`, ($self) => class ApplicationServiceDescriptorTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590892512)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590892512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor()
                        const $t1 = $.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $qMznPd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":957920,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590892512)
            
            //--TRIMMABLE-BOUNDARY-START(4295925216)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295925216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295925216)
            
            //--TRIMMABLE-BOUNDARY-START(4295925216)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295925216)
            
            static $h = 957920;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590892512),
    {
      "r": 65537,
      "n": "Register",
      "d": 957920,
      "h": 8590892512,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590892512)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295925216),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 957920,
      "h": 4295925216,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295925216)
  ],
  "h": 957920
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptorTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationServiceDescriptorTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(957920)
        
        

        //--TRIMMABLE-BOUNDARY-START(1285600)
        $asm.$cls(`$yleQ.LCFCA.DefaultApplicationContextProvider`, ($self) => class DefaultApplicationContextProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25771089376)
            $ctor$1(/*IConfigurationParser*/ config, /*IOptions<ApplicationRuntimeConfiguration>*/ runTimeOptions)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771089376);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Config = config;
                    this.Runtime = runTimeOptions.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value ?? (() =>
                    {
                        //new $.$fPer.LCFCA.ApplicationRuntimeConfiguration()
                        const $t1 = $.$fPer.LCFCA.ApplicationRuntimeConfiguration;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.StartupOptions = (() =>
                        {
                            //new $.$fPer.LCFCS$3.StartupOptions()
                            const $t2 = $.$fPer.LCFCS$3.StartupOptions;
                            const $i2 = new $t2();
                            $i2.$ctor$2();
                            $i2.Runtime = 6/*RuntimeType.DesktopApp*/;
                            return $i2;
                        })();
                        return $i1;
                    })();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771089376)
            
            //--TRIMMABLE-BOUNDARY-START(111670435296)
            /*bool*/ static IsPlainTextWebView = false;
            //--TRIMMABLE-BOUNDARY-END(111670435296)
            
            //--TRIMMABLE-BOUNDARY-START(124555337184)
            /*bool*/ static ReverseDebugProxy = false;
            //--TRIMMABLE-BOUNDARY-END(124555337184)
            
            //--TRIMMABLE-BOUNDARY-START(30066056672)
            /*IConfigurationParser*/ Config = null;
            //--TRIMMABLE-BOUNDARY-END(30066056672)
            
            //--TRIMMABLE-BOUNDARY-START(4296252896)
            /*string?*/ _remoteHost = null;
            //--TRIMMABLE-BOUNDARY-END(4296252896)
            
            //--TRIMMABLE-BOUNDARY-START(120260369888)
            /*string */ get RemoteHost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605664224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._remoteHost ?? $.$strNN(this.Config.LCFCC$1$IConfigurationParser$RemoteHost) + $.$strNN(($.$yleQ.LCFCA.DefaultApplicationContextProvider.ReverseDebugProxy ? "/__" : ""));
            }
            /*string */ set RemoteHost(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030173664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._remoteHost = value;
            }
            //--TRIMMABLE-BOUNDARY-END(120260369888)
            
            //--TRIMMABLE-BOUNDARY-START(103080500704)
            /*bool */ get IsClient()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(103080500704)
            
            //--TRIMMABLE-BOUNDARY-START(107375468000)
            /*bool */ get IsMobile()
            {
                return this.Runtime.Type === 2/*RuntimeType.MobileApp*/;
            }
            //--TRIMMABLE-BOUNDARY-END(107375468000)
            
            //--TRIMMABLE-BOUNDARY-START(115965402592)
            /*Uri */ get LocalUri()
            {
                return new $.$spu.S.Uri().$ctor$5(`http${$.$strNN(($.$yleQ.LCFCA.DefaultApplicationContextProvider.IsPlainTextWebView ? "" : "s"))}://0.0.0.0`);
            }
            //--TRIMMABLE-BOUNDARY-END(115965402592)
            
            //--TRIMMABLE-BOUNDARY-START(128850304480)
            /*ApplicationRuntimeConfiguration*/ Runtime = null;
            //--TRIMMABLE-BOUNDARY-END(128850304480)
            
            //--TRIMMABLE-BOUNDARY-START(42995714390)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IApplicationContextProvider.Runtime.get
            get LCFC$IApplicationContextProvider$Runtime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64470550870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Runtime;
            }
            //--TRIMMABLE-BOUNDARY-END(42995714390)
            
            //--TRIMMABLE-BOUNDARY-START(17225910614)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IApplicationContextProvider.IsMobile.get
            get LCFC$IApplicationContextProvider$IsMobile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51585648982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsMobile;
            }
            //--TRIMMABLE-BOUNDARY-END(17225910614)
            
            //--TRIMMABLE-BOUNDARY-START(8635976022)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IApplicationContextProvider.IsClient.get
            get LCFC$IApplicationContextProvider$IsClient()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47290681686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsClient;
            }
            //--TRIMMABLE-BOUNDARY-END(8635976022)
            
            //--TRIMMABLE-BOUNDARY-START(34405779798)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IApplicationContextProvider.RemoteHost.get
            get LCFC$IApplicationContextProvider$RemoteHost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60175583574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoteHost;
            }
            //--TRIMMABLE-BOUNDARY-END(34405779798)
            
            //--TRIMMABLE-BOUNDARY-START(25815845206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IApplicationContextProvider.LocalUri.get
            get LCFC$IApplicationContextProvider$LocalUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55880616278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LocalUri;
            }
            //--TRIMMABLE-BOUNDARY-END(25815845206)
            
            static $h = 1285600;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670435296),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425795040,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440239072,
        "f": 83886113
      },
      "n": "IsPlainTextWebView",
      "d": 1285600,
      "h": 111670435296,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(111670435296),
//--TRIMMABLE-BOUNDARY-START(124555337184),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195598816,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620108256,
        "f": 83886113
      },
      "n": "ReverseDebugProxy",
      "d": 1285600,
      "h": 124555337184,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(124555337184),
//--TRIMMABLE-BOUNDARY-START(30066056672),
    {
      "p": 4950358,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655991264,
        "f": 50331649
      },
      "n": "Config",
      "d": 1285600,
      "h": 30066056672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066056672),
//--TRIMMABLE-BOUNDARY-START(120260369888),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605664224,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030173664,
        "f": 83886081
      },
      "n": "RemoteHost",
      "d": 1285600,
      "h": 120260369888,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260369888),
//--TRIMMABLE-BOUNDARY-START(103080500704),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245925856,
        "f": 50331649
      },
      "n": "IsClient",
      "d": 1285600,
      "h": 103080500704,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080500704),
//--TRIMMABLE-BOUNDARY-START(107375468000),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835860448,
        "f": 50331649
      },
      "n": "IsMobile",
      "d": 1285600,
      "h": 107375468000,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375468000),
//--TRIMMABLE-BOUNDARY-START(115965402592),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015729632,
        "f": 50331649
      },
      "n": "LocalUri",
      "d": 1285600,
      "h": 115965402592,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965402592),
//--TRIMMABLE-BOUNDARY-START(128850304480),
    {
      "p": 1083734,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785533408,
        "f": 50331649
      },
      "n": "Runtime",
      "d": 1285600,
      "h": 128850304480,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850304480)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296252896),
    {
      "t": 1310721,
      "n": "_remoteHost",
      "d": 1285600,
      "h": 4296252896,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296252896)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771089376),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "runTimeOptions",
          "p": $.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1285600,
      "h": 25771089376,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771089376)
  ],
  "h": 1285600
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IApplicationContextProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.DefaultApplicationContextProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}DefaultApplicationContextProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1285600)
        
        

        //--TRIMMABLE-BOUNDARY-START(2465248)
        $asm.$cls(`$yleQ.LCFCA.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887367136)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887367136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_DefaultApplicationContextProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$yleQ.LCFCA.DefaultApplicationContextProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFCC$1.IConfigurationParser, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFCC$1.IConfigurationParser, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration), provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration), provider));
                }
                if (options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$yleQ.LCFCA.DefaultApplicationContextProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$yleQ.LCFCA.ServiceRegistrar, Get_DefaultApplicationContextProvider, $eolTzg ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_DefaultApplicationContextProvider","d":2465248,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IApplicationContextProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$yleQ.LCFCA.DefaultApplicationContextProvider, x);
                    }), $EGfNOb ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":2465248,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fPer.LCFC.IApplicationContextProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$yleQ.LCFCA.ServiceRegistrar, Get_IApplicationContextProvider, $JGPMZf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IApplicationContextProvider","d":2465248,"h":0,"f":16777250})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887367136)
            
            //--TRIMMABLE-BOUNDARY-START(8592399840)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592399840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$yleQ.LCFCA.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                if (options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFC.IApplicationContextProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$yleQ.LCFCA.DefaultApplicationContextProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFC.IApplicationContextProvider))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$yleQ.LCFCA.DefaultApplicationContextProvider, x);
                    }, $WiMnij ??= {"r":46041430,"p":[{"n":"x","p":327718}],"n":"","d":2465248,"h":0,"f":17825794}));
                }
                $.$yleQ.LCFCA.FastEnumStartupExtension.AddGeneratedFastEnums(services);
                $.$yleQ.LCFCA.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$yleQ.LCFCA.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$yleQ.LCFCA.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592399840)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$yleQ.LCFCA.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297432544)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297432544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297432544)
            
            //--TRIMMABLE-BOUNDARY-START(4297432544)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297432544)
            
            static $h = 2465248;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887367136),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 2465248,
      "h": 12887367136,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12887367136),
//--TRIMMABLE-BOUNDARY-START(8592399840),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2465248,
      "h": 8592399840,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592399840)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297432544),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2465248,
      "h": 4297432544,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297432544)
  ],
  "h": 2465248
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2465248)
        
        

        //--TRIMMABLE-BOUNDARY-START(826848)
        $asm.$cls(`$yleQ.LCFCA.ApplicationServiceDescriptor`, ($self) => class ApplicationServiceDescriptor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(236224028128)
            /*string?*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(236224028128)
            
            //--TRIMMABLE-BOUNDARY-START(244813962720)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(244813962720)
            
            //--TRIMMABLE-BOUNDARY-START(390842850784)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(390842850784)
            
            //--TRIMMABLE-BOUNDARY-START(81605205472)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(81605205472)
            
            //--TRIMMABLE-BOUNDARY-START(231929060832)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(231929060832)
            
            //--TRIMMABLE-BOUNDARY-START(386547883488)
            /*ThemePack?*/ Theme = null;
            //--TRIMMABLE-BOUNDARY-END(386547883488)
            
            //--TRIMMABLE-BOUNDARY-START(85900172768)
            /*string?*/ Domain = null;
            //--TRIMMABLE-BOUNDARY-END(85900172768)
            
            //--TRIMMABLE-BOUNDARY-START(253403897312)
            /*string[]?*/ Paths = null;
            //--TRIMMABLE-BOUNDARY-END(253403897312)
            
            //--TRIMMABLE-BOUNDARY-START(240518995424)
            /*IEnumerable<ApplicationAssembly>?*/ MainAssemblies = null;
            //--TRIMMABLE-BOUNDARY-END(240518995424)
            
            //--TRIMMABLE-BOUNDARY-START(77310238176)
            /*IEnumerable<ApplicationAssembly>?*/ Dependencies = null;
            //--TRIMMABLE-BOUNDARY-END(77310238176)
            
            //--TRIMMABLE-BOUNDARY-START(399432785376)
            /*string?*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(399432785376)
            
            //--TRIMMABLE-BOUNDARY-START(403727752672)
            /*string?*/ UIEntryType = null;
            //--TRIMMABLE-BOUNDARY-END(403727752672)
            
            //--TRIMMABLE-BOUNDARY-START(98785074656)
            /*ApplicationServiceFeatures*/ Features = 0;
            //--TRIMMABLE-BOUNDARY-END(98785074656)
            
            //--TRIMMABLE-BOUNDARY-START(73015270880)
            /*Frameworks.Common.Application.IApplicationProxy*/ Application = null;
            //--TRIMMABLE-BOUNDARY-END(73015270880)
            
            //--TRIMMABLE-BOUNDARY-START(249108930016)
            /*int*/ Order = 0;
            //--TRIMMABLE-BOUNDARY-END(249108930016)
            
            //--TRIMMABLE-BOUNDARY-START(395137818080)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137818080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name ?? $.$$.S.Object.ToString.call(this);
            }
            //--TRIMMABLE-BOUNDARY-END(395137818080)
            
            //--TRIMMABLE-BOUNDARY-START(90195140064)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195140064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                if ($.$is(obj, $.$yleQ.LCFCA.ApplicationServiceDescriptor, { set $v($v){ other = $v; } }))
                {
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca1__;
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca2__;
                    return this.Id === other.Id || $.$fPer.LCFCA.ApplicationAssembly.op_Implicit((__ca1__ = this.MainAssemblies) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA.ApplicationAssembly, __ca1__) : null) === $.$fPer.LCFCA.ApplicationAssembly.op_Implicit((__ca2__ = other.MainAssemblies) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA.ApplicationAssembly, __ca2__) : null);
                }
                return $.$$.S.Object.Equals$1.call(this, obj);
            }
            //--TRIMMABLE-BOUNDARY-END(90195140064)
            
            //--TRIMMABLE-BOUNDARY-START(94490107360)
            /*bool */ Equals$2(/*ApplicationServiceDescriptor?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490107360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca3__;
                /*LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor?*/ let __ca4__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Application.ApplicationAssembly>?*/ let __ca5__;
                return this.Id === (other?.Id ?? null) || $.$fPer.LCFCA.ApplicationAssembly.op_Implicit((__ca3__ = this.MainAssemblies) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA.ApplicationAssembly, __ca3__) : null) === $.$fPer.LCFCA.ApplicationAssembly.op_Implicit((__ca4__ = other) !== null ? ((__ca5__ = __ca4__.MainAssemblies) !== null ? $.$sl.SL.Enumerable.FirstOrDefault$3($.$fPer.LCFCA.ApplicationAssembly, __ca5__) : null) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(94490107360)
            
            //--TRIMMABLE-BOUNDARY-START(47246843360)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Id.get
            get LCFCA$IApplicationServiceProxy$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901549024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(47246843360)
            
            //--TRIMMABLE-BOUNDARY-START(55836777952)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.MainAssemblies.get
            get LCFCA$IApplicationServiceProxy$MainAssemblies()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196516320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MainAssemblies;
            }
            //--TRIMMABLE-BOUNDARY-END(55836777952)
            
            //--TRIMMABLE-BOUNDARY-START(30066974176)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Dependencies.get
            get LCFCA$IApplicationServiceProxy$Dependencies()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592137696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dependencies;
            }
            //--TRIMMABLE-BOUNDARY-END(30066974176)
            
            //--TRIMMABLE-BOUNDARY-START(73016647136)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Type.get
            get LCFCA$IApplicationServiceProxy$Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786450912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Type;
            }
            //--TRIMMABLE-BOUNDARY-END(73016647136)
            
            //--TRIMMABLE-BOUNDARY-START(81606581728)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.UIEntryType.get
            get LCFCA$IApplicationServiceProxy$UIEntryType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081418208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UIEntryType;
            }
            //--TRIMMABLE-BOUNDARY-END(81606581728)
            
            //--TRIMMABLE-BOUNDARY-START(21477039584)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Application.get
            get LCFCA$IApplicationServiceProxy$Application()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297170400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Application;
            }
            //--TRIMMABLE-BOUNDARY-END(21477039584)
            
            //--TRIMMABLE-BOUNDARY-START(38656908768)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Features.get
            get LCFCA$IApplicationServiceProxy$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887104992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(38656908768)
            
            //--TRIMMABLE-BOUNDARY-START(64426712544)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Paths.get
            get LCFCA$IApplicationServiceProxy$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491483616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(64426712544)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8610351446)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOrderedData.Order.get
            get LCFCD$IOrderedData$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12905318742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8610351446)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor>.Equals(LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor?)
            S$IEquatable$LivingThing$Core$Frameworks$Common$Application$ApplicationServiceDescriptor$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(68720303584)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720303584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720303584)
            
            //--TRIMMABLE-BOUNDARY-START(68720303584)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(68720303584)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(231929060832)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(231929060832)
                
                //--TRIMMABLE-BOUNDARY-START(73015270880)
                this.Application = null;
                //--TRIMMABLE-BOUNDARY-END(73015270880)
                
            }
            static $h = 826848;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(236224028128),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914616800,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313533439456,
        "f": 83886081
      },
      "n": "Id",
      "d": 826848,
      "h": 236224028128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224028128),
//--TRIMMABLE-BOUNDARY-START(244813962720),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094485984,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330713308640,
        "f": 83886081
      },
      "n": "Name",
      "d": 826848,
      "h": 244813962720,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244813962720),
//--TRIMMABLE-BOUNDARY-START(390842850784),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210454224352,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365073047008,
        "f": 83886081
      },
      "n": "Title",
      "d": 826848,
      "h": 390842850784,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(390842850784),
//--TRIMMABLE-BOUNDARY-START(81605205472),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554878432,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173701088,
        "f": 83886081
      },
      "n": "Description",
      "d": 826848,
      "h": 81605205472,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605205472),
//--TRIMMABLE-BOUNDARY-START(231929060832),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324682208,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943504864,
        "f": 83886081
      },
      "n": "Icon",
      "d": 826848,
      "h": 231929060832,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231929060832),
//--TRIMMABLE-BOUNDARY-START(386547883488),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864289760,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356483112416,
        "f": 83886081
      },
      "n": "Theme",
      "d": 826848,
      "h": 386547883488,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(386547883488),
//--TRIMMABLE-BOUNDARY-START(85900172768),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144813024,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763635680,
        "f": 83886081
      },
      "n": "Domain",
      "d": 826848,
      "h": 85900172768,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900172768),
//--TRIMMABLE-BOUNDARY-START(253403897312),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274355168,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347893177824,
        "f": 83886081
      },
      "n": "Paths",
      "d": 826848,
      "h": 253403897312,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403897312),
//--TRIMMABLE-BOUNDARY-START(240518995424),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504551392,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322123374048,
        "f": 83886081
      },
      "n": "MainAssemblies",
      "d": 826848,
      "h": 240518995424,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240518995424),
//--TRIMMABLE-BOUNDARY-START(77310238176),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964943840,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583766496,
        "f": 83886081
      },
      "n": "Dependencies",
      "d": 826848,
      "h": 77310238176,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310238176),
//--TRIMMABLE-BOUNDARY-START(399432785376),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219044158944,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373662981600,
        "f": 83886081
      },
      "n": "Type",
      "d": 826848,
      "h": 399432785376,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(399432785376),
//--TRIMMABLE-BOUNDARY-START(403727752672),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634093536,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 382252916192,
        "f": 83886081
      },
      "n": "UIEntryType",
      "d": 826848,
      "h": 403727752672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(403727752672),
//--TRIMMABLE-BOUNDARY-START(98785074656),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734747616,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353570272,
        "f": 83886081
      },
      "n": "Features",
      "d": 826848,
      "h": 98785074656,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785074656),
//--TRIMMABLE-BOUNDARY-START(73015270880),
    {
      "p": 1482208,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375009248,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993831904,
        "f": 83886081
      },
      "n": "Application",
      "d": 826848,
      "h": 73015270880,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015270880),
//--TRIMMABLE-BOUNDARY-START(249108930016),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684420576,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339303243232,
        "f": 83886081
      },
      "n": "Order",
      "d": 826848,
      "h": 249108930016,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249108930016)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(395137818080),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 826848,
      "h": 395137818080,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(395137818080),
//--TRIMMABLE-BOUNDARY-START(90195140064),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 826848,
      "h": 90195140064,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195140064),
//--TRIMMABLE-BOUNDARY-START(94490107360),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 826848
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 826848,
      "h": 94490107360,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490107360)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(68720303584),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 826848,
      "h": 68720303584,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720303584)
  ],
  "h": 826848,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable, $.$$.S.IEquatable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationServiceDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(826848)
        
        

        //--TRIMMABLE-BOUNDARY-START(368096)
        $asm.$cls(`$yleQ.LCFCA.ApplicationDescriptor`, ($self) => class ApplicationDescriptor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(296353111520)
            /*string?*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(296353111520)
            
            //--TRIMMABLE-BOUNDARY-START(317827948000)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(317827948000)
            
            //--TRIMMABLE-BOUNDARY-START(111669517792)
            /*string[]?*/ Domains = null;
            //--TRIMMABLE-BOUNDARY-END(111669517792)
            
            //--TRIMMABLE-BOUNDARY-START(326417882592)
            /*string[]?*/ Paths = null;
            //--TRIMMABLE-BOUNDARY-END(326417882592)
            
            //--TRIMMABLE-BOUNDARY-START(511101476320)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(511101476320)
            
            //--TRIMMABLE-BOUNDARY-START(107374550496)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(107374550496)
            
            //--TRIMMABLE-BOUNDARY-START(292058144224)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(292058144224)
            
            //--TRIMMABLE-BOUNDARY-START(90194681312)
            /*IEnumerable<string>?*/ Categories = null;
            //--TRIMMABLE-BOUNDARY-END(90194681312)
            
            //--TRIMMABLE-BOUNDARY-START(506806509024)
            /*ThemePack?*/ Theme = null;
            //--TRIMMABLE-BOUNDARY-END(506806509024)
            
            //--TRIMMABLE-BOUNDARY-START(115964485088)
            /*ApplicationServiceFeatures*/ Features = 0;
            //--TRIMMABLE-BOUNDARY-END(115964485088)
            
            //--TRIMMABLE-BOUNDARY-START(322122915296)
            /*int*/ Order = 0;
            //--TRIMMABLE-BOUNDARY-END(322122915296)
            
            //--TRIMMABLE-BOUNDARY-START(313532980704)
            /*IEnumerable<ApplicationAssembly>?*/ MainAssemblies = null;
            //--TRIMMABLE-BOUNDARY-END(313532980704)
            
            //--TRIMMABLE-BOUNDARY-START(103079583200)
            /*IEnumerable<ApplicationAssembly>?*/ Dependencies = null;
            //--TRIMMABLE-BOUNDARY-END(103079583200)
            
            //--TRIMMABLE-BOUNDARY-START(523986378208)
            /*string?*/ UIEntryType = null;
            //--TRIMMABLE-BOUNDARY-END(523986378208)
            
            //--TRIMMABLE-BOUNDARY-START(330712849888)
            /*IEnumerable<ApplicationServiceDescriptor>?*/ serviceModules = null;
            //--TRIMMABLE-BOUNDARY-END(330712849888)
            
            //--TRIMMABLE-BOUNDARY-START(335007817184)
            /*IEnumerable<ApplicationServiceDescriptor>? */ get ServiceModules()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813503968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.serviceModules !== null)
                {
                    let $en1 = this.serviceModules.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let sm = $en1.SCG$IEnumerator$$$Current;
                        {
                            sm.Application = this;
                        }
                    }
                }
                return this.serviceModules;
            }
            /*IEnumerable<ApplicationServiceDescriptor>? */ set ServiceModules(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459561868768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.serviceModules = value;
            }
            //--TRIMMABLE-BOUNDARY-END(335007817184)
            
            //--TRIMMABLE-BOUNDARY-START(519691410912)
            /*string?*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(519691410912)
            
            //--TRIMMABLE-BOUNDARY-START(339302784480)
            /*string?*/ ServiceType = null;
            //--TRIMMABLE-BOUNDARY-END(339302784480)
            
            //--TRIMMABLE-BOUNDARY-START(98784615904)
            /*string?*/ CreateLink = null;
            //--TRIMMABLE-BOUNDARY-END(98784615904)
            
            //--TRIMMABLE-BOUNDARY-START(94489648608)
            /*string?*/ CreateLabel = null;
            //--TRIMMABLE-BOUNDARY-END(94489648608)
            
            //--TRIMMABLE-BOUNDARY-START(85899714016)
            /*Frameworks.Common.Application.IApplicationProxy */ get Application()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85899714016)
            
            //--TRIMMABLE-BOUNDARY-START(309238013408)
            /*IEnumerable<IApplicationServiceProxy>? */ get LCFCA$IApplicationProxy$Services()
            {
                return $.$$.N.InterfaceVarianceStubHandler.Create(this.ServiceModules, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor), $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy));
            }
            //--TRIMMABLE-BOUNDARY-END(309238013408)
            
            //--TRIMMABLE-BOUNDARY-START(515396443616)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515396443616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name ?? $.$$.S.Object.ToString.call(this);
            }
            //--TRIMMABLE-BOUNDARY-END(515396443616)
            
            //--TRIMMABLE-BOUNDARY-START(25772137952)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.ICreatorApplicationProxy.CreateLink.get
            get LCFCA$ICreatorApplicationProxy$CreateLink()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592268768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLink;
            }
            //--TRIMMABLE-BOUNDARY-END(25772137952)
            
            //--TRIMMABLE-BOUNDARY-START(17182203360)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.ICreatorApplicationProxy.CreateLabel.get
            get LCFCA$ICreatorApplicationProxy$CreateLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297301472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLabel;
            }
            //--TRIMMABLE-BOUNDARY-END(17182203360)
            
            //--TRIMMABLE-BOUNDARY-START(17181351392)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationProxy.Domains.get
            get LCFCA$IApplicationProxy$Domains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296449504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Domains;
            }
            //--TRIMMABLE-BOUNDARY-END(17181351392)
            
            //--TRIMMABLE-BOUNDARY-START(34361220576)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationProxy.Paths.get
            get LCFCA$IApplicationProxy$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836057056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(34361220576)
            
            //--TRIMMABLE-BOUNDARY-START(25771285984)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationProxy.Features.get
            get LCFCA$IApplicationProxy$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591416800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(25771285984)
            
            //--TRIMMABLE-BOUNDARY-START(51541089760)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationProxy.ServiceType.get
            get LCFCA$IApplicationProxy$ServiceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425991648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceType;
            }
            //--TRIMMABLE-BOUNDARY-END(51541089760)
            
            //--TRIMMABLE-BOUNDARY-START(47246843360)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Id.get
            get LCFCA$IApplicationServiceProxy$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901549024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(47246843360)
            
            //--TRIMMABLE-BOUNDARY-START(55836777952)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.MainAssemblies.get
            get LCFCA$IApplicationServiceProxy$MainAssemblies()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196516320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MainAssemblies;
            }
            //--TRIMMABLE-BOUNDARY-END(55836777952)
            
            //--TRIMMABLE-BOUNDARY-START(30066974176)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Dependencies.get
            get LCFCA$IApplicationServiceProxy$Dependencies()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592137696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dependencies;
            }
            //--TRIMMABLE-BOUNDARY-END(30066974176)
            
            //--TRIMMABLE-BOUNDARY-START(73016647136)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Type.get
            get LCFCA$IApplicationServiceProxy$Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786450912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Type;
            }
            //--TRIMMABLE-BOUNDARY-END(73016647136)
            
            //--TRIMMABLE-BOUNDARY-START(81606581728)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.UIEntryType.get
            get LCFCA$IApplicationServiceProxy$UIEntryType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081418208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UIEntryType;
            }
            //--TRIMMABLE-BOUNDARY-END(81606581728)
            
            //--TRIMMABLE-BOUNDARY-START(21477039584)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Application.get
            get LCFCA$IApplicationServiceProxy$Application()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297170400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Application;
            }
            //--TRIMMABLE-BOUNDARY-END(21477039584)
            
            //--TRIMMABLE-BOUNDARY-START(38656908768)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Features.get
            get LCFCA$IApplicationServiceProxy$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887104992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(38656908768)
            
            //--TRIMMABLE-BOUNDARY-START(64426712544)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Application.IApplicationServiceProxy.Paths.get
            get LCFCA$IApplicationServiceProxy$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491483616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(64426712544)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(8610351446)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IOrderedData.Order.get
            get LCFCD$IOrderedData$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12905318742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8610351446)
            
            //--TRIMMABLE-BOUNDARY-START(8594742696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IThemable.Theme.get
            get LCFCC$IThemable$Theme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889709992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Theme;
            }
            //--TRIMMABLE-BOUNDARY-END(8594742696)
            
            //--TRIMMABLE-BOUNDARY-START(81604746720)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604746720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81604746720)
            
            //--TRIMMABLE-BOUNDARY-START(81604746720)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(81604746720)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(292058144224)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(292058144224)
                
                //--TRIMMABLE-BOUNDARY-START(115964485088)
                this.Features = 1120;
                //--TRIMMABLE-BOUNDARY-END(115964485088)
                
            }
            static $h = 368096;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(296353111520),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863831008,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 416612195808,
        "f": 83886081
      },
      "n": "Id",
      "d": 368096,
      "h": 296353111520,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(296353111520),
//--TRIMMABLE-BOUNDARY-START(317827948000),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043700192,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 433792064992,
        "f": 83886081
      },
      "n": "Name",
      "d": 368096,
      "h": 317827948000,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(317827948000),
//--TRIMMABLE-BOUNDARY-START(111669517792),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094027232,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 390842392032,
        "f": 83886081
      },
      "n": "Domains",
      "d": 368096,
      "h": 111669517792,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669517792),
//--TRIMMABLE-BOUNDARY-START(326417882592),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223569376,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 450971934176,
        "f": 83886081
      },
      "n": "Paths",
      "d": 368096,
      "h": 326417882592,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(326417882592),
//--TRIMMABLE-BOUNDARY-START(511101476320),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583307744,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 485331672544,
        "f": 83886081
      },
      "n": "Title",
      "d": 368096,
      "h": 511101476320,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(511101476320),
//--TRIMMABLE-BOUNDARY-START(107374550496),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504092640,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 382252457440,
        "f": 83886081
      },
      "n": "Description",
      "d": 368096,
      "h": 107374550496,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374550496),
//--TRIMMABLE-BOUNDARY-START(292058144224),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273896416,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 408022261216,
        "f": 83886081
      },
      "n": "Icon",
      "d": 368096,
      "h": 292058144224,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292058144224),
//--TRIMMABLE-BOUNDARY-START(90194681312),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144354272,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347892719072,
        "f": 83886081
      },
      "n": "Categories",
      "d": 368096,
      "h": 90194681312,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194681312),
//--TRIMMABLE-BOUNDARY-START(506806509024),
    {
      "p": 9854376,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993373152,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 476741737952,
        "f": 83886081
      },
      "n": "Theme",
      "d": 368096,
      "h": 506806509024,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(506806509024),
//--TRIMMABLE-BOUNDARY-START(115964485088),
    {
      "p": 1023456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683961824,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 399432326624,
        "f": 83886081
      },
      "n": "Features",
      "d": 368096,
      "h": 115964485088,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964485088),
//--TRIMMABLE-BOUNDARY-START(322122915296),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633634784,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 442381999584,
        "f": 83886081
      },
      "n": "Order",
      "d": 368096,
      "h": 322122915296,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(322122915296),
//--TRIMMABLE-BOUNDARY-START(313532980704),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453765600,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 425202130400,
        "f": 83886081
      },
      "n": "MainAssemblies",
      "d": 368096,
      "h": 313532980704,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313532980704),
//--TRIMMABLE-BOUNDARY-START(103079583200),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914158048,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373662522848,
        "f": 83886081
      },
      "n": "Dependencies",
      "d": 368096,
      "h": 103079583200,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079583200),
//--TRIMMABLE-BOUNDARY-START(523986378208),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287763176928,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 502511541728,
        "f": 83886081
      },
      "n": "UIEntryType",
      "d": 368096,
      "h": 523986378208,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(523986378208),
//--TRIMMABLE-BOUNDARY-START(335007817184),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813503968,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 459561868768,
        "f": 83886081
      },
      "n": "ServiceModules",
      "d": 368096,
      "h": 335007817184,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(335007817184),
//--TRIMMABLE-BOUNDARY-START(519691410912),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173242336,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 493921607136,
        "f": 83886081
      },
      "n": "Type",
      "d": 368096,
      "h": 519691410912,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(519691410912),
//--TRIMMABLE-BOUNDARY-START(339302784480),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403438560,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 468151803360,
        "f": 83886081
      },
      "n": "ServiceType",
      "d": 368096,
      "h": 339302784480,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(339302784480),
//--TRIMMABLE-BOUNDARY-START(98784615904),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324223456,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365072588256,
        "f": 83886081
      },
      "n": "CreateLink",
      "d": 368096,
      "h": 98784615904,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784615904),
//--TRIMMABLE-BOUNDARY-START(94489648608),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734288864,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356482653664,
        "f": 83886081
      },
      "n": "CreateLabel",
      "d": 368096,
      "h": 94489648608,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489648608),
//--TRIMMABLE-BOUNDARY-START(85899714016),
    {
      "p": 1482208,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554419680,
        "f": 50331649
      },
      "n": "Application",
      "d": 368096,
      "h": 85899714016,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899714016),
//--TRIMMABLE-BOUNDARY-START(309238013408),
    {
      "p": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.IApplicationServiceProxy).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304943046112,
        "f": 50331650
      },
      "n": "{1482208}.Services",
      "o": "LCFCA$IApplicationProxy$Services",
      "d": 368096,
      "h": 309238013408,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(309238013408)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(515396443616),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 368096,
      "h": 515396443616,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(515396443616)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(330712849888),
    {
      "t": $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor).$h,
      "n": "serviceModules",
      "d": 368096,
      "h": 330712849888,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(330712849888)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(81604746720),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 368096,
      "h": 81604746720,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604746720)
  ],
  "h": 368096,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$yleQ.LCFCA.ICreatorApplicationProxy, $.$yleQ.LCFCA.IApplicationProxy, $.$yleQ.LCFCA.IApplicationServiceProxy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IOrderedData, $.$vWqU.LCFCC.IThemable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(368096)
        
        

        //--TRIMMABLE-BOUNDARY-START(564704)
        $asm.$cls(`$yleQ.LCFCA.ApplicationPluginAttribute`, ($self) => class ApplicationPluginAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590499296)
            $ctor$2(/*params string[]*/ assemblies)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590499296);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Assemblies = assemblies;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590499296)
            
            //--TRIMMABLE-BOUNDARY-START(12885466592)
            /*string[]*/ Assemblies = null;
            //--TRIMMABLE-BOUNDARY-END(12885466592)
            
            static $h = 564704;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885466592),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475401184,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065335776,
        "f": 83886081
      },
      "n": "Assemblies",
      "d": 564704,
      "h": 12885466592,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885466592)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590499296),
    {
      "p": [
        {
          "n": "assemblies",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 564704,
      "h": 8590499296,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590499296)
  ],
  "h": 564704,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    },
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "Use RequiredAssemblyAttribute instead",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationPluginAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationPluginAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(564704)
        
        

        //--TRIMMABLE-BOUNDARY-START(105952)
        $asm.$cls(`$yleQ.LCFCA.ApplicationBaseUserPreference`, ($self) => class ApplicationBaseUserPreference extends $.$vWqU.LCFCC.ClientUserPreference
        {
            //--TRIMMABLE-BOUNDARY-START(4295073248)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295073248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295073248)
            
            //--TRIMMABLE-BOUNDARY-START(4295073248)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295073248)
            
            static $h = 105952;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$vWqU.LCFCC.ClientUserPreference; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295073248),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 105952,
      "h": 4295073248,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295073248)
  ],
  "h": 105952,
  "a": [
    {
      "t": 44665174,
      "c": 4339632470
    },
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationBaseUserPreference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationBaseUserPreference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(105952)
        
        

        //--TRIMMABLE-BOUNDARY-START(1613280)
        $asm.$cls(`$yleQ.LCFCA.IApplicationRemoteService_Mocking`, ($self) => class IApplicationRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296580576)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296580576);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296580576)
            
            //--TRIMMABLE-BOUNDARY-START(12886515168)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<string>> */ LCFCA$IApplicationRemoteService$GetDependencies(/*string*/ moduleName, /*LivingThing.Core.Frameworks.Common.RuntimeType*/ callerRuntime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886515168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$yleQ.LCFCA.IApplicationRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.String).$type;
                    $i1.MethodName = "GetDependencies";
                    return $i1;
                })();
                return this.InvokeAsync($.$yleQ.LCFCA.IApplicationRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.String), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, moduleName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFC.RuntimeType.$type, $.$box(callerRuntime, $.$fPer.LCFC.RuntimeType)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886515168)
            
            //--TRIMMABLE-BOUNDARY-START(8591547872)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptor>> */ LCFCA$IApplicationRemoteService$GetApplicationsDescriptor(/*LivingThing.Core.Frameworks.Common.RuntimeType*/ callerRuntime, /*bool*/ optimizedForSpecificApplications, /*System.Collections.Generic.IEnumerable<string>?*/ filterToApps)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591547872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$yleQ.LCFCA.IApplicationRemoteService.$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$yleQ.LCFCA.ApplicationsDescriptor).$type;
                    $i2.MethodName = "GetApplicationsDescriptor";
                    return $i2;
                })();
                return this.InvokeAsync($.$yleQ.LCFCA.IApplicationRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$yleQ.LCFCA.ApplicationsDescriptor), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFC.RuntimeType.$type, $.$box(callerRuntime, $.$fPer.LCFC.RuntimeType)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(optimizedForSpecificApplications, $.$$.S.Boolean)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.SCG.IEnumerable$$($.$$.S.String).$type, filterToApps) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591547872)
            
            static $h = 1613280;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296580576),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1613280,
      "h": 4296580576,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296580576)
  ],
  "h": 1613280
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$yleQ.LCFCA.IApplicationRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.IApplicationRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}IApplicationRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1613280)
        
        

        //--TRIMMABLE-BOUNDARY-START(1023456)
        $asm.$str(`$yleQ.LCFCA.ApplicationServiceFeatures`, ($self) => class ApplicationServiceFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static InDevelopment = 1;
            static InPreview = 2;
            static Recommended = 4;
            static Featured = 4;
            static Authorize = 8;
            static UseRouter = 16;
            static RequiresRootServiceToLoad = 32;
            static ShouldCompleteServiceLoadBeforeRender = 64;
            static LoadCategories = 128;
            static LoadPost = 256;
            static FullScreen = 512;
            static Published = 1024;
            static Default = 1120;
            static DefaultInPreview = 98;
            static DefaultInDevelopment = 97;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1023456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "InDevelopment": 1n,
                    "InPreview": 2n,
                    "Recommended": 4n,
                    "Featured": 4n,
                    "Authorize": 8n,
                    "UseRouter": 16n,
                    "RequiresRootServiceToLoad": 32n,
                    "ShouldCompleteServiceLoadBeforeRender": 64n,
                    "LoadCategories": 128n,
                    "LoadPost": 256n,
                    "FullScreen": 512n,
                    "Published": 1024n,
                    "Default": 1120n,
                    "DefaultInPreview": 98n,
                    "DefaultInDevelopment": 97n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295990752)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295990752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295990752)
            
            //--TRIMMABLE-BOUNDARY-START(4295990752)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295990752)
            
            static $h = 1023456;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540631008),
    {
      "t": 1023456,
      "n": "None",
      "d": 1023456,
      "h": 51540631008,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540631008),
//--TRIMMABLE-BOUNDARY-START(34360761824),
    {
      "t": 1023456,
      "n": "InDevelopment",
      "d": 1023456,
      "h": 34360761824,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360761824),
//--TRIMMABLE-BOUNDARY-START(38655729120),
    {
      "t": 1023456,
      "n": "InPreview",
      "d": 1023456,
      "h": 38655729120,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655729120),
//--TRIMMABLE-BOUNDARY-START(60130565600),
    {
      "t": 1023456,
      "n": "Recommended",
      "d": 1023456,
      "h": 60130565600,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130565600),
//--TRIMMABLE-BOUNDARY-START(25770827232),
    {
      "t": 1023456,
      "n": "Featured",
      "d": 1023456,
      "h": 25770827232,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770827232),
//--TRIMMABLE-BOUNDARY-START(8590958048),
    {
      "t": 1023456,
      "n": "Authorize",
      "d": 1023456,
      "h": 8590958048,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590958048),
//--TRIMMABLE-BOUNDARY-START(73015467488),
    {
      "t": 1023456,
      "n": "UseRouter",
      "d": 1023456,
      "h": 73015467488,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015467488),
//--TRIMMABLE-BOUNDARY-START(64425532896),
    {
      "t": 1023456,
      "n": "RequiresRootServiceToLoad",
      "d": 1023456,
      "h": 64425532896,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425532896),
//--TRIMMABLE-BOUNDARY-START(68720500192),
    {
      "t": 1023456,
      "n": "ShouldCompleteServiceLoadBeforeRender",
      "d": 1023456,
      "h": 68720500192,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720500192),
//--TRIMMABLE-BOUNDARY-START(42950696416),
    {
      "t": 1023456,
      "n": "LoadCategories",
      "d": 1023456,
      "h": 42950696416,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950696416),
//--TRIMMABLE-BOUNDARY-START(47245663712),
    {
      "t": 1023456,
      "n": "LoadPost",
      "d": 1023456,
      "h": 47245663712,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245663712),
//--TRIMMABLE-BOUNDARY-START(30065794528),
    {
      "t": 1023456,
      "n": "FullScreen",
      "d": 1023456,
      "h": 30065794528,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065794528),
//--TRIMMABLE-BOUNDARY-START(55835598304),
    {
      "t": 1023456,
      "n": "Published",
      "d": 1023456,
      "h": 55835598304,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835598304),
//--TRIMMABLE-BOUNDARY-START(12885925344),
    {
      "t": 1023456,
      "n": "Default",
      "d": 1023456,
      "h": 12885925344,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885925344),
//--TRIMMABLE-BOUNDARY-START(21475859936),
    {
      "t": 1023456,
      "n": "DefaultInPreview",
      "d": 1023456,
      "h": 21475859936,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475859936),
//--TRIMMABLE-BOUNDARY-START(17180892640),
    {
      "t": 1023456,
      "n": "DefaultInDevelopment",
      "d": 1023456,
      "h": 17180892640,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180892640)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295990752),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1023456,
      "h": 4295990752,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295990752)
  ],
  "h": 1023456,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    },
    {
      "t": 45123926,
      "c": 4340091222
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationServiceFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationServiceFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1023456)
        
        

        //--TRIMMABLE-BOUNDARY-START(2858464)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor`, ($self) => class ApplicationManifestIconTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCP.ApplicationManifestIcon)
        {
            //--TRIMMABLE-BOUNDARY-START(4297825760)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297825760);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor.GenerateProperties($.$yleQ.LCFCP.ApplicationManifestIcon, this, factory);
                    }, $XfdZba ??= {"r":65537,"n":"","d":2858464,"h":0,"f":17825794}), 0, "ApplicationManifestIconTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Application\\ApplicationIcon_LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIconTypeDescriptorBuilder.g.cs", "ApplicationManifestIconTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297825760)
            
            //--TRIMMABLE-BOUNDARY-START(12887760352)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887760352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Source"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifestIcon.$type, $.$discardRef(), "Source", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Source")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Source";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIcon";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifestIcon)).Source);
                        }, $WQoYJk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2858464,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Source = value.AsReference($.$$.S.String);
                        }, $ygZYDe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2858464,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Sizes"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifestIcon.$type, $.$discardRef(), "Sizes", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Sizes")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Sizes";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIcon";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifestIcon)).Sizes);
                        }, $MTmUve ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2858464,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Sizes = value.AsReference($.$$.S.String);
                        }, $dmhAee ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2858464,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MimeType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifestIcon.$type, $.$discardRef(), "MimeType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MimeType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "MimeType";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIcon";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifestIcon)).MimeType);
                        }, $ohyeTd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2858464,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MimeType = value.AsReference($.$$.S.String);
                        }, $PYeVmk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2858464,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887760352)
            
            //--TRIMMABLE-BOUNDARY-START(17182727648)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIcon*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182727648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Source = _target.Source;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Source"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Source, ($v) => _Source = $v, $.$$.S.String)))
                    {
                        _target.Source = _Source;
                    }
                }
                {
                    /*var*/ let _Sizes = _target.Sizes;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Sizes"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Sizes, ($v) => _Sizes = $v, $.$$.S.String)))
                    {
                        _target.Sizes = _Sizes;
                    }
                }
                {
                    /*var*/ let _MimeType = _target.MimeType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MimeType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _MimeType, ($v) => _MimeType = $v, $.$$.S.String)))
                    {
                        _target.MimeType = _MimeType;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182727648)
            
            //--TRIMMABLE-BOUNDARY-START(8592793056)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIcon?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592793056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yleQ.LCFCP.ApplicationManifestIcon().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yleQ.LCFCP.ApplicationManifestIcon, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCP.ApplicationManifestIcon)))
                {
                    /*var*/ let result = $.$yleQ.LCFCP.ApplicationManifestIconTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCP.ApplicationManifestIcon));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yleQ.LCFCP.ApplicationManifestIcon, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCP.ApplicationManifestIcon));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592793056)
            
            static $h = 2858464;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCP.ApplicationManifestIcon); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887760352),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2858464,
      "h": 12887760352,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887760352),
//--TRIMMABLE-BOUNDARY-START(17182727648),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2727392,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2858464,
      "h": 17182727648,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182727648),
//--TRIMMABLE-BOUNDARY-START(8592793056),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2727392,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2858464,
      "h": 8592793056,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592793056)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297825760),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2858464,
      "h": 4297825760,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297825760)
  ],
  "h": 2858464
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yleQ.LCFCP.ApplicationManifestIcon), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestIconTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestIconTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2858464)
        
        

        //--TRIMMABLE-BOUNDARY-START(3120608)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor`, ($self) => class ApplicationManifestScreenShotTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCP.ApplicationManifestScreenShot)
        {
            //--TRIMMABLE-BOUNDARY-START(4298087904)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298087904);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor.GenerateProperties($.$yleQ.LCFCP.ApplicationManifestScreenShot, this, factory);
                    }, $cCsPQb ??= {"r":65537,"n":"","d":3120608,"h":0,"f":17825794}), 0, "ApplicationManifestScreenShotTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Application\\ApplicationManifestScreenShot_LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShotTypeDescriptorBuilder.g.cs", "ApplicationManifestScreenShotTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298087904)
            
            //--TRIMMABLE-BOUNDARY-START(12888022496)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888022496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Source"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifestScreenShot.$type, $.$discardRef(), "Source", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Source")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Source";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShot";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifestScreenShot)).Source);
                        }, $YEOGng ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3120608,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Source = value.AsReference($.$$.S.String);
                        }, $hodGIa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3120608,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Sizes"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifestScreenShot.$type, $.$discardRef(), "Sizes", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Sizes")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Sizes";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShot";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifestScreenShot)).Sizes);
                        }, $BqItQf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3120608,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Sizes = value.AsReference($.$$.S.String);
                        }, $aJLUci ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3120608,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MimeType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifestScreenShot.$type, $.$discardRef(), "MimeType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MimeType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "MimeType";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShot";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifestScreenShot)).MimeType);
                        }, $qhMMck ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3120608,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MimeType = value.AsReference($.$$.S.String);
                        }, $LkYrTi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3120608,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FormFactor"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifestScreenShot.$type, $.$discardRef(), "FormFactor", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FormFactor")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "FormFactor";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShot";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifestScreenShot)).FormFactor);
                        }, $XEKuEi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3120608,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FormFactor = value.AsReference($.$$.S.String);
                        }, $yuZtke ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3120608,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888022496)
            
            //--TRIMMABLE-BOUNDARY-START(17182989792)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShot*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182989792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Source = _target.Source;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Source"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Source, ($v) => _Source = $v, $.$$.S.String)))
                    {
                        _target.Source = _Source;
                    }
                }
                {
                    /*var*/ let _Sizes = _target.Sizes;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Sizes"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Sizes, ($v) => _Sizes = $v, $.$$.S.String)))
                    {
                        _target.Sizes = _Sizes;
                    }
                }
                {
                    /*var*/ let _MimeType = _target.MimeType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MimeType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _MimeType, ($v) => _MimeType = $v, $.$$.S.String)))
                    {
                        _target.MimeType = _MimeType;
                    }
                }
                {
                    /*var*/ let _FormFactor = _target.FormFactor;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FormFactor"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _FormFactor, ($v) => _FormFactor = $v, $.$$.S.String)))
                    {
                        _target.FormFactor = _FormFactor;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182989792)
            
            //--TRIMMABLE-BOUNDARY-START(8593055200)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShot?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593055200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yleQ.LCFCP.ApplicationManifestScreenShot().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yleQ.LCFCP.ApplicationManifestScreenShot, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCP.ApplicationManifestScreenShot)))
                {
                    /*var*/ let result = $.$yleQ.LCFCP.ApplicationManifestScreenShotTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCP.ApplicationManifestScreenShot));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yleQ.LCFCP.ApplicationManifestScreenShot, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCP.ApplicationManifestScreenShot));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593055200)
            
            static $h = 3120608;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCP.ApplicationManifestScreenShot); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888022496),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3120608,
      "h": 12888022496,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888022496),
//--TRIMMABLE-BOUNDARY-START(17182989792),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2989536,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3120608,
      "h": 17182989792,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182989792),
//--TRIMMABLE-BOUNDARY-START(8593055200),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2989536,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3120608,
      "h": 8593055200,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593055200)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298087904),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3120608,
      "h": 4298087904,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298087904)
  ],
  "h": 3120608
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yleQ.LCFCP.ApplicationManifestScreenShot), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestScreenShotTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestScreenShotTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3120608)
        
        

        //--TRIMMABLE-BOUNDARY-START(3251680)
        $asm.$cls(`$yleQ.LCFCP.ApplicationManifestTypeDescriptor`, ($self) => class ApplicationManifestTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCP.ApplicationManifest)
        {
            //--TRIMMABLE-BOUNDARY-START(4298218976)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298218976);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yleQ.LCFCP.ApplicationManifestTypeDescriptor.GenerateProperties($.$yleQ.LCFCP.ApplicationManifest, this, factory);
                    }, $FqWgPi ??= {"r":65537,"n":"","d":3251680,"h":0,"f":17825794}), 0, "ApplicationManifestTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Application\\ApplicationManifest_LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestTypeDescriptorBuilder.g.cs", "ApplicationManifestTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298218976)
            
            //--TRIMMABLE-BOUNDARY-START(12888153568)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888153568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).Id);
                        }, $bHDYmj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $FWqMXc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Name";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).Name);
                        }, $ROJWEd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Name = value.AsReference($.$$.S.String);
                        }, $rjAUYg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ShortName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "ShortName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ShortName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "ShortName";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).ShortName);
                        }, $jbNHcd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ShortName = value.AsReference($.$$.S.String);
                        }, $aJvlvb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Description";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).Description);
                        }, $EvNzuj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Description = value.AsReference($.$$.S.String);
                        }, $kgGZFf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StartUrl"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "StartUrl", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StartUrl")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "StartUrl";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).StartUrl);
                        }, $uKAvdk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.StartUrl = value.AsReference($.$$.S.String);
                        }, $jdCrvd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Display"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "Display", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Display")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Display";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).Display);
                        }, $erhDoc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Display = value.AsReference($.$$.S.String);
                        }, $Aznlck ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BackgroundColor"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "BackgroundColor", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BackgroundColor")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "BackgroundColor";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).BackgroundColor);
                        }, $REQAqf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BackgroundColor = value.AsReference($.$$.S.String);
                        }, $oConnf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ThemeColor"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "ThemeColor", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ThemeColor")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "ThemeColor";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).ThemeColor);
                        }, $YLYYoe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ThemeColor = value.AsReference($.$$.S.String);
                        }, $ozqMki ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PreferRelatedApplications"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "PreferRelatedApplications", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PreferRelatedApplications")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "PreferRelatedApplications";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).PreferRelatedApplications);
                        }, $wsHpBe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PreferRelatedApplications = value.AsBool();
                        }, $oUSTXi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Language"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "Language", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Language")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Language";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).Language);
                        }, $wtRvXb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Language = value.AsReference($.$$.S.String);
                        }, $BSDBpc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Categories"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "Categories", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Categories")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "Categories";
                        $i21.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.String), ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).Categories);
                        }, $JoFHac ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Categories = value.AsReference($.$typeArray($.$$.S.String));
                        }, $xGicef ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icons"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "Icons", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icons")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$yleQ.LCFCP.ApplicationManifestIcon), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "Icons";
                        $i23.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$yleQ.LCFCP.ApplicationManifestIcon), ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).Icons);
                        }, $RNVSdg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Icons = value.AsReference($.$typeArray($.$yleQ.LCFCP.ApplicationManifestIcon));
                        }, $xPSOge ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ScreenShots"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCP.ApplicationManifest.$type, $.$discardRef(), "ScreenShots", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ScreenShots")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$yleQ.LCFCP.ApplicationManifestScreenShot), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "ScreenShots";
                        $i25.DelaredOn = "LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$yleQ.LCFCP.ApplicationManifestScreenShot), ($.$cast(target, $.$yleQ.LCFCP.ApplicationManifest)).ScreenShots);
                        }, $UsKHZb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3251680,"h":0,"f":17825826});
                        $i25.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCP.ApplicationManifestTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ScreenShots = value.AsReference($.$typeArray($.$yleQ.LCFCP.ApplicationManifestScreenShot));
                        }, $CnpVha ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3251680,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888153568)
            
            //--TRIMMABLE-BOUNDARY-START(17183120864)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183120864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                        _target.Name = _Name;
                    }
                }
                {
                    /*var*/ let _ShortName = _target.ShortName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ShortName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ShortName, ($v) => _ShortName = $v, $.$$.S.String)))
                    {
                        _target.ShortName = _ShortName;
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                        _target.Description = _Description;
                    }
                }
                {
                    /*var*/ let _StartUrl = _target.StartUrl;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StartUrl"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _StartUrl, ($v) => _StartUrl = $v, $.$$.S.String)))
                    {
                        _target.StartUrl = _StartUrl;
                    }
                }
                {
                    /*var*/ let _Display = _target.Display;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Display"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Display, ($v) => _Display = $v, $.$$.S.String)))
                    {
                        _target.Display = _Display;
                    }
                }
                {
                    /*var*/ let _BackgroundColor = _target.BackgroundColor;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BackgroundColor"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _BackgroundColor, ($v) => _BackgroundColor = $v, $.$$.S.String)))
                    {
                        _target.BackgroundColor = _BackgroundColor;
                    }
                }
                {
                    /*var*/ let _ThemeColor = _target.ThemeColor;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ThemeColor"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ThemeColor, ($v) => _ThemeColor = $v, $.$$.S.String)))
                    {
                        _target.ThemeColor = _ThemeColor;
                    }
                }
                {
                    /*var*/ let _PreferRelatedApplications = _target.PreferRelatedApplications;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PreferRelatedApplications"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _PreferRelatedApplications, ($v) => _PreferRelatedApplications = $v, null, true)))
                    {
                        _target.PreferRelatedApplications = _PreferRelatedApplications;
                    }
                }
                {
                    /*var*/ let _Language = _target.Language;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Language"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Language, ($v) => _Language = $v, $.$$.S.String)))
                    {
                        _target.Language = _Language;
                    }
                }
                {
                    /*var*/ let _Categories = _target.Categories;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Categories"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Categories, ($v) => _Categories = $v, $.$typeArray($.$$.S.String))))
                    {
                        _target.Categories = _Categories;
                        if (_Categories !== null)
                        {
                            let $i38 = 0;
                            let $arr38 = _Categories;
                            while ($i38 < $arr38.length)
                            {
                                let item = $arr38[$i38++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Categories, ($v) => _Categories = $v, $.$typeArray($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Icons = _target.Icons;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icons"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$yleQ.LCFCP.ApplicationManifestIcon)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$yleQ.LCFCP.ApplicationManifestIcon), $.$yleQ.LCFCP.ApplicationManifestIcon));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$yleQ.LCFCP.ApplicationManifestIcon), $.$yleQ.LCFCP.ApplicationManifestIcon, property, $.$ref(() => _Icons, ($v) => _Icons = $v, $.$typeArray($.$yleQ.LCFCP.ApplicationManifestIcon))))
                    {
                        _target.Icons = _Icons;
                        if (_Icons !== null)
                        {
                            let $i43 = 0;
                            let $arr43 = _Icons;
                            while ($i43 < $arr43.length)
                            {
                                let item = $arr43[$i43++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$yleQ.LCFCP.ApplicationManifestIcon)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$yleQ.LCFCP.ApplicationManifestIcon), $.$yleQ.LCFCP.ApplicationManifestIcon, property, $.$ref(() => _Icons, ($v) => _Icons = $v, $.$typeArray($.$yleQ.LCFCP.ApplicationManifestIcon)));
                    }
                }
                {
                    /*var*/ let _ScreenShots = _target.ScreenShots;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ScreenShots"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$yleQ.LCFCP.ApplicationManifestScreenShot)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$yleQ.LCFCP.ApplicationManifestScreenShot), $.$yleQ.LCFCP.ApplicationManifestScreenShot));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$yleQ.LCFCP.ApplicationManifestScreenShot), $.$yleQ.LCFCP.ApplicationManifestScreenShot, property, $.$ref(() => _ScreenShots, ($v) => _ScreenShots = $v, $.$typeArray($.$yleQ.LCFCP.ApplicationManifestScreenShot))))
                    {
                        _target.ScreenShots = _ScreenShots;
                        if (_ScreenShots !== null)
                        {
                            let $i48 = 0;
                            let $arr48 = _ScreenShots;
                            while ($i48 < $arr48.length)
                            {
                                let item = $arr48[$i48++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$yleQ.LCFCP.ApplicationManifestScreenShot)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$yleQ.LCFCP.ApplicationManifestScreenShot), $.$yleQ.LCFCP.ApplicationManifestScreenShot, property, $.$ref(() => _ScreenShots, ($v) => _ScreenShots = $v, $.$typeArray($.$yleQ.LCFCP.ApplicationManifestScreenShot)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183120864)
            
            //--TRIMMABLE-BOUNDARY-START(8593186272)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.PWA.ApplicationManifest?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593186272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yleQ.LCFCP.ApplicationManifest, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCP.ApplicationManifest)))
                {
                    /*var*/ let result = $.$yleQ.LCFCP.ApplicationManifestTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCP.ApplicationManifest));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yleQ.LCFCP.ApplicationManifest, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCP.ApplicationManifest));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593186272)
            
            static $h = 3251680;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCP.ApplicationManifest); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888153568),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3251680,
      "h": 12888153568,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888153568),
//--TRIMMABLE-BOUNDARY-START(17183120864),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2596320,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3251680,
      "h": 17183120864,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183120864),
//--TRIMMABLE-BOUNDARY-START(8593186272),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2596320,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3251680,
      "h": 8593186272,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593186272)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298218976),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3251680,
      "h": 4298218976,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298218976)
  ],
  "h": 3251680
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yleQ.LCFCP.ApplicationManifest), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.PWA.ApplicationManifestTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}PWA${separator}ApplicationManifestTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3251680)
        
        

        //--TRIMMABLE-BOUNDARY-START(695776)
        $asm.$cls(`$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor`, ($self) => class ApplicationsDescriptorTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCA.ApplicationsDescriptor)
        {
            //--TRIMMABLE-BOUNDARY-START(4295663072)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295663072);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor.GenerateProperties($.$yleQ.LCFCA.ApplicationsDescriptor, this, factory);
                    }, $FGAcJg ??= {"r":65537,"n":"","d":695776,"h":0,"f":17825794}), 0, "ApplicationsDescriptorTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Application\\ApplicationsDescriptor_LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptorTypeDescriptorBuilder.g.cs", "ApplicationsDescriptorTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295663072)
            
            //--TRIMMABLE-BOUNDARY-START(12885597664)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885597664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LazyLoadingEnabled"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationsDescriptor.$type, $.$discardRef(), "LazyLoadingEnabled", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LazyLoadingEnabled")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "LazyLoadingEnabled";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptor";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$yleQ.LCFCA.ApplicationsDescriptor)).LazyLoadingEnabled);
                        }, $Pptmwa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":695776,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LazyLoadingEnabled = value.AsBool();
                        }, $EWkcdl ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":695776,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Applications"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationsDescriptor.$type, $.$discardRef(), "Applications", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Applications")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Applications";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptor";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor), ($.$cast(target, $.$yleQ.LCFCA.ApplicationsDescriptor)).Applications);
                        }, $VIjvub ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":695776,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Applications = value.AsReference($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor));
                        }, $bEjInf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":695776,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DomainMappings"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationsDescriptor.$type, $.$discardRef(), "DomainMappings", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DomainMappings")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationDomainMapping), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "DomainMappings";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptor";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationDomainMapping), ($.$cast(target, $.$yleQ.LCFCA.ApplicationsDescriptor)).DomainMappings);
                        }, $VMBIFh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":695776,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DomainMappings = value.AsReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationDomainMapping));
                        }, $hrKlhe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":695776,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Settings"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationsDescriptor.$type, $.$discardRef(), "Settings", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Settings")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$Iaui.LCFCMS.GlobalSettings, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Settings";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptor";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$Iaui.LCFCMS.GlobalSettings, ($.$cast(target, $.$yleQ.LCFCA.ApplicationsDescriptor)).Settings);
                        }, $CGzXbj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":695776,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Settings = value.AsReference($.$Iaui.LCFCMS.GlobalSettings);
                        }, $RGmQRk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":695776,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885597664)
            
            //--TRIMMABLE-BOUNDARY-START(17180564960)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptor*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180564960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _LazyLoadingEnabled = _target.LazyLoadingEnabled;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LazyLoadingEnabled"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _LazyLoadingEnabled, ($v) => _LazyLoadingEnabled = $v, null, true)))
                    {
                        _target.LazyLoadingEnabled = _LazyLoadingEnabled;
                    }
                }
                {
                    /*var*/ let _Applications = _target.Applications;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Applications"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor), $.$yleQ.LCFCA.ApplicationDescriptor));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor), $.$yleQ.LCFCA.ApplicationDescriptor, property, $.$ref(() => _Applications, ($v) => _Applications = $v, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor))))
                    {
                        _target.Applications = _Applications;
                        if (_Applications !== null)
                        {
                            let $en11 = _Applications.SCG$IEnumerable$$$GetEnumerator();
                            while ($en11.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en11.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$yleQ.LCFCA.ApplicationDescriptor)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor), $.$yleQ.LCFCA.ApplicationDescriptor, property, $.$ref(() => _Applications, ($v) => _Applications = $v, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationDescriptor)));
                    }
                }
                {
                    /*var*/ let _DomainMappings = _target.DomainMappings;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DomainMappings"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationDomainMapping)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationDomainMapping), $.$fPer.LCFCA.ApplicationDomainMapping));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationDomainMapping), $.$fPer.LCFCA.ApplicationDomainMapping, property, $.$ref(() => _DomainMappings, ($v) => _DomainMappings = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationDomainMapping))))
                    {
                        _target.DomainMappings = _DomainMappings;
                        if (_DomainMappings !== null)
                        {
                            let $en16 = _DomainMappings.SCG$IEnumerable$$$GetEnumerator();
                            while ($en16.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en16.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCA.ApplicationDomainMapping, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationDomainMapping), $.$fPer.LCFCA.ApplicationDomainMapping, property, $.$ref(() => _DomainMappings, ($v) => _DomainMappings = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationDomainMapping)));
                    }
                }
                {
                    /*var*/ let _Settings = _target.Settings;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Settings"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$Iaui.LCFCMS.GlobalSettings));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Settings, ($v) => _Settings = $v, $.$Iaui.LCFCMS.GlobalSettings)))
                    {
                        _target.Settings = _Settings;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180564960)
            
            //--TRIMMABLE-BOUNDARY-START(8590630368)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptor?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590630368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yleQ.LCFCA.ApplicationsDescriptor().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yleQ.LCFCA.ApplicationsDescriptor, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationsDescriptor)))
                {
                    /*var*/ let result = $.$yleQ.LCFCA.ApplicationsDescriptorTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationsDescriptor));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yleQ.LCFCA.ApplicationsDescriptor, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationsDescriptor));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590630368)
            
            static $h = 695776;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCA.ApplicationsDescriptor); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885597664),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 695776,
      "h": 12885597664,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885597664),
//--TRIMMABLE-BOUNDARY-START(17180564960),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 630240,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 695776,
      "h": 17180564960,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180564960),
//--TRIMMABLE-BOUNDARY-START(8590630368),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 630240,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 695776,
      "h": 8590630368,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590630368)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295663072),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 695776,
      "h": 4295663072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295663072)
  ],
  "h": 695776
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yleQ.LCFCA.ApplicationsDescriptor), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationsDescriptorTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationsDescriptorTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(695776)
        
        

        //--TRIMMABLE-BOUNDARY-START(892384)
        $asm.$cls(`$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor`, ($self) => class ApplicationServiceDescriptorTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCA.ApplicationServiceDescriptor)
        {
            //--TRIMMABLE-BOUNDARY-START(4295859680)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295859680);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor.GenerateProperties($.$yleQ.LCFCA.ApplicationServiceDescriptor, this, factory);
                    }, $mraONb ??= {"r":65537,"n":"","d":892384,"h":0,"f":17825794}), 0, "ApplicationServiceDescriptorTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Application\\ApplicationServiceDescriptor_LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptorTypeDescriptorBuilder.g.cs", "ApplicationServiceDescriptorTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295859680)
            
            //--TRIMMABLE-BOUNDARY-START(12885794272)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885794272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Id);
                        }, $IslkXb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $IhalHe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Name";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Name);
                        }, $dZpSMd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Name = value.AsReference($.$$.S.String);
                        }, $SpEata ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Title";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Title);
                        }, $Uucvhk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Title = value.AsReference($.$$.S.String);
                        }, $Makeic ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Description";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Description);
                        }, $mQancd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Description = value.AsReference($.$$.S.String);
                        }, $QKgzfg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFC.IconDescriptor, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Icon";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFC.IconDescriptor, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Icon);
                        }, $ZCvVqa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Icon = value.AsValue($.$fPer.LCFC.IconDescriptor);
                        }, $ISYSpa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Theme"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Theme", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Theme")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$vWqU.LCFCC.ThemePack, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Theme";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$vWqU.LCFCC.ThemePack, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Theme);
                        }, $nQdThf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Theme = value.AsReference($.$vWqU.LCFCC.ThemePack);
                        }, $NyJxti ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Domain"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Domain", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Domain")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Domain";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Domain);
                        }, $MqRSte ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Domain = value.AsReference($.$$.S.String);
                        }, $dTqflf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Paths"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Paths", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Paths")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Paths";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.String), ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Paths);
                        }, $vouPjc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Paths = value.AsReference($.$typeArray($.$$.S.String));
                        }, $kORCxk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MainAssemblies"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "MainAssemblies", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MainAssemblies")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "MainAssemblies";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).MainAssemblies);
                        }, $AjjIJd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MainAssemblies = value.AsReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly));
                        }, $mHlprc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Dependencies"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Dependencies", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Dependencies")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Dependencies";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Dependencies);
                        }, $gyArta ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Dependencies = value.AsReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly));
                        }, $kBfbPk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "Type";
                        $i21.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Type);
                        }, $xHckec ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Type = value.AsReference($.$$.S.String);
                        }, $hDWdHc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UIEntryType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "UIEntryType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UIEntryType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "UIEntryType";
                        $i23.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).UIEntryType);
                        }, $DdlmTg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UIEntryType = value.AsReference($.$$.S.String);
                        }, $IrzKNa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Features"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Features", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Features")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$yleQ.LCFCA.ApplicationServiceFeatures, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "Features";
                        $i25.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$yleQ.LCFCA.ApplicationServiceFeatures, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Features);
                        }, $PJLvwd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i25.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Features = value.AsEnumValue($.$yleQ.LCFCA.ApplicationServiceFeatures);
                        }, $PVXScd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Application"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Application", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Application")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$yleQ.LCFCA.IApplicationProxy, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "Application";
                        $i27.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$yleQ.LCFCA.IApplicationProxy, ($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Application);
                        }, $XQtmYk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i27.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Application = value.AsReference($.$yleQ.LCFCA.IApplicationProxy);
                        }, $bvpOkg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Order"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationServiceDescriptor.$type, $.$discardRef(), "Order", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Order")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "Order";
                        $i29.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$yleQ.LCFCA.ApplicationServiceDescriptor)).Order);
                        }, $iYoYcb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":892384,"h":0,"f":17825826});
                        $i29.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Order = value.AsInt();
                        }, $SBsqYc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":892384,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885794272)
            
            //--TRIMMABLE-BOUNDARY-START(17180761568)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180761568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                        _target.Name = _Name;
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                        _target.Title = _Title;
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                        _target.Description = _Description;
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFC.IconDescriptor));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFC.IconDescriptor, () => _Icon, ($v) => _Icon = $v, null, true)))
                    {
                        _target.Icon = $.$clone(_Icon);
                    }
                }
                {
                    /*var*/ let _Theme = _target.Theme;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Theme"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$vWqU.LCFCC.ThemePack));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Theme, ($v) => _Theme = $v, $.$vWqU.LCFCC.ThemePack)))
                    {
                        _target.Theme = _Theme;
                    }
                }
                {
                    /*var*/ let _Domain = _target.Domain;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Domain"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Domain, ($v) => _Domain = $v, $.$$.S.String)))
                    {
                        _target.Domain = _Domain;
                    }
                }
                {
                    /*var*/ let _Paths = _target.Paths;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Paths"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Paths, ($v) => _Paths = $v, $.$typeArray($.$$.S.String))))
                    {
                        _target.Paths = _Paths;
                        if (_Paths !== null)
                        {
                            let $i41 = 0;
                            let $arr41 = _Paths;
                            while ($i41 < $arr41.length)
                            {
                                let item = $arr41[$i41++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Paths, ($v) => _Paths = $v, $.$typeArray($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _MainAssemblies = _target.MainAssemblies;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MainAssemblies"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly, property, $.$ref(() => _MainAssemblies, ($v) => _MainAssemblies = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly))))
                    {
                        _target.MainAssemblies = _MainAssemblies;
                        if (_MainAssemblies !== null)
                        {
                            let $en46 = _MainAssemblies.SCG$IEnumerable$$$GetEnumerator();
                            while ($en46.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en46.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCA.ApplicationAssembly, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly, property, $.$ref(() => _MainAssemblies, ($v) => _MainAssemblies = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly)));
                    }
                }
                {
                    /*var*/ let _Dependencies = _target.Dependencies;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Dependencies"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly, property, $.$ref(() => _Dependencies, ($v) => _Dependencies = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly))))
                    {
                        _target.Dependencies = _Dependencies;
                        if (_Dependencies !== null)
                        {
                            let $en51 = _Dependencies.SCG$IEnumerable$$$GetEnumerator();
                            while ($en51.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en51.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCA.ApplicationAssembly, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly, property, $.$ref(() => _Dependencies, ($v) => _Dependencies = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly)));
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Type, ($v) => _Type = $v, $.$$.S.String)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _UIEntryType = _target.UIEntryType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UIEntryType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _UIEntryType, ($v) => _UIEntryType = $v, $.$$.S.String)))
                    {
                        _target.UIEntryType = _UIEntryType;
                    }
                }
                {
                    /*var*/ let _Features = _target.Features;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Features"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$yleQ.LCFCA.ApplicationServiceFeatures));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$yleQ.LCFCA.ApplicationServiceFeatures, () => _Features, ($v) => _Features = $v, null, true)))
                    {
                        _target.Features = _Features;
                    }
                }
                {
                    /*var*/ let _Application = _target.Application;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Application"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$yleQ.LCFCA.IApplicationProxy));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Application, ($v) => _Application = $v, $.$yleQ.LCFCA.IApplicationProxy)))
                    {
                        _target.Application = _Application;
                    }
                }
                {
                    /*var*/ let _Order = _target.Order;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Order"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Order, ($v) => _Order = $v, $.$$.S.Int32)))
                    {
                        _target.Order = _Order;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180761568)
            
            //--TRIMMABLE-BOUNDARY-START(8590826976)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptor?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590826976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yleQ.LCFCA.ApplicationServiceDescriptor().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yleQ.LCFCA.ApplicationServiceDescriptor, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationServiceDescriptor)))
                {
                    /*var*/ let result = $.$yleQ.LCFCA.ApplicationServiceDescriptorTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationServiceDescriptor));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yleQ.LCFCA.ApplicationServiceDescriptor, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationServiceDescriptor));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590826976)
            
            static $h = 892384;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCA.ApplicationServiceDescriptor); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885794272),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 892384,
      "h": 12885794272,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885794272),
//--TRIMMABLE-BOUNDARY-START(17180761568),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 826848,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 892384,
      "h": 17180761568,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180761568),
//--TRIMMABLE-BOUNDARY-START(8590826976),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 826848,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 892384,
      "h": 8590826976,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590826976)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295859680),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 892384,
      "h": 4295859680,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295859680)
  ],
  "h": 892384
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yleQ.LCFCA.ApplicationServiceDescriptor), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationServiceDescriptorTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationServiceDescriptorTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(892384)
        
        

        //--TRIMMABLE-BOUNDARY-START(433632)
        $asm.$cls(`$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor`, ($self) => class ApplicationDescriptorTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCA.ApplicationDescriptor)
        {
            //--TRIMMABLE-BOUNDARY-START(4295400928)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295400928);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor.GenerateProperties($.$yleQ.LCFCA.ApplicationDescriptor, this, factory);
                    }, $mzOLUe ??= {"r":65537,"n":"","d":433632,"h":0,"f":17825794}), 0, "ApplicationDescriptorTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Application\\ApplicationDescriptor_LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptorTypeDescriptorBuilder.g.cs", "ApplicationDescriptorTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295400928)
            
            //--TRIMMABLE-BOUNDARY-START(12885335520)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885335520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Id);
                        }, $yFpMTi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $FYaFVg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Name";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Name);
                        }, $CmEMLh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Name = value.AsReference($.$$.S.String);
                        }, $leZJyh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Domains"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Domains", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Domains")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Domains";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.String), ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Domains);
                        }, $jvoWyf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Domains = value.AsReference($.$typeArray($.$$.S.String));
                        }, $SGnGsb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Paths"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Paths", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Paths")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Paths";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.String), ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Paths);
                        }, $mbuPPj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Paths = value.AsReference($.$typeArray($.$$.S.String));
                        }, $Oyxeej ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Title";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Title);
                        }, $JzEmnb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Title = value.AsReference($.$$.S.String);
                        }, $yNRJgg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Description";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Description);
                        }, $JLoZGc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Description = value.AsReference($.$$.S.String);
                        }, $vfPCrj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFC.IconDescriptor, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Icon";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFC.IconDescriptor, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Icon);
                        }, $oneije ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Icon = value.AsValue($.$fPer.LCFC.IconDescriptor);
                        }, $PVWYPh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Categories"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Categories", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Categories")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Categories";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Categories);
                        }, $HcBANb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Categories = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $vSQfkd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Theme"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Theme", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Theme")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$vWqU.LCFCC.ThemePack, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Theme";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$vWqU.LCFCC.ThemePack, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Theme);
                        }, $uIUUSg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Theme = value.AsReference($.$vWqU.LCFCC.ThemePack);
                        }, $WwFaJd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Features"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Features", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Features")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$yleQ.LCFCA.ApplicationServiceFeatures, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Features";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$yleQ.LCFCA.ApplicationServiceFeatures, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Features);
                        }, $qHFsJi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Features = value.AsEnumValue($.$yleQ.LCFCA.ApplicationServiceFeatures);
                        }, $vhUMfi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Order"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Order", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Order")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "Order";
                        $i21.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Order);
                        }, $eAjgna ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Order = value.AsInt();
                        }, $asEuNk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MainAssemblies"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "MainAssemblies", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MainAssemblies")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "MainAssemblies";
                        $i23.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).MainAssemblies);
                        }, $RkiNtj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MainAssemblies = value.AsReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly));
                        }, $bQBNOa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Dependencies"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Dependencies", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Dependencies")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "Dependencies";
                        $i25.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Dependencies);
                        }, $XMWvbb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i25.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Dependencies = value.AsReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly));
                        }, $TrzzLe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UIEntryType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "UIEntryType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UIEntryType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "UIEntryType";
                        $i27.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).UIEntryType);
                        }, $hWbHza ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i27.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UIEntryType = value.AsReference($.$$.S.String);
                        }, $zDuhlg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceModules"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "ServiceModules", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceModules")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "ServiceModules";
                        $i29.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor), ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).ServiceModules);
                        }, $jIHCMd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i29.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ServiceModules = value.AsReference($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor));
                        }, $NQQWzh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t31 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i31 = new $t31();
                        $i31.$ctor$2();
                        $i31.Name = "Type";
                        $i31.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i31.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Type);
                        }, $VfWWck ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i31.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Type = value.AsReference($.$$.S.String);
                        }, $MxeUrd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i31;
                    })()), schemas, null, factory);
                    let $en32 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en32.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en32.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "ServiceType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t33 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i33 = new $t33();
                        $i33.$ctor$2();
                        $i33.Name = "ServiceType";
                        $i33.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i33.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).ServiceType);
                        }, $DFKRak ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i33.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ServiceType = value.AsReference($.$$.S.String);
                        }, $ICegTk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i33;
                    })()), schemas, null, factory);
                    let $en34 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en34.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en34.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CreateLink"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "CreateLink", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CreateLink")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t35 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i35 = new $t35();
                        $i35.$ctor$2();
                        $i35.Name = "CreateLink";
                        $i35.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i35.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).CreateLink);
                        }, $Xoogmd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i35.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CreateLink = value.AsReference($.$$.S.String);
                        }, $emKDIa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i35;
                    })()), schemas, null, factory);
                    let $en36 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en36.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en36.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CreateLabel"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "CreateLabel", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CreateLabel")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t37 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i37 = new $t37();
                        $i37.$ctor$2();
                        $i37.Name = "CreateLabel";
                        $i37.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i37.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).CreateLabel);
                        }, $tqzxCi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        $i37.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CreateLabel = value.AsReference($.$$.S.String);
                        }, $SwQwId ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i37;
                    })()), schemas, null, factory);
                    let $en38 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en38.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en38.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Application"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$yleQ.LCFCA.ApplicationDescriptor.$type, $.$discardRef(), "Application", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Application")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$yleQ.LCFCA.IApplicationProxy, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t39 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i39 = new $t39();
                        $i39.$ctor$2();
                        $i39.Name = "Application";
                        $i39.DelaredOn = "LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor";
                        $i39.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$yleQ.LCFCA.IApplicationProxy, ($.$cast(target, $.$yleQ.LCFCA.ApplicationDescriptor)).Application);
                        }, $xlUwuc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":433632,"h":0,"f":17825826});
                        return $i39;
                    })()), schemas, null, factory);
                    let $en40 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en40.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en40.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885335520)
            
            //--TRIMMABLE-BOUNDARY-START(17180302816)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180302816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                        _target.Name = _Name;
                    }
                }
                {
                    /*var*/ let _Domains = _target.Domains;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Domains"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Domains, ($v) => _Domains = $v, $.$typeArray($.$$.S.String))))
                    {
                        _target.Domains = _Domains;
                        if (_Domains !== null)
                        {
                            let $i44 = 0;
                            let $arr44 = _Domains;
                            while ($i44 < $arr44.length)
                            {
                                let item = $arr44[$i44++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Domains, ($v) => _Domains = $v, $.$typeArray($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Paths = _target.Paths;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Paths"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Paths, ($v) => _Paths = $v, $.$typeArray($.$$.S.String))))
                    {
                        _target.Paths = _Paths;
                        if (_Paths !== null)
                        {
                            let $i49 = 0;
                            let $arr49 = _Paths;
                            while ($i49 < $arr49.length)
                            {
                                let item = $arr49[$i49++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Paths, ($v) => _Paths = $v, $.$typeArray($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                        _target.Title = _Title;
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                        _target.Description = _Description;
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFC.IconDescriptor));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFC.IconDescriptor, () => _Icon, ($v) => _Icon = $v, null, true)))
                    {
                        _target.Icon = $.$clone(_Icon);
                    }
                }
                {
                    /*var*/ let _Categories = _target.Categories;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Categories"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Categories, ($v) => _Categories = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.Categories = _Categories;
                        if (_Categories !== null)
                        {
                            let $en58 = _Categories.SCG$IEnumerable$$$GetEnumerator();
                            while ($en58.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en58.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Categories, ($v) => _Categories = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Theme = _target.Theme;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Theme"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$vWqU.LCFCC.ThemePack));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Theme, ($v) => _Theme = $v, $.$vWqU.LCFCC.ThemePack)))
                    {
                        _target.Theme = _Theme;
                    }
                }
                {
                    /*var*/ let _Features = _target.Features;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Features"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$yleQ.LCFCA.ApplicationServiceFeatures));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$yleQ.LCFCA.ApplicationServiceFeatures, () => _Features, ($v) => _Features = $v, null, true)))
                    {
                        _target.Features = _Features;
                    }
                }
                {
                    /*var*/ let _Order = _target.Order;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Order"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Order, ($v) => _Order = $v, $.$$.S.Int32)))
                    {
                        _target.Order = _Order;
                    }
                }
                {
                    /*var*/ let _MainAssemblies = _target.MainAssemblies;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MainAssemblies"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly, property, $.$ref(() => _MainAssemblies, ($v) => _MainAssemblies = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly))))
                    {
                        _target.MainAssemblies = _MainAssemblies;
                        if (_MainAssemblies !== null)
                        {
                            let $en68 = _MainAssemblies.SCG$IEnumerable$$$GetEnumerator();
                            while ($en68.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en68.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCA.ApplicationAssembly, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly, property, $.$ref(() => _MainAssemblies, ($v) => _MainAssemblies = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly)));
                    }
                }
                {
                    /*var*/ let _Dependencies = _target.Dependencies;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Dependencies"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly, property, $.$ref(() => _Dependencies, ($v) => _Dependencies = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly))))
                    {
                        _target.Dependencies = _Dependencies;
                        if (_Dependencies !== null)
                        {
                            let $en73 = _Dependencies.SCG$IEnumerable$$$GetEnumerator();
                            while ($en73.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en73.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCA.ApplicationAssembly, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly), $.$fPer.LCFCA.ApplicationAssembly, property, $.$ref(() => _Dependencies, ($v) => _Dependencies = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCA.ApplicationAssembly)));
                    }
                }
                {
                    /*var*/ let _UIEntryType = _target.UIEntryType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UIEntryType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _UIEntryType, ($v) => _UIEntryType = $v, $.$$.S.String)))
                    {
                        _target.UIEntryType = _UIEntryType;
                    }
                }
                {
                    /*var*/ let _ServiceModules = _target.ServiceModules;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceModules"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor), $.$yleQ.LCFCA.ApplicationServiceDescriptor));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor), $.$yleQ.LCFCA.ApplicationServiceDescriptor, property, $.$ref(() => _ServiceModules, ($v) => _ServiceModules = $v, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor))))
                    {
                        _target.ServiceModules = _ServiceModules;
                        if (_ServiceModules !== null)
                        {
                            let $en79 = _ServiceModules.SCG$IEnumerable$$$GetEnumerator();
                            while ($en79.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en79.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$yleQ.LCFCA.ApplicationServiceDescriptor)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor), $.$yleQ.LCFCA.ApplicationServiceDescriptor, property, $.$ref(() => _ServiceModules, ($v) => _ServiceModules = $v, $.$$.SCG.IEnumerable$$($.$yleQ.LCFCA.ApplicationServiceDescriptor)));
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Type, ($v) => _Type = $v, $.$$.S.String)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _ServiceType = _target.ServiceType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ServiceType, ($v) => _ServiceType = $v, $.$$.S.String)))
                    {
                        _target.ServiceType = _ServiceType;
                    }
                }
                {
                    /*var*/ let _CreateLink = _target.CreateLink;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CreateLink"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _CreateLink, ($v) => _CreateLink = $v, $.$$.S.String)))
                    {
                        _target.CreateLink = _CreateLink;
                    }
                }
                {
                    /*var*/ let _CreateLabel = _target.CreateLabel;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CreateLabel"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _CreateLabel, ($v) => _CreateLabel = $v, $.$$.S.String)))
                    {
                        _target.CreateLabel = _CreateLabel;
                    }
                }
                {
                    /*var*/ let _Application = _target.Application;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Application"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$yleQ.LCFCA.IApplicationProxy));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Application, ($v) => _Application = $v, $.$yleQ.LCFCA.IApplicationProxy)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180302816)
            
            //--TRIMMABLE-BOUNDARY-START(8590368224)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptor?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590368224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$yleQ.LCFCA.ApplicationDescriptor().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yleQ.LCFCA.ApplicationDescriptor, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationDescriptor)))
                {
                    /*var*/ let result = $.$yleQ.LCFCA.ApplicationDescriptorTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationDescriptor));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yleQ.LCFCA.ApplicationDescriptor, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationDescriptor));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590368224)
            
            static $h = 433632;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCA.ApplicationDescriptor); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885335520),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 433632,
      "h": 12885335520,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885335520),
//--TRIMMABLE-BOUNDARY-START(17180302816),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 368096,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 433632,
      "h": 17180302816,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180302816),
//--TRIMMABLE-BOUNDARY-START(8590368224),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 368096,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 433632,
      "h": 8590368224,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590368224)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295400928),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 433632,
      "h": 4295400928,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295400928)
  ],
  "h": 433632
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yleQ.LCFCA.ApplicationDescriptor), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationDescriptorTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationDescriptorTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(433632)
        
        

        //--TRIMMABLE-BOUNDARY-START(237024)
        $asm.$cls(`$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptor`, ($self) => class ApplicationBaseUserPreferenceTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCA.ApplicationBaseUserPreference)
        {
            //--TRIMMABLE-BOUNDARY-START(4295204320)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295204320);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptor.GenerateProperties($.$yleQ.LCFCA.ApplicationBaseUserPreference, this, factory);
                    }, $ZELNVg ??= {"r":65537,"n":"","d":237024,"h":0,"f":17825794}), 0, "ApplicationBaseUserPreferenceTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Application\\ApplicationBaseUserPreference_LivingThing.Core.Frameworks.Common.Application.ApplicationBaseUserPreferenceTypeDescriptorBuilder.g.cs", "ApplicationBaseUserPreferenceTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295204320)
            
            //--TRIMMABLE-BOUNDARY-START(12885138912)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885138912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$vWqU.LCFCC.ClientUserPreferenceTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885138912)
            
            //--TRIMMABLE-BOUNDARY-START(17180106208)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Application.ApplicationBaseUserPreference*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180106208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Client.ClientUserPreference?*/ let targetBase = _target;
                $.$vWqU.LCFCC.ClientUserPreferenceTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$vWqU.LCFCC.ClientUserPreference));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180106208)
            
            //--TRIMMABLE-BOUNDARY-START(8590171616)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Application.ApplicationBaseUserPreference?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590171616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$yleQ.LCFCA.ApplicationBaseUserPreference, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationBaseUserPreference)))
                {
                    /*var*/ let result = $.$yleQ.LCFCA.ApplicationBaseUserPreferenceTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationBaseUserPreference));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$yleQ.LCFCA.ApplicationBaseUserPreference, null, $.$ref(() => _target, ($v) => _target = $v, $.$yleQ.LCFCA.ApplicationBaseUserPreference));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590171616)
            
            static $h = 237024;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$yleQ.LCFCA.ApplicationBaseUserPreference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885138912),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 237024,
      "h": 12885138912,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885138912),
//--TRIMMABLE-BOUNDARY-START(17180106208),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 105952,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 237024,
      "h": 17180106208,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180106208),
//--TRIMMABLE-BOUNDARY-START(8590171616),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 105952,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 237024,
      "h": 8590171616,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590171616)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295204320),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 237024,
      "h": 4295204320,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295204320)
  ],
  "h": 237024
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$yleQ.LCFCA.ApplicationBaseUserPreference), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Application.ApplicationBaseUserPreferenceTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Application${separator}ApplicationBaseUserPreferenceTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(237024)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client"));
})();
//--TRIMMABLE-BOUNDARY-END(40416)
