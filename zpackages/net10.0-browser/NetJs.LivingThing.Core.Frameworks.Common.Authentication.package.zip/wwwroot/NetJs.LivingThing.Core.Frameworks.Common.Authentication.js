
//--TRIMMABLE-BOUNDARY-START(16770)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui) {
    "use strict";
    let _;
    let $bfyvsd;
    let $rKrDec;
    let $Mnpqji;
    let $MGvlrk;
    let $kAKTlk;
    let $HfVXsa;
    let $FNViBb;
    let $UwKZeh;
    let $ZUPVhk;
    let $urJSMe;
    let $uRZYRk;
    let $ympBBj;
    let $KPqBxb;
    let $sOHqva;
    let $aRuPib;
    let $kNUsPg;
    let $wgkJsd;
    let $MXpzKb;
    let $WKIYVj;
    let $vOZsRj;
    let $FuReaj;
    let $wnhOVj;
    let $iFjDNi;
    let $cohgrh;
    let $HQSpbb;
    let $HVXrml;
    let $gNwqdf;
    let $Dsdcng;
    let $JANJgg;
    let $mcnMXd;
    let $vGaTfb;
    let $Mowtvg;
    let $MEalYd;
    let $yIOKRe;
    let $bebadb;
    let $Rlzbyh;
    let $OgEvTf;
    let $vEyfhi;
    let $ODxrgc;
    let $hFgvWa;
    let $RMyqqh;
    let $Iacyxa;
    let $unsXdf;
    let $LNYepc;
    let $SgPBLb;
    let $MHJYgd;
    let $cElXGb;
    let $egGHtf;
    let $NdVPwf;
    let $SfNCml;
    let $QTBLej;
    let $gPiRJi;
    let $WRFhVh;
    let $lhCxVi;
    let $ymZCOk;
    let $FcuUub;
    let $GoEWyh;
    let $fqSlaf;
    let $eKjeHk;
    let $YwJVgg;
    let $gofPMh;
    let $aytWLe;
    let $LGpdlj;
    let $ufMMsk;
    let $GPBhXj;
    let $DVMzEi;
    let $IDhfug;
    let $XnEUpg;
    let $fjxRCd;
    let $qdftfe;
    let $jGjBWi;
    let $CtNzca;
    let $VVCSXi;
    let $HQQBOc;
    let $kOWHkc;
    let $ljORlc;
    let $VOjmof;
    let $XhLCMi;
    let $PihQYc;
    let $buBPbj;
    let $PjMKsf;
    let $Erhvck;
    let $pRhWrk;
    let $isbgmh;
    let $CcLFNj;
    let $Cornth;
    let $OgyEda;
    let $jMoInh;
    let $JmpLyc;
    let $siZzdi;
    let $fQzdCg;
    let $fVkymh;
    let $fnHftg;
    let $WUoZmj;
    let $UgExxh;
    let $khZqWa;
    let $wNPdSd;
    let $kEDqhk;
    let $bWIJZh;
    let $vWypcl;
    let $azXCZi;
    let $VKRfRh;
    let $jMwufd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Authentication", 
    {
  "h": 16770,
  "f": "LivingThing.Core.Frameworks.Common.Authentication",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Authentication",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Authentication",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1589634)
        $asm.$cls(`$GfYa.LCFCA.IAuthenticationClient`, ($self) => class IAuthenticationClient
        {
            static $h = 1589634;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296556930),
    {
      "p": 82306,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886491522,
        "f": 50331905
      },
      "n": "Descriptor",
      "o": "LCFCA$IAuthenticationClient$Descriptor",
      "d": 1589634,
      "h": 4296556930,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296556930)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181458818),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "OnLoggedIn",
      "o": "LCFCA$IAuthenticationClient$OnLoggedIn",
      "d": 1589634,
      "h": 17181458818,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181458818),
//--TRIMMABLE-BOUNDARY-START(21476426114),
    {
      "r": 181338113,
      "n": "OnLoginAborted",
      "o": "LCFCA$IAuthenticationClient$OnLoginAborted",
      "d": 1589634,
      "h": 21476426114,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476426114)
  ],
  "h": 1589634
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}IAuthenticationClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1589634)
        
        

        //--TRIMMABLE-BOUNDARY-START(1720706)
        $asm.$cls(`$GfYa.LCFCA.IAuthenticationTicketStore`, ($self) => class IAuthenticationTicketStore
        {
            static $h = 1720706;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296688002),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "n": "GetTicket",
      "o": "LCFCA$IAuthenticationTicketStore$GetTicket",
      "d": 1720706,
      "h": 4296688002,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296688002),
//--TRIMMABLE-BOUNDARY-START(12886622594),
    {
      "r": 181338113,
      "p": [
        {
          "n": "ticket",
          "p": 1130882
        }
      ],
      "n": "SetTicket",
      "o": "LCFCA$IAuthenticationTicketStore$SetTicket",
      "d": 1720706,
      "h": 12886622594,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886622594),
//--TRIMMABLE-BOUNDARY-START(8591655298),
    {
      "r": 181338113,
      "n": "RemoveTicket",
      "o": "LCFCA$IAuthenticationTicketStore$RemoveTicket",
      "d": 1720706,
      "h": 8591655298,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591655298)
  ],
  "h": 1720706
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationTicketStore`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}IAuthenticationTicketStore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1720706)
        
        

        //--TRIMMABLE-BOUNDARY-START(1458562)
        $asm.$cls(`$GfYa.LCFCA.IApplicationIdentityClaimProvider`, ($self) => class IApplicationIdentityClaimProvider
        {
            static $h = 1458562;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296425858),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim)).$h,
      "p": [
        {
          "n": "user",
          "p": 35686742
        },
        {
          "n": "identity",
          "p": 262213
        }
      ],
      "n": "GetApplicationClaimsAsync",
      "o": "LCFCA$IApplicationIdentityClaimProvider$GetApplicationClaimsAsync",
      "d": 1458562,
      "h": 4296425858,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296425858)
  ],
  "h": 1458562
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.IApplicationIdentityClaimProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}IApplicationIdentityClaimProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1458562)
        
        

        //--TRIMMABLE-BOUNDARY-START(1786242)
        $asm.$cls(`$GfYa.LCFCA.IReadOnlyAuthenticationService`, ($self) => class IReadOnlyAuthenticationService
        {
            static $h = 1786242;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296753538),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.String).$h,
      "n": "GetAuthenticationToken",
      "o": "LCFCA$IReadOnlyAuthenticationService$GetAuthenticationToken",
      "d": 1786242,
      "h": 4296753538,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296753538),
//--TRIMMABLE-BOUNDARY-START(12886688130),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "n": "GetIsLoggedIn",
      "o": "LCFCA$IReadOnlyAuthenticationService$GetIsLoggedIn",
      "d": 1786242,
      "h": 12886688130,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886688130),
//--TRIMMABLE-BOUNDARY-START(8591720834),
    {
      "r": $.$$.STT.ValueTask$$($.$ssc.SSC.ClaimsPrincipal).$h,
      "n": "GetClaimsPrincipal",
      "o": "LCFCA$IReadOnlyAuthenticationService$GetClaimsPrincipal",
      "d": 1786242,
      "h": 8591720834,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591720834),
//--TRIMMABLE-BOUNDARY-START(17181655426),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "n": "GetTicket",
      "o": "LCFCA$IReadOnlyAuthenticationService$GetTicket",
      "d": 1786242,
      "h": 17181655426,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181655426)
  ],
  "h": 1786242
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.IReadOnlyAuthenticationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}IReadOnlyAuthenticationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1786242)
        
        

        //--TRIMMABLE-BOUNDARY-START(1655170)
        $asm.$cls(`$GfYa.LCFCA.IAuthenticationService`, ($self) => class IAuthenticationService
        {
            static $h = 1655170;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(73016099202),
    {
      "r": 181338113,
      "p": [
        {
          "n": "token",
          "p": 1130882
        }
      ],
      "n": "SetTicket",
      "o": "LCFCA$IAuthenticationService$SetTicket",
      "d": 1655170,
      "h": 73016099202,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(73016099202),
//--TRIMMABLE-BOUNDARY-START(47246295426),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "userName",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        },
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "LogIn",
      "o": "LCFCA$IAuthenticationService$LogIn",
      "d": 1655170,
      "h": 47246295426,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47246295426),
//--TRIMMABLE-BOUNDARY-START(21476491650),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "userNameOrEmail",
          "p": 1310721
        }
      ],
      "n": "BeginPasswordReset",
      "o": "LCFCA$IAuthenticationService$BeginPasswordReset",
      "d": 1655170,
      "h": 21476491650,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476491650),
//--TRIMMABLE-BOUNDARY-START(30066426242),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "email",
          "p": 1310721
        },
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "newPassword",
          "p": 1310721
        },
        {
          "n": "confirmPassword",
          "p": 1310721
        }
      ],
      "n": "CompletePasswordReset",
      "o": "LCFCA$IAuthenticationService$CompletePasswordReset",
      "d": 1655170,
      "h": 30066426242,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30066426242),
//--TRIMMABLE-BOUNDARY-START(42951328130),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "provider",
          "p": 1310721
        },
        {
          "n": "providerKey",
          "p": 1310721
        },
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "ExternalLogIn",
      "o": "LCFCA$IAuthenticationService$ExternalLogIn",
      "d": 1655170,
      "h": 42951328130,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42951328130),
//--TRIMMABLE-BOUNDARY-START(25771458946),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "email",
          "p": 1310721
        }
      ],
      "n": "BeginRegistration",
      "o": "LCFCA$IAuthenticationService$BeginRegistration",
      "d": 1655170,
      "h": 25771458946,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25771458946),
//--TRIMMABLE-BOUNDARY-START(34361393538),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "userName",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        },
        {
          "n": "email",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "token",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "firstName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "lastName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "phoneNumber",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "CreateUser",
      "o": "LCFCA$IAuthenticationService$CreateUser",
      "d": 1655170,
      "h": 34361393538,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34361393538),
//--TRIMMABLE-BOUNDARY-START(38656360834),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "DemoLogIn",
      "o": "LCFCA$IAuthenticationService$DemoLogIn",
      "d": 1655170,
      "h": 38656360834,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38656360834),
//--TRIMMABLE-BOUNDARY-START(12886557058),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "AnonymousLogIn",
      "o": "LCFCA$IAuthenticationService$AnonymousLogIn",
      "d": 1655170,
      "h": 12886557058,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886557058),
//--TRIMMABLE-BOUNDARY-START(17181524354),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "p": [
        {
          "n": "client",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "AuthenticateAsync",
      "o": "LCFCA$IAuthenticationService$AuthenticateAsync",
      "d": 1655170,
      "h": 17181524354,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181524354),
//--TRIMMABLE-BOUNDARY-START(51541262722),
    {
      "r": 181338113,
      "p": [
        {
          "n": "caller",
          "p": 1589634,
          "f": 65
        }
      ],
      "n": "LogOut",
      "o": "LCFCA$IAuthenticationService$LogOut",
      "d": 1655170,
      "h": 51541262722,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51541262722),
//--TRIMMABLE-BOUNDARY-START(60131197314),
    {
      "r": $.$$.STT.ValueTask$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h,
      "n": "RefreshLoginToken",
      "o": "LCFCA$IAuthenticationService$RefreshLoginToken",
      "d": 1655170,
      "h": 60131197314,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(60131197314)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(55836230018),
    {
      "e": $.$$.S.EventHandler$$($.$GfYa.LCFCA.AuthenticationEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$GfYa.LCFCA.AuthenticationEventArgs).$h
          }
        ],
        "n": "add_OnAuthenticationChanged",
        "o": "LCFCA$IAuthenticationService$add_OnAuthenticationChanged",
        "d": 1655170,
        "h": 8591589762,
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$GfYa.LCFCA.AuthenticationEventArgs).$h
          }
        ],
        "n": "remove_OnAuthenticationChanged",
        "o": "LCFCA$IAuthenticationService$remove_OnAuthenticationChanged",
        "d": 1655170,
        "h": 68721131906,
        "f": 285212929
      },
      "n": "OnAuthenticationChanged",
      "o": "LivingThing$Core$Frameworks$Common$Authentication$IAuthenticationService$OnAuthenticationChanged",
      "d": 1655170,
      "h": 55836230018,
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(55836230018)
  ],
  "h": 1655170
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$GfYa.LCFCA.IReadOnlyAuthenticationService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.IAuthenticationService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}IAuthenticationService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1655170)
        
        

        //--TRIMMABLE-BOUNDARY-START(1524098)
        $asm.$cls(`$GfYa.LCFCA.IAuthenticatingApplication`, ($self) => class IAuthenticatingApplication
        {
            static $h = 1524098;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1524098
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$GfYa.LCFCA.IAuthenticationClient, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.IAuthenticatingApplication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}IAuthenticatingApplication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1524098)
        
        

        //--TRIMMABLE-BOUNDARY-START(2310530)
        $asm.$cls(`$GfYa.LCFCA.SignInStatusCustomAttributesProvider`, ($self) => class SignInStatusCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297277826)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297277826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297277826)
            
            static $h = 2310530;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297277826),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2310530,
      "h": 4297277826,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297277826)
  ],
  "h": 2310530
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.SignInStatusCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}SignInStatusCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2310530)
        
        

        //--TRIMMABLE-BOUNDARY-START(803202)
        $asm.$cls(`$GfYa.LCFCA.AuthenticationTokenPurposeCustomAttributesProvider`, ($self) => class AuthenticationTokenPurposeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295770498)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295770498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295770498)
            
            static $h = 803202;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295770498),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 803202,
      "h": 4295770498,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295770498)
  ],
  "h": 803202
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationTokenPurposeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationTokenPurposeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(803202)
        
        

        //--TRIMMABLE-BOUNDARY-START(1982850)
        $asm.$cls(`$GfYa.LCFCA.JwtHashAlgorithmCustomAttributesProvider`, ($self) => class JwtHashAlgorithmCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296950146)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296950146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296950146)
            
            static $h = 1982850;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296950146),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1982850,
      "h": 4296950146,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296950146)
  ],
  "h": 1982850
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.JwtHashAlgorithmCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}JwtHashAlgorithmCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1982850)
        
        

        //--TRIMMABLE-BOUNDARY-START(1393026)
        $asm.$cls(`$GfYa.LCFCA.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296360322)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296360322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4296360322)
            
            static $h = 1393026;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296360322),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 1393026,
      "h": 4296360322,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296360322)
  ],
  "h": 1393026
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1393026)
        
        

        //--TRIMMABLE-BOUNDARY-START(344450)
        $asm.$cls(`$GfYa.LCFCA.AuthenticationExtension`, ($self) => class AuthenticationExtension extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065115522)
            /*string*/ static RootWebPath = null;
            //--TRIMMABLE-BOUNDARY-END(30065115522)
            
            //--TRIMMABLE-BOUNDARY-START(21475180930)
            /*string*/ static RegisterPath = null;
            //--TRIMMABLE-BOUNDARY-END(21475180930)
            
            //--TRIMMABLE-BOUNDARY-START(17180213634)
            /*string*/ static RegisterCendentialsPath = null;
            //--TRIMMABLE-BOUNDARY-END(17180213634)
            
            //--TRIMMABLE-BOUNDARY-START(12885246338)
            /*string*/ static LoginPath = null;
            //--TRIMMABLE-BOUNDARY-END(12885246338)
            
            //--TRIMMABLE-BOUNDARY-START(25770148226)
            /*string*/ static ResetPasswordPath = null;
            //--TRIMMABLE-BOUNDARY-END(25770148226)
            
            //--TRIMMABLE-BOUNDARY-START(8590279042)
            /*string*/ static ChooseNewPasswordPath = null;
            //--TRIMMABLE-BOUNDARY-END(8590279042)
            
            //--TRIMMABLE-BOUNDARY-START(4295311746)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295311746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295311746)
            
            //--TRIMMABLE-BOUNDARY-START(4295311746)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295311746)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(30065115522)
                    this.RootWebPath = "Authentication";
                    //--TRIMMABLE-BOUNDARY-END(30065115522)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475180930)
                    this.RegisterPath = "Register";
                    //--TRIMMABLE-BOUNDARY-END(21475180930)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180213634)
                    this.RegisterCendentialsPath = "Credentials";
                    //--TRIMMABLE-BOUNDARY-END(17180213634)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885246338)
                    this.LoginPath = "Login";
                    //--TRIMMABLE-BOUNDARY-END(12885246338)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770148226)
                    this.ResetPasswordPath = "Reset";
                    //--TRIMMABLE-BOUNDARY-END(25770148226)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590279042)
                    this.ChooseNewPasswordPath = "NewPassword";
                    //--TRIMMABLE-BOUNDARY-END(8590279042)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 344450;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065115522),
    {
      "t": 1310721,
      "n": "RootWebPath",
      "d": 344450,
      "h": 30065115522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065115522),
//--TRIMMABLE-BOUNDARY-START(21475180930),
    {
      "t": 1310721,
      "n": "RegisterPath",
      "d": 344450,
      "h": 21475180930,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475180930),
//--TRIMMABLE-BOUNDARY-START(17180213634),
    {
      "t": 1310721,
      "n": "RegisterCendentialsPath",
      "d": 344450,
      "h": 17180213634,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180213634),
//--TRIMMABLE-BOUNDARY-START(12885246338),
    {
      "t": 1310721,
      "n": "LoginPath",
      "d": 344450,
      "h": 12885246338,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885246338),
//--TRIMMABLE-BOUNDARY-START(25770148226),
    {
      "t": 1310721,
      "n": "ResetPasswordPath",
      "d": 344450,
      "h": 25770148226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770148226),
//--TRIMMABLE-BOUNDARY-START(8590279042),
    {
      "t": 1310721,
      "n": "ChooseNewPasswordPath",
      "d": 344450,
      "h": 8590279042,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590279042)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295311746),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 344450,
      "h": 4295311746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295311746)
  ],
  "h": 344450
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(344450)
        
        

        //--TRIMMABLE-BOUNDARY-START(1065346)
        $asm.$cls(`$GfYa.LCFCA.ChatBotBindingToken`, ($self) => class ChatBotBindingToken extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885967234)
            /*string*/ Email = null;
            //--TRIMMABLE-BOUNDARY-END(12885967234)
            
            //--TRIMMABLE-BOUNDARY-START(17180934530)
            static /*string */ Generate(/*string*/ email, /*string?*/ botName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180934530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `/bind ${$.$strNN($.$GfYa.LCFCA.TokenExtension.GenerateToken($.$GfYa.LCFCA.ChatBotBindingToken, (() =>
                {
                    //new $.$GfYa.LCFCA.ChatBotBindingToken()
                    const $t1 = $.$GfYa.LCFCA.ChatBotBindingToken;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Email = email;
                    return $i1;
                })(), 300, null))}\r\n\r\nSend this message to ${$.$strNN((botName ?? "the bot"))} to connect your account *${$.$strNN(email)}* to ${$.$strNN((botName ?? "this bot"))}.\r\n\r\n*DO NOT EDIT!*`;
            }
            //--TRIMMABLE-BOUNDARY-END(17180934530)
            
            //--TRIMMABLE-BOUNDARY-START(8590999938)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590999938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590999938)
            
            //--TRIMMABLE-BOUNDARY-START(8590999938)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590999938)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885967234)
                this.Email = null;
                //--TRIMMABLE-BOUNDARY-END(12885967234)
                
            }
            static $h = 1065346;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885967234),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770869122,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360803714,
        "f": 83886081
      },
      "n": "Email",
      "d": 1065346,
      "h": 12885967234,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885967234)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180934530),
    {
      "r": 1310721,
      "p": [
        {
          "n": "email",
          "p": 1310721
        },
        {
          "n": "botName",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "Generate",
      "d": 1065346,
      "h": 17180934530,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180934530)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590999938),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1065346,
      "h": 8590999938,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590999938)
  ],
  "h": 1065346
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.ChatBotBindingToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}ChatBotBindingToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1065346)
        
        

        //--TRIMMABLE-BOUNDARY-START(1327490)
        $asm.$cls(`$GfYa.LCFCA.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296294786)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296294786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$GfYa.LCFCA.AuthenticationTokenPurpose.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$GfYa.LCFCA.AuthenticationTokenPurposeCustomAttributesProvider, $.$GfYa.LCFCA.AuthenticationTokenPurposeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$GfYa.LCFCA.AuthenticationLoginState.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$GfYa.LCFCA.AuthenticationLoginStateCustomAttributesProvider, $.$GfYa.LCFCA.AuthenticationLoginStateCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$GfYa.LCFCA.SignInStatus.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$GfYa.LCFCA.SignInStatusCustomAttributesProvider, $.$GfYa.LCFCA.SignInStatusCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$GfYa.LCFCA.JwtHashAlgorithm.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$GfYa.LCFCA.JwtHashAlgorithmCustomAttributesProvider, $.$GfYa.LCFCA.JwtHashAlgorithmCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4296294786)
            
            static $h = 1327490;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296294786),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 1327490,
      "h": 4296294786,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296294786)
  ],
  "h": 1327490
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1327490)
        
        

        //--TRIMMABLE-BOUNDARY-START(2441602)
        $asm.$cls(`$GfYa.LCFCA.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297408898)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297408898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptorBuilder.Register();
                $.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptorBuilder.Register();
                $.$GfYa.LCFCA.AuthTokenTypeDescriptorBuilder.Register();
                $.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297408898)
            
            static $h = 2441602;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297408898),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2441602,
      "h": 4297408898,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297408898)
  ],
  "h": 2441602
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2441602)
        
        

        //--TRIMMABLE-BOUNDARY-START(475522)
        $asm.$cls(`$GfYa.LCFCA.AuthenticationLoginStateCustomAttributesProvider`, ($self) => class AuthenticationLoginStateCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295442818)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295442818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295442818)
            
            static $h = 475522;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295442818),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 475522,
      "h": 4295442818,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295442818)
  ],
  "h": 475522
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationLoginStateCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationLoginStateCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(475522)
        
        

        //--TRIMMABLE-BOUNDARY-START(672130)
        $asm.$cls(`$GfYa.LCFCA.AuthenticationMetadataTypeDescriptorBuilder`, ($self) => class AuthenticationMetadataTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590606722)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590606722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor()
                        const $t1 = $.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $aRuPib ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":672130,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$GfYa.LCFCA.AuthenticationMetadata.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590606722)
            
            //--TRIMMABLE-BOUNDARY-START(4295639426)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295639426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295639426)
            
            //--TRIMMABLE-BOUNDARY-START(4295639426)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295639426)
            
            static $h = 672130;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590606722),
    {
      "r": 65537,
      "n": "Register",
      "d": 672130,
      "h": 8590606722,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590606722)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295639426),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 672130,
      "h": 4295639426,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295639426)
  ],
  "h": 672130
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadataTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationMetadataTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(672130)
        
        

        //--TRIMMABLE-BOUNDARY-START(1851778)
        $asm.$cls(`$GfYa.LCFCA.JsonWebToken`, ($self) => class JsonWebToken
        {
            //--TRIMMABLE-BOUNDARY-START(30066622850)
            /*Dictionary<JwtHashAlgorithm, Func<byte[], byte[], byte[]>>*/ static HashAlgorithms = null;
            //--TRIMMABLE-BOUNDARY-END(30066622850)
            
            //--TRIMMABLE-BOUNDARY-START(4296819074)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296819074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$GfYa.LCFCA.JsonWebToken.HashAlgorithms = (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$GfYa.LCFCA.JwtHashAlgorithm, $.$$.S.Func$$$$($.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$GfYa.LCFCA.JwtHashAlgorithm, $.$$.S.Func$$$$($.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte)));
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add(0/*JwtHashAlgorithm.HS256*/, new ($.$$.S.Func$$$$($.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/*key*/ key, /*value*/ value) =>
                    {
                        let sha = null;
                        try
                        {
                            sha = new $.$sscr.SSC.HMACSHA256().$ctor$5(key);
                            return sha.ComputeHash$1(value);
                        }
                        finally
                        {
                            sha?.S$IDisposable$Dispose();
                        }
                    }, $ympBBj ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"key","p":$.$typeArray($.$$.S.Byte).$h},{"n":"value","p":$.$typeArray($.$$.S.Byte).$h}],"n":"","d":1851778,"h":0,"f":17825794}));
                    $i1.Add(1/*JwtHashAlgorithm.HS384*/, new ($.$$.S.Func$$$$($.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/*key*/ key, /**/ value) =>
                    {
                        let sha = null;
                        try
                        {
                            sha = new $.$sscr.SSC.HMACSHA384().$ctor$5(key);
                            return sha.ComputeHash$1(value);
                        }
                        finally
                        {
                            sha?.S$IDisposable$Dispose();
                        }
                    }, $KPqBxb ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"key","p":$.$typeArray($.$$.S.Byte).$h},{"n":"value","p":$.$typeArray($.$$.S.Byte).$h}],"n":"","d":1851778,"h":0,"f":17825794}));
                    $i1.Add(2/*JwtHashAlgorithm.HS512*/, new ($.$$.S.Func$$$$($.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/*key*/ key, /*value*/ value) =>
                    {
                        let sha = null;
                        try
                        {
                            sha = new $.$sscr.SSC.HMACSHA512().$ctor$5(key);
                            return sha.ComputeHash$1(value);
                        }
                        finally
                        {
                            sha?.S$IDisposable$Dispose();
                        }
                    }, $sOHqva ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"key","p":$.$typeArray($.$$.S.Byte).$h},{"n":"value","p":$.$typeArray($.$$.S.Byte).$h}],"n":"","d":1851778,"h":0,"f":17825794}));
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(4296819074)
            
            //--TRIMMABLE-BOUNDARY-START(21476688258)
            static /*string */ Encode$1(/*this object*/ payload, /*string*/ key, /*JwtHashAlgorithm*/ algorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476688258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$GfYa.LCFCA.JsonWebToken.Encode(payload, $.$$.ST.Encoding.UTF8.GetBytes$8(key), algorithm);
            }
            //--TRIMMABLE-BOUNDARY-END(21476688258)
            
            //--TRIMMABLE-BOUNDARY-START(17181720962)
            static /*string */ Encode(/*this object*/ payload, /*byte[]*/ keyBytes, /*JwtHashAlgorithm*/ algorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181720962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let segments = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                /*var*/ let header = { alg : $.$$.S.Enum.ToStringT($.$GfYa.LCFCA.JwtHashAlgorithm, $.$$.S.UInt32, algorithm), typ : "JWT" };
                /*byte[]*/ let headerBytes = $.$$.ST.Encoding.UTF8.GetBytes$8($.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, header, true, false, true, false, false, false, false, "Encode", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Authentication\\TokenExtension.cs", "Encode", 41)));
                /*byte[]*/ let payloadBytes = $.$$.ST.Encoding.UTF8.GetBytes$8($.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, payload, true, false, true, false, false, false, false, "Encode", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Authentication\\TokenExtension.cs", "Encode", 42)));
                segments.Add($.$GfYa.LCFCA.JsonWebToken.Base64UrlEncode(headerBytes));
                segments.Add($.$GfYa.LCFCA.JsonWebToken.Base64UrlEncode(payloadBytes));
                /*var*/ let stringToSign = $.$$.S.String.Join$10(".", segments.ToArray());
                /*var*/ let bytesToSign = $.$$.ST.Encoding.UTF8.GetBytes$8(stringToSign);
                /*byte[]*/ let signature = $.$GfYa.LCFCA.JsonWebToken.HashAlgorithms.get_Item(algorithm).Invoke(keyBytes, bytesToSign);
                segments.Add($.$GfYa.LCFCA.JsonWebToken.Base64UrlEncode(signature));
                return $.$$.S.String.Join$10(".", segments.ToArray());
            }
            //--TRIMMABLE-BOUNDARY-END(17181720962)
            
            //--TRIMMABLE-BOUNDARY-START(25771655554)
            static /*JwtHashAlgorithm */ GetHashAlgorithm(/*string*/ algorithm)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771655554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(algorithm)
                {
                    case "RS256":
                    return 0/*JwtHashAlgorithm.HS256*/;
                    case "HS384":
                    return 1/*JwtHashAlgorithm.HS384*/;
                    case "HS512":
                    return 2/*JwtHashAlgorithm.HS512*/;
                    default:
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Algorithm not supported.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771655554)
            
            //--TRIMMABLE-BOUNDARY-START(12886753666)
            static /*string */ Base64UrlEncode(/*byte[]*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886753666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let output = $.$$.S.Convert.ToBase64String$3(input);
                output = $.$$.System.Array.$ReadT1.call($.$$.S.String.Split$1.call(output, /*=*/ 61, 0), 0);
                output = $.$$.S.String.Replace.call(output, /*+*/ 43, /*-*/ 45);
                output = $.$$.S.String.Replace.call(output, /*/*/ 47, /*_*/ 95);
                return output;
            }
            //--TRIMMABLE-BOUNDARY-END(12886753666)
            
            //--TRIMMABLE-BOUNDARY-START(8591786370)
            static /*byte[] */ Base64UrlDecode(/*string*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591786370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let output = input;
                output = $.$$.S.String.Replace.call(output, /*-*/ 45, /*+*/ 43);
                output = $.$$.S.String.Replace.call(output, /*_*/ 95, /*/*/ 47);
                let $switch3 = output.length % 4;
                switch($switch3)
                {
                    case 0:
                    break;
                    case 2:
                    output += "==";
                    break;
                    case 3:
                    output += "=";
                    break;
                    default:
                    throw new $.$$.S.Exception().$ctor$4("Illegal base64url string!");
                }
                /*var*/ let converted = $.$$.S.Convert.FromBase64String(output);
                return converted;
            }
            //--TRIMMABLE-BOUNDARY-END(8591786370)
            
            static $h = 1851778;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476688258),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 131073
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "algorithm",
          "p": 1917314
        }
      ],
      "n": "Encode",
      "o": "@$1",
      "d": 1851778,
      "h": 21476688258,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476688258),
//--TRIMMABLE-BOUNDARY-START(17181720962),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 131073
        },
        {
          "n": "keyBytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "algorithm",
          "p": 1917314
        }
      ],
      "n": "Encode",
      "d": 1851778,
      "h": 17181720962,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181720962),
//--TRIMMABLE-BOUNDARY-START(25771655554),
    {
      "r": 1917314,
      "p": [
        {
          "n": "algorithm",
          "p": 1310721
        }
      ],
      "n": "GetHashAlgorithm",
      "d": 1851778,
      "h": 25771655554,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771655554),
//--TRIMMABLE-BOUNDARY-START(12886753666),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Base64UrlEncode",
      "d": 1851778,
      "h": 12886753666,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12886753666),
//--TRIMMABLE-BOUNDARY-START(8591786370),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "input",
          "p": 1310721
        }
      ],
      "n": "Base64UrlDecode",
      "d": 1851778,
      "h": 8591786370,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8591786370)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066622850),
    {
      "t": $.$$.SCG.Dictionary$$$($.$GfYa.LCFCA.JwtHashAlgorithm, $.$$.S.Func$$$$($.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte))).$h,
      "n": "HashAlgorithms",
      "d": 1851778,
      "h": 30066622850,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30066622850)
  ],
  "h": 1851778
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.JsonWebToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}JsonWebToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1851778)
        
        

        //--TRIMMABLE-BOUNDARY-START(1261954)
        $asm.$cls(`$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptorBuilder`, ($self) => class DecodedAuthenticationTicketTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591196546)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591196546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor()
                        const $t1 = $.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $NdVPwf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1261954,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591196546)
            
            //--TRIMMABLE-BOUNDARY-START(4296229250)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296229250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296229250)
            
            //--TRIMMABLE-BOUNDARY-START(4296229250)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296229250)
            
            static $h = 1261954;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591196546),
    {
      "r": 65537,
      "n": "Register",
      "d": 1261954,
      "h": 8591196546,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591196546)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296229250),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1261954,
      "h": 4296229250,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296229250)
  ],
  "h": 1261954
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicketTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}DecodedAuthenticationTicketTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1261954)
        
        

        //--TRIMMABLE-BOUNDARY-START(2048386)
        $asm.$cls(`$GfYa.LCFCA.JWTHeader`, ($self) => class JWTHeader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55836623234)
            /*string*/ typ = null;
            //--TRIMMABLE-BOUNDARY-END(55836623234)
            
            //--TRIMMABLE-BOUNDARY-START(17181917570)
            /*string*/ alg = null;
            //--TRIMMABLE-BOUNDARY-END(17181917570)
            
            //--TRIMMABLE-BOUNDARY-START(12886950274)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886950274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886950274)
            
            //--TRIMMABLE-BOUNDARY-START(12886950274)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886950274)
            
            static $h = 2048386;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836623234),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361786754,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541655938,
        "f": 83886081
      },
      "n": "typ",
      "d": 2048386,
      "h": 55836623234,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836623234),
//--TRIMMABLE-BOUNDARY-START(17181917570),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771852162,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951721346,
        "f": 83886081
      },
      "n": "alg",
      "d": 2048386,
      "h": 17181917570,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181917570)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886950274),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2048386,
      "h": 12886950274,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886950274)
  ],
  "h": 2048386
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.JWTHeader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}JWTHeader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2048386)
        
        

        //--TRIMMABLE-BOUNDARY-START(2113922)
        $asm.$cls(`$GfYa.LCFCA.JWToken<>`, (T) => $asm.$gt(`$GfYa.LCFCA.JWToken<>`, [T], ($self) => class JWToken$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476950402)
            /*int*/ Created = 0;
            //--TRIMMABLE-BOUNDARY-END(21476950402)
            
            //--TRIMMABLE-BOUNDARY-START(30066884994)
            /*int*/ Expiry = 0;
            //--TRIMMABLE-BOUNDARY-END(30066884994)
            
            //--TRIMMABLE-BOUNDARY-START(25771917698)
            /*T?*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(25771917698)
            
            //--TRIMMABLE-BOUNDARY-START(17181983106)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181983106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181983106)
            
            //--TRIMMABLE-BOUNDARY-START(17181983106)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181983106)
            
            static $H = 2113922;
            static $h = 2113922;
            static $g = 1;
            static $f = 0b1010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476950402),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38656819586,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 64426623362,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 83886081
      },
      "n": "Created",
      "d": this.$h,
      "H": 21476950402,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476950402),
//--TRIMMABLE-BOUNDARY-START(30066884994),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55836688770,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 81606492546,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 83886081
      },
      "n": "Expiry",
      "d": this.$h,
      "H": 30066884994,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066884994),
//--TRIMMABLE-BOUNDARY-START(25771917698),
    {
      "p": T?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47246754178,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 73016557954,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 83886081
      },
      "n": "Data",
      "d": this.$h,
      "H": 25771917698,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771917698)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181983106),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17181983106,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181983106)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 2113922,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.JWToken<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}JWToken$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2113922)
        
        

        //--TRIMMABLE-BOUNDARY-START(2179458)
        $asm.$cls(`$GfYa.LCFCA.JWTokenValidation<>`, (T) => $asm.$gt(`$GfYa.LCFCA.JWTokenValidation<>`, [T], ($self) => class JWTokenValidation$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81606558082)
            /*bool*/ Valid = false;
            //--TRIMMABLE-BOUNDARY-END(81606558082)
            
            //--TRIMMABLE-BOUNDARY-START(25771983234)
            /*bool*/ Expired = false;
            //--TRIMMABLE-BOUNDARY-END(25771983234)
            
            //--TRIMMABLE-BOUNDARY-START(21477015938)
            /*T?*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(21477015938)
            
            //--TRIMMABLE-BOUNDARY-START(17182048642)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182048642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182048642)
            
            //--TRIMMABLE-BOUNDARY-START(17182048642)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17182048642)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21477015938)
                this.Data = $.$default(T);
                //--TRIMMABLE-BOUNDARY-END(21477015938)
                
            }
            static $H = 2179458;
            static $h = 2179458;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81606558082),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51541787010,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 77311590786,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 83886081
      },
      "n": "Valid",
      "d": this.$h,
      "H": 81606558082,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606558082),
//--TRIMMABLE-BOUNDARY-START(25771983234),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42951852418,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 68721656194,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 83886081
      },
      "n": "Expired",
      "d": this.$h,
      "H": 25771983234,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771983234),
//--TRIMMABLE-BOUNDARY-START(21477015938),
    {
      "p": T?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34361917826,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 60131721602,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 83886081
      },
      "n": "Data",
      "d": this.$h,
      "H": 21477015938,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477015938)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182048642),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17182048642,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182048642)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 2179458,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.JWTokenValidation<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}JWTokenValidation$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2179458)
        
        

        //--TRIMMABLE-BOUNDARY-START(2376066)
        $asm.$cls(`$GfYa.LCFCA.TokenExtension`, ($self) => class TokenExtension
        {
            //--TRIMMABLE-BOUNDARY-START(8592310658)
            static /*string */ GenerateJWT(/*this object*/ payload, /*byte[]?*/ hashKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592310658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let headerPayLoad = { alg : "HS256", typ : "JWT" };
                /*var*/ let headerJson = $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, headerPayLoad, true, false, true, false, false, false, false, "GenerateJWT", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Authentication\\TokenExtension.cs", "GenerateJWT", 157).Json;
                /*var*/ let headerBytes = $.$$.ST.Encoding.UTF8.GetBytes$8(headerJson);
                /*var*/ let header64 = $.$$.S.Convert.ToBase64String$3(headerBytes);
                /*var*/ let payloadJson = $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.S.Object, payload, true, false, true, false, false, false, false, "GenerateJWT", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Authentication\\TokenExtension.cs", "GenerateJWT", 160).Json;
                /*var*/ let payloadBytes = $.$$.ST.Encoding.UTF8.GetBytes$8(payloadJson);
                /*var*/ let payload64 = $.$$.S.String.Trim$2.call($.$$.S.Convert.ToBase64String$3(payloadBytes), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*=*/ 61], [-1], null));
                /*var*/ let headerPayload64 = $.$strNN($.$strNN(header64) + ".") + $.$strNN(payload64);
                /*var*/ let hmac = new $.$sscr.SSC.HMACSHA256().$ctor$5(hashKey ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], [-1], null));
                /*var*/ let bytesToSign = $.$$.ST.Encoding.UTF8.GetBytes$8(headerPayload64);
                /*var*/ let hash = hmac.ComputeHash$1(bytesToSign);
                /*var*/ let signature64 = $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Trim$2.call($.$$.S.Convert.ToBase64String$3(hash), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*=*/ 61], [-1], null)), "+", "-"), "/", "_");
                return $.$strNN($.$strNN(headerPayload64) + ".") + $.$strNN(signature64);
            }
            //--TRIMMABLE-BOUNDARY-END(8592310658)
            
            //--TRIMMABLE-BOUNDARY-START(12887277954)
            static /*string */ GenerateToken(T, /*this T?*/ obj, /*double*/ expirySeconds, /*byte[]?*/ hashKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887277954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTime*/ let epoch = new $.$$.S.DateTime().$ctor$6(1970, 1, 1, 0, 0, 0, 1/*DateTimeKind.Utc*/);
                /*JWToken<T>*/ let payload = (() =>
                {
                    //new $.$GfYa.LCFCA.JWToken$$(T)()
                    const $t1 = $.$GfYa.LCFCA.JWToken$$(T);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Created = $.$cast($.$$.S.DateTime.UtcNow.Subtract$1(epoch).TotalSeconds, $.$$.S.Int32);
                    $i1.Expiry = $.$cast($.$$.S.DateTime.UtcNow.AddSeconds(expirySeconds).Subtract$1(epoch).TotalSeconds, $.$$.S.Int32);
                    $i1.Data = obj;
                    return $i1;
                })();
                return $.$GfYa.LCFCA.TokenExtension.GenerateJWT(payload, hashKey);
            }
            //--TRIMMABLE-BOUNDARY-END(12887277954)
            
            //--TRIMMABLE-BOUNDARY-START(4297343362)
            static /*string */ ForBase64(/*this string*/ str)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297343362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let l = ((($.trunc((((str.length + 3) | 0)) / 4)) * 4) | 0);
                return $.$$.S.String.Substring.call(($.$strNN($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call(str, "-", "+"), "_", "/")) + "==="), 0, l);
            }
            //--TRIMMABLE-BOUNDARY-END(4297343362)
            
            //--TRIMMABLE-BOUNDARY-START(17182245250)
            static /*JWTokenValidation<T> */ ValidateToken(T, /*this string*/ token, /*byte[]?*/ hashKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182245250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let splitted = $.$$.S.String.Split$5.call(token, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*.*/ 46], [-1], null));
                if (splitted.length < 3)
                {
                    return (() =>
                    {
                        //new $.$GfYa.LCFCA.JWTokenValidation$$(T)()
                        const $t2 = $.$GfYa.LCFCA.JWTokenValidation$$(T);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Valid = false;
                        return $i2;
                    })();
                }
                /*var*/ let header64 = $.$GfYa.LCFCA.TokenExtension.ForBase64($.$$.System.Array.$ReadT1.call(splitted, 0));
                /*var*/ let payload64 = $.$GfYa.LCFCA.TokenExtension.ForBase64($.$$.System.Array.$ReadT1.call(splitted, 1));
                /*var*/ let signature64 = $.$GfYa.LCFCA.TokenExtension.ForBase64($.$$.System.Array.$ReadT1.call(splitted, 2));
                /*var*/ let headerBytes = $.$$.S.Convert.FromBase64String(header64);
                /*var*/ let headerJson = $.$$.ST.Encoding.UTF8.GetString$1(headerBytes);
                /*var*/ let header = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$GfYa.LCFCA.JWTHeader, headerJson, false, "ValidateToken", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Authentication\\TokenExtension.cs", "ValidateToken", 203);
                if ((header?.typ ?? null) === "JWT" && (header?.alg ?? null) === "HS256")
                {
                    /*var*/ let signatureBytes = $.$$.S.Convert.FromBase64String(signature64);
                    /*var*/ let hmac = new $.$sscr.SSC.HMACSHA256().$ctor$5(hashKey ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], [-1], null));
                    /*var*/ let bytesToSign = $.$$.ST.Encoding.UTF8.GetBytes$8($.$strNN($.$strNN($.$$.System.Array.$ReadT1.call(splitted, 0)) + ".") + $.$strNN($.$$.System.Array.$ReadT1.call(splitted, 1)));
                    /*var*/ let hash = hmac.ComputeHash$1(bytesToSign);
                    if ($.$sl.SL.Enumerable.SequenceEqual$1($.$$.S.Byte, hash, signatureBytes))
                    {
                        /*var*/ let payloadBytes = $.$$.S.Convert.FromBase64String(payload64);
                        /*var*/ let payloadJson = $.$$.ST.Encoding.UTF8.GetString$1(payloadBytes);
                        /*var*/ let payload = $.$firstOf($.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$GfYa.LCFCA.JWToken$$(T), payloadJson, false, "ValidateToken", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Authentication\\TokenExtension.cs", "ValidateToken", 214), () => { throw new $.$$.S.NullReferenceException().$ctor$12("payload is null") });
                        /*DateTime*/ let epoch = new $.$$.S.DateTime().$ctor$6(1970, 1, 1, 0, 0, 0, 1/*DateTimeKind.Utc*/);
                        /*var*/ let exp = epoch.AddSeconds(payload.Expiry);
                        if ($.$$.S.DateTime.op_GreaterThan(exp, $.$$.S.DateTime.UtcNow))
                        {
                            return (() =>
                            {
                                //new $.$GfYa.LCFCA.JWTokenValidation$$(T)()
                                const $t3 = $.$GfYa.LCFCA.JWTokenValidation$$(T);
                                const $i3 = new $t3();
                                $i3.$ctor$1();
                                $i3.Valid = true;
                                $i3.Expired = false;
                                $i3.Data = payload.Data;
                                return $i3;
                            })();
                        }
                        else 
                        {
                            return (() =>
                            {
                                //new $.$GfYa.LCFCA.JWTokenValidation$$(T)()
                                const $t4 = $.$GfYa.LCFCA.JWTokenValidation$$(T);
                                const $i4 = new $t4();
                                $i4.$ctor$1();
                                $i4.Valid = true;
                                $i4.Expired = true;
                                $i4.Data = payload.Data;
                                return $i4;
                            })();
                        }
                    }
                }
                return (() =>
                {
                    //new $.$GfYa.LCFCA.JWTokenValidation$$(T)()
                    const $t5 = $.$GfYa.LCFCA.JWTokenValidation$$(T);
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    return $i5;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(17182245250)
            
            static $h = 2376066;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592310658),
    {
      "r": 1310721,
      "p": [
        {
          "n": "payload",
          "p": 131073
        },
        {
          "n": "hashKey",
          "p": $.$typeArray($.$$.S.Byte).$h,
          "f": 65
        }
      ],
      "n": "GenerateJWT",
      "d": 2376066,
      "h": 8592310658,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592310658),
//--TRIMMABLE-BOUNDARY-START(12887277954),
    {
      "r": 1310721,
      "p": [
        {
          "n": "obj",
          "p": (T) => T.$h
        },
        {
          "n": "expirySeconds",
          "p": 1179649
        },
        {
          "n": "hashKey",
          "p": $.$typeArray($.$$.S.Byte).$h,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "GenerateToken",
      "d": 2376066,
      "h": 12887277954,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887277954),
//--TRIMMABLE-BOUNDARY-START(4297343362),
    {
      "r": 1310721,
      "p": [
        {
          "n": "str",
          "p": 1310721
        }
      ],
      "n": "ForBase64",
      "d": 2376066,
      "h": 4297343362,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4297343362),
//--TRIMMABLE-BOUNDARY-START(17182245250),
    {
      "r": (T) => $.$GfYa.LCFCA.JWTokenValidation$$(T).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "hashKey",
          "p": $.$typeArray($.$$.S.Byte).$h,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "ValidateToken",
      "d": 2376066,
      "h": 17182245250,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182245250)
  ],
  "h": 2376066
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.TokenExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}TokenExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2376066)
        
        

        //--TRIMMABLE-BOUNDARY-START(999810)
        $asm.$cls(`$GfYa.LCFCA.AuthTokenTypeDescriptorBuilder`, ($self) => class AuthTokenTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590934402)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590934402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$GfYa.LCFCA.AuthTokenTypeDescriptor()
                        const $t1 = $.$GfYa.LCFCA.AuthTokenTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Authentication.AuthToken");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $OgEvTf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":999810,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$GfYa.LCFCA.AuthToken.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590934402)
            
            //--TRIMMABLE-BOUNDARY-START(4295967106)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295967106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295967106)
            
            //--TRIMMABLE-BOUNDARY-START(4295967106)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295967106)
            
            static $h = 999810;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590934402),
    {
      "r": 65537,
      "n": "Register",
      "d": 999810,
      "h": 8590934402,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590934402)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295967106),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 999810,
      "h": 4295967106,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295967106)
  ],
  "h": 999810
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthTokenTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthTokenTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(999810)
        
        

        //--TRIMMABLE-BOUNDARY-START(213378)
        $asm.$cls(`$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptorBuilder`, ($self) => class AuthenticationClientDescriptorTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590147970)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590147970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor()
                        const $t1 = $.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Erhvck ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":213378,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590147970)
            
            //--TRIMMABLE-BOUNDARY-START(4295180674)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295180674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295180674)
            
            //--TRIMMABLE-BOUNDARY-START(4295180674)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295180674)
            
            static $h = 213378;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590147970),
    {
      "r": 65537,
      "n": "Register",
      "d": 213378,
      "h": 8590147970,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590147970)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295180674),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 213378,
      "h": 4295180674,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295180674)
  ],
  "h": 213378
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptorTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationClientDescriptorTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(213378)
        
        

        //--TRIMMABLE-BOUNDARY-START(82306)
        $asm.$cls(`$GfYa.LCFCA.AuthenticationClientDescriptor`, ($self) => class AuthenticationClientDescriptor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68719559042)
            /*string?*/ ApplicationName = null;
            //--TRIMMABLE-BOUNDARY-END(68719559042)
            
            //--TRIMMABLE-BOUNDARY-START(64424591746)
            /*string?*/ ApplicationIcon = null;
            //--TRIMMABLE-BOUNDARY-END(64424591746)
            
            //--TRIMMABLE-BOUNDARY-START(73014526338)
            /*string?*/ ApplicationScheme = null;
            //--TRIMMABLE-BOUNDARY-END(73014526338)
            
            //--TRIMMABLE-BOUNDARY-START(60129624450)
            /*string?*/ ApplicationBaseUrl = null;
            //--TRIMMABLE-BOUNDARY-END(60129624450)
            
            //--TRIMMABLE-BOUNDARY-START(77309493634)
            /*string?*/ ApplicationTheme = null;
            //--TRIMMABLE-BOUNDARY-END(77309493634)
            
            //--TRIMMABLE-BOUNDARY-START(81604460930)
            /*string?*/ AuthenticationPageRoute = null;
            //--TRIMMABLE-BOUNDARY-END(81604460930)
            
            //--TRIMMABLE-BOUNDARY-START(55834657154)
            /*string?*/ ApplicationAccountServiceType = null;
            //--TRIMMABLE-BOUNDARY-END(55834657154)
            
            //--TRIMMABLE-BOUNDARY-START(51539689858)
            /*Dictionary<string, object?>?*/ ApplicationAccountServiceParameters = null;
            //--TRIMMABLE-BOUNDARY-END(51539689858)
            
            //--TRIMMABLE-BOUNDARY-START(171798774146)
            /*string?*/ RegisterationEmailTemplateUrl = null;
            //--TRIMMABLE-BOUNDARY-END(171798774146)
            
            //--TRIMMABLE-BOUNDARY-START(176093741442)
            /*string?*/ ResetPasswordEmailTemplateUrl = null;
            //--TRIMMABLE-BOUNDARY-END(176093741442)
            
            //--TRIMMABLE-BOUNDARY-START(47244722562)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244722562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47244722562)
            
            //--TRIMMABLE-BOUNDARY-START(47244722562)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(47244722562)
            
            static $h = 82306;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719559042),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554133890,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219043414402,
        "f": 83886081
      },
      "n": "ApplicationName",
      "d": 82306,
      "h": 68719559042,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719559042),
//--TRIMMABLE-BOUNDARY-START(64424591746),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964199298,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453479810,
        "f": 83886081
      },
      "n": "ApplicationIcon",
      "d": 82306,
      "h": 64424591746,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424591746),
//--TRIMMABLE-BOUNDARY-START(73014526338),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144068482,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633348994,
        "f": 83886081
      },
      "n": "ApplicationScheme",
      "d": 82306,
      "h": 73014526338,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014526338),
//--TRIMMABLE-BOUNDARY-START(60129624450),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374264706,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201863545218,
        "f": 83886081
      },
      "n": "ApplicationBaseUrl",
      "d": 82306,
      "h": 60129624450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129624450),
//--TRIMMABLE-BOUNDARY-START(77309493634),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734003074,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223283586,
        "f": 83886081
      },
      "n": "ApplicationTheme",
      "d": 82306,
      "h": 77309493634,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309493634),
//--TRIMMABLE-BOUNDARY-START(81604460930),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150323937666,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813218178,
        "f": 83886081
      },
      "n": "AuthenticationPageRoute",
      "d": 82306,
      "h": 81604460930,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604460930),
//--TRIMMABLE-BOUNDARY-START(55834657154),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784330114,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193273610626,
        "f": 83886081
      },
      "n": "ApplicationAccountServiceType",
      "d": 82306,
      "h": 55834657154,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834657154),
//--TRIMMABLE-BOUNDARY-START(51539689858),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194395522,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184683676034,
        "f": 83886081
      },
      "n": "ApplicationAccountServiceParameters",
      "d": 82306,
      "h": 51539689858,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539689858),
//--TRIMMABLE-BOUNDARY-START(171798774146),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158913872258,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253403152770,
        "f": 83886081
      },
      "n": "RegisterationEmailTemplateUrl",
      "d": 82306,
      "h": 171798774146,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171798774146),
//--TRIMMABLE-BOUNDARY-START(176093741442),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167503806850,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993087362,
        "f": 83886081
      },
      "n": "ResetPasswordEmailTemplateUrl",
      "d": 82306,
      "h": 176093741442,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176093741442)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47244722562),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 82306,
      "h": 47244722562,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244722562)
  ],
  "h": 82306,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IJsonSerializableDataConvert ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationClientDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(82306)
        
        

        //--TRIMMABLE-BOUNDARY-START(541058)
        $asm.$cls(`$GfYa.LCFCA.AuthenticationMetadata`, ($self) => class AuthenticationMetadata extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(309238186370)
            /*AuthenticationTokenPurpose?*/ TokenPurpose = null;
            //--TRIMMABLE-BOUNDARY-END(309238186370)
            
            //--TRIMMABLE-BOUNDARY-START(304943219074)
            /*string?*/ TokenEmail = null;
            //--TRIMMABLE-BOUNDARY-END(304943219074)
            
            //--TRIMMABLE-BOUNDARY-START(313533153666)
            /*string?*/ TokenValue = null;
            //--TRIMMABLE-BOUNDARY-END(313533153666)
            
            //--TRIMMABLE-BOUNDARY-START(210453938562)
            /*string?*/ ReferrerId = null;
            //--TRIMMABLE-BOUNDARY-END(210453938562)
            
            //--TRIMMABLE-BOUNDARY-START(206158971266)
            /*string?*/ ReferrerHandlerId = null;
            //--TRIMMABLE-BOUNDARY-END(206158971266)
            
            //--TRIMMABLE-BOUNDARY-START(201864003970)
            /*string?*/ ReferrerData = null;
            //--TRIMMABLE-BOUNDARY-END(201864003970)
            
            //--TRIMMABLE-BOUNDARY-START(180389167490)
            /*int?*/ LoginExpiryMinutes = null;
            //--TRIMMABLE-BOUNDARY-END(180389167490)
            
            //--TRIMMABLE-BOUNDARY-START(60130083202)
            /*Dictionary<string, object>?*/ ApplicationAccountServiceParameter = null;
            //--TRIMMABLE-BOUNDARY-END(60130083202)
            
            //--TRIMMABLE-BOUNDARY-START(214748905858)
            /*string?*/ ReturnUrl = null;
            //--TRIMMABLE-BOUNDARY-END(214748905858)
            
            //--TRIMMABLE-BOUNDARY-START(64425050498)
            /*AuthenticationClientDescriptor?*/ ClientDescriptor = null;
            //--TRIMMABLE-BOUNDARY-END(64425050498)
            
            //--TRIMMABLE-BOUNDARY-START(184684134786)
            /*AuthenticationMetadata */ MergeWith(/*AuthenticationMetadata?*/ second)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684134786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$GfYa.LCFCA.AuthenticationMetadata.op_Equality(second, null))
                {
                    return this;
                }
                return $.$with(this, ($clone) =>
                {
                    $clone.TokenPurpose = this.TokenPurpose !== null ? this.TokenPurpose : second.TokenPurpose;
                    $clone.TokenValue = this.TokenValue ?? second.TokenValue;
                    $clone.TokenEmail = this.TokenEmail ?? second.TokenEmail;
                    $clone.ReferrerId = this.ReferrerId ?? second.ReferrerId;
                    $clone.ReferrerHandlerId = this.ReferrerHandlerId ?? second.ReferrerHandlerId;
                    $clone.ReferrerData = this.ReferrerData ?? second.ReferrerData;
                    $clone.ApplicationAccountServiceParameter = this.ApplicationAccountServiceParameter ?? second.ApplicationAccountServiceParameter;
                    $clone.ReturnUrl = this.ReturnUrl ?? second.ReturnUrl;
                    $clone.ClientDescriptor = this.ClientDescriptor ?? second.ClientDescriptor;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(184684134786)
            
            //--TRIMMABLE-BOUNDARY-START(317828120962)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828120962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCS$6.StringExtension.AsQueryString(this, false);
            }
            //--TRIMMABLE-BOUNDARY-END(317828120962)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata>.Equals(LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata?)
            S$IEquatable$LivingThing$Core$Frameworks$Common$Authentication$AuthenticationMetadata$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(51540148610)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540148610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540148610)
            
            //--TRIMMABLE-BOUNDARY-START(51540148610)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(51540148610)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.TokenPurpose = this.TokenPurpose;
                copy.TokenEmail = this.TokenEmail;
                copy.TokenValue = this.TokenValue;
                copy.ReferrerId = this.ReferrerId;
                copy.ReferrerHandlerId = this.ReferrerHandlerId;
                copy.ReferrerData = this.ReferrerData;
                copy.LoginExpiryMinutes = this.LoginExpiryMinutes;
                copy.ApplicationAccountServiceParameter = this.ApplicationAccountServiceParameter;
                copy.ReturnUrl = this.ReturnUrl;
                copy.ClientDescriptor = this.ClientDescriptor;
                return copy;
            }
            //Begin generated record members
            /*Type*/ get EqualityContract() { return $.$typeOf($.$GfYa.LCFCA.AuthenticationMetadata); }
            /*string*/ ToString()
            {
                let stringBuilder = new $.$$.ST.StringBuilder().$ctor$1();
                stringBuilder.Append$21("AuthenticationMetadata");
                stringBuilder.Append$21("{");
                if (this.PrintMembers(stringBuilder))
                {
                    stringBuilder.Append$21(" ");
                }
                stringBuilder.Append$21("}");
                return stringBuilder.ToString();
            }
            /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
            {
                stringBuilder.Append$21("TokenPurpose = ");
                stringBuilder.Append$21(this.TokenPurpose.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("TokenEmail = ");
                stringBuilder.Append$21(this.TokenEmail);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("TokenValue = ");
                stringBuilder.Append$21(this.TokenValue);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ReferrerId = ");
                stringBuilder.Append$21(this.ReferrerId);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ReferrerHandlerId = ");
                stringBuilder.Append$21(this.ReferrerHandlerId);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ReferrerData = ");
                stringBuilder.Append$21(this.ReferrerData);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("LoginExpiryMinutes = ");
                stringBuilder.Append$21(this.LoginExpiryMinutes.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ApplicationAccountServiceParameter = ");
                stringBuilder.Append$21($.$dsp(this.ApplicationAccountServiceParameter, $.$$.S.Object, ($t) => $t.ToString));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ReturnUrl = ");
                stringBuilder.Append$21(this.ReturnUrl);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ClientDescriptor = ");
                stringBuilder.Append$21($.$dsp(this.ClientDescriptor, $.$$.S.Object, ($t) => $t.ToString));
                return true;
            }
            /*bool*/ Equals$2(/*AuthenticationMetadata*/ other)
            {
                return this === other || (other !== null && this.EqualityContract == other.EqualityContract && this.TokenPurpose === other.TokenPurpose && $.$$.S.String.op_Equality(this.TokenEmail, other.TokenEmail) && $.$$.S.String.op_Equality(this.TokenValue, other.TokenValue) && $.$$.S.String.op_Equality(this.ReferrerId, other.ReferrerId) && $.$$.S.String.op_Equality(this.ReferrerHandlerId, other.ReferrerHandlerId) && $.$$.S.String.op_Equality(this.ReferrerData, other.ReferrerData) && this.LoginExpiryMinutes === other.LoginExpiryMinutes && $.$$.SCG.EqualityComparer$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)).Default.Equals$2(this.ApplicationAccountServiceParameter, other.ApplicationAccountServiceParameter) && $.$$.S.String.op_Equality(this.ReturnUrl, other.ReturnUrl) && $.$$.SCG.EqualityComparer$$($.$GfYa.LCFCA.AuthenticationClientDescriptor).Default.Equals$2(this.ClientDescriptor, other.ClientDescriptor));
            }
            /*int*/ GetHashCode()
            {
                return $.$$.SCG.EqualityComparer$$($.$$.S.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$GfYa.LCFCA.AuthenticationTokenPurpose)).Default.GetHashCode$1(this.TokenPurpose) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.TokenEmail) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.TokenValue) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.ReferrerId) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.ReferrerHandlerId) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.ReferrerData) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Int32)).Default.GetHashCode$1(this.LoginExpiryMinutes) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)).Default.GetHashCode$1(this.ApplicationAccountServiceParameter) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.ReturnUrl) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$GfYa.LCFCA.AuthenticationClientDescriptor).Default.GetHashCode$1(this.ClientDescriptor) * -1521134295;
            }
            static /*bool*/ op_Inequality(/*AuthenticationMetadata*/ left, /*AuthenticationMetadata*/ right)
            {
                return !(this.op_Equality(left, right));
            }
            static /*bool*/ op_Equality(/*AuthenticationMetadata*/ left, /*AuthenticationMetadata*/ right)
            {
                return left === right || (left !== null && left.Equals$2(right));
            }
            Deconstruct(/*out LivingThing.Core.Frameworks.Common.Authentication.AuthenticationTokenPurpose?*/ $TokenPurpose, /*out string?*/ $TokenEmail, /*out string?*/ $TokenValue, /*out string?*/ $ReferrerId, /*out string?*/ $ReferrerHandlerId, /*out string?*/ $ReferrerData, /*out int?*/ $LoginExpiryMinutes, /*out System.Collections.Generic.Dictionary<string, object>?*/ $ApplicationAccountServiceParameter, /*out string?*/ $ReturnUrl, /*out LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor?*/ $ClientDescriptor)
            {
                $TokenPurpose.$v = this.TokenPurpose;
                $TokenEmail.$v = this.TokenEmail;
                $TokenValue.$v = this.TokenValue;
                $ReferrerId.$v = this.ReferrerId;
                $ReferrerHandlerId.$v = this.ReferrerHandlerId;
                $ReferrerData.$v = this.ReferrerData;
                $LoginExpiryMinutes.$v = this.LoginExpiryMinutes;
                $ApplicationAccountServiceParameter.$v = this.ApplicationAccountServiceParameter;
                $ReturnUrl.$v = this.ReturnUrl;
                $ClientDescriptor.$v = this.ClientDescriptor;
            }
            //End generated record member3s
            static $h = 541058;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720017794),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079756162,
        "f": 50331780
      },
      "n": "EqualityContract",
      "d": 541058,
      "h": 68720017794,
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(68720017794),
//--TRIMMABLE-BOUNDARY-START(309238186370),
    {
      "p": $.$typeNullable($.$GfYa.LCFCA.AuthenticationTokenPurpose).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209298306,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292058317186,
        "f": 83886081
      },
      "n": "TokenPurpose",
      "d": 541058,
      "h": 309238186370,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309238186370),
//--TRIMMABLE-BOUNDARY-START(304943219074),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619363714,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468382594,
        "f": 83886081
      },
      "n": "TokenEmail",
      "d": 541058,
      "h": 304943219074,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304943219074),
//--TRIMMABLE-BOUNDARY-START(313533153666),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799232898,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300648251778,
        "f": 83886081
      },
      "n": "TokenValue",
      "d": 541058,
      "h": 313533153666,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313533153666),
//--TRIMMABLE-BOUNDARY-START(210453938562),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439494530,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288513410,
        "f": 83886081
      },
      "n": "ReferrerId",
      "d": 541058,
      "h": 210453938562,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210453938562),
//--TRIMMABLE-BOUNDARY-START(206158971266),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849559938,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698578818,
        "f": 83886081
      },
      "n": "ReferrerHandlerId",
      "d": 541058,
      "h": 206158971266,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206158971266),
//--TRIMMABLE-BOUNDARY-START(201864003970),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259625346,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108644226,
        "f": 83886081
      },
      "n": "ReferrerData",
      "d": 541058,
      "h": 201864003970,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864003970),
//--TRIMMABLE-BOUNDARY-START(180389167490),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669690754,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518709634,
        "f": 83886081
      },
      "n": "LoginExpiryMinutes",
      "d": 541058,
      "h": 180389167490,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389167490),
//--TRIMMABLE-BOUNDARY-START(60130083202),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899886978,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338840450,
        "f": 83886081
      },
      "n": "ApplicationAccountServiceParameter",
      "d": 541058,
      "h": 60130083202,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130083202),
//--TRIMMABLE-BOUNDARY-START(214748905858),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029429122,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878448002,
        "f": 83886081
      },
      "n": "ReturnUrl",
      "d": 541058,
      "h": 214748905858,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214748905858),
//--TRIMMABLE-BOUNDARY-START(64425050498),
    {
      "p": 82306,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489821570,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928775042,
        "f": 83886081
      },
      "n": "ClientDescriptor",
      "d": 541058,
      "h": 64425050498,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425050498)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(184684134786),
    {
      "r": 541058,
      "p": [
        {
          "n": "second",
          "p": 541058
        }
      ],
      "n": "MergeWith",
      "d": 541058,
      "h": 184684134786,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684134786),
//--TRIMMABLE-BOUNDARY-START(317828120962),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 541058,
      "h": 317828120962,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(317828120962),
//--TRIMMABLE-BOUNDARY-START(197569036674),
    {
      "r": 262145,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        }
      ],
      "n": "PrintMembers",
      "d": 541058,
      "h": 197569036674,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(197569036674),
//--TRIMMABLE-BOUNDARY-START(176094200194),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 541058,
      "h": 176094200194,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094200194),
//--TRIMMABLE-BOUNDARY-START(73014985090),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 541058,
      "h": 73014985090,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73014985090),
//--TRIMMABLE-BOUNDARY-START(77309952386),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 541058
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 541058,
      "h": 77309952386,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(77309952386),
//--TRIMMABLE-BOUNDARY-START(12885442946),
    {
      "r": 541058,
      "n": "\u003CClone\u003E$",
      "o": "$$$",
      "d": 541058,
      "h": 12885442946,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885442946)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835115906),
    {
      "p": [
        {
          "n": "original",
          "p": 541058
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 541058,
      "h": 55835115906,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(55835115906),
//--TRIMMABLE-BOUNDARY-START(51540148610),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 541058,
      "h": 51540148610,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540148610)
  ],
  "h": 541058,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$$.S.IEquatable$$($.$GfYa.LCFCA.AuthenticationMetadata) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationMetadata`; }
        });
        //--TRIMMABLE-BOUNDARY-END(541058)
        
        

        //--TRIMMABLE-BOUNDARY-START(1130882)
        $asm.$cls(`$GfYa.LCFCA.DecodedAuthenticationTicket`, ($self) => class DecodedAuthenticationTicket extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(111670280578)
            /*DecodedAuthenticationTicket*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(111670280578)
            
            //--TRIMMABLE-BOUNDARY-START(304943808898)
            /*string?*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(304943808898)
            
            //--TRIMMABLE-BOUNDARY-START(4296098178)
            /*string?*/ _userName = null;
            //--TRIMMABLE-BOUNDARY-END(4296098178)
            
            //--TRIMMABLE-BOUNDARY-START(592706617730)
            /*string? */ get UserName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763939714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._userName !== null)
                {
                    return this._userName;
                }
                if (this.FirstName !== null || this.LastName !== null)
                {
                    return $.$strNN($.$strNN(this.FirstName) + " ") + $.$strNN(this.LastName);
                }
                return null;
            }
            /*string? */ set UserName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579821715842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._userName = value;
            }
            //--TRIMMABLE-BOUNDARY-END(592706617730)
            
            //--TRIMMABLE-BOUNDARY-START(137440084354)
            /*string?*/ FirstName = null;
            //--TRIMMABLE-BOUNDARY-END(137440084354)
            
            //--TRIMMABLE-BOUNDARY-START(343598514562)
            /*string?*/ LastName = null;
            //--TRIMMABLE-BOUNDARY-END(343598514562)
            
            //--TRIMMABLE-BOUNDARY-START(115965247874)
            /*string?*/ Email = null;
            //--TRIMMABLE-BOUNDARY-END(115965247874)
            
            //--TRIMMABLE-BOUNDARY-START(438087795074)
            /*string?*/ PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(438087795074)
            
            //--TRIMMABLE-BOUNDARY-START(442382762370)
            /*bool*/ PhoneNumberVerified = false;
            //--TRIMMABLE-BOUNDARY-END(442382762370)
            
            //--TRIMMABLE-BOUNDARY-START(309238776194)
            /*string?*/ Image = null;
            //--TRIMMABLE-BOUNDARY-END(309238776194)
            
            //--TRIMMABLE-BOUNDARY-START(584116683138)
            /*AuthToken*/ Token;
            //--TRIMMABLE-BOUNDARY-END(584116683138)
            
            //--TRIMMABLE-BOUNDARY-START(103080345986)
            /*IEnumerable<string>?*/ Cookies = null;
            //--TRIMMABLE-BOUNDARY-END(103080345986)
            
            //--TRIMMABLE-BOUNDARY-START(107375313282)
            /*DateTime?*/ Created = null;
            //--TRIMMABLE-BOUNDARY-END(107375313282)
            
            //--TRIMMABLE-BOUNDARY-START(133145117058)
            /*DateTime?*/ Expires = null;
            //--TRIMMABLE-BOUNDARY-END(133145117058)
            
            //--TRIMMABLE-BOUNDARY-START(450972696962)
            /*IEnumerable<string>?*/ Roles = null;
            //--TRIMMABLE-BOUNDARY-END(450972696962)
            
            //--TRIMMABLE-BOUNDARY-START(98785378690)
            /*IEnumerable<Claim>?*/ Claims = null;
            //--TRIMMABLE-BOUNDARY-END(98785378690)
            
            //--TRIMMABLE-BOUNDARY-START(339303547266)
            /*bool */ IsValid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303547266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.UserName !== null || this.Id !== null || this.Token.JWToken !== null)
                {
                    if (this.Expires !== null && $.$$.S.DateTime.UtcNow > this.Expires)
                    {
                        return false;
                    }
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(339303547266)
            
            //--TRIMMABLE-BOUNDARY-START(425202893186)
            /*bool */ NeedsRefresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202893186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Created === null || $.$$.S.TimeSpan.op_GreaterThan($.$$.S.DateTime.op_Subtraction$1($.$$.S.DateTime.UtcNow, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Created)), $.$$.S.TimeSpan.FromHours$2(12)) || (this.Expires !== null && $.$$.S.TimeSpan.op_LessThan($.$$.S.DateTime.op_Subtraction$1($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this.Expires), $.$$.S.DateTime.UtcNow), $.$$.S.TimeSpan.FromMinutes$2(15n)));
            }
            //--TRIMMABLE-BOUNDARY-END(425202893186)
            
            //--TRIMMABLE-BOUNDARY-START(330713612674)
            /*bool*/ IsFresh = false;
            //--TRIMMABLE-BOUNDARY-END(330713612674)
            
            //--TRIMMABLE-BOUNDARY-START(313533743490)
            /*ResourceModel? */ get ImageResource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634397570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Image !== null && !$.$$.S.String.StartsWith$3.call(this.Image, "http"))
                {
                    /*var*/ let parts = $.$$.S.String.Split$5.call(this.Image, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/***/ 42], [-1], null));
                    if (parts.length === 2)
                    {
                        return (() =>
                        {
                            //new $.$Iaui.LCFCM.ResourceModel()
                            const $t1 = $.$Iaui.LCFCM.ResourceModel;
                            const $i1 = new $t1();
                            $i1.$ctor$3();
                            $i1.Identifier = $.$fPer.LCFCD.DataId.op_Implicit$1($.$$.System.Array.$ReadT1.call(parts, 0));
                            $i1.Name = $.$$.System.Array.$ReadT1.call(parts, 1);
                            return $i1;
                        })();
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(313533743490)
            
            //--TRIMMABLE-BOUNDARY-START(365073351042)
            /*DataId */ get LCFCC$2$IContact$Identifier()
            {
                return $.$fPer.LCFCD.DataId.op_Implicit$1(this.Id);
            }
            //--TRIMMABLE-BOUNDARY-END(365073351042)
            
            //--TRIMMABLE-BOUNDARY-START(369368318338)
            /*GeoLocation?*/ LCFCC$2$IContact$Location = null;
            //--TRIMMABLE-BOUNDARY-END(369368318338)
            
            //--TRIMMABLE-BOUNDARY-START(408023024002)
            /*string? */ get LCFC$IDisplayable$Title()
            {
                return this.UserName;
            }
            //--TRIMMABLE-BOUNDARY-END(408023024002)
            
            //--TRIMMABLE-BOUNDARY-START(373663285634)
            /*string?*/ LCFC$IDescribable$Description = null;
            //--TRIMMABLE-BOUNDARY-END(373663285634)
            
            //--TRIMMABLE-BOUNDARY-START(403728056706)
            /*IconDescriptor*/ LCFC$IDisplayable$Icon;
            //--TRIMMABLE-BOUNDARY-END(403728056706)
            
            //--TRIMMABLE-BOUNDARY-START(420907925890)
            /*string? */ get LCFC$INamed$Name()
            {
                return this.UserName;
            }
            //--TRIMMABLE-BOUNDARY-END(420907925890)
            
            //--TRIMMABLE-BOUNDARY-START(335008579970)
            /*bool */ IsSuperAdmin()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(335008579970);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsValid() && this.HasRoles("SuperAdmin");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(335008579970)
            
            //--TRIMMABLE-BOUNDARY-START(317828710786)
            /*bool */ IsAdmin()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(317828710786);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsValid() && this.HasRoles("Admin");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(317828710786)
            
            //--TRIMMABLE-BOUNDARY-START(322123678082)
            /*bool */ IsAnonymous()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(322123678082);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsValid() && this.UserName === "anonymous";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(322123678082)
            
            //--TRIMMABLE-BOUNDARY-START(326418645378)
            /*bool */ IsDemo()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(326418645378);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsValid() && this.UserName === "demo";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(326418645378)
            
            //--TRIMMABLE-BOUNDARY-START(300648841602)
            /*bool */ HasRoles$1(/*params string[]*/ roles)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648841602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                return ((__ca1__ = this.Roles) !== null ? $.$sl.SL.Enumerable.Any($.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                {
                    /*string[]*/ let __ca2__;
                    return ((__ca2__ = roles) !== null ? $.$sl.SL.Enumerable.Any($.$$.S.String, __ca2__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*rr*/ rr) =>
                    {
                        return $.$$.S.String.Equals$2.call(rr, r, 3/*StringComparison.InvariantCultureIgnoreCase*/);
                    }, $bfyvsd ??= {"r":262145,"p":[{"n":"rr","p":1310721}],"n":"","d":1130882,"h":0,"f":17825794})) : false);
                }, $rKrDec ??= {"r":262145,"p":[{"n":"r","p":1310721}],"n":"","d":1130882,"h":0,"f":17825794})) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(300648841602)
            
            //--TRIMMABLE-BOUNDARY-START(296353874306)
            /*bool */ HasRoles(/*string*/ roles)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353874306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasRoles$1($.$$.S.String.Split$1.call(roles, /*,*/ 44, 0));
            }
            //--TRIMMABLE-BOUNDARY-END(296353874306)
            
            //--TRIMMABLE-BOUNDARY-START(141735051650)
            static /*DecodedAuthenticationTicket */ FromPrincipal(/*ClaimsPrincipal*/ principal)
            {
                /*var*/ let iss;
                /*var*/ let _exp;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735051650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTime?*/ let issuedDate = null;
                if ($.$$.S.DateTime.TryParse$3(($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, principal.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Type === "Created";
                }, $Mnpqji ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1130882,"h":0,"f":17825794}))?.Value ?? null), $.$ref(() => iss, ($v) => iss = $v, $.$$.S.DateTime)))
                {
                    issuedDate = iss;
                }
                /*DateTime?*/ let expireDate = null;
                if ($.$$.S.DateTime.TryParse$3(($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, principal.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Type === "http://schemas.microsoft.com/ws/2008/06/identity/claims/expiration"/*ClaimTypes.Expiration*/;
                }, $MGvlrk ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1130882,"h":0,"f":17825794}))?.Value ?? null), $.$ref(() => _exp, ($v) => _exp = $v, $.$$.S.DateTime)))
                {
                    expireDate = _exp;
                }
                return (() =>
                {
                    //new $.$GfYa.LCFCA.DecodedAuthenticationTicket()
                    const $t4 = $.$GfYa.LCFCA.DecodedAuthenticationTicket;
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.Id = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, principal.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Type === "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"/*ClaimTypes.NameIdentifier*/;
                    }, $kAKTlk ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1130882,"h":0,"f":17825794}))?.Value ?? null);
                    $i4.UserName = (principal.Identity?.SSP$1$IIdentity$Name ?? null);
                    $i4.Email = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, principal.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Type === "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"/*ClaimTypes.Email*/;
                    }, $HfVXsa ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1130882,"h":0,"f":17825794}))?.Value ?? null);
                    $i4.PhoneNumber = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, principal.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Type === "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/mobilephone"/*ClaimTypes.MobilePhone*/;
                    }, $FNViBb ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1130882,"h":0,"f":17825794}))?.Value ?? null);
                    $i4.PhoneNumberVerified = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, principal.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/**/ c) =>
                    {
                        return c.Type === "PhoneNumberVerified";
                    }, $UwKZeh ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1130882,"h":0,"f":17825794}))?.Value ?? null) === "True";
                    $i4.Image = ($.$sl.SL.Enumerable.FirstOrDefault$1($.$ssc.SSC.Claim, principal.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Type === "Image";
                    }, $ZUPVhk ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1130882,"h":0,"f":17825794}))?.Value ?? null);
                    $i4.Roles = $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Select$1($.$ssc.SSC.Claim, $.$$.S.String, $.$sl.SL.Enumerable.Where($.$ssc.SSC.Claim, principal.Claims, new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Type === "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"/*ClaimTypes.Role*/;
                    }, $urJSMe ??= {"r":262145,"p":[{"n":"c","p":131141}],"n":"","d":1130882,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$ssc.SSC.Claim, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.Value;
                    }, $uRZYRk ??= {"r":1310721,"p":[{"n":"c","p":131141}],"n":"","d":1130882,"h":0,"f":17825794})));
                    $i4.Claims = principal.Claims;
                    $i4.Created = $.$clone(issuedDate);
                    $i4.Expires = $.$clone(expireDate);
                    return $i4;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(141735051650)
            
            //--TRIMMABLE-BOUNDARY-START(47249721686)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.PhoneNumber.get
            get LCFCC$2$IContact$PhoneNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64429590870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhoneNumber;
            }
            //--TRIMMABLE-BOUNDARY-END(47249721686)
            
            //--TRIMMABLE-BOUNDARY-START(12889983318)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Email.get
            get LCFCC$2$IContact$Email()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300048726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Email;
            }
            //--TRIMMABLE-BOUNDARY-END(12889983318)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket>.Equals(LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket?)
            S$IEquatable$LivingThing$Core$Frameworks$Common$Authentication$DecodedAuthenticationTicket$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(90195444098)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195444098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(90195444098)
            
            //--TRIMMABLE-BOUNDARY-START(90195444098)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(90195444098)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Id = this.Id;
                copy._userName = this._userName;
                copy.FirstName = this.FirstName;
                copy.LastName = this.LastName;
                copy.Email = this.Email;
                copy.PhoneNumber = this.PhoneNumber;
                copy.PhoneNumberVerified = this.PhoneNumberVerified;
                copy.Image = this.Image;
                copy.Token = this.Token.$clone();
                copy.Cookies = this.Cookies;
                copy.Created = this.Created?.$clone() ?? null;
                copy.Expires = this.Expires?.$clone() ?? null;
                copy.Roles = this.Roles;
                copy.Claims = this.Claims;
                copy.IsFresh = this.IsFresh;
                copy.LCFCC$2$IContact$Location = this.LCFCC$2$IContact$Location;
                copy.LCFC$IDescribable$Description = this.LCFC$IDescribable$Description;
                copy.LCFC$IDisplayable$Icon = this.LCFC$IDisplayable$Icon.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(584116683138)
                this.Token = $.$default($.$GfYa.LCFCA.AuthToken);
                //--TRIMMABLE-BOUNDARY-END(584116683138)
                
                //--TRIMMABLE-BOUNDARY-START(107375313282)
                this.Created = null;
                //--TRIMMABLE-BOUNDARY-END(107375313282)
                
                //--TRIMMABLE-BOUNDARY-START(133145117058)
                this.Expires = null;
                //--TRIMMABLE-BOUNDARY-END(133145117058)
                
                //--TRIMMABLE-BOUNDARY-START(403728056706)
                this.LCFC$IDisplayable$Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(403728056706)
                
            }
            //--TRIMMABLE-BOUNDARY-START(85900476802)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900476802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(111670280578)
                    this.Default = new $.$GfYa.LCFCA.DecodedAuthenticationTicket().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(111670280578)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900476802)
            
            //Begin generated record members
            /*Type*/ get EqualityContract() { return $.$typeOf($.$GfYa.LCFCA.DecodedAuthenticationTicket); }
            /*string*/ ToString()
            {
                let stringBuilder = new $.$$.ST.StringBuilder().$ctor$1();
                stringBuilder.Append$21("DecodedAuthenticationTicket");
                stringBuilder.Append$21("{");
                if (this.PrintMembers(stringBuilder))
                {
                    stringBuilder.Append$21(" ");
                }
                stringBuilder.Append$21("}");
                return stringBuilder.ToString();
            }
            /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
            {
                stringBuilder.Append$21("Id = ");
                stringBuilder.Append$21(this.Id);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("UserName = ");
                stringBuilder.Append$21(this.UserName);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("FirstName = ");
                stringBuilder.Append$21(this.FirstName);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("LastName = ");
                stringBuilder.Append$21(this.LastName);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Email = ");
                stringBuilder.Append$21(this.Email);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("PhoneNumber = ");
                stringBuilder.Append$21(this.PhoneNumber);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("PhoneNumberVerified = ");
                stringBuilder.Append$21($.$$.S.Boolean.ToString.call(this.PhoneNumberVerified));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Image = ");
                stringBuilder.Append$21(this.Image);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Token = ");
                stringBuilder.Append$21($.$dsp(this.Token, $.$$.S.Object, ($t) => $t.ToString));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Cookies = ");
                stringBuilder.Append$21($.$dsp(this.Cookies, $.$$.S.Object, ($t) => $t.ToString));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Created = ");
                stringBuilder.Append$21(this.Created.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Expires = ");
                stringBuilder.Append$21(this.Expires.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Roles = ");
                stringBuilder.Append$21($.$dsp(this.Roles, $.$$.S.Object, ($t) => $t.ToString));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Claims = ");
                stringBuilder.Append$21($.$dsp(this.Claims, $.$$.S.Object, ($t) => $t.ToString));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("IsFresh = ");
                stringBuilder.Append$21($.$$.S.Boolean.ToString.call(this.IsFresh));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ImageResource = ");
                stringBuilder.Append$21(this.ImageResource.ToString());
                return true;
            }
            /*bool*/ Equals$2(/*DecodedAuthenticationTicket*/ other)
            {
                return this === other || (other !== null && this.EqualityContract == other.EqualityContract && $.$$.S.String.op_Equality(this.Id, other.Id) && $.$$.S.String.op_Equality(this.UserName, other.UserName) && $.$$.S.String.op_Equality(this.FirstName, other.FirstName) && $.$$.S.String.op_Equality(this.LastName, other.LastName) && $.$$.S.String.op_Equality(this.Email, other.Email) && $.$$.S.String.op_Equality(this.PhoneNumber, other.PhoneNumber) && this.PhoneNumberVerified === other.PhoneNumberVerified && $.$$.S.String.op_Equality(this.Image, other.Image) && $.$$.SCG.EqualityComparer$$($.$GfYa.LCFCA.AuthToken).Default.Equals$2(this.Token, other.Token) && $.$$.SCG.EqualityComparer$$($.$$.SCG.IEnumerable$$($.$$.S.String)).Default.Equals$2(this.Cookies, other.Cookies) && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.DateTime)).Default.Equals$2(this.Created, other.Created) && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.DateTime)).Default.Equals$2(this.Expires, other.Expires) && $.$$.SCG.EqualityComparer$$($.$$.SCG.IEnumerable$$($.$$.S.String)).Default.Equals$2(this.Roles, other.Roles) && $.$$.SCG.EqualityComparer$$($.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim)).Default.Equals$2(this.Claims, other.Claims) && this.IsFresh === other.IsFresh && $.$$.SCG.EqualityComparer$$($.$Iaui.LCFCM.ResourceModel).Default.Equals$2(this.ImageResource, other.ImageResource));
            }
            /*int*/ GetHashCode()
            {
                return $.$$.SCG.EqualityComparer$$($.$$.S.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.Id) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.UserName) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.FirstName) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.LastName) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.Email) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.PhoneNumber) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Boolean).Default.GetHashCode$1(this.PhoneNumberVerified) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.Image) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$GfYa.LCFCA.AuthToken).Default.GetHashCode$1(this.Token) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.SCG.IEnumerable$$($.$$.S.String)).Default.GetHashCode$1(this.Cookies) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.DateTime)).Default.GetHashCode$1(this.Created) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.DateTime)).Default.GetHashCode$1(this.Expires) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.SCG.IEnumerable$$($.$$.S.String)).Default.GetHashCode$1(this.Roles) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim)).Default.GetHashCode$1(this.Claims) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Boolean).Default.GetHashCode$1(this.IsFresh) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$Iaui.LCFCM.ResourceModel).Default.GetHashCode$1(this.ImageResource) * -1521134295;
            }
            static /*bool*/ op_Inequality(/*DecodedAuthenticationTicket*/ left, /*DecodedAuthenticationTicket*/ right)
            {
                return !(this.op_Equality(left, right));
            }
            static /*bool*/ op_Equality(/*DecodedAuthenticationTicket*/ left, /*DecodedAuthenticationTicket*/ right)
            {
                return left === right || (left !== null && left.Equals$2(right));
            }
            Deconstruct(/*out string?*/ $Id, /*out string?*/ $UserName, /*out string?*/ $FirstName, /*out string?*/ $LastName, /*out string?*/ $Email, /*out string?*/ $PhoneNumber, /*out bool*/ $PhoneNumberVerified, /*out string?*/ $Image, /*out LivingThing.Core.Frameworks.Common.Authentication.AuthToken*/ $Token, /*out System.Collections.Generic.IEnumerable<string>?*/ $Cookies, /*out System.DateTime?*/ $Created, /*out System.DateTime?*/ $Expires, /*out System.Collections.Generic.IEnumerable<string>?*/ $Roles, /*out System.Collections.Generic.IEnumerable<System.Security.Claims.Claim>?*/ $Claims, /*out bool*/ $IsFresh, /*out LivingThing.Core.Frameworks.Common.Models.ResourceModel?*/ $ImageResource)
            {
                $Id.$v = this.Id;
                $UserName.$v = this.UserName;
                $FirstName.$v = this.FirstName;
                $LastName.$v = this.LastName;
                $Email.$v = this.Email;
                $PhoneNumber.$v = this.PhoneNumber;
                $PhoneNumberVerified.$v = this.PhoneNumberVerified;
                $Image.$v = this.Image;
                $Token.$v = this.Token;
                $Cookies.$v = this.Cookies;
                $Created.$v = this.Created;
                $Expires.$v = this.Expires;
                $Roles.$v = this.Roles;
                $Claims.$v = this.Claims;
                $IsFresh.$v = this.IsFresh;
                $ImageResource.$v = this.ImageResource;
            }
            //End generated record member3s
            static $h = 1130882;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120260215170),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684724610,
        "f": 50331780
      },
      "n": "EqualityContract",
      "d": 1130882,
      "h": 120260215170,
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(120260215170),
//--TRIMMABLE-BOUNDARY-START(304943808898),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210454528386,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 511102239106,
        "f": 83886081
      },
      "n": "Id",
      "d": 1130882,
      "h": 304943808898,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304943808898),
//--TRIMMABLE-BOUNDARY-START(592706617730),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287763939714,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 579821715842,
        "f": 83886081
      },
      "n": "UserName",
      "d": 1130882,
      "h": 592706617730,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(592706617730),
//--TRIMMABLE-BOUNDARY-START(137440084354),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864593794,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 502512304514,
        "f": 83886081
      },
      "n": "FirstName",
      "d": 1130882,
      "h": 137440084354,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137440084354),
//--TRIMMABLE-BOUNDARY-START(343598514562),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244814266754,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 536872042882,
        "f": 83886081
      },
      "n": "LastName",
      "d": 1130882,
      "h": 343598514562,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(343598514562),
//--TRIMMABLE-BOUNDARY-START(115965247874),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094790018,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 485332435330,
        "f": 83886081
      },
      "n": "Email",
      "d": 1130882,
      "h": 115965247874,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965247874),
//--TRIMMABLE-BOUNDARY-START(438087795074),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253404201346,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 545461977474,
        "f": 83886081
      },
      "n": "PhoneNumber",
      "d": 1130882,
      "h": 438087795074,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(438087795074),
//--TRIMMABLE-BOUNDARY-START(442382762370),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261994135938,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 554051912066,
        "f": 83886081
      },
      "n": "PhoneNumberVerified",
      "d": 1130882,
      "h": 442382762370,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(442382762370),
//--TRIMMABLE-BOUNDARY-START(309238776194),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219044462978,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 519692173698,
        "f": 83886081
      },
      "n": "Image",
      "d": 1130882,
      "h": 309238776194,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309238776194),
//--TRIMMABLE-BOUNDARY-START(584116683138),
    {
      "p": 868738,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279174005122,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 571231781250,
        "f": 83886081
      },
      "n": "Token",
      "d": 1130882,
      "h": 584116683138,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(584116683138),
//--TRIMMABLE-BOUNDARY-START(103080345986),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914920834,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 468152566146,
        "f": 83886081
      },
      "n": "Cookies",
      "d": 1130882,
      "h": 103080345986,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080345986),
//--TRIMMABLE-BOUNDARY-START(107375313282),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504855426,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 476742500738,
        "f": 83886081
      },
      "n": "Created",
      "d": 1130882,
      "h": 107375313282,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375313282),
//--TRIMMABLE-BOUNDARY-START(133145117058),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274659202,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 493922369922,
        "f": 83886081
      },
      "n": "Expires",
      "d": 1130882,
      "h": 133145117058,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145117058),
//--TRIMMABLE-BOUNDARY-START(450972696962),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270584070530,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 562641846658,
        "f": 83886081
      },
      "n": "Roles",
      "d": 1130882,
      "h": 450972696962,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(450972696962),
//--TRIMMABLE-BOUNDARY-START(98785378690),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324986242,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 459562631554,
        "f": 83886081
      },
      "n": "Claims",
      "d": 1130882,
      "h": 98785378690,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785378690),
//--TRIMMABLE-BOUNDARY-START(330713612674),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236224332162,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 528282108290,
        "f": 83886081
      },
      "n": "IsFresh",
      "d": 1130882,
      "h": 330713612674,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(330713612674),
//--TRIMMABLE-BOUNDARY-START(313533743490),
    {
      "p": 15279446,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634397570,
        "f": 50331649
      },
      "n": "ImageResource",
      "d": 1130882,
      "h": 313533743490,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(313533743490),
//--TRIMMABLE-BOUNDARY-START(365073351042),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 352188449154,
        "f": 50331650
      },
      "n": "{5081430}.Identifier",
      "o": "LCFCC$2$IContact$Identifier",
      "d": 1130882,
      "h": 365073351042,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(365073351042),
//--TRIMMABLE-BOUNDARY-START(369368318338),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 360778383746,
        "f": 50331650
      },
      "n": "{5081430}.Location",
      "o": "LCFCC$2$IContact$Location",
      "d": 1130882,
      "h": 369368318338,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(369368318338),
//--TRIMMABLE-BOUNDARY-START(408023024002),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399433089410,
        "f": 50331650
      },
      "n": "{46893398}.Title",
      "o": "LCFC$IDisplayable$Title",
      "d": 1130882,
      "h": 408023024002,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(408023024002),
//--TRIMMABLE-BOUNDARY-START(373663285634),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382253220226,
        "f": 50331650
      },
      "n": "{46827862}.Description",
      "o": "LCFC$IDescribable$Description",
      "d": 1130882,
      "h": 373663285634,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(373663285634),
//--TRIMMABLE-BOUNDARY-START(403728056706),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390843154818,
        "f": 50331650
      },
      "n": "{46893398}.Icon",
      "o": "LCFC$IDisplayable$Icon",
      "d": 1130882,
      "h": 403728056706,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(403728056706),
//--TRIMMABLE-BOUNDARY-START(420907925890),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416612958594,
        "f": 50331650
      },
      "n": "{47483222}.Name",
      "o": "LCFC$INamed$Name",
      "d": 1130882,
      "h": 420907925890,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(420907925890)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(339303547266),
    {
      "r": 262145,
      "n": "IsValid",
      "d": 1130882,
      "h": 339303547266,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(339303547266),
//--TRIMMABLE-BOUNDARY-START(425202893186),
    {
      "r": 262145,
      "n": "NeedsRefresh",
      "d": 1130882,
      "h": 425202893186,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(425202893186),
//--TRIMMABLE-BOUNDARY-START(335008579970),
    {
      "r": 262145,
      "n": "IsSuperAdmin",
      "d": 1130882,
      "h": 335008579970,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(335008579970),
//--TRIMMABLE-BOUNDARY-START(317828710786),
    {
      "r": 262145,
      "n": "IsAdmin",
      "d": 1130882,
      "h": 317828710786,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(317828710786),
//--TRIMMABLE-BOUNDARY-START(322123678082),
    {
      "r": 262145,
      "n": "IsAnonymous",
      "d": 1130882,
      "h": 322123678082,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(322123678082),
//--TRIMMABLE-BOUNDARY-START(326418645378),
    {
      "r": 262145,
      "n": "IsDemo",
      "d": 1130882,
      "h": 326418645378,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(326418645378),
//--TRIMMABLE-BOUNDARY-START(300648841602),
    {
      "r": 262145,
      "p": [
        {
          "n": "roles",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "HasRoles",
      "o": "@$1",
      "d": 1130882,
      "h": 300648841602,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(300648841602),
//--TRIMMABLE-BOUNDARY-START(296353874306),
    {
      "r": 262145,
      "p": [
        {
          "n": "roles",
          "p": 1310721
        }
      ],
      "n": "HasRoles",
      "d": 1130882,
      "h": 296353874306,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296353874306),
//--TRIMMABLE-BOUNDARY-START(141735051650),
    {
      "r": 1130882,
      "p": [
        {
          "n": "principal",
          "p": 393285
        }
      ],
      "n": "FromPrincipal",
      "d": 1130882,
      "h": 141735051650,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141735051650),
//--TRIMMABLE-BOUNDARY-START(588411650434),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1130882,
      "h": 588411650434,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(588411650434),
//--TRIMMABLE-BOUNDARY-START(446677729666),
    {
      "r": 262145,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        }
      ],
      "n": "PrintMembers",
      "d": 1130882,
      "h": 446677729666,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(446677729666),
//--TRIMMABLE-BOUNDARY-START(292058907010),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1130882,
      "h": 292058907010,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(292058907010),
//--TRIMMABLE-BOUNDARY-START(124555182466),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1130882,
      "h": 124555182466,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555182466),
//--TRIMMABLE-BOUNDARY-START(128850149762),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1130882
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1130882,
      "h": 128850149762,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(128850149762),
//--TRIMMABLE-BOUNDARY-START(12886032770),
    {
      "r": 1130882,
      "n": "\u003CClone\u003E$",
      "o": "$$$",
      "d": 1130882,
      "h": 12886032770,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886032770)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(111670280578),
    {
      "t": 1130882,
      "n": "Default",
      "d": 1130882,
      "h": 111670280578,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670280578),
//--TRIMMABLE-BOUNDARY-START(4296098178),
    {
      "t": 1310721,
      "n": "_userName",
      "d": 1130882,
      "h": 4296098178,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296098178)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(94490411394),
    {
      "p": [
        {
          "n": "original",
          "p": 1130882
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1130882,
      "h": 94490411394,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(94490411394),
//--TRIMMABLE-BOUNDARY-START(90195444098),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1130882,
      "h": 90195444098,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195444098)
  ],
  "h": 1130882,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$$.S.IEquatable$$($.$GfYa.LCFCA.DecodedAuthenticationTicket) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}DecodedAuthenticationTicket`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1130882)
        
        

        //--TRIMMABLE-BOUNDARY-START(868738)
        $asm.$str(`$GfYa.LCFCA.AuthToken`, ($self) => class AuthToken extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(81605247362)
            /*string?*/ Provider = null;
            //--TRIMMABLE-BOUNDARY-END(81605247362)
            
            //--TRIMMABLE-BOUNDARY-START(85900214658)
            /*string?*/ ProviderKey = null;
            //--TRIMMABLE-BOUNDARY-END(85900214658)
            
            //--TRIMMABLE-BOUNDARY-START(30065639810)
            /*string?*/ AccessToken = null;
            //--TRIMMABLE-BOUNDARY-END(30065639810)
            
            //--TRIMMABLE-BOUNDARY-START(90195181954)
            /*string?*/ RefreshToken = null;
            //--TRIMMABLE-BOUNDARY-END(90195181954)
            
            //--TRIMMABLE-BOUNDARY-START(77310280066)
            /*string?*/ JWToken = null;
            //--TRIMMABLE-BOUNDARY-END(77310280066)
            
            //--TRIMMABLE-BOUNDARY-START(25770672514)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770672514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770672514)
            
            //--TRIMMABLE-BOUNDARY-START(25770672514)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(25770672514)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Provider = this.Provider;
                copy.ProviderKey = this.ProviderKey;
                copy.AccessToken = this.AccessToken;
                copy.RefreshToken = this.RefreshToken;
                copy.JWToken = this.JWToken;
                return copy;
            }
            static $h = 868738;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605247362),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835443586,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964985730,
        "f": 83886081
      },
      "n": "Provider",
      "d": 868738,
      "h": 81605247362,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605247362),
//--TRIMMABLE-BOUNDARY-START(85900214658),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425378178,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554920322,
        "f": 83886081
      },
      "n": "ProviderKey",
      "d": 868738,
      "h": 85900214658,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900214658),
//--TRIMMABLE-BOUNDARY-START(30065639810),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655574402,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785116546,
        "f": 83886081
      },
      "n": "AccessToken",
      "d": 868738,
      "h": 30065639810,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065639810),
//--TRIMMABLE-BOUNDARY-START(90195181954),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015312770,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144854914,
        "f": 83886081
      },
      "n": "RefreshToken",
      "d": 868738,
      "h": 90195181954,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195181954),
//--TRIMMABLE-BOUNDARY-START(77310280066),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245508994,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375051138,
        "f": 83886081
      },
      "n": "JWToken",
      "d": 868738,
      "h": 77310280066,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310280066)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770672514),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 868738,
      "h": 25770672514,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770672514)
  ],
  "h": 868738,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(868738)
        
        

        //--TRIMMABLE-BOUNDARY-START(737666)
        $asm.$str(`$GfYa.LCFCA.AuthenticationTokenPurpose`, ($self) => class AuthenticationTokenPurpose extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Register = 1;
            static ResetPassword = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(737666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Register": 1n,
                    "ResetPassword": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295704962)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295704962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295704962)
            
            //--TRIMMABLE-BOUNDARY-START(4295704962)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295704962)
            
            static $h = 737666;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590672258),
    {
      "t": 737666,
      "n": "None",
      "d": 737666,
      "h": 8590672258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590672258),
//--TRIMMABLE-BOUNDARY-START(12885639554),
    {
      "t": 737666,
      "n": "Register",
      "d": 737666,
      "h": 12885639554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885639554),
//--TRIMMABLE-BOUNDARY-START(17180606850),
    {
      "t": 737666,
      "n": "ResetPassword",
      "d": 737666,
      "h": 17180606850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180606850)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295704962),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 737666,
      "h": 4295704962,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295704962)
  ],
  "h": 737666
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationTokenPurpose`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationTokenPurpose`; }
        });
        //--TRIMMABLE-BOUNDARY-END(737666)
        
        

        //--TRIMMABLE-BOUNDARY-START(409986)
        $asm.$str(`$GfYa.LCFCA.AuthenticationLoginState`, ($self) => class AuthenticationLoginState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static LoggingIn = 0;
            static NotLoggedIn = 1;
            static LoggedIn = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(409986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "LoggingIn": 0n,
                    "NotLoggedIn": 1n,
                    "LoggedIn": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295377282)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295377282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295377282)
            
            //--TRIMMABLE-BOUNDARY-START(4295377282)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295377282)
            
            static $h = 409986;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885311874),
    {
      "t": 409986,
      "n": "LoggingIn",
      "d": 409986,
      "h": 12885311874,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885311874),
//--TRIMMABLE-BOUNDARY-START(17180279170),
    {
      "t": 409986,
      "n": "NotLoggedIn",
      "d": 409986,
      "h": 17180279170,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180279170),
//--TRIMMABLE-BOUNDARY-START(8590344578),
    {
      "t": 409986,
      "n": "LoggedIn",
      "d": 409986,
      "h": 8590344578,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590344578)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295377282),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 409986,
      "h": 4295377282,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295377282)
  ],
  "h": 409986
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationLoginState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationLoginState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(409986)
        
        

        //--TRIMMABLE-BOUNDARY-START(2244994)
        $asm.$str(`$GfYa.LCFCA.SignInStatus`, ($self) => class SignInStatus extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Success = 0;
            static NoSuchAccount = 1;
            static AccountLocked = 2;
            static VerificationPending = 3;
            static ChoosePassword = 4;
            static Failure = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2244994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Success": 0n,
                    "NoSuchAccount": 1n,
                    "AccountLocked": 2n,
                    "VerificationPending": 3n,
                    "ChoosePassword": 4n,
                    "Failure": 5n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297212290)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297212290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297212290)
            
            //--TRIMMABLE-BOUNDARY-START(4297212290)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297212290)
            
            static $h = 2244994;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25772048770),
    {
      "t": 2244994,
      "n": "Success",
      "d": 2244994,
      "h": 25772048770,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772048770),
//--TRIMMABLE-BOUNDARY-START(21477081474),
    {
      "t": 2244994,
      "n": "NoSuchAccount",
      "d": 2244994,
      "h": 21477081474,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477081474),
//--TRIMMABLE-BOUNDARY-START(8592179586),
    {
      "t": 2244994,
      "n": "AccountLocked",
      "d": 2244994,
      "h": 8592179586,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592179586),
//--TRIMMABLE-BOUNDARY-START(30067016066),
    {
      "t": 2244994,
      "n": "VerificationPending",
      "d": 2244994,
      "h": 30067016066,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067016066),
//--TRIMMABLE-BOUNDARY-START(12887146882),
    {
      "t": 2244994,
      "n": "ChoosePassword",
      "d": 2244994,
      "h": 12887146882,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887146882),
//--TRIMMABLE-BOUNDARY-START(17182114178),
    {
      "t": 2244994,
      "n": "Failure",
      "d": 2244994,
      "h": 17182114178,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182114178)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297212290),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2244994,
      "h": 4297212290,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297212290)
  ],
  "h": 2244994
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.SignInStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}SignInStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2244994)
        
        

        //--TRIMMABLE-BOUNDARY-START(1917314)
        $asm.$str(`$GfYa.LCFCA.JwtHashAlgorithm`, ($self) => class JwtHashAlgorithm extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static HS256 = 0;
            static HS384 = 1;
            static HS512 = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1917314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "HS256": 0n,
                    "HS384": 1n,
                    "HS512": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296884610)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296884610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296884610)
            
            //--TRIMMABLE-BOUNDARY-START(4296884610)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296884610)
            
            static $h = 1917314;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591851906),
    {
      "t": 1917314,
      "n": "HS256",
      "d": 1917314,
      "h": 8591851906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591851906),
//--TRIMMABLE-BOUNDARY-START(12886819202),
    {
      "t": 1917314,
      "n": "HS384",
      "d": 1917314,
      "h": 12886819202,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886819202),
//--TRIMMABLE-BOUNDARY-START(17181786498),
    {
      "t": 1917314,
      "n": "HS512",
      "d": 1917314,
      "h": 17181786498,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181786498)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296884610),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1917314,
      "h": 4296884610,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296884610)
  ],
  "h": 1917314
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.JwtHashAlgorithm`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}JwtHashAlgorithm`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1917314)
        
        

        //--TRIMMABLE-BOUNDARY-START(278914)
        $asm.$cls(`$GfYa.LCFCA.AuthenticationEventArgs`, ($self) => class AuthenticationEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(30065049986)
            /*DecodedAuthenticationTicket*/ Ticket = null;
            //--TRIMMABLE-BOUNDARY-END(30065049986)
            
            //--TRIMMABLE-BOUNDARY-START(8590213506)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590213506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590213506)
            
            //--TRIMMABLE-BOUNDARY-START(8590213506)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590213506)
            
            static $h = 278914;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065049986),
    {
      "p": 1130882,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180148098,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25770082690,
        "f": 83886081
      },
      "n": "Ticket",
      "d": 278914,
      "h": 30065049986,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065049986)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590213506),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 278914,
      "h": 8590213506,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590213506)
  ],
  "h": 278914
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(278914)
        
        

        //--TRIMMABLE-BOUNDARY-START(147842)
        $asm.$cls(`$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor`, ($self) => class AuthenticationClientDescriptorTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$GfYa.LCFCA.AuthenticationClientDescriptor)
        {
            //--TRIMMABLE-BOUNDARY-START(4295115138)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295115138);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor.GenerateProperties($.$GfYa.LCFCA.AuthenticationClientDescriptor, this, factory);
                    }, $pRhWrk ??= {"r":65537,"n":"","d":147842,"h":0,"f":17825794}), 0, "AuthenticationClientDescriptorTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Authentication\\AuthenticationClientDescriptor_LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptorTypeDescriptorBuilder.g.cs", "AuthenticationClientDescriptorTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295115138)
            
            //--TRIMMABLE-BOUNDARY-START(12885049730)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885049730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ApplicationName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, $.$discardRef(), "ApplicationName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ApplicationName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ApplicationName";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationClientDescriptor)).ApplicationName);
                        }, $isbgmh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":147842,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ApplicationName = value.AsReference($.$$.S.String);
                        }, $CcLFNj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":147842,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ApplicationIcon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, $.$discardRef(), "ApplicationIcon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ApplicationIcon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ApplicationIcon";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationClientDescriptor)).ApplicationIcon);
                        }, $Cornth ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":147842,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ApplicationIcon = value.AsReference($.$$.S.String);
                        }, $OgyEda ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":147842,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ApplicationScheme"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, $.$discardRef(), "ApplicationScheme", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ApplicationScheme")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "ApplicationScheme";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationClientDescriptor)).ApplicationScheme);
                        }, $jMoInh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":147842,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ApplicationScheme = value.AsReference($.$$.S.String);
                        }, $JmpLyc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":147842,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ApplicationBaseUrl"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, $.$discardRef(), "ApplicationBaseUrl", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ApplicationBaseUrl")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "ApplicationBaseUrl";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationClientDescriptor)).ApplicationBaseUrl);
                        }, $siZzdi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":147842,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ApplicationBaseUrl = value.AsReference($.$$.S.String);
                        }, $fQzdCg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":147842,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ApplicationTheme"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, $.$discardRef(), "ApplicationTheme", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ApplicationTheme")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "ApplicationTheme";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationClientDescriptor)).ApplicationTheme);
                        }, $fVkymh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":147842,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ApplicationTheme = value.AsReference($.$$.S.String);
                        }, $fnHftg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":147842,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AuthenticationPageRoute"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, $.$discardRef(), "AuthenticationPageRoute", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AuthenticationPageRoute")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "AuthenticationPageRoute";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationClientDescriptor)).AuthenticationPageRoute);
                        }, $WUoZmj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":147842,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.AuthenticationPageRoute = value.AsReference($.$$.S.String);
                        }, $UgExxh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":147842,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ApplicationAccountServiceType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, $.$discardRef(), "ApplicationAccountServiceType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ApplicationAccountServiceType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "ApplicationAccountServiceType";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationClientDescriptor)).ApplicationAccountServiceType);
                        }, $khZqWa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":147842,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ApplicationAccountServiceType = value.AsReference($.$$.S.String);
                        }, $wNPdSd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":147842,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ApplicationAccountServiceParameters"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, $.$discardRef(), "ApplicationAccountServiceParameters", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ApplicationAccountServiceParameters")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "ApplicationAccountServiceParameters";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), ($.$cast(target, $.$GfYa.LCFCA.AuthenticationClientDescriptor)).ApplicationAccountServiceParameters);
                        }, $kEDqhk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":147842,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ApplicationAccountServiceParameters = value.AsReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object));
                        }, $bWIJZh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":147842,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RegisterationEmailTemplateUrl"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, $.$discardRef(), "RegisterationEmailTemplateUrl", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RegisterationEmailTemplateUrl")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "RegisterationEmailTemplateUrl";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationClientDescriptor)).RegisterationEmailTemplateUrl);
                        }, $vWypcl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":147842,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.RegisterationEmailTemplateUrl = value.AsReference($.$$.S.String);
                        }, $azXCZi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":147842,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ResetPasswordEmailTemplateUrl"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationClientDescriptor.$type, $.$discardRef(), "ResetPasswordEmailTemplateUrl", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ResetPasswordEmailTemplateUrl")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "ResetPasswordEmailTemplateUrl";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationClientDescriptor)).ResetPasswordEmailTemplateUrl);
                        }, $VKRfRh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":147842,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ResetPasswordEmailTemplateUrl = value.AsReference($.$$.S.String);
                        }, $jMwufd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":147842,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885049730)
            
            //--TRIMMABLE-BOUNDARY-START(17180017026)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180017026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _ApplicationName = _target.ApplicationName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ApplicationName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ApplicationName, ($v) => _ApplicationName = $v, $.$$.S.String)))
                    {
                        _target.ApplicationName = _ApplicationName;
                    }
                }
                {
                    /*var*/ let _ApplicationIcon = _target.ApplicationIcon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ApplicationIcon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ApplicationIcon, ($v) => _ApplicationIcon = $v, $.$$.S.String)))
                    {
                        _target.ApplicationIcon = _ApplicationIcon;
                    }
                }
                {
                    /*var*/ let _ApplicationScheme = _target.ApplicationScheme;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ApplicationScheme"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ApplicationScheme, ($v) => _ApplicationScheme = $v, $.$$.S.String)))
                    {
                        _target.ApplicationScheme = _ApplicationScheme;
                    }
                }
                {
                    /*var*/ let _ApplicationBaseUrl = _target.ApplicationBaseUrl;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ApplicationBaseUrl"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ApplicationBaseUrl, ($v) => _ApplicationBaseUrl = $v, $.$$.S.String)))
                    {
                        _target.ApplicationBaseUrl = _ApplicationBaseUrl;
                    }
                }
                {
                    /*var*/ let _ApplicationTheme = _target.ApplicationTheme;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ApplicationTheme"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ApplicationTheme, ($v) => _ApplicationTheme = $v, $.$$.S.String)))
                    {
                        _target.ApplicationTheme = _ApplicationTheme;
                    }
                }
                {
                    /*var*/ let _AuthenticationPageRoute = _target.AuthenticationPageRoute;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AuthenticationPageRoute"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _AuthenticationPageRoute, ($v) => _AuthenticationPageRoute = $v, $.$$.S.String)))
                    {
                        _target.AuthenticationPageRoute = _AuthenticationPageRoute;
                    }
                }
                {
                    /*var*/ let _ApplicationAccountServiceType = _target.ApplicationAccountServiceType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ApplicationAccountServiceType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ApplicationAccountServiceType, ($v) => _ApplicationAccountServiceType = $v, $.$$.S.String)))
                    {
                        _target.ApplicationAccountServiceType = _ApplicationAccountServiceType;
                    }
                }
                {
                    /*var*/ let _ApplicationAccountServiceParameters = _target.ApplicationAccountServiceParameters;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ApplicationAccountServiceParameters"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ApplicationAccountServiceParameters, ($v) => _ApplicationAccountServiceParameters = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))))
                    {
                        _target.ApplicationAccountServiceParameters = _ApplicationAccountServiceParameters;
                    }
                }
                {
                    /*var*/ let _RegisterationEmailTemplateUrl = _target.RegisterationEmailTemplateUrl;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RegisterationEmailTemplateUrl"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _RegisterationEmailTemplateUrl, ($v) => _RegisterationEmailTemplateUrl = $v, $.$$.S.String)))
                    {
                        _target.RegisterationEmailTemplateUrl = _RegisterationEmailTemplateUrl;
                    }
                }
                {
                    /*var*/ let _ResetPasswordEmailTemplateUrl = _target.ResetPasswordEmailTemplateUrl;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ResetPasswordEmailTemplateUrl"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ResetPasswordEmailTemplateUrl, ($v) => _ResetPasswordEmailTemplateUrl = $v, $.$$.S.String)))
                    {
                        _target.ResetPasswordEmailTemplateUrl = _ResetPasswordEmailTemplateUrl;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180017026)
            
            //--TRIMMABLE-BOUNDARY-START(8590082434)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptor?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590082434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$GfYa.LCFCA.AuthenticationClientDescriptor().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$GfYa.LCFCA.AuthenticationClientDescriptor, null, $.$ref(() => _target, ($v) => _target = $v, $.$GfYa.LCFCA.AuthenticationClientDescriptor)))
                {
                    /*var*/ let result = $.$GfYa.LCFCA.AuthenticationClientDescriptorTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$GfYa.LCFCA.AuthenticationClientDescriptor));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$GfYa.LCFCA.AuthenticationClientDescriptor, null, $.$ref(() => _target, ($v) => _target = $v, $.$GfYa.LCFCA.AuthenticationClientDescriptor));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590082434)
            
            static $h = 147842;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$GfYa.LCFCA.AuthenticationClientDescriptor); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885049730),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 147842,
      "h": 12885049730,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885049730),
//--TRIMMABLE-BOUNDARY-START(17180017026),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 82306,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 147842,
      "h": 17180017026,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180017026),
//--TRIMMABLE-BOUNDARY-START(8590082434),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 82306,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 147842,
      "h": 8590082434,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590082434)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295115138),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 147842,
      "h": 4295115138,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295115138)
  ],
  "h": 147842
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$GfYa.LCFCA.AuthenticationClientDescriptor), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationClientDescriptorTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationClientDescriptorTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(147842)
        
        

        //--TRIMMABLE-BOUNDARY-START(606594)
        $asm.$cls(`$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor`, ($self) => class AuthenticationMetadataTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$GfYa.LCFCA.AuthenticationMetadata)
        {
            //--TRIMMABLE-BOUNDARY-START(4295573890)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295573890);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor.GenerateProperties($.$GfYa.LCFCA.AuthenticationMetadata, this, factory);
                    }, $kNUsPg ??= {"r":65537,"n":"","d":606594,"h":0,"f":17825794}), 0, "AuthenticationMetadataTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Authentication\\AuthenticationMetadata_LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadataTypeDescriptorBuilder.g.cs", "AuthenticationMetadataTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295573890)
            
            //--TRIMMABLE-BOUNDARY-START(12885508482)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885508482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TokenPurpose"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationMetadata.$type, $.$discardRef(), "TokenPurpose", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TokenPurpose")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$GfYa.LCFCA.AuthenticationTokenPurpose), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "TokenPurpose";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$GfYa.LCFCA.AuthenticationTokenPurpose, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationMetadata)).TokenPurpose);
                        }, $wgkJsd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":606594,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TokenPurpose = value.AsNullableValue($.$GfYa.LCFCA.AuthenticationTokenPurpose);
                        }, $MXpzKb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":606594,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TokenEmail"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationMetadata.$type, $.$discardRef(), "TokenEmail", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TokenEmail")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "TokenEmail";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationMetadata)).TokenEmail);
                        }, $WKIYVj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":606594,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.TokenEmail = value.AsReference($.$$.S.String);
                        }, $vOZsRj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":606594,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("TokenValue"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationMetadata.$type, $.$discardRef(), "TokenValue", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("TokenValue")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "TokenValue";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationMetadata)).TokenValue);
                        }, $FuReaj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":606594,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.TokenValue = value.AsReference($.$$.S.String);
                        }, $wnhOVj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":606594,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ReferrerId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationMetadata.$type, $.$discardRef(), "ReferrerId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ReferrerId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "ReferrerId";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationMetadata)).ReferrerId);
                        }, $iFjDNi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":606594,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.ReferrerId = value.AsReference($.$$.S.String);
                        }, $cohgrh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":606594,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ReferrerHandlerId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationMetadata.$type, $.$discardRef(), "ReferrerHandlerId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ReferrerHandlerId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "ReferrerHandlerId";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationMetadata)).ReferrerHandlerId);
                        }, $HQSpbb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":606594,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ReferrerHandlerId = value.AsReference($.$$.S.String);
                        }, $HVXrml ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":606594,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ReferrerData"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationMetadata.$type, $.$discardRef(), "ReferrerData", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ReferrerData")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "ReferrerData";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationMetadata)).ReferrerData);
                        }, $gNwqdf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":606594,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.ReferrerData = value.AsReference($.$$.S.String);
                        }, $Dsdcng ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":606594,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LoginExpiryMinutes"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationMetadata.$type, $.$discardRef(), "LoginExpiryMinutes", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LoginExpiryMinutes")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.Int32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "LoginExpiryMinutes";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.Int32, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationMetadata)).LoginExpiryMinutes);
                        }, $JANJgg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":606594,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LoginExpiryMinutes = value.AsNullableValue($.$$.S.Int32);
                        }, $mcnMXd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":606594,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ApplicationAccountServiceParameter"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationMetadata.$type, $.$discardRef(), "ApplicationAccountServiceParameter", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ApplicationAccountServiceParameter")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "ApplicationAccountServiceParameter";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), ($.$cast(target, $.$GfYa.LCFCA.AuthenticationMetadata)).ApplicationAccountServiceParameter);
                        }, $vGaTfb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":606594,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ApplicationAccountServiceParameter = value.AsReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object));
                        }, $Mowtvg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":606594,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ReturnUrl"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationMetadata.$type, $.$discardRef(), "ReturnUrl", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ReturnUrl")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "ReturnUrl";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationMetadata)).ReturnUrl);
                        }, $MEalYd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":606594,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ReturnUrl = value.AsReference($.$$.S.String);
                        }, $yIOKRe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":606594,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ClientDescriptor"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthenticationMetadata.$type, $.$discardRef(), "ClientDescriptor", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ClientDescriptor")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$GfYa.LCFCA.AuthenticationClientDescriptor, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "ClientDescriptor";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$GfYa.LCFCA.AuthenticationClientDescriptor, ($.$cast(target, $.$GfYa.LCFCA.AuthenticationMetadata)).ClientDescriptor);
                        }, $bebadb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":606594,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ClientDescriptor = value.AsReference($.$GfYa.LCFCA.AuthenticationClientDescriptor);
                        }, $Rlzbyh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":606594,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885508482)
            
            //--TRIMMABLE-BOUNDARY-START(17180475778)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180475778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _TokenPurpose = _target.TokenPurpose;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TokenPurpose"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$GfYa.LCFCA.AuthenticationTokenPurpose)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$GfYa.LCFCA.AuthenticationTokenPurpose), () => _TokenPurpose, ($v) => _TokenPurpose = $v, null, true)))
                    {
                        _target.TokenPurpose = _TokenPurpose;
                    }
                }
                {
                    /*var*/ let _TokenEmail = _target.TokenEmail;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TokenEmail"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _TokenEmail, ($v) => _TokenEmail = $v, $.$$.S.String)))
                    {
                        _target.TokenEmail = _TokenEmail;
                    }
                }
                {
                    /*var*/ let _TokenValue = _target.TokenValue;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("TokenValue"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _TokenValue, ($v) => _TokenValue = $v, $.$$.S.String)))
                    {
                        _target.TokenValue = _TokenValue;
                    }
                }
                {
                    /*var*/ let _ReferrerId = _target.ReferrerId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ReferrerId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ReferrerId, ($v) => _ReferrerId = $v, $.$$.S.String)))
                    {
                        _target.ReferrerId = _ReferrerId;
                    }
                }
                {
                    /*var*/ let _ReferrerHandlerId = _target.ReferrerHandlerId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ReferrerHandlerId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ReferrerHandlerId, ($v) => _ReferrerHandlerId = $v, $.$$.S.String)))
                    {
                        _target.ReferrerHandlerId = _ReferrerHandlerId;
                    }
                }
                {
                    /*var*/ let _ReferrerData = _target.ReferrerData;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ReferrerData"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ReferrerData, ($v) => _ReferrerData = $v, $.$$.S.String)))
                    {
                        _target.ReferrerData = _ReferrerData;
                    }
                }
                {
                    /*var*/ let _LoginExpiryMinutes = _target.LoginExpiryMinutes;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LoginExpiryMinutes"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.Int32)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.Int32), () => _LoginExpiryMinutes, ($v) => _LoginExpiryMinutes = $v, null, true)))
                    {
                        _target.LoginExpiryMinutes = _LoginExpiryMinutes;
                    }
                }
                {
                    /*var*/ let _ApplicationAccountServiceParameter = _target.ApplicationAccountServiceParameter;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ApplicationAccountServiceParameter"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ApplicationAccountServiceParameter, ($v) => _ApplicationAccountServiceParameter = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))))
                    {
                        _target.ApplicationAccountServiceParameter = _ApplicationAccountServiceParameter;
                    }
                }
                {
                    /*var*/ let _ReturnUrl = _target.ReturnUrl;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ReturnUrl"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ReturnUrl, ($v) => _ReturnUrl = $v, $.$$.S.String)))
                    {
                        _target.ReturnUrl = _ReturnUrl;
                    }
                }
                {
                    /*var*/ let _ClientDescriptor = _target.ClientDescriptor;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ClientDescriptor"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$GfYa.LCFCA.AuthenticationClientDescriptor));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ClientDescriptor, ($v) => _ClientDescriptor = $v, $.$GfYa.LCFCA.AuthenticationClientDescriptor)))
                    {
                        _target.ClientDescriptor = _ClientDescriptor;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180475778)
            
            //--TRIMMABLE-BOUNDARY-START(8590541186)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadata?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590541186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$GfYa.LCFCA.AuthenticationMetadata().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$GfYa.LCFCA.AuthenticationMetadata, null, $.$ref(() => _target, ($v) => _target = $v, $.$GfYa.LCFCA.AuthenticationMetadata)))
                {
                    /*var*/ let result = $.$GfYa.LCFCA.AuthenticationMetadataTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$GfYa.LCFCA.AuthenticationMetadata));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$GfYa.LCFCA.AuthenticationMetadata, null, $.$ref(() => _target, ($v) => _target = $v, $.$GfYa.LCFCA.AuthenticationMetadata));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590541186)
            
            static $h = 606594;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$GfYa.LCFCA.AuthenticationMetadata); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885508482),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 606594,
      "h": 12885508482,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885508482),
//--TRIMMABLE-BOUNDARY-START(17180475778),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 541058,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 606594,
      "h": 17180475778,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180475778),
//--TRIMMABLE-BOUNDARY-START(8590541186),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 541058,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 606594,
      "h": 8590541186,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590541186)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295573890),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 606594,
      "h": 4295573890,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295573890)
  ],
  "h": 606594
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$GfYa.LCFCA.AuthenticationMetadata), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthenticationMetadataTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthenticationMetadataTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(606594)
        
        

        //--TRIMMABLE-BOUNDARY-START(1196418)
        $asm.$cls(`$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor`, ($self) => class DecodedAuthenticationTicketTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$GfYa.LCFCA.DecodedAuthenticationTicket)
        {
            //--TRIMMABLE-BOUNDARY-START(4296163714)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296163714);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor.GenerateProperties($.$GfYa.LCFCA.DecodedAuthenticationTicket, this, factory);
                    }, $SfNCml ??= {"r":65537,"n":"","d":1196418,"h":0,"f":17825794}), 0, "DecodedAuthenticationTicketTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Authentication\\DecodedAuthenticationTicket_LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicketTypeDescriptorBuilder.g.cs", "DecodedAuthenticationTicketTypeDescriptor", 40);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296163714)
            
            //--TRIMMABLE-BOUNDARY-START(12886098306)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886098306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).Id);
                        }, $QTBLej ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $gPiRJi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UserName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "UserName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UserName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "UserName";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).UserName);
                        }, $WRFhVh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.UserName = value.AsReference($.$$.S.String);
                        }, $lhCxVi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FirstName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "FirstName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FirstName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "FirstName";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).FirstName);
                        }, $ymZCOk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.FirstName = value.AsReference($.$$.S.String);
                        }, $FcuUub ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LastName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "LastName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LastName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "LastName";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).LastName);
                        }, $GoEWyh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LastName = value.AsReference($.$$.S.String);
                        }, $fqSlaf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Email"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "Email", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Email")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Email";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).Email);
                        }, $eKjeHk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Email = value.AsReference($.$$.S.String);
                        }, $YwJVgg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PhoneNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "PhoneNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PhoneNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "PhoneNumber";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).PhoneNumber);
                        }, $gofPMh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PhoneNumber = value.AsReference($.$$.S.String);
                        }, $aytWLe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PhoneNumberVerified"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "PhoneNumberVerified", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PhoneNumberVerified")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "PhoneNumberVerified";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).PhoneNumberVerified);
                        }, $LGpdlj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PhoneNumberVerified = value.AsBool();
                        }, $ufMMsk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Image"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "Image", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Image")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Image";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).Image);
                        }, $GPBhXj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Image = value.AsReference($.$$.S.String);
                        }, $DVMzEi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Token"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "Token", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Token")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$GfYa.LCFCA.AuthToken, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Token";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$GfYa.LCFCA.AuthToken, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).Token);
                        }, $IDhfug ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Token = value.AsValue($.$GfYa.LCFCA.AuthToken);
                        }, $XnEUpg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Cookies"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "Cookies", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Cookies")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Cookies";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).Cookies);
                        }, $fjxRCd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Cookies = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $qdftfe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Created"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "Created", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Created")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "Created";
                        $i21.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).Created);
                        }, $jGjBWi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Created = value.AsNullableValue($.$$.S.DateTime);
                        }, $CtNzca ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Expires"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "Expires", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Expires")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.DateTime), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "Expires";
                        $i23.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.DateTime, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).Expires);
                        }, $VVCSXi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Expires = value.AsNullableValue($.$$.S.DateTime);
                        }, $HQQBOc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Roles"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "Roles", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Roles")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "Roles";
                        $i25.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).Roles);
                        }, $kOWHkc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i25.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Roles = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $ljORlc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Claims"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "Claims", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Claims")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "Claims";
                        $i27.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim), ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).Claims);
                        }, $VOjmof ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i27.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Claims = value.AsReference($.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim));
                        }, $XhLCMi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsFresh"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "IsFresh", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsFresh")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "IsFresh";
                        $i29.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).IsFresh);
                        }, $PihQYc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        $i29.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.IsFresh = value.AsBool();
                        }, $buBPbj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ImageResource"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.DecodedAuthenticationTicket.$type, $.$discardRef(), "ImageResource", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ImageResource")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$Iaui.LCFCM.ResourceModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t31 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i31 = new $t31();
                        $i31.$ctor$2();
                        $i31.Name = "ImageResource";
                        $i31.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket";
                        $i31.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$Iaui.LCFCM.ResourceModel, ($.$cast(target, $.$GfYa.LCFCA.DecodedAuthenticationTicket)).ImageResource);
                        }, $PjMKsf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1196418,"h":0,"f":17825826});
                        return $i31;
                    })()), schemas, null, factory);
                    let $en32 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en32.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en32.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886098306)
            
            //--TRIMMABLE-BOUNDARY-START(17181065602)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181065602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _UserName = _target.UserName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UserName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _UserName, ($v) => _UserName = $v, $.$$.S.String)))
                    {
                        _target.UserName = _UserName;
                    }
                }
                {
                    /*var*/ let _FirstName = _target.FirstName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FirstName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _FirstName, ($v) => _FirstName = $v, $.$$.S.String)))
                    {
                        _target.FirstName = _FirstName;
                    }
                }
                {
                    /*var*/ let _LastName = _target.LastName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LastName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _LastName, ($v) => _LastName = $v, $.$$.S.String)))
                    {
                        _target.LastName = _LastName;
                    }
                }
                {
                    /*var*/ let _Email = _target.Email;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Email"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Email, ($v) => _Email = $v, $.$$.S.String)))
                    {
                        _target.Email = _Email;
                    }
                }
                {
                    /*var*/ let _PhoneNumber = _target.PhoneNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PhoneNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PhoneNumber, ($v) => _PhoneNumber = $v, $.$$.S.String)))
                    {
                        _target.PhoneNumber = _PhoneNumber;
                    }
                }
                {
                    /*var*/ let _PhoneNumberVerified = _target.PhoneNumberVerified;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PhoneNumberVerified"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _PhoneNumberVerified, ($v) => _PhoneNumberVerified = $v, null, true)))
                    {
                        _target.PhoneNumberVerified = _PhoneNumberVerified;
                    }
                }
                {
                    /*var*/ let _Image = _target.Image;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Image"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Image, ($v) => _Image = $v, $.$$.S.String)))
                    {
                        _target.Image = _Image;
                    }
                }
                {
                    /*var*/ let _Token = _target.Token;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Token"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$GfYa.LCFCA.AuthToken));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$GfYa.LCFCA.AuthToken, () => _Token, ($v) => _Token = $v, null, true)))
                    {
                        _target.Token = $.$clone(_Token);
                    }
                }
                {
                    /*var*/ let _Cookies = _target.Cookies;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Cookies"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Cookies, ($v) => _Cookies = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.Cookies = _Cookies;
                        if (_Cookies !== null)
                        {
                            let $en44 = _Cookies.SCG$IEnumerable$$$GetEnumerator();
                            while ($en44.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en44.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Cookies, ($v) => _Cookies = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Created = _target.Created;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Created"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _Created, ($v) => _Created = $v, null, true)))
                    {
                        _target.Created = $.$clone(_Created);
                    }
                }
                {
                    /*var*/ let _Expires = _target.Expires;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Expires"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.DateTime)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.DateTime), () => _Expires, ($v) => _Expires = $v, null, true)))
                    {
                        _target.Expires = $.$clone(_Expires);
                    }
                }
                {
                    /*var*/ let _Roles = _target.Roles;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Roles"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Roles, ($v) => _Roles = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.Roles = _Roles;
                        if (_Roles !== null)
                        {
                            let $en53 = _Roles.SCG$IEnumerable$$$GetEnumerator();
                            while ($en53.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en53.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Roles, ($v) => _Roles = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Claims = _target.Claims;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Claims"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim), $.$ssc.SSC.Claim));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim), $.$ssc.SSC.Claim, property, $.$ref(() => _Claims, ($v) => _Claims = $v, $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim))))
                    {
                        _target.Claims = _Claims;
                        if (_Claims !== null)
                        {
                            let $en58 = _Claims.SCG$IEnumerable$$$GetEnumerator();
                            while ($en58.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en58.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$ssc.SSC.Claim)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim), $.$ssc.SSC.Claim, property, $.$ref(() => _Claims, ($v) => _Claims = $v, $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim)));
                    }
                }
                {
                    /*var*/ let _IsFresh = _target.IsFresh;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsFresh"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsFresh, ($v) => _IsFresh = $v, null, true)))
                    {
                        _target.IsFresh = _IsFresh;
                    }
                }
                {
                    /*var*/ let _ImageResource = _target.ImageResource;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ImageResource"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$Iaui.LCFCM.ResourceModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ImageResource, ($v) => _ImageResource = $v, $.$Iaui.LCFCM.ResourceModel)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181065602)
            
            //--TRIMMABLE-BOUNDARY-START(8591131010)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicket?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591131010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$GfYa.LCFCA.DecodedAuthenticationTicket().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$GfYa.LCFCA.DecodedAuthenticationTicket, null, $.$ref(() => _target, ($v) => _target = $v, $.$GfYa.LCFCA.DecodedAuthenticationTicket)))
                {
                    /*var*/ let result = $.$GfYa.LCFCA.DecodedAuthenticationTicketTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$GfYa.LCFCA.DecodedAuthenticationTicket));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$GfYa.LCFCA.DecodedAuthenticationTicket, null, $.$ref(() => _target, ($v) => _target = $v, $.$GfYa.LCFCA.DecodedAuthenticationTicket));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591131010)
            
            static $h = 1196418;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$GfYa.LCFCA.DecodedAuthenticationTicket); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886098306),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1196418,
      "h": 12886098306,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886098306),
//--TRIMMABLE-BOUNDARY-START(17181065602),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1130882,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1196418,
      "h": 17181065602,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181065602),
//--TRIMMABLE-BOUNDARY-START(8591131010),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1130882,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1196418,
      "h": 8591131010,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591131010)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296163714),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1196418,
      "h": 4296163714,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296163714)
  ],
  "h": 1196418
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$GfYa.LCFCA.DecodedAuthenticationTicket), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.DecodedAuthenticationTicketTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}DecodedAuthenticationTicketTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1196418)
        
        

        //--TRIMMABLE-BOUNDARY-START(934274)
        $asm.$cls(`$GfYa.LCFCA.AuthTokenTypeDescriptor`, ($self) => class AuthTokenTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$GfYa.LCFCA.AuthToken)
        {
            //--TRIMMABLE-BOUNDARY-START(4295901570)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295901570);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$GfYa.LCFCA.AuthTokenTypeDescriptor.GenerateProperties($.$GfYa.LCFCA.AuthToken, this, factory);
                    }, $vEyfhi ??= {"r":65537,"n":"","d":934274,"h":0,"f":17825794}), 0, "AuthTokenTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Authentication\\AuthToken_LivingThing.Core.Frameworks.Common.Authentication.AuthTokenTypeDescriptorBuilder.g.cs", "AuthTokenTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295901570)
            
            //--TRIMMABLE-BOUNDARY-START(12885836162)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885836162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Provider"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthToken.$type, $.$discardRef(), "Provider", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Provider")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Provider";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthToken";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthTokenTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthToken)).Provider);
                        }, $ODxrgc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":934274,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthTokenTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$GfYa.LCFCA.AuthToken, target).$v.Provider = value.AsReference($.$$.S.String);
                        }, $hFgvWa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":934274,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ProviderKey"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthToken.$type, $.$discardRef(), "ProviderKey", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ProviderKey")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ProviderKey";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthToken";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthTokenTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthToken)).ProviderKey);
                        }, $RMyqqh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":934274,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthTokenTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$GfYa.LCFCA.AuthToken, target).$v.ProviderKey = value.AsReference($.$$.S.String);
                        }, $Iacyxa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":934274,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AccessToken"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthToken.$type, $.$discardRef(), "AccessToken", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AccessToken")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "AccessToken";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthToken";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthTokenTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthToken)).AccessToken);
                        }, $unsXdf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":934274,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthTokenTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$GfYa.LCFCA.AuthToken, target).$v.AccessToken = value.AsReference($.$$.S.String);
                        }, $LNYepc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":934274,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RefreshToken"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthToken.$type, $.$discardRef(), "RefreshToken", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RefreshToken")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "RefreshToken";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthToken";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthTokenTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthToken)).RefreshToken);
                        }, $SgPBLb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":934274,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthTokenTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$GfYa.LCFCA.AuthToken, target).$v.RefreshToken = value.AsReference($.$$.S.String);
                        }, $MHJYgd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":934274,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("JWToken"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$GfYa.LCFCA.AuthToken.$type, $.$discardRef(), "JWToken", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("JWToken")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "JWToken";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Authentication.AuthToken";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthTokenTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$GfYa.LCFCA.AuthToken)).JWToken);
                        }, $cElXGb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":934274,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$GfYa.LCFCA.AuthTokenTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$GfYa.LCFCA.AuthToken, target).$v.JWToken = value.AsReference($.$$.S.String);
                        }, $egGHtf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":934274,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885836162)
            
            //--TRIMMABLE-BOUNDARY-START(17180803458)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Authentication.AuthToken*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180803458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Provider = _target.Provider;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Provider"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Provider, ($v) => _Provider = $v, $.$$.S.String)))
                    {
                        _target.Provider = _Provider;
                    }
                }
                {
                    /*var*/ let _ProviderKey = _target.ProviderKey;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ProviderKey"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ProviderKey, ($v) => _ProviderKey = $v, $.$$.S.String)))
                    {
                        _target.ProviderKey = _ProviderKey;
                    }
                }
                {
                    /*var*/ let _AccessToken = _target.AccessToken;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AccessToken"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _AccessToken, ($v) => _AccessToken = $v, $.$$.S.String)))
                    {
                        _target.AccessToken = _AccessToken;
                    }
                }
                {
                    /*var*/ let _RefreshToken = _target.RefreshToken;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RefreshToken"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _RefreshToken, ($v) => _RefreshToken = $v, $.$$.S.String)))
                    {
                        _target.RefreshToken = _RefreshToken;
                    }
                }
                {
                    /*var*/ let _JWToken = _target.JWToken;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("JWToken"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _JWToken, ($v) => _JWToken = $v, $.$$.S.String)))
                    {
                        _target.JWToken = _JWToken;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180803458)
            
            //--TRIMMABLE-BOUNDARY-START(8590868866)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Authentication.AuthToken*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590868866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$GfYa.LCFCA.AuthToken, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$GfYa.LCFCA.AuthToken, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$GfYa.LCFCA.AuthTokenTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$GfYa.LCFCA.AuthToken, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$GfYa.LCFCA.AuthToken, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$GfYa.LCFCA.AuthToken, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590868866)
            
            static $h = 934274;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$GfYa.LCFCA.AuthToken); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885836162),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 934274,
      "h": 12885836162,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885836162),
//--TRIMMABLE-BOUNDARY-START(17180803458),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 868738,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 934274,
      "h": 17180803458,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180803458),
//--TRIMMABLE-BOUNDARY-START(8590868866),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 868738,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 934274,
      "h": 8590868866,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590868866)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295901570),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 934274,
      "h": 4295901570,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295901570)
  ],
  "h": 934274
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$GfYa.LCFCA.AuthToken), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Authentication.AuthTokenTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Authentication${separator}AuthTokenTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(934274)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models"));
})();
//--TRIMMABLE-BOUNDARY-END(16770)
