
//--TRIMMABLE-BOUNDARY-START(55226)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer) {
    "use strict";
    let _;
    let $TAcWXg;
    let $MjTAyk;
    let $wwjhMi;
    let $LJGrek;
    let $YNEtmj;
    let $rbkHOj;
    let $ykgRJh;
    let $YzLPNg;
    let $cJrHzj;
    let $UWEYqd;
    let $dFwbok;
    let $uOQjra;
    let $zRkmpc;
    let $RHcjvi;
    let $cLFlCg;
    let $OmpnPe;
    let $dOpCPg;
    let $fMMHOa;
    let $HQjGua;
    let $nxhTcd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Automation", 
    {
  "h": 55226,
  "f": "LivingThing.Core.Frameworks.Common.Automation",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Automation",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Automation",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(251834)
        $asm.$cls(`$eFOo.LCFCAAU.IUserAutomationSettingss`, ($self) => class IUserAutomationSettingss
        {
            static $h = 251834;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295219130),
    {
      "p": 448442,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885153722,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21475088314,
        "f": 83886337
      },
      "n": "AutomationActionSettings",
      "o": "LCFCAAU$IUserAutomationSettingss$AutomationActionSettings",
      "d": 251834,
      "h": 4295219130,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295219130)
  ],
  "h": 251834
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.IUserAutomationSettingss`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Actions${separator}UserDefined${separator}IUserAutomationSettingss`; }
        });
        //--TRIMMABLE-BOUNDARY-END(251834)
        
        

        //--TRIMMABLE-BOUNDARY-START(1169338)
        $asm.$cls(`$eFOo.LCFCA.IAutomationController`, ($self) => class IAutomationController
        {
            static $h = 1169338;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296136634),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 776122
        },
        {
          "n": "triggers",
          "p": $.$typeArray($.$eFOo.LCFCA.AutomationTriggerContext).$h,
          "f": 16
        }
      ],
      "n": "Run",
      "o": "LCFCA$IAutomationController$Run",
      "d": 1169338,
      "h": 4296136634,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296136634),
//--TRIMMABLE-BOUNDARY-START(8591103930),
    {
      "r": 178454529,
      "n": "RunNow",
      "o": "LCFCA$IAutomationController$RunNow",
      "d": 1169338,
      "h": 8591103930,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591103930)
  ],
  "h": 1169338
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.IAutomationController`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}IAutomationController`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1169338)
        
        

        //--TRIMMABLE-BOUNDARY-START(1234874)
        $asm.$cls(`$eFOo.LCFCA.IAutomationTrigger`, ($self) => class IAutomationTrigger
        {
            static $h = 1234874;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066005946),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476071354,
        "f": 50331905
      },
      "n": "Name",
      "o": "LCFCA$IAutomationTrigger$Name",
      "d": 1234874,
      "h": 30066005946,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30066005946),
//--TRIMMABLE-BOUNDARY-START(4296202170),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886136762,
        "f": 50331905
      },
      "n": "Description",
      "o": "LCFCA$IAutomationTrigger$Description",
      "d": 1234874,
      "h": 4296202170,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296202170)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771038650),
    {
      "r": $.$$.STT.Task$$($.$eFOo.LCFCA.AutomationActionContext).$h,
      "p": [
        {
          "n": "request",
          "p": 907194
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "o": "LCFCA$IAutomationTrigger$Handle",
      "d": 1234874,
      "h": 25771038650,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25771038650)
  ],
  "h": 1234874
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}IAutomationTrigger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1234874)
        
        

        //--TRIMMABLE-BOUNDARY-START(1103802)
        $asm.$cls(`$eFOo.LCFCA.IAutomationAction`, ($self) => class IAutomationAction
        {
            static $h = 1103802;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065874874),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475940282,
        "f": 50331905
      },
      "n": "Name",
      "o": "LCFCA$IAutomationAction$Name",
      "d": 1103802,
      "h": 30065874874,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065874874),
//--TRIMMABLE-BOUNDARY-START(4296071098),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886005690,
        "f": 50331905
      },
      "n": "Description",
      "o": "LCFCA$IAutomationAction$Description",
      "d": 1103802,
      "h": 4296071098,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296071098)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770907578),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": 710586
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "o": "LCFCA$IAutomationAction$Handle",
      "d": 1103802,
      "h": 25770907578,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770907578)
  ],
  "h": 1103802
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.IAutomationAction`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}IAutomationAction`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1103802)
        
        

        //--TRIMMABLE-BOUNDARY-START(776122)
        $asm.$cls(`$eFOo.LCFCA.AutomationContext`, ($self) => class AutomationContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295743418)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295743418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295743418)
            
            //--TRIMMABLE-BOUNDARY-START(4295743418)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295743418)
            
            static $h = 776122;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885678010),
    {
      "p": 841658,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065547194,
        "f": 50331905
      },
      "n": "Automator",
      "d": 776122,
      "h": 12885678010,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885678010),
//--TRIMMABLE-BOUNDARY-START(55835350970),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655481786,
        "f": 50331905
      },
      "n": "Triggers",
      "d": 776122,
      "h": 55835350970,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(55835350970),
//--TRIMMABLE-BOUNDARY-START(8590710714),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475612602,
        "f": 50331905
      },
      "n": "Actions",
      "d": 776122,
      "h": 8590710714,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590710714)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540383674),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "trigger",
          "p": 1234874
        },
        {
          "n": "triggerContext",
          "p": 907194
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetParameter",
      "o": "@$1",
      "d": 776122,
      "h": 51540383674,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(51540383674),
//--TRIMMABLE-BOUNDARY-START(47245416378),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "action",
          "p": 1103802
        },
        {
          "n": "actionContext",
          "p": 710586
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetParameter",
      "d": 776122,
      "h": 47245416378,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(47245416378),
//--TRIMMABLE-BOUNDARY-START(42950449082),
    {
      "r": 710586,
      "p": [
        {
          "n": "trigger",
          "p": 1234874
        },
        {
          "n": "triggerContext",
          "p": 907194
        },
        {
          "n": "fired",
          "p": 262145
        }
      ],
      "n": "GetAction",
      "d": 776122,
      "h": 42950449082,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950449082)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295743418),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 776122,
      "h": 4295743418,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295743418)
  ],
  "h": 776122
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.AutomationContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}AutomationContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(776122)
        
        

        //--TRIMMABLE-BOUNDARY-START(1431482)
        $asm.$cls(`$eFOo.LCFCATC.CombineAsCustomAttributesProvider`, ($self) => class CombineAsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296398778)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296398778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296398778)
            
            static $h = 1431482;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296398778),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1431482,
      "h": 4296398778,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296398778)
  ],
  "h": 1431482
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineAsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}Combine${separator}CombineAsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1431482)
        
        

        //--TRIMMABLE-BOUNDARY-START(1628090)
        $asm.$cls(`$eFOo.LCFCATC.CombineTriggersSettingsCustomAttributesProvider`, ($self) => class CombineTriggersSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296595386)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296595386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296595386)
            
            static $h = 1628090;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296595386),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1628090,
      "h": 4296595386,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296595386)
  ],
  "h": 1628090
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTriggersSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}Combine${separator}CombineTriggersSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1628090)
        
        

        //--TRIMMABLE-BOUNDARY-START(1038266)
        $asm.$cls(`$eFOo.LCFCA.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296005562)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296005562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4296005562)
            
            static $h = 1038266;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296005562),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 1038266,
      "h": 4296005562,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296005562)
  ],
  "h": 1038266
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1038266)
        
        

        //--TRIMMABLE-BOUNDARY-START(513978)
        $asm.$cls(`$eFOo.LCFCAAU.UserDefinedActionSettingsCustomAttributesProvider`, ($self) => class UserDefinedActionSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295481274)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295481274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295481274)
            
            static $h = 513978;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295481274),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 513978,
      "h": 4295481274,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295481274)
  ],
  "h": 513978
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Actions${separator}UserDefined${separator}UserDefinedActionSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(513978)
        
        

        //--TRIMMABLE-BOUNDARY-START(1955770)
        $asm.$cls(`$eFOo.LCFCATT.TimeOfDaySettingsCustomAttributesProvider`, ($self) => class TimeOfDaySettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296923066)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296923066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296923066)
            
            static $h = 1955770;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296923066),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1955770,
      "h": 4296923066,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296923066)
  ],
  "h": 1955770
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.TimeOfDaySettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}TimeOfDay${separator}TimeOfDaySettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1955770)
        
        

        //--TRIMMABLE-BOUNDARY-START(1890234)
        $asm.$cls(`$eFOo.LCFCATT.TimeOfDaySettings`, ($self) => class TimeOfDaySettings extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886792122)
            /*MaskableDateTime<MaskProvider>*/ Calendar = null;
            //--TRIMMABLE-BOUNDARY-END(12886792122)
            
            //--TRIMMABLE-BOUNDARY-START(8591824826)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591824826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591824826)
            
            //--TRIMMABLE-BOUNDARY-START(8591824826)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591824826)
            
            static $h = 1890234;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886792122),
    {
      "p": $.$fPer.LCFCDC.MaskableDateTime$$($.$eFOo.LCFCATT.MaskProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476726714,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066661306,
        "f": 83886081
      },
      "n": "Calendar",
      "d": 1890234,
      "h": 12886792122,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886792122)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591824826),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1890234,
      "h": 8591824826,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591824826)
  ],
  "h": 1890234
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.TimeOfDaySettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}TimeOfDay${separator}TimeOfDaySettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1890234)
        
        

        //--TRIMMABLE-BOUNDARY-START(710586)
        $asm.$cls(`$eFOo.LCFCA.AutomationActionContext`, ($self) => class AutomationActionContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180579770)
            $ctor$1(/*AutomationContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180579770);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Context = context;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180579770)
            
            //--TRIMMABLE-BOUNDARY-START(21475547066)
            /*string*/ ActionId = null;
            //--TRIMMABLE-BOUNDARY-END(21475547066)
            
            //--TRIMMABLE-BOUNDARY-START(25770514362)
            /*AutomationContext*/ Context = null;
            //--TRIMMABLE-BOUNDARY-END(25770514362)
            
            //--TRIMMABLE-BOUNDARY-START(30065481658)
            /*bool*/ Fired = false;
            //--TRIMMABLE-BOUNDARY-END(30065481658)
            
            static $h = 710586;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475547066),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655416250,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425220026,
        "f": 83886081
      },
      "n": "ActionId",
      "d": 710586,
      "h": 21475547066,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475547066),
//--TRIMMABLE-BOUNDARY-START(25770514362),
    {
      "p": 776122,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245350842,
        "f": 50331649
      },
      "n": "Context",
      "d": 710586,
      "h": 25770514362,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770514362),
//--TRIMMABLE-BOUNDARY-START(30065481658),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835285434,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015154618,
        "f": 83886081
      },
      "n": "Fired",
      "d": 710586,
      "h": 30065481658,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065481658)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180579770),
    {
      "p": [
        {
          "n": "context",
          "p": 776122
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 710586,
      "h": 17180579770,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180579770)
  ],
  "h": 710586
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.AutomationActionContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}AutomationActionContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(710586)
        
        

        //--TRIMMABLE-BOUNDARY-START(2217914)
        $asm.$cls(`$eFOo.LCFCA.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297185210)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297185210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$eFOo.LCFCAAU.UserDefinedActionSettingsTypeDescriptorBuilder.Register();
                $.$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptorBuilder.Register();
                $.$eFOo.LCFCATT.TimeOfDaySettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297185210)
            
            static $h = 2217914;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297185210),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2217914,
      "h": 4297185210,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297185210)
  ],
  "h": 2217914
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2217914)
        
        

        //--TRIMMABLE-BOUNDARY-START(382906)
        $asm.$cls(`$eFOo.LCFCAAU.UserDefinedActionSetting`, ($self) => class UserDefinedActionSetting extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55834957754)
            /*string*/ TypeName = null;
            //--TRIMMABLE-BOUNDARY-END(55834957754)
            
            //--TRIMMABLE-BOUNDARY-START(34360121274)
            /*string*/ SerializedParameters = null;
            //--TRIMMABLE-BOUNDARY-END(34360121274)
            
            //--TRIMMABLE-BOUNDARY-START(12885284794)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885284794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885284794)
            
            //--TRIMMABLE-BOUNDARY-START(12885284794)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885284794)
            
            static $h = 382906;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834957754),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065153978,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51539990458,
        "f": 83886081
      },
      "n": "TypeName",
      "d": 382906,
      "h": 55834957754,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834957754),
//--TRIMMABLE-BOUNDARY-START(34360121274),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475219386,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950055866,
        "f": 83886081
      },
      "n": "SerializedParameters",
      "d": 382906,
      "h": 34360121274,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360121274)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885284794),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 382906,
      "h": 12885284794,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885284794)
  ],
  "h": 382906
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionSetting`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Actions${separator}UserDefined${separator}UserDefinedActionSetting`; }
        });
        //--TRIMMABLE-BOUNDARY-END(382906)
        
        

        //--TRIMMABLE-BOUNDARY-START(907194)
        $asm.$cls(`$eFOo.LCFCA.AutomationTriggerContext`, ($self) => class AutomationTriggerContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885809082)
            $ctor$1(/*AutomationContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885809082);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Context = context;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885809082)
            
            //--TRIMMABLE-BOUNDARY-START(47245547450)
            /*string*/ TriggerId = null;
            //--TRIMMABLE-BOUNDARY-END(47245547450)
            
            //--TRIMMABLE-BOUNDARY-START(17180776378)
            /*AutomationContext*/ Context = null;
            //--TRIMMABLE-BOUNDARY-END(17180776378)
            
            static $h = 907194;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245547450),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360645562,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950580154,
        "f": 83886081
      },
      "n": "TriggerId",
      "d": 907194,
      "h": 47245547450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245547450),
//--TRIMMABLE-BOUNDARY-START(17180776378),
    {
      "p": 776122,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770710970,
        "f": 50331649
      },
      "n": "Context",
      "d": 907194,
      "h": 17180776378,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180776378)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885809082),
    {
      "p": [
        {
          "n": "context",
          "p": 776122
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 907194,
      "h": 12885809082,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885809082)
  ],
  "h": 907194
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.AutomationTriggerContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}AutomationTriggerContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(907194)
        
        

        //--TRIMMABLE-BOUNDARY-START(448442)
        $asm.$cls(`$eFOo.LCFCAAU.UserDefinedActionSettings`, ($self) => class UserDefinedActionSettings extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885350330)
            /*UserDefinedActionSetting[]*/ ActionSettings = null;
            //--TRIMMABLE-BOUNDARY-END(12885350330)
            
            //--TRIMMABLE-BOUNDARY-START(8590383034)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590383034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590383034)
            
            //--TRIMMABLE-BOUNDARY-START(8590383034)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590383034)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885350330)
                this.ActionSettings = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$eFOo.LCFCAAU.UserDefinedActionSetting), null, [0], null);
                //--TRIMMABLE-BOUNDARY-END(12885350330)
                
            }
            static $h = 448442;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885350330),
    {
      "p": $.$typeArray($.$eFOo.LCFCAAU.UserDefinedActionSetting).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475284922,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065219514,
        "f": 83886081
      },
      "n": "ActionSettings",
      "d": 448442,
      "h": 12885350330,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885350330)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590383034),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 448442,
      "h": 8590383034,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590383034)
  ],
  "h": 448442
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Actions${separator}UserDefined${separator}UserDefinedActionSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(448442)
        
        

        //--TRIMMABLE-BOUNDARY-START(972730)
        $asm.$cls(`$eFOo.LCFCA.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295940026)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295940026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$eFOo.LCFCAAU.UserDefinedActionSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$eFOo.LCFCAAU.UserDefinedActionSettingsCustomAttributesProvider, $.$eFOo.LCFCAAU.UserDefinedActionSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$eFOo.LCFCATC.CombineAs.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$eFOo.LCFCATC.CombineAsCustomAttributesProvider, $.$eFOo.LCFCATC.CombineAsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$eFOo.LCFCATC.CombineTriggersSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$eFOo.LCFCATC.CombineTriggersSettingsCustomAttributesProvider, $.$eFOo.LCFCATC.CombineTriggersSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$eFOo.LCFCATT.TimeOfDaySettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$eFOo.LCFCATT.TimeOfDaySettingsCustomAttributesProvider, $.$eFOo.LCFCATT.TimeOfDaySettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295940026)
            
            static $h = 972730;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295940026),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 972730,
      "h": 4295940026,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295940026)
  ],
  "h": 972730
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(972730)
        
        

        //--TRIMMABLE-BOUNDARY-START(1562554)
        $asm.$cls(`$eFOo.LCFCATC.CombineTriggersSettings`, ($self) => class CombineTriggersSettings extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38656268218)
            /*string[]*/ Members = null;
            //--TRIMMABLE-BOUNDARY-END(38656268218)
            
            //--TRIMMABLE-BOUNDARY-START(17181431738)
            /*CombineAs*/ As = 0;
            //--TRIMMABLE-BOUNDARY-END(17181431738)
            
            //--TRIMMABLE-BOUNDARY-START(12886464442)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886464442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886464442)
            
            //--TRIMMABLE-BOUNDARY-START(12886464442)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886464442)
            
            static $h = 1562554;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656268218),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361300922,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836137402,
        "f": 83886081
      },
      "n": "Members",
      "d": 1562554,
      "h": 38656268218,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656268218),
//--TRIMMABLE-BOUNDARY-START(17181431738),
    {
      "p": 1365946,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771366330,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246202810,
        "f": 83886081
      },
      "n": "As",
      "d": 1562554,
      "h": 17181431738,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181431738)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886464442),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1562554,
      "h": 12886464442,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886464442)
  ],
  "h": 1562554
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTriggersSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}Combine${separator}CombineTriggersSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1562554)
        
        

        //--TRIMMABLE-BOUNDARY-START(2086842)
        $asm.$cls(`$eFOo.LCFCATT.TimeOfDaySettingsTypeDescriptorBuilder`, ($self) => class TimeOfDaySettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592021434)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592021434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$eFOo.LCFCATT.TimeOfDaySettingsTypeDescriptor()
                        const $t1 = $.$eFOo.LCFCATT.TimeOfDaySettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.TimeOfDaySettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ykgRJh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2086842,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$eFOo.LCFCATT.TimeOfDaySettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592021434)
            
            //--TRIMMABLE-BOUNDARY-START(4297054138)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297054138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297054138)
            
            //--TRIMMABLE-BOUNDARY-START(4297054138)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297054138)
            
            static $h = 2086842;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592021434),
    {
      "r": 65537,
      "n": "Register",
      "d": 2086842,
      "h": 8592021434,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592021434)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297054138),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2086842,
      "h": 4297054138,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297054138)
  ],
  "h": 2086842
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.TimeOfDaySettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}TimeOfDay${separator}TimeOfDaySettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2086842)
        
        

        //--TRIMMABLE-BOUNDARY-START(1759162)
        $asm.$cls(`$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptorBuilder`, ($self) => class CombineTriggersSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591693754)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591693754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptor()
                        const $t1 = $.$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTriggersSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $cLFlCg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1759162,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$eFOo.LCFCATC.CombineTriggersSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591693754)
            
            //--TRIMMABLE-BOUNDARY-START(4296726458)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296726458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296726458)
            
            //--TRIMMABLE-BOUNDARY-START(4296726458)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296726458)
            
            static $h = 1759162;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591693754),
    {
      "r": 65537,
      "n": "Register",
      "d": 1759162,
      "h": 8591693754,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591693754)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296726458),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1759162,
      "h": 4296726458,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296726458)
  ],
  "h": 1759162
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTriggersSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}Combine${separator}CombineTriggersSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1759162)
        
        

        //--TRIMMABLE-BOUNDARY-START(645050)
        $asm.$cls(`$eFOo.LCFCAAU.UserDefinedActionSettingsTypeDescriptorBuilder`, ($self) => class UserDefinedActionSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590579642)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590579642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$eFOo.LCFCAAU.UserDefinedActionSettingsTypeDescriptor()
                        const $t1 = $.$eFOo.LCFCAAU.UserDefinedActionSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dFwbok ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":645050,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$eFOo.LCFCAAU.UserDefinedActionSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590579642)
            
            //--TRIMMABLE-BOUNDARY-START(4295612346)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295612346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295612346)
            
            //--TRIMMABLE-BOUNDARY-START(4295612346)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295612346)
            
            static $h = 645050;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590579642),
    {
      "r": 65537,
      "n": "Register",
      "d": 645050,
      "h": 8590579642,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590579642)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295612346),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 645050,
      "h": 4295612346,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295612346)
  ],
  "h": 645050
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Actions${separator}UserDefined${separator}UserDefinedActionSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(645050)
        
        

        //--TRIMMABLE-BOUNDARY-START(1824698)
        $asm.$cls(`$eFOo.LCFCATT.MaskProvider`, ($self) => class MaskProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181693882)
            /*DateTimeMask */ get VisibleFields()
            {
                return 4/*DateTimeMask.Hour*/ | 2/*DateTimeMask.Minute*/ | 8/*DateTimeMask.Weekday*/ | 16/*DateTimeMask.Date*/ | 32/*DateTimeMask.Month*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17181693882)
            
            //--TRIMMABLE-BOUNDARY-START(8596457814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.Calendar.IDateTimeMaskProvider.VisibleFields.get
            get LCFCDC$IDateTimeMaskProvider$VisibleFields()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891425110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.VisibleFields;
            }
            //--TRIMMABLE-BOUNDARY-END(8596457814)
            
            //--TRIMMABLE-BOUNDARY-START(4296791994)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296791994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296791994)
            
            //--TRIMMABLE-BOUNDARY-START(4296791994)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296791994)
            
            static $h = 1824698;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181693882),
    {
      "p": 6392150,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886726586,
        "f": 50331649
      },
      "n": "VisibleFields",
      "d": 1824698,
      "h": 17181693882,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181693882)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296791994),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1824698,
      "h": 4296791994,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296791994)
  ],
  "h": 1824698
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCDC.IDateTimeMaskProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.MaskProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}TimeOfDay${separator}MaskProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1824698)
        
        

        //--TRIMMABLE-BOUNDARY-START(1300410)
        $asm.$cls(`$eFOo.LCFCAT.AlwaysTrueTrigger`, ($self) => class AlwaysTrueTrigger extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361038778)
            /*string */ get Name()
            {
                return "Always";
            }
            //--TRIMMABLE-BOUNDARY-END(34361038778)
            
            //--TRIMMABLE-BOUNDARY-START(8591235002)
            /*string */ get Description()
            {
                return "Always execute irrespective of any other condition";
            }
            //--TRIMMABLE-BOUNDARY-END(8591235002)
            
            //--TRIMMABLE-BOUNDARY-START(30066071482)
            /*Task<AutomationActionContext> */ Handle(/*AutomationTriggerContext*/ request, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066071482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$eFOo.LCFCA.AutomationActionContext, request.Context.GetAction(this, request, true));
            }
            //--TRIMMABLE-BOUNDARY-END(30066071482)
            
            //--TRIMMABLE-BOUNDARY-START(21476071354)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Name.get
            get LCFCA$IAutomationTrigger$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066005946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(21476071354)
            
            //--TRIMMABLE-BOUNDARY-START(12886136762)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Description.get
            get LCFCA$IAutomationTrigger$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296202170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12886136762)
            
            //--TRIMMABLE-BOUNDARY-START(25771038650)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Handle(LivingThing.Core.Frameworks.Common.Automation.AutomationTriggerContext, System.Threading.CancellationToken)
            LCFCA$IAutomationTrigger$Handle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771038650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25771038650)
            
            //--TRIMMABLE-BOUNDARY-START(4296267706)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296267706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296267706)
            
            //--TRIMMABLE-BOUNDARY-START(4296267706)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296267706)
            
            static $h = 1300410;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361038778),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771104186,
        "f": 50331649
      },
      "n": "Name",
      "d": 1300410,
      "h": 34361038778,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361038778),
//--TRIMMABLE-BOUNDARY-START(8591235002),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181169594,
        "f": 50331649
      },
      "n": "Description",
      "d": 1300410,
      "h": 8591235002,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591235002)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066071482),
    {
      "r": $.$$.STT.Task$$($.$eFOo.LCFCA.AutomationActionContext).$h,
      "p": [
        {
          "n": "request",
          "p": 907194
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "d": 1300410,
      "h": 30066071482,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066071482)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296267706),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1300410,
      "h": 4296267706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296267706)
  ],
  "h": 1300410
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$eFOo.LCFCA.IAutomationTrigger ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.AlwaysTrueTrigger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}AlwaysTrueTrigger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1300410)
        
        

        //--TRIMMABLE-BOUNDARY-START(1497018)
        $asm.$cls(`$eFOo.LCFCATC.CombineTrigger`, ($self) => class CombineTrigger extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591431610)
            /*string */ get Description()
            {
                return "Combines one or more trigger rules together";
            }
            //--TRIMMABLE-BOUNDARY-END(8591431610)
            
            //--TRIMMABLE-BOUNDARY-START(34361235386)
            /*string */ get Name()
            {
                return "Combine Triggers";
            }
            //--TRIMMABLE-BOUNDARY-END(34361235386)
            
            //--TRIMMABLE-BOUNDARY-START(30066268090)
            /*Task<AutomationActionContext> *//*async*/  Handle(/*AutomationTriggerContext*/ request, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$eFOo.LCFCA.AutomationActionContext), $.$eFOo.LCFCA.AutomationActionContext, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066268090);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let settings = request.Context.GetParameter$1($.$eFOo.LCFCATC.CombineTriggersSettings, this, request);
                    /*List<Task<AutomationActionContext>>*/ let tasks = new ($.$$.SCG.List$$($.$$.STT.Task$$($.$eFOo.LCFCA.AutomationActionContext)))().$ctor$1();
                    let $en1 = $.$sl.SL.Enumerable.Except$1($.$eFOo.LCFCA.IAutomationTrigger, $.$sl.SL.Enumerable.Where($.$eFOo.LCFCA.IAutomationTrigger, $.$sl.SL.Enumerable.Select$1($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.String), $.$eFOo.LCFCA.IAutomationTrigger, request.Context.Triggers, new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.String), $.$eFOo.LCFCA.IAutomationTrigger))().$ctor(this,  (/**/ t) =>
                    {
                        return t.Item1;
                    }, $TAcWXg ??= {"r":1234874,"p":[{"n":"t","p":$.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.String).$h}],"n":"","d":1497018,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return $.$sl.SL.Enumerable.Any($.$$.S.String, settings.Members, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/**/ m) =>
                        {
                            return m === $.$$.S.Object.GetType.call(t).FullName;
                        }, $MjTAyk ??= {"r":262145,"p":[{"n":"m","p":1310721}],"n":"","d":1497018,"h":0,"f":17825794}));
                    }, $wwjhMi ??= {"r":262145,"p":[{"n":"t","p":1234874}],"n":"","d":1497018,"h":0,"f":17825794})), $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$eFOo.LCFCATC.CombineTrigger), [this], null, null), $.$$.SCG.IEnumerable$$($.$eFOo.LCFCATC.CombineTrigger), $.$$.SCG.IEnumerable$$($.$eFOo.LCFCA.IAutomationTrigger))).SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let trigger = $en1.SCG$IEnumerator$$$Current;
                        {
                            tasks.Add(trigger.LCFCA$IAutomationTrigger$Handle(request, cancellationToken));
                        }
                    }
                    /*bool*/ let fired = false;
                    if (tasks.Count > 0)
                    {
                        let $t2, $r2;
                        /*var*/ let results = ($t2 = $.$$.STT.Task.WhenAll$3($.$eFOo.LCFCA.AutomationActionContext, tasks), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        if (settings.As === 0/*CombineAs.Or*/)
                        {
                            fired = $.$sl.SL.Enumerable.Any($.$eFOo.LCFCA.AutomationActionContext, results, new ($.$$.S.Func$$$($.$eFOo.LCFCA.AutomationActionContext, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                            {
                                return r.Fired;
                            }, $LJGrek ??= {"r":262145,"p":[{"n":"r","p":710586}],"n":"","d":1497018,"h":0,"f":17825794}));
                        }
                        else 
                        {
                            fired = $.$sl.SL.Enumerable.All($.$eFOo.LCFCA.AutomationActionContext, results, new ($.$$.S.Func$$$($.$eFOo.LCFCA.AutomationActionContext, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                            {
                                return r.Fired;
                            }, $YNEtmj ??= {"r":262145,"p":[{"n":"r","p":710586}],"n":"","d":1497018,"h":0,"f":17825794}));
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, request.Context.GetAction(this, request, fired));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30066268090)
            
            //--TRIMMABLE-BOUNDARY-START(21476071354)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Name.get
            get LCFCA$IAutomationTrigger$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066005946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(21476071354)
            
            //--TRIMMABLE-BOUNDARY-START(12886136762)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Description.get
            get LCFCA$IAutomationTrigger$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296202170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12886136762)
            
            //--TRIMMABLE-BOUNDARY-START(25771038650)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Handle(LivingThing.Core.Frameworks.Common.Automation.AutomationTriggerContext, System.Threading.CancellationToken)
            LCFCA$IAutomationTrigger$Handle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771038650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25771038650)
            
            //--TRIMMABLE-BOUNDARY-START(4296464314)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296464314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296464314)
            
            //--TRIMMABLE-BOUNDARY-START(4296464314)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296464314)
            
            static $h = 1497018;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591431610),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181366202,
        "f": 50331649
      },
      "n": "Description",
      "d": 1497018,
      "h": 8591431610,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591431610),
//--TRIMMABLE-BOUNDARY-START(34361235386),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771300794,
        "f": 50331649
      },
      "n": "Name",
      "d": 1497018,
      "h": 34361235386,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361235386)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066268090),
    {
      "r": $.$$.STT.Task$$($.$eFOo.LCFCA.AutomationActionContext).$h,
      "p": [
        {
          "n": "request",
          "p": 907194
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "d": 1497018,
      "h": 30066268090,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(30066268090)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296464314),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1497018,
      "h": 4296464314,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296464314)
  ],
  "h": 1497018
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$eFOo.LCFCA.IAutomationTrigger ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTrigger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}Combine${separator}CombineTrigger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1497018)
        
        

        //--TRIMMABLE-BOUNDARY-START(120762)
        $asm.$cls(`$eFOo.LCFCAA.ConsoleAction`, ($self) => class ConsoleAction extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34359859130)
            /*string */ get Name()
            {
                return "Console";
            }
            //--TRIMMABLE-BOUNDARY-END(34359859130)
            
            //--TRIMMABLE-BOUNDARY-START(8590055354)
            /*string */ get Description()
            {
                return "Prints action to console";
            }
            //--TRIMMABLE-BOUNDARY-END(8590055354)
            
            //--TRIMMABLE-BOUNDARY-START(30064891834)
            /*Task */ Handle(/*AutomationActionContext*/ notification, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064891834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.S.Console.WriteLine$17(`Triggered by ${$.$strNN($.$dsp(notification.Context.Triggers, $.$$.S.Object, ($t) => $t.ToString))}`);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(30064891834)
            
            //--TRIMMABLE-BOUNDARY-START(21475940282)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationAction.Name.get
            get LCFCA$IAutomationAction$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065874874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(21475940282)
            
            //--TRIMMABLE-BOUNDARY-START(12886005690)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationAction.Description.get
            get LCFCA$IAutomationAction$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296071098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12886005690)
            
            //--TRIMMABLE-BOUNDARY-START(25770907578)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationAction.Handle(LivingThing.Core.Frameworks.Common.Automation.AutomationActionContext, System.Threading.CancellationToken)
            LCFCA$IAutomationAction$Handle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770907578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770907578)
            
            //--TRIMMABLE-BOUNDARY-START(4295088058)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295088058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295088058)
            
            //--TRIMMABLE-BOUNDARY-START(4295088058)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295088058)
            
            static $h = 120762;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359859130),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769924538,
        "f": 50331649
      },
      "n": "Name",
      "d": 120762,
      "h": 34359859130,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359859130),
//--TRIMMABLE-BOUNDARY-START(8590055354),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17179989946,
        "f": 50331649
      },
      "n": "Description",
      "d": 120762,
      "h": 8590055354,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590055354)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064891834),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": 710586
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "d": 120762,
      "h": 30064891834,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064891834)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295088058),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 120762,
      "h": 4295088058,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295088058)
  ],
  "h": 120762
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$eFOo.LCFCA.IAutomationAction ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Actions.ConsoleAction`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Actions${separator}ConsoleAction`; }
        });
        //--TRIMMABLE-BOUNDARY-END(120762)
        
        

        //--TRIMMABLE-BOUNDARY-START(841658)
        $asm.$cls(`$eFOo.LCFCA.AutomationController`, ($self) => class AutomationController extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295808954)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295808954);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295808954)
            
            //--TRIMMABLE-BOUNDARY-START(21475678138)
            /*Task */ RunNow()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475678138);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475678138)
            
            //--TRIMMABLE-BOUNDARY-START(8590776250)
            /*Task *//*async*/  FireAction(/*AutomationContext*/ context, /*AutomationActionContext*/ actionContext, /*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590776250);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (context === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    /*List<(IAutomationAction, string)>*/ let handled = new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$$.S.String)))().$ctor$1();
                    let $en1 = context.Actions.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let action = $en1.SCG$IEnumerator$$$Current;
                        {
                            let $t2, $r2;
                            actionContext.ActionId = action.Item2;
                            ($t2 = action.Item1.LCFCA$IAutomationAction$Handle(actionContext, token), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590776250)
            
            //--TRIMMABLE-BOUNDARY-START(17180710842)
            /*Task *//*async*/  Run$1(/*AutomationContext*/ context, /*Func<AutomationContext, AutomationTriggerContext>*/ getTriggerContext, /*params AutomationTriggerContext[]*/ triggerContexts)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180710842);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*List<Task<AutomationActionContext>>*/ let triggers = new ($.$$.SCG.List$$($.$$.STT.Task$$($.$eFOo.LCFCA.AutomationActionContext)))().$ctor$1();
                    /*CancellationTokenSource*/ let t = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                    let $i3 = 0;
                    let $arr3 = triggerContexts;
                    while ($i3 < $arr3.length)
                    {
                        let triggerContext = $arr3[$i3++];
                        let $en4 = context.Triggers.SCG$IEnumerable$$$GetEnumerator();
                        while ($en4.SC$1$IEnumerator$MoveNext())
                        {
                            let trigger = $en4.SCG$IEnumerator$$$Current;
                            {
                                triggerContext.TriggerId = trigger.Item2;
                                /*var*/ let trg = trigger.Item1.LCFCA$IAutomationTrigger$Handle(triggerContext, t.Token);
                                triggers.Add(trg);
                            }
                        }
                    }
                    if (getTriggerContext !== null)
                    {
                        let $en5 = context.Triggers.SCG$IEnumerable$$$GetEnumerator();
                        while ($en5.SC$1$IEnumerator$MoveNext())
                        {
                            let trigger = $en5.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let triggerContext = getTriggerContext.Invoke(context);
                                triggerContext.TriggerId = trigger.Item2;
                                /*var*/ let trg = trigger.Item1.LCFCA$IAutomationTrigger$Handle(triggerContext, t.Token);
                                triggers.Add(trg);
                            }
                        }
                    }
                    if (triggers.Count > 0)
                    {
                        let $t6, $r6;
                        /*var*/ let triggering = ($t6 = $.$$.STT.Task.WhenAll$3($.$eFOo.LCFCA.AutomationActionContext, triggers), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                        /*var*/ let fired = $.$sl.SL.Enumerable.Where($.$eFOo.LCFCA.AutomationActionContext, triggering, new ($.$$.S.Func$$$($.$eFOo.LCFCA.AutomationActionContext, $.$$.S.Boolean))().$ctor(this,  (/**/ t) =>
                        {
                            return t.Fired;
                        }, $rbkHOj ??= {"r":262145,"p":[{"n":"t","p":710586}],"n":"","d":841658,"h":0,"f":17825794}));
                        let $en7 = fired.SCG$IEnumerable$$$GetEnumerator();
                        while ($en7.SC$1$IEnumerator$MoveNext())
                        {
                            let fire = $en7.SCG$IEnumerator$$$Current;
                            {
                                try
                                {
                                    let $t8, $r8;
                                    /*Task*/ let task = this.FireAction(context, fire, t.Token);
                                    ($t8 = task, ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                }
                                catch($e)
                                {
                                }
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17180710842)
            
            //--TRIMMABLE-BOUNDARY-START(12885743546)
            /*Task */ Run(/*AutomationContext*/ context, /*params AutomationTriggerContext[]*/ triggers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885743546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Run$1(context, null, triggers);
            }
            //--TRIMMABLE-BOUNDARY-END(12885743546)
            
            //--TRIMMABLE-BOUNDARY-START(4296136634)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationController.Run(LivingThing.Core.Frameworks.Common.Automation.AutomationContext, params LivingThing.Core.Frameworks.Common.Automation.AutomationTriggerContext[])
            LCFCA$IAutomationController$Run()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296136634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Run(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296136634)
            
            //--TRIMMABLE-BOUNDARY-START(8591103930)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationController.RunNow()
            LCFCA$IAutomationController$RunNow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591103930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RunNow(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591103930)
            
            //--TRIMMABLE-BOUNDARY-START(4295808954)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295808954)
            
            static $h = 841658;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475678138),
    {
      "r": 178454529,
      "n": "RunNow",
      "d": 841658,
      "h": 21475678138,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475678138),
//--TRIMMABLE-BOUNDARY-START(8590776250),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 776122
        },
        {
          "n": "actionContext",
          "p": 710586
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "FireAction",
      "d": 841658,
      "h": 8590776250,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(8590776250),
//--TRIMMABLE-BOUNDARY-START(17180710842),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 776122
        },
        {
          "n": "getTriggerContext",
          "p": $.$$.S.Func$$$($.$eFOo.LCFCA.AutomationContext, $.$eFOo.LCFCA.AutomationTriggerContext).$h
        },
        {
          "n": "triggerContexts",
          "p": $.$typeArray($.$eFOo.LCFCA.AutomationTriggerContext).$h,
          "f": 16
        }
      ],
      "n": "Run",
      "o": "@$1",
      "d": 841658,
      "h": 17180710842,
      "f": 16781328
    },
//--TRIMMABLE-BOUNDARY-END(17180710842),
//--TRIMMABLE-BOUNDARY-START(12885743546),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 776122
        },
        {
          "n": "triggers",
          "p": $.$typeArray($.$eFOo.LCFCA.AutomationTriggerContext).$h,
          "f": 16
        }
      ],
      "n": "Run",
      "d": 841658,
      "h": 12885743546,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885743546)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295808954),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 841658,
      "h": 4295808954,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295808954)
  ],
  "h": 841658
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$eFOo.LCFCA.IAutomationController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.AutomationController`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}AutomationController`; }
        });
        //--TRIMMABLE-BOUNDARY-END(841658)
        
        

        //--TRIMMABLE-BOUNDARY-START(2152378)
        $asm.$cls(`$eFOo.LCFCATT.TimeOfDayTrigger`, ($self) => class TimeOfDayTrigger extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361890746)
            /*string */ get Name()
            {
                return "Schedule";
            }
            //--TRIMMABLE-BOUNDARY-END(34361890746)
            
            //--TRIMMABLE-BOUNDARY-START(8592086970)
            /*string */ get Description()
            {
                return "Trigger at a specific time of a specific day";
            }
            //--TRIMMABLE-BOUNDARY-END(8592086970)
            
            //--TRIMMABLE-BOUNDARY-START(30066923450)
            /*Task<AutomationActionContext> */ Handle(/*AutomationTriggerContext*/ request, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066923450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let now = $.$$.S.DateTime.UtcNow;
                /*var*/ let settings = request.Context.GetParameter$1($.$eFOo.LCFCATT.TimeOfDaySettings, this, request);
                return $.$$.STT.Task.FromResult($.$eFOo.LCFCA.AutomationActionContext, request.Context.GetAction(this, request, settings.Calendar.IsActive));
            }
            //--TRIMMABLE-BOUNDARY-END(30066923450)
            
            //--TRIMMABLE-BOUNDARY-START(21476071354)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Name.get
            get LCFCA$IAutomationTrigger$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066005946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(21476071354)
            
            //--TRIMMABLE-BOUNDARY-START(12886136762)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Description.get
            get LCFCA$IAutomationTrigger$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296202170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12886136762)
            
            //--TRIMMABLE-BOUNDARY-START(25771038650)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Handle(LivingThing.Core.Frameworks.Common.Automation.AutomationTriggerContext, System.Threading.CancellationToken)
            LCFCA$IAutomationTrigger$Handle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771038650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25771038650)
            
            //--TRIMMABLE-BOUNDARY-START(4297119674)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297119674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297119674)
            
            //--TRIMMABLE-BOUNDARY-START(4297119674)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297119674)
            
            static $h = 2152378;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361890746),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771956154,
        "f": 50331649
      },
      "n": "Name",
      "d": 2152378,
      "h": 34361890746,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361890746),
//--TRIMMABLE-BOUNDARY-START(8592086970),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182021562,
        "f": 50331649
      },
      "n": "Description",
      "d": 2152378,
      "h": 8592086970,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8592086970)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066923450),
    {
      "r": $.$$.STT.Task$$($.$eFOo.LCFCA.AutomationActionContext).$h,
      "p": [
        {
          "n": "request",
          "p": 907194
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "d": 2152378,
      "h": 30066923450,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066923450)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297119674),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2152378,
      "h": 4297119674,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297119674)
  ],
  "h": 2152378
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$eFOo.LCFCA.IAutomationTrigger ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.TimeOfDayTrigger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}TimeOfDay${separator}TimeOfDayTrigger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2152378)
        
        

        //--TRIMMABLE-BOUNDARY-START(1365946)
        $asm.$str(`$eFOo.LCFCATC.CombineAs`, ($self) => class CombineAs extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Or = 0;
            static And = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1365946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Or": 0n,
                    "And": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296333242)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296333242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296333242)
            
            //--TRIMMABLE-BOUNDARY-START(4296333242)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296333242)
            
            static $h = 1365946;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886267834),
    {
      "t": 1365946,
      "n": "Or",
      "d": 1365946,
      "h": 12886267834,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886267834),
//--TRIMMABLE-BOUNDARY-START(8591300538),
    {
      "t": 1365946,
      "n": "And",
      "d": 1365946,
      "h": 8591300538,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591300538)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296333242),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1365946,
      "h": 4296333242,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296333242)
  ],
  "h": 1365946
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineAs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}Combine${separator}CombineAs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1365946)
        
        

        //--TRIMMABLE-BOUNDARY-START(186298)
        $asm.$cls(`$eFOo.LCFCAAM.SendEmailActionContext`, ($self) => class SendEmailActionContext extends $.$eFOo.LCFCA.AutomationActionContext
        {
            //--TRIMMABLE-BOUNDARY-START(4295153594)
            $ctor$2(/*AutomationContext*/ context)
            {
                super.$ctor$1(context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295153594);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295153594)
            
            static $h = 186298;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$eFOo.LCFCA.AutomationActionContext; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295153594),
    {
      "p": [
        {
          "n": "context",
          "p": 776122
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 186298,
      "h": 4295153594,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295153594)
  ],
  "h": 186298
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Actions.Models.SendEmailActionContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Actions${separator}Models${separator}SendEmailActionContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(186298)
        
        

        //--TRIMMABLE-BOUNDARY-START(317370)
        $asm.$cls(`$eFOo.LCFCAAU.UserDefinedActionContext`, ($self) => class UserDefinedActionContext extends $.$eFOo.LCFCA.AutomationActionContext
        {
            //--TRIMMABLE-BOUNDARY-START(12885219258)
            /*AutomationActionContext[]*/ Actions = null;
            //--TRIMMABLE-BOUNDARY-END(12885219258)
            
            //--TRIMMABLE-BOUNDARY-START(8590251962)
            $ctor$2(/*AutomationContext*/ context, /*params AutomationActionContext[]*/ actions)
            {
                super.$ctor$1(context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590251962);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Actions = actions;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590251962)
            
            static $h = 317370;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$eFOo.LCFCA.AutomationActionContext; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885219258),
    {
      "p": $.$typeArray($.$eFOo.LCFCA.AutomationActionContext).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475153850,
        "f": 50331649
      },
      "n": "Actions",
      "d": 317370,
      "h": 12885219258,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885219258)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590251962),
    {
      "p": [
        {
          "n": "context",
          "p": 776122
        },
        {
          "n": "actions",
          "p": $.$typeArray($.$eFOo.LCFCA.AutomationActionContext).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 317370,
      "h": 8590251962,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590251962)
  ],
  "h": 317370
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Actions${separator}UserDefined${separator}UserDefinedActionContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(317370)
        
        

        //--TRIMMABLE-BOUNDARY-START(2021306)
        $asm.$cls(`$eFOo.LCFCATT.TimeOfDaySettingsTypeDescriptor`, ($self) => class TimeOfDaySettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$eFOo.LCFCATT.TimeOfDaySettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296988602)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296988602);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$eFOo.LCFCATT.TimeOfDaySettingsTypeDescriptor.GenerateProperties($.$eFOo.LCFCATT.TimeOfDaySettings, this, factory);
                    }, $YzLPNg ??= {"r":65537,"n":"","d":2021306,"h":0,"f":17825794}), 0, "TimeOfDaySettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Automation\\Triggers_TimeOfDay_TimeOfDaySettings_LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.TimeOfDaySettingsTypeDescriptorBuilder.g.cs", "TimeOfDaySettingsTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296988602)
            
            //--TRIMMABLE-BOUNDARY-START(12886923194)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886923194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Calendar"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$eFOo.LCFCATT.TimeOfDaySettings.$type, $.$discardRef(), "Calendar", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Calendar")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDC.MaskableDateTime$$($.$eFOo.LCFCATT.MaskProvider), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Calendar";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.TimeOfDaySettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$eFOo.LCFCATT.TimeOfDaySettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCDC.MaskableDateTime$$($.$eFOo.LCFCATT.MaskProvider), ($.$cast(target, $.$eFOo.LCFCATT.TimeOfDaySettings)).Calendar);
                        }, $cJrHzj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2021306,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$eFOo.LCFCATT.TimeOfDaySettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Calendar = value.AsReference($.$fPer.LCFCDC.MaskableDateTime$$($.$eFOo.LCFCATT.MaskProvider));
                        }, $UWEYqd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2021306,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886923194)
            
            //--TRIMMABLE-BOUNDARY-START(17181890490)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.TimeOfDaySettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181890490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Calendar = _target.Calendar;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Calendar"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDC.MaskableDateTime$$($.$eFOo.LCFCATT.MaskProvider)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Calendar, ($v) => _Calendar = $v, $.$fPer.LCFCDC.MaskableDateTime$$($.$eFOo.LCFCATT.MaskProvider))))
                    {
                        _target.Calendar = _Calendar;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181890490)
            
            //--TRIMMABLE-BOUNDARY-START(8591955898)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.TimeOfDaySettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591955898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$eFOo.LCFCATT.TimeOfDaySettings().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$eFOo.LCFCATT.TimeOfDaySettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$eFOo.LCFCATT.TimeOfDaySettings)))
                {
                    /*var*/ let result = $.$eFOo.LCFCATT.TimeOfDaySettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$eFOo.LCFCATT.TimeOfDaySettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$eFOo.LCFCATT.TimeOfDaySettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$eFOo.LCFCATT.TimeOfDaySettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591955898)
            
            static $h = 2021306;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$eFOo.LCFCATT.TimeOfDaySettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886923194),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2021306,
      "h": 12886923194,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886923194),
//--TRIMMABLE-BOUNDARY-START(17181890490),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1890234,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2021306,
      "h": 17181890490,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181890490),
//--TRIMMABLE-BOUNDARY-START(8591955898),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1890234,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2021306,
      "h": 8591955898,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591955898)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296988602),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2021306,
      "h": 4296988602,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296988602)
  ],
  "h": 2021306
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$eFOo.LCFCATT.TimeOfDaySettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.TimeOfDay.TimeOfDaySettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}TimeOfDay${separator}TimeOfDaySettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2021306)
        
        

        //--TRIMMABLE-BOUNDARY-START(1693626)
        $asm.$cls(`$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptor`, ($self) => class CombineTriggersSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$eFOo.LCFCATC.CombineTriggersSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296660922)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296660922);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptor.GenerateProperties($.$eFOo.LCFCATC.CombineTriggersSettings, this, factory);
                    }, $OmpnPe ??= {"r":65537,"n":"","d":1693626,"h":0,"f":17825794}), 0, "CombineTriggersSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Automation\\Triggers_Combine_CombineTriggersSettings_LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTriggersSettingsTypeDescriptorBuilder.g.cs", "CombineTriggersSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296660922)
            
            //--TRIMMABLE-BOUNDARY-START(12886595514)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886595514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Members"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$eFOo.LCFCATC.CombineTriggersSettings.$type, $.$discardRef(), "Members", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Members")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Members";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTriggersSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.String), ($.$cast(target, $.$eFOo.LCFCATC.CombineTriggersSettings)).Members);
                        }, $dOpCPg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1693626,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Members = value.AsReference($.$typeArray($.$$.S.String));
                        }, $fMMHOa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1693626,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("As"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$eFOo.LCFCATC.CombineTriggersSettings.$type, $.$discardRef(), "As", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("As")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$eFOo.LCFCATC.CombineAs, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "As";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTriggersSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$eFOo.LCFCATC.CombineAs, ($.$cast(target, $.$eFOo.LCFCATC.CombineTriggersSettings)).As);
                        }, $HQjGua ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1693626,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.As = value.AsEnumValue($.$eFOo.LCFCATC.CombineAs);
                        }, $nxhTcd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1693626,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886595514)
            
            //--TRIMMABLE-BOUNDARY-START(17181562810)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTriggersSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181562810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Members = _target.Members;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Members"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Members, ($v) => _Members = $v, $.$typeArray($.$$.S.String))))
                    {
                        _target.Members = _Members;
                        if (_Members !== null)
                        {
                            let $i6 = 0;
                            let $arr6 = _Members;
                            while ($i6 < $arr6.length)
                            {
                                let item = $arr6[$i6++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Members, ($v) => _Members = $v, $.$typeArray($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _As = _target.As;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("As"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$eFOo.LCFCATC.CombineAs));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$eFOo.LCFCATC.CombineAs, () => _As, ($v) => _As = $v, null, true)))
                    {
                        _target.As = _As;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181562810)
            
            //--TRIMMABLE-BOUNDARY-START(8591628218)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTriggersSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591628218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$eFOo.LCFCATC.CombineTriggersSettings().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$eFOo.LCFCATC.CombineTriggersSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$eFOo.LCFCATC.CombineTriggersSettings)))
                {
                    /*var*/ let result = $.$eFOo.LCFCATC.CombineTriggersSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$eFOo.LCFCATC.CombineTriggersSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$eFOo.LCFCATC.CombineTriggersSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$eFOo.LCFCATC.CombineTriggersSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591628218)
            
            static $h = 1693626;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$eFOo.LCFCATC.CombineTriggersSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886595514),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1693626,
      "h": 12886595514,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886595514),
//--TRIMMABLE-BOUNDARY-START(17181562810),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1562554,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1693626,
      "h": 17181562810,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181562810),
//--TRIMMABLE-BOUNDARY-START(8591628218),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1562554,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1693626,
      "h": 8591628218,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591628218)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296660922),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1693626,
      "h": 4296660922,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296660922)
  ],
  "h": 1693626
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$eFOo.LCFCATC.CombineTriggersSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Triggers.Combine.CombineTriggersSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Triggers${separator}Combine${separator}CombineTriggersSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1693626)
        
        

        //--TRIMMABLE-BOUNDARY-START(579514)
        $asm.$cls(`$eFOo.LCFCAAU.UserDefinedActionSettingsTypeDescriptor`, ($self) => class UserDefinedActionSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$eFOo.LCFCAAU.UserDefinedActionSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4295546810)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295546810);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$eFOo.LCFCAAU.UserDefinedActionSettingsTypeDescriptor.GenerateProperties($.$eFOo.LCFCAAU.UserDefinedActionSettings, this, factory);
                    }, $uOQjra ??= {"r":65537,"n":"","d":579514,"h":0,"f":17825794}), 0, "UserDefinedActionSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Automation\\Actions_UserDefined_UserDefinedActionSettings_LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionSettingsTypeDescriptorBuilder.g.cs", "UserDefinedActionSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295546810)
            
            //--TRIMMABLE-BOUNDARY-START(12885481402)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885481402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ActionSettings"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$eFOo.LCFCAAU.UserDefinedActionSettings.$type, $.$discardRef(), "ActionSettings", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ActionSettings")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$eFOo.LCFCAAU.UserDefinedActionSetting), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ActionSettings";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$eFOo.LCFCAAU.UserDefinedActionSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$eFOo.LCFCAAU.UserDefinedActionSetting), ($.$cast(target, $.$eFOo.LCFCAAU.UserDefinedActionSettings)).ActionSettings);
                        }, $zRkmpc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":579514,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$eFOo.LCFCAAU.UserDefinedActionSettingsTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.ActionSettings = value.AsReference($.$typeArray($.$eFOo.LCFCAAU.UserDefinedActionSetting));
                        }, $RHcjvi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":579514,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885481402)
            
            //--TRIMMABLE-BOUNDARY-START(17180448698)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180448698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _ActionSettings = _target.ActionSettings;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ActionSettings"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$eFOo.LCFCAAU.UserDefinedActionSetting)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$eFOo.LCFCAAU.UserDefinedActionSetting), $.$eFOo.LCFCAAU.UserDefinedActionSetting));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$eFOo.LCFCAAU.UserDefinedActionSetting), $.$eFOo.LCFCAAU.UserDefinedActionSetting, property, $.$ref(() => _ActionSettings, ($v) => _ActionSettings = $v, $.$typeArray($.$eFOo.LCFCAAU.UserDefinedActionSetting))))
                    {
                        _target.ActionSettings = _ActionSettings;
                        if (_ActionSettings !== null)
                        {
                            let $i4 = 0;
                            let $arr4 = _ActionSettings;
                            while ($i4 < $arr4.length)
                            {
                                let item = $arr4[$i4++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$eFOo.LCFCAAU.UserDefinedActionSetting)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$eFOo.LCFCAAU.UserDefinedActionSetting), $.$eFOo.LCFCAAU.UserDefinedActionSetting, property, $.$ref(() => _ActionSettings, ($v) => _ActionSettings = $v, $.$typeArray($.$eFOo.LCFCAAU.UserDefinedActionSetting)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180448698)
            
            //--TRIMMABLE-BOUNDARY-START(8590514106)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590514106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$eFOo.LCFCAAU.UserDefinedActionSettings().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$eFOo.LCFCAAU.UserDefinedActionSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$eFOo.LCFCAAU.UserDefinedActionSettings)))
                {
                    /*var*/ let result = $.$eFOo.LCFCAAU.UserDefinedActionSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$eFOo.LCFCAAU.UserDefinedActionSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$eFOo.LCFCAAU.UserDefinedActionSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$eFOo.LCFCAAU.UserDefinedActionSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590514106)
            
            static $h = 579514;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$eFOo.LCFCAAU.UserDefinedActionSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885481402),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 579514,
      "h": 12885481402,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885481402),
//--TRIMMABLE-BOUNDARY-START(17180448698),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 448442,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 579514,
      "h": 17180448698,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180448698),
//--TRIMMABLE-BOUNDARY-START(8590514106),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 448442,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 579514,
      "h": 8590514106,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590514106)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295546810),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 579514,
      "h": 4295546810,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295546810)
  ],
  "h": 579514
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$eFOo.LCFCAAU.UserDefinedActionSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Automation.Actions.UserDefined.UserDefinedActionSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Automation${separator}Actions${separator}UserDefined${separator}UserDefinedActionSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(579514)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(55226)
