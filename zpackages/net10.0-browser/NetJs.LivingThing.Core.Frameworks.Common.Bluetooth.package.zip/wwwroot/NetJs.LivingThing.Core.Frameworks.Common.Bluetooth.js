
//--TRIMMABLE-BOUNDARY-START(56801)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $fXpo, $zHIt, $uvJL, $KuVO) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", 
    {
  "h": 56801,
  "f": "LivingThing.Core.Frameworks.Common.Bluetooth",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Bluetooth",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Bluetooth",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2088417)
        $asm.$cls(`$lOHy.LCFCB.IBluetoothSerialPortFactory`, ($self) => class IBluetoothSerialPortFactory
        {
            static $h = 2088417;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297055713),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$lOHy.LCFCB.IBluetoothDevice)).$h,
      "n": "GetPairedDevices",
      "o": "LCFCB$IBluetoothSerialPortFactory$GetPairedDevices",
      "d": 2088417,
      "h": 4297055713,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297055713),
//--TRIMMABLE-BOUNDARY-START(8592023009),
    {
      "r": $.$$.STT.Task$$($.$lOHy.LCFCB.IBluetoothDeviceSerialPort).$h,
      "p": [
        {
          "n": "device",
          "p": 1957345
        }
      ],
      "n": "Open",
      "o": "LCFCB$IBluetoothSerialPortFactory$Open",
      "d": 2088417,
      "h": 8592023009,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8592023009)
  ],
  "h": 2088417
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.IBluetoothSerialPortFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}IBluetoothSerialPortFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2088417)
        
        

        //--TRIMMABLE-BOUNDARY-START(2022881)
        $asm.$cls(`$lOHy.LCFCB.IBluetoothDeviceSerialPort`, ($self) => class IBluetoothDeviceSerialPort
        {
            static $h = 2022881;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591957473),
    {
      "p": 1957345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771826657,
        "f": 50331905
      },
      "n": "Device",
      "o": "LCFCB$IBluetoothDeviceSerialPort$Device",
      "d": 2022881,
      "h": 8591957473,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591957473),
//--TRIMMABLE-BOUNDARY-START(55836597729),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361761249,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541630433,
        "f": 83886337
      },
      "n": "TimeOut",
      "o": "LCFCB$IBluetoothDeviceSerialPort$TimeOut",
      "d": 2022881,
      "h": 55836597729,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(55836597729)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181892065),
    {
      "r": 65537,
      "n": "DiscardOutBuffer",
      "o": "LCFCB$IBluetoothDeviceSerialPort$DiscardOutBuffer",
      "d": 2022881,
      "h": 17181892065,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181892065),
//--TRIMMABLE-BOUNDARY-START(12886924769),
    {
      "r": 65537,
      "n": "DiscardInBuffer",
      "o": "LCFCB$IBluetoothDeviceSerialPort$DiscardInBuffer",
      "d": 2022881,
      "h": 12886924769,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886924769),
//--TRIMMABLE-BOUNDARY-START(60131565025),
    {
      "r": 65537,
      "p": [
        {
          "n": "b",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Write",
      "o": "LCFCB$IBluetoothDeviceSerialPort$Write",
      "d": 2022881,
      "h": 60131565025,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(60131565025),
//--TRIMMABLE-BOUNDARY-START(42951695841),
    {
      "r": 393217,
      "n": "ReadByte",
      "o": "LCFCB$IBluetoothDeviceSerialPort$ReadByte",
      "d": 2022881,
      "h": 42951695841,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42951695841),
//--TRIMMABLE-BOUNDARY-START(38656728545),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$$.S.Byte)).$h,
      "n": "Read",
      "o": "LCFCB$IBluetoothDeviceSerialPort$Read",
      "d": 2022881,
      "h": 38656728545,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38656728545),
//--TRIMMABLE-BOUNDARY-START(4296990177),
    {
      "r": 65537,
      "n": "Close",
      "o": "LCFCB$IBluetoothDeviceSerialPort$Close",
      "d": 2022881,
      "h": 4296990177,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296990177)
  ],
  "h": 2022881
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.IBluetoothDeviceSerialPort`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}IBluetoothDeviceSerialPort`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2022881)
        
        

        //--TRIMMABLE-BOUNDARY-START(318945)
        $asm.$cls(`$lOHy.LCFCBBI.IBeaconPacketProvider`, ($self) => class IBeaconPacketProvider
        {
            static $h = 318945;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949991905),
    {
      "r": 178454529,
      "n": "StartPacketListening",
      "o": "LCFCBBI$IBeaconPacketProvider$StartPacketListening",
      "d": 318945,
      "h": 42949991905,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42949991905),
//--TRIMMABLE-BOUNDARY-START(47244959201),
    {
      "r": 65537,
      "n": "StopPacketListening",
      "o": "LCFCBBI$IBeaconPacketProvider$StopPacketListening",
      "d": 318945,
      "h": 47244959201,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47244959201)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(21475155425),
    {
      "e": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BLEAdvertisementPacketArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BLEAdvertisementPacketArgs).$h
          }
        ],
        "n": "add_AdvertisementPacketReceived",
        "o": "LCFCBBI$IBeaconPacketProvider$add_AdvertisementPacketReceived",
        "d": 318945,
        "h": 8590253537,
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BLEAdvertisementPacketArgs).$h
          }
        ],
        "n": "remove_AdvertisementPacketReceived",
        "o": "LCFCBBI$IBeaconPacketProvider$remove_AdvertisementPacketReceived",
        "d": 318945,
        "h": 30065090017,
        "f": 285212929
      },
      "n": "AdvertisementPacketReceived",
      "o": "LivingThing$Core$Frameworks$Common$Bluetooth$Beacon$Interfaces$IBeaconPacketProvider$AdvertisementPacketReceived",
      "d": 318945,
      "h": 21475155425,
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(21475155425),
//--TRIMMABLE-BOUNDARY-START(51539926497),
    {
      "e": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BTError).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BTError).$h
          }
        ],
        "n": "add_WatcherStopped",
        "o": "LCFCBBI$IBeaconPacketProvider$add_WatcherStopped",
        "d": 318945,
        "h": 17180188129,
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$lOHy.LCFCBBM.BTError).$h
          }
        ],
        "n": "remove_WatcherStopped",
        "o": "LCFCBBI$IBeaconPacketProvider$remove_WatcherStopped",
        "d": 318945,
        "h": 38655024609,
        "f": 285212929
      },
      "n": "WatcherStopped",
      "o": "LivingThing$Core$Frameworks$Common$Bluetooth$Beacon$Interfaces$IBeaconPacketProvider$WatcherStopped",
      "d": 318945,
      "h": 51539926497,
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(51539926497)
  ],
  "h": 318945
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconPacketProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Interfaces${separator}IBeaconPacketProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(318945)
        
        

        //--TRIMMABLE-BOUNDARY-START(187873)
        $asm.$cls(`$lOHy.LCFCBBI.IBeaconAdvertiser`, ($self) => class IBeaconAdvertiser
        {
            static $h = 187873;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295155169),
    {
      "r": 178454529,
      "p": [
        {
          "n": "data",
          "p": 646625
        },
        {
          "n": "token",
          "p": $.$typeNullable($.$$.ST$1.CancellationToken).$h,
          "f": 65
        }
      ],
      "n": "StartAdvertisement",
      "o": "LCFCBBI$IBeaconAdvertiser$StartAdvertisement",
      "d": 187873,
      "h": 4295155169,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295155169),
//--TRIMMABLE-BOUNDARY-START(8590122465),
    {
      "r": 65537,
      "n": "StopAdvertisement",
      "o": "LCFCBBI$IBeaconAdvertiser$StopAdvertisement",
      "d": 187873,
      "h": 8590122465,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590122465)
  ],
  "h": 187873
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconAdvertiser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Interfaces${separator}IBeaconAdvertiser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(187873)
        
        

        //--TRIMMABLE-BOUNDARY-START(1957345)
        $asm.$cls(`$lOHy.LCFCB.IBluetoothDevice`, ($self) => class IBluetoothDevice
        {
            static $h = 1957345;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476793825),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591891937,
        "f": 50331905
      },
      "n": "Id",
      "o": "LCFCB$IBluetoothDevice$Id",
      "d": 1957345,
      "h": 21476793825,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21476793825),
//--TRIMMABLE-BOUNDARY-START(25771761121),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181826529,
        "f": 50331905
      },
      "n": "Name",
      "o": "LCFCB$IBluetoothDevice$Name",
      "d": 1957345,
      "h": 25771761121,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25771761121)
  ],
  "h": 1957345
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.IBluetoothDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}IBluetoothDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1957345)
        
        

        //--TRIMMABLE-BOUNDARY-START(253409)
        $asm.$cls(`$lOHy.LCFCBBI.IBeaconFrame`, ($self) => class IBeaconFrame
        {
            static $h = 253409;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885155297),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590188001,
        "f": 50331905
      },
      "n": "IsValid",
      "o": "LCFCBBI$IBeaconFrame$IsValid",
      "d": 253409,
      "h": 12885155297,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885155297)
  ],
  "h": 253409
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionMessage ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeaconFrame`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Interfaces${separator}IBeaconFrame`; }
        });
        //--TRIMMABLE-BOUNDARY-END(253409)
        
        

        //--TRIMMABLE-BOUNDARY-START(122337)
        $asm.$cls(`$lOHy.LCFCBBI.IBeacon`, ($self) => class IBeacon
        {
            static $h = 122337;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81604500961),
    {
      "p": 646625,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129664481,
        "f": 50331905
      },
      "n": "LastPacket",
      "o": "LCFCBBI$IBeacon$LastPacket",
      "d": 122337,
      "h": 81604500961,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(81604500961),
//--TRIMMABLE-BOUNDARY-START(4295089633),
    {
      "p": $.$$.SCG.IEnumerable$$($.$lOHy.LCFCBBI.IBeaconFrame).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769926113,
        "f": 50331905
      },
      "n": "BeaconFrames",
      "o": "LCFCBBI$IBeacon$BeaconFrames",
      "d": 122337,
      "h": 4295089633,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295089633),
//--TRIMMABLE-BOUNDARY-START(8590056929),
    {
      "p": 450017,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359860705,
        "f": 50331905
      },
      "n": "BeaconType",
      "o": "LCFCBBI$IBeacon$BeaconType",
      "d": 122337,
      "h": 8590056929,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590056929),
//--TRIMMABLE-BOUNDARY-START(12885024225),
    {
      "p": 983041,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949795297,
        "f": 50331905
      },
      "n": "BluetoothAddress",
      "o": "LCFCBBI$IBeacon$BluetoothAddress",
      "d": 122337,
      "h": 12885024225,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885024225),
//--TRIMMABLE-BOUNDARY-START(17179991521),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539729889,
        "f": 50331905
      },
      "n": "BluetoothAddressAsString",
      "o": "LCFCBBI$IBeacon$BluetoothAddressAsString",
      "d": 122337,
      "h": 17179991521,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17179991521),
//--TRIMMABLE-BOUNDARY-START(85899468257),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719599073,
        "f": 50331905
      },
      "n": "Rssi",
      "o": "LCFCBBI$IBeacon$Rssi",
      "d": 122337,
      "h": 85899468257,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(85899468257),
//--TRIMMABLE-BOUNDARY-START(90194435553),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309533665,
        "f": 50331905
      },
      "n": "Timestamp",
      "o": "LCFCBBI$IBeacon$Timestamp",
      "d": 122337,
      "h": 90194435553,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90194435553)
  ],
  "h": 122337
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged, $.$KuVO.LCFCC.IConnectionClient, $.$fPer.LCFCD.IWorkspace ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Interfaces.IBeacon`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Interfaces${separator}IBeacon`; }
        });
        //--TRIMMABLE-BOUNDARY-END(122337)
        
        

        //--TRIMMABLE-BOUNDARY-START(1433057)
        $asm.$cls(`$lOHy.LCFCBBM.BLERecord`, ($self) => class BLERecord extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476269537)
            /*BLEPacketType*/ PacketType = 0;
            //--TRIMMABLE-BOUNDARY-END(21476269537)
            
            //--TRIMMABLE-BOUNDARY-START(8591367649)
            $ctor$1(/*BLEPacketType*/ packetType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591367649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.PacketType = packetType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591367649)
            
            static $h = 1433057;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476269537),
    {
      "p": 1301985,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181302241,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066204129,
        "f": 83886081
      },
      "n": "PacketType",
      "d": 1433057,
      "h": 21476269537,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476269537)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591367649),
    {
      "p": [
        {
          "n": "packetType",
          "p": 1301985
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1433057,
      "h": 8591367649,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591367649)
  ],
  "h": 1433057
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLERecord`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLERecord`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1433057)
        
        

        //--TRIMMABLE-BOUNDARY-START(646625)
        $asm.$cls(`$lOHy.LCFCBBM.BLEAdvertisementPacket`, ($self) => class BLEAdvertisementPacket extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065417697)
            /*BeaconAdvertisement*/ Advertisement = null;
            //--TRIMMABLE-BOUNDARY-END(30065417697)
            
            //--TRIMMABLE-BOUNDARY-START(34360384993)
            /*BLEAdvertisementType*/ AdvertisementType = 0;
            //--TRIMMABLE-BOUNDARY-END(34360384993)
            
            //--TRIMMABLE-BOUNDARY-START(38655352289)
            /*ulong*/ BluetoothAddress = 0n;
            //--TRIMMABLE-BOUNDARY-END(38655352289)
            
            //--TRIMMABLE-BOUNDARY-START(85899992545)
            /*short*/ RawSignalStrengthInDBm = 0;
            //--TRIMMABLE-BOUNDARY-END(85899992545)
            
            //--TRIMMABLE-BOUNDARY-START(133144632801)
            /*DateTimeOffset*/ Timestamp;
            //--TRIMMABLE-BOUNDARY-END(133144632801)
            
            //--TRIMMABLE-BOUNDARY-START(25770450401)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770450401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770450401)
            
            //--TRIMMABLE-BOUNDARY-START(25770450401)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770450401)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133144632801)
                this.Timestamp = $.$default($.$$.S.DateTimeOffset);
                //--TRIMMABLE-BOUNDARY-END(133144632801)
                
            }
            static $h = 646625;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065417697),
    {
      "p": 384481,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245286881,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489927137,
        "f": 83886081
      },
      "n": "Advertisement",
      "d": 646625,
      "h": 30065417697,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065417697),
//--TRIMMABLE-BOUNDARY-START(34360384993),
    {
      "p": 777697,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835221473,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079861729,
        "f": 83886081
      },
      "n": "AdvertisementType",
      "d": 646625,
      "h": 34360384993,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360384993),
//--TRIMMABLE-BOUNDARY-START(38655352289),
    {
      "p": 983041,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425156065,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669796321,
        "f": 83886081
      },
      "n": "BluetoothAddress",
      "d": 646625,
      "h": 38655352289,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655352289),
//--TRIMMABLE-BOUNDARY-START(85899992545),
    {
      "p": 524289,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015090657,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259730913,
        "f": 83886081
      },
      "n": "RawSignalStrengthInDBm",
      "d": 646625,
      "h": 85899992545,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899992545),
//--TRIMMABLE-BOUNDARY-START(133144632801),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605025249,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849665505,
        "f": 83886081
      },
      "n": "Timestamp",
      "d": 646625,
      "h": 133144632801,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144632801)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770450401),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 646625,
      "h": 25770450401,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770450401)
  ],
  "h": 646625
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEAdvertisementPacket`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEAdvertisementPacket`; }
        });
        //--TRIMMABLE-BOUNDARY-END(646625)
        
        

        //--TRIMMABLE-BOUNDARY-START(384481)
        $asm.$cls(`$lOHy.LCFCBBM.BeaconAdvertisement`, ($self) => class BeaconAdvertisement extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64424893921)
            /*string?*/ LocalName = null;
            //--TRIMMABLE-BOUNDARY-END(64424893921)
            
            //--TRIMMABLE-BOUNDARY-START(73014828513)
            /*List<Guid>?*/ ServiceUuids = null;
            //--TRIMMABLE-BOUNDARY-END(73014828513)
            
            //--TRIMMABLE-BOUNDARY-START(25770188257)
            /*List<BLEAdvertisementDataSection>?*/ DataSections = null;
            //--TRIMMABLE-BOUNDARY-END(25770188257)
            
            //--TRIMMABLE-BOUNDARY-START(68719861217)
            /*List<BLEManufacturerData>?*/ ManufacturerData = null;
            //--TRIMMABLE-BOUNDARY-END(68719861217)
            
            //--TRIMMABLE-BOUNDARY-START(21475220961)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475220961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475220961)
            
            //--TRIMMABLE-BOUNDARY-START(21475220961)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475220961)
            
            static $h = 384481;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64424893921),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950057441,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194697697,
        "f": 83886081
      },
      "n": "LocalName",
      "d": 384481,
      "h": 64424893921,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424893921),
//--TRIMMABLE-BOUNDARY-START(73014828513),
    {
      "p": $.$$.SCG.List$$($.$$.S.Guid).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129926625,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374566881,
        "f": 83886081
      },
      "n": "ServiceUuids",
      "d": 384481,
      "h": 73014828513,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014828513),
//--TRIMMABLE-BOUNDARY-START(25770188257),
    {
      "p": $.$$.SCG.List$$($.$lOHy.LCFCBBM.BLEAdvertisementDataSection).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360122849,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604763105,
        "f": 83886081
      },
      "n": "DataSections",
      "d": 384481,
      "h": 25770188257,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770188257),
//--TRIMMABLE-BOUNDARY-START(68719861217),
    {
      "p": $.$$.SCG.List$$($.$lOHy.LCFCBBM.BLEManufacturerData).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539992033,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784632289,
        "f": 83886081
      },
      "n": "ManufacturerData",
      "d": 384481,
      "h": 68719861217,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719861217)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475220961),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 384481,
      "h": 21475220961,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475220961)
  ],
  "h": 384481
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BeaconAdvertisement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BeaconAdvertisement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(384481)
        
        

        //--TRIMMABLE-BOUNDARY-START(974305)
        $asm.$cls(`$lOHy.LCFCBBM.BLEAdvertisementWatcherStatusCodesCustomAttributesProvider`, ($self) => class BLEAdvertisementWatcherStatusCodesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295941601)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295941601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295941601)
            
            static $h = 974305;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295941601),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 974305,
      "h": 4295941601,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295941601)
  ],
  "h": 974305
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEAdvertisementWatcherStatusCodesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEAdvertisementWatcherStatusCodesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(974305)
        
        

        //--TRIMMABLE-BOUNDARY-START(843233)
        $asm.$cls(`$lOHy.LCFCBBM.BLEAdvertisementTypeCustomAttributesProvider`, ($self) => class BLEAdvertisementTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295810529)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295810529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295810529)
            
            static $h = 843233;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295810529),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 843233,
      "h": 4295810529,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295810529)
  ],
  "h": 843233
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEAdvertisementTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEAdvertisementTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(843233)
        
        

        //--TRIMMABLE-BOUNDARY-START(1695201)
        $asm.$cls(`$lOHy.LCFCBBM.BTMemberCustomAttributesProvider`, ($self) => class BTMemberCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296662497)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296662497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296662497)
            
            static $h = 1695201;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296662497),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1695201,
      "h": 4296662497,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296662497)
  ],
  "h": 1695201
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BTMemberCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BTMemberCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1695201)
        
        

        //--TRIMMABLE-BOUNDARY-START(1826273)
        $asm.$cls(`$lOHy.LCFCB.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296793569)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296793569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lOHy.LCFCBBM.BeaconTypeEnum.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lOHy.LCFCBBM.BeaconTypeEnumCustomAttributesProvider, $.$lOHy.LCFCBBM.BeaconTypeEnumCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lOHy.LCFCBBM.BLEAdvertisementType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lOHy.LCFCBBM.BLEAdvertisementTypeCustomAttributesProvider, $.$lOHy.LCFCBBM.BLEAdvertisementTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lOHy.LCFCBBM.BLEAdvertisementWatcherStatusCodes.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lOHy.LCFCBBM.BLEAdvertisementWatcherStatusCodesCustomAttributesProvider, $.$lOHy.LCFCBBM.BLEAdvertisementWatcherStatusCodesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lOHy.LCFCBBM.BLEPacketType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lOHy.LCFCBBM.BLEPacketTypeCustomAttributesProvider, $.$lOHy.LCFCBBM.BLEPacketTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$lOHy.LCFCBBM.BTMember.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$lOHy.LCFCBBM.BTMemberCustomAttributesProvider, $.$lOHy.LCFCBBM.BTMemberCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4296793569)
            
            static $h = 1826273;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296793569),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 1826273,
      "h": 4296793569,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296793569)
  ],
  "h": 1826273
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1826273)
        
        

        //--TRIMMABLE-BOUNDARY-START(1367521)
        $asm.$cls(`$lOHy.LCFCBBM.BLEPacketTypeCustomAttributesProvider`, ($self) => class BLEPacketTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296334817)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296334817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296334817)
            
            static $h = 1367521;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296334817),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1367521,
      "h": 4296334817,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296334817)
  ],
  "h": 1367521
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEPacketTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEPacketTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1367521)
        
        

        //--TRIMMABLE-BOUNDARY-START(515553)
        $asm.$cls(`$lOHy.LCFCBBM.BeaconTypeEnumCustomAttributesProvider`, ($self) => class BeaconTypeEnumCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295482849)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295482849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295482849)
            
            static $h = 515553;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295482849),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 515553,
      "h": 4295482849,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295482849)
  ],
  "h": 515553
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BeaconTypeEnumCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BeaconTypeEnumCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(515553)
        
        

        //--TRIMMABLE-BOUNDARY-START(1891809)
        $asm.$cls(`$lOHy.LCFCB.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296859105)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296859105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4296859105)
            
            static $h = 1891809;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296859105),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 1891809,
      "h": 4296859105,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296859105)
  ],
  "h": 1891809
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1891809)
        
        

        //--TRIMMABLE-BOUNDARY-START(1498593)
        $asm.$cls(`$lOHy.LCFCBBM.BTError`, ($self) => class BTError extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(1564129)
            static $_BluetoothError;
            static get BluetoothError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1564129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$lOHy.LCFCBBM.BTError;
                return $cls.$_BluetoothError ??= $asm.$nstr(`$lOHy.LCFCBBM.BTError.BluetoothError`, ($self) => class BluetoothError extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static Success = 0;
                    static RadioNotAvailable = 1;
                    static ResourceInUse = 2;
                    static DeviceNotConnected = 3;
                    static OtherError = 4;
                    static DisabledByPolicy = 5;
                    static NotSupported = 6;
                    static DisabledByUser = 7;
                    static ConsentRequired = 8;
                    static TransportNotSupported = 9;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1564129);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Success": 0n,
                            "RadioNotAvailable": 1n,
                            "ResourceInUse": 2n,
                            "DeviceNotConnected": 3n,
                            "OtherError": 4n,
                            "DisabledByPolicy": 5n,
                            "NotSupported": 6n,
                            "DisabledByUser": 7n,
                            "ConsentRequired": 8n,
                            "TransportNotSupported": 9n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4296531425)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296531425);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296531425)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296531425)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296531425)
                    
                    static $h = 1564129;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951237089),
    {
      "t": 1564129,
      "n": "Success",
      "d": 1564129,
      "h": 42951237089,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951237089),
//--TRIMMABLE-BOUNDARY-START(34361302497),
    {
      "t": 1564129,
      "n": "RadioNotAvailable",
      "d": 1564129,
      "h": 34361302497,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361302497),
//--TRIMMABLE-BOUNDARY-START(38656269793),
    {
      "t": 1564129,
      "n": "ResourceInUse",
      "d": 1564129,
      "h": 38656269793,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656269793),
//--TRIMMABLE-BOUNDARY-START(12886466017),
    {
      "t": 1564129,
      "n": "DeviceNotConnected",
      "d": 1564129,
      "h": 12886466017,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886466017),
//--TRIMMABLE-BOUNDARY-START(30066335201),
    {
      "t": 1564129,
      "n": "OtherError",
      "d": 1564129,
      "h": 30066335201,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066335201),
//--TRIMMABLE-BOUNDARY-START(17181433313),
    {
      "t": 1564129,
      "n": "DisabledByPolicy",
      "d": 1564129,
      "h": 17181433313,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181433313),
//--TRIMMABLE-BOUNDARY-START(25771367905),
    {
      "t": 1564129,
      "n": "NotSupported",
      "d": 1564129,
      "h": 25771367905,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771367905),
//--TRIMMABLE-BOUNDARY-START(21476400609),
    {
      "t": 1564129,
      "n": "DisabledByUser",
      "d": 1564129,
      "h": 21476400609,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476400609),
//--TRIMMABLE-BOUNDARY-START(8591498721),
    {
      "t": 1564129,
      "n": "ConsentRequired",
      "d": 1564129,
      "h": 8591498721,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591498721),
//--TRIMMABLE-BOUNDARY-START(47246204385),
    {
      "t": 1564129,
      "n": "TransportNotSupported",
      "d": 1564129,
      "h": 47246204385,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246204385)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296531425),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1564129,
      "h": 4296531425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296531425)
  ],
  "d": 1498593,
  "h": 1564129
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BTError+BluetoothError`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BTError${separator}BluetoothError`; }
                }, $cls, ($v) => $cls.$_BluetoothError = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1564129)
            
            //--TRIMMABLE-BOUNDARY-START(12886400481)
            /*BluetoothError*/ BluetoothErrorCode = 0;
            //--TRIMMABLE-BOUNDARY-END(12886400481)
            
            //--TRIMMABLE-BOUNDARY-START(8591433185)
            $ctor$1(/*BluetoothError*/ btErrorCode)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591433185);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.BluetoothErrorCode = btErrorCode;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591433185)
            
            static $h = 1498593;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886400481),
    {
      "p": 1564129,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476335073,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066269665,
        "f": 83886081
      },
      "n": "BluetoothErrorCode",
      "d": 1498593,
      "h": 12886400481,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886400481)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591433185),
    {
      "p": [
        {
          "n": "btErrorCode",
          "p": 1564129
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1498593,
      "h": 8591433185,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591433185)
  ],
  "h": 1498593
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$lOHy.LCFCBBM.BTError.BluetoothError ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BTError`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BTError`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1498593)
        
        

        //--TRIMMABLE-BOUNDARY-START(1760737)
        $asm.$cls(`$lOHy.LCFCB.BluetoothDevice`, ($self) => class BluetoothDevice extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886662625)
            $ctor$1(/*string*/ id, /*string*/ name)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886662625);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Id = id;
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886662625)
            
            //--TRIMMABLE-BOUNDARY-START(34361499105)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(34361499105)
            
            //--TRIMMABLE-BOUNDARY-START(38656466401)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(38656466401)
            
            //--TRIMMABLE-BOUNDARY-START(8591891937)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.IBluetoothDevice.Id.get
            get LCFCB$IBluetoothDevice$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476793825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(8591891937)
            
            //--TRIMMABLE-BOUNDARY-START(17181826529)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Bluetooth.IBluetoothDevice.Name.get
            get LCFCB$IBluetoothDevice$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771761121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(17181826529)
            
            static $h = 1760737;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361499105),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476597217,
        "f": 50331649
      },
      "n": "Id",
      "d": 1760737,
      "h": 34361499105,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361499105),
//--TRIMMABLE-BOUNDARY-START(38656466401),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066531809,
        "f": 50331649
      },
      "n": "Name",
      "d": 1760737,
      "h": 38656466401,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656466401)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886662625),
    {
      "p": [
        {
          "n": "id",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1760737,
      "h": 12886662625,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886662625)
  ],
  "h": 1760737
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$lOHy.LCFCB.IBluetoothDevice ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.BluetoothDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}BluetoothDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1760737)
        
        

        //--TRIMMABLE-BOUNDARY-START(1039841)
        $asm.$cls(`$lOHy.LCFCBBM.BLEFlagRecord`, ($self) => class BLEFlagRecord extends $.$lOHy.LCFCBBM.BLERecord
        {
            //--TRIMMABLE-BOUNDARY-START(12885941729)
            /*byte*/ Flags = 0;
            //--TRIMMABLE-BOUNDARY-END(12885941729)
            
            //--TRIMMABLE-BOUNDARY-START(8590974433)
            $ctor$2(/*BLEPacketType*/ packetType, /*byte*/ flags)
            {
                super.$ctor$1(packetType);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590974433);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Flags = flags;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590974433)
            
            static $h = 1039841;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lOHy.LCFCBBM.BLERecord; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885941729),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475876321,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065810913,
        "f": 83886082
      },
      "n": "Flags",
      "d": 1039841,
      "h": 12885941729,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885941729)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590974433),
    {
      "p": [
        {
          "n": "packetType",
          "p": 1301985
        },
        {
          "n": "flags",
          "p": 393217
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1039841,
      "h": 8590974433,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590974433)
  ],
  "h": 1039841
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEFlagRecord`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEFlagRecord`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1039841)
        
        

        //--TRIMMABLE-BOUNDARY-START(1105377)
        $asm.$cls(`$lOHy.LCFCBBM.BLEGenericRecord`, ($self) => class BLEGenericRecord extends $.$lOHy.LCFCBBM.BLERecord
        {
            //--TRIMMABLE-BOUNDARY-START(21475941857)
            /*byte[]*/ RawData = null;
            //--TRIMMABLE-BOUNDARY-END(21475941857)
            
            //--TRIMMABLE-BOUNDARY-START(8591039969)
            $ctor$2(/*BLEPacketType*/ packetType, /*byte[]*/ data)
            {
                super.$ctor$1(packetType);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591039969);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.RawData = data;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591039969)
            
            static $h = 1105377;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lOHy.LCFCBBM.BLERecord; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475941857),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180974561,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065876449,
        "f": 83886082
      },
      "n": "RawData",
      "d": 1105377,
      "h": 21475941857,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475941857)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591039969),
    {
      "p": [
        {
          "n": "packetType",
          "p": 1301985
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1105377,
      "h": 8591039969,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591039969)
  ],
  "h": 1105377
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEGenericRecord`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEGenericRecord`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1105377)
        
        

        //--TRIMMABLE-BOUNDARY-START(1236449)
        $asm.$cls(`$lOHy.LCFCBBM.BLENameRecord`, ($self) => class BLENameRecord extends $.$lOHy.LCFCBBM.BLERecord
        {
            //--TRIMMABLE-BOUNDARY-START(8591171041)
            $ctor$2(/*BLEPacketType*/ packetType, /*byte[]*/ data)
            {
                super.$ctor$1(packetType);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591171041);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = $.$$.ST.Encoding.ASCII.GetString$1(data);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591171041)
            
            //--TRIMMABLE-BOUNDARY-START(21476072929)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(21476072929)
            
            static $h = 1236449;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lOHy.LCFCBBM.BLERecord; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476072929),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181105633,
        "f": 50331649
      },
      "n": "Name",
      "d": 1236449,
      "h": 21476072929,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476072929)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591171041),
    {
      "p": [
        {
          "n": "packetType",
          "p": 1301985
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1236449,
      "h": 8591171041,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591171041)
  ],
  "h": 1236449
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLENameRecord`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLENameRecord`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1236449)
        
        

        //--TRIMMABLE-BOUNDARY-START(581089)
        $asm.$cls(`$lOHy.LCFCBBM.BLEAdvertisementDataSection`, ($self) => class BLEAdvertisementDataSection extends $.$lOHy.LCFCBBM.BLERecord
        {
            //--TRIMMABLE-BOUNDARY-START(60130123233)
            /*ushort*/ Manufacturer = 0;
            //--TRIMMABLE-BOUNDARY-END(60130123233)
            
            //--TRIMMABLE-BOUNDARY-START(25770384865)
            /*byte[]?*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(25770384865)
            
            //--TRIMMABLE-BOUNDARY-START(30065352161)
            /*byte*/ DataType = 0;
            //--TRIMMABLE-BOUNDARY-END(30065352161)
            
            //--TRIMMABLE-BOUNDARY-START(17180450273)
            $ctor$2()
            {
                super.$ctor$1(22/*BLEPacketType.ServiceData*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180450273);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180450273)
            
            //--TRIMMABLE-BOUNDARY-START(21475417569)
            $ctor$3(/*BLEPacketType*/ packetType, /*byte[]*/ data)
            {
                super.$ctor$1(packetType);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475417569);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Manufacturer = $.$$.S.BitConverter.ToUInt16(data, 0);
                    this.Data = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [data.length], null);
                    $.$$.S.Buffer.BlockCopy(data, 0, this.Data, 0, this.Data.length);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475417569)
            
            //--TRIMMABLE-BOUNDARY-START(17180450273)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180450273)
            
            static $h = 581089;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lOHy.LCFCBBM.BLERecord; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130123233),
    {
      "p": 589825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835155937,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899927009,
        "f": 83886082
      },
      "n": "Manufacturer",
      "d": 581089,
      "h": 60130123233,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130123233),
//--TRIMMABLE-BOUNDARY-START(25770384865),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655286753,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720057825,
        "f": 83886081
      },
      "n": "Data",
      "d": 581089,
      "h": 25770384865,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770384865),
//--TRIMMABLE-BOUNDARY-START(30065352161),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245221345,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309992417,
        "f": 83886081
      },
      "n": "DataType",
      "d": 581089,
      "h": 30065352161,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065352161)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180450273),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 581089,
      "h": 17180450273,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180450273),
//--TRIMMABLE-BOUNDARY-START(21475417569),
    {
      "p": [
        {
          "n": "packetType",
          "p": 1301985
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 581089,
      "h": 21475417569,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475417569)
  ],
  "h": 581089
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEAdvertisementDataSection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEAdvertisementDataSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(581089)
        
        

        //--TRIMMABLE-BOUNDARY-START(1170913)
        $asm.$cls(`$lOHy.LCFCBBM.BLEManufacturerData`, ($self) => class BLEManufacturerData extends $.$lOHy.LCFCBBM.BLERecord
        {
            //--TRIMMABLE-BOUNDARY-START(21476007393)
            /*ushort*/ CompanyId = 0;
            //--TRIMMABLE-BOUNDARY-END(21476007393)
            
            //--TRIMMABLE-BOUNDARY-START(25770974689)
            /*byte[]?*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(25770974689)
            
            //--TRIMMABLE-BOUNDARY-START(17181040097)
            $ctor$3(/*BLEPacketType*/ packetType, /*byte[]*/ data)
            {
                super.$ctor$1(packetType);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181040097);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CompanyId = $.$$.S.BitConverter.ToUInt16(data, 0);
                    this.Data = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [((data.length - 2) | 0)], null);
                    $.$$.S.Buffer.BlockCopy(data, 2, this.Data, 0, this.Data.length);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181040097)
            
            //--TRIMMABLE-BOUNDARY-START(12886072801)
            $ctor$2()
            {
                super.$ctor$1(255/*BLEPacketType.ManufacturerData*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886072801);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886072801)
            
            //--TRIMMABLE-BOUNDARY-START(12886072801)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886072801)
            
            static $h = 1170913;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lOHy.LCFCBBM.BLERecord; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476007393),
    {
      "p": 589825,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360909281,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540778465,
        "f": 83886081
      },
      "n": "CompanyId",
      "d": 1170913,
      "h": 21476007393,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476007393),
//--TRIMMABLE-BOUNDARY-START(25770974689),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950843873,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130713057,
        "f": 83886081
      },
      "n": "Data",
      "d": 1170913,
      "h": 25770974689,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770974689)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181040097),
    {
      "p": [
        {
          "n": "packetType",
          "p": 1301985
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1170913,
      "h": 17181040097,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181040097),
//--TRIMMABLE-BOUNDARY-START(12886072801),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1170913,
      "h": 12886072801,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886072801)
  ],
  "h": 1170913
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEManufacturerData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEManufacturerData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1170913)
        
        

        //--TRIMMABLE-BOUNDARY-START(777697)
        $asm.$str(`$lOHy.LCFCBBM.BLEAdvertisementType`, ($self) => class BLEAdvertisementType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static ConnectableUndirected = 0;
            static ConnectableDirected = 1;
            static ScannableUndirected = 2;
            static NonConnectableUndirected = 3;
            static ScanResponse = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(777697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ConnectableUndirected": 0n,
                    "ConnectableDirected": 1n,
                    "ScannableUndirected": 2n,
                    "NonConnectableUndirected": 3n,
                    "ScanResponse": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295744993)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295744993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295744993)
            
            //--TRIMMABLE-BOUNDARY-START(4295744993)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295744993)
            
            static $h = 777697;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885679585),
    {
      "t": 777697,
      "n": "ConnectableUndirected",
      "d": 777697,
      "h": 12885679585,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885679585),
//--TRIMMABLE-BOUNDARY-START(8590712289),
    {
      "t": 777697,
      "n": "ConnectableDirected",
      "d": 777697,
      "h": 8590712289,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590712289),
//--TRIMMABLE-BOUNDARY-START(21475614177),
    {
      "t": 777697,
      "n": "ScannableUndirected",
      "d": 777697,
      "h": 21475614177,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475614177),
//--TRIMMABLE-BOUNDARY-START(17180646881),
    {
      "t": 777697,
      "n": "NonConnectableUndirected",
      "d": 777697,
      "h": 17180646881,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180646881),
//--TRIMMABLE-BOUNDARY-START(25770581473),
    {
      "t": 777697,
      "n": "ScanResponse",
      "d": 777697,
      "h": 25770581473,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770581473)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295744993),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 777697,
      "h": 4295744993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295744993)
  ],
  "h": 777697
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEAdvertisementType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEAdvertisementType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(777697)
        
        

        //--TRIMMABLE-BOUNDARY-START(450017)
        $asm.$str(`$lOHy.LCFCBBM.BeaconTypeEnum`, ($self) => class BeaconTypeEnum extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Unknown = 0;
            static Eddystone = 1;
            static iBeacon = 2;
            static iSmartBeacon = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Eddystone": 1n,
                    "iBeacon": 2n,
                    "iSmartBeacon": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295417313)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295417313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295417313)
            
            //--TRIMMABLE-BOUNDARY-START(4295417313)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295417313)
            
            static $h = 450017;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475286497),
    {
      "t": 450017,
      "n": "Unknown",
      "d": 450017,
      "h": 21475286497,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475286497),
//--TRIMMABLE-BOUNDARY-START(8590384609),
    {
      "t": 450017,
      "n": "Eddystone",
      "d": 450017,
      "h": 8590384609,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590384609),
//--TRIMMABLE-BOUNDARY-START(12885351905),
    {
      "t": 450017,
      "n": "iBeacon",
      "d": 450017,
      "h": 12885351905,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885351905),
//--TRIMMABLE-BOUNDARY-START(17180319201),
    {
      "t": 450017,
      "n": "iSmartBeacon",
      "d": 450017,
      "h": 17180319201,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180319201)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295417313),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 450017,
      "h": 4295417313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295417313)
  ],
  "h": 450017
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BeaconTypeEnum`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BeaconTypeEnum`; }
        });
        //--TRIMMABLE-BOUNDARY-END(450017)
        
        

        //--TRIMMABLE-BOUNDARY-START(908769)
        $asm.$str(`$lOHy.LCFCBBM.BLEAdvertisementWatcherStatusCodes`, ($self) => class BLEAdvertisementWatcherStatusCodes extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Created = 0;
            static Started = 1;
            static Stopping = 2;
            static Stopped = 3;
            static Aborted = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(908769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Created": 0n,
                    "Started": 1n,
                    "Stopping": 2n,
                    "Stopped": 3n,
                    "Aborted": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295876065)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295876065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295876065)
            
            //--TRIMMABLE-BOUNDARY-START(4295876065)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295876065)
            
            static $h = 908769;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885810657),
    {
      "t": 908769,
      "n": "Created",
      "d": 908769,
      "h": 12885810657,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885810657),
//--TRIMMABLE-BOUNDARY-START(17180777953),
    {
      "t": 908769,
      "n": "Started",
      "d": 908769,
      "h": 17180777953,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180777953),
//--TRIMMABLE-BOUNDARY-START(25770712545),
    {
      "t": 908769,
      "n": "Stopping",
      "d": 908769,
      "h": 25770712545,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770712545),
//--TRIMMABLE-BOUNDARY-START(21475745249),
    {
      "t": 908769,
      "n": "Stopped",
      "d": 908769,
      "h": 21475745249,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475745249),
//--TRIMMABLE-BOUNDARY-START(8590843361),
    {
      "t": 908769,
      "n": "Aborted",
      "d": 908769,
      "h": 8590843361,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590843361)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295876065),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 908769,
      "h": 4295876065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295876065)
  ],
  "h": 908769
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEAdvertisementWatcherStatusCodes`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEAdvertisementWatcherStatusCodes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(908769)
        
        

        //--TRIMMABLE-BOUNDARY-START(1629665)
        $asm.$str(`$lOHy.LCFCBBM.BTMember`, ($self) => class BTMember extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Estimote = 65178;
            static GoogleEddystone = 65194;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1629665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Estimote": 65178n,
                    "GoogleEddystone": 65194n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296596961)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296596961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296596961)
            
            //--TRIMMABLE-BOUNDARY-START(4296596961)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296596961)
            
            static $h = 1629665;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591564257),
    {
      "t": 1629665,
      "n": "Estimote",
      "d": 1629665,
      "h": 8591564257,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591564257),
//--TRIMMABLE-BOUNDARY-START(12886531553),
    {
      "t": 1629665,
      "n": "GoogleEddystone",
      "d": 1629665,
      "h": 12886531553,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886531553)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296596961),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1629665,
      "h": 4296596961,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296596961)
  ],
  "h": 1629665
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BTMember`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BTMember`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1629665)
        
        

        //--TRIMMABLE-BOUNDARY-START(1301985)
        $asm.$str(`$lOHy.LCFCBBM.BLEPacketType`, ($self) => class BLEPacketType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Invalid = 0;
            static Flags = 1;
            static LocalName = 9;
            static UUID16List = 3;
            static ServiceData = 22;
            static ManufacturerData = 255;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1301985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Invalid": 0n,
                    "Flags": 1n,
                    "LocalName": 9n,
                    "UUID16List": 3n,
                    "ServiceData": 22n,
                    "ManufacturerData": 255n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296269281)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296269281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296269281)
            
            //--TRIMMABLE-BOUNDARY-START(4296269281)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296269281)
            
            static $h = 1301985;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886203873),
    {
      "t": 1301985,
      "n": "Invalid",
      "d": 1301985,
      "h": 12886203873,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886203873),
//--TRIMMABLE-BOUNDARY-START(8591236577),
    {
      "t": 1301985,
      "n": "Flags",
      "d": 1301985,
      "h": 8591236577,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591236577),
//--TRIMMABLE-BOUNDARY-START(17181171169),
    {
      "t": 1301985,
      "n": "LocalName",
      "d": 1301985,
      "h": 17181171169,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181171169),
//--TRIMMABLE-BOUNDARY-START(30066073057),
    {
      "t": 1301985,
      "n": "UUID16List",
      "d": 1301985,
      "h": 30066073057,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066073057),
//--TRIMMABLE-BOUNDARY-START(25771105761),
    {
      "t": 1301985,
      "n": "ServiceData",
      "d": 1301985,
      "h": 25771105761,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771105761),
//--TRIMMABLE-BOUNDARY-START(21476138465),
    {
      "t": 1301985,
      "n": "ManufacturerData",
      "d": 1301985,
      "h": 21476138465,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476138465)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296269281),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1301985,
      "h": 4296269281,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296269281)
  ],
  "h": 1301985
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEPacketType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEPacketType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1301985)
        
        

        //--TRIMMABLE-BOUNDARY-START(712161)
        $asm.$cls(`$lOHy.LCFCBBM.BLEAdvertisementPacketArgs`, ($self) => class BLEAdvertisementPacketArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(12885614049)
            /*BLEAdvertisementPacket*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(12885614049)
            
            //--TRIMMABLE-BOUNDARY-START(8590646753)
            $ctor$2(/*BLEAdvertisementPacket*/ data)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590646753);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Data = data;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590646753)
            
            static $h = 712161;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885614049),
    {
      "p": 646625,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475548641,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065483233,
        "f": 83886082
      },
      "n": "Data",
      "d": 712161,
      "h": 12885614049,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885614049)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590646753),
    {
      "p": [
        {
          "n": "data",
          "p": 646625
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 712161,
      "h": 8590646753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590646753)
  ],
  "h": 712161
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Bluetooth.Beacon.Models.BLEAdvertisementPacketArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Bluetooth${separator}Beacon${separator}Models${separator}BLEAdvertisementPacketArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(712161)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Connection"));
})();
//--TRIMMABLE-BOUNDARY-END(56801)
