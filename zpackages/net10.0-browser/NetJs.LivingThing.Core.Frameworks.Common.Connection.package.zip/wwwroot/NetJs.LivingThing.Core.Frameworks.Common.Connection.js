
//--TRIMMABLE-BOUNDARY-START(61102)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt, $fXpo, $uvJL) {
    "use strict";
    let _;
    let $TQqgBa;
    let $xlcUti;
    let $tGrSai;
    let $GfMzKg;
    let $LsOJLb;
    let $KigNGa;
    let $RanBZk;
    let $wiAwqb;
    let $QwNtbc;
    let $mmZXLc;
    let $RsVRmk;
    let $hkfwDk;
    let $Xcplzi;
    let $VTwSsh;
    let $gctltb;
    let $ZXvQUd;
    let $Ladbua;
    let $xGEXve;
    let $PQGhTj;
    let $pmelrg;
    let $LMDzOi;
    let $RPIVwi;
    let $HKioEg;
    let $aZLirh;
    let $OPyuqj;
    let $bCeWob;
    let $snHnfl;
    let $gTTwBi;
    let $mARari;
    let $EZcQqa;
    let $bZIxel;
    let $WUonik;
    let $waSQnd;
    let $CNHgDj;
    let $Rznofd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Connection", 
    {
  "h": 61102,
  "f": "LivingThing.Core.Frameworks.Common.Connection",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Connection",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Connection",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1633966)
        $asm.$cls(`$KuVO.LCFCC.IConnectionContext`, ($self) => class IConnectionContext
        {
            static $h = 1633966;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(128850652846),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016077998,
        "f": 50331905
      },
      "n": "Id",
      "o": "LCFCC$IConnectionContext$Id",
      "d": 1633966,
      "h": 128850652846,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(128850652846),
//--TRIMMABLE-BOUNDARY-START(146030522030),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375816366,
        "f": 50331905
      },
      "n": "Name",
      "o": "LCFCC$IConnectionContext$Name",
      "d": 1633966,
      "h": 146030522030,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(146030522030),
//--TRIMMABLE-BOUNDARY-START(17181503150),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836208814,
        "f": 50331905
      },
      "n": "FamilyName",
      "o": "LCFCC$IConnectionContext$FamilyName",
      "d": 1633966,
      "h": 17181503150,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17181503150),
//--TRIMMABLE-BOUNDARY-START(133145620142),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606012590,
        "f": 50331905
      },
      "n": "IP",
      "o": "LCFCC$IConnectionContext$IP",
      "d": 1633966,
      "h": 133145620142,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(133145620142),
//--TRIMMABLE-BOUNDARY-START(150325489326),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965750958,
        "f": 50331905
      },
      "n": "Port",
      "o": "LCFCC$IConnectionContext$Port",
      "d": 1633966,
      "h": 150325489326,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(150325489326),
//--TRIMMABLE-BOUNDARY-START(137440587438),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195947182,
        "f": 50331905
      },
      "n": "MaxConnections",
      "o": "LCFCC$IConnectionContext$MaxConnections",
      "d": 1633966,
      "h": 137440587438,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(137440587438),
//--TRIMMABLE-BOUNDARY-START(141735554734),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785881774,
        "f": 50331905
      },
      "n": "MessageDelimiter",
      "o": "LCFCC$IConnectionContext$MessageDelimiter",
      "d": 1633966,
      "h": 141735554734,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(141735554734),
//--TRIMMABLE-BOUNDARY-START(4296601262),
    {
      "p": 23199774,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066405038,
        "f": 50331905
      },
      "n": "Algorithm",
      "o": "LCFCC$IConnectionContext$Algorithm",
      "d": 1633966,
      "h": 4296601262,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296601262),
//--TRIMMABLE-BOUNDARY-START(12886535854),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246274222,
        "f": 50331905
      },
      "n": "EncryptionKey",
      "o": "LCFCC$IConnectionContext$EncryptionKey",
      "d": 1633966,
      "h": 12886535854,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886535854),
//--TRIMMABLE-BOUNDARY-START(8591568558),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656339630,
        "f": 50331905
      },
      "n": "BufferSize",
      "o": "LCFCC$IConnectionContext$BufferSize",
      "d": 1633966,
      "h": 8591568558,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591568558),
//--TRIMMABLE-BOUNDARY-START(154620456622),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555685550,
        "f": 50331905
      },
      "n": "ReceiveFrequencyLimit",
      "o": "LCFCC$IConnectionContext$ReceiveFrequencyLimit",
      "d": 1633966,
      "h": 154620456622,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(154620456622),
//--TRIMMABLE-BOUNDARY-START(21476470446),
    {
      "p": 847534,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426143406,
        "f": 50331905
      },
      "n": "Flags",
      "o": "LCFCC$IConnectionContext$Flags",
      "d": 1633966,
      "h": 21476470446,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21476470446)
  ],
  "h": 1633966
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IConnectionContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IConnectionContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1633966)
        
        

        //--TRIMMABLE-BOUNDARY-START(1699502)
        $asm.$cls(`$KuVO.LCFCC.IConnectionContextProvider`, ($self) => class IConnectionContextProvider
        {
            static $h = 1699502;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296666798),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionContext)).$h,
      "n": "GetContextsAsync",
      "o": "LCFCC$IConnectionContextProvider$GetContextsAsync",
      "d": 1699502,
      "h": 4296666798,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296666798)
  ],
  "h": 1699502
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IConnectionContextProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IConnectionContextProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1699502)
        
        

        //--TRIMMABLE-BOUNDARY-START(1961646)
        $asm.$cls(`$KuVO.LCFCC.IConnectionMessage`, ($self) => class IConnectionMessage
        {
            static $h = 1961646;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296928942),
    {
      "p": 1568430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476798126,
        "f": 50331905
      },
      "n": "Client",
      "o": "LCFCC$IConnectionMessage$Client",
      "d": 1961646,
      "h": 4296928942,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296928942),
//--TRIMMABLE-BOUNDARY-START(12886863534),
    {
      "p": 2289326,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656667310,
        "f": 50331905
      },
      "n": "Direction",
      "o": "LCFCC$IConnectionMessage$Direction",
      "d": 1961646,
      "h": 12886863534,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886863534),
//--TRIMMABLE-BOUNDARY-START(51541569198),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246601902,
        "f": 50331905
      },
      "n": "Id",
      "o": "LCFCC$IConnectionMessage$Id",
      "d": 1961646,
      "h": 51541569198,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51541569198),
//--TRIMMABLE-BOUNDARY-START(8591896238),
    {
      "p": $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066732718,
        "f": 50331905
      },
      "n": "Data",
      "o": "LCFCC$IConnectionMessage$Data",
      "d": 1961646,
      "h": 8591896238,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591896238)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55836536494),
    {
      "r": 65537,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Reply",
      "o": "LCFCC$IConnectionMessage$Reply",
      "d": 1961646,
      "h": 55836536494,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55836536494)
  ],
  "h": 1961646
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IConnectionMessage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1961646)
        
        

        //--TRIMMABLE-BOUNDARY-START(1896110)
        $asm.$cls(`$KuVO.LCFCC.IConnectionManager`, ($self) => class IConnectionManager
        {
            //--TRIMMABLE-BOUNDARY-START(51541503662)
            //--TRIMMABLE-BOUNDARY-END(51541503662)
            
            static $h = 1896110;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066667182),
    {
      "p": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181765294,
        "f": 50331905
      },
      "n": "Interfaces",
      "o": "LCFCC$IConnectionManager$Interfaces",
      "d": 1896110,
      "h": 30066667182,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30066667182),
//--TRIMMABLE-BOUNDARY-START(51541503662),
    {
      "p": 1830574,
      "i": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771699886,
        "f": 50331905
      },
      "n": "Item",
      "o": "LCFCC$IConnectionManager$Item",
      "d": 1896110,
      "h": 51541503662,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51541503662)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296863406),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "ConnectTo",
      "o": "LCFCC$IConnectionManager$ConnectTo",
      "d": 1896110,
      "h": 4296863406,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296863406),
//--TRIMMABLE-BOUNDARY-START(38656601774),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "endpoint",
          "p": 1765038
        }
      ],
      "n": "StartServer",
      "o": "LCFCC$IConnectionManager$StartServer$1",
      "d": 1896110,
      "h": 38656601774,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38656601774),
//--TRIMMABLE-BOUNDARY-START(34361634478),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "factory",
          "p": 650926
        }
      ],
      "n": "StartServer",
      "o": "LCFCC$IConnectionManager$StartServer",
      "d": 1896110,
      "h": 34361634478,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34361634478),
//--TRIMMABLE-BOUNDARY-START(42951569070),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "g": [
        "TConnectionEndPoint"
      ],
      "n": "StartServer",
      "o": "LCFCC$IConnectionManager$StartServer$2",
      "d": 1896110,
      "h": 42951569070,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(42951569070),
//--TRIMMABLE-BOUNDARY-START(8591830702),
    {
      "r": 65537,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "Disconnect",
      "o": "LCFCC$IConnectionManager$Disconnect",
      "d": 1896110,
      "h": 8591830702,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591830702),
//--TRIMMABLE-BOUNDARY-START(47246536366),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "n": "Stop",
      "o": "LCFCC$IConnectionManager$Stop",
      "d": 1896110,
      "h": 47246536366,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47246536366)
  ],
  "h": 1896110
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IConnectionManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IConnectionManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1896110)
        
        

        //--TRIMMABLE-BOUNDARY-START(1568430)
        $asm.$cls(`$KuVO.LCFCC.IConnectionClient`, ($self) => class IConnectionClient
        {
            static $h = 1568430;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296535726),
    {
      "p": 80805889,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886470318,
        "f": 50331905
      },
      "n": "Exception",
      "o": "LCFCC$IConnectionClient$Exception",
      "d": 1568430,
      "h": 4296535726,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296535726),
//--TRIMMABLE-BOUNDARY-START(111670718126),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656274094,
        "f": 50331905
      },
      "n": "IsConnected",
      "o": "LCFCC$IConnectionClient$IsConnected",
      "d": 1568430,
      "h": 111670718126,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(111670718126),
//--TRIMMABLE-BOUNDARY-START(128850587310),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016012462,
        "f": 50331905
      },
      "n": "Name",
      "o": "LCFCC$IConnectionClient$Name",
      "d": 1568430,
      "h": 128850587310,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(128850587310),
//--TRIMMABLE-BOUNDARY-START(103080783534),
    {
      "p": 323246,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476404910,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325423790,
        "f": 83886337
      },
      "n": "Id",
      "o": "LCFCC$IConnectionClient$Id",
      "d": 1568430,
      "h": 103080783534,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103080783534),
//--TRIMMABLE-BOUNDARY-START(115965685422),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246208686,
        "f": 50331905
      },
      "n": "LastReceivedTime",
      "o": "LCFCC$IConnectionClient$LastReceivedTime",
      "d": 1568430,
      "h": 115965685422,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(115965685422),
//--TRIMMABLE-BOUNDARY-START(120260652718),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836143278,
        "f": 50331905
      },
      "n": "LastWriteTime",
      "o": "LCFCC$IConnectionClient$LastWriteTime",
      "d": 1568430,
      "h": 120260652718,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(120260652718),
//--TRIMMABLE-BOUNDARY-START(133145554606),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605947054,
        "f": 50331905
      },
      "n": "PacketCount",
      "o": "LCFCC$IConnectionClient$PacketCount",
      "d": 1568430,
      "h": 133145554606,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(133145554606),
//--TRIMMABLE-BOUNDARY-START(107375750830),
    {
      "p": 1830574,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066339502,
        "f": 50331905
      },
      "n": "Interface",
      "o": "LCFCC$IConnectionClient$Interface",
      "d": 1568430,
      "h": 107375750830,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(107375750830),
//--TRIMMABLE-BOUNDARY-START(124555620014),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426077870,
        "f": 50331905
      },
      "n": "LocalEndPoint",
      "o": "LCFCC$IConnectionClient$LocalEndPoint",
      "d": 1568430,
      "h": 124555620014,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(124555620014),
//--TRIMMABLE-BOUNDARY-START(141735489198),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785816238,
        "f": 50331905
      },
      "n": "RemoteEndPoint",
      "o": "LCFCC$IConnectionClient$RemoteEndPoint",
      "d": 1568430,
      "h": 141735489198,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(141735489198),
//--TRIMMABLE-BOUNDARY-START(137440521902),
    {
      "p": 1568430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195881646,
        "f": 50331905
      },
      "n": "Parent",
      "o": "LCFCC$IConnectionClient$Parent",
      "d": 1568430,
      "h": 137440521902,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(137440521902)
  ],
  "h": 1568430
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IWorkspace ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IConnectionClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IConnectionClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1568430)
        
        

        //--TRIMMABLE-BOUNDARY-START(2092718)
        $asm.$cls(`$KuVO.LCFCC.IRemoteClientConnectionRemoteService`, ($self) => class IRemoteClientConnectionRemoteService
        {
            static $h = 2092718;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592027310),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "clientId",
          "p": 1310721
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "messageId",
          "p": 1310721
        },
        {
          "n": "withPipeline",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Write",
      "o": "LCFCC$IRemoteClientConnectionRemoteService$Write",
      "d": 2092718,
      "h": 8592027310,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8592027310),
//--TRIMMABLE-BOUNDARY-START(12886994606),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$typeArray($.$$.S.Byte))).$h,
      "p": [
        {
          "n": "clientId",
          "p": 1310721
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "messageId",
          "p": 1310721
        },
        {
          "n": "timeOut",
          "p": 186646529
        }
      ],
      "n": "WriteRead",
      "o": "LCFCC$IRemoteClientConnectionRemoteService$WriteRead",
      "d": 2092718,
      "h": 12886994606,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886994606),
//--TRIMMABLE-BOUNDARY-START(4297060014),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Broadcast",
      "o": "LCFCC$IRemoteClientConnectionRemoteService$Broadcast",
      "d": 2092718,
      "h": 4297060014,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4297060014)
  ],
  "h": 2092718,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IRemoteClientConnectionRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IRemoteClientConnectionRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2092718)
        
        

        //--TRIMMABLE-BOUNDARY-START(1830574)
        $asm.$cls(`$KuVO.LCFCC.IConnectionInterface`, ($self) => class IConnectionInterface
        {
            //--TRIMMABLE-BOUNDARY-START(128850849454)
            //--TRIMMABLE-BOUNDARY-END(128850849454)
            
            static $h = 1830574;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90196143790),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951503534,
        "f": 50331905
      },
      "n": "Id",
      "o": "LCFCC$IConnectionInterface$Id",
      "d": 1830574,
      "h": 90196143790,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90196143790),
//--TRIMMABLE-BOUNDARY-START(107376012974),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901176494,
        "f": 50331905
      },
      "n": "Name",
      "o": "LCFCC$IConnectionInterface$Name",
      "d": 1830574,
      "h": 107376012974,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(107376012974),
//--TRIMMABLE-BOUNDARY-START(98786078382),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721307310,
        "f": 50331905
      },
      "n": "LocalAddress",
      "o": "LCFCC$IConnectionInterface$LocalAddress",
      "d": 1830574,
      "h": 98786078382,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98786078382),
//--TRIMMABLE-BOUNDARY-START(12886732462),
    {
      "p": 1633966,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361568942,
        "f": 50331905
      },
      "n": "Context",
      "o": "LCFCC$IConnectionInterface$Context",
      "d": 1830574,
      "h": 12886732462,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886732462),
//--TRIMMABLE-BOUNDARY-START(103081045678),
    {
      "p": 1896110,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311241902,
        "f": 50331905
      },
      "n": "Manager",
      "o": "LCFCC$IConnectionInterface$Manager",
      "d": 1830574,
      "h": 103081045678,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103081045678),
//--TRIMMABLE-BOUNDARY-START(94491111086),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541438126,
        "f": 50331905
      },
      "n": "IsRunning",
      "o": "LCFCC$IConnectionInterface$IsRunning",
      "d": 1830574,
      "h": 94491111086,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94491111086),
//--TRIMMABLE-BOUNDARY-START(8591765166),
    {
      "p": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771634350,
        "f": 50331905
      },
      "n": "Clients",
      "o": "LCFCC$IConnectionInterface$Clients",
      "d": 1830574,
      "h": 8591765166,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591765166),
//--TRIMMABLE-BOUNDARY-START(128850849454),
    {
      "p": 1568430,
      "i": [
        {
          "n": "clientId",
          "p": 323246
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131372718,
        "f": 50331905
      },
      "n": "Item",
      "o": "LCFCC$IConnectionInterface$Item",
      "d": 1830574,
      "h": 128850849454,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(128850849454)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120260914862),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "n": "StartAsync",
      "o": "LCFCC$IConnectionInterface$StartAsync",
      "d": 1830574,
      "h": 120260914862,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(120260914862),
//--TRIMMABLE-BOUNDARY-START(17181699758),
    {
      "r": 65537,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "Disconnect",
      "o": "LCFCC$IConnectionInterface$Disconnect",
      "d": 1830574,
      "h": 17181699758,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181699758),
//--TRIMMABLE-BOUNDARY-START(124555882158),
    {
      "r": 65537,
      "n": "Stop",
      "o": "LCFCC$IConnectionInterface$Stop",
      "d": 1830574,
      "h": 124555882158,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(124555882158),
//--TRIMMABLE-BOUNDARY-START(133145816750),
    {
      "r": 178454529,
      "p": [
        {
          "n": "clientId",
          "p": $.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).$h
        },
        {
          "n": "data",
          "p": 1961646
        },
        {
          "n": "withPipeline",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Write",
      "o": "LCFCC$IConnectionInterface$Write",
      "d": 1830574,
      "h": 133145816750,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(133145816750),
//--TRIMMABLE-BOUNDARY-START(111670980270),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "p": [
        {
          "n": "clientId",
          "p": $.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).$h
        },
        {
          "n": "timeOut",
          "p": 186646529
        }
      ],
      "n": "Read",
      "o": "LCFCC$IConnectionInterface$Read",
      "d": 1830574,
      "h": 111670980270,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(111670980270),
//--TRIMMABLE-BOUNDARY-START(137440784046),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "data",
          "p": 1961646
        },
        {
          "n": "timeOut",
          "p": 186646529
        }
      ],
      "n": "WriteRead",
      "o": "LCFCC$IConnectionInterface$WriteRead",
      "d": 1830574,
      "h": 137440784046,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(137440784046),
//--TRIMMABLE-BOUNDARY-START(4296797870),
    {
      "r": 65537,
      "p": [
        {
          "n": "data",
          "p": 1961646
        }
      ],
      "n": "Broadcast",
      "o": "LCFCC$IConnectionInterface$Broadcast",
      "d": 1830574,
      "h": 4296797870,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296797870),
//--TRIMMABLE-BOUNDARY-START(115965947566),
    {
      "r": 178454529,
      "p": [
        {
          "n": "router",
          "p": 1568430
        },
        {
          "n": "deviceId",
          "p": 323246
        },
        {
          "n": "data",
          "p": 1961646
        },
        {
          "n": "encodeSendData",
          "p": $.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionMessage, $.$KuVO.LCFCC.IConnectionMessage).$h
        }
      ],
      "n": "RouteMessageToDevice",
      "o": "LCFCC$IConnectionInterface$RouteMessageToDevice",
      "d": 1830574,
      "h": 115965947566,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(115965947566)
  ],
  "h": 1830574
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IConnectionInterface`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1830574)
        
        

        //--TRIMMABLE-BOUNDARY-START(2223790)
        $asm.$cls(`$KuVO.LCFCC.IServerConnectionManager`, ($self) => class IServerConnectionManager
        {
            static $h = 2223790;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2223790
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionManager ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IServerConnectionManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IServerConnectionManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2223790)
        
        

        //--TRIMMABLE-BOUNDARY-START(1502894)
        $asm.$cls(`$KuVO.LCFCC.IClientConnectionManager`, ($self) => class IClientConnectionManager
        {
            static $h = 1502894;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1502894
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionManager ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IClientConnectionManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IClientConnectionManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1502894)
        
        

        //--TRIMMABLE-BOUNDARY-START(1437358)
        $asm.$cls(`$KuVO.LCFCC.IBluetoothConnectionInterface`, ($self) => class IBluetoothConnectionInterface
        {
            static $h = 1437358;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296404654),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "deviceId",
          "p": 1310721
        },
        {
          "n": "keepConnect",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "base64DataEncoding",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "Connect",
      "o": "LCFCC$IBluetoothConnectionInterface$Connect",
      "d": 1437358,
      "h": 4296404654,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296404654)
  ],
  "h": 1437358
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionInterface, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IBluetoothConnectionInterface`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IBluetoothConnectionInterface`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1437358)
        
        

        //--TRIMMABLE-BOUNDARY-START(2027182)
        $asm.$cls(`$KuVO.LCFCC.IHttpServerConnectionInterface`, ($self) => class IHttpServerConnectionInterface
        {
            static $h = 2027182;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296994478),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 323246
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "messageId",
          "p": 1310721
        }
      ],
      "n": "OnHttpRequestReceived",
      "o": "LCFCC$IHttpServerConnectionInterface$OnHttpRequestReceived",
      "d": 2027182,
      "h": 4296994478,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296994478)
  ],
  "h": 2027182
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionInterface, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IHttpServerConnectionInterface`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IHttpServerConnectionInterface`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2027182)
        
        

        //--TRIMMABLE-BOUNDARY-START(1765038)
        $asm.$cls(`$KuVO.LCFCC.IConnectionEndPoint`, ($self) => class IConnectionEndPoint
        {
            static $h = 1765038;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1765038
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionClient), $.$fXpo.LCFCP.IPipeline$$($.$KuVO.LCFCC.IConnectionMessage) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IConnectionEndPoint`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IConnectionEndPoint`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1765038)
        
        

        //--TRIMMABLE-BOUNDARY-START(126638)
        $asm.$cls(`$KuVO.LCFCC.BaseConnector`, ($self) => class BaseConnector extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885028526)
            /*string*/ static ServerToDeviceTopicIdentifier = null;
            //--TRIMMABLE-BOUNDARY-END(12885028526)
            
            //--TRIMMABLE-BOUNDARY-START(8590061230)
            /*string*/ static DeviceToServerTopicIdentifier = null;
            //--TRIMMABLE-BOUNDARY-END(8590061230)
            
            //--TRIMMABLE-BOUNDARY-START(4295093934)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295093934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295093934)
            
            //--TRIMMABLE-BOUNDARY-START(4295093934)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295093934)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885028526)
                    this.ServerToDeviceTopicIdentifier = "sd";
                    //--TRIMMABLE-BOUNDARY-END(12885028526)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590061230)
                    this.DeviceToServerTopicIdentifier = "ds";
                    //--TRIMMABLE-BOUNDARY-END(8590061230)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 126638;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885028526),
    {
      "t": 1310721,
      "n": "ServerToDeviceTopicIdentifier",
      "d": 126638,
      "h": 12885028526,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885028526),
//--TRIMMABLE-BOUNDARY-START(8590061230),
    {
      "t": 1310721,
      "n": "DeviceToServerTopicIdentifier",
      "d": 126638,
      "h": 8590061230,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590061230)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295093934),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 126638,
      "h": 4295093934,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295093934)
  ],
  "h": 126638
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.BaseConnector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}BaseConnector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(126638)
        
        

        //--TRIMMABLE-BOUNDARY-START(192174)
        $asm.$cls(`$KuVO.LCFCC.BaseConnector<>`, (TNativeClient) => $asm.$gt(`$KuVO.LCFCC.BaseConnector<>`, [TNativeClient], ($self) => class BaseConnector$$ extends $.$KuVO.LCFCC.BaseConnector
        {
            //--TRIMMABLE-BOUNDARY-START(68719668910)
            /*IConnectionEndPoint?*/ DirectEndPoint = null;
            //--TRIMMABLE-BOUNDARY-END(68719668910)
            
            //--TRIMMABLE-BOUNDARY-START(55834767022)
            /*IPipelineCollection<IConnectionClient>?*/ ConnectionPipelines = null;
            //--TRIMMABLE-BOUNDARY-END(55834767022)
            
            //--TRIMMABLE-BOUNDARY-START(236223393454)
            /*IPipelineCollection<IConnectionMessage>?*/ MessagePipelines = null;
            //--TRIMMABLE-BOUNDARY-END(236223393454)
            
            //--TRIMMABLE-BOUNDARY-START(231928426158)
            /*IConnectionManager*/ Manager = null;
            //--TRIMMABLE-BOUNDARY-END(231928426158)
            
            //--TRIMMABLE-BOUNDARY-START(227633458862)
            /*string?*/ $LocalAddress = null;
            /*string? */ get LocalAddress()
            {
                return this.$LocalAddress;
            }
             /*string? */ set LocalAddress(value)
            {
                this.$LocalAddress = value;
            }
            //--TRIMMABLE-BOUNDARY-END(227633458862)
            
            //--TRIMMABLE-BOUNDARY-START(38654897838)
            $ctor$4(/*IConnectionManager*/ manager)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654897838);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Manager = manager;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38654897838)
            
            //--TRIMMABLE-BOUNDARY-START(30064963246)
            $ctor$2(/*IConnectionManager*/ manager, /*IConnectionEndPoint?*/ endPoint)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064963246);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Manager = manager;
                    if (endPoint !== null)
                    {
                        this.DirectEndPoint = endPoint;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064963246)
            
            //--TRIMMABLE-BOUNDARY-START(34359930542)
            $ctor$3(/*IConnectionManager*/ manager, /*IPipelineCollection<IConnectionClient>?*/ connectionPipelineExecutor, /*IPipelineCollection<IConnectionMessage>?*/ messagePipelines)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359930542);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Manager = manager;
                    this.ConnectionPipelines = connectionPipelineExecutor;
                    this.MessagePipelines = messagePipelines;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359930542)
            
            //--TRIMMABLE-BOUNDARY-START(292057968302)
            /*void */ Subscribe(/*IConnectionEndPoint*/ endpoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292057968302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.MessagePipelines !== null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Cannot have both endpoint and pipeline at the same time");
                }
                if (this.DirectEndPoint !== null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("A subscription is already made");
                }
                this.DirectEndPoint = endpoint;
            }
            //--TRIMMABLE-BOUNDARY-END(292057968302)
            
            //--TRIMMABLE-BOUNDARY-START(223338491566)
            /*ConcurrentDictionary<ClientConnectionIdentity, ConnectionClient<TNativeClient>>*/ KeyedClients = null;
            //--TRIMMABLE-BOUNDARY-END(223338491566)
            
            //--TRIMMABLE-BOUNDARY-START(214748556974)
            /*string */ get Id()
            {
                return $.$$.S.Object.GetType.call(this).Name;
            }
            //--TRIMMABLE-BOUNDARY-END(214748556974)
            
            //--TRIMMABLE-BOUNDARY-START(240518360750)
            /*string */ get Name()
            {
                return $.$$.S.Object.GetType.call(this).Name;
            }
            //--TRIMMABLE-BOUNDARY-END(240518360750)
            
            //--TRIMMABLE-BOUNDARY-START(219043524270)
            /*bool */ get IsRunning()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(219043524270)
            
            //--TRIMMABLE-BOUNDARY-START(257698229934)
            /*bool */ get RunBackgroundCheckClientConnections()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(257698229934)
            
            //--TRIMMABLE-BOUNDARY-START(51539799726)
            /*IEnumerable<IConnectionClient> */ get Clients()
            {
                return $.$$.N.InterfaceVarianceStubHandler.Create(this.KeyedClients.Values, $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.ConnectionClient$$(TNativeClient)), $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionClient));
            }
            //--TRIMMABLE-BOUNDARY-END(51539799726)
            
            //--TRIMMABLE-BOUNDARY-START(90194505390)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(90194505390)
            
            //--TRIMMABLE-BOUNDARY-START(261993197230)
            /*void */ RunCheckClientConnections()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993197230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        while(!this.disposed)
                        {
                            let $t5, $r5;
                            try
                            {
                                let $i1 = 0;
                                let $arr1 = $.$sl.SL.Enumerable.ToArray($.$KuVO.LCFCC.ClientConnectionIdentity, this.KeyedClients.Keys);
                                while ($i1 < $arr1.length)
                                {
                                    let client = $arr1[$i1++];
                                    /*var*/ let context = this.KeyedClients.get_Item$1($.$clone(client));
                                    try
                                    {
                                        let $t2, $r2;
                                        ($t2 = this.Write$1($.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).op_Implicit$1(client), new $.$KuVO.LCFCC.ConnectionMessage().$ctor$1(this, context, 1/*MessageDirection.Out*/, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [1], null))), false).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                                        if ($.$$.S.DateTime.op_GreaterThan($.$$.S.DateTime.UtcNow, context.LastReceivedTime.AddMinutes(2)))
                                        {
                                            let $t3, $r3;
                                            ($t3 = this.DisposeClient($.$clone(client), null).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                            throw new $.$$.S.Exception().$ctor$1();
                                        }
                                    }
                                    catch(e)
                                    {
                                        $.$$.SCG.CollectionExtensions.Remove($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient), this.KeyedClients, $.$clone(client), $.$discardRef());
                                        context.Exception = e;
                                        context.IsConnected = false;
                                        if (this.DirectEndPoint !== null)
                                        {
                                            let $t4, $r4;
                                            ($t4 = this.DirectEndPoint.LCFCP$IPipeline$$$Invoke(context, new ($.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionClient))().$ctor(this,  (/*c*/ c) =>
                                            {
                                                return $.$$.STT.Task.CompletedTask;
                                            }, $pmelrg ??= {"r":178454529,"p":[{"n":"c","p":1568430}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                        }
                                    }
                                }
                            }
                            catch($e)
                            {
                            }
                            ($t5 = $.$$.STT.Task.Delay$1(30000).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        }
                    });
                }, $LMDzOi ??= {"r":178454529,"n":"","d":this.$h,"H":0,"h":0,"f":17829890}));
            }
            //--TRIMMABLE-BOUNDARY-END(261993197230)
            
            //--TRIMMABLE-BOUNDARY-START(296352935598)
            /*IConnectionClient?*/ get_Item$1(/*ClientConnectionIdentity*/ clientId)
            {
                /*var*/ let client;
                if (this.KeyedClients.TryGetValue($.$clone(clientId), $.$ref(() => client, ($v) => client = $v, $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient))))
                {
                    return client;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(296352935598)
            
            //--TRIMMABLE-BOUNDARY-START(64424701614)
            /*IConnectionContext?*/ Context = null;
            //--TRIMMABLE-BOUNDARY-END(64424701614)
            
            //--TRIMMABLE-BOUNDARY-START(283468033710)
            /*Task */ StartAsync(/*IConnectionContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468033710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Context = context;
                if (this.RunBackgroundCheckClientConnections)
                {
                    this.RunCheckClientConnections();
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(283468033710)
            
            //--TRIMMABLE-BOUNDARY-START(73014636206)
            /*void */ Disconnect(/*IConnectionClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014636206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = this.DisposeClient(client.LCFCC$IConnectionClient$Id, null);
                $.$$.SCG.CollectionExtensions.Remove($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient), this.KeyedClients, client.LCFCC$IConnectionClient$Id, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(73014636206)
            
            //--TRIMMABLE-BOUNDARY-START(85899538094)
            /*Task *//*async*/  DisposeClient(/*ClientConnectionIdentity*/ client, /*Exception?*/ e)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899538094);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ConnectionClient<TNativeClient>?*/ let context = null;
                    if (!this.KeyedClients.ContainsKey($.$clone(client)))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    context = this.KeyedClients.get_Item$1($.$clone(client));
                    $.$$.SCG.CollectionExtensions.Remove($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient), this.KeyedClients, $.$clone(client), $.$discardRef());
                    context.Exception = e;
                    context.IsConnected = false;
                    if (this.DirectEndPoint !== null)
                    {
                        let $t7, $r7;
                        ($t7 = this.DirectEndPoint.LCFCP$IPipeline$$$Invoke(context, new ($.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionClient))().$ctor(this,  (/*c*/ c) =>
                        {
                            return $.$$.STT.Task.CompletedTask;
                        }, $RPIVwi ??= {"r":178454529,"p":[{"n":"c","p":1568430}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    }
                    if (this.ConnectionPipelines !== null)
                    {
                        let $t8, $r8;
                        ($t8 = this.ConnectionPipelines.LCFCPC$IPipelineCollection$LivingThing$Core$Frameworks$Common$Connection$IConnectionClient$FeedAsync(context, null).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899538094)
            
            //--TRIMMABLE-BOUNDARY-START(201863655086)
            /*Task *//*async*/  HandleClientConnected(/*ClientConnectionIdentity*/ id, /*TNativeClient*/ nativeClient, /*IConnectionClient?*/ parentClient, /*ConnectionClient<TNativeClient>?*/ clientState)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201863655086);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.KeyedClients.TryAdd($.$clone(id), clientState ?? (() =>
                    {
                        //new $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient)()
                        const $t9 = $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient);
                        const $i9 = new $t9();
                        $i9.$ctor$3(this, nativeClient, parentClient);
                        $i9.Id = $.$clone(id);
                        $i9.IsConnected = true;
                        $i9.LocalEndPoint = this.Context.LCFCC$IConnectionContext$Name;
                        $i9.RemoteEndPoint = id.ToString();
                        return $i9;
                    })());
                    if (this.DirectEndPoint !== null)
                    {
                        let $t10, $r10;
                        ($t10 = this.DirectEndPoint.LCFCP$IPipeline$$$Invoke(this.KeyedClients.get_Item$1($.$clone(id)), new ($.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionClient))().$ctor(this,  (/*c*/ c) =>
                        {
                            return $.$$.STT.Task.CompletedTask;
                        }, $HKioEg ??= {"r":178454529,"p":[{"n":"c","p":1568430}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    }
                    if (this.ConnectionPipelines !== null)
                    {
                        let $t11, $r11;
                        ($t11 = this.ConnectionPipelines.LCFCPC$IPipelineCollection$LivingThing$Core$Frameworks$Common$Connection$IConnectionClient$FeedAsync(this.KeyedClients.get_Item$1($.$clone(id)), null).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201863655086)
            
            //--TRIMMABLE-BOUNDARY-START(197568687790)
            /*ConnectionClient<TNativeClient>? */ GetClientContext(/*ClientConnectionIdentity*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568687790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ConnectionClient<TNativeClient>?*/ let context = null;
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        if (!this.KeyedClients.ContainsKey($.$clone(id)))
                        {
                            return null;
                        }
                        context = this.KeyedClients.get_Item$1($.$clone(id));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
                return context;
            }
            //--TRIMMABLE-BOUNDARY-END(197568687790)
            
            //--TRIMMABLE-BOUNDARY-START(77309603502)
            /*Task *//*async*/  DispatchMessage(/*IConnectionMessage*/ message, /*ConnectionClient<TNativeClient>?*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309603502);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let _awaiter = new ($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String), $.$$.STT.TaskCompletionSource$$($.$KuVO.LCFCC.IConnectionMessage)))().$ctor$3(this.awaitingReceive);
                    if (context !== null && message.LCFCC$IConnectionMessage$Id !== null && _awaiter.TryGetValue(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(context.Id, message.LCFCC$IConnectionMessage$Id), $.$discardRef()))
                    {
                    }
                    if (this.DirectEndPoint !== null)
                    {
                        let $t12, $r12;
                        ($t12 = this.DirectEndPoint.LCFCP$IPipeline$$$Invoke(message, new ($.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionMessage))().$ctor(this,  (/*message*/ message) =>
                        {
                            //lock(this)
                            try
                            {
                                $.$$.ST$1.Monitor.Enter$1(this)
                                {
                                    if (context !== null)
                                    {
                                        /*var*/ let tcs;
                                        if (_awaiter.TryGetValue(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(context.Id, null), $.$ref(() => tcs, ($v) => tcs = $v, $.$$.STT.TaskCompletionSource$$($.$KuVO.LCFCC.IConnectionMessage))))
                                        {
                                            this.awaitingReceive.Remove$1(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(context.Id, null));
                                            tcs.SetResult(message);
                                        }
                                        /*var*/ let messageId = message.LCFCC$IConnectionMessage$Id;
                                        if (messageId !== null)
                                        {
                                            /*var*/ let tcs2;
                                            if (_awaiter.TryGetValue(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(context.Id, messageId), $.$ref(() => tcs2, ($v) => tcs2 = $v, $.$$.STT.TaskCompletionSource$$($.$KuVO.LCFCC.IConnectionMessage))))
                                            {
                                                this.awaitingReceive.Remove$1(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(context.Id, messageId));
                                                tcs2.SetResult(message);
                                            }
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.ST$1.Monitor.Exit(this)
                            }
                            return $.$$.STT.Task.CompletedTask;
                        }, $aZLirh ??= {"r":178454529,"p":[{"n":"message","p":1961646}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    }
                    if (this.MessagePipelines !== null)
                    {
                        let $t15, $r15;
                        ($t15 = this.MessagePipelines.LCFCPC$IPipelineCollection$LivingThing$Core$Frameworks$Common$Connection$IConnectionMessage$FeedAsync(message, new ($.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionMessage))().$ctor(this,  (/*message*/ message) =>
                        {
                            //lock(this)
                            try
                            {
                                $.$$.ST$1.Monitor.Enter$1(this)
                                {
                                    if (context !== null)
                                    {
                                        /*var*/ let tcs;
                                        if (_awaiter.TryGetValue(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(context.Id, null), $.$ref(() => tcs, ($v) => tcs = $v, $.$$.STT.TaskCompletionSource$$($.$KuVO.LCFCC.IConnectionMessage))))
                                        {
                                            this.awaitingReceive.Remove$1(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(context.Id, null));
                                            tcs.SetResult(message);
                                        }
                                        /*var*/ let messageId = message.LCFCC$IConnectionMessage$Id;
                                        if (messageId !== null)
                                        {
                                            /*var*/ let tcs2;
                                            if (_awaiter.TryGetValue(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(context.Id, messageId), $.$ref(() => tcs2, ($v) => tcs2 = $v, $.$$.STT.TaskCompletionSource$$($.$KuVO.LCFCC.IConnectionMessage))))
                                            {
                                                this.awaitingReceive.Remove$1(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(context.Id, messageId));
                                                tcs2.SetResult(message);
                                            }
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.ST$1.Monitor.Exit(this)
                            }
                            return $.$$.STT.Task.CompletedTask;
                        }, $OPyuqj ??= {"r":178454529,"p":[{"n":"message","p":1961646}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77309603502)
            
            //--TRIMMABLE-BOUNDARY-START(253403262638)
            /*Task */ RouteMessageToDevice(/*IConnectionClient*/ router, /*ClientConnectionIdentity*/ deviceId, /*IConnectionMessage*/ data, /*Func<IConnectionMessage, IConnectionMessage>*/ encodeSendData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403262638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (encodeSendData !== null)
                {
                    this.RouteDataFor($.$clone(deviceId), router.LCFCC$IConnectionClient$Id, encodeSendData);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(253403262638)
            
            //--TRIMMABLE-BOUNDARY-START(206158622382)
            /*Task */ HandleDataReceived(/*ClientConnectionIdentity*/ id, /*IConnectionMessage*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158622382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = this.GetClientContext($.$clone(id));
                if (context !== null)
                {
                    context.LastReceivedTime = $.$$.S.DateTime.UtcNow;
                    try
                    {
                        return this.DispatchMessage(message, context);
                    }
                    catch(e)
                    {
                        _ = this.DisposeClient($.$clone(id), e);
                        throw e;
                    }
                }
                else 
                {
                    _ = this.DisposeClient($.$clone(id), null);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(206158622382)
            
            //--TRIMMABLE-BOUNDARY-START(210453589678)
            /*Task */ HandleDataReceived$1(/*ClientConnectionIdentity*/ id, /*OneOf<byte[], ReadOnlyMemory<byte>, Stream>*/ data, /*string?*/ messageId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453589678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = this.GetClientContext($.$clone(id));
                if (context !== null)
                {
                    context.LastReceivedTime = $.$$.S.DateTime.UtcNow;
                    /*var*/ let message = (() =>
                    {
                        //new $.$KuVO.LCFCC.ConnectionMessage()
                        const $t18 = $.$KuVO.LCFCC.ConnectionMessage;
                        const $i18 = new $t18();
                        $i18.$ctor$1(this, context, 0/*MessageDirection.In*/, data);
                        $i18.Id = messageId;
                        return $i18;
                    })();
                    return this.HandleDataReceived($.$clone(id), message);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(210453589678)
            
            //--TRIMMABLE-BOUNDARY-START(287763001006)
            /*void */ Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763001006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(287763001006)
            
            //--TRIMMABLE-BOUNDARY-START(257710)
            static $_ConnectionRouting;
            static get ConnectionRouting()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$KuVO.LCFCC.BaseConnector$$(TNativeClient);
                return $cls.$_ConnectionRouting ??= $asm.$nstr(`$KuVO.LCFCC.BaseConnector<${TNativeClient?.$fullName}>.ConnectionRouting`, ($self) => class ConnectionRouting extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(38654963374)
                    /*ClientConnectionIdentity*/ RouterId;
                    //--TRIMMABLE-BOUNDARY-END(38654963374)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180126894)
                    /*Func<IConnectionMessage, IConnectionMessage>*/ Encoder = null;
                    //--TRIMMABLE-BOUNDARY-END(17180126894)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885159598)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885159598);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885159598)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885159598)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885159598)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.RouterId = this.RouterId.$clone();
                        copy.Encoder = this.Encoder;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(38654963374)
                        this.RouterId = $.$default($.$KuVO.LCFCC.ClientConnectionIdentity);
                        //--TRIMMABLE-BOUNDARY-END(38654963374)
                        
                    }
                    static $H = 257710;
                    static $h = 257710;
                    static $z = 20;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654963374),
    {
      "p": 323246,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34359996078,
        "h": Number(BigInt(257710)|0x800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 55834832558,
        "h": Number(BigInt(257710)|0xD00000000n),
        "f": 83886081
      },
      "n": "RouterId",
      "d": 257710,
      "H": 38654963374,
      "h": Number(BigInt(257710)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654963374),
//--TRIMMABLE-BOUNDARY-START(17180126894),
    {
      "p": $.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionMessage, $.$KuVO.LCFCC.IConnectionMessage).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770061486,
        "h": Number(BigInt(257710)|0x600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47244897966,
        "h": Number(BigInt(257710)|0xB00000000n),
        "f": 83886081
      },
      "n": "Encoder",
      "d": 257710,
      "H": 17180126894,
      "h": Number(BigInt(257710)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180126894)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885159598),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 257710,
      "H": 12885159598,
      "h": Number(BigInt(257710)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885159598)
  ],
  "d": 192174,
  "H": 257710,
  "h": 257710
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.BaseConnector<${TNativeClient?.$fullName}>+ConnectionRouting`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}BaseConnector$${TNativeClient?.$getFullName(separator)}$${separator}ConnectionRouting`; }
                }, $cls, ($v) => $cls.$_ConnectionRouting = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(257710)
            
            //--TRIMMABLE-BOUNDARY-START(60129734318)
            /*ConcurrentDictionary<ClientConnectionIdentity, ConnectionRouting>*/ connectionRouting = null;
            //--TRIMMABLE-BOUNDARY-END(60129734318)
            
            //--TRIMMABLE-BOUNDARY-START(249108295342)
            /*void */ RouteDataFor(/*ClientConnectionIdentity*/ deviceId, /*ClientConnectionIdentity*/ routerId, /*Func<IConnectionMessage, IConnectionMessage>*/ encoder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108295342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.connectionRouting.set_Item$1($.$clone(deviceId), (() =>
                {
                    //new $.$KuVO.LCFCC.BaseConnector$$(TNativeClient).ConnectionRouting()
                    const $t19 = $.$KuVO.LCFCC.BaseConnector$$(TNativeClient).ConnectionRouting;
                    const $i19 = new $t19();
                    $i19.$ctor$2();
                    $i19.RouterId = $.$clone(routerId);
                    $i19.Encoder = encoder;
                    return $i19;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(249108295342)
            
            //--TRIMMABLE-BOUNDARY-START(304942870190)
            /*Task *//*async*/  Write$1(/*OneOf<IConnectionClient, ClientConnectionIdentity>*/ mclient, /*IConnectionMessage*/ message, /*bool*/ withPipeline)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(304942870190);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ClientConnectionIdentity*/ let clientId = mclient.Match($.$KuVO.LCFCC.ClientConnectionIdentity, new ($.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c.LCFCC$IConnectionClient$Id;
                    }, $bCeWob ??= {"r":323246,"p":[{"n":"c","p":1568430}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.ClientConnectionIdentity))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c;
                    }, $snHnfl ??= {"r":323246,"p":[{"n":"c","p":323246}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    if (this.connectionRouting.ContainsKey($.$clone(clientId)))
                    {
                        /*var*/ let routing = this.connectionRouting.get_Item$1($.$clone(clientId));
                        message = (routing.Encoder?.Invoke(message) ?? null) ?? message;
                        clientId = routing.RouterId;
                    }
                    if (withPipeline)
                    {
                        /*var*/ let client = mclient.Match($.$KuVO.LCFCC.IConnectionClient, new ($.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.IConnectionClient))().$ctor(this,  (/*c*/ c) =>
                        {
                            return c;
                        }, $gTTwBi ??= {"r":1568430,"p":[{"n":"c","p":1568430}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.IConnectionClient))().$ctor(this,  (/*c*/ c) =>
                        {
                            return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient), this.KeyedClients, $.$clone(c));
                        }, $mARari ??= {"r":1568430,"p":[{"n":"c","p":323246}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        if (client !== null)
                        {
                            try
                            {
                                if (this.DirectEndPoint !== null)
                                {
                                    let $t20, $r20;
                                    ($t20 = this.DirectEndPoint.LCFCP$IPipeline$$$Invoke(message, new ($.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionMessage))().$ctor(this,  (/*message*/ message) =>
                                    {
                                        return this.WriteClient($.$clone(clientId), message);
                                    }, $EZcQqa ??= {"r":178454529,"p":[{"n":"message","p":1961646}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                                }
                                if (this.MessagePipelines !== null)
                                {
                                    let $t21, $r21;
                                    ($t21 = this.MessagePipelines.LCFCPC$IPipelineCollection$LivingThing$Core$Frameworks$Common$Connection$IConnectionMessage$FeedAsync(message, new ($.$fXpo.LCFCP.PipelineDelegate$$($.$KuVO.LCFCC.IConnectionMessage))().$ctor(this,  (/*message*/ message) =>
                                    {
                                        return this.WriteClient($.$clone(clientId), message);
                                    }, $bZIxel ??= {"r":178454529,"p":[{"n":"message","p":1961646}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                                }
                                if (this.DirectEndPoint === null && this.MessagePipelines === null)
                                {
                                    let $t22, $r22;
                                    ($t22 = this.WriteClient($.$clone(clientId), message), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)));
                                }
                            }
                            catch($e)
                            {
                            }
                        }
                    }
                    else 
                    {
                        let $t23, $r23;
                        ($t23 = this.WriteClient($.$clone(clientId), message), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(304942870190)
            
            //--TRIMMABLE-BOUNDARY-START(300647902894)
            /*Task */ Write(/*IConnectionClient*/ client, /*IConnectionMessage*/ message, /*bool*/ withPipeline)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300647902894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Write$1($.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).op_Implicit$1(client.LCFCC$IConnectionClient$Id), message, withPipeline);
            }
            //--TRIMMABLE-BOUNDARY-END(300647902894)
            
            //--TRIMMABLE-BOUNDARY-START(42949865134)
            /*Dictionary<(ClientConnectionIdentity, string?), TaskCompletionSource<IConnectionMessage>>*/ awaitingReceive = null;
            //--TRIMMABLE-BOUNDARY-END(42949865134)
            
            //--TRIMMABLE-BOUNDARY-START(244813328046)
            /*Task<IConnectionMessage> */ Read(/*OneOf<IConnectionClient, ClientConnectionIdentity>*/ mclient, /*TimeSpan*/ timeOut)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813328046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let clientId = mclient.Match($.$KuVO.LCFCC.ClientConnectionIdentity, new ($.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.LCFCC$IConnectionClient$Id;
                }, $WUonik ??= {"r":323246,"p":[{"n":"c","p":1568430}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.ClientConnectionIdentity))().$ctor(this,  (/*c*/ c) =>
                {
                    return c;
                }, $waSQnd ??= {"r":323246,"p":[{"n":"c","p":323246}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                /*var*/ let tcs = new ($.$$.STT.TaskCompletionSource$$($.$KuVO.LCFCC.IConnectionMessage))().$ctor$1();
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        this.awaitingReceive.set_Item(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3($.$clone(clientId), null), tcs);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
                _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t24, $r24;
                        ($t24 = $.$$.STT.Task.Delay$1($.$cast(timeOut.TotalMilliseconds, $.$$.S.Int32)).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)));
                        this.awaitingReceive.Remove$1(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3($.$clone(clientId), null));
                        if (!tcs.Task.IsCompleted)
                        {
                            tcs.SetCanceled();
                        }
                    });
                }, $CNHgDj ??= {"r":178454529,"n":"","d":this.$h,"H":0,"h":0,"f":17829890}));
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(244813328046)
            
            //--TRIMMABLE-BOUNDARY-START(313532804782)
            /*Task<IConnectionMessage> *//*async*/  WriteRead(/*IConnectionClient*/ client, /*IConnectionMessage*/ message, /*TimeSpan*/ timeOut)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage), $.$KuVO.LCFCC.IConnectionMessage, async ($asnycContext) => 
                {
                    let $t25, $r25;
                    let $t27, $r27;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(313532804782);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let tcs = new ($.$$.STT.TaskCompletionSource$$($.$KuVO.LCFCC.IConnectionMessage))().$ctor$1();
                    //lock(this)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this)
                        {
                            this.awaitingReceive.set_Item(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(client.LCFCC$IConnectionClient$Id, message.LCFCC$IConnectionMessage$Id), tcs);
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this)
                    }
                    ($t25 = this.Write(client, message, true), ($.$$.N.AsyncResolver.IsCompleted($t25, { set $v($v) { $r25 = $v; } }) ? $r25 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t25)));
                    _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t26, $r26;
                            ($t26 = $.$$.STT.Task.Delay$1($.$cast(timeOut.TotalMilliseconds, $.$$.S.Int32)).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                            this.awaitingReceive.Remove$1(new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor$3(client.LCFCC$IConnectionClient$Id, message.LCFCC$IConnectionMessage$Id));
                            if (!tcs.Task.IsCompleted)
                            {
                                tcs.SetCanceled();
                            }
                        });
                    }, $Rznofd ??= {"r":178454529,"n":"","d":this.$h,"H":0,"h":0,"f":17829890}));
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t27 = tcs.Task, ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(313532804782)
            
            //--TRIMMABLE-BOUNDARY-START(47244832430)
            /*void */ Broadcast(/*IConnectionMessage*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244832430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en28 = this.KeyedClients.GetEnumerator();
                while ($en28.SC$1$IEnumerator$MoveNext())
                {
                    let cl = $en28.SCG$IEnumerator$$$Current;
                    {
                        _ = this.Write$1($.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).FromT0(cl.Value), message, true);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244832430)
            
            //--TRIMMABLE-BOUNDARY-START(81604570798)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604570798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.disposed = true;
                let $en29 = this.KeyedClients.GetEnumerator();
                while ($en29.SC$1$IEnumerator$MoveNext())
                {
                    let kv = $en29.SCG$IEnumerator$$$Current;
                    {
                        _ = this.DisposeClient(kv.Key, null);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604570798)
            
            //--TRIMMABLE-BOUNDARY-START(42951503534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Id.get
            get LCFCC$IConnectionInterface$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196143790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(42951503534)
            
            //--TRIMMABLE-BOUNDARY-START(85901176494)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Name.get
            get LCFCC$IConnectionInterface$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376012974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(85901176494)
            
            //--TRIMMABLE-BOUNDARY-START(68721307310)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.LocalAddress.get
            get LCFCC$IConnectionInterface$LocalAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786078382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LocalAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(68721307310)
            
            //--TRIMMABLE-BOUNDARY-START(34361568942)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Context.get
            get LCFCC$IConnectionInterface$Context()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886732462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Context;
            }
            //--TRIMMABLE-BOUNDARY-END(34361568942)
            
            //--TRIMMABLE-BOUNDARY-START(77311241902)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Manager.get
            get LCFCC$IConnectionInterface$Manager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081045678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Manager;
            }
            //--TRIMMABLE-BOUNDARY-END(77311241902)
            
            //--TRIMMABLE-BOUNDARY-START(51541438126)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.IsRunning.get
            get LCFCC$IConnectionInterface$IsRunning()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491111086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsRunning;
            }
            //--TRIMMABLE-BOUNDARY-END(51541438126)
            
            //--TRIMMABLE-BOUNDARY-START(25771634350)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Clients.get
            get LCFCC$IConnectionInterface$Clients()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591765166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clients;
            }
            //--TRIMMABLE-BOUNDARY-END(25771634350)
            
            //--TRIMMABLE-BOUNDARY-START(60131372718)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.this[LivingThing.Core.Frameworks.Common.Connection.ClientConnectionIdentity].get
            LCFCC$IConnectionInterface$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131372718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60131372718)
            
            //--TRIMMABLE-BOUNDARY-START(120260914862)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.StartAsync(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext)
            LCFCC$IConnectionInterface$StartAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260914862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(120260914862)
            
            //--TRIMMABLE-BOUNDARY-START(17181699758)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Disconnect(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient)
            LCFCC$IConnectionInterface$Disconnect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181699758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Disconnect(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181699758)
            
            //--TRIMMABLE-BOUNDARY-START(124555882158)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Stop()
            LCFCC$IConnectionInterface$Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555882158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Stop(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(124555882158)
            
            //--TRIMMABLE-BOUNDARY-START(133145816750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Write(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Connection.ClientConnectionIdentity>, LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, bool)
            LCFCC$IConnectionInterface$Write()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145816750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Write$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(133145816750)
            
            //--TRIMMABLE-BOUNDARY-START(111670980270)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Read(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Connection.ClientConnectionIdentity>, System.TimeSpan)
            LCFCC$IConnectionInterface$Read()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670980270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Read(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(111670980270)
            
            //--TRIMMABLE-BOUNDARY-START(137440784046)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.WriteRead(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, System.TimeSpan)
            LCFCC$IConnectionInterface$WriteRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440784046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WriteRead(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(137440784046)
            
            //--TRIMMABLE-BOUNDARY-START(4296797870)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Broadcast(LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage)
            LCFCC$IConnectionInterface$Broadcast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296797870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Broadcast(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296797870)
            
            //--TRIMMABLE-BOUNDARY-START(115965947566)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.RouteMessageToDevice(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Connection.ClientConnectionIdentity, LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, System.Func<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>)
            LCFCC$IConnectionInterface$RouteMessageToDevice()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965947566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RouteMessageToDevice(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(115965947566)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(223338491566)
                this.KeyedClients = new ($.$scc.SCC.ConcurrentDictionary$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(223338491566)
                
                //--TRIMMABLE-BOUNDARY-START(60129734318)
                this.connectionRouting = new ($.$scc.SCC.ConcurrentDictionary$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.BaseConnector$$(TNativeClient).ConnectionRouting))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(60129734318)
                
                //--TRIMMABLE-BOUNDARY-START(42949865134)
                this.awaitingReceive = new ($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String), $.$$.STT.TaskCompletionSource$$($.$KuVO.LCFCC.IConnectionMessage)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(42949865134)
                
            }
            static $H = 192174;
            static $h = 192174;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$KuVO.LCFCC.BaseConnector; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719668910),
    {
      "p": 1765038,
      "g": {
        "r": 0,
        "d": 0,
        "H": 124554243758,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 279173066414,
        "h": Number(BigInt(this.$h)|0x4100000000n),
        "f": 83886082
      },
      "n": "DirectEndPoint",
      "d": this.$h,
      "H": 68719668910,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(68719668910),
//--TRIMMABLE-BOUNDARY-START(55834767022),
    {
      "p": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107374374574,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331652
      },
      "n": "ConnectionPipelines",
      "d": this.$h,
      "H": 55834767022,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(55834767022),
//--TRIMMABLE-BOUNDARY-START(231928426158),
    {
      "p": 1896110,
      "g": {
        "r": 0,
        "d": 0,
        "H": 176093851310,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 50331649
      },
      "n": "Manager",
      "d": this.$h,
      "H": 231928426158,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231928426158),
//--TRIMMABLE-BOUNDARY-START(227633458862),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 167503916718,
        "h": Number(BigInt(this.$h)|0x2700000000n),
        "f": 50331777
      },
      "n": "LocalAddress",
      "d": this.$h,
      "H": 227633458862,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(227633458862),
//--TRIMMABLE-BOUNDARY-START(223338491566),
    {
      "p": $.$scc.SCC.ConcurrentDictionary$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 158913982126,
        "h": Number(BigInt(this.$h)|0x2500000000n),
        "f": 50331652
      },
      "n": "KeyedClients",
      "d": this.$h,
      "H": 223338491566,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(223338491566),
//--TRIMMABLE-BOUNDARY-START(214748556974),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 133144178350,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331777
      },
      "n": "Id",
      "d": this.$h,
      "H": 214748556974,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(214748556974),
//--TRIMMABLE-BOUNDARY-START(240518360750),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 184683785902,
        "h": Number(BigInt(this.$h)|0x2B00000000n),
        "f": 50331777
      },
      "n": "Name",
      "d": this.$h,
      "H": 240518360750,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(240518360750),
//--TRIMMABLE-BOUNDARY-START(219043524270),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 141734112942,
        "h": Number(BigInt(this.$h)|0x2100000000n),
        "f": 50331649
      },
      "n": "IsRunning",
      "d": this.$h,
      "H": 219043524270,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219043524270),
//--TRIMMABLE-BOUNDARY-START(257698229934),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 193273720494,
        "h": Number(BigInt(this.$h)|0x2D00000000n),
        "f": 50331780
      },
      "n": "RunBackgroundCheckClientConnections",
      "d": this.$h,
      "H": 257698229934,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(257698229934),
//--TRIMMABLE-BOUNDARY-START(51539799726),
    {
      "p": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98784439982,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "n": "Clients",
      "d": this.$h,
      "H": 51539799726,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539799726),
//--TRIMMABLE-BOUNDARY-START(296352935598),
    {
      "p": 1568430,
      "i": [
        {
          "n": "clientId",
          "p": 323246
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "H": 150324047534,
        "h": Number(BigInt(this.$h)|0x2300000000n),
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "H": 296352935598,
      "h": Number(BigInt(this.$h)|0x4500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(296352935598),
//--TRIMMABLE-BOUNDARY-START(64424701614),
    {
      "p": 1633966,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115964309166,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 270583131822,
        "h": Number(BigInt(this.$h)|0x3F00000000n),
        "f": 83886081
      },
      "n": "Context",
      "d": this.$h,
      "H": 64424701614,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424701614)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(292057968302),
    {
      "r": 65537,
      "p": [
        {
          "n": "endpoint",
          "p": 1765038
        }
      ],
      "n": "Subscribe",
      "d": this.$h,
      "H": 292057968302,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(292057968302),
//--TRIMMABLE-BOUNDARY-START(261993197230),
    {
      "r": 65537,
      "n": "RunCheckClientConnections",
      "d": this.$h,
      "H": 261993197230,
      "h": Number(BigInt(this.$h)|0x3D00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(261993197230),
//--TRIMMABLE-BOUNDARY-START(283468033710),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "n": "StartAsync",
      "d": this.$h,
      "H": 283468033710,
      "h": Number(BigInt(this.$h)|0x4200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(283468033710),
//--TRIMMABLE-BOUNDARY-START(73014636206),
    {
      "r": 65537,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "Disconnect",
      "d": this.$h,
      "H": 73014636206,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(73014636206),
//--TRIMMABLE-BOUNDARY-START(85899538094),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 323246
        },
        {
          "n": "e",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "DisposeClient",
      "d": this.$h,
      "H": 85899538094,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16781444
    },
//--TRIMMABLE-BOUNDARY-END(85899538094),
//--TRIMMABLE-BOUNDARY-START(201863655086),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 323246
        },
        {
          "n": "nativeClient",
          "p": TNativeClient?.$h??1572864
        },
        {
          "n": "parentClient",
          "p": 1568430,
          "f": 65
        },
        {
          "n": "clientState",
          "p": $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient).$h,
          "f": 65
        }
      ],
      "n": "HandleClientConnected",
      "d": this.$h,
      "H": 201863655086,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 16781316
    },
//--TRIMMABLE-BOUNDARY-END(201863655086),
//--TRIMMABLE-BOUNDARY-START(197568687790),
    {
      "r": $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient).$h,
      "p": [
        {
          "n": "id",
          "p": 323246
        }
      ],
      "n": "GetClientContext",
      "d": this.$h,
      "H": 197568687790,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197568687790),
//--TRIMMABLE-BOUNDARY-START(77309603502),
    {
      "r": 178454529,
      "p": [
        {
          "n": "message",
          "p": 1961646
        },
        {
          "n": "context",
          "p": $.$KuVO.LCFCC.ConnectionClient$$(TNativeClient).$h,
          "f": 65
        }
      ],
      "n": "DispatchMessage",
      "d": this.$h,
      "H": 77309603502,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16781316
    },
//--TRIMMABLE-BOUNDARY-END(77309603502),
//--TRIMMABLE-BOUNDARY-START(253403262638),
    {
      "r": 178454529,
      "p": [
        {
          "n": "router",
          "p": 1568430
        },
        {
          "n": "deviceId",
          "p": 323246
        },
        {
          "n": "data",
          "p": 1961646
        },
        {
          "n": "encodeSendData",
          "p": $.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionMessage, $.$KuVO.LCFCC.IConnectionMessage).$h
        }
      ],
      "n": "RouteMessageToDevice",
      "d": this.$h,
      "H": 253403262638,
      "h": Number(BigInt(this.$h)|0x3B00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(253403262638),
//--TRIMMABLE-BOUNDARY-START(206158622382),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 323246
        },
        {
          "n": "message",
          "p": 1961646
        }
      ],
      "n": "HandleDataReceived",
      "d": this.$h,
      "H": 206158622382,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(206158622382),
//--TRIMMABLE-BOUNDARY-START(210453589678),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 323246
        },
        {
          "n": "data",
          "p": $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).$h
        },
        {
          "n": "messageId",
          "p": 1310721
        }
      ],
      "n": "HandleDataReceived",
      "o": "@$1",
      "d": this.$h,
      "H": 210453589678,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(210453589678),
//--TRIMMABLE-BOUNDARY-START(287763001006),
    {
      "r": 65537,
      "n": "Stop",
      "d": this.$h,
      "H": 287763001006,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(287763001006),
//--TRIMMABLE-BOUNDARY-START(249108295342),
    {
      "r": 65537,
      "p": [
        {
          "n": "deviceId",
          "p": 323246
        },
        {
          "n": "routerId",
          "p": 323246
        },
        {
          "n": "encoder",
          "p": $.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionMessage, $.$KuVO.LCFCC.IConnectionMessage).$h
        }
      ],
      "n": "RouteDataFor",
      "d": this.$h,
      "H": 249108295342,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(249108295342),
//--TRIMMABLE-BOUNDARY-START(309237837486),
    {
      "r": 178454529,
      "p": [
        {
          "n": "clientId",
          "p": 323246
        },
        {
          "n": "message",
          "p": 1961646
        }
      ],
      "n": "WriteClient",
      "d": this.$h,
      "H": 309237837486,
      "h": Number(BigInt(this.$h)|0x4800000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(309237837486),
//--TRIMMABLE-BOUNDARY-START(304942870190),
    {
      "r": 178454529,
      "p": [
        {
          "n": "mclient",
          "p": $.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).$h
        },
        {
          "n": "message",
          "p": 1961646
        },
        {
          "n": "withPipeline",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": this.$h,
      "H": 304942870190,
      "h": Number(BigInt(this.$h)|0x4700000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(304942870190),
//--TRIMMABLE-BOUNDARY-START(300647902894),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "message",
          "p": 1961646
        },
        {
          "n": "withPipeline",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Write",
      "d": this.$h,
      "H": 300647902894,
      "h": Number(BigInt(this.$h)|0x4600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(300647902894),
//--TRIMMABLE-BOUNDARY-START(244813328046),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "p": [
        {
          "n": "mclient",
          "p": $.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).$h
        },
        {
          "n": "timeOut",
          "p": 186646529
        }
      ],
      "n": "Read",
      "d": this.$h,
      "H": 244813328046,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813328046),
//--TRIMMABLE-BOUNDARY-START(313532804782),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "message",
          "p": 1961646
        },
        {
          "n": "timeOut",
          "p": 186646529
        }
      ],
      "n": "WriteRead",
      "d": this.$h,
      "H": 313532804782,
      "h": Number(BigInt(this.$h)|0x4900000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(313532804782),
//--TRIMMABLE-BOUNDARY-START(47244832430),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1961646
        }
      ],
      "n": "Broadcast",
      "d": this.$h,
      "H": 47244832430,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244832430),
//--TRIMMABLE-BOUNDARY-START(81604570798),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 81604570798,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81604570798)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(236223393454),
    {
      "t": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "n": "MessagePipelines",
      "d": this.$h,
      "H": 236223393454,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(236223393454),
//--TRIMMABLE-BOUNDARY-START(90194505390),
    {
      "t": 262145,
      "n": "disposed",
      "d": this.$h,
      "H": 90194505390,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(90194505390),
//--TRIMMABLE-BOUNDARY-START(60129734318),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.BaseConnector$$(TNativeClient).ConnectionRouting).$h,
      "n": "connectionRouting",
      "d": this.$h,
      "H": 60129734318,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60129734318),
//--TRIMMABLE-BOUNDARY-START(42949865134),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String), $.$$.STT.TaskCompletionSource$$($.$KuVO.LCFCC.IConnectionMessage)).$h,
      "n": "awaitingReceive",
      "d": this.$h,
      "H": 42949865134,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949865134)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38654897838),
    {
      "p": [
        {
          "n": "manager",
          "p": 1896110
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 38654897838,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654897838),
//--TRIMMABLE-BOUNDARY-START(30064963246),
    {
      "p": [
        {
          "n": "manager",
          "p": 1896110
        },
        {
          "n": "endPoint",
          "p": 1765038,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 30064963246,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064963246),
//--TRIMMABLE-BOUNDARY-START(34359930542),
    {
      "p": [
        {
          "n": "manager",
          "p": 1896110
        },
        {
          "n": "connectionPipelineExecutor",
          "p": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionClient).$h,
          "f": 65
        },
        {
          "n": "messagePipelines",
          "p": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionMessage).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 34359930542,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359930542)
  ],
  "s": [
    {
      "h": TNativeClient?.$h??1572864,
      "n": "TNativeClient"
    }
  ],
  "r": 1,
  "H": 192174,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionInterface, $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$KuVO.LCFCC.BaseConnector$$(TNativeClient).ConnectionRouting ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.BaseConnector<${TNativeClient?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}BaseConnector$${TNativeClient?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(192174)
        
        

        //--TRIMMABLE-BOUNDARY-START(781998)
        $asm.$cls(`$KuVO.LCFCC.ConnectionEventArg`, ($self) => class ConnectionEventArg extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475618478)
            /*IConnectionContext*/ Context = null;
            //--TRIMMABLE-BOUNDARY-END(21475618478)
            
            //--TRIMMABLE-BOUNDARY-START(17180651182)
            /*IConnectionClient*/ Client = null;
            //--TRIMMABLE-BOUNDARY-END(17180651182)
            
            //--TRIMMABLE-BOUNDARY-START(12885683886)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885683886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885683886)
            
            //--TRIMMABLE-BOUNDARY-START(12885683886)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885683886)
            
            static $h = 781998;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475618478),
    {
      "p": 1633966,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655487662,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835356846,
        "f": 83886081
      },
      "n": "Context",
      "d": 781998,
      "h": 21475618478,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475618478),
//--TRIMMABLE-BOUNDARY-START(17180651182),
    {
      "p": 1568430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065553070,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245422254,
        "f": 83886081
      },
      "n": "Client",
      "d": 781998,
      "h": 17180651182,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180651182)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885683886),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 781998,
      "h": 12885683886,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885683886)
  ],
  "h": 781998
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionEventArg`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionEventArg`; }
        });
        //--TRIMMABLE-BOUNDARY-END(781998)
        
        

        //--TRIMMABLE-BOUNDARY-START(1371822)
        $asm.$cls(`$KuVO.LCFCC.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296339118)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296339118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4296339118)
            
            static $h = 1371822;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296339118),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 1371822,
      "h": 4296339118,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296339118)
  ],
  "h": 1371822
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1371822)
        
        

        //--TRIMMABLE-BOUNDARY-START(716462)
        $asm.$cls(`$KuVO.LCFCC.ConnectionErrorEventArg`, ($self) => class ConnectionErrorEventArg extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885618350)
            /*Exception?*/ Exception = null;
            //--TRIMMABLE-BOUNDARY-END(12885618350)
            
            //--TRIMMABLE-BOUNDARY-START(8590651054)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590651054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590651054)
            
            //--TRIMMABLE-BOUNDARY-START(8590651054)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590651054)
            
            static $h = 716462;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885618350),
    {
      "p": 80805889,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475552942,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065487534,
        "f": 83886081
      },
      "n": "Exception",
      "d": 716462,
      "h": 12885618350,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885618350)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590651054),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 716462,
      "h": 8590651054,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590651054)
  ],
  "h": 716462
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionErrorEventArg`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionErrorEventArg`; }
        });
        //--TRIMMABLE-BOUNDARY-END(716462)
        
        

        //--TRIMMABLE-BOUNDARY-START(1306286)
        $asm.$cls(`$KuVO.LCFCC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296273582)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296273582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$KuVO.LCFCC.ConnectionFlags.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$KuVO.LCFCC.ConnectionFlagsCustomAttributesProvider, $.$KuVO.LCFCC.ConnectionFlagsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$KuVO.LCFCC.MessageDirection.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$KuVO.LCFCC.MessageDirectionCustomAttributesProvider, $.$KuVO.LCFCC.MessageDirectionCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4296273582)
            
            static $h = 1306286;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296273582),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 1306286,
      "h": 4296273582,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296273582)
  ],
  "h": 1306286
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1306286)
        
        

        //--TRIMMABLE-BOUNDARY-START(2354862)
        $asm.$cls(`$KuVO.LCFCC.MessageDirectionCustomAttributesProvider`, ($self) => class MessageDirectionCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297322158)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297322158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297322158)
            
            static $h = 2354862;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297322158),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2354862,
      "h": 4297322158,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297322158)
  ],
  "h": 2354862
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.MessageDirectionCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}MessageDirectionCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2354862)
        
        

        //--TRIMMABLE-BOUNDARY-START(913070)
        $asm.$cls(`$KuVO.LCFCC.ConnectionFlagsCustomAttributesProvider`, ($self) => class ConnectionFlagsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295880366)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295880366)
            
            //--TRIMMABLE-BOUNDARY-START(8590847662)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590847662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$KuVO.LCFCC.ConnectionFlagsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$KuVO.LCFCC.ConnectionFlagsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $xlcUti ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":913070,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $tGrSai ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":913070,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590847662)
            
            static $h = 913070;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590847662),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 913070,
      "h": 8590847662,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590847662)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295880366),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 913070,
      "h": 4295880366,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295880366)
  ],
  "h": 913070
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionFlagsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionFlagsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(913070)
        
        

        //--TRIMMABLE-BOUNDARY-START(978606)
        $asm.$cls(`$KuVO.LCFCC.ConnectionInterfaceExtension`, ($self) => class ConnectionInterfaceExtension
        {
            //--TRIMMABLE-BOUNDARY-START(17180847790)
            static /*Task */ Write$1(/*this IConnectionInterface*/ _interface, /*IConnectionClient*/ client, /*IConnectionMessage*/ data, /*bool*/ withPipeline)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180847790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return _interface.LCFCC$IConnectionInterface$Write($.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).FromT0(client), data, withPipeline);
            }
            //--TRIMMABLE-BOUNDARY-END(17180847790)
            
            //--TRIMMABLE-BOUNDARY-START(12885880494)
            static /*Task */ Write(/*this IConnectionInterface*/ _interface, /*ClientConnectionIdentity*/ clientId, /*IConnectionMessage*/ data, /*bool*/ withPipeline)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885880494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return _interface.LCFCC$IConnectionInterface$Write($.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).FromT1($.$clone(clientId)), data, withPipeline);
            }
            //--TRIMMABLE-BOUNDARY-END(12885880494)
            
            //--TRIMMABLE-BOUNDARY-START(8590913198)
            static /*Task<IConnectionMessage> */ Read$1(/*this IConnectionInterface*/ _interface, /*IConnectionClient*/ client, /*TimeSpan*/ timeOut)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590913198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return _interface.LCFCC$IConnectionInterface$Read($.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).FromT0(client), timeOut);
            }
            //--TRIMMABLE-BOUNDARY-END(8590913198)
            
            //--TRIMMABLE-BOUNDARY-START(4295945902)
            static /*Task<IConnectionMessage> */ Read(/*this IConnectionInterface*/ _interface, /*ClientConnectionIdentity*/ clientId, /*TimeSpan*/ timeOut)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295945902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return _interface.LCFCC$IConnectionInterface$Read($.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).FromT1($.$clone(clientId)), timeOut);
            }
            //--TRIMMABLE-BOUNDARY-END(4295945902)
            
            static $h = 978606;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180847790),
    {
      "r": 178454529,
      "p": [
        {
          "n": "_interface",
          "p": 1830574
        },
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "data",
          "p": 1961646
        },
        {
          "n": "withPipeline",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 978606,
      "h": 17180847790,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180847790),
//--TRIMMABLE-BOUNDARY-START(12885880494),
    {
      "r": 178454529,
      "p": [
        {
          "n": "_interface",
          "p": 1830574
        },
        {
          "n": "clientId",
          "p": 323246
        },
        {
          "n": "data",
          "p": 1961646
        },
        {
          "n": "withPipeline",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Write",
      "d": 978606,
      "h": 12885880494,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885880494),
//--TRIMMABLE-BOUNDARY-START(8590913198),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "p": [
        {
          "n": "_interface",
          "p": 1830574
        },
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "timeOut",
          "p": 186646529
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 978606,
      "h": 8590913198,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590913198),
//--TRIMMABLE-BOUNDARY-START(4295945902),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "p": [
        {
          "n": "_interface",
          "p": 1830574
        },
        {
          "n": "clientId",
          "p": 323246
        },
        {
          "n": "timeOut",
          "p": 186646529
        }
      ],
      "n": "Read",
      "d": 978606,
      "h": 4295945902,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295945902)
  ],
  "h": 978606
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionInterfaceExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionInterfaceExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(978606)
        
        

        //--TRIMMABLE-BOUNDARY-START(2420398)
        $asm.$cls(`$KuVO.LCFCC.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297387694)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297387694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$KuVO.LCFCC.IRemoteClientConnectionRemoteService, $.$KuVO.LCFCC.IRemoteClientConnectionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$KuVO.LCFCC.IRemoteClientConnectionRemoteService_Mocking().$ctor$3(impl);
                }, $GfMzKg ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":2420398,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4297387694)
            
            static $h = 2420398;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297387694),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 2420398,
      "h": 4297387694,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297387694)
  ],
  "h": 2420398
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2420398)
        
        

        //--TRIMMABLE-BOUNDARY-START(1109678)
        $asm.$cls(`$KuVO.LCFCC.ConnectionManagerExtension`, ($self) => class ConnectionManagerExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296076974)
            static /*IEnumerable<(IConnectionInterface Interface, IConnectionClient Client)> */ GetClients(/*this IConnectionManager*/ connectionManager, /*string*/ clientId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296076974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = $.$KuVO.LCFCC.ClientConnectionIdentity.IdentifyConnection(clientId);
                return $.$sl.SL.Enumerable.Where($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient), $.$sl.SL.Enumerable.SelectMany$2($.$KuVO.LCFCC.IConnectionInterface, $.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient), connectionManager.LCFCC$IConnectionManager$Interfaces, new ($.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionInterface, $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient))))().$ctor(this,  (/*i*/ i) =>
                {
                    return $.$sl.SL.Enumerable.Select$1($.$KuVO.LCFCC.IConnectionClient, $.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient), i.LCFCC$IConnectionInterface$Clients, new ($.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionClient, $.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient)))().$ctor(this,  (/*c*/ c) =>
                    {
                        return new ($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient))().$ctor$3(i, c);
                    }, $hkfwDk ??= {"r":$.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient).$h,"p":[{"n":"c","p":1568430}],"n":"","d":1109678,"h":0,"f":17825794}));
                }, $Xcplzi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient)).$h,"p":[{"n":"i","p":1830574}],"n":"","d":1109678,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient), $.$$.S.Boolean))().$ctor(this,  (/*i*/ i) =>
                {
                    return $.$KuVO.LCFCC.ClientConnectionIdentity.op_Equality(i.Item2.LCFCC$IConnectionClient$Id, id);
                }, $VTwSsh ??= {"r":262145,"p":[{"n":"i","p":$.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient).$h}],"n":"","d":1109678,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4296076974)
            
            //--TRIMMABLE-BOUNDARY-START(8591044270)
            static /*Task<bool> *//*async*/  Write(/*this IConnectionManager*/ connectionManager, /*string*/ clientId, /*byte[]*/ data, /*bool*/ withPipeline)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591044270);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let clients = $.$KuVO.LCFCC.ConnectionManagerExtension.GetClients(connectionManager, clientId);
                    if ($.$sl.SL.Enumerable.Any$1($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient), clients))
                    {
                        let $en1 = clients.SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let client = $en1.SCG$IEnumerator$$$Current;
                            {
                                if (client.Item2 !== null)
                                {
                                    let $t2, $r2;
                                    ($t2 = $.$KuVO.LCFCC.ConnectionInterfaceExtension.Write$1(client.Item1, client.Item2, new $.$KuVO.LCFCC.ConnectionMessage().$ctor$1(client.Item1, client.Item2, 1/*MessageDirection.Out*/, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit(data)), withPipeline), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                                }
                            }
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, true);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8591044270)
            
            //--TRIMMABLE-BOUNDARY-START(12886011566)
            static /*Task<byte[]?> *//*async*/  WriteRead(/*this IConnectionManager*/ connectionManager, /*string*/ clientId, /*byte[]*/ data, /*TimeSpan*/ timeOut, /*bool*/ withPipeline)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$typeArray($.$$.S.Byte)), $.$typeArray($.$$.S.Byte), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886011566);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let clients = $.$KuVO.LCFCC.ConnectionManagerExtension.GetClients(connectionManager, clientId);
                    /*string?*/ let error = null;
                    if ($.$sl.SL.Enumerable.Any$1($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient), clients))
                    {
                        let $en3 = clients.SCG$IEnumerable$$$GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let client = $en3.SCG$IEnumerator$$$Current;
                            {
                                if (client.Item2 !== null)
                                {
                                    try
                                    {
                                        let $t4, $r4;
                                        /*var*/ let bytes = ($t4 = client.Item1.LCFCC$IConnectionInterface$WriteRead(client.Item2, new $.$KuVO.LCFCC.ConnectionMessage().$ctor$1(client.Item1, client.Item2, 1/*MessageDirection.Out*/, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit(data)), timeOut), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                        /*var*/ let bts = $.$KuVO.LCFCC.ConnectonInterfaceExtension.ToBytes(bytes.LCFCC$IConnectionMessage$Data);
                                        /*byte[]?*/ let __ca1__;
                                        if ((__ca1__ = bts) !== null ? $.$sl.SL.Enumerable.Any$1($.$$.S.Byte, __ca1__) : false)
                                        {
                                            return $.$$.N.AsyncResolver.Result($asnycContext, bts);
                                        }
                                    }
                                    catch(e)
                                    {
                                        error += "\r\n" + $.$strNN(e.Message);
                                    }
                                }
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12886011566)
            
            static $h = 1109678;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296076974),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$KuVO.LCFCC.IConnectionInterface, $.$KuVO.LCFCC.IConnectionClient)).$h,
      "p": [
        {
          "n": "connectionManager",
          "p": 1896110
        },
        {
          "n": "clientId",
          "p": 1310721
        }
      ],
      "n": "GetClients",
      "d": 1109678,
      "h": 4296076974,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296076974),
//--TRIMMABLE-BOUNDARY-START(8591044270),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "connectionManager",
          "p": 1896110
        },
        {
          "n": "clientId",
          "p": 1310721
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "withPipeline",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Write",
      "d": 1109678,
      "h": 8591044270,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(8591044270),
//--TRIMMABLE-BOUNDARY-START(12886011566),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$$.S.Byte)).$h,
      "p": [
        {
          "n": "connectionManager",
          "p": 1896110
        },
        {
          "n": "clientId",
          "p": 1310721
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "timeOut",
          "p": 186646529
        },
        {
          "n": "withPipeline",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "WriteRead",
      "d": 1109678,
      "h": 12886011566,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(12886011566)
  ],
  "h": 1109678
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionManagerExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionManagerExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1109678)
        
        

        //--TRIMMABLE-BOUNDARY-START(1240750)
        $asm.$cls(`$KuVO.LCFCC.ConnectonInterfaceExtension`, ($self) => class ConnectonInterfaceExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296208046)
            static /*ValueTask */ SendTo(/*this OneOf<byte[], ReadOnlyMemory<byte>, Stream>*/ data, /*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296208046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return data.Match($.$$.STT.ValueTask, new ($.$$.S.Func$$$($.$typeArray($.$$.S.Byte), $.$$.STT.ValueTask))().$ctor(this,  (/**/ bytes) =>
                {
                    return new $.$$.STT.ValueTask().$ctor$5(stream.WriteAsync$1(bytes, 0, bytes.length));
                }, $LsOJLb ??= {"r":181338113,"p":[{"n":"bytes","p":$.$typeArray($.$$.S.Byte).$h}],"n":"","d":1240750,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.STT.ValueTask))().$ctor(this,  (/**/ mem) =>
                {
                    return stream.WriteAsync$2(mem, new $.$$.ST$1.CancellationToken());
                }, $KigNGa ??= {"r":181338113,"p":[{"n":"mem","p":$.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h}],"n":"","d":1240750,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SI.Stream, $.$$.STT.ValueTask))().$ctor(this,  (/*stm*/ stm) =>
                {
                    return new $.$$.STT.ValueTask().$ctor$5(stm.CopyToAsync$3(stream));
                }, $RanBZk ??= {"r":181338113,"p":[{"n":"stm","p":95748097}],"n":"","d":1240750,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4296208046)
            
            //--TRIMMABLE-BOUNDARY-START(8591175342)
            static /*byte[]? */ ToBytes(/*this OneOf<byte[], ReadOnlyMemory<byte>, Stream>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591175342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return data.Match($.$typeArray($.$$.S.Byte), new ($.$$.S.Func$$$($.$typeArray($.$$.S.Byte), $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/**/ bytes) =>
                {
                    return bytes;
                }, $wiAwqb ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"bytes","p":$.$typeArray($.$$.S.Byte).$h}],"n":"","d":1240750,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/*mem*/ mem) =>
                {
                    return mem.ToArray();
                }, $QwNtbc ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"mem","p":$.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h}],"n":"","d":1240750,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.SI.Stream, $.$typeArray($.$$.S.Byte)))().$ctor(this,  (/*stream*/ stream) =>
                {
                    /*byte[]*/ let bb = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [((1024 * 1024) | 0)], null);
                    /*int*/ let l = stream.Read(bb, 0, bb.length);
                    return $.$sl.SL.Enumerable.ToArray($.$$.S.Byte, $.$sl.SL.Enumerable.Take($.$$.S.Byte, bb, l));
                }, $mmZXLc ??= {"r":$.$typeArray($.$$.S.Byte).$h,"p":[{"n":"stream","p":95748097}],"n":"","d":1240750,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8591175342)
            
            //--TRIMMABLE-BOUNDARY-START(12886142638)
            static /*PacketBuilder? */ ToPacketBuilder(/*this OneOf<byte[], ReadOnlyMemory<byte>, Stream>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886142638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let bytes = $.$KuVO.LCFCC.ConnectonInterfaceExtension.ToBytes(data);
                if (bytes === null)
                {
                    return null;
                }
                return new $.$fPer.LCFCD.PacketBuilder().$ctor$1(bytes);
            }
            //--TRIMMABLE-BOUNDARY-END(12886142638)
            
            static $h = 1240750;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296208046),
    {
      "r": 181338113,
      "p": [
        {
          "n": "data",
          "p": $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).$h
        },
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": "SendTo",
      "d": 1240750,
      "h": 4296208046,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296208046),
//--TRIMMABLE-BOUNDARY-START(8591175342),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "data",
          "p": $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).$h
        }
      ],
      "n": "ToBytes",
      "d": 1240750,
      "h": 8591175342,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591175342),
//--TRIMMABLE-BOUNDARY-START(12886142638),
    {
      "r": 31164758,
      "p": [
        {
          "n": "data",
          "p": $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).$h
        }
      ],
      "n": "ToPacketBuilder",
      "d": 1240750,
      "h": 12886142638,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886142638)
  ],
  "h": 1240750
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectonInterfaceExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectonInterfaceExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1240750)
        
        

        //--TRIMMABLE-BOUNDARY-START(2551470)
        $asm.$cls(`$KuVO.LCFCC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887453358)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887453358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_RemoteClientConnectionProxy(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$KuVO.LCFCC.RemoteClientConnectionProxy().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$uvJL.LCFCR.IServerRemoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$KuVO.LCFCC.RemoteClientConnectionProxy.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$KuVO.LCFCC.ServiceRegistrar, Get_RemoteClientConnectionProxy, $TQqgBa ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_RemoteClientConnectionProxy","d":2551470,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12887453358)
            
            //--TRIMMABLE-BOUNDARY-START(8592486062)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592486062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$KuVO.LCFCC.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$KuVO.LCFCC.RemoteClientConnectionProxy, services);
                $.$KuVO.LCFCC.FastEnumStartupExtension.AddGeneratedFastEnums(services);
                $.$KuVO.LCFCC.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$KuVO.LCFCC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592486062)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$KuVO.LCFCC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297518766)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297518766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297518766)
            
            //--TRIMMABLE-BOUNDARY-START(4297518766)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297518766)
            
            static $h = 2551470;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887453358),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 2551470,
      "h": 12887453358,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12887453358),
//--TRIMMABLE-BOUNDARY-START(8592486062),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2551470,
      "h": 8592486062,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592486062)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297518766),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2551470,
      "h": 4297518766,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297518766)
  ],
  "h": 2551470
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2551470)
        
        

        //--TRIMMABLE-BOUNDARY-START(1175214)
        $asm.$cls(`$KuVO.LCFCC.ConnectionMessage`, ($self) => class ConnectionMessage extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476011694)
            $ctor$1(/*IConnectionInterface*/ $interface, /*IConnectionClient*/ client, /*MessageDirection*/ direction, /*OneOf<byte[], ReadOnlyMemory<byte>, Stream>*/ data)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476011694);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Direction = direction;
                    this.Client = client;
                    this.Data = data;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476011694)
            
            //--TRIMMABLE-BOUNDARY-START(34360913582)
            /*MessageDirection*/ Direction = 0;
            //--TRIMMABLE-BOUNDARY-END(34360913582)
            
            //--TRIMMABLE-BOUNDARY-START(73015619246)
            /*string?*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(73015619246)
            
            //--TRIMMABLE-BOUNDARY-START(25770978990)
            /*IConnectionClient*/ Client = null;
            //--TRIMMABLE-BOUNDARY-END(25770978990)
            
            //--TRIMMABLE-BOUNDARY-START(30065946286)
            /*OneOf<byte[], ReadOnlyMemory<byte>, Stream>*/ Data;
            //--TRIMMABLE-BOUNDARY-END(30065946286)
            
            //--TRIMMABLE-BOUNDARY-START(77310586542)
            /*void */ Reply(/*byte[]*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310586542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$KuVO.LCFCC.ConnectionInterfaceExtension.Write$1(this.Client.LCFCC$IConnectionClient$Interface, this.Client, new $.$KuVO.LCFCC.ConnectionMessage().$ctor$1(this.Client.LCFCC$IConnectionClient$Interface, this.Client, 1/*MessageDirection.Out*/, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit(bytes)), true);
            }
            //--TRIMMABLE-BOUNDARY-END(77310586542)
            
            //--TRIMMABLE-BOUNDARY-START(107375357614)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375357614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `Direction: ${$.$strNN($.$$.S.Enum.ToStringT($.$KuVO.LCFCC.MessageDirection, $.$$.S.UInt32, this.Direction))}, Client: ${$.$strNN($.$dsp(this.Client, $.$$.S.Object, ($t) => $t.ToString))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(107375357614)
            
            //--TRIMMABLE-BOUNDARY-START(21476798126)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage.Client.get
            get LCFCC$IConnectionMessage$Client()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296928942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Client;
            }
            //--TRIMMABLE-BOUNDARY-END(21476798126)
            
            //--TRIMMABLE-BOUNDARY-START(38656667310)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage.Direction.get
            get LCFCC$IConnectionMessage$Direction()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886863534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Direction;
            }
            //--TRIMMABLE-BOUNDARY-END(38656667310)
            
            //--TRIMMABLE-BOUNDARY-START(47246601902)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage.Id.get
            get LCFCC$IConnectionMessage$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541569198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(47246601902)
            
            //--TRIMMABLE-BOUNDARY-START(30066732718)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage.Data.get
            get LCFCC$IConnectionMessage$Data()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591896238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Data;
            }
            //--TRIMMABLE-BOUNDARY-END(30066732718)
            
            //--TRIMMABLE-BOUNDARY-START(55836536494)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage.Reply(byte[])
            LCFCC$IConnectionMessage$Reply()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836536494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reply(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(55836536494)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30065946286)
                this.Data = $.$default($.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream));
                //--TRIMMABLE-BOUNDARY-END(30065946286)
                
            }
            static $h = 1175214;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360913582),
    {
      "p": 2289326,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130717358,
        "f": 50331649
      },
      "n": "Direction",
      "d": 1175214,
      "h": 34360913582,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360913582),
//--TRIMMABLE-BOUNDARY-START(73015619246),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720651950,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080390318,
        "f": 83886081
      },
      "n": "Id",
      "d": 1175214,
      "h": 73015619246,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015619246),
//--TRIMMABLE-BOUNDARY-START(25770978990),
    {
      "p": 1568430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950848174,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900521134,
        "f": 83886081
      },
      "n": "Client",
      "d": 1175214,
      "h": 25770978990,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770978990),
//--TRIMMABLE-BOUNDARY-START(30065946286),
    {
      "p": $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540782766,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490455726,
        "f": 83886081
      },
      "n": "Data",
      "d": 1175214,
      "h": 30065946286,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065946286)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310586542),
    {
      "r": 65537,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Reply",
      "d": 1175214,
      "h": 77310586542,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310586542),
//--TRIMMABLE-BOUNDARY-START(107375357614),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1175214,
      "h": 107375357614,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107375357614)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476011694),
    {
      "p": [
        {
          "n": "interface",
          "p": 1830574
        },
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "direction",
          "p": 2289326
        },
        {
          "n": "data",
          "p": $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1175214,
      "h": 21476011694,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476011694)
  ],
  "h": 1175214
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionMessage ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionMessage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionMessage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1175214)
        
        

        //--TRIMMABLE-BOUNDARY-START(519854)
        $asm.$cls(`$KuVO.LCFCC.ConnectionContext`, ($self) => class ConnectionContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(184684113582)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(184684113582)
            
            //--TRIMMABLE-BOUNDARY-START(201863982766)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(201863982766)
            
            //--TRIMMABLE-BOUNDARY-START(188979080878)
            /*string?*/ IP = null;
            //--TRIMMABLE-BOUNDARY-END(188979080878)
            
            //--TRIMMABLE-BOUNDARY-START(73014963886)
            /*string?*/ FamilyName = null;
            //--TRIMMABLE-BOUNDARY-END(73014963886)
            
            //--TRIMMABLE-BOUNDARY-START(206158950062)
            /*int*/ Port = 0;
            //--TRIMMABLE-BOUNDARY-END(206158950062)
            
            //--TRIMMABLE-BOUNDARY-START(193274048174)
            /*int*/ MaxConnections = 0;
            //--TRIMMABLE-BOUNDARY-END(193274048174)
            
            //--TRIMMABLE-BOUNDARY-START(197569015470)
            /*byte[]?*/ MessageDelimiter = null;
            //--TRIMMABLE-BOUNDARY-END(197569015470)
            
            //--TRIMMABLE-BOUNDARY-START(60130061998)
            /*SymmetricAlgorithm?*/ Algorithm = null;
            //--TRIMMABLE-BOUNDARY-END(60130061998)
            
            //--TRIMMABLE-BOUNDARY-START(68719996590)
            /*byte[]?*/ EncryptionKey = null;
            //--TRIMMABLE-BOUNDARY-END(68719996590)
            
            //--TRIMMABLE-BOUNDARY-START(64425029294)
            /*int*/ BufferSize = 0;
            //--TRIMMABLE-BOUNDARY-END(64425029294)
            
            //--TRIMMABLE-BOUNDARY-START(210453917358)
            /*int*/ ReceiveFrequencyLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(210453917358)
            
            //--TRIMMABLE-BOUNDARY-START(77309931182)
            /*ConnectionFlags*/ Flags = 0;
            //--TRIMMABLE-BOUNDARY-END(77309931182)
            
            //--TRIMMABLE-BOUNDARY-START(317828099758)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828099758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Id)}(${$.$strNN(this.Name)})`;
            }
            //--TRIMMABLE-BOUNDARY-END(317828099758)
            
            //--TRIMMABLE-BOUNDARY-START(73016077998)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.Id.get
            get LCFCC$IConnectionContext$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850652846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(73016077998)
            
            //--TRIMMABLE-BOUNDARY-START(107375816366)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.Name.get
            get LCFCC$IConnectionContext$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030522030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(107375816366)
            
            //--TRIMMABLE-BOUNDARY-START(55836208814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.FamilyName.get
            get LCFCC$IConnectionContext$FamilyName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181503150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FamilyName;
            }
            //--TRIMMABLE-BOUNDARY-END(55836208814)
            
            //--TRIMMABLE-BOUNDARY-START(81606012590)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.IP.get
            get LCFCC$IConnectionContext$IP()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145620142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IP;
            }
            //--TRIMMABLE-BOUNDARY-END(81606012590)
            
            //--TRIMMABLE-BOUNDARY-START(115965750958)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.Port.get
            get LCFCC$IConnectionContext$Port()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325489326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Port;
            }
            //--TRIMMABLE-BOUNDARY-END(115965750958)
            
            //--TRIMMABLE-BOUNDARY-START(90195947182)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.MaxConnections.get
            get LCFCC$IConnectionContext$MaxConnections()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440587438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MaxConnections;
            }
            //--TRIMMABLE-BOUNDARY-END(90195947182)
            
            //--TRIMMABLE-BOUNDARY-START(98785881774)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.MessageDelimiter.get
            get LCFCC$IConnectionContext$MessageDelimiter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735554734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MessageDelimiter;
            }
            //--TRIMMABLE-BOUNDARY-END(98785881774)
            
            //--TRIMMABLE-BOUNDARY-START(30066405038)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.Algorithm.get
            get LCFCC$IConnectionContext$Algorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296601262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Algorithm;
            }
            //--TRIMMABLE-BOUNDARY-END(30066405038)
            
            //--TRIMMABLE-BOUNDARY-START(47246274222)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.EncryptionKey.get
            get LCFCC$IConnectionContext$EncryptionKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886535854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EncryptionKey;
            }
            //--TRIMMABLE-BOUNDARY-END(47246274222)
            
            //--TRIMMABLE-BOUNDARY-START(38656339630)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.BufferSize.get
            get LCFCC$IConnectionContext$BufferSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591568558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BufferSize;
            }
            //--TRIMMABLE-BOUNDARY-END(38656339630)
            
            //--TRIMMABLE-BOUNDARY-START(124555685550)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.ReceiveFrequencyLimit.get
            get LCFCC$IConnectionContext$ReceiveFrequencyLimit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620456622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReceiveFrequencyLimit;
            }
            //--TRIMMABLE-BOUNDARY-END(124555685550)
            
            //--TRIMMABLE-BOUNDARY-START(64426143406)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionContext.Flags.get
            get LCFCC$IConnectionContext$Flags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476470446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Flags;
            }
            //--TRIMMABLE-BOUNDARY-END(64426143406)
            
            //--TRIMMABLE-BOUNDARY-START(55835094702)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835094702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835094702)
            
            //--TRIMMABLE-BOUNDARY-START(55835094702)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(55835094702)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(193274048174)
                this.MaxConnections = 2147483647;
                //--TRIMMABLE-BOUNDARY-END(193274048174)
                
                //--TRIMMABLE-BOUNDARY-START(64425029294)
                this.BufferSize = 1024;
                //--TRIMMABLE-BOUNDARY-END(64425029294)
                
            }
            static $h = 519854;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(184684113582),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849538734,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993524910,
        "f": 83886081
      },
      "n": "Id",
      "d": 519854,
      "h": 184684113582,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684113582),
//--TRIMMABLE-BOUNDARY-START(201863982766),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209277102,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353263278,
        "f": 83886081
      },
      "n": "Name",
      "d": 519854,
      "h": 201863982766,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201863982766),
//--TRIMMABLE-BOUNDARY-START(188979080878),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439473326,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583459502,
        "f": 83886081
      },
      "n": "IP",
      "d": 519854,
      "h": 188979080878,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188979080878),
//--TRIMMABLE-BOUNDARY-START(73014963886),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669669550,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813655726,
        "f": 83886081
      },
      "n": "FamilyName",
      "d": 519854,
      "h": 73014963886,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014963886),
//--TRIMMABLE-BOUNDARY-START(206158950062),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799211694,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943197870,
        "f": 83886081
      },
      "n": "Port",
      "d": 519854,
      "h": 206158950062,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206158950062),
//--TRIMMABLE-BOUNDARY-START(193274048174),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029407918,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173394094,
        "f": 83886081
      },
      "n": "MaxConnections",
      "d": 519854,
      "h": 193274048174,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274048174),
//--TRIMMABLE-BOUNDARY-START(197569015470),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619342510,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763328686,
        "f": 83886081
      },
      "n": "MessageDelimiter",
      "d": 519854,
      "h": 197569015470,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569015470),
//--TRIMMABLE-BOUNDARY-START(60130061998),
    {
      "p": 23199774,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899865774,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219043851950,
        "f": 83886081
      },
      "n": "Algorithm",
      "d": 519854,
      "h": 60130061998,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130061998),
//--TRIMMABLE-BOUNDARY-START(68719996590),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079734958,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236223721134,
        "f": 83886081
      },
      "n": "EncryptionKey",
      "d": 519854,
      "h": 68719996590,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719996590),
//--TRIMMABLE-BOUNDARY-START(64425029294),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489800366,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633786542,
        "f": 83886081
      },
      "n": "BufferSize",
      "d": 519854,
      "h": 64425029294,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425029294),
//--TRIMMABLE-BOUNDARY-START(210453917358),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389146286,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313533132462,
        "f": 83886081
      },
      "n": "ReceiveFrequencyLimit",
      "d": 519854,
      "h": 210453917358,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210453917358),
//--TRIMMABLE-BOUNDARY-START(77309931182),
    {
      "p": 847534,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259604142,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253403590318,
        "f": 83886081
      },
      "n": "Flags",
      "d": 519854,
      "h": 77309931182,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309931182)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(317828099758),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 519854,
      "h": 317828099758,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(317828099758)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835094702),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 519854,
      "h": 55835094702,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835094702)
  ],
  "h": 519854
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionContext ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(519854)
        
        

        //--TRIMMABLE-BOUNDARY-START(2485934)
        $asm.$cls(`$KuVO.LCFCC.RemoteClientConnectionProxy`, ($self) => class RemoteClientConnectionProxy extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297453230)
            /*IServerRemoteService*/ _server = null;
            //--TRIMMABLE-BOUNDARY-END(4297453230)
            
            //--TRIMMABLE-BOUNDARY-START(17182355118)
            /*ConcurrentDictionary<ClientConnectionIdentity, IConnectionClient>*/ clients = null;
            //--TRIMMABLE-BOUNDARY-END(17182355118)
            
            //--TRIMMABLE-BOUNDARY-START(8592420526)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592420526);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592420526)
            
            //--TRIMMABLE-BOUNDARY-START(206160916142)
            /*IConnectionInterface*/ get_Item$2(/*IConnectionContext*/ context)
            {
                return this;
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(206160916142)
            
            //--TRIMMABLE-BOUNDARY-START(201865948846)
            /*IConnectionClient*/ get_Item$1(/*ClientConnectionIdentity*/ clientId)
            {
                return this.clients.GetOrAdd($.$clone(clientId), new ($.$$.S.Func$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.IConnectionClient))().$ctor(this,  (/*clientId*/ clientId) =>
                {
                    return (() =>
                    {
                        //new $.$KuVO.LCFCC.ConnectionClient$$($.$$.S.Object)()
                        const $t1 = $.$KuVO.LCFCC.ConnectionClient$$($.$$.S.Object);
                        const $i1 = new $t1();
                        $i1.$ctor$3(this, null, null);
                        $i1.Id = $.$clone(clientId);
                        $i1.LocalEndPoint = "proxy";
                        $i1.RemoteEndPoint = clientId.ToString();
                        return $i1;
                    })();
                }, $gctltb ??= {"r":1568430,"p":[{"n":"clientId","p":323246}],"n":"","d":2485934,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(201865948846)
            
            //--TRIMMABLE-BOUNDARY-START(210455883438)
            /*IConnectionClient*/ get_Item$3(/*string*/ clientId)
            {
                return this.get_Item$1($.$KuVO.LCFCC.ClientConnectionIdentity.IdentifyConnection(clientId));
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(210455883438)
            
            //--TRIMMABLE-BOUNDARY-START(146031373998)
            /*IEnumerable<IConnectionInterface> */ get Interfaces()
            {
                return $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$KuVO.LCFCC.RemoteClientConnectionProxy), [this], null, null), $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.RemoteClientConnectionProxy), $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionInterface));
            }
            //--TRIMMABLE-BOUNDARY-END(146031373998)
            
            //--TRIMMABLE-BOUNDARY-START(141736406702)
            /*string */ get Id()
            {
                return "RemoteClientConnectionProxy";
            }
            //--TRIMMABLE-BOUNDARY-END(141736406702)
            
            //--TRIMMABLE-BOUNDARY-START(163211243182)
            /*string */ get Name()
            {
                return "RemoteClientConnectionProxy";
            }
            //--TRIMMABLE-BOUNDARY-END(163211243182)
            
            //--TRIMMABLE-BOUNDARY-START(30067257006)
            /*IConnectionContext? */ get Context()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(30067257006)
            
            //--TRIMMABLE-BOUNDARY-START(158916275886)
            /*IConnectionManager */ get Manager()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(158916275886)
            
            //--TRIMMABLE-BOUNDARY-START(150326341294)
            /*bool */ get IsRunning()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(150326341294)
            
            //--TRIMMABLE-BOUNDARY-START(154621308590)
            /*string? */ get LocalAddress()
            {
                return "localhost";
            }
            //--TRIMMABLE-BOUNDARY-END(154621308590)
            
            //--TRIMMABLE-BOUNDARY-START(21477322414)
            /*IEnumerable<IConnectionClient> */ get Clients()
            {
                return this.clients.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(21477322414)
            
            //--TRIMMABLE-BOUNDARY-START(25772289710)
            /*Task<IConnectionClient?> */ ConnectTo(/*IConnectionContext*/ context, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772289710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(25772289710)
            
            //--TRIMMABLE-BOUNDARY-START(34362224302)
            /*void */ DiscardInBuffer(/*IConnectionClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362224302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34362224302)
            
            //--TRIMMABLE-BOUNDARY-START(38657191598)
            /*void */ Disconnect(/*IConnectionClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657191598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38657191598)
            
            //--TRIMMABLE-BOUNDARY-START(42952158894)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952158894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42952158894)
            
            //--TRIMMABLE-BOUNDARY-START(171801177774)
            /*Task */ RouteMessageToDevice(/*IConnectionClient*/ router, /*ClientConnectionIdentity*/ deviceId, /*IConnectionMessage*/ data, /*Func<IConnectionMessage, IConnectionMessage>*/ encodeSendData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801177774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(171801177774)
            
            //--TRIMMABLE-BOUNDARY-START(176096145070)
            /*Task */ StartAsync(/*IConnectionContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096145070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(176096145070)
            
            //--TRIMMABLE-BOUNDARY-START(184686079662)
            /*ValueTask<IConnectionInterface?> */ StartServer$1(/*IConnectionContext*/ context, /*IConnectionEndPoint*/ endpoint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184686079662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$KuVO.LCFCC.IConnectionInterface, this);
            }
            //--TRIMMABLE-BOUNDARY-END(184686079662)
            
            //--TRIMMABLE-BOUNDARY-START(180391112366)
            /*ValueTask<IConnectionInterface?> */ StartServer(/*IConnectionContext*/ context, /*ConnectionEndPointProviderFactory*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391112366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$KuVO.LCFCC.IConnectionInterface, this);
            }
            //--TRIMMABLE-BOUNDARY-END(180391112366)
            
            //--TRIMMABLE-BOUNDARY-START(188981046958)
            /*ValueTask<IConnectionInterface?> */ StartServer$2(TConnectionEndPoint, /*IConnectionContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981046958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$KuVO.LCFCC.IConnectionInterface, this);
            }
            //--TRIMMABLE-BOUNDARY-END(188981046958)
            
            //--TRIMMABLE-BOUNDARY-START(197570981550)
            /*void */ Stop$1(/*IConnectionContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570981550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(197570981550)
            
            //--TRIMMABLE-BOUNDARY-START(193276014254)
            /*void */ Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276014254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(193276014254)
            
            //--TRIMMABLE-BOUNDARY-START(214750850734)
            /*Task *//*async*/  Write(/*OneOf<IConnectionClient, ClientConnectionIdentity>*/ client, /*IConnectionMessage*/ data, /*bool*/ withPipeline)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214750850734);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$KuVO.LCFCC.IRemoteClientConnectionRemoteService, this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$KuVO.LCFCC.IRemoteClientConnectionRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCFCC$IRemoteClientConnectionRemoteService$Write(client.Match($.$$.S.String, new ($.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionClient, $.$$.S.String))().$ctor(this,  (/**/ c) =>
                        {
                            return c.LCFCC$IConnectionClient$Id.Id;
                        }, $ZXvQUd ??= {"r":1310721,"p":[{"n":"c","p":1568430}],"n":"","d":2485934,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$$.S.String))().$ctor(this,  (/**/ c) =>
                        {
                            return c.Id;
                        }, $Ladbua ??= {"r":1310721,"p":[{"n":"c","p":323246}],"n":"","d":2485934,"h":0,"f":17825794})), $.$KuVO.LCFCC.ConnectonInterfaceExtension.ToBytes(data.LCFCC$IConnectionMessage$Data), data.LCFCC$IConnectionMessage$Id, withPipeline);
                    }, $xGEXve ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"server","p":2092718}],"n":"","d":2485934,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(214750850734)
            
            //--TRIMMABLE-BOUNDARY-START(219045818030)
            /*Task<IConnectionMessage> *//*async*/  WriteRead(/*IConnectionClient*/ client, /*IConnectionMessage*/ data, /*TimeSpan*/ timeout)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage), $.$KuVO.LCFCC.IConnectionMessage, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(219045818030);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let bytes = ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$KuVO.LCFCC.IRemoteClientConnectionRemoteService, $.$typeArray($.$$.S.Byte), this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$KuVO.LCFCC.IRemoteClientConnectionRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$typeArray($.$$.S.Byte))))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCFCC$IRemoteClientConnectionRemoteService$WriteRead(client.LCFCC$IConnectionClient$Id.Id, $.$KuVO.LCFCC.ConnectonInterfaceExtension.ToBytes(data.LCFCC$IConnectionMessage$Data), data.LCFCC$IConnectionMessage$Id, timeout);
                    }, $PQGhTj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$typeArray($.$$.S.Byte))).$h,"p":[{"n":"server","p":2092718}],"n":"","d":2485934,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                    {
                        //new $.$KuVO.LCFCC.ConnectionMessage()
                        const $t4 = $.$KuVO.LCFCC.ConnectionMessage;
                        const $i4 = new $t4();
                        $i4.$ctor$1(this, client, 0/*MessageDirection.In*/, $.$fPer.LCFCO.OneOf$$$$($.$typeArray($.$$.S.Byte), $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.SI.Stream).op_Implicit(bytes));
                        $i4.Id = data.LCFCC$IConnectionMessage$Id;
                        return $i4;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(219045818030)
            
            //--TRIMMABLE-BOUNDARY-START(12887387822)
            /*void */ Broadcast(/*IConnectionMessage*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887387822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(12887387822)
            
            //--TRIMMABLE-BOUNDARY-START(167506210478)
            /*Task<IConnectionMessage> */ Read(/*OneOf<IConnectionClient, ClientConnectionIdentity>*/ clientId, /*TimeSpan*/ timeOut)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506210478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(167506210478)
            
            //--TRIMMABLE-BOUNDARY-START(4296863406)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.ConnectTo(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext, System.Threading.CancellationToken)
            LCFCC$IConnectionManager$ConnectTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296863406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ConnectTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296863406)
            
            //--TRIMMABLE-BOUNDARY-START(38656601774)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.StartServer(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext, LivingThing.Core.Frameworks.Common.Connection.IConnectionEndPoint?)
            LCFCC$IConnectionManager$StartServer$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656601774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartServer$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38656601774)
            
            //--TRIMMABLE-BOUNDARY-START(34361634478)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.StartServer(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext, LivingThing.Core.Frameworks.Common.Connection.ConnectionEndPointProviderFactory?)
            LCFCC$IConnectionManager$StartServer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361634478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartServer(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34361634478)
            
            //--TRIMMABLE-BOUNDARY-START(42951569070)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.StartServer<TConnectionEndPoint>(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext)
            LCFCC$IConnectionManager$StartServer$2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951569070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartServer$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42951569070)
            
            //--TRIMMABLE-BOUNDARY-START(8591830702)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.Disconnect(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient)
            LCFCC$IConnectionManager$Disconnect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591830702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Disconnect(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591830702)
            
            //--TRIMMABLE-BOUNDARY-START(47246536366)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.Stop(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext)
            LCFCC$IConnectionManager$Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246536366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Stop$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47246536366)
            
            //--TRIMMABLE-BOUNDARY-START(17181765294)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.Interfaces.get
            get LCFCC$IConnectionManager$Interfaces()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066667182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Interfaces;
            }
            //--TRIMMABLE-BOUNDARY-END(17181765294)
            
            //--TRIMMABLE-BOUNDARY-START(25771699886)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionManager.this[LivingThing.Core.Frameworks.Common.Connection.IConnectionContext].get
            LCFCC$IConnectionManager$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771699886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25771699886)
            
            //--TRIMMABLE-BOUNDARY-START(42951503534)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Id.get
            get LCFCC$IConnectionInterface$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196143790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(42951503534)
            
            //--TRIMMABLE-BOUNDARY-START(85901176494)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Name.get
            get LCFCC$IConnectionInterface$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376012974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(85901176494)
            
            //--TRIMMABLE-BOUNDARY-START(68721307310)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.LocalAddress.get
            get LCFCC$IConnectionInterface$LocalAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786078382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LocalAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(68721307310)
            
            //--TRIMMABLE-BOUNDARY-START(34361568942)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Context.get
            get LCFCC$IConnectionInterface$Context()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886732462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Context;
            }
            //--TRIMMABLE-BOUNDARY-END(34361568942)
            
            //--TRIMMABLE-BOUNDARY-START(77311241902)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Manager.get
            get LCFCC$IConnectionInterface$Manager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081045678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Manager;
            }
            //--TRIMMABLE-BOUNDARY-END(77311241902)
            
            //--TRIMMABLE-BOUNDARY-START(51541438126)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.IsRunning.get
            get LCFCC$IConnectionInterface$IsRunning()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491111086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsRunning;
            }
            //--TRIMMABLE-BOUNDARY-END(51541438126)
            
            //--TRIMMABLE-BOUNDARY-START(25771634350)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Clients.get
            get LCFCC$IConnectionInterface$Clients()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591765166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clients;
            }
            //--TRIMMABLE-BOUNDARY-END(25771634350)
            
            //--TRIMMABLE-BOUNDARY-START(60131372718)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.this[LivingThing.Core.Frameworks.Common.Connection.ClientConnectionIdentity].get
            LCFCC$IConnectionInterface$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131372718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60131372718)
            
            //--TRIMMABLE-BOUNDARY-START(120260914862)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.StartAsync(LivingThing.Core.Frameworks.Common.Connection.IConnectionContext)
            LCFCC$IConnectionInterface$StartAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260914862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.StartAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(120260914862)
            
            //--TRIMMABLE-BOUNDARY-START(17181699758)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Disconnect(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient)
            LCFCC$IConnectionInterface$Disconnect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181699758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Disconnect(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17181699758)
            
            //--TRIMMABLE-BOUNDARY-START(124555882158)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Stop()
            LCFCC$IConnectionInterface$Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555882158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Stop(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(124555882158)
            
            //--TRIMMABLE-BOUNDARY-START(133145816750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Write(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Connection.ClientConnectionIdentity>, LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, bool)
            LCFCC$IConnectionInterface$Write()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145816750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Write(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(133145816750)
            
            //--TRIMMABLE-BOUNDARY-START(111670980270)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Read(LivingThing.Core.Frameworks.Common.OneOf.OneOf<LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Connection.ClientConnectionIdentity>, System.TimeSpan)
            LCFCC$IConnectionInterface$Read()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670980270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Read(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(111670980270)
            
            //--TRIMMABLE-BOUNDARY-START(137440784046)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.WriteRead(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, System.TimeSpan)
            LCFCC$IConnectionInterface$WriteRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440784046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.WriteRead(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(137440784046)
            
            //--TRIMMABLE-BOUNDARY-START(4296797870)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.Broadcast(LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage)
            LCFCC$IConnectionInterface$Broadcast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296797870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Broadcast(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296797870)
            
            //--TRIMMABLE-BOUNDARY-START(115965947566)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionInterface.RouteMessageToDevice(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, LivingThing.Core.Frameworks.Common.Connection.ClientConnectionIdentity, LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, System.Func<LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage>)
            LCFCC$IConnectionInterface$RouteMessageToDevice()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965947566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RouteMessageToDevice(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(115965947566)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17182355118)
                this.clients = new ($.$scc.SCC.ConcurrentDictionary$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.IConnectionClient))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17182355118)
                
            }
            static $h = 2485934;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(206160916142),
    {
      "p": 1830574,
      "i": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081701038,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 2485934,
      "h": 206160916142,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(206160916142),
//--TRIMMABLE-BOUNDARY-START(201865948846),
    {
      "p": 1568430,
      "i": [
        {
          "n": "clientId",
          "p": 323246
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491766446,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 2485934,
      "h": 201865948846,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(201865948846),
//--TRIMMABLE-BOUNDARY-START(210455883438),
    {
      "p": 1568430,
      "i": [
        {
          "n": "clientId",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671635630,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$3",
      "d": 2485934,
      "h": 210455883438,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(210455883438),
//--TRIMMABLE-BOUNDARY-START(146031373998),
    {
      "p": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311897262,
        "f": 50331649
      },
      "n": "Interfaces",
      "d": 2485934,
      "h": 146031373998,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146031373998),
//--TRIMMABLE-BOUNDARY-START(141736406702),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721962670,
        "f": 50331649
      },
      "n": "Id",
      "d": 2485934,
      "h": 141736406702,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141736406702),
//--TRIMMABLE-BOUNDARY-START(163211243182),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137441439406,
        "f": 50331649
      },
      "n": "Name",
      "d": 2485934,
      "h": 163211243182,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163211243182),
//--TRIMMABLE-BOUNDARY-START(30067257006),
    {
      "p": 1633966,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132028078,
        "f": 50331649
      },
      "n": "Context",
      "d": 2485934,
      "h": 30067257006,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067257006),
//--TRIMMABLE-BOUNDARY-START(158916275886),
    {
      "p": 1896110,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851504814,
        "f": 50331649
      },
      "n": "Manager",
      "d": 2485934,
      "h": 158916275886,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158916275886),
//--TRIMMABLE-BOUNDARY-START(150326341294),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901831854,
        "f": 50331649
      },
      "n": "IsRunning",
      "d": 2485934,
      "h": 150326341294,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150326341294),
//--TRIMMABLE-BOUNDARY-START(154621308590),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261570222,
        "f": 50331649
      },
      "n": "LocalAddress",
      "d": 2485934,
      "h": 154621308590,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154621308590),
//--TRIMMABLE-BOUNDARY-START(21477322414),
    {
      "p": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542093486,
        "f": 50331649
      },
      "n": "Clients",
      "d": 2485934,
      "h": 21477322414,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477322414)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772289710),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionClient).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "ConnectTo",
      "d": 2485934,
      "h": 25772289710,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772289710),
//--TRIMMABLE-BOUNDARY-START(34362224302),
    {
      "r": 65537,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "DiscardInBuffer",
      "d": 2485934,
      "h": 34362224302,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362224302),
//--TRIMMABLE-BOUNDARY-START(38657191598),
    {
      "r": 65537,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "Disconnect",
      "d": 2485934,
      "h": 38657191598,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657191598),
//--TRIMMABLE-BOUNDARY-START(42952158894),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2485934,
      "h": 42952158894,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952158894),
//--TRIMMABLE-BOUNDARY-START(171801177774),
    {
      "r": 178454529,
      "p": [
        {
          "n": "router",
          "p": 1568430
        },
        {
          "n": "deviceId",
          "p": 323246
        },
        {
          "n": "data",
          "p": 1961646
        },
        {
          "n": "encodeSendData",
          "p": $.$$.S.Func$$$($.$KuVO.LCFCC.IConnectionMessage, $.$KuVO.LCFCC.IConnectionMessage).$h
        }
      ],
      "n": "RouteMessageToDevice",
      "d": 2485934,
      "h": 171801177774,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171801177774),
//--TRIMMABLE-BOUNDARY-START(176096145070),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "n": "StartAsync",
      "d": 2485934,
      "h": 176096145070,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176096145070),
//--TRIMMABLE-BOUNDARY-START(184686079662),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "endpoint",
          "p": 1765038
        }
      ],
      "n": "StartServer",
      "o": "@$1",
      "d": 2485934,
      "h": 184686079662,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184686079662),
//--TRIMMABLE-BOUNDARY-START(180391112366),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        },
        {
          "n": "factory",
          "p": 650926
        }
      ],
      "n": "StartServer",
      "d": 2485934,
      "h": 180391112366,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180391112366),
//--TRIMMABLE-BOUNDARY-START(188981046958),
    {
      "r": $.$$.STT.ValueTask$$($.$KuVO.LCFCC.IConnectionInterface).$h,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "g": [
        "TConnectionEndPoint"
      ],
      "n": "StartServer",
      "o": "@$2",
      "d": 2485934,
      "h": 188981046958,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(188981046958),
//--TRIMMABLE-BOUNDARY-START(197570981550),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 1633966
        }
      ],
      "n": "Stop",
      "o": "@$1",
      "d": 2485934,
      "h": 197570981550,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197570981550),
//--TRIMMABLE-BOUNDARY-START(193276014254),
    {
      "r": 65537,
      "n": "Stop",
      "d": 2485934,
      "h": 193276014254,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193276014254),
//--TRIMMABLE-BOUNDARY-START(214750850734),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": $.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).$h
        },
        {
          "n": "data",
          "p": 1961646
        },
        {
          "n": "withPipeline",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Write",
      "d": 2485934,
      "h": 214750850734,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(214750850734),
//--TRIMMABLE-BOUNDARY-START(219045818030),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "data",
          "p": 1961646
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "n": "WriteRead",
      "d": 2485934,
      "h": 219045818030,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(219045818030),
//--TRIMMABLE-BOUNDARY-START(12887387822),
    {
      "r": 65537,
      "p": [
        {
          "n": "data",
          "p": 1961646
        }
      ],
      "n": "Broadcast",
      "d": 2485934,
      "h": 12887387822,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887387822),
//--TRIMMABLE-BOUNDARY-START(167506210478),
    {
      "r": $.$$.STT.Task$$($.$KuVO.LCFCC.IConnectionMessage).$h,
      "p": [
        {
          "n": "clientId",
          "p": $.$fPer.LCFCO.OneOf$$$($.$KuVO.LCFCC.IConnectionClient, $.$KuVO.LCFCC.ClientConnectionIdentity).$h
        },
        {
          "n": "timeOut",
          "p": 186646529
        }
      ],
      "n": "Read",
      "d": 2485934,
      "h": 167506210478,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167506210478)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297453230),
    {
      "t": 1309651,
      "n": "_server",
      "d": 2485934,
      "h": 4297453230,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297453230),
//--TRIMMABLE-BOUNDARY-START(17182355118),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$KuVO.LCFCC.ClientConnectionIdentity, $.$KuVO.LCFCC.IConnectionClient).$h,
      "n": "clients",
      "d": 2485934,
      "h": 17182355118,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182355118)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592420526),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2485934,
      "h": 8592420526,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592420526)
  ],
  "h": 2485934
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionManager, $.$KuVO.LCFCC.IConnectionInterface, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.RemoteClientConnectionProxy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}RemoteClientConnectionProxy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2485934)
        
        

        //--TRIMMABLE-BOUNDARY-START(323246)
        $asm.$str(`$KuVO.LCFCC.ClientConnectionIdentity`, ($self) => class ClientConnectionIdentity extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(68719799982)
            /*string?*/ id = null;
            //--TRIMMABLE-BOUNDARY-END(68719799982)
            
            //--TRIMMABLE-BOUNDARY-START(73014767278)
            /*string */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949996206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.id ?? this.ToString();
            }
            /*string */ set Id(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374505646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.id = value;
            }
            //--TRIMMABLE-BOUNDARY-END(73014767278)
            
            //--TRIMMABLE-BOUNDARY-START(25770127022)
            /*string?*/ FamilyName = null;
            //--TRIMMABLE-BOUNDARY-END(25770127022)
            
            //--TRIMMABLE-BOUNDARY-START(133144309422)
            /*string*/ UniqueId = null;
            //--TRIMMABLE-BOUNDARY-END(133144309422)
            
            //--TRIMMABLE-BOUNDARY-START(90194636462)
            /*string?*/ Scope = null;
            //--TRIMMABLE-BOUNDARY-END(90194636462)
            
            //--TRIMMABLE-BOUNDARY-START(128849342126)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849342126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN((this.Scope !== null ? $.$strNN(this.Scope) + "/" : ""))}${$.$strNN((this.FamilyName !== null ? $.$strNN(this.FamilyName) + "/" : ""))}${$.$strNN(this.UniqueId)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(128849342126)
            
            //--TRIMMABLE-BOUNDARY-START(64424832686)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424832686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.id !== null)
                {
                    return $.$$.S.String.GetHashCode.call(this.id);
                }
                return $.$$.S.HashCode.Combine$4($.$$.S.String, $.$$.S.String, $.$$.S.String, $.$$.S.String, this.Id, this.FamilyName, this.UniqueId, this.Scope);
            }
            //--TRIMMABLE-BOUNDARY-END(64424832686)
            
            //--TRIMMABLE-BOUNDARY-START(21475159726)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475159726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let c2;
                if ($.$is(obj, $.$KuVO.LCFCC.ClientConnectionIdentity, { set $v($v){ c2 = $v; } }))
                {
                    if (this.id !== null && c2.id !== null)
                    {
                        return this.id === c2.id;
                    }
                    return this.Id === c2.id && this.FamilyName === c2.FamilyName && this.UniqueId === c2.UniqueId && this.Scope === c2.Scope;
                }
                return super.Equals$1(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(21475159726)
            
            //--TRIMMABLE-BOUNDARY-START(81604701870)
            static /*bool */ op_Equality(/*ClientConnectionIdentity*/ id1, /*ClientConnectionIdentity*/ id2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604701870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (id1.id !== null && id2.id !== null)
                {
                    return id1.id === id2.id;
                }
                return id1.FamilyName === id2.FamilyName && id1.UniqueId === id2.UniqueId;
            }
            //--TRIMMABLE-BOUNDARY-END(81604701870)
            
            //--TRIMMABLE-BOUNDARY-START(85899669166)
            static /*bool */ op_Inequality(/*ClientConnectionIdentity*/ id1, /*ClientConnectionIdentity*/ id2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899669166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (id1.id !== null && id2.id !== null)
                {
                    return id1.id !== id2.id;
                }
                return id1.FamilyName !== id2.FamilyName || id1.UniqueId !== id2.UniqueId;
            }
            //--TRIMMABLE-BOUNDARY-END(85899669166)
            
            //--TRIMMABLE-BOUNDARY-START(77309734574)
            static /*ClientConnectionIdentity */ IdentifyConnection(/*string*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309734574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let splits = $.$sl.SL.Enumerable.ToArray($.$$.S.String, $.$sl.SL.Enumerable.Where($.$$.S.String, $.$$.S.String.Split$5.call($.$$.S.String.Trim$3.call(id, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /*/*/ 47, /*\\*/ 92 ])), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*/*/ 47, /*\\*/ 92], [-1], null)), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return !$.$$.S.String.StartsWith$3.call(e, "__test");
                }, $RsVRmk ??= {"r":262145,"p":[{"n":"e","p":1310721}],"n":"","d":323246,"h":0,"f":17825794})));
                /*int*/ let uniqueIdIndex = 2;
                /*int*/ let familyNameIndex = 1;
                /*int*/ let scopeIndex = 0;
                if (splits.length === 1)
                {
                    uniqueIdIndex = 0;
                    familyNameIndex = -1;
                    scopeIndex = -1;
                }
                else if (splits.length === 2)
                {
                    familyNameIndex = 0;
                    uniqueIdIndex = 1;
                    scopeIndex = -1;
                }
                /*string?*/ let family = familyNameIndex >= 0 ? $.$$.System.Array.$ReadT1.call(splits, familyNameIndex) : null;
                /*string?*/ let scope = scopeIndex >= 0 ? $.$$.System.Array.$ReadT1.call(splits, 0) : null;
                if (scope === "_")
                {
                    scope = null;
                }
                /*string?*/ let __ca1__;
                if ((__ca1__ = family) !== null ? $.$$.S.String.Contains$3.call(__ca1__, "@") : false)
                {
                    /*var*/ let ss = $.$$.S.String.Split$1.call(family, /*@*/ 64, 0);
                    scope = $.$$.System.Array.$ReadT1.call(ss, 0);
                    family = $.$$.System.Array.$ReadT1.call(ss, 1);
                }
                /*string*/ let uid = $.$$.System.Array.$ReadT1.call(splits, uniqueIdIndex);
                /*string*/ let fid = `${$.$strNN(family)}/${$.$strNN(uid)}`;
                return (() =>
                {
                    //new $.$KuVO.LCFCC.ClientConnectionIdentity()
                    const $t1 = $.$KuVO.LCFCC.ClientConnectionIdentity;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Scope = scope;
                    $i1.FamilyName = family;
                    $i1.UniqueId = uid;
                    $i1.Id = fid;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(77309734574)
            
            //--TRIMMABLE-BOUNDARY-START(17180192430)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180192430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180192430)
            
            //--TRIMMABLE-BOUNDARY-START(17180192430)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180192430)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.id = this.id;
                copy.FamilyName = this.FamilyName;
                copy.UniqueId = this.UniqueId;
                copy.Scope = this.Scope;
                return copy;
            }
            static $h = 323246;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014767278),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949996206,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374505646,
        "f": 83886081
      },
      "n": "Id",
      "d": 323246,
      "h": 73014767278,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014767278),
//--TRIMMABLE-BOUNDARY-START(25770127022),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360061614,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784571054,
        "f": 83886081
      },
      "n": "FamilyName",
      "d": 323246,
      "h": 25770127022,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770127022),
//--TRIMMABLE-BOUNDARY-START(133144309422),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129865390,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554374830,
        "f": 83886081
      },
      "n": "UniqueId",
      "d": 323246,
      "h": 133144309422,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144309422),
//--TRIMMABLE-BOUNDARY-START(90194636462),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539930798,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964440238,
        "f": 83886081
      },
      "n": "Scope",
      "d": 323246,
      "h": 90194636462,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194636462)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128849342126),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 323246,
      "h": 128849342126,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128849342126),
//--TRIMMABLE-BOUNDARY-START(64424832686),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 323246,
      "h": 64424832686,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64424832686),
//--TRIMMABLE-BOUNDARY-START(21475159726),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 323246,
      "h": 21475159726,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475159726),
//--TRIMMABLE-BOUNDARY-START(77309734574),
    {
      "r": 323246,
      "p": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": "IdentifyConnection",
      "d": 323246,
      "h": 77309734574,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309734574)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68719799982),
    {
      "t": 1310721,
      "n": "id",
      "d": 323246,
      "h": 68719799982,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68719799982)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180192430),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 323246,
      "h": 17180192430,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180192430)
  ],
  "h": 323246
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ClientConnectionIdentity`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ClientConnectionIdentity`; }
        });
        //--TRIMMABLE-BOUNDARY-END(323246)
        
        

        //--TRIMMABLE-BOUNDARY-START(1044142)
        $asm.$cls(`$KuVO.LCFCC.ConnectionInterfaceFactory`, ($self) => class ConnectionInterfaceFactory extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*IConnectionInterface*/ Invoke(/**/ manager, /**/ endPoint, /**/ connectionPipelines, /**/ messagePipelines)
            {
                return this.$nativeFunction.call(this.$target, manager, endPoint, connectionPipelines, messagePipelines);
            }
            static $h = 1044142;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180913326),
    {
      "r": 1830574,
      "p": [
        {
          "n": "manager",
          "p": 1896110
        },
        {
          "n": "endPoint",
          "p": 1765038
        },
        {
          "n": "connectionPipelines",
          "p": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionClient).$h
        },
        {
          "n": "messagePipelines",
          "p": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionMessage).$h
        }
      ],
      "n": "Invoke",
      "d": 1044142,
      "h": 17180913326,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180913326),
//--TRIMMABLE-BOUNDARY-START(8590978734),
    {
      "r": 90570753,
      "p": [
        {
          "n": "manager",
          "p": 1896110
        },
        {
          "n": "endPoint",
          "p": 1765038
        },
        {
          "n": "connectionPipelines",
          "p": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionClient).$h
        },
        {
          "n": "messagePipelines",
          "p": $.$fXpo.LCFCPC.IPipelineCollection$$($.$KuVO.LCFCC.IConnectionMessage).$h
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1044142,
      "h": 8590978734,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590978734),
//--TRIMMABLE-BOUNDARY-START(12885946030),
    {
      "r": 1830574,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 1044142,
      "h": 12885946030,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885946030)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296011438),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1044142,
      "h": 4296011438,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296011438)
  ],
  "h": 1044142
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionInterfaceFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionInterfaceFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1044142)
        
        

        //--TRIMMABLE-BOUNDARY-START(585390)
        $asm.$cls(`$KuVO.LCFCC.ConnectionEndPointProvider`, ($self) => class ConnectionEndPointProvider extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*IEnumerable<IConnectionEndPoint>*/ Invoke(/**/ serviceFactory)
            {
                return this.$nativeFunction.call(this.$target, serviceFactory);
            }
            static $h = 585390;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180454574),
    {
      "r": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionEndPoint).$h,
      "p": [
        {
          "n": "serviceFactory",
          "p": 61966678
        }
      ],
      "n": "Invoke",
      "d": 585390,
      "h": 17180454574,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180454574),
//--TRIMMABLE-BOUNDARY-START(8590519982),
    {
      "r": 90570753,
      "p": [
        {
          "n": "serviceFactory",
          "p": 61966678
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 585390,
      "h": 8590519982,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590519982),
//--TRIMMABLE-BOUNDARY-START(12885487278),
    {
      "r": $.$$.SCG.IEnumerable$$($.$KuVO.LCFCC.IConnectionEndPoint).$h,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 585390,
      "h": 12885487278,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885487278)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295552686),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 585390,
      "h": 4295552686,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295552686)
  ],
  "h": 585390
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionEndPointProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionEndPointProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(585390)
        
        

        //--TRIMMABLE-BOUNDARY-START(650926)
        $asm.$cls(`$KuVO.LCFCC.ConnectionEndPointProviderFactory`, ($self) => class ConnectionEndPointProviderFactory extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*ConnectionEndPointProvider*/ Invoke(/**/ client)
            {
                return this.$nativeFunction.call(this.$target, client);
            }
            static $h = 650926;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180520110),
    {
      "r": 585390,
      "p": [
        {
          "n": "client",
          "p": 1568430
        }
      ],
      "n": "Invoke",
      "d": 650926,
      "h": 17180520110,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180520110),
//--TRIMMABLE-BOUNDARY-START(8590585518),
    {
      "r": 90570753,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 650926,
      "h": 8590585518,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590585518),
//--TRIMMABLE-BOUNDARY-START(12885552814),
    {
      "r": 585390,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 650926,
      "h": 12885552814,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885552814)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295618222),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 650926,
      "h": 4295618222,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295618222)
  ],
  "h": 650926
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionEndPointProviderFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionEndPointProviderFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(650926)
        
        

        //--TRIMMABLE-BOUNDARY-START(2158254)
        $asm.$cls(`$KuVO.LCFCC.IRemoteClientConnectionRemoteService_Mocking`, ($self) => class IRemoteClientConnectionRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4297125550)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297125550);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297125550)
            
            //--TRIMMABLE-BOUNDARY-START(12887060142)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCFCC$IRemoteClientConnectionRemoteService$Write(/*string*/ clientId, /*byte[]*/ data, /*string?*/ messageId, /*bool*/ withPipeline)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887060142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$KuVO.LCFCC.IRemoteClientConnectionRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i1.MethodName = "Write";
                    return $i1;
                })();
                return this.InvokeAsync($.$KuVO.LCFCC.IRemoteClientConnectionRemoteService, $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, clientId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$$.S.Byte).$type, data), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, messageId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(withPipeline, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12887060142)
            
            //--TRIMMABLE-BOUNDARY-START(17182027438)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<byte[]>> */ LCFCC$IRemoteClientConnectionRemoteService$WriteRead(/*string*/ clientId, /*byte[]*/ data, /*string?*/ messageId, /*System.TimeSpan*/ timeOut)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182027438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$KuVO.LCFCC.IRemoteClientConnectionRemoteService.$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$typeArray($.$$.S.Byte)).$type;
                    $i2.MethodName = "WriteRead";
                    return $i2;
                })();
                return this.InvokeAsync($.$KuVO.LCFCC.IRemoteClientConnectionRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$typeArray($.$$.S.Byte)), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, clientId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$$.S.Byte).$type, data), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, messageId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.TimeSpan.$type, timeOut) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17182027438)
            
            //--TRIMMABLE-BOUNDARY-START(8592092846)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCFCC$IRemoteClientConnectionRemoteService$Broadcast(/*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592092846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$KuVO.LCFCC.IRemoteClientConnectionRemoteService.$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i3.MethodName = "Broadcast";
                    return $i3;
                })();
                return this.InvokeAsync($.$KuVO.LCFCC.IRemoteClientConnectionRemoteService, $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$$.S.Byte).$type, data) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8592092846)
            
            static $h = 2158254;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297125550),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2158254,
      "h": 4297125550,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297125550)
  ],
  "h": 2158254
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$KuVO.LCFCC.IRemoteClientConnectionRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.IRemoteClientConnectionRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}IRemoteClientConnectionRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2158254)
        
        

        //--TRIMMABLE-BOUNDARY-START(847534)
        $asm.$str(`$KuVO.LCFCC.ConnectionFlags`, ($self) => class ConnectionFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Challenge = 1;
            static SymmetricEncryption = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(847534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Challenge": 1n,
                    "SymmetricEncryption": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295814830)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295814830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295814830)
            
            //--TRIMMABLE-BOUNDARY-START(4295814830)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295814830)
            
            static $h = 847534;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885749422),
    {
      "t": 847534,
      "n": "None",
      "d": 847534,
      "h": 12885749422,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885749422),
//--TRIMMABLE-BOUNDARY-START(8590782126),
    {
      "t": 847534,
      "n": "Challenge",
      "d": 847534,
      "h": 8590782126,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590782126),
//--TRIMMABLE-BOUNDARY-START(17180716718),
    {
      "t": 847534,
      "n": "SymmetricEncryption",
      "d": 847534,
      "h": 17180716718,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180716718)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295814830),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 847534,
      "h": 4295814830,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295814830)
  ],
  "h": 847534,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(847534)
        
        

        //--TRIMMABLE-BOUNDARY-START(2289326)
        $asm.$str(`$KuVO.LCFCC.MessageDirection`, ($self) => class MessageDirection extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static In = 0;
            static Out = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2289326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "In": 0n,
                    "Out": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297256622)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297256622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297256622)
            
            //--TRIMMABLE-BOUNDARY-START(4297256622)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297256622)
            
            static $h = 2289326;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592223918),
    {
      "t": 2289326,
      "n": "In",
      "d": 2289326,
      "h": 8592223918,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592223918),
//--TRIMMABLE-BOUNDARY-START(12887191214),
    {
      "t": 2289326,
      "n": "Out",
      "d": 2289326,
      "h": 12887191214,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887191214)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297256622),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2289326,
      "h": 4297256622,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297256622)
  ],
  "h": 2289326
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.MessageDirection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}MessageDirection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2289326)
        
        

        //--TRIMMABLE-BOUNDARY-START(388782)
        $asm.$cls(`$KuVO.LCFCC.ConnectionClient`, ($self) => class ConnectionClient extends $.$fPer.LCFCD.Workspace
        {
            //--TRIMMABLE-BOUNDARY-START(64424898222)
            $ctor$2(/*IConnectionInterface*/ _interface, /*IConnectionClient?*/ parentClient)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424898222);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Interface = _interface;
                    this.Parent = parentClient;
                    this.MessageBuffer = _interface.LCFCC$IConnectionInterface$Context !== null ? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [_interface.LCFCC$IConnectionInterface$Context.LCFCC$IConnectionContext$BufferSize], null) : $.$$.S.Array.Empty($.$$.S.Byte);
                    this.LastReceivedTime = $.$$.S.DateTime.UtcNow;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424898222)
            
            //--TRIMMABLE-BOUNDARY-START(68719865518)
            /*int*/ DelimiterIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(68719865518)
            
            //--TRIMMABLE-BOUNDARY-START(236223590062)
            /*byte[]*/ MessageBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(236223590062)
            
            //--TRIMMABLE-BOUNDARY-START(240518557358)
            /*int*/ MessageBufferCount = 0;
            //--TRIMMABLE-BOUNDARY-END(240518557358)
            
            //--TRIMMABLE-BOUNDARY-START(206158818990)
            /*ClientConnectionIdentity*/ id;
            //--TRIMMABLE-BOUNDARY-END(206158818990)
            
            //--TRIMMABLE-BOUNDARY-START(210453786286)
            /*ClientConnectionIdentity */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784636590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.id;
            }
            /*ClientConnectionIdentity */ set Id(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763197614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(value.UniqueId))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("UniqueId cannot be empty");
                }
                this.id = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(210453786286)
            
            //--TRIMMABLE-BOUNDARY-START(261993393838)
            /*string?*/ Scope = null;
            //--TRIMMABLE-BOUNDARY-END(261993393838)
            
            //--TRIMMABLE-BOUNDARY-START(244813524654)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(244813524654)
            
            //--TRIMMABLE-BOUNDARY-START(223338688174)
            /*DateTime*/ LastReceivedTime;
            //--TRIMMABLE-BOUNDARY-END(223338688174)
            
            //--TRIMMABLE-BOUNDARY-START(227633655470)
            /*DateTime*/ LastWriteTime;
            //--TRIMMABLE-BOUNDARY-END(227633655470)
            
            //--TRIMMABLE-BOUNDARY-START(249108491950)
            /*int*/ PacketCount = 0;
            //--TRIMMABLE-BOUNDARY-END(249108491950)
            
            //--TRIMMABLE-BOUNDARY-START(231928622766)
            /*string?*/ LocalEndPoint = null;
            //--TRIMMABLE-BOUNDARY-END(231928622766)
            
            //--TRIMMABLE-BOUNDARY-START(257698426542)
            /*string?*/ RemoteEndPoint = null;
            //--TRIMMABLE-BOUNDARY-END(257698426542)
            
            //--TRIMMABLE-BOUNDARY-START(214748753582)
            /*IConnectionInterface*/ Interface = null;
            //--TRIMMABLE-BOUNDARY-END(214748753582)
            
            //--TRIMMABLE-BOUNDARY-START(253403459246)
            /*IConnectionClient?*/ Parent = null;
            //--TRIMMABLE-BOUNDARY-END(253403459246)
            
            //--TRIMMABLE-BOUNDARY-START(219043720878)
            /*bool*/ IsConnected = false;
            //--TRIMMABLE-BOUNDARY-END(219043720878)
            
            //--TRIMMABLE-BOUNDARY-START(73014832814)
            /*Exception?*/ Exception = null;
            //--TRIMMABLE-BOUNDARY-END(73014832814)
            
            //--TRIMMABLE-BOUNDARY-START(377957510830)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957510830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(377957510830)
            
            //--TRIMMABLE-BOUNDARY-START(12886470318)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.Exception.get
            get LCFCC$IConnectionClient$Exception()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296535726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exception;
            }
            //--TRIMMABLE-BOUNDARY-END(12886470318)
            
            //--TRIMMABLE-BOUNDARY-START(38656274094)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.IsConnected.get
            get LCFCC$IConnectionClient$IsConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670718126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsConnected;
            }
            //--TRIMMABLE-BOUNDARY-END(38656274094)
            
            //--TRIMMABLE-BOUNDARY-START(73016012462)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.Name.get
            get LCFCC$IConnectionClient$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850587310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(73016012462)
            
            //--TRIMMABLE-BOUNDARY-START(21476404910)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.Id.get
            get LCFCC$IConnectionClient$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080783534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(21476404910)
            
            //--TRIMMABLE-BOUNDARY-START(150325423790)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.Id.set
            set LCFCC$IConnectionClient$Id(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080783534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Id = value;
            }
            //--TRIMMABLE-BOUNDARY-END(150325423790)
            
            //--TRIMMABLE-BOUNDARY-START(47246208686)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.LastReceivedTime.get
            get LCFCC$IConnectionClient$LastReceivedTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965685422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastReceivedTime;
            }
            //--TRIMMABLE-BOUNDARY-END(47246208686)
            
            //--TRIMMABLE-BOUNDARY-START(55836143278)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.LastWriteTime.get
            get LCFCC$IConnectionClient$LastWriteTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260652718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastWriteTime;
            }
            //--TRIMMABLE-BOUNDARY-END(55836143278)
            
            //--TRIMMABLE-BOUNDARY-START(81605947054)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.PacketCount.get
            get LCFCC$IConnectionClient$PacketCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145554606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PacketCount;
            }
            //--TRIMMABLE-BOUNDARY-END(81605947054)
            
            //--TRIMMABLE-BOUNDARY-START(30066339502)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.Interface.get
            get LCFCC$IConnectionClient$Interface()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375750830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Interface;
            }
            //--TRIMMABLE-BOUNDARY-END(30066339502)
            
            //--TRIMMABLE-BOUNDARY-START(64426077870)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.LocalEndPoint.get
            get LCFCC$IConnectionClient$LocalEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555620014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LocalEndPoint;
            }
            //--TRIMMABLE-BOUNDARY-END(64426077870)
            
            //--TRIMMABLE-BOUNDARY-START(98785816238)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.RemoteEndPoint.get
            get LCFCC$IConnectionClient$RemoteEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735489198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoteEndPoint;
            }
            //--TRIMMABLE-BOUNDARY-END(98785816238)
            
            //--TRIMMABLE-BOUNDARY-START(90195881646)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Connection.IConnectionClient.Parent.get
            get LCFCC$IConnectionClient$Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440521902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parent;
            }
            //--TRIMMABLE-BOUNDARY-END(90195881646)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(206158818990)
                this.id = $.$default($.$KuVO.LCFCC.ClientConnectionIdentity);
                //--TRIMMABLE-BOUNDARY-END(206158818990)
                
                //--TRIMMABLE-BOUNDARY-START(223338688174)
                this.LastReceivedTime = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(223338688174)
                
                //--TRIMMABLE-BOUNDARY-START(227633655470)
                this.LastWriteTime = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(227633655470)
                
            }
            static $h = 388782;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD.Workspace; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719865518),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604767406,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583328430,
        "f": 83886081
      },
      "n": "DelimiterIndex",
      "d": 388782,
      "h": 68719865518,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719865518),
//--TRIMMABLE-BOUNDARY-START(236223590062),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324244142,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330712870574,
        "f": 83886081
      },
      "n": "MessageBuffer",
      "d": 388782,
      "h": 236223590062,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236223590062),
//--TRIMMABLE-BOUNDARY-START(240518557358),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914178734,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339302805166,
        "f": 83886081
      },
      "n": "MessageBufferCount",
      "d": 388782,
      "h": 240518557358,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240518557358),
//--TRIMMABLE-BOUNDARY-START(210453786286),
    {
      "p": 323246,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784636590,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763197614,
        "f": 83886081
      },
      "n": "Id",
      "d": 388782,
      "h": 210453786286,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210453786286),
//--TRIMMABLE-BOUNDARY-START(261993393838),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863851694,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373662543534,
        "f": 83886081
      },
      "n": "Scope",
      "d": 388782,
      "h": 261993393838,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261993393838),
//--TRIMMABLE-BOUNDARY-START(244813524654),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504113326,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347892739758,
        "f": 83886081
      },
      "n": "Name",
      "d": 388782,
      "h": 244813524654,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244813524654),
//--TRIMMABLE-BOUNDARY-START(223338688174),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554440366,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943066798,
        "f": 83886081
      },
      "n": "LastReceivedTime",
      "d": 388782,
      "h": 223338688174,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223338688174),
//--TRIMMABLE-BOUNDARY-START(227633655470),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144374958,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313533001390,
        "f": 83886081
      },
      "n": "LastWriteTime",
      "d": 388782,
      "h": 227633655470,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227633655470),
//--TRIMMABLE-BOUNDARY-START(249108491950),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094047918,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356482674350,
        "f": 83886081
      },
      "n": "PacketCount",
      "d": 388782,
      "h": 249108491950,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249108491950),
//--TRIMMABLE-BOUNDARY-START(231928622766),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734309550,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322122935982,
        "f": 83886081
      },
      "n": "LocalEndPoint",
      "d": 388782,
      "h": 231928622766,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231928622766),
//--TRIMMABLE-BOUNDARY-START(257698426542),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273917102,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365072608942,
        "f": 83886081
      },
      "n": "RemoteEndPoint",
      "d": 388782,
      "h": 257698426542,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257698426542),
//--TRIMMABLE-BOUNDARY-START(214748753582),
    {
      "p": 1830574,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374571182,
        "f": 50331649
      },
      "n": "Interface",
      "d": 388782,
      "h": 214748753582,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214748753582),
//--TRIMMABLE-BOUNDARY-START(253403459246),
    {
      "p": 1568430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683982510,
        "f": 50331649
      },
      "n": "Parent",
      "d": 388782,
      "h": 253403459246,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403459246),
//--TRIMMABLE-BOUNDARY-START(219043720878),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964505774,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353132206,
        "f": 83886081
      },
      "n": "IsConnected",
      "d": 388782,
      "h": 219043720878,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219043720878),
//--TRIMMABLE-BOUNDARY-START(73014832814),
    {
      "p": 80805889,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194701998,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173263022,
        "f": 83886081
      },
      "n": "Exception",
      "d": 388782,
      "h": 73014832814,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014832814)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(377957510830),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 388782,
      "h": 377957510830,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(377957510830)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(206158818990),
    {
      "t": 323246,
      "n": "id",
      "d": 388782,
      "h": 206158818990,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(206158818990)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(64424898222),
    {
      "p": [
        {
          "n": "_interface",
          "p": 1830574
        },
        {
          "n": "parentClient",
          "p": 1568430,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 388782,
      "h": 64424898222,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424898222)
  ],
  "h": 388782
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionClient, $.$fPer.LCFCD.IWorkspace ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(388782)
        
        

        //--TRIMMABLE-BOUNDARY-START(454318)
        $asm.$cls(`$KuVO.LCFCC.ConnectionClient<>`, (TNativeClient) => $asm.$gt(`$KuVO.LCFCC.ConnectionClient<>`, [TNativeClient], ($self) => class ConnectionClient$$ extends $.$KuVO.LCFCC.ConnectionClient
        {
            //--TRIMMABLE-BOUNDARY-START(8590388910)
            $ctor$3(/*IConnectionInterface*/ _interface, /*TNativeClient*/ native, /*IConnectionClient?*/ parentClient)
            {
                super.$ctor$2(_interface, parentClient);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590388910);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Native = native;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590388910)
            
            //--TRIMMABLE-BOUNDARY-START(21475290798)
            /*TNativeClient*/ Native = $.$default(TNativeClient);
            //--TRIMMABLE-BOUNDARY-END(21475290798)
            
            static $H = 454318;
            static $h = 454318;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$KuVO.LCFCC.ConnectionClient; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475290798),
    {
      "p": TNativeClient?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180323502,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Native",
      "d": this.$h,
      "H": 21475290798,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475290798)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590388910),
    {
      "p": [
        {
          "n": "_interface",
          "p": 1830574
        },
        {
          "n": "native",
          "p": TNativeClient?.$h??1572864
        },
        {
          "n": "parentClient",
          "p": 1568430,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 8590388910,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590388910)
  ],
  "s": [
    {
      "h": TNativeClient?.$h??1572864,
      "n": "TNativeClient"
    }
  ],
  "r": 1,
  "H": 454318,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$KuVO.LCFCC.IConnectionClient, $.$fPer.LCFCD.IWorkspace ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Connection.ConnectionClient<${TNativeClient?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Connection${separator}ConnectionClient$${TNativeClient?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(454318)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.RPC"));
})();
//--TRIMMABLE-BOUNDARY-END(61102)
