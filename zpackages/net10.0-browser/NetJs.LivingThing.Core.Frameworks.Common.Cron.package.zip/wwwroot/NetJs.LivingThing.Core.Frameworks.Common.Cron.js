
//--TRIMMABLE-BOUNDARY-START(19910)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer) {
    "use strict";
    let _;
    let $gUQWdg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Cron", 
    {
  "h": 19910,
  "f": "LivingThing.Core.Frameworks.Common.Cron",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Cron",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Cron",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(478662)
        $asm.$cls(`$JRhp.LCFCC.CronParser`, ($self) => class CronParser
        {
            //--TRIMMABLE-BOUNDARY-START(8590413254)
            static /*CronField */ ParseField(/*Stringy*/ token, /*CronField*/ defaultField)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590413254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFC.Stringy.op_Implicit$1(token) === "*")
                {
                    return $.$with(defaultField, ($clone) =>
                    {
                        $clone.IsAny = true;
                    });
                }
                if (token.Contains$1(/*,*/ 44))
                {
                    /*var*/ let svals = $.$fPer.LCFCS$6.StringExtension.SplitBy$1(token, /*,*/ 44);
                    /*var*/ let vals = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor)), null, [svals.Length], null);
                    /*int*/ let i = 0;
                    let $en1 = svals.GetEnumerator();
                    while ($en1.MoveNext())
                    {
                        let sval = $en1.Current;
                        {
                            $.$$.System.Array.$WriteT1.call(vals, $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit($.$$.S.Int32.Parse$7($.$fPer.LCFC.Stringy.op_Implicit$1(sval.Token))), i++);
                        }
                    }
                    return $.$JRhp.LCFCC.CronField.AnyOf(vals);
                }
                if (token.Contains$1(/*-*/ 45))
                {
                    /*var*/ let svals = $.$fPer.LCFCS$6.StringExtension.SplitBy$1(token, /*-*/ 45);
                    if (svals.Length !== 2)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("Range values must be two");
                    }
                    return $.$JRhp.LCFCC.CronField.Range($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit($.$$.S.Int32.Parse$7($.$fPer.LCFC.Stringy.op_Implicit$1(svals.get_Item$1(0)))), $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit($.$$.S.Int32.Parse$7($.$fPer.LCFC.Stringy.op_Implicit$1(svals.get_Item$1(1)))));
                }
                return $.$JRhp.LCFCC.CronField.At($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit($.$$.S.Int32.Parse$7($.$fPer.LCFC.Stringy.op_Implicit$1(token))));
            }
            //--TRIMMABLE-BOUNDARY-END(8590413254)
            
            //--TRIMMABLE-BOUNDARY-START(4295445958)
            static /*CronDateTime */ Parse(/*Stringy*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295445958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let split = $.$fPer.LCFCS$6.StringExtension.SplitBy$1(expression, /* */ 32);
                if (split.Length !== 5 && split.Length !== 6)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Invalid Cron Expression: \"${$.$strNN(expression.ToString())}\"`);
                }
                /*CronField*/ let ss = $.$JRhp.LCFCC.CronField.Any, mm = $.$JRhp.LCFCC.CronField.Any, hh = $.$JRhp.LCFCC.CronField.Any, d = $.$JRhp.LCFCC.CronField.Any, m = $.$JRhp.LCFCC.CronField.Any, wd = $.$JRhp.LCFCC.CronField.Any;
                /*int*/ let next = 0;
                if (split.Length === 6)
                {
                    ss = $.$JRhp.LCFCC.CronParser.ParseField(split.get_Item$1(0), $.$JRhp.LCFCC.CronField.Range($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(0), $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(59)));
                    next = 1;
                }
                mm = $.$JRhp.LCFCC.CronParser.ParseField(split.get_Item$1(next), $.$JRhp.LCFCC.CronField.Range($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(0), $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(59)));
                next++;
                hh = $.$JRhp.LCFCC.CronParser.ParseField(split.get_Item$1(next), $.$JRhp.LCFCC.CronField.Range($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(0), $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(23)));
                next++;
                d = $.$JRhp.LCFCC.CronParser.ParseField(split.get_Item$1(next), $.$JRhp.LCFCC.CronField.Range($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(1), $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).FromT1(new $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor().$ctor(this,  (/*CronEnumerationState*/ dt) =>
                {
                    return $.$$.S.DateTime.DaysInMonth(dt.$v.Year, dt.$v.Month);
                }, $gUQWdg ??= {"r":655361,"p":[{"n":"dt","p":216518,"f":4}],"n":"","d":478662,"h":0,"f":17825794}))));
                next++;
                m = $.$JRhp.LCFCC.CronParser.ParseField(split.get_Item$1(next), $.$JRhp.LCFCC.CronField.Range($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(1), $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(12)));
                next++;
                wd = $.$JRhp.LCFCC.CronParser.ParseField(split.get_Item$1(next), $.$JRhp.LCFCC.CronField.Range($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(1), $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(7)));
                next++;
                return (() =>
                {
                    //new $.$JRhp.LCFCC.CronDateTime()
                    const $t2 = $.$JRhp.LCFCC.CronDateTime;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Second = $.$clone(ss);
                    $i2.Minute = $.$clone(mm);
                    $i2.Hour = $.$clone(hh);
                    $i2.Date = $.$clone(d);
                    $i2.Month = $.$clone(m);
                    $i2.Weekday = $.$clone(wd);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(4295445958)
            
            //--TRIMMABLE-BOUNDARY-START(12885380550)
            static /*bool */ TryParse(/*Stringy*/ expression, /*out CronDateTime*/ date)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885380550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let split = $.$fPer.LCFCS$6.StringExtension.SplitBy$1(expression, /* */ 32);
                if (split.Length !== 5 && split.Length !== 6)
                {
                    date.$v = new $.$JRhp.LCFCC.CronDateTime();
                    return false;
                }
                date.$v = $.$JRhp.LCFCC.CronParser.Parse($.$clone(expression));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(12885380550)
            
            static $h = 478662;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590413254),
    {
      "r": 282054,
      "p": [
        {
          "n": "token",
          "p": 64915798
        },
        {
          "n": "defaultField",
          "p": 282054
        }
      ],
      "n": "ParseField",
      "d": 478662,
      "h": 8590413254,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590413254),
//--TRIMMABLE-BOUNDARY-START(4295445958),
    {
      "r": 85446,
      "p": [
        {
          "n": "expression",
          "p": 64915798
        }
      ],
      "n": "Parse",
      "d": 478662,
      "h": 4295445958,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295445958),
//--TRIMMABLE-BOUNDARY-START(12885380550),
    {
      "r": 262145,
      "p": [
        {
          "n": "expression",
          "p": 64915798
        },
        {
          "n": "date",
          "p": 85446,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 478662,
      "h": 12885380550,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885380550)
  ],
  "h": 478662
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Cron.CronParser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Cron${separator}CronParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(478662)
        
        

        //--TRIMMABLE-BOUNDARY-START(216518)
        $asm.$str(`$JRhp.LCFCC.CronEnumerationState`, ($self) => class CronEnumerationState extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(115964333510)
            /*int*/ Second = 0;
            //--TRIMMABLE-BOUNDARY-END(115964333510)
            
            //--TRIMMABLE-BOUNDARY-START(107374398918)
            /*int*/ Minute = 0;
            //--TRIMMABLE-BOUNDARY-END(107374398918)
            
            //--TRIMMABLE-BOUNDARY-START(103079431622)
            /*int*/ Hour = 0;
            //--TRIMMABLE-BOUNDARY-END(103079431622)
            
            //--TRIMMABLE-BOUNDARY-START(38654922182)
            /*int*/ Date = 0;
            //--TRIMMABLE-BOUNDARY-END(38654922182)
            
            //--TRIMMABLE-BOUNDARY-START(111669366214)
            /*int*/ Month = 0;
            //--TRIMMABLE-BOUNDARY-END(111669366214)
            
            //--TRIMMABLE-BOUNDARY-START(184683810246)
            /*int*/ Year = 0;
            //--TRIMMABLE-BOUNDARY-END(184683810246)
            
            //--TRIMMABLE-BOUNDARY-START(180388842950)
            /*int*/ Weekday = 0;
            //--TRIMMABLE-BOUNDARY-END(180388842950)
            
            //--TRIMMABLE-BOUNDARY-START(34359954886)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359954886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359954886)
            
            //--TRIMMABLE-BOUNDARY-START(34359954886)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(34359954886)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Second = this.Second;
                copy.Minute = this.Minute;
                copy.Hour = this.Hour;
                copy.Date = this.Date;
                copy.Month = this.Month;
                copy.Year = this.Year;
                copy.Weekday = this.Weekday;
                return copy;
            }
            static $h = 216518;
            static $z = 28;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964333510),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604595142,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914006470,
        "f": 83886081
      },
      "n": "Second",
      "d": 216518,
      "h": 115964333510,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964333510),
//--TRIMMABLE-BOUNDARY-START(107374398918),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424725958,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734137286,
        "f": 83886081
      },
      "n": "Minute",
      "d": 216518,
      "h": 107374398918,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374398918),
//--TRIMMABLE-BOUNDARY-START(103079431622),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834791366,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144202694,
        "f": 83886081
      },
      "n": "Hour",
      "d": 216518,
      "h": 103079431622,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079431622),
//--TRIMMABLE-BOUNDARY-START(38654922182),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244856774,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554268102,
        "f": 83886081
      },
      "n": "Date",
      "d": 216518,
      "h": 38654922182,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654922182),
//--TRIMMABLE-BOUNDARY-START(111669366214),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014660550,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324071878,
        "f": 83886081
      },
      "n": "Month",
      "d": 216518,
      "h": 111669366214,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669366214),
//--TRIMMABLE-BOUNDARY-START(184683810246),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784464326,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176093875654,
        "f": 83886081
      },
      "n": "Year",
      "d": 216518,
      "h": 184683810246,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184683810246),
//--TRIMMABLE-BOUNDARY-START(180388842950),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194529734,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167503941062,
        "f": 83886081
      },
      "n": "Weekday",
      "d": 216518,
      "h": 180388842950,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180388842950)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34359954886),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 216518,
      "h": 34359954886,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359954886)
  ],
  "h": 216518
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Cron.CronEnumerationState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Cron${separator}CronEnumerationState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(216518)
        
        

        //--TRIMMABLE-BOUNDARY-START(347590)
        $asm.$str(`$JRhp.LCFCC.CronFieldEnumerable`, ($self) => class CronFieldEnumerable extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295314886)
            /*CronField*/ _field;
            //--TRIMMABLE-BOUNDARY-END(4295314886)
            
            //--TRIMMABLE-BOUNDARY-START(8590282182)
            /*ref CronEnumerationState*/ _state;
            //--TRIMMABLE-BOUNDARY-END(8590282182)
            
            //--TRIMMABLE-BOUNDARY-START(17180216774)
            $ctor$3(/*CronField*/ field, /*ref CronEnumerationState*/ state)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180216774);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._field = $.$clone(field);
                    this._state = state;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180216774)
            
            //--TRIMMABLE-BOUNDARY-START(413126)
            static $_CronFieldEnumerator;
            static get CronFieldEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(413126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$JRhp.LCFCC.CronFieldEnumerable;
                return $cls.$_CronFieldEnumerator ??= $asm.$nstr(`$JRhp.LCFCC.CronFieldEnumerable.CronFieldEnumerator`, ($self) => class CronFieldEnumerator extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8590347718)
                    /*CronField*/ _field;
                    //--TRIMMABLE-BOUNDARY-END(8590347718)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180282310)
                    /*ref CronEnumerationState*/ _state;
                    //--TRIMMABLE-BOUNDARY-END(17180282310)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295380422)
                    /*OneOf<int, CronDateTimeEnumeratorAccessor>?*/ _current = null;
                    //--TRIMMABLE-BOUNDARY-END(4295380422)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885315014)
                    /*int*/ _index = 0;
                    //--TRIMMABLE-BOUNDARY-END(12885315014)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065184198)
                    /*int */ get Current()
                    {
                        return $.$$.S.Nullable$$($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor)).Value$get.call(this._current).IsT0 ? $.$$.S.Nullable$$($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor)).Value$get.call(this._current).AsT0 : $.$$.S.Nullable$$($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor)).Value$get.call(this._current).AsT1.Invoke(this._state);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065184198)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770216902)
                    $ctor$3(/*CronField*/ field, /*ref CronEnumerationState*/ state)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770216902);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._field = $.$clone(field);
                            this._state = state;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770216902)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950086086)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950086086);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._field.Values.length === 0)
                        {
                            return false;
                        }
                        if (this._current === null)
                        {
                            this._current = $.$$.System.Array.$ReadT1.call(this._field.Values, 0);
                            this._index = 0;
                            return true;
                        }
                        if (this._field.Values.length === 1)
                        {
                            return false;
                        }
                        if (!this._field.IsRange)
                        {
                            /*int*/ let currentIndex = ((this._index + 1) | 0);
                            if (currentIndex < this._field.Values.length)
                            {
                                this._current = $.$$.System.Array.$ReadT1.call(this._field.Values, currentIndex);
                                this._index++;
                                return true;
                            }
                            return false;
                        }
                        else 
                        {
                            /*var*/ let field = $.$$.System.Array.$ReadT1.call(this._field.Values, 1);
                            if (this.Current >= (field.IsT0 ? field.AsT0 : field.AsT1.Invoke(this._state)))
                            {
                                return false;
                            }
                            this._current = $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(((this.Current + 1) | 0));
                            return true;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950086086)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475249606)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475249606);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475249606)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475249606)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475249606)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._field = this._field.$clone();
                        copy._state = this._state.$clone();
                        copy._current = this._current?.$clone() ?? null;
                        copy._index = this._index;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590347718)
                        this._field = $.$default($.$JRhp.LCFCC.CronField);
                        //--TRIMMABLE-BOUNDARY-END(8590347718)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180282310)
                        this._state = $.$$.SRC.Unsafe.NullRef($.$JRhp.LCFCC.CronEnumerationState);
                        //--TRIMMABLE-BOUNDARY-END(17180282310)
                        
                        //--TRIMMABLE-BOUNDARY-START(4295380422)
                        this._current = null;
                        //--TRIMMABLE-BOUNDARY-END(4295380422)
                        
                    }
                    static $h = 413126;
                    static $z = 51;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065184198),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655118790,
        "f": 50331649
      },
      "n": "Current",
      "d": 413126,
      "h": 30065184198,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065184198)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950086086),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 413126,
      "h": 42950086086,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950086086)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590347718),
    {
      "t": 282054,
      "n": "_field",
      "d": 413126,
      "h": 8590347718,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590347718),
//--TRIMMABLE-BOUNDARY-START(17180282310),
    {
      "t": 216518,
      "n": "_state",
      "d": 413126,
      "h": 17180282310,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180282310),
//--TRIMMABLE-BOUNDARY-START(4295380422),
    {
      "t": $.$typeNullable($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor)).$h,
      "n": "_current",
      "d": 413126,
      "h": 4295380422,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295380422),
//--TRIMMABLE-BOUNDARY-START(12885315014),
    {
      "t": 655361,
      "n": "_index",
      "d": 413126,
      "h": 12885315014,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885315014)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770216902),
    {
      "p": [
        {
          "n": "field",
          "p": 282054
        },
        {
          "n": "state",
          "p": 216518,
          "f": 4
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 413126,
      "h": 25770216902,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770216902),
//--TRIMMABLE-BOUNDARY-START(21475249606),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 413126,
      "h": 21475249606,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475249606)
  ],
  "d": 347590,
  "h": 413126
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Cron.CronFieldEnumerable+CronFieldEnumerator`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Cron${separator}CronFieldEnumerable${separator}CronFieldEnumerator`; }
                }, $cls, ($v) => $cls.$_CronFieldEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(413126)
            
            //--TRIMMABLE-BOUNDARY-START(21475184070)
            /*CronFieldEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475184070);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$JRhp.LCFCC.CronFieldEnumerable.CronFieldEnumerator().$ctor$3($.$clone(this._field), this._state);
            }
            //--TRIMMABLE-BOUNDARY-END(21475184070)
            
            //--TRIMMABLE-BOUNDARY-START(12885249478)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885249478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885249478)
            
            //--TRIMMABLE-BOUNDARY-START(12885249478)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885249478)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._field = this._field.$clone();
                copy._state = this._state.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295314886)
                this._field = $.$default($.$JRhp.LCFCC.CronField);
                //--TRIMMABLE-BOUNDARY-END(4295314886)
                
                //--TRIMMABLE-BOUNDARY-START(8590282182)
                this._state = $.$$.SRC.Unsafe.NullRef($.$JRhp.LCFCC.CronEnumerationState);
                //--TRIMMABLE-BOUNDARY-END(8590282182)
                
            }
            static $h = 347590;
            static $z = 34;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475184070),
    {
      "r": 413126,
      "n": "GetEnumerator",
      "d": 347590,
      "h": 21475184070,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475184070)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295314886),
    {
      "t": 282054,
      "n": "_field",
      "d": 347590,
      "h": 4295314886,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295314886),
//--TRIMMABLE-BOUNDARY-START(8590282182),
    {
      "t": 216518,
      "n": "_state",
      "d": 347590,
      "h": 8590282182,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590282182)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180216774),
    {
      "p": [
        {
          "n": "field",
          "p": 282054
        },
        {
          "n": "state",
          "p": 216518,
          "f": 4
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 347590,
      "h": 17180216774,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180216774),
//--TRIMMABLE-BOUNDARY-START(12885249478),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 347590,
      "h": 12885249478,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885249478)
  ],
  "h": 347590
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$JRhp.LCFCC.CronFieldEnumerable.CronFieldEnumerator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Cron.CronFieldEnumerable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Cron${separator}CronFieldEnumerable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(347590)
        
        

        //--TRIMMABLE-BOUNDARY-START(85446)
        $asm.$str(`$JRhp.LCFCC.CronDateTime`, ($self) => class CronDateTime extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(120259169734)
            /*CronField*/ Second;
            //--TRIMMABLE-BOUNDARY-END(120259169734)
            
            //--TRIMMABLE-BOUNDARY-START(103079300550)
            /*CronField*/ Minute;
            //--TRIMMABLE-BOUNDARY-END(103079300550)
            
            //--TRIMMABLE-BOUNDARY-START(98784333254)
            /*CronField*/ Hour;
            //--TRIMMABLE-BOUNDARY-END(98784333254)
            
            //--TRIMMABLE-BOUNDARY-START(34359823814)
            /*CronField*/ Date;
            //--TRIMMABLE-BOUNDARY-END(34359823814)
            
            //--TRIMMABLE-BOUNDARY-START(107374267846)
            /*CronField*/ Month;
            //--TRIMMABLE-BOUNDARY-END(107374267846)
            
            //--TRIMMABLE-BOUNDARY-START(176093744582)
            /*CronField*/ Weekday;
            //--TRIMMABLE-BOUNDARY-END(176093744582)
            
            //--TRIMMABLE-BOUNDARY-START(111669235142)
            static /*bool */ op_Equality(/*CronDateTime*/ cron, /*DateTime*/ refTime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669235142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CronEnumerationState*/ let state = new $.$JRhp.LCFCC.CronEnumerationState().$ctor$2();
                state.Second = refTime.Second;
                state.Minute = refTime.Minute;
                state.Hour = refTime.Hour;
                state.Date = refTime.Day;
                state.Month = refTime.Month;
                state.Weekday = refTime.DayOfWeek;
                state.Year = refTime.Year;
                return cron.Second.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Second) && cron.Minute.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Minute) && cron.Hour.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Hour) && cron.Date.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Day) && cron.Month.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Month) && cron.Weekday.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.DayOfWeek);
            }
            //--TRIMMABLE-BOUNDARY-END(111669235142)
            
            //--TRIMMABLE-BOUNDARY-START(115964202438)
            static /*bool */ op_Inequality(/*CronDateTime*/ cron, /*DateTime*/ refTime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964202438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CronEnumerationState*/ let state = new $.$JRhp.LCFCC.CronEnumerationState().$ctor$2();
                state.Second = refTime.Second;
                state.Minute = refTime.Minute;
                state.Hour = refTime.Hour;
                state.Date = refTime.Day;
                state.Month = refTime.Month;
                state.Weekday = refTime.DayOfWeek;
                state.Year = refTime.Year;
                return !cron.Second.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Second) || !cron.Minute.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Minute) || !cron.Hour.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Hour) || !cron.Date.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Day) || !cron.Month.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Month) || !cron.Weekday.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.DayOfWeek);
            }
            //--TRIMMABLE-BOUNDARY-END(115964202438)
            
            //--TRIMMABLE-BOUNDARY-START(90194398662)
            /*DateTime */ GetDate(/*DateTime*/ refTime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194398662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CronEnumerationState*/ let state = new $.$JRhp.LCFCC.CronEnumerationState().$ctor$2();
                state.Second = refTime.Second;
                state.Minute = refTime.Minute;
                state.Hour = refTime.Hour;
                state.Date = refTime.Day;
                state.Month = refTime.Month;
                state.Weekday = refTime.DayOfWeek;
                state.Year = refTime.Year;
                /*var*/ let sec = this.Second.GetValue($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Second);
                /*var*/ let min = this.Minute.GetValue($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Minute);
                /*var*/ let hr = this.Hour.GetValue($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Hour);
                /*var*/ let dt = this.Date.GetValue($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Day);
                /*var*/ let mon = this.Month.GetValue($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.Month);
                /*var*/ let weekday = this.Weekday.GetValue($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), refTime.DayOfWeek);
                return new $.$$.S.DateTime().$ctor$16(refTime.Year, mon, dt, hr, min, sec);
            }
            //--TRIMMABLE-BOUNDARY-END(90194398662)
            
            //--TRIMMABLE-BOUNDARY-START(94489365958)
            /*DateTime */ GetNext(/*DateTime*/ startTime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489365958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                startTime = new $.$$.S.DateTime().$ctor$16(startTime.Year, startTime.Month, startTime.Day, startTime.Hour, startTime.Minute, startTime.Second);
                /*CronEnumerationState*/ let state = new $.$JRhp.LCFCC.CronEnumerationState().$ctor$2();
                state.Second = startTime.Second;
                state.Minute = startTime.Minute;
                state.Hour = startTime.Hour;
                state.Date = startTime.Day;
                state.Month = startTime.Month;
                state.Weekday = startTime.DayOfWeek;
                state.Year = startTime.Year;
                /*long*/ let startWeight = BigInt(((((((((((((((startTime.Month * 60) | 0) * 60) | 0) * 24) | 0) * 31) | 0) + ((((((startTime.Day * 60) | 0) * 60) | 0) * 24) | 0)) | 0) + ((((startTime.Hour * 60) | 0) * 60) | 0)) | 0) + ((startTime.Minute * 60) | 0)) | 0) + startTime.Second);
                /*bool*/  function IsValid(/*ref CronDateTime*/ cron)
                {
                    return cron.$v.Second.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), state.Second) && cron.$v.Minute.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), state.Minute) && cron.$v.Hour.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), state.Hour) && cron.$v.Date.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), state.Date) && cron.$v.Month.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), state.Month) && cron.$v.Weekday.IsValid($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true), state.Weekday);
                }
                /*bool*/  function IsAfterStartDate()
                {
                    /*long*/ let weight = BigInt(((((((((((((((state.Month * 60) | 0) * 60) | 0) * 24) | 0) * 31) | 0) + ((((((state.Date * 60) | 0) * 60) | 0) * 24) | 0)) | 0) + ((((state.Hour * 60) | 0) * 60) | 0)) | 0) + ((state.Minute * 60) | 0)) | 0) + state.Second);
                    return weight >= startWeight;
                }
                /*DateTime*/  function Create()
                {
                    return new $.$$.S.DateTime().$ctor$6(state.Year, state.Month, state.Date, state.Hour, state.Minute, state.Second, startTime.Kind);
                }
                let $en25 = this.Month.GetEnumerable($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true)).GetEnumerator();
                while ($en25.MoveNext())
                {
                    let _month = $en25.Current;
                    {
                        /*var*/ let month = _month < 1 ? startTime.Month : _month;
                        state.Month = month;
                        /*var*/ let dateWithMonth = new $.$$.S.DateTime().$ctor$6(startTime.Year, state.Month, $.$$.S.Math.Min$4(startTime.Day, $.$$.S.DateTime.DaysInMonth(startTime.Year, state.Month)), startTime.Hour, startTime.Minute, startTime.Second, startTime.Kind);
                        if ($.$$.S.DateTime.op_LessThan(dateWithMonth, startTime))
                        {
                            continue;
                        }
                        let $en27 = this.Date.GetEnumerable($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true)).GetEnumerator();
                        while ($en27.MoveNext())
                        {
                            let _date = $en27.Current;
                            {
                                /*var*/ let date = _date < 1 ? $.$$.S.Math.Min$4(startTime.Day, $.$$.S.DateTime.DaysInMonth(startTime.Year, month)) : _date;
                                state.Date = date;
                                /*var*/ let dateWithDate = new $.$$.S.DateTime().$ctor$6(state.Year, month, date, startTime.Hour, startTime.Minute, startTime.Second, startTime.Kind);
                                if ($.$$.S.DateTime.op_LessThan(dateWithDate, startTime))
                                {
                                    continue;
                                }
                                let $en29 = this.Weekday.GetEnumerable($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true)).GetEnumerator();
                                while ($en29.MoveNext())
                                {
                                    let _weekday = $en29.Current;
                                    {
                                        /*var*/ let weekday = _weekday < 0 ? startTime.DayOfWeek : _weekday;
                                        state.Weekday = weekday;
                                        if (this.Weekday.IsAny || dateWithDate.DayOfWeek === weekday)
                                        {
                                            let $en31 = this.Hour.GetEnumerable($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true)).GetEnumerator();
                                            while ($en31.MoveNext())
                                            {
                                                let _hour = $en31.Current;
                                                {
                                                    /*var*/ let hour = _hour < 0 ? 0 : _hour;
                                                    state.Hour = hour;
                                                    /*var*/ let dateWithHour = new $.$$.S.DateTime().$ctor$6(state.Year, month, date, hour, startTime.Minute, startTime.Second, startTime.Kind);
                                                    if ($.$$.S.DateTime.op_LessThan(dateWithHour, startTime))
                                                    {
                                                        continue;
                                                    }
                                                    let $en33 = this.Minute.GetEnumerable($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true)).GetEnumerator();
                                                    while ($en33.MoveNext())
                                                    {
                                                        let _minute = $en33.Current;
                                                        {
                                                            /*var*/ let minute = _minute < 0 ? 0 : _minute;
                                                            state.Minute = minute;
                                                            /*var*/ let dateWithMinute = new $.$$.S.DateTime().$ctor$6(state.Year, month, date, hour, minute, startTime.Second, startTime.Kind);
                                                            if ($.$$.S.DateTime.op_LessThan(dateWithMinute, startTime))
                                                            {
                                                                continue;
                                                            }
                                                            let $en35 = this.Second.GetEnumerable($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronEnumerationState, () => state, ($v) => state = $v, null, true)).GetEnumerator();
                                                            while ($en35.MoveNext())
                                                            {
                                                                let _second = $en35.Current;
                                                                {
                                                                    /*var*/ let second = _second < 0 ? 0 : _second;
                                                                    state.Second = second;
                                                                    /*var*/ let dateWithSecond = new $.$$.S.DateTime().$ctor$6(state.Year, month, date, hour, minute, second, startTime.Kind);
                                                                    if ($.$$.S.DateTime.op_LessThan(dateWithSecond, startTime))
                                                                    {
                                                                        continue;
                                                                    }
                                                                    if (IsValid.call(this, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$JRhp.LCFCC.CronDateTime, () => this, ($v) => $v.$clone(this), null, true)) && IsAfterStartDate.call(this))
                                                                    {
                                                                        return Create.call(this);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return $.$$.S.DateTime.MaxValue;
            }
            //--TRIMMABLE-BOUNDARY-END(94489365958)
            
            //--TRIMMABLE-BOUNDARY-START(30064856518)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064856518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064856518)
            
            //--TRIMMABLE-BOUNDARY-START(30064856518)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(30064856518)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Second = this.Second.$clone();
                copy.Minute = this.Minute.$clone();
                copy.Hour = this.Hour.$clone();
                copy.Date = this.Date.$clone();
                copy.Month = this.Month.$clone();
                copy.Weekday = this.Weekday.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(120259169734)
                this.Second = $.$default($.$JRhp.LCFCC.CronField);
                //--TRIMMABLE-BOUNDARY-END(120259169734)
                
                //--TRIMMABLE-BOUNDARY-START(103079300550)
                this.Minute = $.$default($.$JRhp.LCFCC.CronField);
                //--TRIMMABLE-BOUNDARY-END(103079300550)
                
                //--TRIMMABLE-BOUNDARY-START(98784333254)
                this.Hour = $.$default($.$JRhp.LCFCC.CronField);
                //--TRIMMABLE-BOUNDARY-END(98784333254)
                
                //--TRIMMABLE-BOUNDARY-START(34359823814)
                this.Date = $.$default($.$JRhp.LCFCC.CronField);
                //--TRIMMABLE-BOUNDARY-END(34359823814)
                
                //--TRIMMABLE-BOUNDARY-START(107374267846)
                this.Month = $.$default($.$JRhp.LCFCC.CronField);
                //--TRIMMABLE-BOUNDARY-END(107374267846)
                
                //--TRIMMABLE-BOUNDARY-START(176093744582)
                this.Weekday = $.$default($.$JRhp.LCFCC.CronField);
                //--TRIMMABLE-BOUNDARY-END(176093744582)
                
            }
            static $h = 85446;
            static $z = 36;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120259169734),
    {
      "p": 282054,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309496774,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163208842694,
        "f": 83886081
      },
      "n": "Second",
      "d": 85446,
      "h": 120259169734,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259169734),
//--TRIMMABLE-BOUNDARY-START(103079300550),
    {
      "p": 282054,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129627590,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146028973510,
        "f": 83886081
      },
      "n": "Minute",
      "d": 85446,
      "h": 103079300550,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079300550),
//--TRIMMABLE-BOUNDARY-START(98784333254),
    {
      "p": 282054,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539692998,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439038918,
        "f": 83886081
      },
      "n": "Hour",
      "d": 85446,
      "h": 98784333254,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784333254),
//--TRIMMABLE-BOUNDARY-START(34359823814),
    {
      "p": 282054,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949758406,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849104326,
        "f": 83886081
      },
      "n": "Date",
      "d": 85446,
      "h": 34359823814,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359823814),
//--TRIMMABLE-BOUNDARY-START(107374267846),
    {
      "p": 282054,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719562182,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154618908102,
        "f": 83886081
      },
      "n": "Month",
      "d": 85446,
      "h": 107374267846,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374267846),
//--TRIMMABLE-BOUNDARY-START(176093744582),
    {
      "p": 282054,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899431366,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171798777286,
        "f": 83886081
      },
      "n": "Weekday",
      "d": 85446,
      "h": 176093744582,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176093744582)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90194398662),
    {
      "r": 65994753,
      "p": [
        {
          "n": "refTime",
          "p": 65994753
        }
      ],
      "n": "GetDate",
      "d": 85446,
      "h": 90194398662,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194398662),
//--TRIMMABLE-BOUNDARY-START(94489365958),
    {
      "r": 65994753,
      "p": [
        {
          "n": "startTime",
          "p": 65994753
        }
      ],
      "n": "GetNext",
      "d": 85446,
      "h": 94489365958,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489365958)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30064856518),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 85446,
      "h": 30064856518,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064856518)
  ],
  "h": 85446
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Cron.CronDateTime`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Cron${separator}CronDateTime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(85446)
        
        

        //--TRIMMABLE-BOUNDARY-START(282054)
        $asm.$str(`$JRhp.LCFCC.CronField`, ($self) => class CronField extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(25770085830)
            /*CronField*/ static Any;
            //--TRIMMABLE-BOUNDARY-END(25770085830)
            
            //--TRIMMABLE-BOUNDARY-START(103079497158)
            static /*CronField */ Range(/*OneOf<int, CronDateTimeEnumeratorAccessor>*/ start, /*OneOf<int, CronDateTimeEnumeratorAccessor>*/ end)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079497158);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$JRhp.LCFCC.CronField()
                        const $t1 = $.$JRhp.LCFCC.CronField;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Values = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor)), [start, end], [-1], null);
                        $i1.IsRange = true;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079497158)
            
            //--TRIMMABLE-BOUNDARY-START(34360020422)
            static /*CronField */ At(/*OneOf<int, CronDateTimeEnumeratorAccessor>*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360020422);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$JRhp.LCFCC.CronField()
                        const $t2 = $.$JRhp.LCFCC.CronField;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.Values = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor)), [value], [-1], null);
                        return $i2;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360020422)
            
            //--TRIMMABLE-BOUNDARY-START(30065053126)
            static /*CronField */ AnyOf(/*OneOf<int, CronDateTimeEnumeratorAccessor>[]*/ values)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065053126);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$JRhp.LCFCC.CronField()
                        const $t3 = $.$JRhp.LCFCC.CronField;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Values = values;
                        return $i3;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065053126)
            
            //--TRIMMABLE-BOUNDARY-START(90194595270)
            /*bool*/ IsRange = false;
            //--TRIMMABLE-BOUNDARY-END(90194595270)
            
            //--TRIMMABLE-BOUNDARY-START(85899627974)
            /*bool*/ IsAny = false;
            //--TRIMMABLE-BOUNDARY-END(85899627974)
            
            //--TRIMMABLE-BOUNDARY-START(137439235526)
            /*OneOf<int, CronDateTimeEnumeratorAccessor>[]*/ Values = null;
            //--TRIMMABLE-BOUNDARY-END(137439235526)
            
            //--TRIMMABLE-BOUNDARY-START(133144268230)
            /*OneOf<int, CronDateTimeEnumeratorAccessor> */ get Value()
            {
                const $t4 = this.Values;
                return $.$ifnn($t4, ($t) => $t.length) === 1 ? $.$$.System.Array.$ReadT1.call(this.Values, 0) : new ($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor))();
            }
            //--TRIMMABLE-BOUNDARY-END(133144268230)
            
            //--TRIMMABLE-BOUNDARY-START(38654987718)
            /*OneOf<int, Func<DateTime, int>>? */ First(/*ref CronEnumerationState*/ _stackEnumeration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654987718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                const $t5 = this.Values;
                /*var*/ let field = $.$ifnn($t5, ($t) => $.$$.System.Array.$ReadT1.call($t, 0));
                return $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$$.S.Func$$$($.$$.S.DateTime, $.$$.S.Int32)).op_Implicit(((field?.IsT0 ?? null) ?? false) ? ((field?.AsT0 ?? null) ?? null) : ((field?.AsT1.Invoke(_stackEnumeration) ?? null) ?? null));
            }
            //--TRIMMABLE-BOUNDARY-END(38654987718)
            
            //--TRIMMABLE-BOUNDARY-START(81604660678)
            /*int */ GetValue(/*ref CronEnumerationState*/ _stackEnumeration, /*int*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604660678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Values === null || this.IsAny)
                {
                    return defaultValue;
                }
                if (this.Values.length === 1)
                {
                    /*var*/ let field = $.$$.System.Array.$ReadT1.call(this.Values, 0);
                    /*var*/ let dval = field.IsT0 ? field.AsT0 : field.AsT1.Invoke(_stackEnumeration);
                    return dval;
                }
                return defaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(81604660678)
            
            //--TRIMMABLE-BOUNDARY-START(98784529862)
            /*int? */ Next(/*ref CronEnumerationState*/ _stackEnumeration, /*int*/ current)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784529862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Values === null)
                {
                    return null;
                }
                if (this.Values.length === 1)
                {
                    /*var*/ let field = $.$$.System.Array.$ReadT1.call(this.Values, 0);
                    /*var*/ let dval = field.IsT0 ? field.AsT0 : field.AsT1.Invoke(_stackEnumeration);
                    return dval;
                }
                if (!this.IsRange)
                {
                    /*int*/ let currentIndex = (($.$$.S.Array.IndexOf$5($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor), this.Values, $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(current)) + 1) | 0);
                    if (currentIndex > ((this.Values.length - 1) | 0))
                    {
                        currentIndex = 0;
                    }
                    /*var*/ let field = $.$$.System.Array.$ReadT1.call(this.Values, currentIndex);
                    return field.IsT0 ? field.AsT0 : field.AsT1.Invoke(_stackEnumeration);
                }
                /*var*/ let next = ((current + 1) | 0);
                /*var*/ let startField = $.$$.System.Array.$ReadT1.call(this.Values, 0);
                /*var*/ let startValue = startField.IsT0 ? startField.AsT0 : startField.AsT1.Invoke(_stackEnumeration);
                /*var*/ let endField = $.$$.System.Array.$ReadT1.call(this.Values, 1);
                /*var*/ let endValue = endField.IsT0 ? endField.AsT0 : endField.AsT1.Invoke(_stackEnumeration);
                if (next > endValue)
                {
                    next = startValue;
                }
                return next;
            }
            //--TRIMMABLE-BOUNDARY-END(98784529862)
            
            //--TRIMMABLE-BOUNDARY-START(94489562566)
            /*bool */ IsValid(/*ref CronEnumerationState*/ state, /*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489562566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsAny)
                {
                    return true;
                }
                if (this.Values.length === 1)
                {
                    /*var*/ let field = $.$$.System.Array.$ReadT1.call(this.Values, 0);
                    /*var*/ let dval = field.IsT0 ? field.AsT0 : field.AsT1.Invoke(state);
                    return dval === value;
                }
                if (!this.IsRange)
                {
                    let $i13 = 0;
                    let $arr13 = this.Values;
                    while ($i13 < $arr13.length)
                    {
                        let field = $arr13[$i13++];
                        /*var*/ let val = field.IsT0 ? field.AsT0 : field.AsT1.Invoke(state);
                        if (val === value)
                        {
                            return true;
                        }
                    }
                    return false;
                }
                else 
                {
                    /*var*/ let startField = $.$$.System.Array.$ReadT1.call(this.Values, 0);
                    /*var*/ let startValue = startField.IsT0 ? startField.AsT0 : startField.AsT1.Invoke(state);
                    /*var*/ let endField = $.$$.System.Array.$ReadT1.call(this.Values, 1);
                    /*var*/ let endValue = endField.IsT0 ? endField.AsT0 : endField.AsT1.Invoke(state);
                    return value >= startValue && value <= endValue;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489562566)
            
            //--TRIMMABLE-BOUNDARY-START(77309693382)
            /*CronFieldEnumerable */ GetEnumerable(/*ref CronEnumerationState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309693382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$JRhp.LCFCC.CronFieldEnumerable().$ctor$3($.$clone(this), state);
            }
            //--TRIMMABLE-BOUNDARY-END(77309693382)
            
            //--TRIMMABLE-BOUNDARY-START(21475118534)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475118534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475118534)
            
            //--TRIMMABLE-BOUNDARY-START(21475118534)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475118534)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.IsRange = this.IsRange;
                copy.IsAny = this.IsAny;
                copy.Values = this.Values;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(17180151238)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180151238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25770085830)
                    this.Any = (() =>
                    {
                        //new $.$JRhp.LCFCC.CronField()
                        const $t18 = $.$JRhp.LCFCC.CronField;
                        const $i18 = new $t18();
                        $i18.$ctor$2();
                        $i18.Values = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor)), [$.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).op_Implicit(-1)], [-1], null);
                        $i18.IsAny = true;
                        return $i18;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(25770085830)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180151238)
            
            static $h = 282054;
            static $z = 6;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194595270),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834856902,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259366342,
        "f": 83886081
      },
      "n": "IsRange",
      "d": 282054,
      "h": 90194595270,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194595270),
//--TRIMMABLE-BOUNDARY-START(85899627974),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244922310,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669431750,
        "f": 83886081
      },
      "n": "IsAny",
      "d": 282054,
      "h": 85899627974,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899627974),
//--TRIMMABLE-BOUNDARY-START(137439235526),
    {
      "p": $.$typeArray($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014726086,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849300934,
        "f": 83886081
      },
      "n": "Values",
      "d": 282054,
      "h": 137439235526,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439235526),
//--TRIMMABLE-BOUNDARY-START(133144268230),
    {
      "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424791494,
        "f": 50331649
      },
      "n": "Value",
      "d": 282054,
      "h": 133144268230,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144268230)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103079497158),
    {
      "r": 282054,
      "p": [
        {
          "n": "start",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).$h
        },
        {
          "n": "end",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).$h
        }
      ],
      "n": "Range",
      "d": 282054,
      "h": 103079497158,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103079497158),
//--TRIMMABLE-BOUNDARY-START(34360020422),
    {
      "r": 282054,
      "p": [
        {
          "n": "value",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor).$h
        }
      ],
      "n": "At",
      "d": 282054,
      "h": 34360020422,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360020422),
//--TRIMMABLE-BOUNDARY-START(30065053126),
    {
      "r": 282054,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$JRhp.LCFCC.CronDateTimeEnumeratorAccessor)).$h
        }
      ],
      "n": "AnyOf",
      "d": 282054,
      "h": 30065053126,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065053126),
//--TRIMMABLE-BOUNDARY-START(38654987718),
    {
      "r": $.$typeNullable($.$fPer.LCFCO.OneOf$$$($.$$.S.Int32, $.$$.S.Func$$$($.$$.S.DateTime, $.$$.S.Int32))).$h,
      "p": [
        {
          "n": "_stackEnumeration",
          "p": 216518,
          "f": 4
        }
      ],
      "n": "First",
      "d": 282054,
      "h": 38654987718,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654987718),
//--TRIMMABLE-BOUNDARY-START(81604660678),
    {
      "r": 655361,
      "p": [
        {
          "n": "_stackEnumeration",
          "p": 216518,
          "f": 4
        },
        {
          "n": "defaultValue",
          "p": 655361
        }
      ],
      "n": "GetValue",
      "d": 282054,
      "h": 81604660678,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604660678),
//--TRIMMABLE-BOUNDARY-START(98784529862),
    {
      "r": $.$typeNullable($.$$.S.Int32).$h,
      "p": [
        {
          "n": "_stackEnumeration",
          "p": 216518,
          "f": 4
        },
        {
          "n": "current",
          "p": 655361
        }
      ],
      "n": "Next",
      "d": 282054,
      "h": 98784529862,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784529862),
//--TRIMMABLE-BOUNDARY-START(94489562566),
    {
      "r": 262145,
      "p": [
        {
          "n": "state",
          "p": 216518,
          "f": 4
        },
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "IsValid",
      "d": 282054,
      "h": 94489562566,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489562566),
//--TRIMMABLE-BOUNDARY-START(77309693382),
    {
      "r": 347590,
      "p": [
        {
          "n": "state",
          "p": 216518,
          "f": 4
        }
      ],
      "n": "GetEnumerable",
      "d": 282054,
      "h": 77309693382,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309693382)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770085830),
    {
      "t": 282054,
      "n": "Any",
      "d": 282054,
      "h": 25770085830,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770085830)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475118534),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 282054,
      "h": 21475118534,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475118534)
  ],
  "h": 282054
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Cron.CronField`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Cron${separator}CronField`; }
        });
        //--TRIMMABLE-BOUNDARY-END(282054)
        
        

        //--TRIMMABLE-BOUNDARY-START(150982)
        $asm.$cls(`$JRhp.LCFCC.CronDateTimeEnumeratorAccessor`, ($self) => class CronDateTimeEnumeratorAccessor extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*int*/ Invoke(/**/ state)
            {
                return this.$nativeFunction.call(this.$target, state);
            }
            static $h = 150982;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180020166),
    {
      "r": 655361,
      "p": [
        {
          "n": "state",
          "p": 216518,
          "f": 4
        }
      ],
      "n": "Invoke",
      "d": 150982,
      "h": 17180020166,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180020166),
//--TRIMMABLE-BOUNDARY-START(8590085574),
    {
      "r": 90570753,
      "p": [
        {
          "n": "state",
          "p": 216518,
          "f": 4
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 150982,
      "h": 8590085574,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590085574),
//--TRIMMABLE-BOUNDARY-START(12885052870),
    {
      "r": 655361,
      "p": [
        {
          "n": "state",
          "p": 216518,
          "f": 4
        },
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 150982,
      "h": 12885052870,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885052870)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295118278),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 150982,
      "h": 4295118278,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295118278)
  ],
  "h": 150982
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Cron.CronDateTimeEnumeratorAccessor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Cron${separator}CronDateTimeEnumeratorAccessor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(150982)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(19910)
