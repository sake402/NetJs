
//--TRIMMABLE-BOUNDARY-START(60355)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $HnZw, $mep, $meca, $mxdi, $mexla, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $meo, $mecm, $mecga, $mec, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer) {
    "use strict";
    let _;
    let $kiOaOa;
    let $JVAhVj;
    let $cTXwFe;
    let $WsjtYe;
    let $bYonXj;
    let $CoViYh;
    let $LYuAtj;
    let $UDiMzj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", 
    {
  "h": 60355,
  "f": "LivingThing.Core.Frameworks.Common.Dynamic",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Dynamic",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Dynamic",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(125891)
        $asm.$cls(`$DJRY.LCFCD.InterpreterExtension`, ($self) => class InterpreterExtension
        {
            //--TRIMMABLE-BOUNDARY-START(17179995075)
            /*Interpreter*/ static interpreter = null;
            //--TRIMMABLE-BOUNDARY-END(17179995075)
            
            //--TRIMMABLE-BOUNDARY-START(4295093187)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295093187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$DJRY.LCFCD.InterpreterExtension.interpreter.Reference$3($.$sl.SL.Enumerable.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(4295093187)
            
            //--TRIMMABLE-BOUNDARY-START(8590060483)
            static /*Func<TClass, TResult> */ CompileExpression(TClass, TResult, /*this string*/ expression, /*params string[]*/ parameterNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590060483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lamba = $.$DJRY.LCFCD.InterpreterExtension.interpreter.ParseAsDelegate($.$$.S.Func$$$(TClass, TResult), expression, parameterNames);
                return lamba;
            }
            //--TRIMMABLE-BOUNDARY-END(8590060483)
            
            //--TRIMMABLE-BOUNDARY-START(12885027779)
            static /*TResult */ EvaluateExpression(TClass, TResult, /*this string*/ expression, /*TClass?*/ target, /*params string[]*/ parameterNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885027779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lamba = $.$DJRY.LCFCD.InterpreterExtension.interpreter.ParseAsDelegate($.$$.S.Func$$$(TClass, TResult), expression, parameterNames);
                return lamba.Invoke(target);
            }
            //--TRIMMABLE-BOUNDARY-END(12885027779)
            
            //--TRIMMABLE-BOUNDARY-START(4295093187)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295093187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17179995075)
                    this.interpreter = new $.$HnZw.D.Interpreter().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(17179995075)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295093187)
            
            static $h = 125891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590060483),
    {
      "r": (TClass, TResult) => $.$$.S.Func$$$(TClass, TResult).$h,
      "p": [
        {
          "n": "expression",
          "p": 1310721
        },
        {
          "n": "parameterNames",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "g": [
        "TClass",
        "TResult"
      ],
      "n": "CompileExpression",
      "d": 125891,
      "h": 8590060483,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590060483),
//--TRIMMABLE-BOUNDARY-START(12885027779),
    {
      "r": (TClass, TResult) => TResult.$h,
      "p": [
        {
          "n": "expression",
          "p": 1310721
        },
        {
          "n": "target",
          "p": (TClass, TResult) => TClass.$h
        },
        {
          "n": "parameterNames",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "g": [
        "TClass",
        "TResult"
      ],
      "n": "EvaluateExpression",
      "d": 125891,
      "h": 12885027779,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885027779)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179995075),
    {
      "t": 1028211,
      "n": "interpreter",
      "d": 125891,
      "h": 17179995075,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17179995075)
  ],
  "h": 125891
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Dynamic.InterpreterExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Dynamic${separator}InterpreterExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(125891)
        
        

        //--TRIMMABLE-BOUNDARY-START(191427)
        $asm.$cls(`$DJRY.LCFCD.MemoryCacheExtensions`, ($self) => class MemoryCacheExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590126019)
            /*Lazy<Func<MemoryCache, object>>*/ static _getEntries6 = null;
            //--TRIMMABLE-BOUNDARY-END(8590126019)
            
            //--TRIMMABLE-BOUNDARY-START(4295158723)
            /*Lazy<Func<MemoryCache, object>>*/ static _getCoherentState = null;
            //--TRIMMABLE-BOUNDARY-END(4295158723)
            
            //--TRIMMABLE-BOUNDARY-START(12885093315)
            /*Lazy<Func<object, IDictionary>>*/ static _getEntries7 = null;
            //--TRIMMABLE-BOUNDARY-END(12885093315)
            
            //--TRIMMABLE-BOUNDARY-START(25769995203)
            /*Lazy<Func<object, IDictionary>>*/ static _getStringEntries8010 = null;
            //--TRIMMABLE-BOUNDARY-END(25769995203)
            
            //--TRIMMABLE-BOUNDARY-START(21475027907)
            /*Lazy<Func<object, IDictionary>>*/ static _getNonStringEntries8010 = null;
            //--TRIMMABLE-BOUNDARY-END(21475027907)
            
            //--TRIMMABLE-BOUNDARY-START(34359929795)
            static /*Func<TParam, TReturn> */ CreateGetter(TParam, TReturn, /*FieldInfo*/ field)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359929795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let methodName = `${$.$strNN(field.ReflectedType.FullName)}.get_${$.$strNN(field.Name)}`;
                /*var*/ let method = new DynamicMethod(methodName, TReturn.$type, $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.Type.$type, [ TParam.$type ], null, null), TParam.$type, true);
                /*var*/ let ilGen = method.GetILGenerator();
                ilGen.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Ldarg_0);
                ilGen.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Ldfld, field);
                ilGen.Emit(/*$.$$.SRE.OpCodes*/$.$$.DeletedObject.Ret);
                return $.$cast(method.CreateDelegate$1($.$$.S.Func$$$(TParam, TReturn).$type), $.$$.S.Func$$$(TParam, TReturn));
            }
            //--TRIMMABLE-BOUNDARY-END(34359929795)
            
            //--TRIMMABLE-BOUNDARY-START(17180060611)
            /*Func<MemoryCache, IEnumerable>*/ static _getKeys = null;
            //--TRIMMABLE-BOUNDARY-END(17180060611)
            
            //--TRIMMABLE-BOUNDARY-START(38654897091)
            static /*IEnumerable */ GetKeys(/*this IMemoryCache*/ memoryCache)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654897091);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$DJRY.LCFCD.MemoryCacheExtensions._getKeys.Invoke($.$cast(memoryCache, $.$mecm.MECM.MemoryCache));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654897091)
            
            //--TRIMMABLE-BOUNDARY-START(42949864387)
            static /*IEnumerable<T> */ GetKeys$1(T, /*this IMemoryCache*/ memoryCache)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949864387);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.OfType(T, $.$DJRY.LCFCD.MemoryCacheExtensions.GetKeys(memoryCache));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949864387)
            
            //--TRIMMABLE-BOUNDARY-START(30064962499)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064962499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590126019)
                    this._getEntries6 = new ($.$$.S.Lazy$$($.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.S.Object)))().$ctor$6(new ($.$$.S.Func$$($.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.S.Object)))().$ctor(this,  () =>
                    {
                        return $.$cast($.$$.S.Delegate.CreateDelegate$6($.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.S.Object).$type, $.$mecm.MECM.MemoryCache.$type.GetProperty$1("EntriesCollection", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/).GetGetMethod$1(true), true), $.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.S.Object));
                    }, $kiOaOa ??= {"r":$.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.S.Object).$h,"n":"","d":191427,"h":0,"f":17825794}));
                    //--TRIMMABLE-BOUNDARY-END(8590126019)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295158723)
                    this._getCoherentState = new ($.$$.S.Lazy$$($.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.S.Object)))().$ctor$6(new ($.$$.S.Func$$($.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.S.Object)))().$ctor(this,  () =>
                    {
                        return $.$DJRY.LCFCD.MemoryCacheExtensions.CreateGetter($.$mecm.MECM.MemoryCache, $.$$.S.Object, $.$mecm.MECM.MemoryCache.$type.GetField$1("_coherentState", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/));
                    }, $JVAhVj ??= {"r":$.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.S.Object).$h,"n":"","d":191427,"h":0,"f":17825794}));
                    //--TRIMMABLE-BOUNDARY-END(4295158723)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885093315)
                    this._getEntries7 = new ($.$$.S.Lazy$$($.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary)))().$ctor$6(new ($.$$.S.Func$$($.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary)))().$ctor(this,  () =>
                    {
                        return $.$DJRY.LCFCD.MemoryCacheExtensions.CreateGetter($.$$.S.Object, $.$$.SC$1.IDictionary, $.$mecm.MECM.MemoryCache.$type.GetNestedType("CoherentState", 32/*BindingFlags.NonPublic*/).GetField$1("_entries", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/));
                    }, $cTXwFe ??= {"r":$.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary).$h,"n":"","d":191427,"h":0,"f":17825794}));
                    //--TRIMMABLE-BOUNDARY-END(12885093315)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769995203)
                    this._getStringEntries8010 = new ($.$$.S.Lazy$$($.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary)))().$ctor$6(new ($.$$.S.Func$$($.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary)))().$ctor(this,  () =>
                    {
                        return $.$DJRY.LCFCD.MemoryCacheExtensions.CreateGetter($.$$.S.Object, $.$$.SC$1.IDictionary, $.$mecm.MECM.MemoryCache.$type.GetNestedType("CoherentState", 32/*BindingFlags.NonPublic*/).GetField$1("_stringEntries", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/));
                    }, $WsjtYe ??= {"r":$.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary).$h,"n":"","d":191427,"h":0,"f":17825794}));
                    //--TRIMMABLE-BOUNDARY-END(25769995203)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475027907)
                    this._getNonStringEntries8010 = new ($.$$.S.Lazy$$($.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary)))().$ctor$6(new ($.$$.S.Func$$($.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary)))().$ctor(this,  () =>
                    {
                        return $.$DJRY.LCFCD.MemoryCacheExtensions.CreateGetter($.$$.S.Object, $.$$.SC$1.IDictionary, $.$mecm.MECM.MemoryCache.$type.GetNestedType("CoherentState", 32/*BindingFlags.NonPublic*/).GetField$1("_nonStringEntries", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/));
                    }, $bYonXj ??= {"r":$.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary).$h,"n":"","d":191427,"h":0,"f":17825794}));
                    //--TRIMMABLE-BOUNDARY-END(21475027907)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180060611)
                    this._getKeys = (() =>
                    {
                        let $switch1 = $.$sdf.SD.FileVersionInfo.GetVersionInfo($.$$.SR.Assembly.GetAssembly($.$mecm.MECM.MemoryCache.$type).Location);
                        if ($switch1.ProductMajorPart < 7)
                        {
                            return new ($.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.SC$1.IEnumerable))().$ctor($.$DJRY.LCFCD.MemoryCacheExtensions, /*static*/ (/*cache*/ cache) =>
                            {
                                return ($.$cast($.$DJRY.LCFCD.MemoryCacheExtensions._getEntries6.Value.Invoke(cache), $.$$.SC$1.IDictionary)).SC$1$IDictionary$Keys;
                            }, $CoViYh ??= {"r":63373313,"p":[{"n":"cache","p":262247}],"n":"","d":191427,"h":0,"f":17825826});
                        }
                        if (($switch1.ProductMajorPart < 8) || ($switch1.ProductMajorPart === 8 && $switch1.ProductMinorPart === 0 && $switch1.ProductBuildPart < 10))
                        {
                            return new ($.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.SC$1.IEnumerable))().$ctor($.$DJRY.LCFCD.MemoryCacheExtensions, /*static*/ (/*cache*/ cache) =>
                            {
                                return $.$DJRY.LCFCD.MemoryCacheExtensions._getEntries7.Value.Invoke($.$DJRY.LCFCD.MemoryCacheExtensions._getCoherentState.Value.Invoke(cache)).SC$1$IDictionary$Keys;
                            }, $LYuAtj ??= {"r":63373313,"p":[{"n":"cache","p":262247}],"n":"","d":191427,"h":0,"f":17825826});
                        }
                        return new ($.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.SC$1.IEnumerable))().$ctor($.$DJRY.LCFCD.MemoryCacheExtensions, /*static*/ (/*cache*/ cache) =>
                        {
                            return $.$sl.SL.Enumerable.Concat($.$$.S.Object, $.$$.N.InterfaceVarianceStubHandler.Create(($.$$.N.InterfaceVarianceStubHandler.Create($.$cast($.$DJRY.LCFCD.MemoryCacheExtensions._getStringEntries8010.Value.Invoke($.$DJRY.LCFCD.MemoryCacheExtensions._getCoherentState.Value.Invoke(cache)).SC$1$IDictionary$Keys, $.$$.SCG.ICollection$$($.$$.S.String)), $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.SCG.IEnumerable$$($.$$.S.Object)), $.$cast($.$DJRY.LCFCD.MemoryCacheExtensions._getNonStringEntries8010.Value.Invoke($.$DJRY.LCFCD.MemoryCacheExtensions._getCoherentState.Value.Invoke(cache)).SC$1$IDictionary$Keys, $.$$.SCG.ICollection$$($.$$.S.Object)));
                        }, $UDiMzj ??= {"r":63373313,"p":[{"n":"cache","p":262247}],"n":"","d":191427,"h":0,"f":17825826});
                    })();
                    //--TRIMMABLE-BOUNDARY-END(17180060611)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064962499)
            
            static $h = 191427;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34359929795),
    {
      "r": (TParam, TReturn) => $.$$.S.Func$$$(TParam, TReturn).$h,
      "p": [
        {
          "n": "field",
          "p": 114622465
        }
      ],
      "g": [
        "TParam",
        "TReturn"
      ],
      "n": "CreateGetter",
      "d": 191427,
      "h": 34359929795,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(34359929795),
//--TRIMMABLE-BOUNDARY-START(38654897091),
    {
      "r": 63373313,
      "p": [
        {
          "n": "memoryCache",
          "p": 1114214
        }
      ],
      "n": "GetKeys",
      "d": 191427,
      "h": 38654897091,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654897091),
//--TRIMMABLE-BOUNDARY-START(42949864387),
    {
      "r": (T) => $.$$.SCG.IEnumerable$$(T).$h,
      "p": [
        {
          "n": "memoryCache",
          "p": 1114214
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetKeys",
      "o": "@$1",
      "d": 191427,
      "h": 42949864387,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42949864387)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590126019),
    {
      "t": $.$$.S.Lazy$$($.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.S.Object)).$h,
      "n": "_getEntries6",
      "d": 191427,
      "h": 8590126019,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590126019),
//--TRIMMABLE-BOUNDARY-START(4295158723),
    {
      "t": $.$$.S.Lazy$$($.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.S.Object)).$h,
      "n": "_getCoherentState",
      "d": 191427,
      "h": 4295158723,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295158723),
//--TRIMMABLE-BOUNDARY-START(12885093315),
    {
      "t": $.$$.S.Lazy$$($.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary)).$h,
      "n": "_getEntries7",
      "d": 191427,
      "h": 12885093315,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885093315),
//--TRIMMABLE-BOUNDARY-START(25769995203),
    {
      "t": $.$$.S.Lazy$$($.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary)).$h,
      "n": "_getStringEntries8010",
      "d": 191427,
      "h": 25769995203,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25769995203),
//--TRIMMABLE-BOUNDARY-START(21475027907),
    {
      "t": $.$$.S.Lazy$$($.$$.S.Func$$$($.$$.S.Object, $.$$.SC$1.IDictionary)).$h,
      "n": "_getNonStringEntries8010",
      "d": 191427,
      "h": 21475027907,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21475027907),
//--TRIMMABLE-BOUNDARY-START(17180060611),
    {
      "t": $.$$.S.Func$$$($.$mecm.MECM.MemoryCache, $.$$.SC$1.IEnumerable).$h,
      "n": "_getKeys",
      "d": 191427,
      "h": 17180060611,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180060611)
  ],
  "h": 191427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Dynamic.MemoryCacheExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Dynamic${separator}MemoryCacheExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(191427)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.DynamicExpresso.Core", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(60355)
