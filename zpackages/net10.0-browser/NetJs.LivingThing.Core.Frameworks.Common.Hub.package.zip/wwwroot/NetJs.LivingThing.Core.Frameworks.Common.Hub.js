
//--TRIMMABLE-BOUNDARY-START(10697)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt) {
    "use strict";
    let _;
    let $ZPgiKc;
    let $Gsnvvc;
    let $fCAJVa;
    let $sEWcmf;
    let $NCimId;
    let $ecPaja;
    let $Ntlkff;
    let $ylDVZg;
    let $MFXzqe;
    let $JFzayb;
    let $GIquRh;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Hub", 
    {
  "h": 10697,
  "f": "LivingThing.Core.Frameworks.Common.Hub",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Hub",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Hub",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(600521)
        $asm.$cls(`$kVHt.LCFCH.IPluginHubServer`, ($self) => class IPluginHubServer
        {
            static $h = 600521;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 600521
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IPluginHubServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IPluginHubServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(600521)
        
        

        //--TRIMMABLE-BOUNDARY-START(469449)
        $asm.$cls(`$kVHt.LCFCH.IHubConnector<>`, (/*in*/ THubClient) => $asm.$gt(`$kVHt.LCFCH.IHubConnector<>`, [/*in*/ THubClient], ($self) => class IHubConnector$$
        {
            static $H = 469449;
            static $h = 469449;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475305929),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360207817,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331905
      },
      "n": "ConnectionId",
      "o": "LCFCH$IHubConnector$$$ConnectionId",
      "d": this.$h,
      "H": 21475305929,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475305929)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770273225),
    {
      "r": 178454529,
      "p": [
        {
          "n": "timeOutMs",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "EnsureConnected",
      "o": "LCFCH$IHubConnector$$$EnsureConnected",
      "d": this.$h,
      "H": 25770273225,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770273225),
//--TRIMMABLE-BOUNDARY-START(64424978889),
    {
      "r": 91095041,
      "p": [
        {
          "n": "client",
          "p": THubClient?.$h??1572864,
          "f": 32
        }
      ],
      "n": "Subscribe",
      "o": "LCFCH$IHubConnector$$$Subscribe",
      "d": this.$h,
      "H": 64424978889,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(64424978889)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(38655175113),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_OnConnected",
        "o": "LCFCH$IHubConnector$$$add_OnConnected",
        "d": this.$h,
        "H": 8590404041,
        "h": Number(BigInt(this.$h)|0x200000000n),
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_OnConnected",
        "o": "LCFCH$IHubConnector$$$remove_OnConnected",
        "d": this.$h,
        "H": 51540077001,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 285212929
      },
      "n": "OnConnected",
      "o": "LivingThing$Core$Frameworks$Common$Hub$IHubConnector$$$OnConnected",
      "d": this.$h,
      "H": 38655175113,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(38655175113),
//--TRIMMABLE-BOUNDARY-START(42950142409),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_OnDisconnected",
        "o": "LCFCH$IHubConnector$$$add_OnDisconnected",
        "d": this.$h,
        "H": 17180338633,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_OnDisconnected",
        "o": "LCFCH$IHubConnector$$$remove_OnDisconnected",
        "d": this.$h,
        "H": 60130011593,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 285212929
      },
      "n": "OnDisconnected",
      "o": "LivingThing$Core$Frameworks$Common$Hub$IHubConnector$$$OnDisconnected",
      "d": this.$h,
      "H": 42950142409,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(42950142409)
  ],
  "s": [
    {
      "h": THubClient?.$h??1572864,
      "n": "THubClient",
      "f": 16,
      "c": [534985
      ]
    }
  ],
  "r": 1,
  "H": 469449,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IHubConnector<${THubClient?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IHubConnector$${THubClient?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(469449)
        
        

        //--TRIMMABLE-BOUNDARY-START(534985)
        $asm.$cls(`$kVHt.LCFCH.IPluginHubClient`, ($self) => class IPluginHubClient
        {
            static $h = 534985;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 534985
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IPluginHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IPluginHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(534985)
        
        

        //--TRIMMABLE-BOUNDARY-START(338377)
        $asm.$cls(`$kVHt.LCFCH.IComponentHubServer`, ($self) => class IComponentHubServer
        {
            static $h = 338377;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 338377
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IPluginHubServer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IComponentHubServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IComponentHubServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(338377)
        
        

        //--TRIMMABLE-BOUNDARY-START(797129)
        $asm.$cls(`$kVHt.LCFCH.IWebSocketClientHub`, ($self) => class IWebSocketClientHub
        {
            static $h = 797129;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 797129
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IWebSocketClientHub`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IWebSocketClientHub`; }
        });
        //--TRIMMABLE-BOUNDARY-END(797129)
        
        

        //--TRIMMABLE-BOUNDARY-START(272841)
        $asm.$cls(`$kVHt.LCFCH.IComponentHubClient`, ($self) => class IComponentHubClient
        {
            static $h = 272841;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 272841
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IComponentHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IComponentHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(272841)
        
        

        //--TRIMMABLE-BOUNDARY-START(862665)
        $asm.$cls(`$kVHt.LCFCH.IWebSocketServerHub`, ($self) => class IWebSocketServerHub
        {
            static $h = 862665;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 862665
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IWebSocketServerHub`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IWebSocketServerHub`; }
        });
        //--TRIMMABLE-BOUNDARY-END(862665)
        
        

        //--TRIMMABLE-BOUNDARY-START(403913)
        $asm.$cls(`$kVHt.LCFCH.IHubConnector<,>`, (/*in*/ THubClient, TServerHub) => $asm.$gt(`$kVHt.LCFCH.IHubConnector<,>`, [/*in*/ THubClient, TServerHub], ($self) => class IHubConnector$$$
        {
            static $H = 403913;
            static $h = 403913;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295371209),
    {
      "r": 181338113,
      "p": [
        {
          "n": "execute",
          "p": $.$$.S.Func$$$(TServerHub, $.$$.STT.ValueTask).$h
        }
      ],
      "n": "Execute",
      "o": `LCFCH$IHubConnector$${THubClient.$getFullName('$')}$${TServerHub.$getFullName('$')}$Execute`,
      "d": this.$h,
      "H": 4295371209,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295371209),
//--TRIMMABLE-BOUNDARY-START(8590338505),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "execute",
          "p": (T) => $.$$.S.Func$$$(TServerHub, $.$$.STT.ValueTask$$(T)).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Execute",
      "o": `LCFCH$IHubConnector$$$$Execute$${THubClient.$getFullName('$')}$${TServerHub.$getFullName('$')}$1`,
      "d": this.$h,
      "H": 8590338505,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590338505)
  ],
  "s": [
    {
      "h": THubClient?.$h??1572864,
      "n": "THubClient",
      "f": 16,
      "c": [534985
      ]
    },
    {
      "h": TServerHub?.$h??1638400,
      "n": "TServerHub",
      "f": 1
    }
  ],
  "r": 2,
  "H": 403913,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IHubConnector$$(THubClient) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IHubConnector<${THubClient?.$fullName},${TServerHub?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IHubConnector$${THubClient?.$getFullName(separator)}$${TServerHub?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(403913)
        
        

        //--TRIMMABLE-BOUNDARY-START(993737)
        $asm.$cls(`$kVHt.LCFCH.IWebSocketServerHub<>`, (TClientInterface) => $asm.$gt(`$kVHt.LCFCH.IWebSocketServerHub<>`, [TClientInterface], ($self) => class IWebSocketServerHub$$
        {
            static $H = 993737;
            static $h = 993737;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TClientInterface?.$h??1572864,
      "n": "TClientInterface"
    }
  ],
  "r": 1,
  "H": 993737,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IWebSocketServerHub, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IWebSocketServerHub<${TClientInterface?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IWebSocketServerHub$${TClientInterface?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(993737)
        
        

        //--TRIMMABLE-BOUNDARY-START(666057)
        $asm.$cls(`$kVHt.LCFCH.IServiceHubClient`, ($self) => class IServiceHubClient
        {
            static $h = 666057;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 666057
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IServiceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IServiceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(666057)
        
        

        //--TRIMMABLE-BOUNDARY-START(731593)
        $asm.$cls(`$kVHt.LCFCH.IServiceHubServer`, ($self) => class IServiceHubServer
        {
            static $h = 731593;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 731593
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IComponentHubServer, $.$kVHt.LCFCH.IPluginHubServer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IServiceHubServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IServiceHubServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(731593)
        
        

        //--TRIMMABLE-BOUNDARY-START(928201)
        $asm.$cls(`$kVHt.LCFCH.IWebSocketServerHub<,>`, (TServerInterface, TClientInterface) => $asm.$gt(`$kVHt.LCFCH.IWebSocketServerHub<,>`, [TServerInterface, TClientInterface], ($self) => class IWebSocketServerHub$$$
        {
            static $H = 928201;
            static $h = 928201;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TServerInterface?.$h??1572864,
      "n": "TServerInterface"
    },
    {
      "h": TClientInterface?.$h??1638400,
      "n": "TClientInterface"
    }
  ],
  "r": 2,
  "H": 928201,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IWebSocketServerHub$$(TClientInterface), $.$kVHt.LCFCH.IWebSocketServerHub, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.IWebSocketServerHub<${TServerInterface?.$fullName},${TClientInterface?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}IWebSocketServerHub$${TServerInterface?.$getFullName(separator)}$${TClientInterface?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(928201)
        
        

        //--TRIMMABLE-BOUNDARY-START(76233)
        $asm.$cls(`$kVHt.LCFCH.BaseClientHubConnector<,,>`, (THubClient, THubServer, TConnection) => $asm.$gt(`$kVHt.LCFCH.BaseClientHubConnector<,,>`, [THubClient, THubServer, TConnection], ($self) => class BaseClientHubConnector$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47244716489)
            /*TConnection?*/ connection = null;
            //--TRIMMABLE-BOUNDARY-END(47244716489)
            
            //--TRIMMABLE-BOUNDARY-START(34359814601)
            /*IApplicationContextProvider*/ applicationContext = null;
            //--TRIMMABLE-BOUNDARY-END(34359814601)
            
            //--TRIMMABLE-BOUNDARY-START(68719552969)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(68719552969)
            
            //--TRIMMABLE-BOUNDARY-START(60129618377)
            /*List<IDisposable>*/ disposables = null;
            //--TRIMMABLE-BOUNDARY-END(60129618377)
            
            //--TRIMMABLE-BOUNDARY-START(214748441033)
            /*ConcurrentDictionary<TaskCompletionSource, TaskCompletionSource>*/ waitingConnections = null;
            //--TRIMMABLE-BOUNDARY-END(214748441033)
            
            //--TRIMMABLE-BOUNDARY-START(12884978121)
            $ctor$1(/*IApplicationContextProvider*/ appContext)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884978121);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.applicationContext = appContext;
                    this.ConnectionId = $.$fPer.LCFCS$6.StringExtension.GetRandomString(16, true, true, false);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884978121)
            
            //--TRIMMABLE-BOUNDARY-START(51539683785)
            /*string*/ ConnectionId = null;
            //--TRIMMABLE-BOUNDARY-END(51539683785)
            
            //--TRIMMABLE-BOUNDARY-START(184683669961)
            /*string */ get Route()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964193225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let route = $.$$.S.String.Replace$3.call(THubClient.$type.Name, "Client", "");
                if ($.$$.S.String.get_Chars.call(route, 0) === /*I*/ 73)
                {
                    route = $.$$.S.String.Substring$1.call(route, 1);
                }
                return route;
            }
            //--TRIMMABLE-BOUNDARY-END(184683669961)
            
            //--TRIMMABLE-BOUNDARY-START(128849095113)
            /*Stringy */ get Host()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374258633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let attr = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributeFast$5($.$kVHt.LCFCH.HubAttribute, THubClient.$type, null, false, true);
                /*var*/ let host = (attr?.RemoteHost ?? null) ?? this.applicationContext.LCFC$IApplicationContextProvider$RemoteHost;
                if ($.$$.S.String.StartsWith$3.call(host, "https://"))
                {
                    return $.$fPer.LCFC.StringyExtension.AsStringy$1(host).Slice$1("https://".length);
                }
                if ($.$$.S.String.StartsWith$3.call(host, "http://"))
                {
                    return $.$fPer.LCFC.StringyExtension.AsStringy$1(host).Slice$1("http://".length);
                }
                return $.$fPer.LCFC.Stringy.op_Implicit$3(host);
            }
            //--TRIMMABLE-BOUNDARY-END(128849095113)
            
            //--TRIMMABLE-BOUNDARY-START(188978637257)
            /*Stringy */ get Scheme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554127817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let attr = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributeFast$5($.$kVHt.LCFCH.HubAttribute, THubClient.$type, null, false, true);
                /*var*/ let host = (attr?.RemoteHost ?? null) ?? this.applicationContext.LCFC$IApplicationContextProvider$RemoteHost;
                if ($.$$.S.String.StartsWith$3.call(host, "https://"))
                {
                    return $.$fPer.LCFC.Stringy.op_Implicit$3("wss");
                }
                if ($.$$.S.String.StartsWith$3.call(host, "http://"))
                {
                    return $.$fPer.LCFC.Stringy.op_Implicit$3("ws");
                }
                return $.$fPer.LCFC.Stringy.op_Implicit$3("wss");
            }
            //--TRIMMABLE-BOUNDARY-END(188978637257)
            
            //--TRIMMABLE-BOUNDARY-START(158913866185)
            /*EventHandler?*/ OnConnected = null;
            //--TRIMMABLE-BOUNDARY-END(158913866185)
            
            //--TRIMMABLE-BOUNDARY-START(158913866185)
            //--TRIMMABLE-BOUNDARY-START(21474912713)
            add_OnConnected(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474912713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnConnected = $.$$.S.Delegate.Combine$2(this.OnConnected, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21474912713)
            
            //--TRIMMABLE-BOUNDARY-START(171798768073)
            remove_OnConnected(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798768073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnConnected = $.$$.S.Delegate.Remove(this.OnConnected, value);
            }
            //--TRIMMABLE-BOUNDARY-END(171798768073)
            
            //--TRIMMABLE-BOUNDARY-END(158913866185)
            
            //--TRIMMABLE-BOUNDARY-START(163208833481)
            /*EventHandler?*/ OnDisconnected = null;
            //--TRIMMABLE-BOUNDARY-END(163208833481)
            
            //--TRIMMABLE-BOUNDARY-START(163208833481)
            //--TRIMMABLE-BOUNDARY-START(30064847305)
            add_OnDisconnected(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064847305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDisconnected = $.$$.S.Delegate.Combine$2(this.OnDisconnected, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30064847305)
            
            //--TRIMMABLE-BOUNDARY-START(180388702665)
            remove_OnDisconnected(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388702665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDisconnected = $.$$.S.Delegate.Remove(this.OnDisconnected, value);
            }
            //--TRIMMABLE-BOUNDARY-END(180388702665)
            
            //--TRIMMABLE-BOUNDARY-END(163208833481)
            
            //--TRIMMABLE-BOUNDARY-START(146028964297)
            /*void */ NotifyConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146028964297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnConnected?.Invoke(this, $.$$.S.EventArgs.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(146028964297)
            
            //--TRIMMABLE-BOUNDARY-START(150323931593)
            /*void */ NotifyDisconnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150323931593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDisconnected?.Invoke(this, $.$$.S.EventArgs.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(150323931593)
            
            //--TRIMMABLE-BOUNDARY-START(73014520265)
            /*Task *//*async*/  EnsureConnected(/*int*/ timeOutMs)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014520265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.connection === null)
                    {
                        _ = this.StartConnect(null);
                    }
                    if (this.IsConnected())
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    if (timeOutMs < 1000)
                    {
                        timeOutMs = 1000;
                    }
                    /*var*/ let connectionReady = new $.$$.STT.TaskCompletionSource().$ctor$1();
                    this.waitingConnections.set_Item$1(connectionReady, connectionReady);
                    /*CancellationTokenSource*/ let cts = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                    cts.CancelAfter(timeOutMs);
                    cts.Token.Register$1(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        connectionReady.TrySetCanceled();
                        this.waitingConnections.TryRemove$1(connectionReady, $.$discardRef());
                    }, $Ntlkff ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    ($t1 = connectionReady.Task, ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    this.waitingConnections.TryRemove$1(connectionReady, $.$discardRef());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73014520265)
            
            //--TRIMMABLE-BOUNDARY-START(201863539145)
            /*Task *//*async*/  StartConnect(/*Exception?*/ error)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201863539145);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.disposed)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    if (error !== null)
                    {
                        let $t2, $r2;
                        ($t2 = $.$$.STT.Task.Delay$1((($.$$.S.Random.Shared.Next$1(3, 5) * 1000) | 0)).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    //lock(this)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this)
                        {
                            if (this.disposed)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                            this.connection = this.CreateConnection(this.connection);
                            this.disposables.ForEach(new ($.$$.S.Action$$($.$$.S.IDisposable))().$ctor(this,  (/*d*/ d) =>
                            {
                                return d.S$IDisposable$Dispose();
                            }, $ylDVZg ??= {"r":65537,"p":[{"n":"d","p":91095041}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            this.disposables.Clear();
                            /*var*/ let methods = $.$fPer.LCFCT.TypesExtensions.GetIMethods(THubClient.$type);
                            let $en3 = methods.SCG$IEnumerable$$$GetEnumerator();
                            while ($en3.SC$1$IEnumerator$MoveNext())
                            {
                                let _method = $en3.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let method = _method;
                                    /*IDisposable*/ let disposable = this.OnClientMethod(this.connection, method, new ($.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$$.STT.Task))().$ctor(this,  (/*parameters*/ parameters) =>
                                    {
                                        let $en4 = this.clients.GetEnumerator();
                                        while ($en4.MoveNext())
                                        {
                                            let cl = $en4.Current;
                                            {
                                                method.Invoke($.$box(cl, THubClient), parameters);
                                            }
                                        }
                                        return $.$$.STT.Task.CompletedTask;
                                    }, $MFXzqe ??= {"r":178454529,"p":[{"n":"parameters","p":$.$typeArray($.$$.S.Object).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                    this.disposables.Add(disposable);
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this)
                    }
                    try
                    {
                        let $t5, $r5;
                        ($t5 = this.StartConnection(this.connection), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                        this.NotifyConnected();
                        let $en6 = this.waitingConnections.GetEnumerator();
                        while ($en6.SC$1$IEnumerator$MoveNext())
                        {
                            let vv = $en6.SCG$IEnumerator$$$Current;
                            {
                                vv.Value.TrySetResult();
                            }
                        }
                        this.waitingConnections.Clear();
                    }
                    catch(e)
                    {
                        $.$fPer.LCFCL.LoggingFactory.LogException(e, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Hub\\BaseClientHubConnector.cs", "StartConnect", 200);
                        if (!this.disposed)
                        {
                            _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                            {
                                return this.StartConnect(e);
                            }, $JFzayb ??= {"r":178454529,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201863539145)
            
            //--TRIMMABLE-BOUNDARY-START(38654781897)
            /*List<THubClient>*/ clients = null;
            //--TRIMMABLE-BOUNDARY-END(38654781897)
            
            //--TRIMMABLE-BOUNDARY-START(210453473737)
            /*IDisposable */ Subscribe(/*THubClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453473737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                client = $.$firstOf(client, () => { throw new $.$$.S.NullReferenceException().$ctor$9() });
                if (!this.clients.Contains(client))
                {
                    this.clients.Add(client);
                }
                return new ($.$kVHt.LCFCH.HubClientDisposer$$$$(THubClient, THubServer, TConnection))().$ctor$1(this, client);
            }
            //--TRIMMABLE-BOUNDARY-END(210453473737)
            
            //--TRIMMABLE-BOUNDARY-START(77309487561)
            /*ValueTask *//*async*/  Execute(/*Func<THubServer, ValueTask>*/ execute)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t7, $r7;
                    let $t8, $r8;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309487561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t7 = this.EnsureConnected(0), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    /*var*/ let t = $.$zHIt.LCFCM.Mock.Interface$2(THubServer, this, true);
                    ($t8 = execute.Invoke(t), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77309487561)
            
            //--TRIMMABLE-BOUNDARY-START(81604454857)
            /*ValueTask<T> *//*async*/  Execute$1(T, /*Func<THubServer, ValueTask<T>>*/ execute)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T), T, async ($asnycContext) => 
                {
                    let $t9, $r9;
                    let $t10, $r10;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604454857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t9 = this.EnsureConnected(0), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    /*var*/ let t = $.$zHIt.LCFCM.Mock.Interface$2(THubServer, this, true);
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t10 = execute.Invoke(t), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81604454857)
            
            //--TRIMMABLE-BOUNDARY-START(64424585673)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424585673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        this.disposed = true;
                        this.clients.Clear();
                        this.disposables.ForEach(new ($.$$.S.Action$$($.$$.S.IDisposable))().$ctor(this,  (/*d*/ d) =>
                        {
                            return d.S$IDisposable$Dispose();
                        }, $GIquRh ??= {"r":65537,"p":[{"n":"d","p":91095041}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        this.disposables.Clear();
                        if (this.connection !== null)
                        {
                            this.CloseConnection(this.connection);
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424585673)
            
            //--TRIMMABLE-BOUNDARY-START(133144062409)
            /*TResult */ Invoke(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144062409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(133144062409)
            
            //--TRIMMABLE-BOUNDARY-START(4295371209)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient, THubServer>.Execute(System.Func<THubServer, System.Threading.Tasks.ValueTask>)
            [`LCFCH$IHubConnector$${THubClient.$getFullName('$')}$${THubServer.$getFullName('$')}$Execute`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295371209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295371209)
            
            //--TRIMMABLE-BOUNDARY-START(8590338505)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient, THubServer>.Execute<T>(System.Func<THubServer, System.Threading.Tasks.ValueTask<T>>)
            [`LCFCH$IHubConnector$$$$Execute$${THubClient.$getFullName('$')}$${THubServer.$getFullName('$')}$1`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590338505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590338505)
            
            //--TRIMMABLE-BOUNDARY-START(25770273225)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient>.EnsureConnected(int)
            LCFCH$IHubConnector$$$EnsureConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770273225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EnsureConnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770273225)
            
            //--TRIMMABLE-BOUNDARY-START(64424978889)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient>.Subscribe(THubClient)
            LCFCH$IHubConnector$$$Subscribe()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424978889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Subscribe(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(64424978889)
            
            //--TRIMMABLE-BOUNDARY-START(34360207817)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient>.ConnectionId.get
            get LCFCH$IHubConnector$$$ConnectionId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475305929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ConnectionId;
            }
            //--TRIMMABLE-BOUNDARY-END(34360207817)
            
            //--TRIMMABLE-BOUNDARY-START(8590404041)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient>.OnConnected.add
            LCFCH$IHubConnector$$$add_OnConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590404041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_OnConnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590404041)
            
            //--TRIMMABLE-BOUNDARY-START(51540077001)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient>.OnConnected.remove
            LCFCH$IHubConnector$$$remove_OnConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540077001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_OnConnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51540077001)
            
            //--TRIMMABLE-BOUNDARY-START(38655175113)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient>.OnConnected
            LivingThing$Core$Frameworks$Common$Hub$IHubConnector$$$OnConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655175113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnConnected;
            }
            //--TRIMMABLE-BOUNDARY-END(38655175113)
            
            //--TRIMMABLE-BOUNDARY-START(17180338633)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient>.OnDisconnected.add
            LCFCH$IHubConnector$$$add_OnDisconnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180338633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_OnDisconnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180338633)
            
            //--TRIMMABLE-BOUNDARY-START(60130011593)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient>.OnDisconnected.remove
            LCFCH$IHubConnector$$$remove_OnDisconnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130011593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_OnDisconnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60130011593)
            
            //--TRIMMABLE-BOUNDARY-START(42950142409)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Hub.IHubConnector<THubClient>.OnDisconnected
            LivingThing$Core$Frameworks$Common$Hub$IHubConnector$$$OnDisconnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950142409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDisconnected;
            }
            //--TRIMMABLE-BOUNDARY-END(42950142409)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(4295159622)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mocking.IMockImplement.Invoke<TInterface, TResult>(LivingThing.Core.Frameworks.Common.Mocking.MockMethodContext, params LivingThing.Core.Frameworks.Common.Mocking.MockMethodParameter[])
            LCFCM$IMockImplement$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295159622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295159622)
            
            //--TRIMMABLE-BOUNDARY-START(8590126918)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mocking.IMockImplement.InvokeAsync<TInterface, TResult>(LivingThing.Core.Frameworks.Common.Mocking.MockMethodContext, params LivingThing.Core.Frameworks.Common.Mocking.MockMethodParameter[])
            LCFCM$IMockImplement$InvokeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590126918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590126918)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60129618377)
                this.disposables = new ($.$$.SCG.List$$($.$$.S.IDisposable))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(60129618377)
                
                //--TRIMMABLE-BOUNDARY-START(214748441033)
                this.waitingConnections = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.STT.TaskCompletionSource, $.$$.STT.TaskCompletionSource))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(214748441033)
                
                //--TRIMMABLE-BOUNDARY-START(38654781897)
                this.clients = new ($.$$.SCG.List$$(THubClient))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(38654781897)
                
            }
            static $H = 76233;
            static $h = 76233;
            static $g = 3;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51539683785),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98784324041,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "n": "ConnectionId",
      "d": this.$h,
      "H": 51539683785,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539683785),
//--TRIMMABLE-BOUNDARY-START(184683669961),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115964193225,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331652
      },
      "n": "Route",
      "d": this.$h,
      "H": 184683669961,
      "h": Number(BigInt(this.$h)|0x2B00000000n),
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(184683669961),
//--TRIMMABLE-BOUNDARY-START(128849095113),
    {
      "p": 64915798,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107374258633,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331652
      },
      "n": "Host",
      "d": this.$h,
      "H": 128849095113,
      "h": Number(BigInt(this.$h)|0x1E00000000n),
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(128849095113),
//--TRIMMABLE-BOUNDARY-START(188978637257),
    {
      "p": 64915798,
      "g": {
        "r": 0,
        "d": 0,
        "H": 124554127817,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 50331652
      },
      "n": "Scheme",
      "d": this.$h,
      "H": 188978637257,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(188978637257),
//--TRIMMABLE-BOUNDARY-START(38654781897),
    {
      "p": $.$$.SCG.List$$(THubClient).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90194389449,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331664
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 197568571849,
        "h": Number(BigInt(this.$h)|0x2E00000000n),
        "f": 83886096
      },
      "n": "clients",
      "d": this.$h,
      "H": 38654781897,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097168
    },
//--TRIMMABLE-BOUNDARY-END(38654781897)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146028964297),
    {
      "r": 65537,
      "n": "NotifyConnected",
      "d": this.$h,
      "H": 146028964297,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(146028964297),
//--TRIMMABLE-BOUNDARY-START(150323931593),
    {
      "r": 65537,
      "n": "NotifyDisconnected",
      "d": this.$h,
      "H": 150323931593,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(150323931593),
//--TRIMMABLE-BOUNDARY-START(55834651081),
    {
      "r": TConnection?.$h??1703936,
      "p": [
        {
          "n": "currentConnection",
          "p": TConnection?.$h??1703936
        }
      ],
      "n": "CreateConnection",
      "d": this.$h,
      "H": 55834651081,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(55834651081),
//--TRIMMABLE-BOUNDARY-START(42949749193),
    {
      "r": 65537,
      "p": [
        {
          "n": "connection",
          "p": TConnection?.$h??1703936
        }
      ],
      "n": "CloseConnection",
      "d": this.$h,
      "H": 42949749193,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(42949749193),
//--TRIMMABLE-BOUNDARY-START(206158506441),
    {
      "r": 178454529,
      "p": [
        {
          "n": "connection",
          "p": TConnection?.$h??1703936
        }
      ],
      "n": "StartConnection",
      "d": this.$h,
      "H": 206158506441,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(206158506441),
//--TRIMMABLE-BOUNDARY-START(141733997001),
    {
      "r": 262145,
      "n": "IsConnected",
      "d": this.$h,
      "H": 141733997001,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(141733997001),
//--TRIMMABLE-BOUNDARY-START(154618898889),
    {
      "r": 91095041,
      "p": [
        {
          "n": "connection",
          "p": TConnection?.$h??1703936
        },
        {
          "n": "method",
          "p": 117571585
        },
        {
          "n": "handler",
          "p": $.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$$.STT.Task).$h
        }
      ],
      "n": "OnClientMethod",
      "d": this.$h,
      "H": 154618898889,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(154618898889),
//--TRIMMABLE-BOUNDARY-START(73014520265),
    {
      "r": 178454529,
      "p": [
        {
          "n": "timeOutMs",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "EnsureConnected",
      "d": this.$h,
      "H": 73014520265,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(73014520265),
//--TRIMMABLE-BOUNDARY-START(201863539145),
    {
      "r": 178454529,
      "p": [
        {
          "n": "error",
          "p": 80805889
        }
      ],
      "n": "StartConnect",
      "d": this.$h,
      "H": 201863539145,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 16781316
    },
//--TRIMMABLE-BOUNDARY-END(201863539145),
//--TRIMMABLE-BOUNDARY-START(210453473737),
    {
      "r": 91095041,
      "p": [
        {
          "n": "client",
          "p": THubClient?.$h??1572864
        }
      ],
      "n": "Subscribe",
      "d": this.$h,
      "H": 210453473737,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210453473737),
//--TRIMMABLE-BOUNDARY-START(77309487561),
    {
      "r": 181338113,
      "p": [
        {
          "n": "execute",
          "p": $.$$.S.Func$$$(THubServer, $.$$.STT.ValueTask).$h
        }
      ],
      "n": "Execute",
      "d": this.$h,
      "H": 77309487561,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(77309487561),
//--TRIMMABLE-BOUNDARY-START(81604454857),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "execute",
          "p": (T) => $.$$.S.Func$$$(THubServer, $.$$.STT.ValueTask$$(T)).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Execute",
      "o": "@$1",
      "d": this.$h,
      "H": 81604454857,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(81604454857),
//--TRIMMABLE-BOUNDARY-START(64424585673),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 64424585673,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424585673),
//--TRIMMABLE-BOUNDARY-START(133144062409),
    {
      "r": (TInterface, TResult) => TResult.$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 133144062409,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(133144062409),
//--TRIMMABLE-BOUNDARY-START(137439029705),
    {
      "r": (TInterface, TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "InvokeAsync",
      "d": this.$h,
      "H": 137439029705,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(137439029705)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47244716489),
    {
      "t": TConnection?.$h??1703936,
      "n": "connection",
      "d": this.$h,
      "H": 47244716489,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(47244716489),
//--TRIMMABLE-BOUNDARY-START(34359814601),
    {
      "t": 46041430,
      "n": "applicationContext",
      "d": this.$h,
      "H": 34359814601,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(34359814601),
//--TRIMMABLE-BOUNDARY-START(68719552969),
    {
      "t": 262145,
      "n": "disposed",
      "d": this.$h,
      "H": 68719552969,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(68719552969),
//--TRIMMABLE-BOUNDARY-START(60129618377),
    {
      "t": $.$$.SCG.List$$($.$$.S.IDisposable).$h,
      "n": "disposables",
      "d": this.$h,
      "H": 60129618377,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(60129618377),
//--TRIMMABLE-BOUNDARY-START(214748441033),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.STT.TaskCompletionSource, $.$$.STT.TaskCompletionSource).$h,
      "n": "waitingConnections",
      "d": this.$h,
      "H": 214748441033,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(214748441033)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884978121),
    {
      "p": [
        {
          "n": "appContext",
          "p": 46041430
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12884978121,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12884978121)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(158913866185),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_OnConnected",
        "d": this.$h,
        "H": 21474912713,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_OnConnected",
        "d": this.$h,
        "H": 171798768073,
        "h": Number(BigInt(this.$h)|0x2800000000n),
        "f": 285212673
      },
      "n": "OnConnected",
      "d": this.$h,
      "H": 158913866185,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(158913866185),
//--TRIMMABLE-BOUNDARY-START(163208833481),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_OnDisconnected",
        "d": this.$h,
        "H": 30064847305,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_OnDisconnected",
        "d": this.$h,
        "H": 180388702665,
        "h": Number(BigInt(this.$h)|0x2A00000000n),
        "f": 285212673
      },
      "n": "OnDisconnected",
      "d": this.$h,
      "H": 163208833481,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(163208833481)
  ],
  "s": [
    {
      "h": THubClient?.$h??1572864,
      "n": "THubClient",
      "c": [534985
      ]
    },
    {
      "h": THubServer?.$h??1638400,
      "n": "THubServer",
      "f": 1
    },
    {
      "h": TConnection?.$h??1703936,
      "n": "TConnection"
    }
  ],
  "r": 3,
  "H": 76233,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IHubConnector$$$(THubClient, THubServer), $.$kVHt.LCFCH.IHubConnector$$(THubClient), $.$$.S.IDisposable, $.$zHIt.LCFCM.IMockImplement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.BaseClientHubConnector<${THubClient?.$fullName},${THubServer?.$fullName},${TConnection?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}BaseClientHubConnector$${THubClient?.$getFullName(separator)}$${THubServer?.$getFullName(separator)}$${TConnection?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(76233)
        
        

        //--TRIMMABLE-BOUNDARY-START(1124809)
        $asm.$cls(`$kVHt.LCFCH.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296092105)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296092105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296092105)
            
            static $h = 1124809;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296092105),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1124809,
      "h": 4296092105,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296092105)
  ],
  "h": 1124809
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1124809)
        
        

        //--TRIMMABLE-BOUNDARY-START(1321417)
        $asm.$cls(`$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptorBuilder`, ($self) => class WebSocketClientMetadataTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591256009)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591256009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptor()
                        const $t1 = $.$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadata");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ZPgiKc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1321417,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$kVHt.LCFCH.WebSocketClientMetadata.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591256009)
            
            //--TRIMMABLE-BOUNDARY-START(4296288713)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296288713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296288713)
            
            //--TRIMMABLE-BOUNDARY-START(4296288713)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296288713)
            
            static $h = 1321417;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591256009),
    {
      "r": 65537,
      "n": "Register",
      "d": 1321417,
      "h": 8591256009,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591256009)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296288713),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1321417,
      "h": 4296288713,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296288713)
  ],
  "h": 1321417
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadataTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}WebSocketClientMetadataTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1321417)
        
        

        //--TRIMMABLE-BOUNDARY-START(1386953)
        $asm.$cls(`$kVHt.LCFCH.WebSocketHubUtility`, ($self) => class WebSocketHubUtility
        {
            //--TRIMMABLE-BOUNDARY-START(4296354249)
            /*int*/ static MessageBufferSize = 262144;
            //--TRIMMABLE-BOUNDARY-END(4296354249)
            
            //--TRIMMABLE-BOUNDARY-START(8591321545)
            /*byte*/ static RequestPrefix = 0;
            //--TRIMMABLE-BOUNDARY-END(8591321545)
            
            //--TRIMMABLE-BOUNDARY-START(12886288841)
            /*byte*/ static ResponsePrefix = 1;
            //--TRIMMABLE-BOUNDARY-END(12886288841)
            
            //--TRIMMABLE-BOUNDARY-START(17181256137)
            static /*Task *//*async*/  SendOverSocket(T, /*WebSocket*/ webSocket, /*T*/ data, /*byte*/ headerPrefix, /*int*/ requestId, /*CancellationToken?*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181256137);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let ser = $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(T, data, true, false, true, false, false, false, false, "SendOverSocket", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Hub\\WebSocketHubUtility.cs", "SendOverSocket", 27).Json;
                    /*var*/ let pool = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(((((ser.length * 2) | 0) + 4) | 0));
                    try
                    {
                        /*int*/ let offset = 0;
                        $.$$.System.Array.$WriteT1.call(pool, headerPrefix, offset++);
                        if (headerPrefix === 1/*ResponsePrefix*/)
                        {
                            $.$$.System.Array.$WriteT1.call(pool, $.$cast(requestId, $.$$.S.Byte), offset++);
                            $.$$.System.Array.$WriteT1.call(pool, $.$cast((requestId >> 8), $.$$.S.Byte), offset++);
                        }
                        /*int*/ let len = ((((1 + (headerPrefix === 1/*ResponsePrefix*/ ? 2 : 0)) | 0) + $.$$.ST.Encoding.UTF8.GetBytes$6(ser, 0, ser.length, pool, offset)) | 0);
                        if (len > 262144/*WebSocketHubUtility.MessageBufferSize*/)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12(`Message size is too large, Cannot send more than ${$.$strNN(262144/*WebSocketHubUtility.MessageBufferSize*/)}B. Data is ${$.$strNN(len)}B`);
                        }
                        /*int*/ let foffset = 0;
                        /*int*/ let frameLen = 1024;
                        while(len > 0)
                        {
                            let $t1, $r1;
                            /*int*/ let lframe = len >= frameLen ? frameLen : len;
                            ($t1 = webSocket.SendAsync(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$3(pool, foffset, lframe), 1/*WebSocketMessageType.Binary*/, len === lframe, token ?? $.$$.ST$1.CancellationToken.None), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                            foffset += lframe;
                            len -= lframe;
                        }
                    }
                    finally
                    {
                        {
                            $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(pool, false);
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17181256137)
            
            //--TRIMMABLE-BOUNDARY-START(21476223433)
            static /*Task */ SendRequestOverSocket(T, /*WebSocket*/ webSocket, /*T*/ data, /*CancellationToken?*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476223433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$kVHt.LCFCH.WebSocketHubUtility.SendOverSocket(T, webSocket, data, 0/*RequestPrefix*/, 0, $.$clone(token));
            }
            //--TRIMMABLE-BOUNDARY-END(21476223433)
            
            //--TRIMMABLE-BOUNDARY-START(25771190729)
            static /*Task */ SendResponseOverSocket(T, /*WebSocket*/ webSocket, /*T*/ data, /*int*/ requestId, /*CancellationToken?*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771190729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$kVHt.LCFCH.WebSocketHubUtility.SendOverSocket(T, webSocket, data, 1/*ResponsePrefix*/, requestId, $.$clone(token));
            }
            //--TRIMMABLE-BOUNDARY-END(25771190729)
            
            static $h = 1386953;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181256137),
    {
      "r": 178454529,
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        },
        {
          "n": "data",
          "p": (T) => T.$h
        },
        {
          "n": "headerPrefix",
          "p": 393217
        },
        {
          "n": "requestId",
          "p": 655361
        },
        {
          "n": "token",
          "p": $.$typeNullable($.$$.ST$1.CancellationToken).$h,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "SendOverSocket",
      "d": 1386953,
      "h": 17181256137,
      "f": 16912418
    },
//--TRIMMABLE-BOUNDARY-END(17181256137),
//--TRIMMABLE-BOUNDARY-START(21476223433),
    {
      "r": 178454529,
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        },
        {
          "n": "data",
          "p": (T) => T.$h
        },
        {
          "n": "token",
          "p": $.$typeNullable($.$$.ST$1.CancellationToken).$h,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "SendRequestOverSocket",
      "d": 1386953,
      "h": 21476223433,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21476223433),
//--TRIMMABLE-BOUNDARY-START(25771190729),
    {
      "r": 178454529,
      "p": [
        {
          "n": "webSocket",
          "p": 1572968
        },
        {
          "n": "data",
          "p": (T) => T.$h
        },
        {
          "n": "requestId",
          "p": 655361
        },
        {
          "n": "token",
          "p": $.$typeNullable($.$$.ST$1.CancellationToken).$h,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "SendResponseOverSocket",
      "d": 1386953,
      "h": 25771190729,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25771190729)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296354249),
    {
      "t": 655361,
      "n": "MessageBufferSize",
      "d": 1386953,
      "h": 4296354249,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4296354249),
//--TRIMMABLE-BOUNDARY-START(8591321545),
    {
      "t": 393217,
      "n": "RequestPrefix",
      "d": 1386953,
      "h": 8591321545,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591321545),
//--TRIMMABLE-BOUNDARY-START(12886288841),
    {
      "t": 393217,
      "n": "ResponsePrefix",
      "d": 1386953,
      "h": 12886288841,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886288841)
  ],
  "h": 1386953
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.WebSocketHubUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}WebSocketHubUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1386953)
        
        

        //--TRIMMABLE-BOUNDARY-START(207305)
        $asm.$cls(`$kVHt.LCFCH.HubClientDisposer<,,>`, (THubClient, THubServer, TConnection) => $asm.$gt(`$kVHt.LCFCH.HubClientDisposer<,,>`, [THubClient, THubServer, TConnection], ($self) => class HubClientDisposer$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180076489)
            /*BaseClientHubConnector<THubClient, THubServer, TConnection>*/ hub = null;
            //--TRIMMABLE-BOUNDARY-END(17180076489)
            
            //--TRIMMABLE-BOUNDARY-START(8590141897)
            /*THubClient*/ client = $.$default(THubClient);
            //--TRIMMABLE-BOUNDARY-END(8590141897)
            
            //--TRIMMABLE-BOUNDARY-START(4295174601)
            $ctor$1(/*BaseClientHubConnector<THubClient, THubServer, TConnection>*/ hub, /*THubClient*/ client)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295174601);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.hub = hub;
                    this.client = client;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295174601)
            
            //--TRIMMABLE-BOUNDARY-START(12885109193)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885109193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.hub.clients.Remove(this.client);
            }
            //--TRIMMABLE-BOUNDARY-END(12885109193)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            static $H = 207305;
            static $h = 207305;
            static $g = 3;
            static $f = 0b1010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885109193),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 12885109193,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885109193)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180076489),
    {
      "t": $.$kVHt.LCFCH.BaseClientHubConnector$$$$(THubClient, THubServer, TConnection).$h,
      "n": "hub",
      "d": this.$h,
      "H": 17180076489,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180076489),
//--TRIMMABLE-BOUNDARY-START(8590141897),
    {
      "t": THubClient?.$h??1572864,
      "n": "client",
      "d": this.$h,
      "H": 8590141897,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590141897)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295174601),
    {
      "p": [
        {
          "n": "hub",
          "p": $.$kVHt.LCFCH.BaseClientHubConnector$$$$(THubClient, THubServer, TConnection).$h
        },
        {
          "n": "client",
          "p": THubClient?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295174601,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295174601)
  ],
  "s": [
    {
      "h": THubClient?.$h??1572864,
      "n": "THubClient",
      "c": [534985
      ]
    },
    {
      "h": THubServer?.$h??1638400,
      "n": "THubServer",
      "f": 1
    },
    {
      "h": TConnection?.$h??1703936,
      "n": "TConnection"
    }
  ],
  "r": 3,
  "H": 207305,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.HubClientDisposer<${THubClient?.$fullName},${THubServer?.$fullName},${TConnection?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}HubClientDisposer$${THubClient?.$getFullName(separator)}$${THubServer?.$getFullName(separator)}$${TConnection?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(207305)
        
        

        //--TRIMMABLE-BOUNDARY-START(1059273)
        $asm.$cls(`$kVHt.LCFCH.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590993865)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590993865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$kVHt.LCFCH.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(8590993865)
            
            //--TRIMMABLE-BOUNDARY-START(12885961161)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885961161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885961161)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$kVHt.LCFCH.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296026569)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296026569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296026569)
            
            //--TRIMMABLE-BOUNDARY-START(4296026569)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296026569)
            
            static $h = 1059273;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590993865),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1059273,
      "h": 8590993865,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590993865),
//--TRIMMABLE-BOUNDARY-START(12885961161),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 1059273,
      "h": 12885961161,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885961161)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296026569),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1059273,
      "h": 4296026569,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296026569)
  ],
  "h": 1059273
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1059273)
        
        

        //--TRIMMABLE-BOUNDARY-START(141769)
        $asm.$cls(`$kVHt.LCFCH.HubAttribute`, ($self) => class HubAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(21474978249)
            /*string*/ RemoteHost = null;
            //--TRIMMABLE-BOUNDARY-END(21474978249)
            
            //--TRIMMABLE-BOUNDARY-START(8590076361)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590076361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590076361)
            
            //--TRIMMABLE-BOUNDARY-START(8590076361)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590076361)
            
            static $h = 141769;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474978249),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180010953,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30064912841,
        "f": 83886081
      },
      "n": "RemoteHost",
      "d": 141769,
      "h": 21474978249,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474978249)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590076361),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 141769,
      "h": 8590076361,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590076361)
  ],
  "h": 141769
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.HubAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}HubAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(141769)
        
        

        //--TRIMMABLE-BOUNDARY-START(1190345)
        $asm.$str(`$kVHt.LCFCH.WebSocketClientMetadata`, ($self) => class WebSocketClientMetadata extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17181059529)
            /*IDictionary<string, object?>?*/ Attributes = null;
            //--TRIMMABLE-BOUNDARY-END(17181059529)
            
            //--TRIMMABLE-BOUNDARY-START(21476026825)
            /*string?*/ DisplayName = null;
            //--TRIMMABLE-BOUNDARY-END(21476026825)
            
            //--TRIMMABLE-BOUNDARY-START(68720667081)
            /*void*/ set_Item$1(/*string*/ key, /*object?*/ value)
            {
                $.$fPer.LCFCD.DynamicDataContainerExtension.Add$2($.$kVHt.LCFCH.WebSocketClientMetadata, this, $.$$.S.Object.GetType.call(value), value, key);
            }
            //--TRIMMABLE-BOUNDARY-END(68720667081)
            
            //--TRIMMABLE-BOUNDARY-START(12903156054)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDynamicDataContainer.Attributes.get
            get LCFCD$IDynamicDataContainer$Attributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313221462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Attributes;
            }
            //--TRIMMABLE-BOUNDARY-END(12903156054)
            
            //--TRIMMABLE-BOUNDARY-START(30083025238)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDynamicDataContainer.Attributes.set
            set LCFCD$IDynamicDataContainer$Attributes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313221462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Attributes = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30083025238)
            
            //--TRIMMABLE-BOUNDARY-START(38672959830)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDynamicDataContainer.this[string].set
            LCFCD$IDynamicDataContainer$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38672959830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38672959830)
            
            //--TRIMMABLE-BOUNDARY-START(12907153750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IReadOnlyDynamicDataContainer.Attributes.get
            get LCFCD$IReadOnlyDynamicDataContainer$Attributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4317219158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Attributes;
            }
            //--TRIMMABLE-BOUNDARY-END(12907153750)
            
            //--TRIMMABLE-BOUNDARY-START(12886092233)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886092233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886092233)
            
            //--TRIMMABLE-BOUNDARY-START(12886092233)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886092233)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Attributes = this.Attributes;
                copy.DisplayName = this.DisplayName;
                return copy;
            }
            static $h = 1190345;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181059529),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065961417,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245830601,
        "f": 83886081
      },
      "n": "Attributes",
      "d": 1190345,
      "h": 17181059529,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181059529),
//--TRIMMABLE-BOUNDARY-START(21476026825),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655896009,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835765193,
        "f": 83886081
      },
      "n": "DisplayName",
      "d": 1190345,
      "h": 21476026825,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476026825),
//--TRIMMABLE-BOUNDARY-START(68720667081),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425699785,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 1190345,
      "h": 68720667081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720667081)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886092233),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1190345,
      "h": 12886092233,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886092233)
  ],
  "h": 1190345,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDynamicDataContainer, $.$fPer.LCFCD.IReadOnlyDynamicDataContainer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadata`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}WebSocketClientMetadata`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1190345)
        
        

        //--TRIMMABLE-BOUNDARY-START(1255881)
        $asm.$cls(`$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptor`, ($self) => class WebSocketClientMetadataTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$kVHt.LCFCH.WebSocketClientMetadata)
        {
            //--TRIMMABLE-BOUNDARY-START(4296223177)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296223177);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptor.GenerateProperties($.$kVHt.LCFCH.WebSocketClientMetadata, this, factory);
                    }, $Gsnvvc ??= {"r":65537,"n":"","d":1255881,"h":0,"f":17825794}), 0, "WebSocketClientMetadataTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Hub\\WebSocketClientMetadata_LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadataTypeDescriptorBuilder.g.cs", "WebSocketClientMetadataTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296223177)
            
            //--TRIMMABLE-BOUNDARY-START(12886157769)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886157769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Attributes"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$kVHt.LCFCH.WebSocketClientMetadata.$type, $.$discardRef(), "Attributes", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Attributes")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Attributes";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadata";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), ($.$cast(target, $.$kVHt.LCFCH.WebSocketClientMetadata)).Attributes);
                        }, $fCAJVa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1255881,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$kVHt.LCFCH.WebSocketClientMetadata, target).$v.Attributes = value.AsReference($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object));
                        }, $sEWcmf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1255881,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DisplayName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$kVHt.LCFCH.WebSocketClientMetadata.$type, $.$discardRef(), "DisplayName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DisplayName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "DisplayName";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadata";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$kVHt.LCFCH.WebSocketClientMetadata)).DisplayName);
                        }, $NCimId ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1255881,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$kVHt.LCFCH.WebSocketClientMetadata, target).$v.DisplayName = value.AsReference($.$$.S.String);
                        }, $ecPaja ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1255881,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886157769)
            
            //--TRIMMABLE-BOUNDARY-START(17181125065)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadata*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181125065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Attributes = _target.Attributes;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Attributes"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Attributes, ($v) => _Attributes = $v, $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object))))
                    {
                        _target.Attributes = _Attributes;
                    }
                }
                {
                    /*var*/ let _DisplayName = _target.DisplayName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DisplayName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _DisplayName, ($v) => _DisplayName = $v, $.$$.S.String)))
                    {
                        _target.DisplayName = _DisplayName;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181125065)
            
            //--TRIMMABLE-BOUNDARY-START(8591190473)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadata*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591190473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$kVHt.LCFCH.WebSocketClientMetadata, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$kVHt.LCFCH.WebSocketClientMetadata, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$kVHt.LCFCH.WebSocketClientMetadataTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$kVHt.LCFCH.WebSocketClientMetadata, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$kVHt.LCFCH.WebSocketClientMetadata, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$kVHt.LCFCH.WebSocketClientMetadata, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591190473)
            
            static $h = 1255881;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$kVHt.LCFCH.WebSocketClientMetadata); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886157769),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1255881,
      "h": 12886157769,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886157769),
//--TRIMMABLE-BOUNDARY-START(17181125065),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1190345,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1255881,
      "h": 17181125065,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181125065),
//--TRIMMABLE-BOUNDARY-START(8591190473),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1190345,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1255881,
      "h": 8591190473,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591190473)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296223177),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1255881,
      "h": 4296223177,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296223177)
  ],
  "h": 1255881
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$kVHt.LCFCH.WebSocketClientMetadata), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadataTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Hub${separator}WebSocketClientMetadataTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1255881)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking"));
})();
//--TRIMMABLE-BOUNDARY-END(10697)
