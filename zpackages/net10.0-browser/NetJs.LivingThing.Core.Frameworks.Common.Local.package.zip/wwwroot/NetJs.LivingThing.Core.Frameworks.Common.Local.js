
//--TRIMMABLE-BOUNDARY-START(61647)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer) {
    "use strict";
    let _;
    let $sbiJej;
    let $vBwnzi;
    let $pEztEd;
    let $ZUSvee;
    let $eyyDDj;
    let $HbVOYk;
    let $LuuqPd;
    let $Lejxgc;
    let $HAqsqj;
    let $GUWrfk;
    let $tlaDng;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Local", 
    {
  "h": 61647,
  "f": "LivingThing.Core.Frameworks.Common.Local",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Local",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Local",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(520399)
        $asm.$cls(`$IHYd.LCFCL.PostUtility`, ($self) => class PostUtility
        {
            static $h = 520399;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 520399
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.PostUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}PostUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(520399)
        
        

        //--TRIMMABLE-BOUNDARY-START(127183)
        $asm.$cls(`$IHYd.LCFCL.CopyControl`, ($self) => class CopyControl extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(158913917135)
            /*bool*/ SkipIfTimeEquals = false;
            //--TRIMMABLE-BOUNDARY-END(158913917135)
            
            //--TRIMMABLE-BOUNDARY-START(150323982543)
            /*Func<string, string, bool>?*/ ShouldCopyFile = null;
            //--TRIMMABLE-BOUNDARY-END(150323982543)
            
            //--TRIMMABLE-BOUNDARY-START(154618949839)
            /*Func<string, string, bool>?*/ ShouldCopyFolder = null;
            //--TRIMMABLE-BOUNDARY-END(154618949839)
            
            //--TRIMMABLE-BOUNDARY-START(34359865551)
            /*Func<string, string>?*/ ChangeFilePath = null;
            //--TRIMMABLE-BOUNDARY-END(34359865551)
            
            //--TRIMMABLE-BOUNDARY-START(38654832847)
            /*Func<string, string>?*/ ChangeFolderPath = null;
            //--TRIMMABLE-BOUNDARY-END(38654832847)
            
            //--TRIMMABLE-BOUNDARY-START(94489407695)
            /*Func<Stream, Stream>?*/ ModifyFileContent = null;
            //--TRIMMABLE-BOUNDARY-END(94489407695)
            
            //--TRIMMABLE-BOUNDARY-START(30064898255)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064898255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064898255)
            
            //--TRIMMABLE-BOUNDARY-START(30064898255)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30064898255)
            
            static $h = 127183;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158913917135),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194440399,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029015247,
        "f": 83886081
      },
      "n": "SkipIfTimeEquals",
      "d": 127183,
      "h": 158913917135,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158913917135),
//--TRIMMABLE-BOUNDARY-START(150323982543),
    {
      "p": $.$$.S.Func$$$$($.$$.S.String, $.$$.S.String, $.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014571215,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849146063,
        "f": 83886081
      },
      "n": "ShouldCopyFile",
      "d": 127183,
      "h": 150323982543,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150323982543),
//--TRIMMABLE-BOUNDARY-START(154618949839),
    {
      "p": $.$$.S.Func$$$$($.$$.S.String, $.$$.S.String, $.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604505807,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439080655,
        "f": 83886081
      },
      "n": "ShouldCopyFolder",
      "d": 127183,
      "h": 154618949839,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154618949839),
//--TRIMMABLE-BOUNDARY-START(34359865551),
    {
      "p": $.$$.S.Func$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244767439,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079342287,
        "f": 83886081
      },
      "n": "ChangeFilePath",
      "d": 127183,
      "h": 34359865551,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359865551),
//--TRIMMABLE-BOUNDARY-START(38654832847),
    {
      "p": $.$$.S.Func$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834702031,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669276879,
        "f": 83886081
      },
      "n": "ChangeFolderPath",
      "d": 127183,
      "h": 38654832847,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654832847),
//--TRIMMABLE-BOUNDARY-START(94489407695),
    {
      "p": $.$$.S.Func$$$($.$$.SI.Stream, $.$$.SI.Stream).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424636623,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259211471,
        "f": 83886081
      },
      "n": "ModifyFileContent",
      "d": 127183,
      "h": 94489407695,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489407695)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30064898255),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 127183,
      "h": 30064898255,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064898255)
  ],
  "h": 127183
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.CopyControl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}CopyControl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(127183)
        
        

        //--TRIMMABLE-BOUNDARY-START(454863)
        $asm.$cls(`$IHYd.LCFCL.LocalPathUtility`, ($self) => class LocalPathUtility
        {
            //--TRIMMABLE-BOUNDARY-START(4295422159)
            static /*void */ CopyFolder(/*string*/ source, /*string*/ dest, /*bool*/ overwriteFile, /*CopyControl?*/ copyControl)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295422159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (source === dest)
                {
                    return;
                }
                if (copyControl === null || copyControl.ShouldCopyFolder === null || copyControl.ShouldCopyFolder.Invoke(source, dest))
                {
                    if (copyControl !== null && copyControl.ChangeFolderPath !== null)
                    {
                        dest = copyControl.ChangeFolderPath.Invoke(dest);
                    }
                    if (!$.$$.SI.Directory.Exists(dest))
                    {
                        $.$$.SI.Directory.CreateDirectory$1(dest);
                    }
                    /*DirectoryInfo*/ let ds = new $.$$.SI.DirectoryInfo().$ctor$5(source);
                    /*DirectoryInfo*/ let dd = new $.$$.SI.DirectoryInfo().$ctor$5(dest);
                    if ((!(copyControl?.SkipIfTimeEquals ?? null) ?? true) || $.$$.S.DateTime.op_Inequality(ds.LastWriteTime, dd.LastWriteTime))
                    {
                        let $i1 = 0;
                        let $arr1 = $.$$.SI.Directory.GetFiles$3(source);
                        while ($i1 < $arr1.length)
                        {
                            let file = $arr1[$i1++];
                            if (copyControl === null || copyControl.ShouldCopyFile === null || copyControl.ShouldCopyFile.Invoke(source, file))
                            {
                                /*string*/ let to = $.$$.SI.Path.Combine$3(dest, $.$$.SI.Path.GetFileName$1(file));
                                if (copyControl !== null && copyControl.ChangeFilePath !== null)
                                {
                                    to = copyControl.ChangeFilePath.Invoke(to);
                                }
                                /*FileInfo*/ let fs = new $.$$.SI.FileInfo().$ctor$6(file);
                                /*FileInfo*/ let fd = new $.$$.SI.FileInfo().$ctor$6(to);
                                if ((!(copyControl?.SkipIfTimeEquals ?? null) ?? true) || $.$$.S.DateTime.op_Inequality(fs.LastWriteTime, fd.LastWriteTime))
                                {
                                    if ((copyControl?.ModifyFileContent ?? null) !== null)
                                    {
                                        /*var*/ let newfs = copyControl.ModifyFileContent.Invoke($.$$.SI.File.OpenRead(file));
                                        let nfs = null;
                                        try
                                        {
                                            nfs = $.$$.SI.File.OpenWrite(to);
                                            newfs.CopyTo$1(nfs);
                                        }
                                        finally
                                        {
                                            nfs?.S$IDisposable$Dispose();
                                        }
                                    }
                                    else 
                                    {
                                        $.$$.SI.File.Copy(file, to, overwriteFile);
                                    }
                                }
                            }
                        }
                        let $i2 = 0;
                        let $arr2 = $.$$.SI.Directory.GetDirectories$3(source);
                        while ($i2 < $arr2.length)
                        {
                            let folder = $arr2[$i2++];
                            /*string*/ let destFolder = $.$$.SI.Path.Combine$3(dest, $.$$.SI.Path.GetFileName$1(folder));
                            $.$IHYd.LCFCL.LocalPathUtility.CopyFolder(folder, destFolder, overwriteFile, copyControl);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295422159)
            
            static $h = 454863;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295422159),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "dest",
          "p": 1310721
        },
        {
          "n": "overwriteFile",
          "p": 262145
        },
        {
          "n": "copyControl",
          "p": 127183,
          "f": 65
        }
      ],
      "n": "CopyFolder",
      "d": 454863,
      "h": 4295422159,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295422159)
  ],
  "h": 454863
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.LocalPathUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}LocalPathUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(454863)
        
        

        //--TRIMMABLE-BOUNDARY-START(192719)
        $asm.$cls(`$IHYd.LCFCLF.InMemoryFileProvider`, ($self) => class InMemoryFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(258255)
            static $_InMemoryFile;
            static get InMemoryFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(258255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$IHYd.LCFCLF.InMemoryFileProvider;
                return $cls.$_InMemoryFile ??= $asm.$ncls(`$IHYd.LCFCLF.InMemoryFileProvider.InMemoryFile`, ($self) => class InMemoryFile extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295225551)
                    /*byte[]*/ _data = null;
                    //--TRIMMABLE-BOUNDARY-END(4295225551)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065029327)
                    $ctor$1(/*string*/ json)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065029327);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._data = $.$$.ST.Encoding.UTF8.GetBytes$8(json);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065029327)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359996623)
                    /*Stream */ CreateReadStream()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34359996623);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$$.SI.MemoryStream().$ctor$8(this._data);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359996623)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654963919)
                    /*bool*/ Exists = false;
                    //--TRIMMABLE-BOUNDARY-END(38654963919)
                    
                    //--TRIMMABLE-BOUNDARY-START(103079473359)
                    /*long */ get Length()
                    {
                        return BigInt(this._data.length);
                    }
                    //--TRIMMABLE-BOUNDARY-END(103079473359)
                    
                    //--TRIMMABLE-BOUNDARY-START(111669407951)
                    /*string*/ PhysicalPath = null;
                    //--TRIMMABLE-BOUNDARY-END(111669407951)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374440655)
                    /*string*/ Name = null;
                    //--TRIMMABLE-BOUNDARY-END(107374440655)
                    
                    //--TRIMMABLE-BOUNDARY-START(98784506063)
                    /*DateTimeOffset*/ LastModified;
                    //--TRIMMABLE-BOUNDARY-END(98784506063)
                    
                    //--TRIMMABLE-BOUNDARY-START(94489538767)
                    /*bool*/ IsDirectory = false;
                    //--TRIMMABLE-BOUNDARY-END(94489538767)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065891)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
                    get MEF$IFileInfo$Exists()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590131299);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Exists;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065891)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949869667)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
                    get MEF$IFileInfo$Length()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014640739);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Length;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949869667)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129738851)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
                    get MEF$IFileInfo$PhysicalPath()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81604575331);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.PhysicalPath;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129738851)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539804259)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
                    get MEF$IFileInfo$Name()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77309608035);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539804259)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359935075)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
                    get MEF$IFileInfo$LastModified()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68719673443);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.LastModified;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359935075)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000483)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
                    get MEF$IFileInfo$IsDirectory()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424706147);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsDirectory;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000483)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295164003)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
                    MEF$IFileInfo$CreateReadStream()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295164003);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreateReadStream(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295164003)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(38654963919)
                        this.Exists = true;
                        //--TRIMMABLE-BOUNDARY-END(38654963919)
                        
                        //--TRIMMABLE-BOUNDARY-START(111669407951)
                        this.PhysicalPath = $.$$.S.String.Empty;
                        //--TRIMMABLE-BOUNDARY-END(111669407951)
                        
                        //--TRIMMABLE-BOUNDARY-START(107374440655)
                        this.Name = $.$$.S.String.Empty;
                        //--TRIMMABLE-BOUNDARY-END(107374440655)
                        
                        //--TRIMMABLE-BOUNDARY-START(98784506063)
                        this.LastModified = $.$$.S.DateTimeOffset.UtcNow;
                        //--TRIMMABLE-BOUNDARY-END(98784506063)
                        
                        //--TRIMMABLE-BOUNDARY-START(94489538767)
                        this.IsDirectory = false;
                        //--TRIMMABLE-BOUNDARY-END(94489538767)
                        
                    }
                    static $h = 258255;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654963919),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244898511,
        "f": 50331649
      },
      "n": "Exists",
      "d": 258255,
      "h": 38654963919,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654963919),
//--TRIMMABLE-BOUNDARY-START(103079473359),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014702287,
        "f": 50331649
      },
      "n": "Length",
      "d": 258255,
      "h": 103079473359,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079473359),
//--TRIMMABLE-BOUNDARY-START(111669407951),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194571471,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 258255,
      "h": 111669407951,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669407951),
//--TRIMMABLE-BOUNDARY-START(107374440655),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604636879,
        "f": 50331649
      },
      "n": "Name",
      "d": 258255,
      "h": 107374440655,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374440655),
//--TRIMMABLE-BOUNDARY-START(98784506063),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424767695,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 258255,
      "h": 98784506063,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784506063),
//--TRIMMABLE-BOUNDARY-START(94489538767),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834833103,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 258255,
      "h": 94489538767,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489538767)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34359996623),
    {
      "r": 95748097,
      "n": "CreateReadStream",
      "d": 258255,
      "h": 34359996623,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359996623)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295225551),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_data",
      "d": 258255,
      "h": 4295225551,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295225551)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065029327),
    {
      "p": [
        {
          "n": "json",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 258255,
      "h": 30065029327,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065029327)
  ],
  "d": 192719,
  "h": 258255
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileInfo ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.FileProviders.InMemoryFileProvider+InMemoryFile`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}FileProviders${separator}InMemoryFileProvider${separator}InMemoryFile`; }
                }, $cls, ($v) => $cls.$_InMemoryFile = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(258255)
            
            //--TRIMMABLE-BOUNDARY-START(4295160015)
            /*IFileInfo*/ _fileInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295160015)
            
            //--TRIMMABLE-BOUNDARY-START(8590127311)
            $ctor$1(/*string*/ json)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590127311);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._fileInfo = new $.$IHYd.LCFCLF.InMemoryFileProvider.InMemoryFile().$ctor$1(json);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590127311)
            
            //--TRIMMABLE-BOUNDARY-START(17180061903)
            /*IFileInfo */ GetFileInfo(/*string*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180061903);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._fileInfo;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180061903)
            
            //--TRIMMABLE-BOUNDARY-START(12885094607)
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885094607);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885094607)
            
            //--TRIMMABLE-BOUNDARY-START(21475029199)
            /*IChangeToken */ Watch(/*string*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475029199);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mefa.MEF.NullChangeToken.Singleton;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475029199)
            
            //--TRIMMABLE-BOUNDARY-START(8590196835)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            MEF$IFileProvider$GetFileInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFileInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196835)
            
            //--TRIMMABLE-BOUNDARY-START(4295229539)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            MEF$IFileProvider$GetDirectoryContents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDirectoryContents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229539)
            
            //--TRIMMABLE-BOUNDARY-START(12885164131)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            MEF$IFileProvider$Watch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Watch(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164131)
            
            static $h = 192719;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180061903),
    {
      "r": 196707,
      "p": [
        {
          "n": "_",
          "p": 1310721
        }
      ],
      "n": "GetFileInfo",
      "d": 192719,
      "h": 17180061903,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180061903),
//--TRIMMABLE-BOUNDARY-START(12885094607),
    {
      "r": 131171,
      "p": [
        {
          "n": "_",
          "p": 1310721
        }
      ],
      "n": "GetDirectoryContents",
      "d": 192719,
      "h": 12885094607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885094607),
//--TRIMMABLE-BOUNDARY-START(21475029199),
    {
      "r": 720981,
      "p": [
        {
          "n": "_",
          "p": 1310721
        }
      ],
      "n": "Watch",
      "d": 192719,
      "h": 21475029199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475029199)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295160015),
    {
      "t": 196707,
      "n": "_fileInfo",
      "d": 192719,
      "h": 4295160015,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295160015)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590127311),
    {
      "p": [
        {
          "n": "json",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 192719,
      "h": 8590127311,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590127311)
  ],
  "h": 192719
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileProvider ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$IHYd.LCFCLF.InMemoryFileProvider.InMemoryFile ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.FileProviders.InMemoryFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}FileProviders${separator}InMemoryFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(192719)
        
        

        //--TRIMMABLE-BOUNDARY-START(323791)
        $asm.$cls(`$IHYd.LCFCLF.StreamFileProvider`, ($self) => class StreamFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(389327)
            static $_InMemoryStreamFile;
            static get InMemoryStreamFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(389327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$IHYd.LCFCLF.StreamFileProvider;
                return $cls.$_InMemoryStreamFile ??= $asm.$ncls(`$IHYd.LCFCLF.StreamFileProvider.InMemoryStreamFile`, ($self) => class InMemoryStreamFile extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295356623)
                    /*Stream*/ _data = null;
                    //--TRIMMABLE-BOUNDARY-END(4295356623)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065160399)
                    $ctor$1(/*Stream*/ stream)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065160399);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._data = stream;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065160399)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360127695)
                    /*Stream */ CreateReadStream()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34360127695);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._data;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360127695)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655094991)
                    /*bool*/ Exists = false;
                    //--TRIMMABLE-BOUNDARY-END(38655094991)
                    
                    //--TRIMMABLE-BOUNDARY-START(103079604431)
                    /*long */ get Length()
                    {
                        return this._data.Length;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103079604431)
                    
                    //--TRIMMABLE-BOUNDARY-START(111669539023)
                    /*string*/ PhysicalPath = null;
                    //--TRIMMABLE-BOUNDARY-END(111669539023)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374571727)
                    /*string*/ Name = null;
                    //--TRIMMABLE-BOUNDARY-END(107374571727)
                    
                    //--TRIMMABLE-BOUNDARY-START(98784637135)
                    /*DateTimeOffset*/ LastModified;
                    //--TRIMMABLE-BOUNDARY-END(98784637135)
                    
                    //--TRIMMABLE-BOUNDARY-START(94489669839)
                    /*bool*/ IsDirectory = false;
                    //--TRIMMABLE-BOUNDARY-END(94489669839)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065891)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
                    get MEF$IFileInfo$Exists()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590131299);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Exists;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065891)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949869667)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
                    get MEF$IFileInfo$Length()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014640739);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Length;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949869667)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129738851)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
                    get MEF$IFileInfo$PhysicalPath()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81604575331);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.PhysicalPath;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129738851)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539804259)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
                    get MEF$IFileInfo$Name()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77309608035);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539804259)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359935075)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
                    get MEF$IFileInfo$LastModified()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68719673443);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.LastModified;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359935075)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000483)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
                    get MEF$IFileInfo$IsDirectory()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424706147);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsDirectory;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000483)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295164003)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
                    MEF$IFileInfo$CreateReadStream()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295164003);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreateReadStream(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295164003)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(38655094991)
                        this.Exists = true;
                        //--TRIMMABLE-BOUNDARY-END(38655094991)
                        
                        //--TRIMMABLE-BOUNDARY-START(111669539023)
                        this.PhysicalPath = $.$$.S.String.Empty;
                        //--TRIMMABLE-BOUNDARY-END(111669539023)
                        
                        //--TRIMMABLE-BOUNDARY-START(107374571727)
                        this.Name = $.$$.S.String.Empty;
                        //--TRIMMABLE-BOUNDARY-END(107374571727)
                        
                        //--TRIMMABLE-BOUNDARY-START(98784637135)
                        this.LastModified = $.$$.S.DateTimeOffset.UtcNow;
                        //--TRIMMABLE-BOUNDARY-END(98784637135)
                        
                        //--TRIMMABLE-BOUNDARY-START(94489669839)
                        this.IsDirectory = false;
                        //--TRIMMABLE-BOUNDARY-END(94489669839)
                        
                    }
                    static $h = 389327;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655094991),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245029583,
        "f": 50331649
      },
      "n": "Exists",
      "d": 389327,
      "h": 38655094991,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655094991),
//--TRIMMABLE-BOUNDARY-START(103079604431),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014833359,
        "f": 50331649
      },
      "n": "Length",
      "d": 389327,
      "h": 103079604431,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079604431),
//--TRIMMABLE-BOUNDARY-START(111669539023),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194702543,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 389327,
      "h": 111669539023,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669539023),
//--TRIMMABLE-BOUNDARY-START(107374571727),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604767951,
        "f": 50331649
      },
      "n": "Name",
      "d": 389327,
      "h": 107374571727,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374571727),
//--TRIMMABLE-BOUNDARY-START(98784637135),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424898767,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 389327,
      "h": 98784637135,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784637135),
//--TRIMMABLE-BOUNDARY-START(94489669839),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834964175,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 389327,
      "h": 94489669839,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489669839)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360127695),
    {
      "r": 95748097,
      "n": "CreateReadStream",
      "d": 389327,
      "h": 34360127695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360127695)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295356623),
    {
      "t": 95748097,
      "n": "_data",
      "d": 389327,
      "h": 4295356623,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295356623)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065160399),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 389327,
      "h": 30065160399,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065160399)
  ],
  "d": 323791,
  "h": 389327
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileInfo ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.FileProviders.StreamFileProvider+InMemoryStreamFile`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}FileProviders${separator}StreamFileProvider${separator}InMemoryStreamFile`; }
                }, $cls, ($v) => $cls.$_InMemoryStreamFile = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(389327)
            
            //--TRIMMABLE-BOUNDARY-START(4295291087)
            /*IFileInfo*/ _fileInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295291087)
            
            //--TRIMMABLE-BOUNDARY-START(8590258383)
            $ctor$1(/*Stream*/ stream)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590258383);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._fileInfo = new $.$IHYd.LCFCLF.StreamFileProvider.InMemoryStreamFile().$ctor$1(stream);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590258383)
            
            //--TRIMMABLE-BOUNDARY-START(17180192975)
            /*IFileInfo */ GetFileInfo(/*string*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180192975);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._fileInfo;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180192975)
            
            //--TRIMMABLE-BOUNDARY-START(12885225679)
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885225679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885225679)
            
            //--TRIMMABLE-BOUNDARY-START(21475160271)
            /*IChangeToken */ Watch(/*string*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475160271);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mefa.MEF.NullChangeToken.Singleton;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475160271)
            
            //--TRIMMABLE-BOUNDARY-START(8590196835)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            MEF$IFileProvider$GetFileInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFileInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196835)
            
            //--TRIMMABLE-BOUNDARY-START(4295229539)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            MEF$IFileProvider$GetDirectoryContents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDirectoryContents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229539)
            
            //--TRIMMABLE-BOUNDARY-START(12885164131)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            MEF$IFileProvider$Watch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Watch(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164131)
            
            static $h = 323791;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180192975),
    {
      "r": 196707,
      "p": [
        {
          "n": "_",
          "p": 1310721
        }
      ],
      "n": "GetFileInfo",
      "d": 323791,
      "h": 17180192975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180192975),
//--TRIMMABLE-BOUNDARY-START(12885225679),
    {
      "r": 131171,
      "p": [
        {
          "n": "_",
          "p": 1310721
        }
      ],
      "n": "GetDirectoryContents",
      "d": 323791,
      "h": 12885225679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885225679),
//--TRIMMABLE-BOUNDARY-START(21475160271),
    {
      "r": 720981,
      "p": [
        {
          "n": "_",
          "p": 1310721
        }
      ],
      "n": "Watch",
      "d": 323791,
      "h": 21475160271,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475160271)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295291087),
    {
      "t": 196707,
      "n": "_fileInfo",
      "d": 323791,
      "h": 4295291087,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295291087)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590258383),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 323791,
      "h": 8590258383,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590258383)
  ],
  "h": 323791
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileProvider ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$IHYd.LCFCLF.StreamFileProvider.InMemoryStreamFile ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.FileProviders.StreamFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}FileProviders${separator}StreamFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(323791)
        
        

        //--TRIMMABLE-BOUNDARY-START(585935)
        $asm.$cls(`$IHYd.LCFCL.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590520527)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590520527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$IHYd.LCFCL.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$IHYd.LCFCLS.FiledLocalStorageService, services);
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCS$5.IPersistentStorageService, services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCS$5.IPersistentStorageService))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IHYd.LCFCLS.FiledLocalStorageService, x);
                    }, $sbiJej ??= {"r":63932758,"p":[{"n":"x","p":327718}],"n":"","d":585935,"h":0,"f":17825794}));
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$mefa.MEF.IFileProvider, services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$mefa.MEF.IFileProvider))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IHYd.LCFCLS.FiledLocalStorageService, x);
                    }, $vBwnzi ??= {"r":262243,"p":[{"n":"x","p":327718}],"n":"","d":585935,"h":0,"f":17825794}));
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCS$5.IDataCacheStorageService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$IHYd.LCFCLS.FiledCacheStorageService, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCS$5.IDataCacheStorageService))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IHYd.LCFCLS.FiledCacheStorageService, x);
                    }, $pEztEd ??= {"r":63867222,"p":[{"n":"x","p":327718}],"n":"","d":585935,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590520527)
            
            //--TRIMMABLE-BOUNDARY-START(12885487823)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885487823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_FiledLocalStorageService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$IHYd.LCFCLS.FiledLocalStorageService().$ctor$1();
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$IHYd.LCFCLS.FiledLocalStorageService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$IHYd.LCFCL.ServiceRegistrar, Get_FiledLocalStorageService, $ZUSvee ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_FiledLocalStorageService","d":585935,"h":0,"f":16777250})));
                /*static object*/  function Get_IPersistentStorageService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IHYd.LCFCLS.FiledLocalStorageService, x);
                    }), $eyyDDj ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":585935,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fPer.LCFCS$5.IPersistentStorageService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$IHYd.LCFCL.ServiceRegistrar, Get_IPersistentStorageService, $HbVOYk ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPersistentStorageService","d":585935,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IFileProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IHYd.LCFCLS.FiledLocalStorageService, x);
                    }), $LuuqPd ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":585935,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$mefa.MEF.IFileProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$IHYd.LCFCL.ServiceRegistrar, Get_IFileProvider, $Lejxgc ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IFileProvider","d":585935,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_FiledCacheStorageService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$IHYd.LCFCLS.FiledCacheStorageService().$ctor$2();
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$IHYd.LCFCLS.FiledCacheStorageService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$IHYd.LCFCL.ServiceRegistrar, Get_FiledCacheStorageService, $HAqsqj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_FiledCacheStorageService","d":585935,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IDataCacheStorageService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IHYd.LCFCLS.FiledCacheStorageService, x);
                    }), $GUWrfk ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":585935,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fPer.LCFCS$5.IDataCacheStorageService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$IHYd.LCFCL.ServiceRegistrar, Get_IDataCacheStorageService, $tlaDng ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IDataCacheStorageService","d":585935,"h":0,"f":16777250})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885487823)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$IHYd.LCFCL.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295553231)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295553231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295553231)
            
            //--TRIMMABLE-BOUNDARY-START(4295553231)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295553231)
            
            static $h = 585935;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590520527),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 585935,
      "h": 8590520527,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590520527),
//--TRIMMABLE-BOUNDARY-START(12885487823),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 585935,
      "h": 12885487823,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885487823)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295553231),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 585935,
      "h": 4295553231,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295553231)
  ],
  "h": 585935
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(585935)
        
        

        //--TRIMMABLE-BOUNDARY-START(717007)
        $asm.$cls(`$IHYd.LCFCLS.FiledLocalStorageService`, ($self) => class FiledLocalStorageService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655422671)
            /*Dictionary<string, object?>*/ inMemoryStore = null;
            //--TRIMMABLE-BOUNDARY-END(38655422671)
            
            //--TRIMMABLE-BOUNDARY-START(30065488079)
            static /*string */ GetFilePath(/*string*/ fileName, /*bool*/ flat, /*bool*/ createDirectoryIfNotExist)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065488079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let dir = $.$$.SI.Path.Combine$3($.$$.S.Environment.GetFolderPath$1(28/*Environment.SpecialFolder.LocalApplicationData*/), ($.$$.SR.Assembly.GetEntryAssembly()?.GetName().Name ?? null) ?? "_");
                if (!flat)
                {
                    /*var*/ let ddir = $.$$.SI.Path.GetDirectoryName$1(fileName);
                    fileName = $.$$.SI.Path.GetFileName$1(fileName);
                    dir = $.$$.SI.Path.Join$6(dir, ddir ?? "");
                }
                else 
                {
                    fileName = !$.$$.S.String.IsNullOrEmpty(fileName) ? $.$$.S.Int32.ToString.call($.$fPer.LCFCS$6.StringExtension.GetDeterministicHashCode(fileName)) : fileName;
                }
                if (createDirectoryIfNotExist)
                {
                    if (!$.$$.SI.Directory.Exists(dir))
                    {
                        $.$$.SI.Directory.CreateDirectory$1(dir);
                    }
                }
                return $.$$.SI.Path.Combine$3(dir, fileName);
            }
            //--TRIMMABLE-BOUNDARY-END(30065488079)
            
            //--TRIMMABLE-BOUNDARY-START(34360455375)
            /*ValueTask<T?> */ GetItem(T, /*string*/ key)
            {
                /*var*/ let mcache;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360455375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                key = $.$IHYd.LCFCLS.FiledLocalStorageService.GetFilePath(key, true, false);
                if (this.inMemoryStore.TryGetValue(key, $.$ref(() => mcache, ($v) => mcache = $v, $.$$.S.Object)))
                {
                    return $.$$.STT.ValueTask.FromResult(T, $.$cast(mcache, T));
                }
                if ($.$$.SI.File.Exists(key))
                {
                    try
                    {
                        /*var*/ let fileContent = $.$$.SI.File.ReadAllText$1(key);
                        let t;
                        if ($.$is(fileContent, T, { set $v($v){ t = $v; } }))
                        {
                            this.inMemoryStore.set_Item(key, $.$box(t, T));
                            return $.$$.STT.ValueTask.FromResult(T, t);
                        }
                        /*var*/ let result = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3(T, fileContent, false, "GetItem", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Local\\FiledLocalStorageService.cs", "GetItem", 67);
                        this.inMemoryStore.set_Item(key, $.$box(result, T));
                        return $.$$.STT.ValueTask.FromResult(T, result);
                    }
                    catch(e)
                    {
                        $.$fPer.LCFCL.LoggingFactory.LogException(e, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Local\\FiledLocalStorageService.cs", "GetItem", 73);
                    }
                }
                return $.$$.STT.ValueTask.FromResult(T, $.$default(T));
            }
            //--TRIMMABLE-BOUNDARY-END(34360455375)
            
            //--TRIMMABLE-BOUNDARY-START(47245357263)
            /*ValueTask */ RemoveItem(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245357263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                key = $.$IHYd.LCFCLS.FiledLocalStorageService.GetFilePath(key, true, false);
                this.inMemoryStore.Remove$1(key);
                if ($.$$.SI.File.Exists(key))
                {
                    $.$$.SI.File.Delete(key);
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(47245357263)
            
            //--TRIMMABLE-BOUNDARY-START(51540324559)
            /*ValueTask */ SetItem(T, /*string*/ key, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540324559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                key = $.$IHYd.LCFCLS.FiledLocalStorageService.GetFilePath(key, true, true);
                this.inMemoryStore.set_Item(key, $.$box(value, T));
                let t;
                /*var*/ let json = $.$is(value, $.$$.S.String, { set $v($v){ t = $v; } }) ? t : $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(T, value, true, false, true, false, false, false, false, "SetItem", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Local\\FiledLocalStorageService.cs", "SetItem", 94).Json;
                $.$$.SI.File.WriteAllText$3(key, json);
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(51540324559)
            
            //--TRIMMABLE-BOUNDARY-START(8590651599)
            /*ValueTask */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590651599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.inMemoryStore.Clear();
                /*var*/ let path = $.$IHYd.LCFCLS.FiledLocalStorageService.GetFilePath("", true, false);
                /*var*/ let dirs = $.$$.SI.Directory.EnumerateDirectories$3(path);
                let $en2 = dirs.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let dir = $en2.SCG$IEnumerator$$$Current;
                    {
                        try
                        {
                            $.$$.SI.Directory.Delete(dir, true);
                        }
                        catch($e)
                        {
                        }
                    }
                }
                /*var*/ let files = $.$$.SI.Directory.EnumerateFiles$3(path);
                let $en3 = files.SCG$IEnumerable$$$GetEnumerator();
                while ($en3.SC$1$IEnumerator$MoveNext())
                {
                    let file = $en3.SCG$IEnumerator$$$Current;
                    {
                        try
                        {
                            $.$$.SI.File.Delete(file);
                        }
                        catch($e)
                        {
                        }
                    }
                }
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(8590651599)
            
            //--TRIMMABLE-BOUNDARY-START(17180586191)
            /*bool */ Exists(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180586191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ppath = $.$IHYd.LCFCLS.FiledLocalStorageService.GetFilePath(path, false, false);
                return $.$$.SI.File.Exists(ppath);
            }
            //--TRIMMABLE-BOUNDARY-END(17180586191)
            
            //--TRIMMABLE-BOUNDARY-START(42950389967)
            /*Stream? */ ReadStream(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950389967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ppath = $.$IHYd.LCFCLS.FiledLocalStorageService.GetFilePath(path, false, false);
                if ($.$$.SI.File.Exists(ppath))
                {
                    return new $.$$.SI.FileStream().$ctor$15(ppath, 3/*FileMode.Open*/, 1/*FileAccess.Read*/);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(42950389967)
            
            //--TRIMMABLE-BOUNDARY-START(60130259151)
            /*Task *//*async*/  WriteStream(/*string*/ path, /*OneOf<string, Stream?>*/ stream, /*long?*/ position)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130259151);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let ppath = $.$IHYd.LCFCLS.FiledLocalStorageService.GetFilePath(path, false, true);
                    let fStream = null;
                    try
                    {
                        fStream = new $.$$.SI.FileStream().$ctor$15(ppath, 4/*FileMode.OpenOrCreate*/, 2/*FileAccess.Write*/);
                        if (position !== null)
                        {
                            fStream.Seek($.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(position), 0/*SeekOrigin.Begin*/);
                        }
                        if (stream.IsT0)
                        {
                            fStream.Write$1($.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1($.$$.ST.Encoding.UTF8.GetBytes$8(stream.AsT0)));
                        }
                        else if (stream.IsT1 && stream.AsT1 !== null)
                        {
                            let $t4, $r4;
                            ($t4 = stream.AsT1.CopyToAsync$3(fStream), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        }
                        fStream.Flush();
                    }
                    finally
                    {
                        fStream?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60130259151)
            
            //--TRIMMABLE-BOUNDARY-START(12885618895)
            /*Task */ DeleteStream(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885618895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ppath = $.$IHYd.LCFCLS.FiledLocalStorageService.GetFilePath(path, false, true);
                if ($.$$.SI.File.Exists(ppath))
                {
                    $.$$.SI.File.Delete(ppath);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12885618895)
            
            //--TRIMMABLE-BOUNDARY-START(848079)
            static $_NotExistFileInfo;
            static get NotExistFileInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(848079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$IHYd.LCFCLS.FiledLocalStorageService;
                return $cls.$_NotExistFileInfo ??= $asm.$ncls(`$IHYd.LCFCLS.FiledLocalStorageService.NotExistFileInfo`, ($self) => class NotExistFileInfo extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(47245488335)
                    /*NotExistFileInfo*/ static FileInfo = null;
                    //--TRIMMABLE-BOUNDARY-END(47245488335)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950521039)
                    /*bool*/ Exists = false;
                    //--TRIMMABLE-BOUNDARY-END(42950521039)
                    
                    //--TRIMMABLE-BOUNDARY-START(111669997775)
                    /*long*/ Length = 0n;
                    //--TRIMMABLE-BOUNDARY-END(111669997775)
                    
                    //--TRIMMABLE-BOUNDARY-START(120259932367)
                    /*string?*/ PhysicalPath = null;
                    //--TRIMMABLE-BOUNDARY-END(120259932367)
                    
                    //--TRIMMABLE-BOUNDARY-START(115964965071)
                    /*string*/ Name = null;
                    //--TRIMMABLE-BOUNDARY-END(115964965071)
                    
                    //--TRIMMABLE-BOUNDARY-START(107375030479)
                    /*DateTimeOffset*/ LastModified;
                    //--TRIMMABLE-BOUNDARY-END(107375030479)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080063183)
                    /*bool*/ IsDirectory = false;
                    //--TRIMMABLE-BOUNDARY-END(103080063183)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655553743)
                    /*Stream */ CreateReadStream()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655553743);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.S.NotImplementedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655553743)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065891)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
                    get MEF$IFileInfo$Exists()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590131299);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Exists;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065891)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949869667)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
                    get MEF$IFileInfo$Length()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014640739);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Length;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949869667)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129738851)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
                    get MEF$IFileInfo$PhysicalPath()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81604575331);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.PhysicalPath;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129738851)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539804259)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
                    get MEF$IFileInfo$Name()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77309608035);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539804259)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359935075)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
                    get MEF$IFileInfo$LastModified()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68719673443);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.LastModified;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359935075)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000483)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
                    get MEF$IFileInfo$IsDirectory()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424706147);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsDirectory;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000483)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295164003)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
                    MEF$IFileInfo$CreateReadStream()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295164003);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreateReadStream(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295164003)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360586447)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360586447);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360586447)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360586447)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360586447)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(107375030479)
                        this.LastModified = $.$default($.$$.S.DateTimeOffset);
                        //--TRIMMABLE-BOUNDARY-END(107375030479)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(30065619151)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065619151);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(47245488335)
                            this.FileInfo = new $.$IHYd.LCFCLS.FiledLocalStorageService.NotExistFileInfo().$ctor$1();
                            //--TRIMMABLE-BOUNDARY-END(47245488335)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065619151)
                    
                    static $h = 848079;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950521039),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835422927,
        "f": 50331649
      },
      "n": "Exists",
      "d": 848079,
      "h": 42950521039,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950521039),
//--TRIMMABLE-BOUNDARY-START(111669997775),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605226703,
        "f": 50331649
      },
      "n": "Length",
      "d": 848079,
      "h": 111669997775,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669997775),
//--TRIMMABLE-BOUNDARY-START(120259932367),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785095887,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 848079,
      "h": 120259932367,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259932367),
//--TRIMMABLE-BOUNDARY-START(115964965071),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195161295,
        "f": 50331649
      },
      "n": "Name",
      "d": 848079,
      "h": 115964965071,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964965071),
//--TRIMMABLE-BOUNDARY-START(107375030479),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015292111,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 848079,
      "h": 107375030479,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375030479),
//--TRIMMABLE-BOUNDARY-START(103080063183),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425357519,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 848079,
      "h": 103080063183,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080063183)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655553743),
    {
      "r": 95748097,
      "n": "CreateReadStream",
      "d": 848079,
      "h": 38655553743,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655553743)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245488335),
    {
      "t": 848079,
      "n": "FileInfo",
      "d": 848079,
      "h": 47245488335,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245488335)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360586447),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 848079,
      "h": 34360586447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360586447)
  ],
  "d": 717007,
  "h": 848079
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileInfo ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.Storage.FiledLocalStorageService+NotExistFileInfo`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}Storage${separator}FiledLocalStorageService${separator}NotExistFileInfo`; }
                }, $cls, ($v) => $cls.$_NotExistFileInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(848079)
            
            //--TRIMMABLE-BOUNDARY-START(782543)
            static $_FiledInfo;
            static get FiledInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(782543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$IHYd.LCFCLS.FiledLocalStorageService;
                return $cls.$_FiledInfo ??= $asm.$ncls(`$IHYd.LCFCLS.FiledLocalStorageService.FiledInfo`, ($self) => class FiledInfo extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(30065553615)
                    $ctor$1(/*string*/ name)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065553615);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Name = name;
                            /*var*/ let path = $.$IHYd.LCFCLS.FiledLocalStorageService.GetFilePath(this.Name, false, false);
                            this.Exists = $.$$.SI.File.Exists(path);
                            if (this.Exists)
                            {
                                this.PhysicalPath = path;
                                /*var*/ let info = new $.$$.SI.FileInfo().$ctor$6(path);
                                this.Length = info.Length;
                                this.LastModified = $.$$.S.DateTimeOffset.op_Implicit(info.LastWriteTime);
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065553615)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655488207)
                    /*bool*/ Exists = false;
                    //--TRIMMABLE-BOUNDARY-END(38655488207)
                    
                    //--TRIMMABLE-BOUNDARY-START(103079997647)
                    /*long*/ Length = 0n;
                    //--TRIMMABLE-BOUNDARY-END(103079997647)
                    
                    //--TRIMMABLE-BOUNDARY-START(111669932239)
                    /*string?*/ PhysicalPath = null;
                    //--TRIMMABLE-BOUNDARY-END(111669932239)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374964943)
                    /*string*/ Name = null;
                    //--TRIMMABLE-BOUNDARY-END(107374964943)
                    
                    //--TRIMMABLE-BOUNDARY-START(98785030351)
                    /*DateTimeOffset*/ LastModified;
                    //--TRIMMABLE-BOUNDARY-END(98785030351)
                    
                    //--TRIMMABLE-BOUNDARY-START(94490063055)
                    /*bool*/ IsDirectory = false;
                    //--TRIMMABLE-BOUNDARY-END(94490063055)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360520911)
                    /*Stream */ CreateReadStream()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360520911);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$$.SI.FileStream().$ctor$15(this.PhysicalPath, 3/*FileMode.Open*/, 1/*FileAccess.Read*/);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360520911)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065891)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
                    get MEF$IFileInfo$Exists()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590131299);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Exists;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065891)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949869667)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
                    get MEF$IFileInfo$Length()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014640739);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Length;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949869667)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129738851)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
                    get MEF$IFileInfo$PhysicalPath()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81604575331);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.PhysicalPath;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129738851)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539804259)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
                    get MEF$IFileInfo$Name()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77309608035);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Name;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539804259)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359935075)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
                    get MEF$IFileInfo$LastModified()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68719673443);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.LastModified;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359935075)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000483)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
                    get MEF$IFileInfo$IsDirectory()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424706147);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsDirectory;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000483)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295164003)
                    //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
                    MEF$IFileInfo$CreateReadStream()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295164003);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreateReadStream(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295164003)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(98785030351)
                        this.LastModified = $.$default($.$$.S.DateTimeOffset);
                        //--TRIMMABLE-BOUNDARY-END(98785030351)
                        
                    }
                    static $h = 782543;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655488207),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245422799,
        "f": 50331649
      },
      "n": "Exists",
      "d": 782543,
      "h": 38655488207,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655488207),
//--TRIMMABLE-BOUNDARY-START(103079997647),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015226575,
        "f": 50331649
      },
      "n": "Length",
      "d": 782543,
      "h": 103079997647,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079997647),
//--TRIMMABLE-BOUNDARY-START(111669932239),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195095759,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 782543,
      "h": 111669932239,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669932239),
//--TRIMMABLE-BOUNDARY-START(107374964943),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605161167,
        "f": 50331649
      },
      "n": "Name",
      "d": 782543,
      "h": 107374964943,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374964943),
//--TRIMMABLE-BOUNDARY-START(98785030351),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425291983,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 782543,
      "h": 98785030351,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785030351),
//--TRIMMABLE-BOUNDARY-START(94490063055),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835357391,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 782543,
      "h": 94490063055,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490063055)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360520911),
    {
      "r": 95748097,
      "n": "CreateReadStream",
      "d": 782543,
      "h": 34360520911,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360520911)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065553615),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 782543,
      "h": 30065553615,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065553615)
  ],
  "d": 717007,
  "h": 782543
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileInfo ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.Storage.FiledLocalStorageService+FiledInfo`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}Storage${separator}FiledLocalStorageService${separator}FiledInfo`; }
                }, $cls, ($v) => $cls.$_FiledInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(782543)
            
            //--TRIMMABLE-BOUNDARY-START(25770520783)
            /*IFileInfo */ GetFileInfo(/*string*/ subpath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770520783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let path = $.$IHYd.LCFCLS.FiledLocalStorageService.GetFilePath(subpath, false, false);
                if (!$.$$.SI.File.Exists(path))
                {
                    return $.$IHYd.LCFCLS.FiledLocalStorageService.NotExistFileInfo.FileInfo;
                }
                return new $.$IHYd.LCFCLS.FiledLocalStorageService.FiledInfo().$ctor$1(subpath);
            }
            //--TRIMMABLE-BOUNDARY-END(25770520783)
            
            //--TRIMMABLE-BOUNDARY-START(21475553487)
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ subpath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475553487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475553487)
            
            //--TRIMMABLE-BOUNDARY-START(55835291855)
            /*IChangeToken */ Watch(/*string*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835291855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(55835291855)
            
            //--TRIMMABLE-BOUNDARY-START(8653867350)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Storage.IPersistentStorageService.GetItem<T>(string)
            LCFCS$5$IPersistentStorageService$GetItem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653867350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetItem(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8653867350)
            
            //--TRIMMABLE-BOUNDARY-START(17243801942)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Storage.IPersistentStorageService.SetItem<T>(string, T)
            LCFCS$5$IPersistentStorageService$SetItem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17243801942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetItem(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17243801942)
            
            //--TRIMMABLE-BOUNDARY-START(12948834646)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Storage.IPersistentStorageService.RemoveItem(string)
            LCFCS$5$IPersistentStorageService$RemoveItem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12948834646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveItem(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12948834646)
            
            //--TRIMMABLE-BOUNDARY-START(4358900054)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Storage.IPersistentStorageService.Clear()
            LCFCS$5$IPersistentStorageService$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358900054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358900054)
            
            //--TRIMMABLE-BOUNDARY-START(8590196835)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            MEF$IFileProvider$GetFileInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFileInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196835)
            
            //--TRIMMABLE-BOUNDARY-START(4295229539)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            MEF$IFileProvider$GetDirectoryContents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDirectoryContents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229539)
            
            //--TRIMMABLE-BOUNDARY-START(12885164131)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            MEF$IFileProvider$Watch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Watch(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164131)
            
            //--TRIMMABLE-BOUNDARY-START(4295684303)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295684303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295684303)
            
            //--TRIMMABLE-BOUNDARY-START(4295684303)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295684303)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38655422671)
                this.inMemoryStore = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(38655422671)
                
            }
            static $h = 717007;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065488079),
    {
      "r": 1310721,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "flat",
          "p": 262145
        },
        {
          "n": "createDirectoryIfNotExist",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "GetFilePath",
      "d": 717007,
      "h": 30065488079,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065488079),
//--TRIMMABLE-BOUNDARY-START(34360455375),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetItem",
      "d": 717007,
      "h": 34360455375,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(34360455375),
//--TRIMMABLE-BOUNDARY-START(47245357263),
    {
      "r": 181338113,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "RemoveItem",
      "d": 717007,
      "h": 47245357263,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245357263),
//--TRIMMABLE-BOUNDARY-START(51540324559),
    {
      "r": 181338113,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "SetItem",
      "d": 717007,
      "h": 51540324559,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(51540324559),
//--TRIMMABLE-BOUNDARY-START(8590651599),
    {
      "r": 181338113,
      "n": "Clear",
      "d": 717007,
      "h": 8590651599,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590651599),
//--TRIMMABLE-BOUNDARY-START(17180586191),
    {
      "r": 262145,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "Exists",
      "d": 717007,
      "h": 17180586191,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180586191),
//--TRIMMABLE-BOUNDARY-START(42950389967),
    {
      "r": 95748097,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "ReadStream",
      "d": 717007,
      "h": 42950389967,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950389967),
//--TRIMMABLE-BOUNDARY-START(60130259151),
    {
      "r": 178454529,
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "stream",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.String, $.$$.SI.Stream).$h
        },
        {
          "n": "position",
          "p": $.$typeNullable($.$$.S.Int64).$h,
          "f": 65
        }
      ],
      "n": "WriteStream",
      "d": 717007,
      "h": 60130259151,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(60130259151),
//--TRIMMABLE-BOUNDARY-START(12885618895),
    {
      "r": 178454529,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "DeleteStream",
      "d": 717007,
      "h": 12885618895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885618895),
//--TRIMMABLE-BOUNDARY-START(25770520783),
    {
      "r": 196707,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetFileInfo",
      "d": 717007,
      "h": 25770520783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770520783),
//--TRIMMABLE-BOUNDARY-START(21475553487),
    {
      "r": 131171,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetDirectoryContents",
      "d": 717007,
      "h": 21475553487,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475553487),
//--TRIMMABLE-BOUNDARY-START(55835291855),
    {
      "r": 720981,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "Watch",
      "d": 717007,
      "h": 55835291855,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835291855)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655422671),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "n": "inMemoryStore",
      "d": 717007,
      "h": 38655422671,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655422671)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295684303),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 717007,
      "h": 4295684303,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295684303)
  ],
  "h": 717007
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$5.IPersistentStorageService, $.$mefa.MEF.IFileProvider ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$IHYd.LCFCLS.FiledLocalStorageService.NotExistFileInfo, $.$IHYd.LCFCLS.FiledLocalStorageService.FiledInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.Storage.FiledLocalStorageService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}Storage${separator}FiledLocalStorageService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(717007)
        
        

        //--TRIMMABLE-BOUNDARY-START(651471)
        $asm.$cls(`$IHYd.LCFCLS.FiledCacheStorageService`, ($self) => class FiledCacheStorageService extends $.$IHYd.LCFCLS.FiledLocalStorageService
        {
            //--TRIMMABLE-BOUNDARY-START(12885553359)
            /*ValueTask */ SetItem$1(T, /*string*/ key, /*T*/ value, /*TimeSpan*/ expiry)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885553359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.SetItem($.$fPer.LCFCD.DataCache$$(T), key, (() =>
                {
                    //new $.$fPer.LCFCD.DataCache$$(T)()
                    const $t1 = $.$fPer.LCFCD.DataCache$$(T);
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Data = value;
                    $i1.Expires = $.$$.S.TimeSpan.op_Equality(expiry, $.$$.S.TimeSpan.MaxValue) ? $.$$.S.DateTime.MaxValue : $.$$.S.DateTime.UtcNow.Add(expiry);
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(12885553359)
            
            //--TRIMMABLE-BOUNDARY-START(8590586063)
            /*ValueTask<T?> *//*async*/  GetItem(T, /*string*/ key)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T), T, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590586063);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let cache = ($t2 = super.GetItem($.$fPer.LCFCD.DataCache$$(T), key).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    /*var*/ let now = $.$$.S.DateTime.UtcNow;
                    if ($.$$.S.DateTime.op_LessThan(now, cache.Expires))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, cache.Data);
                    }
                    else 
                    {
                        let $t3, $r3;
                        ($t3 = this.RemoveItem(key).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$default(T));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590586063)
            
            //--TRIMMABLE-BOUNDARY-START(4358834518)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Storage.IDataCacheStorageService.GetItem<T>(string)
            LCFCS$5$IDataCacheStorageService$GetItem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358834518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetItem(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358834518)
            
            //--TRIMMABLE-BOUNDARY-START(12948769110)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Storage.IDataCacheStorageService.SetItem<T>(string, T, System.TimeSpan)
            LCFCS$5$IDataCacheStorageService$SetItem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12948769110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetItem$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12948769110)
            
            //--TRIMMABLE-BOUNDARY-START(8653801814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Storage.IDataCacheStorageService.RemoveItem(string)
            LCFCS$5$IDataCacheStorageService$RemoveItem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653801814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveItem(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8653801814)
            
            //--TRIMMABLE-BOUNDARY-START(4295618767)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295618767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295618767)
            
            //--TRIMMABLE-BOUNDARY-START(4295618767)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295618767)
            
            static $h = 651471;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$IHYd.LCFCLS.FiledLocalStorageService; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885553359),
    {
      "r": 181338113,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "expiry",
          "p": 186646529
        }
      ],
      "g": [
        "T"
      ],
      "n": "SetItem",
      "o": "@$1",
      "d": 651471,
      "h": 12885553359,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(12885553359),
//--TRIMMABLE-BOUNDARY-START(8590586063),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetItem",
      "d": 651471,
      "h": 8590586063,
      "f": 16945153
    },
//--TRIMMABLE-BOUNDARY-END(8590586063)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295618767),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 651471,
      "h": 4295618767,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295618767)
  ],
  "h": 651471
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$5.IPersistentStorageService, $.$mefa.MEF.IFileProvider, $.$fPer.LCFCS$5.IDataCacheStorageService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Local.Storage.FiledCacheStorageService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Local${separator}Storage${separator}FiledCacheStorageService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(651471)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(61647)
