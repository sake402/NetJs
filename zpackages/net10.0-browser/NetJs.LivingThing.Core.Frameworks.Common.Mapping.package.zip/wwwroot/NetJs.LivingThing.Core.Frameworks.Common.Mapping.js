
//--TRIMMABLE-BOUNDARY-START(47342)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer) {
    "use strict";
    let _;
    let $RmWZBc;
    let $JUUwoh;
    let $KlGRbg;
    let $MDzlIe;
    let $IryIsj;
    let $YJbOhb;
    let $xOINWi;
    let $sFFbud;
    let $OKPpij;
    let $oTQEDb;
    let $CHYNlh;
    let $CyTLUg;
    let $LGNXzb;
    let $pWKfRk;
    let $JwwsId;
    let $Jcroge;
    let $ClQljf;
    let $DULYKh;
    let $ISQNPe;
    let $uLoCAi;
    let $IlLRvk;
    let $mQAzye;
    let $CfQnog;
    let $DiXCci;
    let $wHBLEd;
    let $dXRfEd;
    let $VACMgj;
    let $fdanMc;
    let $IBiORg;
    let $hXCtya;
    let $RfQIMg;
    let $QGDvKc;
    let $NrSoQc;
    let $ZCUoRd;
    let $JhPkGc;
    let $JEAAUf;
    let $fqhcnl;
    let $qhpPTj;
    let $nsiqjb;
    let $eGFoDh;
    let $GgwGgk;
    let $QDhKyg;
    let $CzRLei;
    let $IECMuk;
    let $qHEscf;
    let $RRDfmf;
    let $dAKkHj;
    let $sjGWhi;
    let $MsLqBg;
    let $AOpqpc;
    let $ociZHi;
    let $cNQErj;
    let $pjSpIk;
    let $eaFjnb;
    let $TckRgd;
    let $pmHUkf;
    let $TBmUqh;
    let $oifCSi;
    let $rvXKKd;
    let $HUIrrd;
    let $gsKVQf;
    let $pspBEe;
    let $qWkwHc;
    let $JqUBFf;
    let $wZtTOe;
    let $JSnWlj;
    let $PCiOwi;
    let $qXEXze;
    let $MUYDdi;
    let $iTRFZg;
    let $qmNOQd;
    let $PzMmCg;
    let $BrbRaf;
    let $NJXvvf;
    let $FjFGpj;
    let $EAURaf;
    let $TiLVye;
    let $OWaCUh;
    let $jUUMrb;
    let $JWFimf;
    let $TafWlg;
    let $yrvrwc;
    let $RooCYf;
    let $MKWrph;
    let $hkZKeb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Mapping", 
    {
  "h": 47342,
  "f": "LivingThing.Core.Frameworks.Common.Mapping",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Mapping",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Mapping",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1751278)
        $asm.$cls(`$AutK.LCFCML.LocationIQDirectionDrivingGeometry`, ($self) => class LocationIQDirectionDrivingGeometry extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181620462)
            /*double[][]*/ Coordinates = null;
            //--TRIMMABLE-BOUNDARY-END(17181620462)
            
            //--TRIMMABLE-BOUNDARY-START(55836326126)
            /*string*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(55836326126)
            
            //--TRIMMABLE-BOUNDARY-START(12886653166)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886653166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886653166)
            
            //--TRIMMABLE-BOUNDARY-START(12886653166)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886653166)
            
            static $h = 1751278;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181620462),
    {
      "p": $.$typeArray($.$typeArray($.$$.S.Double)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771555054,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951424238,
        "f": 83886081
      },
      "n": "Coordinates",
      "d": 1751278,
      "h": 17181620462,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "coordinates",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181620462),
//--TRIMMABLE-BOUNDARY-START(55836326126),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361489646,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541358830,
        "f": 83886081
      },
      "n": "Type",
      "d": 1751278,
      "h": 55836326126,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "type",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836326126)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886653166),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1751278,
      "h": 12886653166,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886653166)
  ],
  "h": 1751278
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingGeometry`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQDirectionDrivingGeometry`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1751278)
        
        

        //--TRIMMABLE-BOUNDARY-START(571630)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel`, ($self) => class GeocodeMapsCoReverseGeocodeMapsAddressModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115964688622)
            /*string*/ Road = null;
            //--TRIMMABLE-BOUNDARY-END(115964688622)
            
            //--TRIMMABLE-BOUNDARY-START(184684165358)
            /*string*/ Suburb = null;
            //--TRIMMABLE-BOUNDARY-END(184684165358)
            
            //--TRIMMABLE-BOUNDARY-START(47245211886)
            /*string*/ County = null;
            //--TRIMMABLE-BOUNDARY-END(47245211886)
            
            //--TRIMMABLE-BOUNDARY-START(180389198062)
            /*string*/ State = null;
            //--TRIMMABLE-BOUNDARY-END(180389198062)
            
            //--TRIMMABLE-BOUNDARY-START(111669721326)
            /*string*/ Postcode = null;
            //--TRIMMABLE-BOUNDARY-END(111669721326)
            
            //--TRIMMABLE-BOUNDARY-START(38655277294)
            /*string*/ Country = null;
            //--TRIMMABLE-BOUNDARY-END(38655277294)
            
            //--TRIMMABLE-BOUNDARY-START(42950244590)
            /*string*/ CountryCode = null;
            //--TRIMMABLE-BOUNDARY-END(42950244590)
            
            //--TRIMMABLE-BOUNDARY-START(34360309998)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360309998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360309998)
            
            //--TRIMMABLE-BOUNDARY-START(34360309998)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34360309998)
            
            static $h = 571630;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964688622),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194884846,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914361582,
        "f": 83886081
      },
      "n": "Road",
      "d": 571630,
      "h": 115964688622,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "road",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964688622),
//--TRIMMABLE-BOUNDARY-START(184684165358),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374754030,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094230766,
        "f": 83886081
      },
      "n": "Suburb",
      "d": 571630,
      "h": 184684165358,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "suburb",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184684165358),
//--TRIMMABLE-BOUNDARY-START(47245211886),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015015662,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734492398,
        "f": 83886081
      },
      "n": "County",
      "d": 571630,
      "h": 47245211886,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "county",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245211886),
//--TRIMMABLE-BOUNDARY-START(180389198062),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784819438,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504296174,
        "f": 83886081
      },
      "n": "State",
      "d": 571630,
      "h": 180389198062,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "state",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180389198062),
//--TRIMMABLE-BOUNDARY-START(111669721326),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604950254,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324426990,
        "f": 83886081
      },
      "n": "Postcode",
      "d": 571630,
      "h": 111669721326,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "postcode",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669721326),
//--TRIMMABLE-BOUNDARY-START(38655277294),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835146478,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554623214,
        "f": 83886081
      },
      "n": "Country",
      "d": 571630,
      "h": 38655277294,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "country",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655277294),
//--TRIMMABLE-BOUNDARY-START(42950244590),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425081070,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144557806,
        "f": 83886081
      },
      "n": "CountryCode",
      "d": 571630,
      "h": 42950244590,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "country_code",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950244590)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360309998),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 571630,
      "h": 34360309998,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360309998)
  ],
  "h": 571630
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoReverseGeocodeMapsAddressModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(571630)
        
        

        //--TRIMMABLE-BOUNDARY-START(833774)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel`, ($self) => class GeocodeMapsCoReverseGeocodeMapsModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(171799525614)
            /*long*/ PlaceId = 0n;
            //--TRIMMABLE-BOUNDARY-END(171799525614)
            
            //--TRIMMABLE-BOUNDARY-START(154619656430)
            /*string*/ Licence = null;
            //--TRIMMABLE-BOUNDARY-END(154619656430)
            
            //--TRIMMABLE-BOUNDARY-START(176094492910)
            /*string*/ PoweredBy = null;
            //--TRIMMABLE-BOUNDARY-END(176094492910)
            
            //--TRIMMABLE-BOUNDARY-START(167504558318)
            /*string*/ OsmType = null;
            //--TRIMMABLE-BOUNDARY-END(167504558318)
            
            //--TRIMMABLE-BOUNDARY-START(163209591022)
            /*long*/ OsmId = 0n;
            //--TRIMMABLE-BOUNDARY-END(163209591022)
            
            //--TRIMMABLE-BOUNDARY-START(150324689134)
            /*string*/ Lat = null;
            //--TRIMMABLE-BOUNDARY-END(150324689134)
            
            //--TRIMMABLE-BOUNDARY-START(158914623726)
            /*string*/ Lon = null;
            //--TRIMMABLE-BOUNDARY-END(158914623726)
            
            //--TRIMMABLE-BOUNDARY-START(60130375918)
            /*string*/ DisplayName = null;
            //--TRIMMABLE-BOUNDARY-END(60130375918)
            
            //--TRIMMABLE-BOUNDARY-START(51540441326)
            /*GeocodeMapsCoReverseGeocodeMapsAddressModel*/ Address = null;
            //--TRIMMABLE-BOUNDARY-END(51540441326)
            
            //--TRIMMABLE-BOUNDARY-START(55835408622)
            /*string[]*/ Boundingbox = null;
            //--TRIMMABLE-BOUNDARY-END(55835408622)
            
            //--TRIMMABLE-BOUNDARY-START(47245474030)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245474030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245474030)
            
            //--TRIMMABLE-BOUNDARY-START(47245474030)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(47245474030)
            
            static $h = 833774;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(171799525614),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439787246,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253403904238,
        "f": 83886081
      },
      "n": "PlaceId",
      "d": 833774,
      "h": 171799525614,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "place_id",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799525614),
//--TRIMMABLE-BOUNDARY-START(154619656430),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080048878,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044165870,
        "f": 83886081
      },
      "n": "Licence",
      "d": 833774,
      "h": 154619656430,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "licence",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619656430),
//--TRIMMABLE-BOUNDARY-START(176094492910),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029721838,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993838830,
        "f": 83886081
      },
      "n": "PoweredBy",
      "d": 833774,
      "h": 176094492910,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "powered_by",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094492910),
//--TRIMMABLE-BOUNDARY-START(167504558318),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849852654,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244813969646,
        "f": 83886081
      },
      "n": "OsmType",
      "d": 833774,
      "h": 167504558318,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "osm_type",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167504558318),
//--TRIMMABLE-BOUNDARY-START(163209591022),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259918062,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224035054,
        "f": 83886081
      },
      "n": "OsmId",
      "d": 833774,
      "h": 163209591022,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "osm_id",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209591022),
//--TRIMMABLE-BOUNDARY-START(150324689134),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490114286,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454231278,
        "f": 83886081
      },
      "n": "Lat",
      "d": 833774,
      "h": 150324689134,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "lat",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324689134),
//--TRIMMABLE-BOUNDARY-START(158914623726),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669983470,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634100462,
        "f": 83886081
      },
      "n": "Lon",
      "d": 833774,
      "h": 158914623726,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "lon",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914623726),
//--TRIMMABLE-BOUNDARY-START(60130375918),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900179694,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864296686,
        "f": 83886081
      },
      "n": "DisplayName",
      "d": 833774,
      "h": 60130375918,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "display_name",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130375918),
//--TRIMMABLE-BOUNDARY-START(51540441326),
    {
      "p": 571630,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720310510,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684427502,
        "f": 83886081
      },
      "n": "Address",
      "d": 833774,
      "h": 51540441326,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "address",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540441326),
//--TRIMMABLE-BOUNDARY-START(55835408622),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310245102,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274362094,
        "f": 83886081
      },
      "n": "Boundingbox",
      "d": 833774,
      "h": 55835408622,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "boundingbox",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835408622)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47245474030),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 833774,
      "h": 47245474030,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245474030)
  ],
  "h": 833774
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoReverseGeocodeMapsModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(833774)
        
        

        //--TRIMMABLE-BOUNDARY-START(309486)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoModel`, ($self) => class GeocodeMapsCoModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(201863772398)
            /*long*/ PlaceId = 0n;
            //--TRIMMABLE-BOUNDARY-END(201863772398)
            
            //--TRIMMABLE-BOUNDARY-START(184683903214)
            /*string*/ Licence = null;
            //--TRIMMABLE-BOUNDARY-END(184683903214)
            
            //--TRIMMABLE-BOUNDARY-START(206158739694)
            /*string*/ PoweredBy = null;
            //--TRIMMABLE-BOUNDARY-END(206158739694)
            
            //--TRIMMABLE-BOUNDARY-START(197568805102)
            /*string*/ OsmType = null;
            //--TRIMMABLE-BOUNDARY-END(197568805102)
            
            //--TRIMMABLE-BOUNDARY-START(193273837806)
            /*long*/ OsmId = 0n;
            //--TRIMMABLE-BOUNDARY-END(193273837806)
            
            //--TRIMMABLE-BOUNDARY-START(60129851630)
            /*string[]*/ Boundingbox = null;
            //--TRIMMABLE-BOUNDARY-END(60129851630)
            
            //--TRIMMABLE-BOUNDARY-START(180388935918)
            /*string*/ Lat = null;
            //--TRIMMABLE-BOUNDARY-END(180388935918)
            
            //--TRIMMABLE-BOUNDARY-START(188978870510)
            /*string*/ Lon = null;
            //--TRIMMABLE-BOUNDARY-END(188978870510)
            
            //--TRIMMABLE-BOUNDARY-START(68719786222)
            /*string*/ DisplayName = null;
            //--TRIMMABLE-BOUNDARY-END(68719786222)
            
            //--TRIMMABLE-BOUNDARY-START(64424818926)
            /*string*/ Class = null;
            //--TRIMMABLE-BOUNDARY-END(64424818926)
            
            //--TRIMMABLE-BOUNDARY-START(313532922094)
            /*string*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(313532922094)
            
            //--TRIMMABLE-BOUNDARY-START(176093968622)
            /*double*/ Importance = 0;
            //--TRIMMABLE-BOUNDARY-END(176093968622)
            
            //--TRIMMABLE-BOUNDARY-START(55834884334)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834884334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834884334)
            
            //--TRIMMABLE-BOUNDARY-START(55834884334)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(55834884334)
            
            static $h = 309486;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(201863772398),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619132142,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292058085614,
        "f": 83886081
      },
      "n": "PlaceId",
      "d": 309486,
      "h": 201863772398,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "place_id",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201863772398),
//--TRIMMABLE-BOUNDARY-START(184683903214),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259393774,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698347246,
        "f": 83886081
      },
      "n": "Licence",
      "d": 309486,
      "h": 184683903214,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "licence",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184683903214),
//--TRIMMABLE-BOUNDARY-START(206158739694),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209066734,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300648020206,
        "f": 83886081
      },
      "n": "PoweredBy",
      "d": 309486,
      "h": 206158739694,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "powered_by",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206158739694),
//--TRIMMABLE-BOUNDARY-START(197568805102),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029197550,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468151022,
        "f": 83886081
      },
      "n": "OsmType",
      "d": 309486,
      "h": 197568805102,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "osm_type",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197568805102),
//--TRIMMABLE-BOUNDARY-START(193273837806),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439262958,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878216430,
        "f": 83886081
      },
      "n": "OsmId",
      "d": 309486,
      "h": 193273837806,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "osm_id",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193273837806),
//--TRIMMABLE-BOUNDARY-START(60129851630),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309720814,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748674286,
        "f": 83886081
      },
      "n": "Boundingbox",
      "d": 309486,
      "h": 60129851630,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "boundingbox",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60129851630),
//--TRIMMABLE-BOUNDARY-START(180388935918),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669459182,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108412654,
        "f": 83886081
      },
      "n": "Lat",
      "d": 309486,
      "h": 180388935918,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "lat",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180388935918),
//--TRIMMABLE-BOUNDARY-START(188978870510),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849328366,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288281838,
        "f": 83886081
      },
      "n": "Lon",
      "d": 309486,
      "h": 188978870510,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "lon",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188978870510),
//--TRIMMABLE-BOUNDARY-START(68719786222),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489589998,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928543470,
        "f": 83886081
      },
      "n": "DisplayName",
      "d": 309486,
      "h": 68719786222,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "display_name",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719786222),
//--TRIMMABLE-BOUNDARY-START(64424818926),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899655406,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338608878,
        "f": 83886081
      },
      "n": "Class",
      "d": 309486,
      "h": 64424818926,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "class",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64424818926),
//--TRIMMABLE-BOUNDARY-START(313532922094),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799001326,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309237954798,
        "f": 83886081
      },
      "n": "Type",
      "d": 309486,
      "h": 313532922094,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "type",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(313532922094),
//--TRIMMABLE-BOUNDARY-START(176093968622),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079524590,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518478062,
        "f": 83886081
      },
      "n": "Importance",
      "d": 309486,
      "h": 176093968622,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "importance",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176093968622)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55834884334),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 309486,
      "h": 55834884334,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834884334)
  ],
  "h": 309486
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(309486)
        
        

        //--TRIMMABLE-BOUNDARY-START(243950)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoConfiguration`, ($self) => class GeocodeMapsCoConfiguration extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885145838)
            /*string*/ APIKey = null;
            //--TRIMMABLE-BOUNDARY-END(12885145838)
            
            //--TRIMMABLE-BOUNDARY-START(8590178542)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590178542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590178542)
            
            //--TRIMMABLE-BOUNDARY-START(8590178542)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590178542)
            
            static $h = 243950;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885145838),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475080430,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065015022,
        "f": 83886081
      },
      "n": "APIKey",
      "d": 243950,
      "h": 12885145838,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885145838)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590178542),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 243950,
      "h": 8590178542,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590178542)
  ],
  "h": 243950
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoConfiguration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(243950)
        
        

        //--TRIMMABLE-BOUNDARY-START(1095918)
        $asm.$cls(`$AutK.LCFCMG$1.GoogleCloudMapConfiguration`, ($self) => class GoogleCloudMapConfiguration extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885997806)
            /*string*/ APIKey = null;
            //--TRIMMABLE-BOUNDARY-END(12885997806)
            
            //--TRIMMABLE-BOUNDARY-START(8591030510)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591030510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591030510)
            
            //--TRIMMABLE-BOUNDARY-START(8591030510)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591030510)
            
            static $h = 1095918;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885997806),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475932398,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065866990,
        "f": 83886081
      },
      "n": "APIKey",
      "d": 1095918,
      "h": 12885997806,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885997806)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591030510),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1095918,
      "h": 8591030510,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591030510)
  ],
  "h": 1095918
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.Google.GoogleCloudMapConfiguration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}Google${separator}GoogleCloudMapConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1095918)
        
        

        //--TRIMMABLE-BOUNDARY-START(1816814)
        $asm.$cls(`$AutK.LCFCML.LocationIQDirectionDrivingLeg`, ($self) => class LocationIQDirectionDrivingLeg extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(124555868398)
            /*object[]*/ Steps = null;
            //--TRIMMABLE-BOUNDARY-END(124555868398)
            
            //--TRIMMABLE-BOUNDARY-START(128850835694)
            /*string*/ Summary = null;
            //--TRIMMABLE-BOUNDARY-END(128850835694)
            
            //--TRIMMABLE-BOUNDARY-START(133145802990)
            /*double*/ Weight = 0;
            //--TRIMMABLE-BOUNDARY-END(133145802990)
            
            //--TRIMMABLE-BOUNDARY-START(34361555182)
            /*double*/ Duration = 0;
            //--TRIMMABLE-BOUNDARY-END(34361555182)
            
            //--TRIMMABLE-BOUNDARY-START(30066587886)
            /*double*/ Distance = 0;
            //--TRIMMABLE-BOUNDARY-END(30066587886)
            
            //--TRIMMABLE-BOUNDARY-START(25771620590)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771620590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771620590)
            
            //--TRIMMABLE-BOUNDARY-START(25771620590)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25771620590)
            
            static $h = 1816814;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124555868398),
    {
      "p": $.$typeArray($.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131358958,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081031918,
        "f": 83886081
      },
      "n": "Steps",
      "d": 1816814,
      "h": 124555868398,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "steps",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124555868398),
//--TRIMMABLE-BOUNDARY-START(128850835694),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721293550,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670966510,
        "f": 83886081
      },
      "n": "Summary",
      "d": 1816814,
      "h": 128850835694,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "summary",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850835694),
//--TRIMMABLE-BOUNDARY-START(133145802990),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311228142,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260901102,
        "f": 83886081
      },
      "n": "Weight",
      "d": 1816814,
      "h": 133145802990,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "weight",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145802990),
//--TRIMMABLE-BOUNDARY-START(34361555182),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541424366,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491097326,
        "f": 83886081
      },
      "n": "Duration",
      "d": 1816814,
      "h": 34361555182,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "duration",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361555182),
//--TRIMMABLE-BOUNDARY-START(30066587886),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951489774,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901162734,
        "f": 83886081
      },
      "n": "Distance",
      "d": 1816814,
      "h": 30066587886,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "distance",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066587886)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771620590),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1816814,
      "h": 25771620590,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771620590)
  ],
  "h": 1816814
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingLeg`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQDirectionDrivingLeg`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1816814)
        
        

        //--TRIMMABLE-BOUNDARY-START(1620206)
        $asm.$cls(`$AutK.LCFCML.LocationIQ`, ($self) => class LocationIQ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42951293166)
            /*HttpClient*/ http = null;
            //--TRIMMABLE-BOUNDARY-END(42951293166)
            
            //--TRIMMABLE-BOUNDARY-START(51541227758)
            /*LocationIQRoutingDirection?*/ routing = null;
            //--TRIMMABLE-BOUNDARY-END(51541227758)
            
            //--TRIMMABLE-BOUNDARY-START(8591554798)
            $ctor$1(/*HttpClient*/ http, /*IOptions<LocationIQConfiguration>*/ configuration)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591554798);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.http = http;
                    if (configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Mapping$LocationIQ$LocationIQConfiguration$Value.APIKey === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("LocationIQ not configured");
                    }
                    this.Configuration = configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Mapping$LocationIQ$LocationIQConfiguration$Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591554798)
            
            //--TRIMMABLE-BOUNDARY-START(47246260462)
            /*HttpClient */ get Http()
            {
                return this.http;
            }
            //--TRIMMABLE-BOUNDARY-END(47246260462)
            
            //--TRIMMABLE-BOUNDARY-START(12886522094)
            /*LocationIQConfiguration*/ Configuration = null;
            //--TRIMMABLE-BOUNDARY-END(12886522094)
            
            //--TRIMMABLE-BOUNDARY-START(55836195054)
            /*LocationIQRoutingDirection */ get RoutingDirection()
            {
                return this.routing ??= new $.$AutK.LCFCML.LocationIQRoutingDirection().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(55836195054)
            
            static $h = 1620206;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246260462),
    {
      "p": 6488117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066391278,
        "f": 50331656
      },
      "n": "Http",
      "d": 1620206,
      "h": 47246260462,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(47246260462),
//--TRIMMABLE-BOUNDARY-START(12886522094),
    {
      "p": 1685742,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476456686,
        "f": 50331656
      },
      "n": "Configuration",
      "d": 1620206,
      "h": 12886522094,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(12886522094),
//--TRIMMABLE-BOUNDARY-START(55836195054),
    {
      "p": 2275566,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656325870,
        "f": 50331649
      },
      "n": "RoutingDirection",
      "d": 1620206,
      "h": 55836195054,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836195054)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951293166),
    {
      "t": 6488117,
      "n": "http",
      "d": 1620206,
      "h": 42951293166,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951293166),
//--TRIMMABLE-BOUNDARY-START(51541227758),
    {
      "t": 2275566,
      "n": "routing",
      "d": 1620206,
      "h": 51541227758,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51541227758)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591554798),
    {
      "p": [
        {
          "n": "http",
          "p": 6488117
        },
        {
          "n": "configuration",
          "p": $.$meo.MEO.IOptions$$($.$AutK.LCFCML.LocationIQConfiguration).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1620206,
      "h": 8591554798,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591554798)
  ],
  "h": 1620206
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQ`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQ`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1620206)
        
        

        //--TRIMMABLE-BOUNDARY-START(2210030)
        $asm.$cls(`$AutK.LCFCML.LocationIQDirectionDrivingWaypoint`, ($self) => class LocationIQDirectionDrivingWaypoint extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64426719470)
            /*string*/ Hint = null;
            //--TRIMMABLE-BOUNDARY-END(64426719470)
            
            //--TRIMMABLE-BOUNDARY-START(25772013806)
            /*double*/ Distance = 0;
            //--TRIMMABLE-BOUNDARY-END(25772013806)
            
            //--TRIMMABLE-BOUNDARY-START(73016654062)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(73016654062)
            
            //--TRIMMABLE-BOUNDARY-START(68721686766)
            /*double[]*/ Location = null;
            //--TRIMMABLE-BOUNDARY-END(68721686766)
            
            //--TRIMMABLE-BOUNDARY-START(21477046510)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477046510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477046510)
            
            //--TRIMMABLE-BOUNDARY-START(21477046510)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21477046510)
            
            static $h = 2210030;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64426719470),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951882990,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196523246,
        "f": 83886081
      },
      "n": "Hint",
      "d": 2210030,
      "h": 64426719470,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "hint",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64426719470),
//--TRIMMABLE-BOUNDARY-START(25772013806),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361948398,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81606588654,
        "f": 83886081
      },
      "n": "Distance",
      "d": 2210030,
      "h": 25772013806,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "distance",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25772013806),
//--TRIMMABLE-BOUNDARY-START(73016654062),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131752174,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107376392430,
        "f": 83886081
      },
      "n": "Name",
      "d": 2210030,
      "h": 73016654062,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "name",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016654062),
//--TRIMMABLE-BOUNDARY-START(68721686766),
    {
      "p": $.$typeArray($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541817582,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786457838,
        "f": 83886081
      },
      "n": "Location",
      "d": 2210030,
      "h": 68721686766,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "location",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68721686766)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477046510),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2210030,
      "h": 21477046510,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477046510)
  ],
  "h": 2210030
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingWaypoint`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQDirectionDrivingWaypoint`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2210030)
        
        

        //--TRIMMABLE-BOUNDARY-START(2144494)
        $asm.$cls(`$AutK.LCFCML.LocationIQDirectionDrivingRoute`, ($self) => class LocationIQDirectionDrivingRoute extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42951817454)
            /*LocationIQDirectionDrivingGeometry*/ Geometry = null;
            //--TRIMMABLE-BOUNDARY-END(42951817454)
            
            //--TRIMMABLE-BOUNDARY-START(98786392302)
            /*LocationIQDirectionDrivingLeg[]*/ Legs = null;
            //--TRIMMABLE-BOUNDARY-END(98786392302)
            
            //--TRIMMABLE-BOUNDARY-START(158915934446)
            /*string*/ WeightName = null;
            //--TRIMMABLE-BOUNDARY-END(158915934446)
            
            //--TRIMMABLE-BOUNDARY-START(154620967150)
            /*double*/ Weight = 0;
            //--TRIMMABLE-BOUNDARY-END(154620967150)
            
            //--TRIMMABLE-BOUNDARY-START(38656850158)
            /*double*/ Duration = 0;
            //--TRIMMABLE-BOUNDARY-END(38656850158)
            
            //--TRIMMABLE-BOUNDARY-START(34361882862)
            /*double*/ Distance = 0;
            //--TRIMMABLE-BOUNDARY-END(34361882862)
            
            //--TRIMMABLE-BOUNDARY-START(30066915566)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066915566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066915566)
            
            //--TRIMMABLE-BOUNDARY-START(30066915566)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30066915566)
            
            static $h = 2144494;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951817454),
    {
      "p": 1751278,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721621230,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124556196078,
        "f": 83886081
      },
      "n": "Geometry",
      "d": 2144494,
      "h": 42951817454,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "geometry",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951817454),
//--TRIMMABLE-BOUNDARY-START(98786392302),
    {
      "p": $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingLeg).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311555822,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133146130670,
        "f": 83886081
      },
      "n": "Legs",
      "d": 2144494,
      "h": 98786392302,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "legs",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98786392302),
//--TRIMMABLE-BOUNDARY-START(158915934446),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491425006,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325999854,
        "f": 83886081
      },
      "n": "WeightName",
      "d": 2144494,
      "h": 158915934446,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "weight_name",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158915934446),
//--TRIMMABLE-BOUNDARY-START(154620967150),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901490414,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141736065262,
        "f": 83886081
      },
      "n": "Weight",
      "d": 2144494,
      "h": 154620967150,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "weight",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620967150),
//--TRIMMABLE-BOUNDARY-START(38656850158),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131686638,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115966261486,
        "f": 83886081
      },
      "n": "Duration",
      "d": 2144494,
      "h": 38656850158,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "duration",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656850158),
//--TRIMMABLE-BOUNDARY-START(34361882862),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541752046,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107376326894,
        "f": 83886081
      },
      "n": "Distance",
      "d": 2144494,
      "h": 34361882862,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "distance",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361882862)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066915566),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2144494,
      "h": 30066915566,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066915566)
  ],
  "h": 2144494
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingRoute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQDirectionDrivingRoute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2144494)
        
        

        //--TRIMMABLE-BOUNDARY-START(1685742)
        $asm.$cls(`$AutK.LCFCML.LocationIQConfiguration`, ($self) => class LocationIQConfiguration extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886587630)
            /*string*/ APIKey = null;
            //--TRIMMABLE-BOUNDARY-END(12886587630)
            
            //--TRIMMABLE-BOUNDARY-START(8591620334)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591620334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591620334)
            
            //--TRIMMABLE-BOUNDARY-START(8591620334)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591620334)
            
            static $h = 1685742;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886587630),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476522222,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066456814,
        "f": 83886081
      },
      "n": "APIKey",
      "d": 1685742,
      "h": 12886587630,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886587630)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591620334),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1685742,
      "h": 8591620334,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591620334)
  ],
  "h": 1685742
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQConfiguration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1685742)
        
        

        //--TRIMMABLE-BOUNDARY-START(1161454)
        $asm.$cls(`$AutK.LCFCMG$1.GoogleMapGeocodeResponse`, ($self) => class GoogleMapGeocodeResponse extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360899822)
            /*GoogleMapGeocodeResult[]*/ Results = null;
            //--TRIMMABLE-BOUNDARY-END(34360899822)
            
            //--TRIMMABLE-BOUNDARY-START(55835736302)
            /*string*/ Status = null;
            //--TRIMMABLE-BOUNDARY-END(55835736302)
            
            //--TRIMMABLE-BOUNDARY-START(1489134)
            static $_GoogleMapGeocodeResult;
            static get GoogleMapGeocodeResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1489134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$AutK.LCFCMG$1.GoogleMapGeocodeResponse;
                return $cls.$_GoogleMapGeocodeResult ??= $asm.$ncls(`$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeResult`, ($self) => class GoogleMapGeocodeResult extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(30066260206)
                    /*GoogleMapGeocodeAddressComponent[]*/ AddressComponents = null;
                    //--TRIMMABLE-BOUNDARY-END(30066260206)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361227502)
                    /*string*/ FormattedAddress = null;
                    //--TRIMMABLE-BOUNDARY-END(34361227502)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656194798)
                    /*GoogleMapGeocodeGeometry*/ Geometry = null;
                    //--TRIMMABLE-BOUNDARY-END(38656194798)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900835054)
                    /*string*/ PlaceId = null;
                    //--TRIMMABLE-BOUNDARY-END(85900835054)
                    
                    //--TRIMMABLE-BOUNDARY-START(133145475310)
                    /*string[]*/ Types = null;
                    //--TRIMMABLE-BOUNDARY-END(133145475310)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771292910)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771292910);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771292910)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771292910)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771292910)
                    
                    static $h = 1489134;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066260206),
    {
      "p": $.$typeArray($.$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeAddressComponent).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246129390,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490769646,
        "f": 83886081
      },
      "n": "AddressComponents",
      "d": 1489134,
      "h": 30066260206,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "address_components",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066260206),
//--TRIMMABLE-BOUNDARY-START(34361227502),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836063982,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080704238,
        "f": 83886081
      },
      "n": "FormattedAddress",
      "d": 1489134,
      "h": 34361227502,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "formatted_address",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361227502),
//--TRIMMABLE-BOUNDARY-START(38656194798),
    {
      "p": 1358062,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425998574,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670638830,
        "f": 83886081
      },
      "n": "Geometry",
      "d": 1489134,
      "h": 38656194798,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "geometry",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656194798),
//--TRIMMABLE-BOUNDARY-START(85900835054),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015933166,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260573422,
        "f": 83886081
      },
      "n": "PlaceId",
      "d": 1489134,
      "h": 85900835054,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "place_id",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900835054),
//--TRIMMABLE-BOUNDARY-START(133145475310),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605867758,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850508014,
        "f": 83886081
      },
      "n": "Types",
      "d": 1489134,
      "h": 133145475310,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "types",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133145475310)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771292910),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1489134,
      "h": 25771292910,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771292910)
  ],
  "d": 1161454,
  "h": 1489134
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.Google.GoogleMapGeocodeResponse+GoogleMapGeocodeResult`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}Google${separator}GoogleMapGeocodeResponse${separator}GoogleMapGeocodeResult`; }
                }, $cls, ($v) => $cls.$_GoogleMapGeocodeResult = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1489134)
            
            //--TRIMMABLE-BOUNDARY-START(1226990)
            static $_GoogleMapGeocodeAddressComponent;
            static get GoogleMapGeocodeAddressComponent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1226990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$AutK.LCFCMG$1.GoogleMapGeocodeResponse;
                return $cls.$_GoogleMapGeocodeAddressComponent ??= $asm.$ncls(`$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeAddressComponent`, ($self) => class GoogleMapGeocodeAddressComponent extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(47245867246)
                    /*string*/ LongName = null;
                    //--TRIMMABLE-BOUNDARY-END(47245867246)
                    
                    //--TRIMMABLE-BOUNDARY-START(77310638318)
                    /*string*/ ShortName = null;
                    //--TRIMMABLE-BOUNDARY-END(77310638318)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605605614)
                    /*string[]*/ Types = null;
                    //--TRIMMABLE-BOUNDARY-END(81605605614)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181096174)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181096174);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181096174)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181096174)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181096174)
                    
                    static $h = 1226990;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245867246),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771030766,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835801838,
        "f": 83886081
      },
      "n": "LongName",
      "d": 1226990,
      "h": 47245867246,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "long_name",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245867246),
//--TRIMMABLE-BOUNDARY-START(77310638318),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360965358,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425736430,
        "f": 83886081
      },
      "n": "ShortName",
      "d": 1226990,
      "h": 77310638318,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "short_name",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310638318),
//--TRIMMABLE-BOUNDARY-START(81605605614),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950899950,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015671022,
        "f": 83886081
      },
      "n": "Types",
      "d": 1226990,
      "h": 81605605614,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "types",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605605614)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181096174),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1226990,
      "h": 17181096174,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181096174)
  ],
  "d": 1161454,
  "h": 1226990
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.Google.GoogleMapGeocodeResponse+GoogleMapGeocodeAddressComponent`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}Google${separator}GoogleMapGeocodeResponse${separator}GoogleMapGeocodeAddressComponent`; }
                }, $cls, ($v) => $cls.$_GoogleMapGeocodeAddressComponent = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1226990)
            
            //--TRIMMABLE-BOUNDARY-START(1358062)
            static $_GoogleMapGeocodeGeometry;
            static get GoogleMapGeocodeGeometry()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1358062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$AutK.LCFCMG$1.GoogleMapGeocodeResponse;
                return $cls.$_GoogleMapGeocodeGeometry ??= $asm.$ncls(`$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeGeometry`, ($self) => class GoogleMapGeocodeGeometry extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(25771161838)
                    /*GoogleMapGeocodeBounds*/ Bounds = null;
                    //--TRIMMABLE-BOUNDARY-END(25771161838)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425867502)
                    /*GoogleMapGeocodeLocation*/ Location = null;
                    //--TRIMMABLE-BOUNDARY-END(64425867502)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720834798)
                    /*string*/ LocationType = null;
                    //--TRIMMABLE-BOUNDARY-END(68720834798)
                    
                    //--TRIMMABLE-BOUNDARY-START(107375540462)
                    /*GoogleMapGeocodeBounds*/ Viewport = null;
                    //--TRIMMABLE-BOUNDARY-END(107375540462)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476194542)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476194542);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476194542)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476194542)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476194542)
                    
                    static $h = 1358062;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771161838),
    {
      "p": 1292526,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361096430,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310769390,
        "f": 83886081
      },
      "n": "Bounds",
      "d": 1358062,
      "h": 25771161838,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "bounds",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771161838),
//--TRIMMABLE-BOUNDARY-START(64425867502),
    {
      "p": 1423598,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951031022,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900703982,
        "f": 83886081
      },
      "n": "Location",
      "d": 1358062,
      "h": 64425867502,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "location",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425867502),
//--TRIMMABLE-BOUNDARY-START(68720834798),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540965614,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490638574,
        "f": 83886081
      },
      "n": "LocationType",
      "d": 1358062,
      "h": 68720834798,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "location_type",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720834798),
//--TRIMMABLE-BOUNDARY-START(107375540462),
    {
      "p": 1292526,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130900206,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080573166,
        "f": 83886081
      },
      "n": "Viewport",
      "d": 1358062,
      "h": 107375540462,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "viewport",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107375540462)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476194542),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1358062,
      "h": 21476194542,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476194542)
  ],
  "d": 1161454,
  "h": 1358062
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.Google.GoogleMapGeocodeResponse+GoogleMapGeocodeGeometry`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}Google${separator}GoogleMapGeocodeResponse${separator}GoogleMapGeocodeGeometry`; }
                }, $cls, ($v) => $cls.$_GoogleMapGeocodeGeometry = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1358062)
            
            //--TRIMMABLE-BOUNDARY-START(1292526)
            static $_GoogleMapGeocodeBounds;
            static get GoogleMapGeocodeBounds()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1292526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$AutK.LCFCMG$1.GoogleMapGeocodeResponse;
                return $cls.$_GoogleMapGeocodeBounds ??= $asm.$ncls(`$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeBounds`, ($self) => class GoogleMapGeocodeBounds extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(34361030894)
                    /*GoogleMapGeocodeLocation*/ Northeast = null;
                    //--TRIMMABLE-BOUNDARY-END(34361030894)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835867374)
                    /*GoogleMapGeocodeLocation*/ Southwest = null;
                    //--TRIMMABLE-BOUNDARY-END(55835867374)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886194414)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886194414);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886194414)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886194414)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886194414)
                    
                    static $h = 1292526;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361030894),
    {
      "p": 1423598,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476129006,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950965486,
        "f": 83886081
      },
      "n": "Northeast",
      "d": 1292526,
      "h": 34361030894,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "northeast",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361030894),
//--TRIMMABLE-BOUNDARY-START(55835867374),
    {
      "p": 1423598,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066063598,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540900078,
        "f": 83886081
      },
      "n": "Southwest",
      "d": 1292526,
      "h": 55835867374,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "southwest",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835867374)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886194414),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1292526,
      "h": 12886194414,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886194414)
  ],
  "d": 1161454,
  "h": 1292526
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.Google.GoogleMapGeocodeResponse+GoogleMapGeocodeBounds`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}Google${separator}GoogleMapGeocodeResponse${separator}GoogleMapGeocodeBounds`; }
                }, $cls, ($v) => $cls.$_GoogleMapGeocodeBounds = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1292526)
            
            //--TRIMMABLE-BOUNDARY-START(1423598)
            static $_GoogleMapGeocodeLocation;
            static get GoogleMapGeocodeLocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1423598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$AutK.LCFCMG$1.GoogleMapGeocodeResponse;
                return $cls.$_GoogleMapGeocodeLocation ??= $asm.$ncls(`$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeLocation`, ($self) => class GoogleMapGeocodeLocation extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(34361161966)
                    /*double*/ Lat = 0;
                    //--TRIMMABLE-BOUNDARY-END(34361161966)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656129262)
                    /*double*/ Lng = 0;
                    //--TRIMMABLE-BOUNDARY-END(38656129262)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886325486)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886325486);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886325486)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886325486)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886325486)
                    
                    static $h = 1423598;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361161966),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476260078,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246063854,
        "f": 83886081
      },
      "n": "Lat",
      "d": 1423598,
      "h": 34361161966,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "lat",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361161966),
//--TRIMMABLE-BOUNDARY-START(38656129262),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066194670,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835998446,
        "f": 83886081
      },
      "n": "Lng",
      "d": 1423598,
      "h": 38656129262,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "lng",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656129262)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886325486),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1423598,
      "h": 12886325486,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886325486)
  ],
  "d": 1161454,
  "h": 1423598
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.Google.GoogleMapGeocodeResponse+GoogleMapGeocodeLocation`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}Google${separator}GoogleMapGeocodeResponse${separator}GoogleMapGeocodeLocation`; }
                }, $cls, ($v) => $cls.$_GoogleMapGeocodeLocation = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1423598)
            
            //--TRIMMABLE-BOUNDARY-START(12886063342)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886063342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886063342)
            
            //--TRIMMABLE-BOUNDARY-START(12886063342)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886063342)
            
            static $h = 1161454;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360899822),
    {
      "p": $.$typeArray($.$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeResult).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475997934,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950834414,
        "f": 83886081
      },
      "n": "Results",
      "d": 1161454,
      "h": 34360899822,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "results",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360899822),
//--TRIMMABLE-BOUNDARY-START(55835736302),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065932526,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540769006,
        "f": 83886081
      },
      "n": "Status",
      "d": 1161454,
      "h": 55835736302,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "status",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835736302)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886063342),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1161454,
      "h": 12886063342,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886063342)
  ],
  "h": 1161454
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeResult, $.$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeAddressComponent, $.$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeGeometry, $.$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeBounds, $.$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeLocation ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.Google.GoogleMapGeocodeResponse`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}Google${separator}GoogleMapGeocodeResponse`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1161454)
        
        

        //--TRIMMABLE-BOUNDARY-START(1882350)
        $asm.$cls(`$AutK.LCFCML.LocationIQDirectionDrivingModel`, ($self) => class LocationIQDirectionDrivingModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476718830)
            /*string*/ Code = null;
            //--TRIMMABLE-BOUNDARY-END(21476718830)
            
            //--TRIMMABLE-BOUNDARY-START(51541489902)
            /*LocationIQDirectionDrivingRoute[]*/ Routes = null;
            //--TRIMMABLE-BOUNDARY-END(51541489902)
            
            //--TRIMMABLE-BOUNDARY-START(81606260974)
            /*LocationIQDirectionDrivingWaypoint[]*/ Waypoints = null;
            //--TRIMMABLE-BOUNDARY-END(81606260974)
            
            //--TRIMMABLE-BOUNDARY-START(17181751534)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181751534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181751534)
            
            //--TRIMMABLE-BOUNDARY-START(17181751534)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181751534)
            
            static $h = 1882350;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476718830),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066653422,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60131424494,
        "f": 83886081
      },
      "n": "Code",
      "d": 1882350,
      "h": 21476718830,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "code",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476718830),
//--TRIMMABLE-BOUNDARY-START(51541489902),
    {
      "p": $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingRoute).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656588014,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68721359086,
        "f": 83886081
      },
      "n": "Routes",
      "d": 1882350,
      "h": 51541489902,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "routes",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541489902),
//--TRIMMABLE-BOUNDARY-START(81606260974),
    {
      "p": $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246522606,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77311293678,
        "f": 83886081
      },
      "n": "Waypoints",
      "d": 1882350,
      "h": 81606260974,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "waypoints",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81606260974)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181751534),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1882350,
      "h": 17181751534,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181751534)
  ],
  "h": 1882350
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQDirectionDrivingModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1882350)
        
        

        //--TRIMMABLE-BOUNDARY-START(2275566)
        $asm.$cls(`$AutK.LCFCML.LocationIQRoutingDirection`, ($self) => class LocationIQRoutingDirection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887177454)
            /*LocationIQ*/ iq = null;
            //--TRIMMABLE-BOUNDARY-END(12887177454)
            
            //--TRIMMABLE-BOUNDARY-START(4297242862)
            $ctor$1(/*LocationIQ*/ iq)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297242862);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.iq = iq;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297242862)
            
            //--TRIMMABLE-BOUNDARY-START(8592210158)
            /*Task<LocationIQDirectionDrivingModel?> */ GetDirection(/*GeoLocation*/ start, /*GeoLocation*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592210158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snhj.SNHJ.HttpClientJsonExtensions.GetFromJsonAsync$8($.$AutK.LCFCML.LocationIQDirectionDrivingModel, this.iq.Http, `https://us1.locationiq.com/v1/directions/driving/${$.$strNN(start.Longitude)},${$.$strNN(start.Latitude)};${$.$strNN(end.Longitude)},${$.$strNN(end.Latitude)}?key=${$.$strNN(this.iq.Configuration.APIKey)}&overview=full&geometries=geojson`, new $.$$.ST$1.CancellationToken());
            }
            //--TRIMMABLE-BOUNDARY-END(8592210158)
            
            static $h = 2275566;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592210158),
    {
      "r": $.$$.STT.Task$$($.$AutK.LCFCML.LocationIQDirectionDrivingModel).$h,
      "p": [
        {
          "n": "start",
          "p": 13928790
        },
        {
          "n": "end",
          "p": 13928790
        }
      ],
      "n": "GetDirection",
      "d": 2275566,
      "h": 8592210158,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592210158)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887177454),
    {
      "t": 1620206,
      "n": "iq",
      "d": 2275566,
      "h": 12887177454,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887177454)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297242862),
    {
      "p": [
        {
          "n": "iq",
          "p": 1620206
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2275566,
      "h": 4297242862,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297242862)
  ],
  "h": 2275566
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQRoutingDirection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQRoutingDirection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2275566)
        
        

        //--TRIMMABLE-BOUNDARY-START(2406638)
        $asm.$cls(`$AutK.LCFCM.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297373934)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297373934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptorBuilder.Register();
                $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptorBuilder.Register();
                $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptorBuilder.Register();
                $.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297373934)
            
            static $h = 2406638;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297373934),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2406638,
      "h": 4297373934,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297373934)
  ],
  "h": 2406638
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2406638)
        
        

        //--TRIMMABLE-BOUNDARY-START(375022)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoModelCustomAttributesProvider`, ($self) => class GeocodeMapsCoModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295342318)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295342318)
            
            //--TRIMMABLE-BOUNDARY-START(8590309614)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590309614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AutK.LCFCMG.GeocodeMapsCoModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(12, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("PlaceId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("place_id");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Licence", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("licence");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PoweredBy", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t5 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("powered_by");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("OsmType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t6 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$3("osm_type");
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("OsmId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t7 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$3("osm_id");
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Boundingbox", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t8 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$3("boundingbox");
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Lat", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t9 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$3("lat");
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Lon", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t10 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$3("lon");
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DisplayName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t11 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$3("display_name");
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Class", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t12 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$3("class");
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Type", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t13 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$3("type");
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Importance", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t14 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$3("importance");
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AutK.LCFCMG.GeocodeMapsCoModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $xOINWi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":375022,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $sFFbud ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":375022,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590309614)
            
            static $h = 375022;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590309614),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 375022,
      "h": 8590309614,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590309614)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295342318),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 375022,
      "h": 4295342318,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295342318)
  ],
  "h": 375022
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(375022)
        
        

        //--TRIMMABLE-BOUNDARY-START(112878)
        $asm.$cls(`$AutK.LCFCM.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295080174)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295080174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AutK.LCFCMG.GeocodeMapsCoModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelCustomAttributesProvider, $.$AutK.LCFCMG.GeocodeMapsCoModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelCustomAttributesProvider, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelCustomAttributesProvider, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AutK.LCFCML.LocationIQDirectionDrivingModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AutK.LCFCML.LocationIQDirectionDrivingModelCustomAttributesProvider, $.$AutK.LCFCML.LocationIQDirectionDrivingModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295080174)
            
            static $h = 112878;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295080174),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 112878,
      "h": 4295080174,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295080174)
  ],
  "h": 112878
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(112878)
        
        

        //--TRIMMABLE-BOUNDARY-START(637166)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelCustomAttributesProvider`, ($self) => class GeocodeMapsCoReverseGeocodeMapsAddressModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295604462)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295604462)
            
            //--TRIMMABLE-BOUNDARY-START(8590571758)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590571758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(7, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Road", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("road");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Suburb", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("suburb");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("County", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t5 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("county");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("State", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t6 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$3("state");
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Postcode", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t7 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$3("postcode");
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Country", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t8 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$3("country");
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CountryCode", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t9 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$3("country_code");
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $IryIsj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":637166,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $YJbOhb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":637166,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590571758)
            
            static $h = 637166;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590571758),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 637166,
      "h": 8590571758,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590571758)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295604462),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 637166,
      "h": 4295604462,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295604462)
  ],
  "h": 637166
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoReverseGeocodeMapsAddressModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(637166)
        
        

        //--TRIMMABLE-BOUNDARY-START(768238)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptorBuilder`, ($self) => class GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590702830)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590702830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor()
                        const $t1 = $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $mQAzye ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":768238,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590702830)
            
            //--TRIMMABLE-BOUNDARY-START(4295735534)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295735534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295735534)
            
            //--TRIMMABLE-BOUNDARY-START(4295735534)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295735534)
            
            static $h = 768238;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590702830),
    {
      "r": 65537,
      "n": "Register",
      "d": 768238,
      "h": 8590702830,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590702830)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295735534),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 768238,
      "h": 4295735534,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295735534)
  ],
  "h": 768238
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(768238)
        
        

        //--TRIMMABLE-BOUNDARY-START(2078958)
        $asm.$cls(`$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptorBuilder`, ($self) => class LocationIQDirectionDrivingModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592013550)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592013550);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor()
                        const $t1 = $.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CyTLUg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2078958,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AutK.LCFCML.LocationIQDirectionDrivingModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592013550)
            
            //--TRIMMABLE-BOUNDARY-START(4297046254)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297046254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297046254)
            
            //--TRIMMABLE-BOUNDARY-START(4297046254)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297046254)
            
            static $h = 2078958;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592013550),
    {
      "r": 65537,
      "n": "Register",
      "d": 2078958,
      "h": 8592013550,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592013550)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297046254),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2078958,
      "h": 4297046254,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297046254)
  ],
  "h": 2078958
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQDirectionDrivingModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2078958)
        
        

        //--TRIMMABLE-BOUNDARY-START(1947886)
        $asm.$cls(`$AutK.LCFCML.LocationIQDirectionDrivingModelCustomAttributesProvider`, ($self) => class LocationIQDirectionDrivingModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296915182)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296915182)
            
            //--TRIMMABLE-BOUNDARY-START(8591882478)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591882478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AutK.LCFCML.LocationIQDirectionDrivingModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Code", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("code");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Routes", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("routes");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Waypoints", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t5 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("waypoints");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AutK.LCFCML.LocationIQDirectionDrivingModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $KlGRbg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1947886,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $MDzlIe ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1947886,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591882478)
            
            static $h = 1947886;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591882478),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1947886,
      "h": 8591882478,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591882478)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296915182),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1947886,
      "h": 4296915182,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296915182)
  ],
  "h": 1947886
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQDirectionDrivingModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1947886)
        
        

        //--TRIMMABLE-BOUNDARY-START(506094)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptorBuilder`, ($self) => class GeocodeMapsCoModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590440686)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590440686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor()
                        const $t1 = $.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HUIrrd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":506094,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AutK.LCFCMG.GeocodeMapsCoModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590440686)
            
            //--TRIMMABLE-BOUNDARY-START(4295473390)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295473390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295473390)
            
            //--TRIMMABLE-BOUNDARY-START(4295473390)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295473390)
            
            static $h = 506094;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590440686),
    {
      "r": 65537,
      "n": "Register",
      "d": 506094,
      "h": 8590440686,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590440686)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295473390),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 506094,
      "h": 4295473390,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295473390)
  ],
  "h": 506094
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(506094)
        
        

        //--TRIMMABLE-BOUNDARY-START(1030382)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptorBuilder`, ($self) => class GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590964974)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590964974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor()
                        const $t1 = $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $qhpPTj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1030382,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590964974)
            
            //--TRIMMABLE-BOUNDARY-START(4295997678)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295997678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295997678)
            
            //--TRIMMABLE-BOUNDARY-START(4295997678)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295997678)
            
            static $h = 1030382;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590964974),
    {
      "r": 65537,
      "n": "Register",
      "d": 1030382,
      "h": 8590964974,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590964974)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295997678),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1030382,
      "h": 4295997678,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295997678)
  ],
  "h": 1030382
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1030382)
        
        

        //--TRIMMABLE-BOUNDARY-START(178414)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCo`, ($self) => class GeocodeMapsCo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180047598)
            /*HttpClient*/ http = null;
            //--TRIMMABLE-BOUNDARY-END(17180047598)
            
            //--TRIMMABLE-BOUNDARY-START(21475014894)
            /*DateTime*/ lastCall;
            //--TRIMMABLE-BOUNDARY-END(21475014894)
            
            //--TRIMMABLE-BOUNDARY-START(8590113006)
            /*GeocodeMapsCoConfiguration*/ configuration = null;
            //--TRIMMABLE-BOUNDARY-END(8590113006)
            
            //--TRIMMABLE-BOUNDARY-START(4295145710)
            $ctor$1(/*HttpClient*/ http, /*IOptions<GeocodeMapsCoConfiguration>*/ configuration)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295145710);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.http = http;
                    this.configuration = $.$firstOf(configuration.MEO$IOptions$LivingThing$Core$Frameworks$Common$Mapping$GeocodeMaps$GeocodeMapsCoConfiguration$Value, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("GeocodeMapsCo not configured") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295145710)
            
            //--TRIMMABLE-BOUNDARY-START(30064949486)
            /*int */ ThorttleCall(/*int*/ periodMs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064949486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let now = $.$$.S.DateTime.UtcNow;
                /*var*/ let elapsed = $.$$.S.DateTime.op_Subtraction$1(now, this.lastCall);
                this.lastCall = now;
                if ($.$$.S.TimeSpan.op_GreaterThan(elapsed, $.$$.S.TimeSpan.FromMilliseconds$2(BigInt(periodMs))))
                {
                    return 0;
                }
                return $.$cast((($.$$.S.TimeSpan.op_Subtraction($.$$.S.TimeSpan.FromSeconds$2(BigInt(periodMs)), elapsed)).TotalMilliseconds), $.$$.S.Int32);
            }
            //--TRIMMABLE-BOUNDARY-END(30064949486)
            
            //--TRIMMABLE-BOUNDARY-START(12885080302)
            /*Task<IEnumerable<GeoLocation>> *//*async*/  Geocode(/*string*/ address)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation)), $.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885080302);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = $.$$.STT.Task.Delay$1(this.ThorttleCall(1000)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*var*/ let locations = ($t2 = $.$snhj.SNHJ.HttpClientJsonExtensions.GetFromJsonAsync$8($.$$.SCG.IEnumerable$$($.$AutK.LCFCMG.GeocodeMapsCoModel), this.http, `https://geocode.maps.co/search?q=${$.$strNN(address)}&api_key=${$.$strNN(this.configuration.APIKey)}`, new $.$$.ST$1.CancellationToken()), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Select$1($.$AutK.LCFCMG.GeocodeMapsCoModel, $.$fPer.LCFCDG.GeoLocation, locations, new ($.$$.S.Func$$$($.$AutK.LCFCMG.GeocodeMapsCoModel, $.$fPer.LCFCDG.GeoLocation))().$ctor(this,  (/*l*/ l) =>
                    {
                        return (() =>
                        {
                            //new $.$fPer.LCFCDG.GeoLocation()
                            const $t3 = $.$fPer.LCFCDG.GeoLocation;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            $i3.Latitude = $.$$.S.Double.Parse$7(l.Lat);
                            $i3.Longitude = $.$$.S.Double.Parse$7(l.Lon);
                            $i3.Address = l.DisplayName;
                            return $i3;
                        })();
                    }, $OKPpij ??= {"r":13928790,"p":[{"n":"l","p":309486}],"n":"","d":178414,"h":0,"f":17825794})));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885080302)
            
            //--TRIMMABLE-BOUNDARY-START(25769982190)
            /*Task<string?> *//*async*/  ReverseGeocode(/*GeoLocation*/ location)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.String), $.$$.S.String, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769982190);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = $.$$.STT.Task.Delay$1(this.ThorttleCall(1000)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    /*var*/ let address = ($t5 = $.$snhj.SNHJ.HttpClientJsonExtensions.GetFromJsonAsync$8($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel, this.http, `https://geocode.maps.co/reverse?lat=${$.$strNN(location.Latitude)}&lon=${$.$strNN(location.Longitude)}&api_key=${$.$strNN(this.configuration.APIKey)}`, new $.$$.ST$1.CancellationToken()), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, address.DisplayName);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25769982190)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475014894)
                this.lastCall = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(21475014894)
                
            }
            static $h = 178414;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064949486),
    {
      "r": 655361,
      "p": [
        {
          "n": "periodMs",
          "p": 655361,
          "f": 65,
          "v": 1000
        }
      ],
      "n": "ThorttleCall",
      "d": 178414,
      "h": 30064949486,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30064949486),
//--TRIMMABLE-BOUNDARY-START(12885080302),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation)).$h,
      "p": [
        {
          "n": "address",
          "p": 1310721
        }
      ],
      "n": "Geocode",
      "d": 178414,
      "h": 12885080302,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12885080302),
//--TRIMMABLE-BOUNDARY-START(25769982190),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "p": [
        {
          "n": "location",
          "p": 13928790
        }
      ],
      "n": "ReverseGeocode",
      "d": 178414,
      "h": 25769982190,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25769982190)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180047598),
    {
      "t": 6488117,
      "n": "http",
      "d": 178414,
      "h": 17180047598,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180047598),
//--TRIMMABLE-BOUNDARY-START(21475014894),
    {
      "t": 65994753,
      "n": "lastCall",
      "d": 178414,
      "h": 21475014894,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475014894),
//--TRIMMABLE-BOUNDARY-START(8590113006),
    {
      "t": 243950,
      "n": "configuration",
      "d": 178414,
      "h": 8590113006,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590113006)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295145710),
    {
      "p": [
        {
          "n": "http",
          "p": 6488117
        },
        {
          "n": "configuration",
          "p": $.$meo.MEO.IOptions$$($.$AutK.LCFCMG.GeocodeMapsCoConfiguration).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 178414,
      "h": 4295145710,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295145710)
  ],
  "h": 178414
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(178414)
        
        

        //--TRIMMABLE-BOUNDARY-START(899310)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelCustomAttributesProvider`, ($self) => class GeocodeMapsCoReverseGeocodeMapsModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295866606)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295866606)
            
            //--TRIMMABLE-BOUNDARY-START(8590833902)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590833902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(10, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("PlaceId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("place_id");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Licence", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("licence");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("PoweredBy", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t5 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("powered_by");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("OsmType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t6 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$3("osm_type");
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("OsmId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t7 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$3("osm_id");
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Lat", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t8 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$3("lat");
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Lon", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t9 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$3("lon");
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("DisplayName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t10 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$3("display_name");
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Address", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t11 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$3("address");
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Boundingbox", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t12 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$3("boundingbox");
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $uLoCAi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":899310,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $IlLRvk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":899310,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590833902)
            
            static $h = 899310;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590833902),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 899310,
      "h": 8590833902,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590833902)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295866606),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 899310,
      "h": 4295866606,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295866606)
  ],
  "h": 899310
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoReverseGeocodeMapsModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(899310)
        
        

        //--TRIMMABLE-BOUNDARY-START(2341102)
        $asm.$cls(`$AutK.LCFCM.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592275694)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592275694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$AutK.LCFCML.LocationIQ, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$AutK.LCFCMG.GeocodeMapsCo, services);
                if (options.Runtime !== 2/*RuntimeType.MobileApp*/)
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCS$3.ILocationRouteProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$AutK.LCFCM.LocationGeocoder, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCS$3.ILocationRouteProvider))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$AutK.LCFCM.LocationGeocoder, x);
                    }, $RmWZBc ??= {"r":61507926,"p":[{"n":"x","p":327718}],"n":"","d":2341102,"h":0,"f":17825794}));
                    if (options.Runtime !== 4/*RuntimeType.WasmMobileApp*/)
                    {
                        $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCS$3.ILocationGeocoder, services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCS$3.ILocationGeocoder))().$ctor(this,  (/**/ x) =>
                        {
                            return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$AutK.LCFCM.LocationGeocoder, x);
                        }, $JUUwoh ??= {"r":61376854,"p":[{"n":"x","p":327718}],"n":"","d":2341102,"h":0,"f":17825794}));
                    }
                }
                $.$AutK.LCFCM.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$AutK.LCFCM.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592275694)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$AutK.LCFCM.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297308398)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297308398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297308398)
            
            //--TRIMMABLE-BOUNDARY-START(4297308398)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297308398)
            
            static $h = 2341102;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592275694),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2341102,
      "h": 8592275694,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592275694)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297308398),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2341102,
      "h": 4297308398,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297308398)
  ],
  "h": 2341102
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2341102)
        
        

        //--TRIMMABLE-BOUNDARY-START(1554670)
        $asm.$cls(`$AutK.LCFCM.LocationGeocoder`, ($self) => class LocationGeocoder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476391150)
            /*HttpClient*/ http = null;
            //--TRIMMABLE-BOUNDARY-END(21476391150)
            
            //--TRIMMABLE-BOUNDARY-START(12886456558)
            /*GeocodeMapsCo*/ geocodemaps = null;
            //--TRIMMABLE-BOUNDARY-END(12886456558)
            
            //--TRIMMABLE-BOUNDARY-START(25771358446)
            /*LocationIQ.LocationIQ*/ locationIQ = null;
            //--TRIMMABLE-BOUNDARY-END(25771358446)
            
            //--TRIMMABLE-BOUNDARY-START(17181423854)
            /*GoogleCloudMapConfiguration*/ googleCloudConfig = null;
            //--TRIMMABLE-BOUNDARY-END(17181423854)
            
            //--TRIMMABLE-BOUNDARY-START(4296521966)
            $ctor$1(/*HttpClient*/ http, /*GeocodeMapsCo*/ geocodemaps, /*LocationIQ.LocationIQ*/ locationIQ, /*IOptions<GoogleCloudMapConfiguration>*/ googleConfig)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296521966);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.http = http;
                    this.geocodemaps = geocodemaps;
                    this.locationIQ = locationIQ;
                    this.googleCloudConfig = googleConfig.MEO$IOptions$LivingThing$Core$Frameworks$Common$Mapping$Google$GoogleCloudMapConfiguration$Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296521966)
            
            //--TRIMMABLE-BOUNDARY-START(8591489262)
            /*Task<IEnumerable<GeoLocation>> *//*async*/  Geocode(/*string*/ address)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation)), $.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591489262);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let response = ($t1 = $.$snhj.SNHJ.HttpClientJsonExtensions.GetFromJsonAsync$8($.$AutK.LCFCMG$1.GoogleMapGeocodeResponse, this.http, `https://maps.googleapis.com/maps/api/geocode/json?key=${$.$strNN(this.googleCloudConfig.APIKey)}&address=${$.$strNN($.$swh.SW.HttpUtility.UrlEncode$3(address))}`, new $.$$.ST$1.CancellationToken()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if ((response?.Status ?? null) === "OK")
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Select$1($.$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeResult, $.$fPer.LCFCDG.GeoLocation, response.Results, new ($.$$.S.Func$$$($.$AutK.LCFCMG$1.GoogleMapGeocodeResponse.GoogleMapGeocodeResult, $.$fPer.LCFCDG.GeoLocation))().$ctor(this,  (/**/ r) =>
                        {
                            return (() =>
                            {
                                //new $.$fPer.LCFCDG.GeoLocation()
                                const $t2 = $.$fPer.LCFCDG.GeoLocation;
                                const $i2 = new $t2();
                                $i2.$ctor$2();
                                $i2.Latitude = r.Geometry.Location.Lat;
                                $i2.Longitude = r.Geometry.Location.Lng;
                                $i2.Address = r.FormattedAddress;
                                return $i2;
                            })();
                        }, $oTQEDb ??= {"r":13928790,"p":[{"n":"r","p":1489134}],"n":"","d":1554670,"h":0,"f":17825794})));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = this.geocodemaps.Geocode(address), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8591489262)
            
            //--TRIMMABLE-BOUNDARY-START(30066325742)
            /*Task<string?> */ ReverseGeocode(/*GeoLocation*/ location)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066325742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.geocodemaps.ReverseGeocode(location);
            }
            //--TRIMMABLE-BOUNDARY-END(30066325742)
            
            //--TRIMMABLE-BOUNDARY-START(34361293038)
            /*Task<GeoLocationRoute> *//*async*/  RouteByRoad(/*GeoLocation*/ start, /*GeoLocation*/ end)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFCDG.GeoLocationRoute), $.$fPer.LCFCDG.GeoLocationRoute, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361293038);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let direction = ($t4 = this.locationIQ.RoutingDirection.GetDirection(start, end), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    /*LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModel?*/ let __ca1__;
                    /*string*/ let __ca2__;
                    if ((__ca1__ = direction) !== null ? ((__ca2__ = __ca1__.Code) !== null ? $.$$.S.String.Equals$2.call(__ca2__, "ok", 3/*StringComparison.InvariantCultureIgnoreCase*/) : false) : false)
                    {
                        /*LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingRoute[]*/ let __ca3__;
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$fPer.LCFCDG.GeoLocationRoute()
                            const $t5 = $.$fPer.LCFCDG.GeoLocationRoute;
                            const $i5 = new $t5();
                            $i5.$ctor$1();
                            $i5.Geometries = ((__ca3__ = direction.Routes) !== null ? $.$sl.SL.Enumerable.Select$1($.$typeArray($.$$.S.Double), $.$fPer.LCFCDG.GeoLocation, $.$$.System.Array.$ReadT1.call(__ca3__, 0).Geometry.Coordinates, new ($.$$.S.Func$$$($.$typeArray($.$$.S.Double), $.$fPer.LCFCDG.GeoLocation))().$ctor(this,  (/*c*/ c) =>
                            {
                                return (() =>
                                {
                                    //new $.$fPer.LCFCDG.GeoLocation()
                                    const $t6 = $.$fPer.LCFCDG.GeoLocation;
                                    const $i6 = new $t6();
                                    $i6.$ctor$2();
                                    $i6.Longitude = $.$$.System.Array.$ReadT1.call(c, 0);
                                    $i6.Latitude = $.$$.System.Array.$ReadT1.call(c, 1);
                                    return $i6;
                                })();
                            }, $CHYNlh ??= {"r":13928790,"p":[{"n":"c","p":$.$typeArray($.$$.S.Double).$h}],"n":"","d":1554670,"h":0,"f":17825794})) : null);
                            $i5.Distance = new $.$fPer.LCFCDM.Length().$ctor$3((direction.Routes?.[0].Distance ?? null) ?? 0, 1/*LengthUnitTypes.m*/);
                            return $i5;
                        })());
                    }
                    throw new $.$$.S.Exception().$ctor$4(`LocationIQ: Failed with code \"${$.$strNN((direction?.Code ?? null))}\"`);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34361293038)
            
            //--TRIMMABLE-BOUNDARY-START(8651311446)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.ILocationGeocoder.ReverseGeocode(LivingThing.Core.Frameworks.Common.Data.Geographic.GeoLocation)
            LCFCS$3$ILocationGeocoder$ReverseGeocode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8651311446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReverseGeocode(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8651311446)
            
            //--TRIMMABLE-BOUNDARY-START(4356344150)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.ILocationGeocoder.Geocode(string)
            LCFCS$3$ILocationGeocoder$Geocode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356344150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Geocode(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356344150)
            
            //--TRIMMABLE-BOUNDARY-START(4356475222)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.ILocationRouteProvider.RouteByRoad(LivingThing.Core.Frameworks.Common.Data.Geographic.GeoLocation, LivingThing.Core.Frameworks.Common.Data.Geographic.GeoLocation)
            LCFCS$3$ILocationRouteProvider$RouteByRoad()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356475222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RouteByRoad(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356475222)
            
            static $h = 1554670;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591489262),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation)).$h,
      "p": [
        {
          "n": "address",
          "p": 1310721
        }
      ],
      "n": "Geocode",
      "d": 1554670,
      "h": 8591489262,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(8591489262),
//--TRIMMABLE-BOUNDARY-START(30066325742),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "p": [
        {
          "n": "location",
          "p": 13928790
        }
      ],
      "n": "ReverseGeocode",
      "d": 1554670,
      "h": 30066325742,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30066325742),
//--TRIMMABLE-BOUNDARY-START(34361293038),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCDG.GeoLocationRoute).$h,
      "p": [
        {
          "n": "start",
          "p": 13928790
        },
        {
          "n": "end",
          "p": 13928790
        }
      ],
      "n": "RouteByRoad",
      "d": 1554670,
      "h": 34361293038,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34361293038)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476391150),
    {
      "t": 6488117,
      "n": "http",
      "d": 1554670,
      "h": 21476391150,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476391150),
//--TRIMMABLE-BOUNDARY-START(12886456558),
    {
      "t": 178414,
      "n": "geocodemaps",
      "d": 1554670,
      "h": 12886456558,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886456558),
//--TRIMMABLE-BOUNDARY-START(25771358446),
    {
      "t": 1620206,
      "n": "locationIQ",
      "d": 1554670,
      "h": 25771358446,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771358446),
//--TRIMMABLE-BOUNDARY-START(17181423854),
    {
      "t": 1095918,
      "n": "googleCloudConfig",
      "d": 1554670,
      "h": 17181423854,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181423854)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296521966),
    {
      "p": [
        {
          "n": "http",
          "p": 6488117
        },
        {
          "n": "geocodemaps",
          "p": 178414
        },
        {
          "n": "locationIQ",
          "p": 1620206
        },
        {
          "n": "googleConfig",
          "p": $.$meo.MEO.IOptions$$($.$AutK.LCFCMG$1.GoogleCloudMapConfiguration).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1554670,
      "h": 4296521966,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296521966)
  ],
  "h": 1554670
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.ILocationGeocoder, $.$fPer.LCFCS$3.ILocationRouteProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationGeocoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationGeocoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1554670)
        
        

        //--TRIMMABLE-BOUNDARY-START(702702)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor`, ($self) => class GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295669998)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295669998);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor.GenerateProperties($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel, this, factory);
                    }, $CfQnog ??= {"r":65537,"n":"","d":702702,"h":0,"f":17825794}), 0, "GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Mapping\\GeocodeMaps_GeocodeMapsCoReverseGeocodeMapsAddressModel_LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptorBuilder.g.cs", "GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295669998)
            
            //--TRIMMABLE-BOUNDARY-START(12885604590)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885604590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Road"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel.$type, $.$discardRef(), "Road", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Road")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Road";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel)).Road);
                        }, $DiXCci ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":702702,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Road = value.AsReference($.$$.S.String);
                        }, $wHBLEd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":702702,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Suburb"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel.$type, $.$discardRef(), "Suburb", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Suburb")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Suburb";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel)).Suburb);
                        }, $dXRfEd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":702702,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Suburb = value.AsReference($.$$.S.String);
                        }, $VACMgj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":702702,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("County"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel.$type, $.$discardRef(), "County", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("County")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "County";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel)).County);
                        }, $fdanMc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":702702,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.County = value.AsReference($.$$.S.String);
                        }, $IBiORg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":702702,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "State";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel)).State);
                        }, $hXCtya ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":702702,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.State = value.AsReference($.$$.S.String);
                        }, $RfQIMg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":702702,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Postcode"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel.$type, $.$discardRef(), "Postcode", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Postcode")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Postcode";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel)).Postcode);
                        }, $QGDvKc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":702702,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Postcode = value.AsReference($.$$.S.String);
                        }, $NrSoQc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":702702,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Country"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel.$type, $.$discardRef(), "Country", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Country")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Country";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel)).Country);
                        }, $ZCUoRd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":702702,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Country = value.AsReference($.$$.S.String);
                        }, $JhPkGc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":702702,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CountryCode"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel.$type, $.$discardRef(), "CountryCode", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CountryCode")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "CountryCode";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel)).CountryCode);
                        }, $JEAAUf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":702702,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CountryCode = value.AsReference($.$$.S.String);
                        }, $fqhcnl ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":702702,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885604590)
            
            //--TRIMMABLE-BOUNDARY-START(17180571886)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180571886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Road = _target.Road;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Road"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Road, ($v) => _Road = $v, $.$$.S.String)))
                    {
                        _target.Road = _Road;
                    }
                }
                {
                    /*var*/ let _Suburb = _target.Suburb;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Suburb"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Suburb, ($v) => _Suburb = $v, $.$$.S.String)))
                    {
                        _target.Suburb = _Suburb;
                    }
                }
                {
                    /*var*/ let _County = _target.County;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("County"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _County, ($v) => _County = $v, $.$$.S.String)))
                    {
                        _target.County = _County;
                    }
                }
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _State, ($v) => _State = $v, $.$$.S.String)))
                    {
                        _target.State = _State;
                    }
                }
                {
                    /*var*/ let _Postcode = _target.Postcode;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Postcode"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Postcode, ($v) => _Postcode = $v, $.$$.S.String)))
                    {
                        _target.Postcode = _Postcode;
                    }
                }
                {
                    /*var*/ let _Country = _target.Country;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Country"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Country, ($v) => _Country = $v, $.$$.S.String)))
                    {
                        _target.Country = _Country;
                    }
                }
                {
                    /*var*/ let _CountryCode = _target.CountryCode;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CountryCode"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _CountryCode, ($v) => _CountryCode = $v, $.$$.S.String)))
                    {
                        _target.CountryCode = _CountryCode;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180571886)
            
            //--TRIMMABLE-BOUNDARY-START(8590637294)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590637294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel)))
                {
                    /*var*/ let result = $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590637294)
            
            static $h = 702702;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885604590),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 702702,
      "h": 12885604590,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885604590),
//--TRIMMABLE-BOUNDARY-START(17180571886),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 571630,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 702702,
      "h": 17180571886,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180571886),
//--TRIMMABLE-BOUNDARY-START(8590637294),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 571630,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 702702,
      "h": 8590637294,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590637294)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295669998),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 702702,
      "h": 4295669998,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295669998)
  ],
  "h": 702702
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoReverseGeocodeMapsAddressModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(702702)
        
        

        //--TRIMMABLE-BOUNDARY-START(2013422)
        $asm.$cls(`$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor`, ($self) => class LocationIQDirectionDrivingModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AutK.LCFCML.LocationIQDirectionDrivingModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296980718)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296980718);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor.GenerateProperties($.$AutK.LCFCML.LocationIQDirectionDrivingModel, this, factory);
                    }, $LGNXzb ??= {"r":65537,"n":"","d":2013422,"h":0,"f":17825794}), 0, "LocationIQDirectionDrivingModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Mapping\\LocationIQ_LocationIQDirectionDrivingModel_LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModelTypeDescriptorBuilder.g.cs", "LocationIQDirectionDrivingModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296980718)
            
            //--TRIMMABLE-BOUNDARY-START(12886915310)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886915310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Code"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCML.LocationIQDirectionDrivingModel.$type, $.$discardRef(), "Code", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Code")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Code";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCML.LocationIQDirectionDrivingModel)).Code);
                        }, $pWKfRk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2013422,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Code = value.AsReference($.$$.S.String);
                        }, $JwwsId ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2013422,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Routes"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCML.LocationIQDirectionDrivingModel.$type, $.$discardRef(), "Routes", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Routes")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingRoute), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Routes";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingRoute), ($.$cast(target, $.$AutK.LCFCML.LocationIQDirectionDrivingModel)).Routes);
                        }, $Jcroge ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2013422,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Routes = value.AsReference($.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingRoute));
                        }, $ClQljf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2013422,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Waypoints"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCML.LocationIQDirectionDrivingModel.$type, $.$discardRef(), "Waypoints", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Waypoints")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Waypoints";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint), ($.$cast(target, $.$AutK.LCFCML.LocationIQDirectionDrivingModel)).Waypoints);
                        }, $DULYKh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2013422,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Waypoints = value.AsReference($.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint));
                        }, $ISQNPe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2013422,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886915310)
            
            //--TRIMMABLE-BOUNDARY-START(17181882606)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181882606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Code = _target.Code;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Code"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Code, ($v) => _Code = $v, $.$$.S.String)))
                    {
                        _target.Code = _Code;
                    }
                }
                {
                    /*var*/ let _Routes = _target.Routes;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Routes"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingRoute)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingRoute), $.$AutK.LCFCML.LocationIQDirectionDrivingRoute));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingRoute), $.$AutK.LCFCML.LocationIQDirectionDrivingRoute, property, $.$ref(() => _Routes, ($v) => _Routes = $v, $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingRoute))))
                    {
                        _target.Routes = _Routes;
                        if (_Routes !== null)
                        {
                            let $i9 = 0;
                            let $arr9 = _Routes;
                            while ($i9 < $arr9.length)
                            {
                                let item = $arr9[$i9++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$AutK.LCFCML.LocationIQDirectionDrivingRoute)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingRoute), $.$AutK.LCFCML.LocationIQDirectionDrivingRoute, property, $.$ref(() => _Routes, ($v) => _Routes = $v, $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingRoute)));
                    }
                }
                {
                    /*var*/ let _Waypoints = _target.Waypoints;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Waypoints"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint), $.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint), $.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint, property, $.$ref(() => _Waypoints, ($v) => _Waypoints = $v, $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint))))
                    {
                        _target.Waypoints = _Waypoints;
                        if (_Waypoints !== null)
                        {
                            let $i14 = 0;
                            let $arr14 = _Waypoints;
                            while ($i14 < $arr14.length)
                            {
                                let item = $arr14[$i14++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint), $.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint, property, $.$ref(() => _Waypoints, ($v) => _Waypoints = $v, $.$typeArray($.$AutK.LCFCML.LocationIQDirectionDrivingWaypoint)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181882606)
            
            //--TRIMMABLE-BOUNDARY-START(8591948014)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591948014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AutK.LCFCML.LocationIQDirectionDrivingModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AutK.LCFCML.LocationIQDirectionDrivingModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCML.LocationIQDirectionDrivingModel)))
                {
                    /*var*/ let result = $.$AutK.LCFCML.LocationIQDirectionDrivingModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCML.LocationIQDirectionDrivingModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AutK.LCFCML.LocationIQDirectionDrivingModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCML.LocationIQDirectionDrivingModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591948014)
            
            static $h = 2013422;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AutK.LCFCML.LocationIQDirectionDrivingModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886915310),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2013422,
      "h": 12886915310,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886915310),
//--TRIMMABLE-BOUNDARY-START(17181882606),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1882350,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2013422,
      "h": 17181882606,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181882606),
//--TRIMMABLE-BOUNDARY-START(8591948014),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1882350,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2013422,
      "h": 8591948014,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591948014)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296980718),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2013422,
      "h": 4296980718,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296980718)
  ],
  "h": 2013422
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AutK.LCFCML.LocationIQDirectionDrivingModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.LocationIQ.LocationIQDirectionDrivingModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}LocationIQ${separator}LocationIQDirectionDrivingModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2013422)
        
        

        //--TRIMMABLE-BOUNDARY-START(440558)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor`, ($self) => class GeocodeMapsCoModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AutK.LCFCMG.GeocodeMapsCoModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295407854)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295407854);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor.GenerateProperties($.$AutK.LCFCMG.GeocodeMapsCoModel, this, factory);
                    }, $gsKVQf ??= {"r":65537,"n":"","d":440558,"h":0,"f":17825794}), 0, "GeocodeMapsCoModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Mapping\\GeocodeMaps_GeocodeMapsCoModel_LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModelTypeDescriptorBuilder.g.cs", "GeocodeMapsCoModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295407854)
            
            //--TRIMMABLE-BOUNDARY-START(12885342446)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885342446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PlaceId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "PlaceId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PlaceId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int64, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "PlaceId";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$8(($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).PlaceId);
                        }, $pspBEe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PlaceId = value.AsLong();
                        }, $qWkwHc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Licence"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "Licence", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Licence")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Licence";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).Licence);
                        }, $JqUBFf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Licence = value.AsReference($.$$.S.String);
                        }, $wZtTOe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PoweredBy"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "PoweredBy", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PoweredBy")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "PoweredBy";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).PoweredBy);
                        }, $JSnWlj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PoweredBy = value.AsReference($.$$.S.String);
                        }, $PCiOwi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OsmType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "OsmType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OsmType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "OsmType";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).OsmType);
                        }, $qXEXze ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OsmType = value.AsReference($.$$.S.String);
                        }, $MUYDdi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OsmId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "OsmId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OsmId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int64, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "OsmId";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$8(($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).OsmId);
                        }, $iTRFZg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OsmId = value.AsLong();
                        }, $qmNOQd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Boundingbox"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "Boundingbox", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Boundingbox")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Boundingbox";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.String), ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).Boundingbox);
                        }, $PzMmCg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Boundingbox = value.AsReference($.$typeArray($.$$.S.String));
                        }, $BrbRaf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Lat"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "Lat", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Lat")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Lat";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).Lat);
                        }, $NJXvvf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Lat = value.AsReference($.$$.S.String);
                        }, $FjFGpj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Lon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "Lon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Lon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Lon";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).Lon);
                        }, $EAURaf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Lon = value.AsReference($.$$.S.String);
                        }, $TiLVye ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DisplayName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "DisplayName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DisplayName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "DisplayName";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).DisplayName);
                        }, $OWaCUh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DisplayName = value.AsReference($.$$.S.String);
                        }, $jUUMrb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Class"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "Class", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Class")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Class";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).Class);
                        }, $JWFimf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Class = value.AsReference($.$$.S.String);
                        }, $TafWlg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "Type";
                        $i21.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).Type);
                        }, $yrvrwc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Type = value.AsReference($.$$.S.String);
                        }, $RooCYf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Importance"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoModel.$type, $.$discardRef(), "Importance", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Importance")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "Importance";
                        $i23.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoModel)).Importance);
                        }, $MKWrph ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":440558,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Importance = value.AsDouble();
                        }, $hkZKeb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":440558,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885342446)
            
            //--TRIMMABLE-BOUNDARY-START(17180309742)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180309742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _PlaceId = _target.PlaceId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PlaceId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int64));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int64, property, $.$ref(() => _PlaceId, ($v) => _PlaceId = $v, $.$$.S.Int64)))
                    {
                        _target.PlaceId = _PlaceId;
                    }
                }
                {
                    /*var*/ let _Licence = _target.Licence;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Licence"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Licence, ($v) => _Licence = $v, $.$$.S.String)))
                    {
                        _target.Licence = _Licence;
                    }
                }
                {
                    /*var*/ let _PoweredBy = _target.PoweredBy;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PoweredBy"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PoweredBy, ($v) => _PoweredBy = $v, $.$$.S.String)))
                    {
                        _target.PoweredBy = _PoweredBy;
                    }
                }
                {
                    /*var*/ let _OsmType = _target.OsmType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OsmType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _OsmType, ($v) => _OsmType = $v, $.$$.S.String)))
                    {
                        _target.OsmType = _OsmType;
                    }
                }
                {
                    /*var*/ let _OsmId = _target.OsmId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OsmId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int64));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int64, property, $.$ref(() => _OsmId, ($v) => _OsmId = $v, $.$$.S.Int64)))
                    {
                        _target.OsmId = _OsmId;
                    }
                }
                {
                    /*var*/ let _Boundingbox = _target.Boundingbox;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Boundingbox"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Boundingbox, ($v) => _Boundingbox = $v, $.$typeArray($.$$.S.String))))
                    {
                        _target.Boundingbox = _Boundingbox;
                        if (_Boundingbox !== null)
                        {
                            let $i31 = 0;
                            let $arr31 = _Boundingbox;
                            while ($i31 < $arr31.length)
                            {
                                let item = $arr31[$i31++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Boundingbox, ($v) => _Boundingbox = $v, $.$typeArray($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Lat = _target.Lat;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Lat"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Lat, ($v) => _Lat = $v, $.$$.S.String)))
                    {
                        _target.Lat = _Lat;
                    }
                }
                {
                    /*var*/ let _Lon = _target.Lon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Lon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Lon, ($v) => _Lon = $v, $.$$.S.String)))
                    {
                        _target.Lon = _Lon;
                    }
                }
                {
                    /*var*/ let _DisplayName = _target.DisplayName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DisplayName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _DisplayName, ($v) => _DisplayName = $v, $.$$.S.String)))
                    {
                        _target.DisplayName = _DisplayName;
                    }
                }
                {
                    /*var*/ let _Class = _target.Class;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Class"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Class, ($v) => _Class = $v, $.$$.S.String)))
                    {
                        _target.Class = _Class;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Type, ($v) => _Type = $v, $.$$.S.String)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _Importance = _target.Importance;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Importance"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Importance, ($v) => _Importance = $v, $.$$.S.Double)))
                    {
                        _target.Importance = _Importance;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180309742)
            
            //--TRIMMABLE-BOUNDARY-START(8590375150)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590375150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AutK.LCFCMG.GeocodeMapsCoModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AutK.LCFCMG.GeocodeMapsCoModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCMG.GeocodeMapsCoModel)))
                {
                    /*var*/ let result = $.$AutK.LCFCMG.GeocodeMapsCoModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCMG.GeocodeMapsCoModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AutK.LCFCMG.GeocodeMapsCoModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCMG.GeocodeMapsCoModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590375150)
            
            static $h = 440558;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AutK.LCFCMG.GeocodeMapsCoModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885342446),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 440558,
      "h": 12885342446,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885342446),
//--TRIMMABLE-BOUNDARY-START(17180309742),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 309486,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 440558,
      "h": 17180309742,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180309742),
//--TRIMMABLE-BOUNDARY-START(8590375150),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 309486,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 440558,
      "h": 8590375150,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590375150)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295407854),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 440558,
      "h": 4295407854,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295407854)
  ],
  "h": 440558
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AutK.LCFCMG.GeocodeMapsCoModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(440558)
        
        

        //--TRIMMABLE-BOUNDARY-START(964846)
        $asm.$cls(`$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor`, ($self) => class GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295932142)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295932142);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor.GenerateProperties($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel, this, factory);
                    }, $nsiqjb ??= {"r":65537,"n":"","d":964846,"h":0,"f":17825794}), 0, "GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Mapping\\GeocodeMaps_GeocodeMapsCoReverseGeocodeMapsModel_LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptorBuilder.g.cs", "GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295932142)
            
            //--TRIMMABLE-BOUNDARY-START(12885866734)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885866734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PlaceId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, $.$discardRef(), "PlaceId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PlaceId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int64, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "PlaceId";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$8(($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)).PlaceId);
                        }, $eGFoDh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":964846,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PlaceId = value.AsLong();
                        }, $GgwGgk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":964846,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Licence"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, $.$discardRef(), "Licence", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Licence")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Licence";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)).Licence);
                        }, $QDhKyg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":964846,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Licence = value.AsReference($.$$.S.String);
                        }, $CzRLei ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":964846,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PoweredBy"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, $.$discardRef(), "PoweredBy", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PoweredBy")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "PoweredBy";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)).PoweredBy);
                        }, $IECMuk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":964846,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PoweredBy = value.AsReference($.$$.S.String);
                        }, $qHEscf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":964846,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OsmType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, $.$discardRef(), "OsmType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OsmType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "OsmType";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)).OsmType);
                        }, $RRDfmf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":964846,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OsmType = value.AsReference($.$$.S.String);
                        }, $dAKkHj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":964846,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OsmId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, $.$discardRef(), "OsmId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OsmId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int64, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "OsmId";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$8(($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)).OsmId);
                        }, $sjGWhi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":964846,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OsmId = value.AsLong();
                        }, $MsLqBg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":964846,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Lat"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, $.$discardRef(), "Lat", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Lat")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Lat";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)).Lat);
                        }, $AOpqpc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":964846,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Lat = value.AsReference($.$$.S.String);
                        }, $ociZHi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":964846,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Lon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, $.$discardRef(), "Lon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Lon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Lon";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)).Lon);
                        }, $cNQErj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":964846,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Lon = value.AsReference($.$$.S.String);
                        }, $pjSpIk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":964846,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DisplayName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, $.$discardRef(), "DisplayName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DisplayName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "DisplayName";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)).DisplayName);
                        }, $eaFjnb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":964846,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DisplayName = value.AsReference($.$$.S.String);
                        }, $TckRgd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":964846,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Address"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, $.$discardRef(), "Address", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Address")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Address";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel, ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)).Address);
                        }, $pmHUkf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":964846,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Address = value.AsReference($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel);
                        }, $TBmUqh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":964846,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Boundingbox"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel.$type, $.$discardRef(), "Boundingbox", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Boundingbox")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Boundingbox";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$$.S.String), ($.$cast(target, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)).Boundingbox);
                        }, $oifCSi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":964846,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Boundingbox = value.AsReference($.$typeArray($.$$.S.String));
                        }, $rvXKKd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":964846,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885866734)
            
            //--TRIMMABLE-BOUNDARY-START(17180834030)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180834030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _PlaceId = _target.PlaceId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PlaceId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int64));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int64, property, $.$ref(() => _PlaceId, ($v) => _PlaceId = $v, $.$$.S.Int64)))
                    {
                        _target.PlaceId = _PlaceId;
                    }
                }
                {
                    /*var*/ let _Licence = _target.Licence;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Licence"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Licence, ($v) => _Licence = $v, $.$$.S.String)))
                    {
                        _target.Licence = _Licence;
                    }
                }
                {
                    /*var*/ let _PoweredBy = _target.PoweredBy;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PoweredBy"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _PoweredBy, ($v) => _PoweredBy = $v, $.$$.S.String)))
                    {
                        _target.PoweredBy = _PoweredBy;
                    }
                }
                {
                    /*var*/ let _OsmType = _target.OsmType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OsmType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _OsmType, ($v) => _OsmType = $v, $.$$.S.String)))
                    {
                        _target.OsmType = _OsmType;
                    }
                }
                {
                    /*var*/ let _OsmId = _target.OsmId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OsmId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int64));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int64, property, $.$ref(() => _OsmId, ($v) => _OsmId = $v, $.$$.S.Int64)))
                    {
                        _target.OsmId = _OsmId;
                    }
                }
                {
                    /*var*/ let _Lat = _target.Lat;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Lat"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Lat, ($v) => _Lat = $v, $.$$.S.String)))
                    {
                        _target.Lat = _Lat;
                    }
                }
                {
                    /*var*/ let _Lon = _target.Lon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Lon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Lon, ($v) => _Lon = $v, $.$$.S.String)))
                    {
                        _target.Lon = _Lon;
                    }
                }
                {
                    /*var*/ let _DisplayName = _target.DisplayName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DisplayName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _DisplayName, ($v) => _DisplayName = $v, $.$$.S.String)))
                    {
                        _target.DisplayName = _DisplayName;
                    }
                }
                {
                    /*var*/ let _Address = _target.Address;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Address"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Address, ($v) => _Address = $v, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsAddressModel)))
                    {
                        _target.Address = _Address;
                    }
                }
                {
                    /*var*/ let _Boundingbox = _target.Boundingbox;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Boundingbox"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Boundingbox, ($v) => _Boundingbox = $v, $.$typeArray($.$$.S.String))))
                    {
                        _target.Boundingbox = _Boundingbox;
                        if (_Boundingbox !== null)
                        {
                            let $i32 = 0;
                            let $arr32 = _Boundingbox;
                            while ($i32 < $arr32.length)
                            {
                                let item = $arr32[$i32++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$$.S.String), $.$$.S.String, property, $.$ref(() => _Boundingbox, ($v) => _Boundingbox = $v, $.$typeArray($.$$.S.String)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180834030)
            
            //--TRIMMABLE-BOUNDARY-START(8590899438)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590899438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel)))
                {
                    /*var*/ let result = $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590899438)
            
            static $h = 964846;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885866734),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 964846,
      "h": 12885866734,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885866734),
//--TRIMMABLE-BOUNDARY-START(17180834030),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 833774,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 964846,
      "h": 17180834030,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180834030),
//--TRIMMABLE-BOUNDARY-START(8590899438),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 833774,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 964846,
      "h": 8590899438,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590899438)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295932142),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 964846,
      "h": 4295932142,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295932142)
  ],
  "h": 964846
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AutK.LCFCMG.GeocodeMapsCoReverseGeocodeMapsModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mapping.GeocodeMaps.GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mapping${separator}GeocodeMaps${separator}GeocodeMapsCoReverseGeocodeMapsModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(964846)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(47342)
