
//--TRIMMABLE-BOUNDARY-START(35068)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $HnZw, $mep, $meca, $mxdi, $mexla, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $meo, $mecm, $mecga, $mec, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $DJRY) {
    "use strict";
    let _;
    let $dynhIk;
    let $kzUkIk;
    let $VpntEj;
    let $lcYgib;
    let $WVdFic;
    let $ZMihYe;
    let $pIWQzb;
    let $BmnYke;
    let $oEBvck;
    let $WEdBlg;
    let $hojxij;
    let $RJTqVi;
    let $AqPAHi;
    let $oEFYhb;
    let $lJTyye;
    let $zpazol;
    let $dDZKTb;
    let $zWSCfe;
    let $auWTHg;
    let $NkiVze;
    let $kIugse;
    let $kbEtIe;
    let $Cnxndg;
    let $HyNApb;
    let $SJTMbd;
    let $NQGaeh;
    let $ejNcTi;
    let $UfGmfk;
    let $JFLlzi;
    let $sntePb;
    let $JirMFk;
    let $vkEUpg;
    let $ukPAWb;
    let $geuONc;
    let $oWxDmi;
    let $IlRqNa;
    let $DTUtae;
    let $pxcrnb;
    let $TDxqci;
    let $hFYQmj;
    let $yrfwji;
    let $UIiqIf;
    let $zyGNbd;
    let $CTAaCc;
    let $oDQTQc;
    let $YqOJac;
    let $vCecEc;
    let $KDckha;
    let $paTtPj;
    let $srrLld;
    let $fFtWQk;
    let $FdiEgd;
    let $tbpOIh;
    let $lZXYib;
    let $CgXqWc;
    let $tdvveh;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus", 
    {
  "h": 35068,
  "f": "LivingThing.Core.Frameworks.Common.MarkdownPlus",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.MarkdownPlus",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.MarkdownPlus",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(559356)
        $asm.$cls(`$EVvT.LCFCM.IMarkdownPlusTemplateFactory`, ($self) => class IMarkdownPlusTemplateFactory
        {
            //--TRIMMABLE-BOUNDARY-START(47245199612)
            /*bool */ get LCFCM$IMarkdownPlusTemplateFactory$RandomizeTemplates()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(47245199612)
            
            static $h = 559356;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950232316),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180428540,
        "f": 50331905
      },
      "n": "Name",
      "o": "LCFCM$IMarkdownPlusTemplateFactory$Name",
      "d": 559356,
      "h": 42950232316,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42950232316),
//--TRIMMABLE-BOUNDARY-START(51540166908),
    {
      "p": 1083644,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360297724,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130101500,
        "f": 83886337
      },
      "n": "Repeat",
      "o": "LCFCM$IMarkdownPlusTemplateFactory$Repeat",
      "d": 559356,
      "h": 51540166908,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51540166908),
//--TRIMMABLE-BOUNDARY-START(38655265020),
    {
      "p": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTemplate).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590493948,
        "f": 50331905
      },
      "n": "MarkdownTemplates",
      "o": "LCFCM$IMarkdownPlusTemplateFactory$MarkdownTemplates",
      "d": 559356,
      "h": 38655265020,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38655265020),
//--TRIMMABLE-BOUNDARY-START(47245199612),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770363132,
        "f": 50331777
      },
      "n": "RandomizeTemplates",
      "o": "LCFCM$IMarkdownPlusTemplateFactory$RandomizeTemplates",
      "d": 559356,
      "h": 47245199612,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(47245199612)
  ],
  "h": 559356
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusTemplateFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}IMarkdownPlusTemplateFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(559356)
        
        

        //--TRIMMABLE-BOUNDARY-START(624892)
        $asm.$cls(`$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver`, ($self) => class IMarkdownPlusTokenMethodResolver
        {
            static $h = 624892;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065395964),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475461372,
        "f": 50331905
      },
      "n": "Invocation",
      "o": "LCFCM$IMarkdownPlusTokenMethodResolver$Invocation",
      "d": 624892,
      "h": 30065395964,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065395964),
//--TRIMMABLE-BOUNDARY-START(4295592188),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885526780,
        "f": 50331905
      },
      "n": "Description",
      "o": "LCFCM$IMarkdownPlusTokenMethodResolver$Description",
      "d": 624892,
      "h": 4295592188,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295592188)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770428668),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "o": "LCFCM$IMarkdownPlusTokenMethodResolver$GetParameterInfos",
      "d": 624892,
      "h": 25770428668,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770428668),
//--TRIMMABLE-BOUNDARY-START(34360363260),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "o": "LCFCM$IMarkdownPlusTokenMethodResolver$ResolveToken",
      "d": 624892,
      "h": 34360363260,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360363260)
  ],
  "h": 624892
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusTokenMethodResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}IMarkdownPlusTokenMethodResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(624892)
        
        

        //--TRIMMABLE-BOUNDARY-START(297212)
        $asm.$cls(`$EVvT.LCFCM.IMarkdownPlusMarkdown`, ($self) => class IMarkdownPlusMarkdown
        {
            static $h = 297212;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770100988),
    {
      "p": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180166396,
        "f": 50331905
      },
      "n": "QuestionTokens",
      "o": "LCFCM$IMarkdownPlusMarkdown$QuestionTokens",
      "d": 297212,
      "h": 25770100988,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770100988),
//--TRIMMABLE-BOUNDARY-START(21475133692),
    {
      "p": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590231804,
        "f": 50331905
      },
      "n": "HelpTokens",
      "o": "LCFCM$IMarkdownPlusMarkdown$HelpTokens",
      "d": 297212,
      "h": 21475133692,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475133692)
  ],
  "h": 297212
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusMarkdown`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}IMarkdownPlusMarkdown`; }
        });
        //--TRIMMABLE-BOUNDARY-END(297212)
        
        

        //--TRIMMABLE-BOUNDARY-START(362748)
        $asm.$cls(`$EVvT.LCFCM.IMarkdownPlusMarkdownAnswer`, ($self) => class IMarkdownPlusMarkdownAnswer
        {
            static $h = 362748;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295330044),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IQueryOption).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885264636,
        "f": 50331905
      },
      "n": "ChosenAnswers",
      "o": "LCFCM$IMarkdownPlusMarkdownAnswer$ChosenAnswers",
      "d": 362748,
      "h": 4295330044,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295330044)
  ],
  "h": 362748
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusMarkdownAnswer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}IMarkdownPlusMarkdownAnswer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(362748)
        
        

        //--TRIMMABLE-BOUNDARY-START(231676)
        $asm.$cls(`$EVvT.LCFCM.IMarkdownPlusDebuggable`, ($self) => class IMarkdownPlusDebuggable
        {
            static $h = 231676;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885133564),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590166268,
        "f": 50331905
      },
      "n": "Variables",
      "o": "LCFCM$IMarkdownPlusDebuggable$Variables",
      "d": 231676,
      "h": 12885133564,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885133564)
  ],
  "h": 231676
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusDebuggable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}IMarkdownPlusDebuggable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(231676)
        
        

        //--TRIMMABLE-BOUNDARY-START(428284)
        $asm.$cls(`$EVvT.LCFCM.IMarkdownPlusMarkdownAnswerEditor`, ($self) => class IMarkdownPlusMarkdownAnswerEditor
        {
            //--TRIMMABLE-BOUNDARY-START(17180297468)
            /*IEnumerable<IQueryOption> */ get LCFCM$IMarkdownPlusMarkdownAnswer$ChosenAnswers()
            {
                return this.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers;
            }
            //--TRIMMABLE-BOUNDARY-END(17180297468)
            
            //--TRIMMABLE-BOUNDARY-START(30065199356)
            /*IQueryOption */ LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer(/*IQueryOption*/ answer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065199356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let existingRef = $.$sl.SL.Enumerable.SingleOrDefault$1($.$fPer.LCFCD.IQueryOption, this.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers, new ($.$$.S.Func$$$($.$fPer.LCFCD.IQueryOption, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    return s === answer;
                }, $VpntEj ??= {"r":262145,"p":[{"n":"s","p":21924182}],"n":"","d":428284,"h":0,"f":17825794}));
                if (existingRef !== null)
                {
                    return existingRef;
                }
                /*var*/ let existing = $.$sl.SL.Enumerable.SingleOrDefault$1($.$fPer.LCFCD.IQueryOption, this.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers, new ($.$$.S.Func$$$($.$fPer.LCFCD.IQueryOption, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.LCFCD$IQueryOption$Option === answer.LCFCD$IQueryOption$Option;
                }, $lcYgib ??= {"r":262145,"p":[{"n":"s","p":21924182}],"n":"","d":428284,"h":0,"f":17825794}));
                if (existing !== null)
                {
                    this.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Remove(existing);
                }
                this.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Add(answer);
                return answer;
            }
            //--TRIMMABLE-BOUNDARY-END(30065199356)
            
            //--TRIMMABLE-BOUNDARY-START(34360166652)
            /*IQueryOption */ LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer$1(/*string?*/ name, /*object?*/ value, /*double*/ score)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360166652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let existing = $.$sl.SL.Enumerable.SingleOrDefault$1($.$fPer.LCFCD.IQueryOption, this.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers, new ($.$$.S.Func$$$($.$fPer.LCFCD.IQueryOption, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.LCFCD$IQueryOption$Option === name;
                }, $WVdFic ??= {"r":262145,"p":[{"n":"s","p":21924182}],"n":"","d":428284,"h":0,"f":17825794}));
                if (existing !== null)
                {
                    this.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Remove(existing);
                }
                /*var*/ let answer = (() =>
                {
                    //new $.$fPer.LCFCD.QueryOption()
                    const $t1 = $.$fPer.LCFCD.QueryOption;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Option = name;
                    $i1.Value = value;
                    $i1.Score = score;
                    return $i1;
                })();
                this.LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers.Add($.$clone(answer));
                return answer;
            }
            //--TRIMMABLE-BOUNDARY-END(34360166652)
            
            static $h = 428284;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180297468),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IQueryOption).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770232060,
        "f": 50331650
      },
      "n": "{362748}.ChosenAnswers",
      "o": "LCFCM$IMarkdownPlusMarkdownAnswer$ChosenAnswers",
      "d": 428284,
      "h": 17180297468,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17180297468),
//--TRIMMABLE-BOUNDARY-START(4295395580),
    {
      "p": $.$so.SCO.ObservableCollection$$($.$fPer.LCFCD.IQueryOption).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885330172,
        "f": 50331905
      },
      "n": "ChosenAnswers",
      "o": "LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers",
      "d": 428284,
      "h": 4295395580,
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(4295395580)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065199356),
    {
      "r": 21924182,
      "p": [
        {
          "n": "answer",
          "p": 21924182
        }
      ],
      "n": "SetAnswer",
      "o": "LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer",
      "d": 428284,
      "h": 30065199356,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30065199356),
//--TRIMMABLE-BOUNDARY-START(34360166652),
    {
      "r": 21924182,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "score",
          "p": 1179649,
          "f": 65,
          "v": 0
        }
      ],
      "n": "SetAnswer",
      "o": "LCFCM$IMarkdownPlusMarkdownAnswerEditor$SetAnswer$1",
      "d": 428284,
      "h": 34360166652,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34360166652)
  ],
  "h": 428284
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusMarkdownAnswer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusMarkdownAnswerEditor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}IMarkdownPlusMarkdownAnswerEditor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(428284)
        
        

        //--TRIMMABLE-BOUNDARY-START(493820)
        $asm.$cls(`$EVvT.LCFCM.IMarkdownPlusOption`, ($self) => class IMarkdownPlusOption
        {
            //--TRIMMABLE-BOUNDARY-START(21475330300)
            //--TRIMMABLE-BOUNDARY-END(21475330300)
            
            static $h = 493820;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475330300),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590428412,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 17180363004,
        "f": 83886337
      },
      "n": "Item",
      "o": "LCFCM$IMarkdownPlusOption$Item",
      "d": 493820,
      "h": 21475330300,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475330300)
  ],
  "h": 493820
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IScoredQueryOption, $.$fPer.LCFCD.IQueryOption, $.$fPer.LCFCD.IOrderedData ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusOption`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}IMarkdownPlusOption`; }
        });
        //--TRIMMABLE-BOUNDARY-END(493820)
        
        

        //--TRIMMABLE-BOUNDARY-START(1607932)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusTokenResolverBase`, ($self) => class MarkdownPlusTokenResolverBase extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60131150076)
            /*IMarkdownPlusTokenMethodResolver?*/ Parent = null;
            //--TRIMMABLE-BOUNDARY-END(60131150076)
            
            //--TRIMMABLE-BOUNDARY-START(51541215484)
            /*T? */ GetParent(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541215484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let p = this.Parent;
                while(p !== null)
                {
                    let t;
                    if ($.$is(p, T, { set $v($v){ t = $v; } }))
                    {
                        return t;
                    }
                    let pp;
                    if ($.$is(p, $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase, { set $v($v){ pp = $v; } }))
                    {
                        p = pp.Parent;
                    }
                }
                return $.$default(T);
            }
            //--TRIMMABLE-BOUNDARY-END(51541215484)
            
            //--TRIMMABLE-BOUNDARY-START(77311019260)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311019260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invocation;
            }
            //--TRIMMABLE-BOUNDARY-END(77311019260)
            
            //--TRIMMABLE-BOUNDARY-START(17181477116)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181477116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17181477116)
            
            //--TRIMMABLE-BOUNDARY-START(21475461372)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusTokenMethodResolver.Invocation.get
            get LCFCM$IMarkdownPlusTokenMethodResolver$Invocation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065395964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invocation;
            }
            //--TRIMMABLE-BOUNDARY-END(21475461372)
            
            //--TRIMMABLE-BOUNDARY-START(12885526780)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusTokenMethodResolver.Description.get
            get LCFCM$IMarkdownPlusTokenMethodResolver$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295592188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12885526780)
            
            //--TRIMMABLE-BOUNDARY-START(25770428668)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusTokenMethodResolver.GetParameterInfos()
            LCFCM$IMarkdownPlusTokenMethodResolver$GetParameterInfos()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770428668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetParameterInfos(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770428668)
            
            //--TRIMMABLE-BOUNDARY-START(34360363260)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusTokenMethodResolver.ResolveToken(LivingThing.Core.Frameworks.Common.Stringy, System.Collections.Generic.Dictionary<string, LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusToken>, LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverClosure)
            LCFCM$IMarkdownPlusTokenMethodResolver$ResolveToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360363260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ResolveToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34360363260)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(8591542524)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591542524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591542524)
            
            //--TRIMMABLE-BOUNDARY-START(8591542524)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591542524)
            
            static $h = 1607932;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836182780),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361346300,
        "f": 50331905
      },
      "n": "Invocation",
      "d": 1607932,
      "h": 55836182780,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(55836182780),
//--TRIMMABLE-BOUNDARY-START(12886509820),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771411708,
        "f": 50331905
      },
      "n": "Description",
      "d": 1607932,
      "h": 12886509820,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886509820),
//--TRIMMABLE-BOUNDARY-START(60131150076),
    {
      "p": 624892,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951280892,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016051964,
        "f": 83886088
      },
      "n": "Parent",
      "d": 1607932,
      "h": 60131150076,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131150076)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246248188),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 1607932,
      "h": 47246248188,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47246248188),
//--TRIMMABLE-BOUNDARY-START(51541215484),
    {
      "r": (T) => T.$h,
      "g": [
        "T"
      ],
      "n": "GetParent",
      "d": 1607932,
      "h": 51541215484,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(51541215484),
//--TRIMMABLE-BOUNDARY-START(64426117372),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 1607932,
      "h": 64426117372,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(64426117372),
//--TRIMMABLE-BOUNDARY-START(77311019260),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1607932,
      "h": 77311019260,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77311019260),
//--TRIMMABLE-BOUNDARY-START(17181477116),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1607932,
      "h": 17181477116,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181477116)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591542524),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1607932,
      "h": 8591542524,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591542524)
  ],
  "h": 1607932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverBase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTokenResolverBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1607932)
        
        

        //--TRIMMABLE-BOUNDARY-START(1739004)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusTokenResolverExtension`, ($self) => class MarkdownPlusTokenResolverExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296706300)
            static /*T */ WithParent(T, /*this T*/ t, /*IMarkdownPlusTokenMethodResolver?*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296706300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                t.Parent = parent;
                return t;
            }
            //--TRIMMABLE-BOUNDARY-END(4296706300)
            
            static $h = 1739004;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296706300),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "t",
          "p": (T) => T.$h
        },
        {
          "n": "parent",
          "p": 624892
        }
      ],
      "g": [
        "T"
      ],
      "n": "WithParent",
      "d": 1739004,
      "h": 4296706300,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4296706300)
  ],
  "h": 1739004
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTokenResolverExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1739004)
        
        

        //--TRIMMABLE-BOUNDARY-START(755964)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusConst`, ($self) => class MarkdownPlusConst extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360494332)
            /*char*/ static TemplateOpen = /*{*/ 123;
            //--TRIMMABLE-BOUNDARY-END(34360494332)
            
            //--TRIMMABLE-BOUNDARY-START(30065527036)
            /*char*/ static TemplateClose = /*}*/ 125;
            //--TRIMMABLE-BOUNDARY-END(30065527036)
            
            //--TRIMMABLE-BOUNDARY-START(38655461628)
            /*string*/ static VariableStartIdentifier = null;
            //--TRIMMABLE-BOUNDARY-END(38655461628)
            
            //--TRIMMABLE-BOUNDARY-START(8590690556)
            /*string*/ static DefaultRepeatIteratorIndexName = null;
            //--TRIMMABLE-BOUNDARY-END(8590690556)
            
            //--TRIMMABLE-BOUNDARY-START(12885657852)
            /*string*/ static DeferedCodePrefix = null;
            //--TRIMMABLE-BOUNDARY-END(12885657852)
            
            //--TRIMMABLE-BOUNDARY-START(25770559740)
            /*string*/ static StylePrefix = null;
            //--TRIMMABLE-BOUNDARY-END(25770559740)
            
            //--TRIMMABLE-BOUNDARY-START(17180625148)
            /*string*/ static DefinePrefix = null;
            //--TRIMMABLE-BOUNDARY-END(17180625148)
            
            //--TRIMMABLE-BOUNDARY-START(21475592444)
            /*string*/ static ExpansionDelimiter = null;
            //--TRIMMABLE-BOUNDARY-END(21475592444)
            
            //--TRIMMABLE-BOUNDARY-START(4295723260)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295723260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295723260)
            
            //--TRIMMABLE-BOUNDARY-START(4295723260)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295723260)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(38655461628)
                    this.VariableStartIdentifier = "$";
                    //--TRIMMABLE-BOUNDARY-END(38655461628)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590690556)
                    this.DefaultRepeatIteratorIndexName = "$i";
                    //--TRIMMABLE-BOUNDARY-END(8590690556)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885657852)
                    this.DeferedCodePrefix = "!";
                    //--TRIMMABLE-BOUNDARY-END(12885657852)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770559740)
                    this.StylePrefix = "styles.";
                    //--TRIMMABLE-BOUNDARY-END(25770559740)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180625148)
                    this.DefinePrefix = "__define__.";
                    //--TRIMMABLE-BOUNDARY-END(17180625148)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475592444)
                    this.ExpansionDelimiter = "##";
                    //--TRIMMABLE-BOUNDARY-END(21475592444)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 755964;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360494332),
    {
      "t": 458753,
      "n": "TemplateOpen",
      "d": 755964,
      "h": 34360494332,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360494332),
//--TRIMMABLE-BOUNDARY-START(30065527036),
    {
      "t": 458753,
      "n": "TemplateClose",
      "d": 755964,
      "h": 30065527036,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065527036),
//--TRIMMABLE-BOUNDARY-START(38655461628),
    {
      "t": 1310721,
      "n": "VariableStartIdentifier",
      "d": 755964,
      "h": 38655461628,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655461628),
//--TRIMMABLE-BOUNDARY-START(8590690556),
    {
      "t": 1310721,
      "n": "DefaultRepeatIteratorIndexName",
      "d": 755964,
      "h": 8590690556,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590690556),
//--TRIMMABLE-BOUNDARY-START(12885657852),
    {
      "t": 1310721,
      "n": "DeferedCodePrefix",
      "d": 755964,
      "h": 12885657852,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885657852),
//--TRIMMABLE-BOUNDARY-START(25770559740),
    {
      "t": 1310721,
      "n": "StylePrefix",
      "d": 755964,
      "h": 25770559740,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770559740),
//--TRIMMABLE-BOUNDARY-START(17180625148),
    {
      "t": 1310721,
      "n": "DefinePrefix",
      "d": 755964,
      "h": 17180625148,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180625148),
//--TRIMMABLE-BOUNDARY-START(21475592444),
    {
      "t": 1310721,
      "n": "ExpansionDelimiter",
      "d": 755964,
      "h": 21475592444,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475592444)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295723260),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 755964,
      "h": 4295723260,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295723260)
  ],
  "h": 755964
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusConst`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusConst`; }
        });
        //--TRIMMABLE-BOUNDARY-END(755964)
        
        

        //--TRIMMABLE-BOUNDARY-START(3180796)
        $asm.$cls(`$EVvT.LCFCMR.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4298148092)
            static /*void */ AddMarkdownPlusResolvers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298148092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusNumberTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusStringTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusImportTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusInitTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusRandomTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusShuffleTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusEvalTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusHelpTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusHiddenTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusRepeatTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusRepeat2DTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusIfTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusStyleTokenResolver, services, null);
                $.$EVvT.LCFCM.Startup.AddMarkdownPlusResolver($.$EVvT.LCFCMR.MarkdownPlusDefineTokenResolver, services, null);
            }
            //--TRIMMABLE-BOUNDARY-END(4298148092)
            
            static $h = 3180796;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298148092),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddMarkdownPlusResolvers",
      "d": 3180796,
      "h": 4298148092,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298148092)
  ],
  "h": 3180796
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3180796)
        
        

        //--TRIMMABLE-BOUNDARY-START(952572)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusMarkdownAnswerExtension`, ($self) => class MarkdownPlusMarkdownAnswerExtension
        {
            //--TRIMMABLE-BOUNDARY-START(8590887164)
            static /*IQueryOption? */ GetChosenAnswer(/*this IMarkdownPlusMarkdownAnswer*/ answer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590887164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.SingleOrDefault$3($.$fPer.LCFCD.IQueryOption, answer.LCFCM$IMarkdownPlusMarkdownAnswer$ChosenAnswers);
            }
            //--TRIMMABLE-BOUNDARY-END(8590887164)
            
            //--TRIMMABLE-BOUNDARY-START(4295919868)
            static /*IEnumerable<IQueryOption> */ GetAnswers(/*this IMarkdownPlusMarkdownAnswer*/ answer, /*string*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295919868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Where($.$fPer.LCFCD.IQueryOption, answer.LCFCM$IMarkdownPlusMarkdownAnswer$ChosenAnswers, new ($.$$.S.Func$$$($.$fPer.LCFCD.IQueryOption, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    return a.LCFCD$IQueryOption$Option === id;
                }, $ZMihYe ??= {"r":262145,"p":[{"n":"a","p":21924182}],"n":"","d":952572,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295919868)
            
            static $h = 952572;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590887164),
    {
      "r": 21924182,
      "p": [
        {
          "n": "answer",
          "p": 362748
        }
      ],
      "n": "GetChosenAnswer",
      "d": 952572,
      "h": 8590887164,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590887164),
//--TRIMMABLE-BOUNDARY-START(4295919868),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IQueryOption).$h,
      "p": [
        {
          "n": "answer",
          "p": 362748
        },
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": "GetAnswers",
      "d": 952572,
      "h": 4295919868,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295919868)
  ],
  "h": 952572
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusMarkdownAnswerExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusMarkdownAnswerExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(952572)
        
        

        //--TRIMMABLE-BOUNDARY-START(3311868)
        $asm.$cls(`$EVvT.LCFCM.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4298279164)
            static /*void */ AddMarkdownPlusResolver(T, /*this IServiceCollection*/ services, /*string?*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298279164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key !== null)
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedTransient$5($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedTransient$6(T, services, key), key, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver))().$ctor(this,  (/*x*/ x, /*k*/ k) =>
                    {
                        return $.$box($.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1(T, x, k), T);
                    }, $AqPAHi ??= {"r":624892,"p":[{"n":"x","p":327718},{"n":"k","p":131073}],"n":"","d":3311868,"h":0,"f":17825794}));
                }
                else 
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$5($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$6(T, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$box($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1(T, x), T);
                    }, $oEFYhb ??= {"r":624892,"p":[{"n":"x","p":327718}],"n":"","d":3311868,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298279164)
            
            //--TRIMMABLE-BOUNDARY-START(8593246460)
            static /*MarkdownPlusTokenMethodResolverFactory */ GetDefaultMarkdownPlusTokenMethodResolverFactory(/*this IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593246460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory().$ctor(this,  (/*string*/ invocationName, /*string?*/ key, /*IMarkdownPlusTokenMethodResolver?*/ parent) =>
                {
                    /*var*/ let resolvers = $.$sl.SL.Enumerable.Concat($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver), serviceProvider), key !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver), serviceProvider, key) : $.$sl.SL.Enumerable.Empty($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver));
                    /*var*/ let resolver = $.$sl.SL.Enumerable.SingleOrDefault$1($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, resolvers, new ($.$$.S.Func$$$($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                    {
                        return $.$fPer.LCFCS$6.StringExtension.SplitBy$1($.$fPer.LCFC.StringyExtension.AsStringy$1(r.LCFCM$IMarkdownPlusTokenMethodResolver$Invocation), /*/*/ 47).Contains($.$fPer.LCFC.Stringy.op_Implicit$3(invocationName));
                    }, $lJTyye ??= {"r":262145,"p":[{"n":"r","p":624892}],"n":"","d":3311868,"h":0,"f":17825794}));
                    let b;
                    if ($.$is(resolver, $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase, { set $v($v){ b = $v; } }))
                    {
                        $.$EVvT.LCFCM.MarkdownPlusTokenResolverExtension.WithParent($.$EVvT.LCFCM.MarkdownPlusTokenResolverBase, b, parent);
                    }
                    return resolver;
                }, $zpazol ??= {"r":624892,"p":[{"n":"invocationName","p":1310721},{"n":"key","p":1310721},{"n":"parent","p":624892}],"n":"","d":3311868,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(8593246460)
            
            static $h = 3311868;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298279164),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "key",
          "p": 1310721,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddMarkdownPlusResolver",
      "d": 3311868,
      "h": 4298279164,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4298279164),
//--TRIMMABLE-BOUNDARY-START(8593246460),
    {
      "r": 1476860,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "GetDefaultMarkdownPlusTokenMethodResolverFactory",
      "d": 3311868,
      "h": 8593246460,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593246460)
  ],
  "h": 3311868
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3311868)
        
        

        //--TRIMMABLE-BOUNDARY-START(166140)
        $asm.$cls(`$EVvT.LCFCM.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295133436)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295133436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295133436)
            
            static $h = 166140;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295133436),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 166140,
      "h": 4295133436,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295133436)
  ],
  "h": 166140
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(166140)
        
        

        //--TRIMMABLE-BOUNDARY-START(100604)
        $asm.$cls(`$EVvT.LCFCM.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295067900)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295067900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$EVvT.LCFCM.MarkdownPlusRepeatType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$EVvT.LCFCM.MarkdownPlusRepeatTypeCustomAttributesProvider, $.$EVvT.LCFCM.MarkdownPlusRepeatTypeCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295067900)
            
            static $h = 100604;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295067900),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 100604,
      "h": 4295067900,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295067900)
  ],
  "h": 100604
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(100604)
        
        

        //--TRIMMABLE-BOUNDARY-START(1149180)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusRepeaterParser`, ($self) => class MarkdownPlusRepeaterParser
        {
            //--TRIMMABLE-BOUNDARY-START(4296116476)
            static /*IAsyncEnumerable<T> *//*async*/  Compile(T, /*MarkdownPlusTokenResolverGlobalClosure*/ global, /*MarkdownPlusContext*/ context, /*IMarkdownPlusTemplateFactory*/ factory, /*MarkdownPlusTokenResolverRootClosure?*/ importerClosure, /*MarkdownPlusTokenResolverImport?*/ $import)
            {
                return new ($.$$.N.YieldToIterator$$(T))().$ctor$1(async function*()
                {
                    if (!$.$sl.SL.Enumerable.Any$1($.$EVvT.LCFCM.MarkdownPlusTemplate, factory.LCFCM$IMarkdownPlusTemplateFactory$MarkdownTemplates))
                    {
                        return;
                    }
                    if (importerClosure !== null)
                    {
                        $.$$.SD.Debug.Assert$4(factory.LCFCM$IMarkdownPlusTemplateFactory$Repeat.Mode === 1/*MarkdownPlusRepeatType.Cycles*/ && factory.LCFCM$IMarkdownPlusTemplateFactory$Repeat.Value === 1, "factory.Repeat.Mode == MarkdownPlusRepeatType.Cycles && factory.Repeat.Value == 1");
                    }
                    /*int*/ let i = 0;
                    /*bool*/  function GenerateNext()
                    {
                        if (factory.LCFCM$IMarkdownPlusTemplateFactory$Repeat.Mode === 1/*MarkdownPlusRepeatType.Cycles*/)
                        {
                            if (factory.LCFCM$IMarkdownPlusTemplateFactory$Repeat.Value > 0)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, i < $.$$.S.Math.Max$4(1, factory.LCFCM$IMarkdownPlusTemplateFactory$Repeat.Value));
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, i < $.$$.S.Math.Max$4(1, $.$fPer.LCFC.ArrayCompare.Count(factory.LCFCM$IMarkdownPlusTemplateFactory$MarkdownTemplates)));
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, context.Score < factory.LCFCM$IMarkdownPlusTemplateFactory$Repeat.Value);
                    }
                    for(; GenerateNext.call(this); i++)
                    {
                        let $t1, $r1;
                        /*var*/ let questionIndex = factory.LCFCM$IMarkdownPlusTemplateFactory$RandomizeTemplates ? $.$$.S.Random.Shared.Next$2($.$fPer.LCFC.ArrayCompare.Count(factory.LCFCM$IMarkdownPlusTemplateFactory$MarkdownTemplates)) : i % $.$fPer.LCFC.ArrayCompare.Count(factory.LCFCM$IMarkdownPlusTemplateFactory$MarkdownTemplates);
                        /*var*/ let useQuestionTemplate = $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$swh.SW.HttpUtility.HtmlDecode$1($.$sl.SL.Enumerable.ElementAt$1($.$EVvT.LCFCM.MarkdownPlusTemplate, factory.LCFCM$IMarkdownPlusTemplateFactory$MarkdownTemplates, questionIndex).Value), "\\_", "_"), "\\*", "*");
                        /*var*/ let questionClosure = $.$cast(($t1 = context.CreateClosure(global, useQuestionTemplate, i), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))), T);
                        questionClosure.Importer = importerClosure;
                        if ($import !== null)
                        {
                            let $en2 = $import.Parameters.GetEnumerator();
                            while ($en2.MoveNext())
                            {
                                let parameter = $en2.Current;
                                {
                                    $.$dsp(questionClosure, T, ($t) => $t.Set, $.$EVvT.LCFCM.MarkdownPlusToken, $.$fPer.LCFC.Stringy.op_Implicit$3($.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/) + $.$strNN(parameter.Key)), parameter.Value);
                                }
                            }
                        }
                        questionClosure.QuestionTokens = $.$sl.SL.Enumerable.ToList($.$EVvT.LCFCM.MarkdownPlusToken, $.$EVvT.LCFCM.MarkdownPlusParser.Parse$1(useQuestionTemplate, questionClosure));
                        if ($.$sl.SL.Enumerable.Any$1($.$EVvT.LCFCM.MarkdownPlusTokenResolverImport, questionClosure.ImportedTemplates))
                        {
                            /*var*/ let importer = questionClosure;
                            /*bool*/ let _continue = false;
                            let $en3 = questionClosure.ImportedTemplates.GetEnumerator();
                            while ($en3.MoveNext())
                            {
                                let importedTemplate = $en3.Current;
                                {
                                    let $t4, $r4;
                                    /*var*/ let template = ($t4 = context.ResolveImport(new $.$fPer.LCFCD.DataId().$ctor$3($.$fPer.LCFCD.DataId.Parse(importedTemplate.Id), null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                    if (template !== null)
                                    {
                                        importedTemplate.ImportedFactory = template;
                                        template.LCFCM$IMarkdownPlusTemplateFactory$Repeat = (() =>
                                        {
                                            //new $.$EVvT.LCFCM.MarkdownPlusRepeat()
                                            const $t5 = $.$EVvT.LCFCM.MarkdownPlusRepeat;
                                            const $i5 = new $t5();
                                            $i5.$ctor$2();
                                            $i5.Mode = 1/*MarkdownPlusRepeatType.Cycles*/;
                                            $i5.Value = 1;
                                            return $i5;
                                        })();
                                        /*var*/ let importedClosures = $.$EVvT.LCFCM.MarkdownPlusRepeaterParser.Compile(T, global, context, template, importer, importedTemplate);
                                        if (importedClosures !== null)
                                        {
                                            /*var*/ let imported = new ($.$$.SCG.List$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverRootClosure))().$ctor$1();
                                            let $en6 = importedClosures[`SCG$IAsyncEnumerable$${T.$getFullName('$')}$GetAsyncEnumerator`]($.$$.ST$1.CancellationToken.None);
                                            while (await $en6.SCG$IAsyncEnumerator$$$MoveNextAsync())
                                            {
                                                let mimport = $en6.SCG$IAsyncEnumerator$$$Current;
                                                {
                                                    imported.Add(mimport);
                                                }
                                            }
                                            importedTemplate.ImportedClosure = imported;
                                            let $en7 = importedClosures[`SCG$IAsyncEnumerable$${T.$getFullName('$')}$GetAsyncEnumerator`]($.$$.ST$1.CancellationToken.None);
                                            while (await $en7.SCG$IAsyncEnumerator$$$MoveNextAsync())
                                            {
                                                let importedClosure = $en7.SCG$IAsyncEnumerator$$$Current;
                                                {
                                                    yield importedClosure;
                                                }
                                            }
                                            _continue = true;
                                        }
                                    }
                                }
                            }
                            if (_continue)
                            {
                                continue;
                            }
                        }
                        if (importerClosure !== null)
                        {
                        }
                        yield questionClosure;
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(4296116476)
            
            //--TRIMMABLE-BOUNDARY-START(8591083772)
            static /*IAsyncEnumerable<T> *//*async*/  ParseManyAsync(T, /*this IMarkdownPlusTemplateFactory*/ factory, /*MarkdownPlusContext*/ context, /*MarkdownPlusTokenResolverGlobalClosure?*/ global)
            {
                return new ($.$$.N.YieldToIterator$$(T))().$ctor$1(async function*()
                {
                    global ??= new $.$EVvT.LCFCM.MarkdownPlusTokenResolverGlobalClosure().$ctor$3(context);
                    /*var*/ let questionClosures = $.$EVvT.LCFCM.MarkdownPlusRepeaterParser.Compile(T, global, context, factory, null, null);
                    if (questionClosures !== null)
                    {
                        let $en8 = questionClosures[`SCG$IAsyncEnumerable$${T.$getFullName('$')}$GetAsyncEnumerator`]($.$$.ST$1.CancellationToken.None);
                        while (await $en8.SCG$IAsyncEnumerator$$$MoveNextAsync())
                        {
                            let questionClosure = $en8.SCG$IAsyncEnumerator$$$Current;
                            {
                                yield questionClosure;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(8591083772)
            
            static $h = 1149180;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296116476),
    {
      "r": (T) => $.$$.SCG.IAsyncEnumerable$$(T).$h,
      "p": [
        {
          "n": "global",
          "p": 1804540
        },
        {
          "n": "context",
          "p": 821500
        },
        {
          "n": "factory",
          "p": 559356
        },
        {
          "n": "importerClosure",
          "p": 2066684,
          "f": 65
        },
        {
          "n": "import",
          "p": 1870076,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "Compile",
      "d": 1149180,
      "h": 4296116476,
      "f": 16912418
    },
//--TRIMMABLE-BOUNDARY-END(4296116476),
//--TRIMMABLE-BOUNDARY-START(8591083772),
    {
      "r": (T) => $.$$.SCG.IAsyncEnumerable$$(T).$h,
      "p": [
        {
          "n": "factory",
          "p": 559356
        },
        {
          "n": "context",
          "p": 821500
        },
        {
          "n": "global",
          "p": 1804540,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "ParseManyAsync",
      "d": 1149180,
      "h": 8591083772,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(8591083772)
  ],
  "h": 1149180
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusRepeaterParser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusRepeaterParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1149180)
        
        

        //--TRIMMABLE-BOUNDARY-START(2197756)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusUtilityMethods`, ($self) => class MarkdownPlusUtilityMethods
        {
            //--TRIMMABLE-BOUNDARY-START(55836772604)
            /*string*/ static InvocationName = null;
            //--TRIMMABLE-BOUNDARY-END(55836772604)
            
            //--TRIMMABLE-BOUNDARY-START(85901543676)
            static /*string? */ name(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901543676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let resolved;
                if ($.$is(value, $.$EVvT.LCFCM.MarkdownPlusToken, { set $v($v){ resolved = $v; } }))
                {
                    return resolved.Name;
                }
                /*object?*/ let __ca1__;
                return _ = ((__ca1__ = value) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(85901543676)
            
            //--TRIMMABLE-BOUNDARY-START(111671347452)
            static /*double */ round(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111671347452);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Math.Round$7(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111671347452)
            
            //--TRIMMABLE-BOUNDARY-START(146031085820)
            static /*double */ trunc(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146031085820);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Math.Truncate$1(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146031085820)
            
            //--TRIMMABLE-BOUNDARY-START(51541805308)
            static /*double */ exp(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541805308);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.exp(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541805308)
            
            //--TRIMMABLE-BOUNDARY-START(38656903420)
            static /*double */ clamp(/*double*/ value, /*double*/ min, /*double*/ max)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656903420);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Math.Clamp$2(value, min, max);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656903420)
            
            //--TRIMMABLE-BOUNDARY-START(17182066940)
            static /*double */ asin(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182066940);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.asin(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182066940)
            
            //--TRIMMABLE-BOUNDARY-START(124556249340)
            static /*double */ sin(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124556249340);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.sin(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124556249340)
            
            //--TRIMMABLE-BOUNDARY-START(128851216636)
            static /*double */ sinh(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128851216636);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.sinh(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128851216636)
            
            //--TRIMMABLE-BOUNDARY-START(12887099644)
            static /*double */ acos(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887099644);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.acos(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887099644)
            
            //--TRIMMABLE-BOUNDARY-START(42951870716)
            static /*double */ cos(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951870716);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.cos(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951870716)
            
            //--TRIMMABLE-BOUNDARY-START(47246838012)
            static /*double */ cosh(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246838012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.cosh(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246838012)
            
            //--TRIMMABLE-BOUNDARY-START(21477034236)
            static /*double */ atan(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477034236);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.atan(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477034236)
            
            //--TRIMMABLE-BOUNDARY-START(25772001532)
            static /*double */ atan2(/*double*/ x, /*double*/ y)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772001532);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.atan2(x, y);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772001532)
            
            //--TRIMMABLE-BOUNDARY-START(137441151228)
            static /*double */ tan(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137441151228);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.tan(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137441151228)
            
            //--TRIMMABLE-BOUNDARY-START(141736118524)
            static /*double */ tanh(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141736118524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.tanh(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141736118524)
            
            //--TRIMMABLE-BOUNDARY-START(60131739900)
            static /*double */ log(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131739900);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.log(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131739900)
            
            //--TRIMMABLE-BOUNDARY-START(64426707196)
            static /*double */ log10(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426707196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Math.log10(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426707196)
            
            //--TRIMMABLE-BOUNDARY-START(81606576380)
            static /*double */ min(/*double*/ value, /*double*/ value2)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81606576380);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return value < value2 ? value : value2;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81606576380)
            
            //--TRIMMABLE-BOUNDARY-START(77311609084)
            static /*double */ max(/*double*/ value, /*double*/ value2)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311609084);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return value > value2 ? value : value2;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311609084)
            
            //--TRIMMABLE-BOUNDARY-START(8592132348)
            static /*double */ abs(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592132348);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Math.Abs$1(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592132348)
            
            //--TRIMMABLE-BOUNDARY-START(154621020412)
            static /*string */ upper$1(/*string*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154621020412);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.String.ToUpper.call(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154621020412)
            
            //--TRIMMABLE-BOUNDARY-START(150326053116)
            static /*string */ upper(/*MarkdownPlusToken*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326053116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca2__;
                return ((__ca2__ = value.ToString()) !== null ? ($.$$.S.String.ToUpper.call(__ca2__) ?? "") : "");
            }
            //--TRIMMABLE-BOUNDARY-END(150326053116)
            
            //--TRIMMABLE-BOUNDARY-START(73016641788)
            static /*string */ lower$1(/*string*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016641788);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.String.ToLower.call(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016641788)
            
            //--TRIMMABLE-BOUNDARY-START(68721674492)
            static /*string */ lower(/*MarkdownPlusToken*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721674492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca3__;
                return ((__ca3__ = value.ToString()) !== null ? ($.$$.S.String.ToLower.call(__ca3__) ?? "") : "");
            }
            //--TRIMMABLE-BOUNDARY-END(68721674492)
            
            //--TRIMMABLE-BOUNDARY-START(94491478268)
            static /*double */ number$1(/*string*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94491478268);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.Parse$7(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491478268)
            
            //--TRIMMABLE-BOUNDARY-START(90196510972)
            static /*double */ number(/*MarkdownPlusToken*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90196510972);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$1(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90196510972)
            
            //--TRIMMABLE-BOUNDARY-START(133146183932)
            static /*string */ str(/*double*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146183932);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.ToString.call(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146183932)
            
            //--TRIMMABLE-BOUNDARY-START(167505922300)
            static /*string */ verbal$2(/*long*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167505922300);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$fPer.LCFCS$6.NumberExtension.ToVerbal$1(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167505922300)
            
            //--TRIMMABLE-BOUNDARY-START(163210955004)
            static /*string */ verbal$1(/*int*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163210955004);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$fPer.LCFCS$6.NumberExtension.ToVerbal(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163210955004)
            
            //--TRIMMABLE-BOUNDARY-START(171800889596)
            static /*string */ verbal$3(/*string*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171800889596);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$fPer.LCFCS$6.NumberExtension.ToVerbal$1($.$$.S.Int64.Parse$7(value));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171800889596)
            
            //--TRIMMABLE-BOUNDARY-START(158915987708)
            static /*string */ verbal(/*MarkdownPlusToken*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158915987708);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$fPer.LCFCS$6.NumberExtension.ToVerbal$1($.$$.S.Int64.Parse$7($.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$3(value)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915987708)
            
            //--TRIMMABLE-BOUNDARY-START(115966314748)
            static /*string */ scramble(/*MarkdownPlusToken*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966314748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca4__;
                return $.$$.S.String.Create$2(((__ca4__ = value.ToString()) !== null ? $.$sl.SL.Enumerable.ToArray($.$$.S.Char, $.$sl.SL.Enumerable.OrderBy$1($.$$.S.Char, $.$$.S.Int32, $.$$.S.String.ToCharArray.call(__ca4__), new ($.$$.S.Func$$$($.$$.S.Char, $.$$.S.Int32))().$ctor(this,  (/*r*/ r) =>
                {
                    return $.$$.S.Random.Shared.Next();
                }, $NQGaeh ??= {"r":655361,"p":[{"n":"r","p":458753}],"n":"","d":2197756,"h":0,"f":17825794}))) : null));
            }
            //--TRIMMABLE-BOUNDARY-END(115966314748)
            
            //--TRIMMABLE-BOUNDARY-START(120261282044)
            static /*string */ scramble$1(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261282044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Create$2($.$sl.SL.Enumerable.ToArray($.$$.S.Char, $.$sl.SL.Enumerable.OrderBy$1($.$$.S.Char, $.$$.S.Int32, $.$$.S.String.ToCharArray.call(value), new ($.$$.S.Func$$$($.$$.S.Char, $.$$.S.Int32))().$ctor(this,  (/*r*/ r) =>
                {
                    return $.$$.S.Random.Shared.Next();
                }, $ejNcTi ??= {"r":655361,"p":[{"n":"r","p":458753}],"n":"","d":2197756,"h":0,"f":17825794}))));
            }
            //--TRIMMABLE-BOUNDARY-END(120261282044)
            
            //--TRIMMABLE-BOUNDARY-START(30066968828)
            static /*string */ chartonum(/*MarkdownPlusToken*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066968828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Join$5(",", $.$sl.SL.Enumerable.Select$1($.$$.S.Char, $.$$.S.String, $.$$.S.String.ToUpper.call((value.ToString() ?? "")), new ($.$$.S.Func$$$($.$$.S.Char, $.$$.S.String))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$$.S.Int32.ToString.call(((((c - /*A*/ 65) + 1) | 0)));
                }, $UfGmfk ??= {"r":1310721,"p":[{"n":"c","p":458753}],"n":"","d":2197756,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(30066968828)
            
            //--TRIMMABLE-BOUNDARY-START(34361936124)
            static /*string */ chartonum$1(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361936124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Join$5(",", $.$sl.SL.Enumerable.Select$1($.$$.S.Char, $.$$.S.String, $.$$.S.String.ToUpper.call(value), new ($.$$.S.Func$$$($.$$.S.Char, $.$$.S.String))().$ctor(this,  (/**/ c) =>
                {
                    return $.$$.S.Int32.ToString.call(((((c - /*A*/ 65) + 1) | 0)));
                }, $JFLlzi ??= {"r":1310721,"p":[{"n":"c","p":458753}],"n":"","d":2197756,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(34361936124)
            
            //--TRIMMABLE-BOUNDARY-START(107376380156)
            /*string[][]*/ static RomanNumerals = null;
            //--TRIMMABLE-BOUNDARY-END(107376380156)
            
            //--TRIMMABLE-BOUNDARY-START(98786445564)
            static /*string */ roman(/*MarkdownPlusToken*/ number)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786445564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$EVvT.LCFCM.MarkdownPlusUtilityMethods.roman$1($.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$2(number));
            }
            //--TRIMMABLE-BOUNDARY-END(98786445564)
            
            //--TRIMMABLE-BOUNDARY-START(103081412860)
            static /*string */ roman$1(/*int*/ number)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081412860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (number > 3999)
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12("> 3999 not yet supported");
                }
                /*var*/ let intArr = $.$sl.SL.Enumerable.ToList($.$$.S.Char, $.$sl.SL.Enumerable.Reverse$1($.$$.S.Char, $.$$.S.String.ToCharArray.call($.$$.S.Int32.ToString.call(number))));
                /*var*/ let len = intArr.Count;
                /*var*/ let romanNumeral = "";
                /*var*/ let i = len;
                while(i-- > 0)
                {
                    romanNumeral += $.$$.System.Array.$ReadT1.call($.$$.System.Array.$ReadT1.call($.$EVvT.LCFCM.MarkdownPlusUtilityMethods.RomanNumerals, i), intArr.get_Item(i) - /*0*/ 48);
                }
                return romanNumeral;
            }
            //--TRIMMABLE-BOUNDARY-END(103081412860)
            
            //--TRIMMABLE-BOUNDARY-START(4297165052)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297165052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(55836772604)
                    this.InvocationName = "mardownplus";
                    //--TRIMMABLE-BOUNDARY-END(55836772604)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107376380156)
                    this.RomanNumerals = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeArray($.$$.S.String).$type, [ $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX" ], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC" ], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM" ], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "", "M", "MM", "MMM" ], null, null) ], null, null);
                    //--TRIMMABLE-BOUNDARY-END(107376380156)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297165052)
            
            static $h = 2197756;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901543676),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "name",
      "d": 2197756,
      "h": 85901543676,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85901543676),
//--TRIMMABLE-BOUNDARY-START(111671347452),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "round",
      "d": 2197756,
      "h": 111671347452,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111671347452),
//--TRIMMABLE-BOUNDARY-START(146031085820),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "trunc",
      "d": 2197756,
      "h": 146031085820,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(146031085820),
//--TRIMMABLE-BOUNDARY-START(51541805308),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "exp",
      "d": 2197756,
      "h": 51541805308,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541805308),
//--TRIMMABLE-BOUNDARY-START(38656903420),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        },
        {
          "n": "min",
          "p": 1179649
        },
        {
          "n": "max",
          "p": 1179649
        }
      ],
      "n": "clamp",
      "d": 2197756,
      "h": 38656903420,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656903420),
//--TRIMMABLE-BOUNDARY-START(17182066940),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "asin",
      "d": 2197756,
      "h": 17182066940,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182066940),
//--TRIMMABLE-BOUNDARY-START(124556249340),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "sin",
      "d": 2197756,
      "h": 124556249340,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124556249340),
//--TRIMMABLE-BOUNDARY-START(128851216636),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "sinh",
      "d": 2197756,
      "h": 128851216636,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128851216636),
//--TRIMMABLE-BOUNDARY-START(12887099644),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "acos",
      "d": 2197756,
      "h": 12887099644,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887099644),
//--TRIMMABLE-BOUNDARY-START(42951870716),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "cos",
      "d": 2197756,
      "h": 42951870716,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951870716),
//--TRIMMABLE-BOUNDARY-START(47246838012),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "cosh",
      "d": 2197756,
      "h": 47246838012,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246838012),
//--TRIMMABLE-BOUNDARY-START(21477034236),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "atan",
      "d": 2197756,
      "h": 21477034236,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477034236),
//--TRIMMABLE-BOUNDARY-START(25772001532),
    {
      "r": 1179649,
      "p": [
        {
          "n": "x",
          "p": 1179649
        },
        {
          "n": "y",
          "p": 1179649
        }
      ],
      "n": "atan2",
      "d": 2197756,
      "h": 25772001532,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772001532),
//--TRIMMABLE-BOUNDARY-START(137441151228),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "tan",
      "d": 2197756,
      "h": 137441151228,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(137441151228),
//--TRIMMABLE-BOUNDARY-START(141736118524),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "tanh",
      "d": 2197756,
      "h": 141736118524,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141736118524),
//--TRIMMABLE-BOUNDARY-START(60131739900),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "log",
      "d": 2197756,
      "h": 60131739900,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60131739900),
//--TRIMMABLE-BOUNDARY-START(64426707196),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "log10",
      "d": 2197756,
      "h": 64426707196,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426707196),
//--TRIMMABLE-BOUNDARY-START(81606576380),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        },
        {
          "n": "value2",
          "p": 1179649
        }
      ],
      "n": "min",
      "d": 2197756,
      "h": 81606576380,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81606576380),
//--TRIMMABLE-BOUNDARY-START(77311609084),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        },
        {
          "n": "value2",
          "p": 1179649
        }
      ],
      "n": "max",
      "d": 2197756,
      "h": 77311609084,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77311609084),
//--TRIMMABLE-BOUNDARY-START(8592132348),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "abs",
      "d": 2197756,
      "h": 8592132348,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592132348),
//--TRIMMABLE-BOUNDARY-START(154621020412),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "upper",
      "o": "@$1",
      "d": 2197756,
      "h": 154621020412,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(154621020412),
//--TRIMMABLE-BOUNDARY-START(150326053116),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1411324
        }
      ],
      "n": "upper",
      "d": 2197756,
      "h": 150326053116,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(150326053116),
//--TRIMMABLE-BOUNDARY-START(73016641788),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "lower",
      "o": "@$1",
      "d": 2197756,
      "h": 73016641788,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73016641788),
//--TRIMMABLE-BOUNDARY-START(68721674492),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1411324
        }
      ],
      "n": "lower",
      "d": 2197756,
      "h": 68721674492,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68721674492),
//--TRIMMABLE-BOUNDARY-START(94491478268),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "number",
      "o": "@$1",
      "d": 2197756,
      "h": 94491478268,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94491478268),
//--TRIMMABLE-BOUNDARY-START(90196510972),
    {
      "r": 1179649,
      "p": [
        {
          "n": "value",
          "p": 1411324
        }
      ],
      "n": "number",
      "d": 2197756,
      "h": 90196510972,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90196510972),
//--TRIMMABLE-BOUNDARY-START(133146183932),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "str",
      "d": 2197756,
      "h": 133146183932,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133146183932),
//--TRIMMABLE-BOUNDARY-START(167505922300),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "verbal",
      "o": "@$2",
      "d": 2197756,
      "h": 167505922300,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167505922300),
//--TRIMMABLE-BOUNDARY-START(163210955004),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "verbal",
      "o": "@$1",
      "d": 2197756,
      "h": 163210955004,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(163210955004),
//--TRIMMABLE-BOUNDARY-START(171800889596),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "verbal",
      "o": "@$3",
      "d": 2197756,
      "h": 171800889596,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171800889596),
//--TRIMMABLE-BOUNDARY-START(158915987708),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1411324
        }
      ],
      "n": "verbal",
      "d": 2197756,
      "h": 158915987708,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(158915987708),
//--TRIMMABLE-BOUNDARY-START(115966314748),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1411324
        }
      ],
      "n": "scramble",
      "d": 2197756,
      "h": 115966314748,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115966314748),
//--TRIMMABLE-BOUNDARY-START(120261282044),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "scramble",
      "o": "@$1",
      "d": 2197756,
      "h": 120261282044,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120261282044),
//--TRIMMABLE-BOUNDARY-START(30066968828),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1411324
        }
      ],
      "n": "chartonum",
      "d": 2197756,
      "h": 30066968828,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066968828),
//--TRIMMABLE-BOUNDARY-START(34361936124),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "chartonum",
      "o": "@$1",
      "d": 2197756,
      "h": 34361936124,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361936124),
//--TRIMMABLE-BOUNDARY-START(98786445564),
    {
      "r": 1310721,
      "p": [
        {
          "n": "number",
          "p": 1411324
        }
      ],
      "n": "roman",
      "d": 2197756,
      "h": 98786445564,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98786445564),
//--TRIMMABLE-BOUNDARY-START(103081412860),
    {
      "r": 1310721,
      "p": [
        {
          "n": "number",
          "p": 655361
        }
      ],
      "n": "roman",
      "o": "@$1",
      "d": 2197756,
      "h": 103081412860,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103081412860)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55836772604),
    {
      "t": 1310721,
      "n": "InvocationName",
      "d": 2197756,
      "h": 55836772604,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836772604),
//--TRIMMABLE-BOUNDARY-START(107376380156),
    {
      "t": $.$typeArray($.$typeArray($.$$.S.String)).$h,
      "n": "RomanNumerals",
      "d": 2197756,
      "h": 107376380156,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(107376380156)
  ],
  "h": 2197756
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusUtilityMethods`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusUtilityMethods`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2197756)
        
        

        //--TRIMMABLE-BOUNDARY-START(1280252)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusRepeatTypeCustomAttributesProvider`, ($self) => class MarkdownPlusRepeatTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296247548)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296247548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296247548)
            
            static $h = 1280252;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296247548),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1280252,
      "h": 4296247548,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296247548)
  ],
  "h": 1280252
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusRepeatTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusRepeatTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1280252)
        
        

        //--TRIMMABLE-BOUNDARY-START(1018108)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusParser`, ($self) => class MarkdownPlusParser
        {
            //--TRIMMABLE-BOUNDARY-START(42950691068)
            static /*Stringy */ ResolveParameterName(/*MarkdownPlusTokenResolverClosure*/ context, /*Stringy*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950691068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!token.StartsWith($.$fPer.LCFC.Stringy.op_Implicit$3("$"/*MarkdownPlusConst.VariableStartIdentifier*/), 4))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Parameter name must start with " + $.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/));
                }
                /*var*/ let variableName = $.$clone(token);
                if (variableName.Contains$1(/*[*/ 91))
                {
                    /*var*/ let braceStart = variableName.IndexOf(/*[*/ 91, 0);
                    /*var*/ let braceEnd = $.$fPer.LCFCS$6.InterpreterExtension.MatchBrace(variableName, braceStart);
                    if (braceEnd > braceStart)
                    {
                        /*var*/ let variableValue;
                        /*var*/ let prefixVariableName = variableName.Slice(0, braceStart);
                        /*var*/ let braceVariable = variableName.Slice(((braceStart + 1) | 0), ((((braceEnd - braceStart) | 0) - 1) | 0));
                        context.ResolveParameter($.$fPer.LCFC.Stringy.op_Implicit$1(braceVariable), $.$ref(() => variableValue, ($v) => variableValue = $v, $.$$.S.Object), 0);
                        variableName = $.$fPer.LCFC.Stringy.op_Implicit$3($.$strNN($.$strNN(prefixVariableName.ToString()) + "[" + $.$strNN($.$dspc(variableValue, $.$$.S.Object, ($t) => $t.ToString))) + "]");
                    }
                }
                return variableName;
            }
            //--TRIMMABLE-BOUNDARY-END(42950691068)
            
            //--TRIMMABLE-BOUNDARY-START(21475854588)
            static /*bool */ IsNumber(/*Stringy*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475854588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token.Length === 0)
                {
                    return false;
                }
                /*bool*/ let hasSeenDot = false;
                for(/*int*/ let i = 0; i < token.Length; i++)
                {
                    /*char*/ let c = token.get_Item$1(i);
                    if (i === 0 && c === /*-*/ 45)
                    {
                        continue;
                    }
                    if (c === /*.*/ 46 && !hasSeenDot)
                    {
                        hasSeenDot = true;
                        continue;
                    }
                    if ($.$$.S.Char.IsNumber$1(c))
                    {
                        continue;
                    }
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21475854588)
            
            //--TRIMMABLE-BOUNDARY-START(25770821884)
            static /*bool */ IsQuotedString(/*Stringy*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770821884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token.Length >= 2 && token.StartsWith($.$fPer.LCFC.Stringy.op_Implicit$3("\""), 4) && token.EndsWith($.$fPer.LCFC.Stringy.op_Implicit$3("\"")) && token.get_Item$1(((token.Length - 2) | 0)) !== /*\\*/ 92)
                {
                    for(/*int*/ let i = 1; i < ((token.Length - 1) | 0); i++)
                    {
                        if (token.get_Item$1(i) === /*\"*/ 34 && token.get_Item$1(((i - 1) | 0)) !== /*\\*/ 92)
                        {
                            return false;
                        }
                    }
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(25770821884)
            
            //--TRIMMABLE-BOUNDARY-START(4295985404)
            static /*bool */ ContainsVariable(/*Stringy*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295985404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return token.Contains$2($.$fPer.LCFC.Stringy.op_Implicit$3("$"/*MarkdownPlusConst.VariableStartIdentifier*/));
            }
            //--TRIMMABLE-BOUNDARY-END(4295985404)
            
            //--TRIMMABLE-BOUNDARY-START(17180887292)
            static /*bool */ IsDeferedToken(/*Stringy*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180887292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token.StartsWith($.$fPer.LCFC.Stringy.op_Implicit$3("!"/*MarkdownPlusConst.DeferedCodePrefix*/), 4))
                {
                    return true;
                }
                if ($.$fPer.LCFCS$6.InterpreterExtension.IsWrappedInBrace(token, /*(*/ 40))
                {
                    /*var*/ let methodName;
                    /*var*/ let parameters;
                    if ($.$fPer.LCFCS$6.InterpreterExtension.TryParseMethod(token, $.$ref(() => methodName, ($v) => methodName = $v, $.$fPer.LCFC.Stringy), $.$ref(() => parameters, ($v) => parameters = $v, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.StringySplitEntry)))))
                    {
                        if (methodName.Length === 0 && $.$fPer.LCFC.ArrayCompare.Count(parameters) === 1)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180887292)
            
            //--TRIMMABLE-BOUNDARY-START(47245658364)
            static /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ token, /*MarkdownPlusTokenResolverClosure*/ closure, /*IMarkdownPlusTokenMethodResolver?*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245658364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                token = token.Trim();
                /*Stringy*/ let resultName = $.$fPer.LCFC.Stringy.Null;
                /*MarkdownPlusToken*/ let result = new $.$EVvT.LCFCM.MarkdownPlusToken();
                if (!token.EndsWith($.$fPer.LCFC.Stringy.op_Implicit$3(")")))
                {
                    /*int*/ let sliceCount = 2;
                    /*var*/ let index = token.LastIndexOf("=>");
                    if (index < 0)
                    {
                        index = token.LastIndexOf(":");
                        if (index > 0)
                        {
                            sliceCount = 1;
                        }
                    }
                    if (index < 0)
                    {
                        index = token.LastIndexOf("=&gt;");
                        if (index > 0)
                        {
                            sliceCount = 5;
                        }
                    }
                    if (index > 0)
                    {
                        /*int*/ let dollarIndex = ((index + sliceCount) | 0);
                        while(dollarIndex < token.Length && $.$$.S.Char.IsWhiteSpace$1(token.get_Item$1(dollarIndex)))
                        {
                            dollarIndex++;
                        }
                        if (dollarIndex < token.Length && token.get_Item$1(dollarIndex) === /*$*/ 36)
                        {
                            resultName = token.Slice(((index + sliceCount) | 0), ((((token.Length - index) | 0) - sliceCount) | 0)).Trim();
                            token = token.Slice(0, index).Trim();
                        }
                    }
                }
                if ($.$EVvT.LCFCM.MarkdownPlusParser.IsDeferedToken($.$clone(token)))
                {
                    result = new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(new $.$EVvT.LCFCM.MarkdownPlusDeferedParameterResolver().$ctor$3(closure, $.$clone(token), new ($.$$.S.Func$$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure, $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken)))().$ctor(this,  (/*closure*/ closure) =>
                    {
                        /*var*/ let deferedTokens = token.get_Item$1(0) === $.$$.S.String.get_Chars.call("!"/*MarkdownPlusConst.DeferedCodePrefix*/, 0) ? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFC.Stringy), [token.Slice$1(1)], null, null) : $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.StringySplitEntry), $.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.InterpreterExtension.SplitMethodParameter(token.Slice(1, ((token.Length - 2) | 0)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "," ], null, null)), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.StringySplitEntry), $.$fPer.LCFC.Stringy))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.Value.Token;
                        }, $CTAaCc ??= {"r":64915798,"p":[{"n":"s","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.StringySplitEntry).$h}],"n":"","d":1018108,"h":0,"f":17825794}));
                        return $.$sl.SL.Enumerable.ToList($.$EVvT.LCFCM.MarkdownPlusToken, $.$sl.SL.Enumerable.Select$1($.$fPer.LCFC.Stringy, $.$EVvT.LCFCM.MarkdownPlusToken, deferedTokens, new ($.$$.S.Func$$$($.$fPer.LCFC.Stringy, $.$EVvT.LCFCM.MarkdownPlusToken))().$ctor(this,  (/*deferedToken*/ deferedToken) =>
                        {
                            return $.$EVvT.LCFCM.MarkdownPlusParser.ResolveToken($.$clone(deferedToken), closure, parent);
                        }, $oDQTQc ??= {"r":1411324,"p":[{"n":"deferedToken","p":64915798}],"n":"","d":1018108,"h":0,"f":17825794})));
                    }, $YqOJac ??= {"r":$.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken).$h,"p":[{"n":"closure","p":1673468}],"n":"","d":1018108,"h":0,"f":17825794})));
                }
                else if (token.Length >= 2 && token.get_Item$1(0) === /*[*/ 91 && token.get_Item$1(((token.Length - 1) | 0)) === /*]*/ 93)
                {
                    /*var*/ let values = $.$fPer.LCFCS$6.InterpreterExtension.SplitMethodParameter(token.Slice(1, ((token.Length - 2) | 0)).Trim(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "," ], null, null));
                    result = new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$sl.SL.Enumerable.ToList($.$EVvT.LCFCM.MarkdownPlusToken, $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.StringySplitEntry), $.$EVvT.LCFCM.MarkdownPlusToken, values, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.StringySplitEntry), $.$EVvT.LCFCM.MarkdownPlusToken))().$ctor(this,  (/*v*/ v) =>
                    {
                        return $.$EVvT.LCFCM.MarkdownPlusParser.ResolveToken(v.Value.Token, closure, parent);
                    }, $vCecEc ??= {"r":1411324,"p":[{"n":"v","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.StringySplitEntry).$h}],"n":"","d":1018108,"h":0,"f":17825794}))));
                }
                else if (token.StartsWith($.$fPer.LCFC.Stringy.op_Implicit$3("$"/*MarkdownPlusConst.VariableStartIdentifier*/), 4) && $.$fPer.LCFCS$6.InterpreterExtension.IsValidVariableName(token.Slice$1("$"/*MarkdownPlusConst.VariableStartIdentifier*/.length)))
                {
                    /*var*/ let obj;
                    /*var*/ let parameterName = $.$EVvT.LCFCM.MarkdownPlusParser.ResolveParameterName(closure, $.$clone(token));
                    /*var*/ let ok = closure.ResolveParameter($.$fPer.LCFC.Stringy.op_Implicit$1(parameterName), $.$ref(() => obj, ($v) => obj = $v, $.$$.S.Object), 0);
                    if (ok)
                    {
                        result = new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(obj);
                    }
                }
                else if ($.$EVvT.LCFCM.MarkdownPlusParser.IsQuotedString($.$clone(token)))
                {
                    token = token.Slice(1, ((token.Length - 2) | 0));
                    if (token.Contains$2($.$fPer.LCFC.Stringy.op_Implicit$3("\"")))
                    {
                        token = $.$fPer.LCFC.Stringy.op_Implicit$3($.$str.STR.Regex.Unescape($.$fPer.LCFC.Stringy.op_Implicit$1(token)));
                    }
                    /*var*/ let rr = $.$sl.SL.Enumerable.ToList($.$EVvT.LCFCM.MarkdownPlusToken, $.$EVvT.LCFCM.MarkdownPlusParser.Parse($.$clone(token), closure));
                    if ($.$fPer.LCFC.ArrayCompare.Count(rr) === 1)
                    {
                        result = new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$sl.SL.Enumerable.Single$1($.$EVvT.LCFCM.MarkdownPlusToken, rr).ToString());
                    }
                    else 
                    {
                        result = new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$sl.SL.Enumerable.ToList($.$$.S.Object, $.$sl.SL.Enumerable.Select$1($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Object, rr, new ($.$$.S.Func$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Object))().$ctor(this,  (/*r*/ r) =>
                        {
                            let str;
                            if ($.$is(r.Value, $.$fPer.LCFC.Stringy, { set $v($v){ str = $v; } }))
                            {
                                return str.ToString();
                            }
                            let mpt;
                            if ($.$is(r, $.$EVvT.LCFCM.MarkdownPlusToken, { set $v($v){ mpt = $v; } }))
                            {
                                return mpt.ToString();
                            }
                            return r.Value;
                        }, $KDckha ??= {"r":131073,"p":[{"n":"r","p":1411324}],"n":"","d":1018108,"h":0,"f":17825794}))));
                    }
                }
                if (result.Value === null)
                {
                    /*IEnumerable<KeyValuePair<Stringy, StringySplitEntry>>*/ let parameters = $.$sl.SL.Enumerable.Empty($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.StringySplitEntry));
                    /*Stringy*/ let methodName = $.$fPer.LCFC.Stringy.Null;
                    if (!$.$fPer.LCFCS$6.InterpreterExtension.TryParseMethod(token, $.$ref(() => methodName, ($v) => methodName = $v, $.$fPer.LCFC.Stringy), $.$ref(() => parameters, ($v) => parameters = $v, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.StringySplitEntry)))))
                    {
                        methodName = $.$clone(token);
                    }
                    /*var*/ let resolver = closure.Context.ResolverFactory.Invoke(methodName.ToString() ?? "", closure.Context.ResolverKey, parent);
                    if (resolver !== null)
                    {
                        closure.Resolvers.Add(resolver);
                    }
                    /*Dictionary<string, MarkdownPlusToken>?*/ let resolvedParameters = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken))().$ctor$1();
                    if (methodName.Length > 0 && $.$sl.SL.Enumerable.Any$1($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$fPer.LCFCS$6.StringySplitEntry), parameters))
                    {
                        let methodParameterClosure = null;
                        try
                        {
                            methodParameterClosure = new $.$EVvT.LCFCM.MarkdownPlusTokenResolverMethodClosure().$ctor$3(closure);
                            let $en7 = parameters.SCG$IEnumerable$$$GetEnumerator();
                            while ($en7.SC$1$IEnumerator$MoveNext())
                            {
                                let parameter = $en7.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let para = $.$EVvT.LCFCM.MarkdownPlusParser.ResolveToken(parameter.Value.Token, methodParameterClosure, resolver);
                                    methodParameterClosure.Set($.$EVvT.LCFCM.MarkdownPlusToken, parameter.Key.Trim(), $.$clone(para));
                                    resolvedParameters.set_Item($.$fPer.LCFC.Stringy.op_Implicit$1(parameter.Key.Trim()), $.$clone(para));
                                }
                            }
                        }
                        finally
                        {
                            methodParameterClosure?.S$IDisposable$Dispose();
                        }
                    }
                    /*MarkdownPlusToken?*/ let view = null;
                    if (resolver === null)
                    {
                        try
                        {
                            if (resolvedParameters.Count === 0)
                            {
                                if (!$.$EVvT.LCFCM.MarkdownPlusParser.IsNumber($.$clone(token)) && !$.$EVvT.LCFCM.MarkdownPlusParser.IsQuotedString($.$clone(token)) && $.$EVvT.LCFCM.MarkdownPlusParser.ContainsVariable($.$clone(token)))
                                {
                                    view = closure.EvaluateExpression($.$clone(token), null);
                                }
                            }
                            else 
                            {
                                if ($.$$.S.Char.IsLower$1(methodName.get_Item$1(0)) && !methodName.Contains$1(/*.*/ 46))
                                {
                                    view = closure.EvaluateExpression(`${$.$strNN("mardownplus"/*MarkdownPlusUtilityMethods.InvocationName*/)}.${$.$strNN(methodName.ToString())}(${$.$strNN($.$$.S.String.Join$5(", ", $.$sl.SL.Enumerable.Select($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.String, resolvedParameters, (new ($.$$.S.Func$$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32, $.$$.S.String))().$ctor(this,  (/*p*/ p, /*i*/ i) =>
                                    {
                                        return "arg" + i;
                                    }, $paTtPj ??= {"r":1310721,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h},{"n":"i","p":655361}],"n":"","d":1018108,"h":0,"f":17825794})))))})`, $.$sl.SL.Enumerable.ToDictionary$5($.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32), $.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken, $.$sl.SL.Enumerable.Select($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32), resolvedParameters, new ($.$$.S.Func$$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32)))().$ctor(this,  (/*p*/ p, /*i*/ i) =>
                                    {
                                        return new ($.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32))().$ctor$3(p, i);
                                    }, $srrLld ??= {"r":$.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32).$h,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h},{"n":"i","p":655361}],"n":"","d":1018108,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32), $.$$.S.String))().$ctor(this,  (/*kv*/ kv) =>
                                    {
                                        return "arg" + kv.Item2;
                                    }, $fFtWQk ??= {"r":1310721,"p":[{"n":"kv","p":$.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32).$h}],"n":"","d":1018108,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32), $.$EVvT.LCFCM.MarkdownPlusToken))().$ctor(this,  (/*kv*/ kv) =>
                                    {
                                        return kv.Item1.Value;
                                    }, $FdiEgd ??= {"r":1411324,"p":[{"n":"kv","p":$.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32).$h}],"n":"","d":1018108,"h":0,"f":17825794})));
                                }
                                else 
                                {
                                    view = closure.EvaluateExpression(`${$.$strNN(methodName.ToString())}(${$.$strNN($.$$.S.String.Join$5(", ", $.$sl.SL.Enumerable.Select($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.String, resolvedParameters, (new ($.$$.S.Func$$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32, $.$$.S.String))().$ctor(this,  (/*p*/ p, /*i*/ i) =>
                                    {
                                        return "arg" + i;
                                    }, $tbpOIh ??= {"r":1310721,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h},{"n":"i","p":655361}],"n":"","d":1018108,"h":0,"f":17825794})))))})`, $.$sl.SL.Enumerable.ToDictionary$5($.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32), $.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken, $.$sl.SL.Enumerable.Select($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32), resolvedParameters, new ($.$$.S.Func$$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32)))().$ctor(this,  (/*p*/ p, /*i*/ i) =>
                                    {
                                        return new ($.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32))().$ctor$3(p, i);
                                    }, $lZXYib ??= {"r":$.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32).$h,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h},{"n":"i","p":655361}],"n":"","d":1018108,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32), $.$$.S.String))().$ctor(this,  (/*kv*/ kv) =>
                                    {
                                        return "arg" + kv.Item2;
                                    }, $CgXqWc ??= {"r":1310721,"p":[{"n":"kv","p":$.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32).$h}],"n":"","d":1018108,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32), $.$EVvT.LCFCM.MarkdownPlusToken))().$ctor(this,  (/*kv*/ kv) =>
                                    {
                                        return kv.Item1.Value;
                                    }, $tdvveh ??= {"r":1411324,"p":[{"n":"kv","p":$.$$.S.ValueTuple$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$$.S.Int32).$h}],"n":"","d":1018108,"h":0,"f":17825794})));
                                }
                            }
                        }
                        catch(e)
                        {
                            $.$fPer.LCFCL.LoggingFactory.LogException(e, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.MarkdownPlus\\MarkdownPlusParser.cs", "ResolveToken", 525);
                        }
                    }
                    else 
                    {
                        view = (resolver?.LCFCM$IMarkdownPlusTokenMethodResolver$ResolveToken($.$clone(methodName), resolvedParameters, closure) ?? null);
                    }
                    result = view ?? new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$clone(token));
                }
                if (result.Value !== null && !resultName.IsNull)
                {
                    if (resultName.StartsWith($.$fPer.LCFC.Stringy.op_Implicit$3("$"/*MarkdownPlusConst.VariableStartIdentifier*/), 4))
                    {
                        /*var*/ let parameterName = $.$EVvT.LCFCM.MarkdownPlusParser.ResolveParameterName(closure, $.$clone(resultName));
                        closure.Set($.$EVvT.LCFCM.MarkdownPlusToken, parameterName, $.$clone(result));
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(47245658364)
            
            //--TRIMMABLE-BOUNDARY-START(8590952700)
            static /*Stringy */ Expand(/*Stringy*/ token, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590952700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token.IndexOf$1("##"/*MarkdownPlusConst.ExpansionDelimiter*/, 0) < 0)
                {
                    return $.$clone(token);
                }
                /*StringBuilder*/ let builder = new $.$$.ST.StringBuilder().$ctor$1();
                /*int*/ let lastStart = 0;
                /*int*/ let start = 0;
                while((start = token.IndexOf$1("##"/*MarkdownPlusConst.ExpansionDelimiter*/, lastStart)) > 0)
                {
                    let $t8 = token.Span;
                    builder.Append$17($t8.Slice(lastStart, start - lastStart));
                    /*int*/ let keywordStart = ((start + "##"/*MarkdownPlusConst.ExpansionDelimiter*/.length) | 0);
                    /*int*/ let keyworkEnd = token.IndexOf$1("##"/*MarkdownPlusConst.ExpansionDelimiter*/, keywordStart);
                    if (keyworkEnd > keywordStart)
                    {
                        let $t9 = token.Span;
                        /*var*/ let definitionName = $t9.Slice(keywordStart, keyworkEnd - keywordStart).ToString();
                        if (!$.$$.S.String.Contains$1.call(definitionName, /* */ 32))
                        {
                            /*var*/ let values = context.Get($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), $.$strNN("__define__."/*MarkdownPlusConst.DefinePrefix*/) + $.$strNN(definitionName));
                            if (values !== null)
                            {
                                let $en10 = values.GetEnumerator();
                                while ($en10.MoveNext())
                                {
                                    let v = $en10.Current;
                                    {
                                        builder.Append$15(v.Value);
                                    }
                                }
                            }
                            else 
                            {
                                let $t11 = token.Span;
                                builder.Append$17($t11.Slice(start, (((keyworkEnd + "##"/*MarkdownPlusConst.ExpansionDelimiter*/.length) | 0)) - start));
                            }
                        }
                        else 
                        {
                            let $t12 = token.Span;
                            builder.Append$17($t12.Slice(start, (((keyworkEnd + "##"/*MarkdownPlusConst.ExpansionDelimiter*/.length) | 0)) - start));
                        }
                        lastStart = ((keyworkEnd + "##"/*MarkdownPlusConst.ExpansionDelimiter*/.length) | 0);
                    }
                    else 
                    {
                        let $t13 = token.Span;
                        builder.Append$17($t13.Slice(start, $t13.Length - start));
                        break;
                    }
                }
                let $t14 = token.Span;
                builder.Append$17($t14.Slice(lastStart, $t14.Length - lastStart));
                return $.$fPer.LCFC.Stringy.op_Implicit$3(builder.ToString());
            }
            //--TRIMMABLE-BOUNDARY-END(8590952700)
            
            //--TRIMMABLE-BOUNDARY-START(12885919996)
            static /*MarkdownPlusTokenResolverClosure */ GetDefaultMarkdownPlusClosure(/*this IServiceProvider*/ provider, /*string?*/ resolverKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885919996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = new $.$EVvT.LCFCM.MarkdownPlusContext().$ctor$1($.$EVvT.LCFCM.Startup.GetDefaultMarkdownPlusTokenMethodResolverFactory(provider), resolverKey);
                /*var*/ let closure = new $.$EVvT.LCFCM.MarkdownPlusTokenResolverGlobalClosure().$ctor$3(context);
                return closure;
            }
            //--TRIMMABLE-BOUNDARY-END(12885919996)
            
            //--TRIMMABLE-BOUNDARY-START(30065789180)
            static /*IEnumerable<MarkdownPlusToken> */ Parse(/*this Stringy*/ markdown, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusToken))().$ctor$1(function*()
                {
                    /*var*/ let remainingMarkdown;
                    /*var*/ let frontMatter = $.$fPer.LCFCS$6.YamlFrontMatter.GetMetadatas($.$fPer.LCFC.Stringy.op_Implicit$1(markdown), $.$ref(() => remainingMarkdown, ($v) => remainingMarkdown = $v, $.$fPer.LCFC.Stringy));
                    if (frontMatter !== null)
                    {
                        let $en16 = frontMatter.GetEnumerator();
                        while ($en16.MoveNext())
                        {
                            let kv = $en16.Current;
                            {
                                /*var*/ let value = $.$EVvT.LCFCM.MarkdownPlusParser.ResolveToken(kv.Value.Trim(), closure, null);
                                closure.Set($.$EVvT.LCFCM.MarkdownPlusToken, $.$fPer.LCFC.Stringy.op_Implicit$3("$"/*MarkdownPlusConst.VariableStartIdentifier*/ + $.$strNN(kv.Key.ToString())), $.$clone(value));
                            }
                        }
                    }
                    markdown = remainingMarkdown.Trim();
                    /*int*/ let start = 0;
                    /*int*/ let i;
                    for(i = 0; i < markdown.Length; i++)
                    {
                        if (markdown.get_Item$1(i) === /*{*/ 123 && markdown.get_Item$1(((i + 1) | 0)) !== /*{*/ 123)
                        {
                            if (i > start)
                            {
                                yield new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(markdown.Slice(start, ((i - start) | 0)));
                                start = i;
                            }
                            /*int*/ let braceStart = i;
                            /*int*/ let braceEnd = $.$fPer.LCFCS$6.InterpreterExtension.MatchBrace(markdown, braceStart);
                            if (braceEnd < 0)
                            {
                                yield new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(markdown.Slice(start, ((i - start) | 0)));
                                break;
                            }
                            start = ((braceEnd + 1) | 0);
                            i = braceEnd;
                            /*var*/ let token = markdown.Slice(((braceStart + 1) | 0), ((((braceEnd - braceStart) | 0) - 1) | 0)).Trim();
                            token = $.$EVvT.LCFCM.MarkdownPlusParser.Expand($.$clone(token), closure);
                            /*var*/ let tokens = $.$fPer.LCFCS$6.InterpreterExtension.SplitMethodParameter(token, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "," ], null, null));
                            let $en17 = tokens.SCG$IEnumerable$$$GetEnumerator();
                            while ($en17.SC$1$IEnumerator$MoveNext())
                            {
                                let [ _0, _token, sep ] = $.$destructure($en17.SCG$IEnumerator$$$Current, 1, [1]);
                                {
                                    /*var*/ let x = $.$EVvT.LCFCM.MarkdownPlusParser.ResolveToken(_token.Trim(), closure, null);
                                    yield x;
                                }
                            }
                        }
                    }
                    if (i > start)
                    {
                        yield new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(markdown.Slice(start, ((i - start) | 0)));
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30065789180)
            
            //--TRIMMABLE-BOUNDARY-START(38655723772)
            static /*void */ ParseToView(/*this Stringy*/ markdown, /*MarkdownPlusTokenResolverClosure*/ closure, /*Action<OneOf<char, MarkdownPlusToken>>*/ renderToView)
            {
                /*var*/ let remainingMarkdown;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655723772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let frontMatter = $.$fPer.LCFCS$6.YamlFrontMatter.GetMetadatas($.$fPer.LCFC.Stringy.op_Implicit$1(markdown), $.$ref(() => remainingMarkdown, ($v) => remainingMarkdown = $v, $.$fPer.LCFC.Stringy));
                if (frontMatter !== null)
                {
                    let $en19 = frontMatter.GetEnumerator();
                    while ($en19.MoveNext())
                    {
                        let kv = $en19.Current;
                        {
                            /*var*/ let value = $.$EVvT.LCFCM.MarkdownPlusParser.ResolveToken(kv.Value.Trim(), closure, null);
                            closure.Set($.$EVvT.LCFCM.MarkdownPlusToken, $.$fPer.LCFC.Stringy.op_Implicit$3("$"/*MarkdownPlusConst.VariableStartIdentifier*/ + $.$strNN(kv.Key.ToString())), $.$clone(value));
                        }
                    }
                }
                markdown = remainingMarkdown.Trim();
                /*int*/ let i;
                for(i = 0; i < markdown.Length; i++)
                {
                    if (markdown.get_Item$1(i) === /*{*/ 123 && markdown.get_Item$1(((i + 1) | 0)) !== /*{*/ 123)
                    {
                        /*int*/ let braceStart = i;
                        /*int*/ let braceEnd = $.$fPer.LCFCS$6.InterpreterExtension.MatchBrace(markdown, braceStart);
                        if (braceEnd > braceStart)
                        {
                            i = braceEnd;
                            /*var*/ let token = markdown.Slice(((braceStart + 1) | 0), ((((braceEnd - braceStart) | 0) - 1) | 0)).Trim();
                            token = $.$EVvT.LCFCM.MarkdownPlusParser.Expand($.$clone(token), closure);
                            /*var*/ let tokens = $.$fPer.LCFCS$6.InterpreterExtension.SplitMethodParameter(token, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "," ], null, null));
                            let $en20 = tokens.SCG$IEnumerable$$$GetEnumerator();
                            while ($en20.SC$1$IEnumerator$MoveNext())
                            {
                                let [ _0, _token, sep ] = $.$destructure($en20.SCG$IEnumerator$$$Current, 1, [1]);
                                {
                                    /*var*/ let x = $.$EVvT.LCFCM.MarkdownPlusParser.ResolveToken(_token.Trim(), closure, null);
                                    renderToView.Invoke($.$fPer.LCFCO.OneOf$$$($.$$.S.Char, $.$EVvT.LCFCM.MarkdownPlusToken).op_Implicit$1(x));
                                }
                            }
                        }
                        else 
                        {
                            renderToView.Invoke($.$fPer.LCFCO.OneOf$$$($.$$.S.Char, $.$EVvT.LCFCM.MarkdownPlusToken).op_Implicit(markdown.get_Item$1(i)));
                        }
                    }
                    else 
                    {
                        renderToView.Invoke($.$fPer.LCFCO.OneOf$$$($.$$.S.Char, $.$EVvT.LCFCM.MarkdownPlusToken).op_Implicit(markdown.get_Item$1(i)));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655723772)
            
            //--TRIMMABLE-BOUNDARY-START(34360756476)
            static /*IEnumerable<MarkdownPlusToken> */ Parse$1(/*this string?*/ entry, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360756476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$EVvT.LCFCM.MarkdownPlusParser.Parse($.$fPer.LCFC.StringyExtension.AsStringy$1(entry), closure);
            }
            //--TRIMMABLE-BOUNDARY-END(34360756476)
            
            static $h = 1018108;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950691068),
    {
      "r": 64915798,
      "p": [
        {
          "n": "context",
          "p": 1673468
        },
        {
          "n": "token",
          "p": 64915798
        }
      ],
      "n": "ResolveParameterName",
      "d": 1018108,
      "h": 42950691068,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950691068),
//--TRIMMABLE-BOUNDARY-START(21475854588),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 64915798
        }
      ],
      "n": "IsNumber",
      "d": 1018108,
      "h": 21475854588,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475854588),
//--TRIMMABLE-BOUNDARY-START(25770821884),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 64915798
        }
      ],
      "n": "IsQuotedString",
      "d": 1018108,
      "h": 25770821884,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770821884),
//--TRIMMABLE-BOUNDARY-START(4295985404),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 64915798
        }
      ],
      "n": "ContainsVariable",
      "d": 1018108,
      "h": 4295985404,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4295985404),
//--TRIMMABLE-BOUNDARY-START(17180887292),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 64915798
        }
      ],
      "n": "IsDeferedToken",
      "d": 1018108,
      "h": 17180887292,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180887292),
//--TRIMMABLE-BOUNDARY-START(47245658364),
    {
      "r": 1411324,
      "p": [
        {
          "n": "token",
          "p": 64915798
        },
        {
          "n": "closure",
          "p": 1673468
        },
        {
          "n": "parent",
          "p": 624892
        }
      ],
      "n": "ResolveToken",
      "d": 1018108,
      "h": 47245658364,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245658364),
//--TRIMMABLE-BOUNDARY-START(8590952700),
    {
      "r": 64915798,
      "p": [
        {
          "n": "token",
          "p": 64915798
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "Expand",
      "d": 1018108,
      "h": 8590952700,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590952700),
//--TRIMMABLE-BOUNDARY-START(12885919996),
    {
      "r": 1673468,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "resolverKey",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetDefaultMarkdownPlusClosure",
      "d": 1018108,
      "h": 12885919996,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885919996),
//--TRIMMABLE-BOUNDARY-START(30065789180),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "p": [
        {
          "n": "markdown",
          "p": 64915798
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "Parse",
      "d": 1018108,
      "h": 30065789180,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065789180),
//--TRIMMABLE-BOUNDARY-START(38655723772),
    {
      "r": 65537,
      "p": [
        {
          "n": "markdown",
          "p": 64915798
        },
        {
          "n": "closure",
          "p": 1673468
        },
        {
          "n": "renderToView",
          "p": $.$$.S.Action$$($.$fPer.LCFCO.OneOf$$$($.$$.S.Char, $.$EVvT.LCFCM.MarkdownPlusToken)).$h
        }
      ],
      "n": "ParseToView",
      "d": 1018108,
      "h": 38655723772,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655723772),
//--TRIMMABLE-BOUNDARY-START(34360756476),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "p": [
        {
          "n": "entry",
          "p": 1310721
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "Parse",
      "o": "@$1",
      "d": 1018108,
      "h": 34360756476,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360756476)
  ],
  "h": 1018108
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusParser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1018108)
        
        

        //--TRIMMABLE-BOUNDARY-START(2132220)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusUtility`, ($self) => class MarkdownPlusUtility
        {
            //--TRIMMABLE-BOUNDARY-START(42951805180)
            static /*string */ GetStylesParameter(/*this Dictionary<string, MarkdownPlusToken>*/ parameters, /*Stringy*/ methodToken, /*MarkdownPlusTokenResolverClosure*/ closure, /*string?*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951805180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*StringBuilder*/ let builder = new $.$$.ST.StringBuilder().$ctor$1();
                /*var*/ let contextStyle = closure.Get($.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), "styles."/*MarkdownPlusConst.StylePrefix*/ + $.$strNN(methodToken.ToString()));
                /*string?*/  function GetStringParameterValue(/*string*/ k1, /*string*/ k2)
                {
                    /*System.Collections.Generic.Dictionary<string, LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusToken>?*/ let __ca1__;
                    /*System.Collections.Generic.Dictionary<string, LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusToken>?*/ let __ca2__;
                    return $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ $.$strNN(prefix) + $.$strNN(k1), $.$strNN(prefix) + $.$strNN(k2) ], null, null)) ?? ((__ca2__ = contextStyle) !== null ? ($.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken, __ca2__, $.$strNN(prefix) + $.$strNN(k1)).ToString() ?? ((__ca1__ = contextStyle) !== null ? $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken, __ca1__, $.$strNN(prefix) + $.$strNN(k2)).ToString() : null)) : ((__ca1__ = contextStyle) !== null ? $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken, __ca1__, $.$strNN(prefix) + $.$strNN(k2)).ToString() : null));
                }
                /*var*/ let width = GetStringParameterValue.call(this, "w", "width");
                if (width !== null)
                {
                    builder.Append$1(`width:${$.$strNN(width)}px;`);
                }
                /*var*/ let height = GetStringParameterValue.call(this, "h", "height");
                if (height !== null)
                {
                    builder.Append$1(`height:${$.$strNN(height)}px;`);
                }
                /*var*/ let minWidth = GetStringParameterValue.call(this, "miw", "minWidth");
                if (minWidth !== null)
                {
                    builder.Append$1(`min-width:${$.$strNN(minWidth)}px;`);
                }
                /*var*/ let minHeight = GetStringParameterValue.call(this, "mih", "minHeight");
                if (minHeight !== null)
                {
                    builder.Append$1(`min-height:${$.$strNN(minHeight)}px;`);
                }
                /*var*/ let maxWidth = GetStringParameterValue.call(this, "maw", "maxWidth");
                if (maxWidth !== null)
                {
                    builder.Append$1(`max-width:${$.$strNN(maxWidth)}px;`);
                }
                /*var*/ let maxHeight = GetStringParameterValue.call(this, "mah", "maxHeight");
                if (maxHeight !== null)
                {
                    builder.Append$1(`max-height:${$.$strNN(maxHeight)}px;`);
                }
                /*var*/ let color = GetStringParameterValue.call(this, "cl", "color");
                if (color !== null)
                {
                    builder.Append$1(`color:${$.$strNN(color)};`);
                }
                /*var*/ let backgroundColor = GetStringParameterValue.call(this, "bgc", "backgroundColor");
                if (backgroundColor !== null)
                {
                    builder.Append$1(`background-color:${$.$strNN(backgroundColor)};`);
                }
                /*var*/ let pad = GetStringParameterValue.call(this, "pd", "pad");
                if (pad !== null)
                {
                    builder.Append$1(`padding:${$.$strNN(pad)}px;`);
                }
                /*var*/ let margin = GetStringParameterValue.call(this, "mg", "margin");
                if (margin !== null)
                {
                    if (margin === "a")
                    {
                        builder.Append$21(`margin:auto;`);
                    }
                    else 
                    {
                        builder.Append$1(`margin:${$.$strNN(margin)}px;`);
                    }
                }
                /*var*/ let marginX = GetStringParameterValue.call(this, "mgx", "marginX");
                if (marginX !== null)
                {
                    if (marginX === "a")
                    {
                        builder.Append$21(`margin:0 auto;`);
                    }
                    else 
                    {
                        builder.Append$1(`margin:0 ${$.$strNN(marginX)}px;`);
                    }
                }
                /*var*/ let marginY = GetStringParameterValue.call(this, "mgy", "marginY");
                if (marginY !== null)
                {
                    if (marginY === "a")
                    {
                        builder.Append$21(`margin:auto 0;`);
                    }
                    else 
                    {
                        builder.Append$1(`margin:${$.$strNN(marginX)}px 0;`);
                    }
                }
                /*var*/ let marginLeft = GetStringParameterValue.call(this, "mgl", "marginLeft");
                if (marginLeft !== null)
                {
                    if (marginLeft === "a")
                    {
                        builder.Append$21(`margin-left:auto;`);
                    }
                    else 
                    {
                        builder.Append$1(`margin-left:${$.$strNN(marginLeft)}px;`);
                    }
                }
                /*var*/ let marginRight = GetStringParameterValue.call(this, "mgr", "marginRight");
                if (marginRight !== null)
                {
                    if (marginRight === "a")
                    {
                        builder.Append$21(`margin-right:auto;`);
                    }
                    else 
                    {
                        builder.Append$1(`margin-right:${$.$strNN(marginRight)}px;`);
                    }
                }
                /*var*/ let marginTop = GetStringParameterValue.call(this, "mgl", "marginTop");
                if (marginTop !== null)
                {
                    if (marginTop === "a")
                    {
                        builder.Append$21(`margin-top:auto;`);
                    }
                    else 
                    {
                        builder.Append$1(`margin-top:${$.$strNN(marginTop)}px;`);
                    }
                }
                /*var*/ let marginBottom = GetStringParameterValue.call(this, "mgr", "marginBottom");
                if (marginBottom !== null)
                {
                    if (marginBottom === "a")
                    {
                        builder.Append$21(`margin-bottom:auto;`);
                    }
                    else 
                    {
                        builder.Append$1(`margin-bottom:${$.$strNN(marginBottom)}px;`);
                    }
                }
                /*var*/ let border = GetStringParameterValue.call(this, "bd", "border");
                /*var*/ let borderColor = GetStringParameterValue.call(this, "bdc", "borderColor");
                if (border !== null)
                {
                    builder.Append$1(`border:${$.$strNN(border)}px solid ${$.$strNN(borderColor)};`);
                }
                /*var*/ let borderRadius = GetStringParameterValue.call(this, "bdr", "borderRadius");
                if (borderRadius !== null)
                {
                    builder.Append$1(`border-radius:${$.$strNN(borderRadius)}px;`);
                }
                /*var*/ let fontSize = GetStringParameterValue.call(this, "fsz", "fontSize");
                if (fontSize !== null)
                {
                    builder.Append$1(`font-size:${$.$strNN(fontSize)}px;`);
                }
                /*var*/ let fontWeight = GetStringParameterValue.call(this, "fw", "fontWeight");
                if (fontWeight !== null)
                {
                    builder.Append$1(`font-weight:${$.$strNN(fontWeight)};`);
                }
                return builder.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(42951805180)
            
            //--TRIMMABLE-BOUNDARY-START(8592066812)
            static /*object? */ GetClass(/*this Dictionary<string, MarkdownPlusToken>*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592066812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "cls", "class" ], null, null)).Value;
            }
            //--TRIMMABLE-BOUNDARY-END(8592066812)
            
            //--TRIMMABLE-BOUNDARY-START(34361870588)
            static /*object? */ GetSeparator(/*this Dictionary<string, MarkdownPlusToken>*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361870588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "sp", "separator" ], null, null)).Value;
            }
            //--TRIMMABLE-BOUNDARY-END(34361870588)
            
            //--TRIMMABLE-BOUNDARY-START(47246772476)
            static /*string? */ GetWidth(/*this Dictionary<string, MarkdownPlusToken>*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246772476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let width = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "w", "width" ], null, null));
                return width;
            }
            //--TRIMMABLE-BOUNDARY-END(47246772476)
            
            //--TRIMMABLE-BOUNDARY-START(12887034108)
            static /*string? */ GetHeight(/*this Dictionary<string, MarkdownPlusToken>*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887034108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let height = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "h", "height" ], null, null));
                return height;
            }
            //--TRIMMABLE-BOUNDARY-END(12887034108)
            
            //--TRIMMABLE-BOUNDARY-START(17182001404)
            static /*string? */ GetId(/*this Dictionary<string, MarkdownPlusToken>*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182001404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let height = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "id", "identifier" ], null, null));
                return height;
            }
            //--TRIMMABLE-BOUNDARY-END(17182001404)
            
            //--TRIMMABLE-BOUNDARY-START(21476968700)
            static /*MarkdownPlusToken */ GetParameterValue(/*this Dictionary<string, MarkdownPlusToken>*/ parameters, /*int*/ index, /*params string[]*/ keys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476968700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (keys.length > 0)
                {
                    let $i1 = 0;
                    let $arr1 = keys;
                    while ($i1 < $arr1.length)
                    {
                        /*var*/ let value;
                        let key = $arr1[$i1++];
                        if (parameters.Remove(key, $.$ref(() => value, ($v) => value = $v, $.$EVvT.LCFCM.MarkdownPlusToken)))
                        {
                            return value;
                        }
                    }
                }
                if (index >= 0)
                {
                    /*var*/ let val;
                    if (parameters.Remove($.$$.S.Int32.ToString.call(index), $.$ref(() => val, ($v) => val = $v, $.$EVvT.LCFCM.MarkdownPlusToken)))
                    {
                        return val;
                    }
                }
                return new $.$EVvT.LCFCM.MarkdownPlusToken();
            }
            //--TRIMMABLE-BOUNDARY-END(21476968700)
            
            //--TRIMMABLE-BOUNDARY-START(4297099516)
            static /*bool? */ GetBoolParameterValue(/*this Dictionary<string, MarkdownPlusToken>*/ parameters, /*int*/ index, /*params string[]*/ keys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297099516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let vval = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, index, keys);
                let b;
                if ($.$is(vval.Value, $.$$.S.Boolean, { set $v($v){ b = $v; } }))
                {
                    return b;
                }
                /*var*/ let val = vval.ToString();
                if (val === "1")
                {
                    return true;
                }
                if (val === "0")
                {
                    return false;
                }
                if (val === "true")
                {
                    return true;
                }
                if (val === "false")
                {
                    return false;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4297099516)
            
            //--TRIMMABLE-BOUNDARY-START(38656837884)
            static /*string? */ GetStringParameterValue(/*this Dictionary<string, MarkdownPlusToken>*/ parameters, /*int*/ index, /*params string[]*/ keys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656837884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let vval = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, index, keys);
                let b;
                if ($.$is(vval.Value, $.$$.S.Boolean, { set $v($v){ b = $v; } }))
                {
                    return b ? "true" : "false";
                }
                /*var*/ let val = vval.ToString();
                if (val !== null && val.length >= 2 && $.$$.S.String.get_Chars.call(val, 0) === /*'*/ 39 && $.$$.S.String.get_Chars.call(val, ((val.length - 1) | 0)) === /*'*/ 39)
                {
                    val = $.$$.S.String.Substring.call(val, 1, ((val.length - 2) | 0));
                }
                return val;
            }
            //--TRIMMABLE-BOUNDARY-END(38656837884)
            
            //--TRIMMABLE-BOUNDARY-START(25771935996)
            static /*MarkdownPlusToken */ GetRequiredParameterValue(/*this Dictionary<string, MarkdownPlusToken>*/ parameters, /*int*/ index, /*params string[]*/ keys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771935996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let v = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, index, keys);
                if (v.Value === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Required parameter ${$.$strNN(index)}/${$.$strNN($.$$.S.String.Join$10(",", keys))} not provided`);
                }
                return v;
            }
            //--TRIMMABLE-BOUNDARY-END(25771935996)
            
            //--TRIMMABLE-BOUNDARY-START(30066903292)
            static /*string */ GetRequiredStringParameterValue(/*this Dictionary<string, MarkdownPlusToken>*/ parameters, /*int*/ index, /*params string[]*/ keys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066903292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$firstOf($.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, index, keys), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Required parameter ${$.$strNN(index)}/${$.$strNN($.$$.S.String.Join$10(",", keys))} not provided`) });
            }
            //--TRIMMABLE-BOUNDARY-END(30066903292)
            
            static $h = 2132220;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951805180),
    {
      "r": 1310721,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "methodToken",
          "p": 64915798
        },
        {
          "n": "closure",
          "p": 1673468
        },
        {
          "n": "prefix",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetStylesParameter",
      "d": 2132220,
      "h": 42951805180,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951805180),
//--TRIMMABLE-BOUNDARY-START(8592066812),
    {
      "r": 131073,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        }
      ],
      "n": "GetClass",
      "d": 2132220,
      "h": 8592066812,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592066812),
//--TRIMMABLE-BOUNDARY-START(34361870588),
    {
      "r": 131073,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        }
      ],
      "n": "GetSeparator",
      "d": 2132220,
      "h": 34361870588,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361870588),
//--TRIMMABLE-BOUNDARY-START(47246772476),
    {
      "r": 1310721,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        }
      ],
      "n": "GetWidth",
      "d": 2132220,
      "h": 47246772476,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246772476),
//--TRIMMABLE-BOUNDARY-START(12887034108),
    {
      "r": 1310721,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        }
      ],
      "n": "GetHeight",
      "d": 2132220,
      "h": 12887034108,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887034108),
//--TRIMMABLE-BOUNDARY-START(17182001404),
    {
      "r": 1310721,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        }
      ],
      "n": "GetId",
      "d": 2132220,
      "h": 17182001404,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182001404),
//--TRIMMABLE-BOUNDARY-START(21476968700),
    {
      "r": 1411324,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "keys",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "GetParameterValue",
      "d": 2132220,
      "h": 21476968700,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476968700),
//--TRIMMABLE-BOUNDARY-START(4297099516),
    {
      "r": $.$typeNullable($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "keys",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "GetBoolParameterValue",
      "d": 2132220,
      "h": 4297099516,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297099516),
//--TRIMMABLE-BOUNDARY-START(38656837884),
    {
      "r": 1310721,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "keys",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "GetStringParameterValue",
      "d": 2132220,
      "h": 38656837884,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656837884),
//--TRIMMABLE-BOUNDARY-START(25771935996),
    {
      "r": 1411324,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "keys",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "GetRequiredParameterValue",
      "d": 2132220,
      "h": 25771935996,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771935996),
//--TRIMMABLE-BOUNDARY-START(30066903292),
    {
      "r": 1310721,
      "p": [
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "keys",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "GetRequiredStringParameterValue",
      "d": 2132220,
      "h": 30066903292,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066903292)
  ],
  "h": 2132220
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusUtility`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusUtility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2132220)
        
        

        //--TRIMMABLE-BOUNDARY-START(3246332)
        $asm.$cls(`$EVvT.LCFCM.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12888148220)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888148220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_MarkdownPlusTokenMethodResolverFactory(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor($.$EVvT.LCFCM.Startup, ($.$EVvT.LCFCM.Startup.GetDefaultMarkdownPlusTokenMethodResolverFactory))).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$EVvT.LCFCM.ServiceRegistrar, Get_MarkdownPlusTokenMethodResolverFactory, $kzUkIk ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_MarkdownPlusTokenMethodResolverFactory","d":3246332,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12888148220)
            
            //--TRIMMABLE-BOUNDARY-START(8593180924)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593180924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$EVvT.LCFCM.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory, services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory))().$ctor($.$EVvT.LCFCM.Startup, $.$EVvT.LCFCM.Startup.GetDefaultMarkdownPlusTokenMethodResolverFactory));
                $.$EVvT.LCFCMR.Startup.AddMarkdownPlusResolvers(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593180924)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$EVvT.LCFCM.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298213628)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298213628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298213628)
            
            //--TRIMMABLE-BOUNDARY-START(4298213628)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298213628)
            
            static $h = 3246332;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888148220),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 3246332,
      "h": 12888148220,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12888148220),
//--TRIMMABLE-BOUNDARY-START(8593180924),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3246332,
      "h": 8593180924,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8593180924)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298213628),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3246332,
      "h": 4298213628,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298213628)
  ],
  "h": 3246332
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3246332)
        
        

        //--TRIMMABLE-BOUNDARY-START(1870076)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusTokenResolverImport`, ($self) => class MarkdownPlusTokenResolverImport extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25771673852)
            $ctor$1(/*MarkdownPlusTokenResolverRootClosure*/ importer, /*string*/ id, /*Dictionary<string, MarkdownPlusToken>*/ parameters)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771673852);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Importer = importer;
                    this.Id = id;
                    this.Parameters = parameters;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771673852)
            
            //--TRIMMABLE-BOUNDARY-START(94491150588)
            /*MarkdownPlusTokenResolverRootClosure*/ Importer = null;
            //--TRIMMABLE-BOUNDARY-END(94491150588)
            
            //--TRIMMABLE-BOUNDARY-START(81606248700)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(81606248700)
            
            //--TRIMMABLE-BOUNDARY-START(98786117884)
            /*Dictionary<string, MarkdownPlusToken>*/ Parameters = null;
            //--TRIMMABLE-BOUNDARY-END(98786117884)
            
            //--TRIMMABLE-BOUNDARY-START(90196183292)
            /*IMarkdownPlusTemplateFactory?*/ ImportedFactory = null;
            //--TRIMMABLE-BOUNDARY-END(90196183292)
            
            //--TRIMMABLE-BOUNDARY-START(85901215996)
            /*IEnumerable<MarkdownPlusTokenResolverRootClosure>?*/ ImportedClosure = null;
            //--TRIMMABLE-BOUNDARY-END(85901215996)
            
            //--TRIMMABLE-BOUNDARY-START(120260954364)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260954364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(120260954364)
            
            //--TRIMMABLE-BOUNDARY-START(30066641148)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066641148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let imp;
                if ($.$is(obj, $.$EVvT.LCFCM.MarkdownPlusTokenResolverImport, { set $v($v){ imp = $v; } }))
                {
                    return this.Equals$2(imp);
                }
                return $.$$.S.Object.Equals$1.call(this, obj);
            }
            //--TRIMMABLE-BOUNDARY-END(30066641148)
            
            //--TRIMMABLE-BOUNDARY-START(34361608444)
            /*bool */ Equals$2(/*MarkdownPlusTokenResolverImport?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361608444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id === (other?.Id ?? null) && this.Parameters.Count === other.Parameters.Count && $.$sl.SL.Enumerable.All($.$$.S.String, this.Parameters.Keys, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/**/ k) =>
                {
                    /*var*/ let v1 = this.Parameters.get_Item(k).Value;
                    /*var*/ let v2 = other.Parameters.get_Item(k).Value;
                    /*object?*/ let __ca1__;
                    return v1 === v2 || (((__ca1__ = v1) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.Equals$1, v2) : false));
                }, $RJTqVi ??= {"r":262145,"p":[{"n":"k","p":1310721}],"n":"","d":1870076,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(34361608444)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverImport>.Equals(LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverImport?)
            S$IEquatable$LivingThing$Core$Frameworks$Common$MarkdownPlus$MarkdownPlusTokenResolverImport$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            static $h = 1870076;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94491150588),
    {
      "p": 2066684,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721346812,
        "f": 50331649
      },
      "n": "Importer",
      "d": 1870076,
      "h": 94491150588,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491150588),
//--TRIMMABLE-BOUNDARY-START(81606248700),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951543036,
        "f": 50331649
      },
      "n": "Id",
      "d": 1870076,
      "h": 81606248700,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606248700),
//--TRIMMABLE-BOUNDARY-START(98786117884),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311281404,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 1870076,
      "h": 98786117884,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786117884),
//--TRIMMABLE-BOUNDARY-START(90196183292),
    {
      "p": 559356,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131412220,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965987068,
        "f": 83886088
      },
      "n": "ImportedFactory",
      "d": 1870076,
      "h": 90196183292,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196183292),
//--TRIMMABLE-BOUNDARY-START(85901215996),
    {
      "p": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverRootClosure).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541477628,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107376052476,
        "f": 83886081
      },
      "n": "ImportedClosure",
      "d": 1870076,
      "h": 85901215996,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85901215996)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120260954364),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1870076,
      "h": 120260954364,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120260954364),
//--TRIMMABLE-BOUNDARY-START(30066641148),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1870076,
      "h": 30066641148,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066641148),
//--TRIMMABLE-BOUNDARY-START(34361608444),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1870076
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1870076,
      "h": 34361608444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361608444)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771673852),
    {
      "p": [
        {
          "n": "importer",
          "p": 2066684
        },
        {
          "n": "id",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1870076,
      "h": 25771673852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771673852)
  ],
  "h": 1870076
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverImport) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverImport`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTokenResolverImport`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1870076)
        
        

        //--TRIMMABLE-BOUNDARY-START(1673468)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusTokenResolverClosure`, ($self) => class MarkdownPlusTokenResolverClosure extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38656379132)
            $ctor$1(/*MarkdownPlusContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656379132);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Context = context;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656379132)
            
            //--TRIMMABLE-BOUNDARY-START(42951346428)
            $ctor$2(/*MarkdownPlusTokenResolverClosure*/ parent)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951346428);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Context = parent.Context;
                    this.ParentScope = parent;
                    parent.Children.Add(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951346428)
            
            //--TRIMMABLE-BOUNDARY-START(279174547708)
            /*List<IMarkdownPlusTokenMethodResolver>*/ Resolvers = null;
            //--TRIMMABLE-BOUNDARY-END(279174547708)
            
            //--TRIMMABLE-BOUNDARY-START(283469515004)
            /*MarkdownPlusTokenResolverRootClosure */ get RootClosure()
            {
                return this.ParentScope === null ? $.$cast(this, $.$EVvT.LCFCM.MarkdownPlusTokenResolverRootClosure) : this.ParentScope.RootClosure;
            }
            //--TRIMMABLE-BOUNDARY-END(283469515004)
            
            //--TRIMMABLE-BOUNDARY-START(227634940156)
            /*MarkdownPlusTokenResolverGlobalClosure */ get Global()
            {
                return $.$as(this, $.$EVvT.LCFCM.MarkdownPlusTokenResolverGlobalClosure) ?? this.RootClosure.Global$1;
            }
            //--TRIMMABLE-BOUNDARY-END(227634940156)
            
            //--TRIMMABLE-BOUNDARY-START(249109776636)
            /*IEnumerable<IMarkdownPlusTokenMethodResolver> */ get NestedResolvers()
            {
                return $.$sl.SL.Enumerable.Concat($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, this.Resolvers, $.$sl.SL.Enumerable.SelectMany$2($.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure, $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, this.Children, new ($.$$.S.Func$$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure, $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver)))().$ctor(this,  (/**/ c) =>
                {
                    return c.NestedResolvers;
                }, $oWxDmi ??= {"r":$.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver).$h,"p":[{"n":"c","p":1673468}],"n":"","d":1673468,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(249109776636)
            
            //--TRIMMABLE-BOUNDARY-START(60131215612)
            /*MarkdownPlusContext*/ Context = null;
            //--TRIMMABLE-BOUNDARY-END(60131215612)
            
            //--TRIMMABLE-BOUNDARY-START(266289645820)
            /*MarkdownPlusTokenResolverClosure?*/ ParentScope = null;
            //--TRIMMABLE-BOUNDARY-END(266289645820)
            
            //--TRIMMABLE-BOUNDARY-START(231929907452)
            /*MarkdownPlusTokenResolverRootClosure?*/ Importer = null;
            //--TRIMMABLE-BOUNDARY-END(231929907452)
            
            //--TRIMMABLE-BOUNDARY-START(55836248316)
            /*List<MarkdownPlusTokenResolverClosure>*/ Children = null;
            //--TRIMMABLE-BOUNDARY-END(55836248316)
            
            //--TRIMMABLE-BOUNDARY-START(4296640764)
            /*Dictionary<string, object?>*/ _localParameters = null;
            //--TRIMMABLE-BOUNDARY-END(4296640764)
            
            //--TRIMMABLE-BOUNDARY-START(244814809340)
            /*IReadOnlyDictionary<string, object?> */ get LocalParameters()
            {
                return this._localParameters;
            }
            //--TRIMMABLE-BOUNDARY-END(244814809340)
            
            //--TRIMMABLE-BOUNDARY-START(304944351484)
            /*void */ Set(T, /*Stringy*/ name, /*T*/ val)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304944351484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (name.get_Item$1(0) === $.$$.S.String.get_Chars.call("$"/*MarkdownPlusConst.VariableStartIdentifier*/, 0) && name.get_Item$1(1) === $.$$.S.String.get_Chars.call("$"/*MarkdownPlusConst.VariableStartIdentifier*/, 0))
                {
                    /*var*/ let setTargetContext = this;
                    while(name.get_Item$1(1) === $.$$.S.String.get_Chars.call("$"/*MarkdownPlusConst.VariableStartIdentifier*/, 0))
                    {
                        setTargetContext = setTargetContext.ParentScope ?? setTargetContext;
                        name = name.Slice$1(1);
                    }
                    setTargetContext.Set(T, $.$clone(name), val);
                }
                else 
                {
                    this._localParameters.set_Item($.$fPer.LCFC.Stringy.op_Implicit$1(name), $.$box(val, T));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(304944351484)
            
            //--TRIMMABLE-BOUNDARY-START(309239318780)
            /*DisposableDelegate */ SetTemp(T, /*Stringy*/ name, /*T*/ val)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309239318780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._localParameters.Add($.$fPer.LCFC.Stringy.op_Implicit$1(name), $.$box(val, T));
                return new $.$fPer.LCFC.DisposableDelegate().$ctor$3(new $.$$.S.Action().$ctor(this,  () =>
                {
                    return this._localParameters.Remove$1($.$fPer.LCFC.Stringy.op_Implicit$1(name));
                }, $IlRqNa ??= {"r":65537,"n":"","d":1673468,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(309239318780)
            
            //--TRIMMABLE-BOUNDARY-START(223339972860)
            /*T? */ Get(T, /*string*/ name)
            {
                /*var*/ let r;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339972860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ok = this.ResolveParameter(name, $.$ref(() => r, ($v) => r = $v, $.$$.S.Object), 0);
                if (!ok)
                {
                    return $.$default(T);
                }
                if (r !== null && T.$type.IsAssignableFrom($.$$.S.Object.GetType.call(r)))
                {
                    return $.$cast(r, T);
                }
                return $.$default(T);
            }
            //--TRIMMABLE-BOUNDARY-END(223339972860)
            
            //--TRIMMABLE-BOUNDARY-START(317829253372)
            /*object?*/ get_Item$1(/*string*/ name)
            {
                return this.Get($.$$.S.Object, name);
            }
            /*void*/ set_Item$1(/*string*/ name, /*object?*/ value)
            {
                this.Set($.$$.S.Object, $.$fPer.LCFC.Stringy.op_Implicit$3(name), value);
            }
            //--TRIMMABLE-BOUNDARY-END(317829253372)
            
            //--TRIMMABLE-BOUNDARY-START(236224874748)
            /*MarkdownPlusTokenResolverParameterProxy<int> */ get Int()
            {
                return new ($.$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy$$($.$$.S.Int32))().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(236224874748)
            
            //--TRIMMABLE-BOUNDARY-START(240519842044)
            /*MarkdownPlusTokenResolverParameterProxy<int> */ get Integer()
            {
                return new ($.$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy$$($.$$.S.Int32))().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(240519842044)
            
            //--TRIMMABLE-BOUNDARY-START(68721150204)
            /*MarkdownPlusTokenResolverParameterProxy<double> */ get Double()
            {
                return new ($.$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy$$($.$$.S.Double))().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(68721150204)
            
            //--TRIMMABLE-BOUNDARY-START(253404743932)
            /*MarkdownPlusTokenResolverParameterProxy<double> */ get Number()
            {
                return new ($.$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy$$($.$$.S.Double))().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(253404743932)
            
            //--TRIMMABLE-BOUNDARY-START(313534286076)
            /*MarkdownPlusTokenResolverParameterProxy<string> */ get String()
            {
                return new ($.$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy$$($.$$.S.String))().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(313534286076)
            
            //--TRIMMABLE-BOUNDARY-START(261994678524)
            /*IEnumerable<string> */ get ParameterKeys()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.String))().$ctor$1(function*()
                {
                    let $en2 = this.LocalParameters.SCG$IReadOnlyDictionary$$$$Keys.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let key = $en2.SCG$IEnumerator$$$Current;
                        {
                            yield key;
                        }
                    }
                    if (this.ParentScope !== null)
                    {
                        let $en3 = this.ParentScope.ParameterKeys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en3.SCG$IEnumerator$$$Current;
                            {
                                yield key;
                            }
                        }
                    }
                    else 
                    {
                        let $en4 = this.Context.ParameterKeys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en4.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en4.SCG$IEnumerator$$$Current;
                            {
                                yield key;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(261994678524)
            
            //--TRIMMABLE-BOUNDARY-START(274879580412)
            /*bool */ ResolveParameter(/*string*/ name, /*out object?*/ value, /*int*/ depth)
            {
                /*var*/ let val;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879580412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (depth > 20)
                {
                    value.$v = null;
                    return false;
                }
                if (this.LocalParameters.SCG$IReadOnlyDictionary$$$$TryGetValue(name, $.$ref(() => val, ($v) => val = $v, $.$$.S.Object)))
                {
                    value.$v = val;
                    return true;
                }
                if (this.ParentScope !== null)
                {
                    return this.ParentScope.ResolveParameter(name, value, ((depth + 1) | 0));
                }
                if (this.Importer !== null)
                {
                    return this.Importer.ResolveParameter(name, value, ((depth + 1) | 0));
                }
                if (this.Global.ResolveParameter(name, value, ((depth + 1) | 0)))
                {
                    return true;
                }
                return this.Context.ResolveParameter(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(274879580412)
            
            //--TRIMMABLE-BOUNDARY-START(47246313724)
            /*ConcurrentDictionary<string, Lambda>*/ static cachedDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(47246313724)
            
            //--TRIMMABLE-BOUNDARY-START(51541281020)
            /*MarkdownPlusToken */ CachedResolveExpression(/*object*/ _expression, /*Dictionary<string, MarkdownPlusToken>?*/ _parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541281020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (_expression === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`);
                }
                /*IEnumerable<string>?*/ let expressions = null;
                let defered;
                if ($.$is(_expression, $.$EVvT.LCFCM.MarkdownPlusDeferedParameterResolver, { set $v($v){ defered = $v; } }))
                {
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusToken>?*/ let __ca1__;
                    expressions = ((__ca1__ = defered.GetValue(this)) !== null ? ($.$sl.SL.Enumerable.Select$1($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                    {
                        return $.$firstOf(s.ToString(), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`) });
                    }, $DTUtae ??= {"r":1310721,"p":[{"n":"s","p":1411324}],"n":"","d":1673468,"h":0,"f":17825794})) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [$.$firstOf(defered.Token.ToString(), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`) })], null, null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [$.$firstOf(defered.Token.ToString(), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`) })], null, null));
                }
                else 
                {
                    /*var*/ let e = $.$dsp(_expression, $.$$.S.Object, ($t) => $t.ToString);
                    if ($.$$.S.String.IsNullOrEmpty(e))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`);
                    }
                    expressions = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [e], null, null);
                }
                /*List<Parameter>*/ let parameters = (() =>
                {
                    //new $.$$.SCG.List$$($.$HnZw.D.Parameter)()
                    const $t10 = $.$$.SCG.List$$($.$HnZw.D.Parameter);
                    const $i10 = new $t10();
                    $i10.$ctor$1();
                    $i10.Add(new $.$HnZw.D.Parameter().$ctor$2("context", this));
                    return $i10;
                })();
                if (_parameters !== null)
                {
                    let $en11 = _parameters.GetEnumerator();
                    while ($en11.MoveNext())
                    {
                        let pv = $en11.Current;
                        {
                            parameters.Add(new $.$HnZw.D.Parameter().$ctor$2(pv.Key, pv.Value));
                        }
                    }
                }
                /*List<object>?*/ let results = null;
                let $en12 = expressions.SCG$IEnumerable$$$GetEnumerator();
                while ($en12.SC$1$IEnumerator$MoveNext())
                {
                    let mexpression = $en12.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let expression = mexpression;
                        let $en13 = this.ParameterKeys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en13.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en13.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let value;
                                if (!$.$$.S.String.StartsWith$3.call(key, "$"/*MarkdownPlusConst.VariableStartIdentifier*/))
                                {
                                    continue;
                                }
                                if (!$.$$.S.String.Contains$3.call(expression, key))
                                {
                                    continue;
                                }
                                /*var*/ let ok = this.ResolveParameter(key, $.$ref(() => value, ($v) => value = $v, $.$$.S.Object), 0);
                                if (!ok)
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval cannot find named parameter ${$.$strNN(key)}`);
                                }
                                /*var*/ let newKey = $.$$.S.String.Replace$3.call(key, "$", "_");
                                parameters.Add(new $.$HnZw.D.Parameter().$ctor$2(newKey, value));
                                if (expression === newKey)
                                {
                                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(value);
                                }
                            }
                        }
                        expression = $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call(expression, `.${$.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/)}.`, `.${$.$strNN("ParentScope")}.`), `${$.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/)}.`, "context."), `${$.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/)}[`, "context[");
                        /*string?*/ let exp;
                        if ($.$$.S.String.Contains$1.call(expression, /*\"*/ 34))
                        {
                            /*int*/ let where = 0;
                            /*bool*/ let inQuote = false;
                            /*StringBuilder*/ let builtExpression = new $.$$.ST.StringBuilder().$ctor$1();
                            while(where < expression.length)
                            {
                                /*char*/ let c = $.$$.S.String.get_Chars.call(expression, where);
                                if (c === /*\"*/ 34 && (where === 0 || $.$$.S.String.get_Chars.call(expression, ((where - 1) | 0)) !== /*\\*/ 92))
                                {
                                    inQuote = !inQuote;
                                }
                                if (!inQuote && (c === $.$$.S.String.get_Chars.call("$"/*MarkdownPlusConst.VariableStartIdentifier*/, 0)))
                                {
                                    builtExpression.Append$5(/*_*/ 95);
                                }
                                else 
                                {
                                    builtExpression.Append$5(c);
                                }
                                where++;
                            }
                            exp = builtExpression.ToString();
                        }
                        else 
                        {
                            exp = $.$$.S.String.Replace$3.call(expression, "$", "_");
                        }
                        /*var*/ let interpreterParameters = parameters.ToArray();
                        try
                        {
                            /*var*/ let lamda = $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure.cachedDelegate.GetOrAdd(exp, new ($.$$.S.Func$$$($.$$.S.String, $.$HnZw.D.Lambda))().$ctor(this,  (/*exp*/ exp) =>
                            {
                                return this.Global.Interpreter.Parse(exp, $.$sl.SL.Enumerable.ToArray($.$HnZw.D.Parameter, $.$sl.SL.Enumerable.Select$1($.$HnZw.D.Parameter, $.$HnZw.D.Parameter, interpreterParameters, new ($.$$.S.Func$$$($.$HnZw.D.Parameter, $.$HnZw.D.Parameter))().$ctor(this,  (/*p*/ p) =>
                                {
                                    if (p.Value !== null)
                                    {
                                        return new $.$HnZw.D.Parameter().$ctor$3(p.Name, $.$$.S.Object.GetType.call(p.Value), null);
                                    }
                                    return p;
                                }, $pxcrnb ??= {"r":1421427,"p":[{"n":"p","p":1421427}],"n":"","d":1673468,"h":0,"f":17825794}))));
                            }, $TDxqci ??= {"r":1159283,"p":[{"n":"exp","p":1310721}],"n":"","d":1673468,"h":0,"f":17825794}));
                            /*var*/ let r = lamda.Invoke$1(interpreterParameters);
                            if ($.$fPer.LCFC.ArrayCompare.Count(expressions) === 1)
                            {
                                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(r);
                            }
                            results ??= new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                            results.Add(r);
                        }
                        catch(e)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$11($.$strNN($.$strNN(exp) + ":") + $.$strNN(e.Message), e);
                        }
                    }
                }
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(results);
            }
            //--TRIMMABLE-BOUNDARY-END(51541281020)
            
            //--TRIMMABLE-BOUNDARY-START(270584613116)
            /*object? */ ResolveExpression(/*object?*/ _expression, /*Dictionary<string, object?>?*/ _parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584613116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (_expression === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`);
                }
                /*IEnumerable<string>?*/ let expressions = null;
                let defered;
                if ($.$is(_expression, $.$EVvT.LCFCM.MarkdownPlusDeferedParameterResolver, { set $v($v){ defered = $v; } }))
                {
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusToken>?*/ let __ca2__;
                    expressions = ((__ca2__ = defered.GetValue(this)) !== null ? ($.$sl.SL.Enumerable.Select$1($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.String, __ca2__, new ($.$$.S.Func$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                    {
                        return $.$firstOf(s.ToString(), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`) });
                    }, $hFYQmj ??= {"r":1310721,"p":[{"n":"s","p":1411324}],"n":"","d":1673468,"h":0,"f":17825794})) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [$.$firstOf(defered.Token.ToString(), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`) })], null, null)) : $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [$.$firstOf(defered.Token.ToString(), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`) })], null, null));
                }
                else 
                {
                    /*var*/ let e = $.$dspc(_expression, $.$$.S.Object, ($t) => $t.ToString);
                    if ($.$$.S.String.IsNullOrEmpty(e))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`);
                    }
                    expressions = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [e], null, null);
                }
                /*List<Parameter>*/ let parameters = (() =>
                {
                    //new $.$$.SCG.List$$($.$HnZw.D.Parameter)()
                    const $t15 = $.$$.SCG.List$$($.$HnZw.D.Parameter);
                    const $i15 = new $t15();
                    $i15.$ctor$1();
                    $i15.Add(new $.$HnZw.D.Parameter().$ctor$2("context", this));
                    return $i15;
                })();
                if (_parameters !== null)
                {
                    let $en16 = _parameters.GetEnumerator();
                    while ($en16.MoveNext())
                    {
                        let pv = $en16.Current;
                        {
                            parameters.Add(new $.$HnZw.D.Parameter().$ctor$2(pv.Key, pv.Value));
                        }
                    }
                }
                /*List<object>?*/ let results = null;
                let $en17 = expressions.SCG$IEnumerable$$$GetEnumerator();
                while ($en17.SC$1$IEnumerator$MoveNext())
                {
                    let lexpression = $en17.SCG$IEnumerator$$$Current;
                    {
                        if ($.$$.S.String.IsNullOrEmpty(lexpression))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval expression cannot be null or blank`);
                        }
                        /*var*/ let expression = lexpression;
                        let $en18 = $.$sl.SL.Enumerable.OrderByDescending$1($.$$.S.String, $.$$.S.Int32, this.ParameterKeys, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Int32))().$ctor(this,  (/*o*/ o) =>
                        {
                            return o.length;
                        }, $yrfwji ??= {"r":655361,"p":[{"n":"o","p":1310721}],"n":"","d":1673468,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                        while ($en18.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en18.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let value;
                                if (!$.$$.S.String.StartsWith$3.call(key, "$"/*MarkdownPlusConst.VariableStartIdentifier*/))
                                {
                                    continue;
                                }
                                if (!$.$$.S.String.Contains$3.call(expression, key))
                                {
                                    continue;
                                }
                                /*var*/ let ok = this.ResolveParameter(key, $.$ref(() => value, ($v) => value = $v, $.$$.S.Object), 0);
                                if (!ok)
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Eval cannot find named parameter ${$.$strNN(key)}`);
                                }
                                if (value === null || $.$is(value, $.$$.S.String) || $.$is(value, $.$fPer.LCFC.Stringy) || $.$is(value, $.$$.S.Int32) || $.$is(value, $.$EVvT.LCFCM.MarkdownPlusToken))
                                {
                                    /*object?*/ let __ca3__;
                                    let ss;
                                    /*var*/ let valStr = $.$is(value, $.$$.S.String, { set $v($v){ ss = $v; } }) ? `\"${$.$strNN($.$dspc(value, $.$$.S.Object, ($t) => $t.ToString))}\"` : ((__ca3__ = value) !== null ? ($.$dspc(__ca3__, $.$$.S.Object, ($t) => $t.ToString) ?? "null") : "null");
                                    /*var*/ let quotesKey = $.$strNN("\"" + $.$strNN(key)) + "\"";
                                    /*string*/ let placeHolder = "@@@@@@@@@@@@@@@";
                                    expression = $.$$.S.String.Replace$3.call(expression, quotesKey, placeHolder);
                                    expression = $.$$.S.String.Replace$3.call(expression, key, valStr);
                                    expression = $.$$.S.String.Replace$3.call(expression, placeHolder, quotesKey);
                                }
                                else 
                                {
                                    /*var*/ let newKey = $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call(key, "$", "_"), "[", "_"), "]", "_");
                                    parameters.Add(new $.$HnZw.D.Parameter().$ctor$2(newKey, value));
                                    expression = $.$$.S.String.Replace$3.call(expression, key, newKey);
                                    if (expression === newKey)
                                    {
                                        return value;
                                    }
                                }
                            }
                        }
                        expression = $.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call($.$$.S.String.Replace$3.call(expression, `.${$.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/)}.`, `.${$.$strNN("ParentScope")}.`), `${$.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/)}.`, "context."), `${$.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/)}[`, "context[");
                        /*int*/ let where = 0;
                        /*bool*/ let inQuote = false;
                        /*StringBuilder*/ let builtExpression = new $.$$.ST.StringBuilder().$ctor$1();
                        while(where < expression.length)
                        {
                            /*char*/ let c = $.$$.S.String.get_Chars.call(expression, where);
                            if (c === /*\"*/ 34 && (where === 0 || $.$$.S.String.get_Chars.call(expression, ((where - 1) | 0)) !== /*\\*/ 92))
                            {
                                inQuote = !inQuote;
                            }
                            if (!inQuote && c === /*$*/ 36)
                            {
                                builtExpression.Append$5(/*_*/ 95);
                            }
                            else 
                            {
                                builtExpression.Append$5(c);
                            }
                            where++;
                        }
                        /*var*/ let interpreterParameters = parameters.ToArray();
                        /*var*/ let exp = builtExpression.ToString();
                        try
                        {
                            /*var*/ let lamda = this.Global.Interpreter.Parse(exp, interpreterParameters);
                            /*var*/ let r = lamda.Invoke$1(interpreterParameters);
                            if ($.$fPer.LCFC.ArrayCompare.Count(expressions) === 1)
                            {
                                return r;
                            }
                            results ??= new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                            results.Add(r);
                        }
                        catch(e)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$11($.$strNN($.$strNN(exp) + ":") + $.$strNN(e.Message), e);
                        }
                    }
                }
                return results;
            }
            //--TRIMMABLE-BOUNDARY-END(270584613116)
            
            //--TRIMMABLE-BOUNDARY-START(73016117500)
            /*MarkdownPlusToken */ EvaluateExpression(/*object*/ _expression, /*Dictionary<string, MarkdownPlusToken>?*/ _parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016117500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CachedResolveExpression(_expression, _parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(73016117500)
            
            //--TRIMMABLE-BOUNDARY-START(257699711228)
            /*List<QueryOption>*/ Options = null;
            //--TRIMMABLE-BOUNDARY-END(257699711228)
            
            //--TRIMMABLE-BOUNDARY-START(64426182908)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426182908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Resolvers.ForEach(new ($.$$.S.Action$$($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver))().$ctor(this,  (/*r*/ r) =>
                {
                    return (($.$as(r, $.$$.S.IDisposable))?.S$IDisposable$Dispose() ?? null);
                }, $UIiqIf ??= {"r":65537,"p":[{"n":"r","p":624892}],"n":"","d":1673468,"h":0,"f":17825794}));
                this.Children.ForEach(new ($.$$.S.Action$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Dispose();
                }, $zyGNbd ??= {"r":65537,"p":[{"n":"c","p":1673468}],"n":"","d":1673468,"h":0,"f":17825794}));
                if (this.ParentScope !== null)
                {
                    this.ParentScope.Children.Remove(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426182908)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(279174547708)
                this.Resolvers = new ($.$$.SCG.List$$($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(279174547708)
                
                //--TRIMMABLE-BOUNDARY-START(55836248316)
                this.Children = new ($.$$.SCG.List$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(55836248316)
                
                //--TRIMMABLE-BOUNDARY-START(4296640764)
                this._localParameters = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296640764)
                
                //--TRIMMABLE-BOUNDARY-START(257699711228)
                this.Options = new ($.$$.SCG.List$$($.$fPer.LCFCD.QueryOption))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(257699711228)
                
            }
            //--TRIMMABLE-BOUNDARY-START(34361411836)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361411836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(47246313724)
                    this.cachedDelegate = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$HnZw.D.Lambda))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(47246313724)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361411836)
            
            static $h = 1673468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(279174547708),
    {
      "p": $.$$.SCG.List$$($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201865136380,
        "f": 50331649
      },
      "n": "Resolvers",
      "d": 1673468,
      "h": 279174547708,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279174547708),
//--TRIMMABLE-BOUNDARY-START(283469515004),
    {
      "p": 2066684,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210455070972,
        "f": 50331649
      },
      "n": "RootClosure",
      "d": 1673468,
      "h": 283469515004,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283469515004),
//--TRIMMABLE-BOUNDARY-START(227634940156),
    {
      "p": 1804540,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375855868,
        "f": 50331649
      },
      "n": "Global",
      "d": 1673468,
      "h": 227634940156,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227634940156),
//--TRIMMABLE-BOUNDARY-START(249109776636),
    {
      "p": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915463420,
        "f": 50331649
      },
      "n": "NestedResolvers",
      "d": 1673468,
      "h": 249109776636,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249109776636),
//--TRIMMABLE-BOUNDARY-START(60131215612),
    {
      "p": 821500,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195986684,
        "f": 50331649
      },
      "n": "Context",
      "d": 1673468,
      "h": 60131215612,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131215612),
//--TRIMMABLE-BOUNDARY-START(266289645820),
    {
      "p": 1673468,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193275201788,
        "f": 50331649
      },
      "n": "ParentScope",
      "d": 1673468,
      "h": 266289645820,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266289645820),
//--TRIMMABLE-BOUNDARY-START(231929907452),
    {
      "p": 2066684,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965790460,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292059449596,
        "f": 83886081
      },
      "n": "Importer",
      "d": 1673468,
      "h": 231929907452,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231929907452),
//--TRIMMABLE-BOUNDARY-START(55836248316),
    {
      "p": $.$$.SCG.List$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606052092,
        "f": 50331649
      },
      "n": "Children",
      "d": 1673468,
      "h": 55836248316,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836248316),
//--TRIMMABLE-BOUNDARY-START(244814809340),
    {
      "p": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325528828,
        "f": 50331649
      },
      "n": "LocalParameters",
      "d": 1673468,
      "h": 244814809340,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(244814809340),
//--TRIMMABLE-BOUNDARY-START(317829253372),
    {
      "p": 131073,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735594236,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300649384188,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 1673468,
      "h": 317829253372,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(317829253372),
//--TRIMMABLE-BOUNDARY-START(236224874748),
    {
      "p": $.$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy$$($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555725052,
        "f": 50331649
      },
      "n": "Int",
      "d": 1673468,
      "h": 236224874748,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224874748),
//--TRIMMABLE-BOUNDARY-START(240519842044),
    {
      "p": $.$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy$$($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145659644,
        "f": 50331649
      },
      "n": "Integer",
      "d": 1673468,
      "h": 240519842044,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(240519842044),
//--TRIMMABLE-BOUNDARY-START(68721150204),
    {
      "p": $.$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy$$($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785921276,
        "f": 50331649
      },
      "n": "Double",
      "d": 1673468,
      "h": 68721150204,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721150204),
//--TRIMMABLE-BOUNDARY-START(253404743932),
    {
      "p": $.$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy$$($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505398012,
        "f": 50331649
      },
      "n": "Number",
      "d": 1673468,
      "h": 253404743932,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253404743932),
//--TRIMMABLE-BOUNDARY-START(313534286076),
    {
      "p": $.$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219045005564,
        "f": 50331649
      },
      "n": "String",
      "d": 1673468,
      "h": 313534286076,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313534286076),
//--TRIMMABLE-BOUNDARY-START(261994678524),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685267196,
        "f": 50331649
      },
      "n": "ParameterKeys",
      "d": 1673468,
      "h": 261994678524,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261994678524),
//--TRIMMABLE-BOUNDARY-START(257699711228),
    {
      "p": $.$$.SCG.List$$($.$fPer.LCFCD.QueryOption).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095332604,
        "f": 50331649
      },
      "n": "Options",
      "d": 1673468,
      "h": 257699711228,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257699711228)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(304944351484),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 64915798
        },
        {
          "n": "val",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Set",
      "d": 1673468,
      "h": 304944351484,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(304944351484),
//--TRIMMABLE-BOUNDARY-START(309239318780),
    {
      "r": 43944278,
      "p": [
        {
          "n": "name",
          "p": 64915798
        },
        {
          "n": "val",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "SetTemp",
      "d": 1673468,
      "h": 309239318780,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(309239318780),
//--TRIMMABLE-BOUNDARY-START(223339972860),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "Get",
      "d": 1673468,
      "h": 223339972860,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(223339972860),
//--TRIMMABLE-BOUNDARY-START(274879580412),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073,
          "f": 2
        },
        {
          "n": "depth",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ResolveParameter",
      "d": 1673468,
      "h": 274879580412,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(274879580412),
//--TRIMMABLE-BOUNDARY-START(51541281020),
    {
      "r": 1411324,
      "p": [
        {
          "n": "_expression",
          "p": 131073
        },
        {
          "n": "_parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h,
          "f": 65
        }
      ],
      "n": "CachedResolveExpression",
      "d": 1673468,
      "h": 51541281020,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51541281020),
//--TRIMMABLE-BOUNDARY-START(270584613116),
    {
      "r": 131073,
      "p": [
        {
          "n": "_expression",
          "p": 131073
        },
        {
          "n": "_parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
          "f": 65
        }
      ],
      "n": "ResolveExpression",
      "d": 1673468,
      "h": 270584613116,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(270584613116),
//--TRIMMABLE-BOUNDARY-START(73016117500),
    {
      "r": 1411324,
      "p": [
        {
          "n": "_expression",
          "p": 131073
        },
        {
          "n": "_parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h,
          "f": 65
        }
      ],
      "n": "EvaluateExpression",
      "d": 1673468,
      "h": 73016117500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016117500),
//--TRIMMABLE-BOUNDARY-START(64426182908),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1673468,
      "h": 64426182908,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64426182908)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296640764),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "n": "_localParameters",
      "d": 1673468,
      "h": 4296640764,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296640764),
//--TRIMMABLE-BOUNDARY-START(47246313724),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$HnZw.D.Lambda).$h,
      "n": "cachedDelegate",
      "d": 1673468,
      "h": 47246313724,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47246313724)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38656379132),
    {
      "p": [
        {
          "n": "context",
          "p": 821500
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1673468,
      "h": 38656379132,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38656379132),
//--TRIMMABLE-BOUNDARY-START(42951346428),
    {
      "p": [
        {
          "n": "parent",
          "p": 1673468
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1673468,
      "h": 42951346428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951346428)
  ],
  "h": 1673468
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverClosure`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTokenResolverClosure`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1673468)
        
        

        //--TRIMMABLE-BOUNDARY-START(821500)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusContext`, ($self) => class MarkdownPlusContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(90195134716)
            $ctor$2(/*IServiceProxy<MarkdownPlusTokenMethodResolverFactory>*/ resolver, /*string?*/ resolverKey)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195134716);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._resolverFactory = resolver;
                    this.ResolverKey = resolverKey;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(90195134716)
            
            //--TRIMMABLE-BOUNDARY-START(85900167420)
            $ctor$1(/*MarkdownPlusTokenMethodResolverFactory*/ resolver, /*string?*/ resolverKey)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900167420);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._resolverFactory = new ($.$fPer.LCFCS$3.ValueServiceProxy$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory))().$ctor$1(resolver);
                    this.ResolverKey = resolverKey;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85900167420)
            
            //--TRIMMABLE-BOUNDARY-START(4295788796)
            /*IServiceProxy<MarkdownPlusTokenMethodResolverFactory>*/ _resolverFactory = null;
            //--TRIMMABLE-BOUNDARY-END(4295788796)
            
            //--TRIMMABLE-BOUNDARY-START(489627093244)
            /*MarkdownPlusTokenMethodResolverFactory */ get ResolverFactory()
            {
                return this._resolverFactory.LCFCS$3$IServiceProxy$$$Service;
            }
            //--TRIMMABLE-BOUNDARY-END(489627093244)
            
            //--TRIMMABLE-BOUNDARY-START(493922060540)
            /*string?*/ ResolverKey = null;
            //--TRIMMABLE-BOUNDARY-END(493922060540)
            
            //--TRIMMABLE-BOUNDARY-START(416612649212)
            /*bool*/ IsEditor = false;
            //--TRIMMABLE-BOUNDARY-END(416612649212)
            
            //--TRIMMABLE-BOUNDARY-START(511101929724)
            /*double*/ Score = 0;
            //--TRIMMABLE-BOUNDARY-END(511101929724)
            
            //--TRIMMABLE-BOUNDARY-START(158914611452)
            /*string?*/ DefaultBackgroundSound = null;
            //--TRIMMABLE-BOUNDARY-END(158914611452)
            
            //--TRIMMABLE-BOUNDARY-START(111669971196)
            /*IEnumerable<string>?*/ Assets = null;
            //--TRIMMABLE-BOUNDARY-END(111669971196)
            
            //--TRIMMABLE-BOUNDARY-START(425202583804)
            /*IEnumerable<string>? */ get Musics()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483107068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                return _ = ((__ca1__ = this.Assets) !== null ? $.$sl.SL.Enumerable.Where($.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    return $.$$.S.String.Contains$3.call(a, "/music/");
                }, $sntePb ??= {"r":262145,"p":[{"n":"a","p":1310721}],"n":"","d":821500,"h":0,"f":17825794})) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(425202583804)
            
            //--TRIMMABLE-BOUNDARY-START(661425785084)
            /*IEnumerable<string>? */ get Sounds()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022714620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca2__;
                return _ = ((__ca2__ = this.Assets) !== null ? $.$sl.SL.Enumerable.Where($.$$.S.String, __ca2__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    return $.$$.S.String.Contains$3.call(a, "/sound/");
                }, $JirMFk ??= {"r":262145,"p":[{"n":"a","p":1310721}],"n":"","d":821500,"h":0,"f":17825794})) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(661425785084)
            
            //--TRIMMABLE-BOUNDARY-START(180389447932)
            /*IEnumerable<string>? */ get Fonts()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943499516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca3__;
                return _ = ((__ca3__ = this.Assets) !== null ? $.$sl.SL.Enumerable.Where($.$$.S.String, __ca3__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    return $.$$.S.String.Contains$3.call(a, "/font/");
                }, $vkEUpg ??= {"r":262145,"p":[{"n":"a","p":1310721}],"n":"","d":821500,"h":0,"f":17825794})) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(180389447932)
            
            //--TRIMMABLE-BOUNDARY-START(412317681916)
            /*IEnumerable<string>? */ get Images()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123368700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca4__;
                return _ = ((__ca4__ = this.Assets) !== null ? $.$sl.SL.Enumerable.Where($.$$.S.String, __ca4__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    return $.$$.S.String.Contains$3.call(a, "/image/");
                }, $ukPAWb ??= {"r":262145,"p":[{"n":"a","p":1310721}],"n":"","d":821500,"h":0,"f":17825794})) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(412317681916)
            
            //--TRIMMABLE-BOUNDARY-START(124554873084)
            /*IEnumerable<string>? */ get Banners()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044153596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<string>?*/ let __ca5__;
                return _ = ((__ca5__ = this.Assets) !== null ? $.$sl.SL.Enumerable.Where($.$$.S.String, __ca5__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                {
                    return $.$$.S.String.Contains$3.call(a, "/image/banner/");
                }, $geuONc ??= {"r":262145,"p":[{"n":"a","p":1310721}],"n":"","d":821500,"h":0,"f":17825794})) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(124554873084)
            
            //--TRIMMABLE-BOUNDARY-START(433792518396)
            /*EventHandler<bool>?*/ OnAfterRender = null;
            //--TRIMMABLE-BOUNDARY-END(433792518396)
            
            //--TRIMMABLE-BOUNDARY-START(433792518396)
            //--TRIMMABLE-BOUNDARY-START(98785069308)
            add_OnAfterRender(/*EventHandler<bool>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785069308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnAfterRender = $.$$.S.Delegate.Combine$2(this.OnAfterRender, value);
            }
            //--TRIMMABLE-BOUNDARY-END(98785069308)
            
            //--TRIMMABLE-BOUNDARY-START(459562322172)
            remove_OnAfterRender(/*EventHandler<bool>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459562322172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnAfterRender = $.$$.S.Delegate.Remove(this.OnAfterRender, value);
            }
            //--TRIMMABLE-BOUNDARY-END(459562322172)
            
            //--TRIMMABLE-BOUNDARY-END(433792518396)
            
            //--TRIMMABLE-BOUNDARY-START(442382452988)
            /*PropertyChangedEventHandler?*/ PropertyChanged = null;
            //--TRIMMABLE-BOUNDARY-END(442382452988)
            
            //--TRIMMABLE-BOUNDARY-START(442382452988)
            //--TRIMMABLE-BOUNDARY-START(107375003900)
            add_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375003900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Combine$2(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(107375003900)
            
            //--TRIMMABLE-BOUNDARY-START(468152256764)
            remove_PropertyChanged(/*PropertyChangedEventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468152256764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged = $.$$.S.Delegate.Remove(this.PropertyChanged, value);
            }
            //--TRIMMABLE-BOUNDARY-END(468152256764)
            
            //--TRIMMABLE-BOUNDARY-END(442382452988)
            
            //--TRIMMABLE-BOUNDARY-START(450972387580)
            /*void */ RaisePropertyChanged(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972387580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged?.Invoke(this, new $.$so.SC$1.PropertyChangedEventArgs().$ctor$2(name));
            }
            //--TRIMMABLE-BOUNDARY-END(450972387580)
            
            //--TRIMMABLE-BOUNDARY-START(420907616508)
            /*string?*/ LastError = null;
            //--TRIMMABLE-BOUNDARY-END(420907616508)
            
            //--TRIMMABLE-BOUNDARY-START(481037158652)
            /*Task<IMarkdownPlusTemplateFactory?> */ ResolveImport(/*DataId*/ importId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(481037158652);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.Task.FromResult($.$EVvT.LCFCM.IMarkdownPlusTemplateFactory, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(481037158652)
            
            //--TRIMMABLE-BOUNDARY-START(154619644156)
            /*ValueTask<MarkdownPlusTokenResolverRootClosure> */ CreateClosure(/*MarkdownPlusTokenResolverGlobalClosure*/ global, /*string*/ templateString, /*int*/ iteratorIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619644156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$EVvT.LCFCM.MarkdownPlusTokenResolverRootClosure, new $.$EVvT.LCFCM.MarkdownPlusTokenResolverRootClosure().$ctor$3(global, this, templateString));
            }
            //--TRIMMABLE-BOUNDARY-END(154619644156)
            
            //--TRIMMABLE-BOUNDARY-START(498217027836)
            /*void */ SafeExecute(/*Action*/ action)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498217027836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LastError = null;
                try
                {
                    action.Invoke();
                }
                catch(e)
                {
                    this.LastError = e.Message;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(498217027836)
            
            //--TRIMMABLE-BOUNDARY-START(502511995132)
            /*Task *//*async*/  SafeExecute$1(/*Func<Task>*/ action)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(502511995132);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.LastError = null;
                    try
                    {
                        let $t1, $r1;
                        ($t1 = action.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    catch(e)
                    {
                        this.LastError = e.Message;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(502511995132)
            
            //--TRIMMABLE-BOUNDARY-START(506806962428)
            /*Task<T> *//*async*/  SafeExecute$2(T, /*Func<Task<T>>*/ action)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(T), T, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(506806962428);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.LastError = null;
                    try
                    {
                        let $t2, $r2;
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t2 = action.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))));
                    }
                    catch(e)
                    {
                        this.LastError = e.Message;
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$default(T));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(506806962428)
            
            //--TRIMMABLE-BOUNDARY-START(476742191356)
            /*void */ RequestRendering()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476742191356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged?.Invoke(this, new $.$so.SC$1.PropertyChangedEventArgs().$ctor$2(""));
            }
            //--TRIMMABLE-BOUNDARY-END(476742191356)
            
            //--TRIMMABLE-BOUNDARY-START(472447224060)
            /*object?*/ RenderingContainer = null;
            //--TRIMMABLE-BOUNDARY-END(472447224060)
            
            //--TRIMMABLE-BOUNDARY-START(163209578748)
            /*bool*/ firstRenderAfterNewQuestion = true;
            //--TRIMMABLE-BOUNDARY-END(163209578748)
            
            //--TRIMMABLE-BOUNDARY-START(128849840380)
            /*void */ BeginNewRender()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849840380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnAfterRender = null;
                this.firstRenderAfterNewQuestion = true;
            }
            //--TRIMMABLE-BOUNDARY-END(128849840380)
            
            //--TRIMMABLE-BOUNDARY-START(446677420284)
            /*void */ RaiseAfterRender()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677420284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.OnAfterRender !== null)
                {
                    this.OnAfterRender?.Invoke(this, this.firstRenderAfterNewQuestion);
                    this.firstRenderAfterNewQuestion = false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(446677420284)
            
            //--TRIMMABLE-BOUNDARY-START(429497551100)
            /*Dictionary<string, object?>*/ namedParameters = null;
            //--TRIMMABLE-BOUNDARY-END(429497551100)
            
            //--TRIMMABLE-BOUNDARY-START(485332125948)
            /*bool */ ResolveParameter(/*string*/ name, /*out object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485332125948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.namedParameters.TryGetValue(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(485332125948)
            
            //--TRIMMABLE-BOUNDARY-START(438087485692)
            /*IEnumerable<string> */ get ParameterKeys()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.String))().$ctor$1(function*()
                {
                    let $en4 = this.namedParameters.Keys.GetEnumerator();
                    while ($en4.MoveNext())
                    {
                        let key = $en4.Current;
                        {
                            yield key;
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(438087485692)
            
            //--TRIMMABLE-BOUNDARY-START(665720752380)
            /*object?*/ get_Item$1(/*string*/ namedParameter)
            {
                /*var*/ let p;
                if (this.namedParameters.TryGetValue(namedParameter, $.$ref(() => p, ($v) => p = $v, $.$$.S.Object)))
                {
                    return p;
                }
                return null;
            }
            /*void*/ set_Item$1(/*string*/ namedParameter, /*object?*/ value)
            {
                switch(namedParameter)
                {
                    default:
                    this.namedParameters.set_Item(namedParameter, value);
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(665720752380)
            
            //--TRIMMABLE-BOUNDARY-START(133144807676)
            /*bool*/ BgMusicPlaying = false;
            //--TRIMMABLE-BOUNDARY-END(133144807676)
            
            //--TRIMMABLE-BOUNDARY-START(167504546044)
            /*string?*/ Font = null;
            //--TRIMMABLE-BOUNDARY-END(167504546044)
            
            //--TRIMMABLE-BOUNDARY-START(184684415228)
            /*string?*/ FontSize = null;
            //--TRIMMABLE-BOUNDARY-END(184684415228)
            
            //--TRIMMABLE-BOUNDARY-START(171799513340)
            /*string?*/ FontColor = null;
            //--TRIMMABLE-BOUNDARY-END(171799513340)
            
            //--TRIMMABLE-BOUNDARY-START(176094480636)
            /*string?*/ FontHighlightColor = null;
            //--TRIMMABLE-BOUNDARY-END(176094480636)
            
            //--TRIMMABLE-BOUNDARY-START(115964938492)
            /*string?*/ BackgroundBanner = null;
            //--TRIMMABLE-BOUNDARY-END(115964938492)
            
            //--TRIMMABLE-BOUNDARY-START(120259905788)
            /*string?*/ BackgroundColor = null;
            //--TRIMMABLE-BOUNDARY-END(120259905788)
            
            //--TRIMMABLE-BOUNDARY-START(146029709564)
            /*string?*/ ButtonControlFontSize = null;
            //--TRIMMABLE-BOUNDARY-END(146029709564)
            
            //--TRIMMABLE-BOUNDARY-START(137439774972)
            /*string?*/ ButtonControlBackgroundColor = null;
            //--TRIMMABLE-BOUNDARY-END(137439774972)
            
            //--TRIMMABLE-BOUNDARY-START(141734742268)
            /*string?*/ ButtonControlColor = null;
            //--TRIMMABLE-BOUNDARY-END(141734742268)
            
            //--TRIMMABLE-BOUNDARY-START(150324676860)
            /*Dictionary<string, object>*/ Controls = null;
            //--TRIMMABLE-BOUNDARY-END(150324676860)
            
            //--TRIMMABLE-BOUNDARY-START(8591114258)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.add
            SC$1$INotifyPropertyChanged$add_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591114258)
            
            //--TRIMMABLE-BOUNDARY-START(21476016146)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged.remove
            SC$1$INotifyPropertyChanged$remove_PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_PropertyChanged(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21476016146)
            
            //--TRIMMABLE-BOUNDARY-START(12886081554)
            //Generated interface implemetation for System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            System$ComponentModel$INotifyPropertyChanged$PropertyChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PropertyChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081554)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(429497551100)
                this.namedParameters = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(429497551100)
                
                //--TRIMMABLE-BOUNDARY-START(150324676860)
                this.Controls = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(150324676860)
                
            }
            static $h = 821500;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(489627093244),
    {
      "p": 1476860,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382252910844,
        "f": 50331649
      },
      "n": "ResolverFactory",
      "d": 821500,
      "h": 489627093244,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(489627093244),
//--TRIMMABLE-BOUNDARY-START(493922060540),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390842845436,
        "f": 50331649
      },
      "n": "ResolverKey",
      "d": 821500,
      "h": 493922060540,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(493922060540),
//--TRIMMABLE-BOUNDARY-START(416612649212),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330713303292,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 622771079420,
        "f": 83886081
      },
      "n": "IsEditor",
      "d": 821500,
      "h": 416612649212,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(416612649212),
//--TRIMMABLE-BOUNDARY-START(511101929724),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399432780028,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 657130817788,
        "f": 83886084
      },
      "n": "Score",
      "d": 821500,
      "h": 511101929724,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(511101929724),
//--TRIMMABLE-BOUNDARY-START(158914611452),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583761148,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 579821406460,
        "f": 83886084
      },
      "n": "DefaultBackgroundSound",
      "d": 821500,
      "h": 158914611452,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914611452),
//--TRIMMABLE-BOUNDARY-START(111669971196),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274349820,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 519691864316,
        "f": 83886084
      },
      "n": "Assets",
      "d": 821500,
      "h": 111669971196,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669971196),
//--TRIMMABLE-BOUNDARY-START(425202583804),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356483107068,
        "f": 50331777
      },
      "n": "Musics",
      "d": 821500,
      "h": 425202583804,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(425202583804),
//--TRIMMABLE-BOUNDARY-START(661425785084),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408022714620,
        "f": 50331777
      },
      "n": "Sounds",
      "d": 821500,
      "h": 661425785084,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(661425785084),
//--TRIMMABLE-BOUNDARY-START(180389447932),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304943499516,
        "f": 50331777
      },
      "n": "Fonts",
      "d": 821500,
      "h": 180389447932,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(180389447932),
//--TRIMMABLE-BOUNDARY-START(412317681916),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322123368700,
        "f": 50331777
      },
      "n": "Images",
      "d": 821500,
      "h": 412317681916,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(412317681916),
//--TRIMMABLE-BOUNDARY-START(124554873084),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219044153596,
        "f": 50331777
      },
      "n": "Banners",
      "d": 821500,
      "h": 124554873084,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(124554873084),
//--TRIMMABLE-BOUNDARY-START(420907616508),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347893172476,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 639950948604,
        "f": 83886082
      },
      "n": "LastError",
      "d": 821500,
      "h": 420907616508,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(420907616508),
//--TRIMMABLE-BOUNDARY-START(472447224060),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373662976252,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 648540883196,
        "f": 83886081
      },
      "n": "RenderingContainer",
      "d": 821500,
      "h": 472447224060,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(472447224060),
//--TRIMMABLE-BOUNDARY-START(438087485692),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365073041660,
        "f": 50331777
      },
      "n": "ParameterKeys",
      "d": 821500,
      "h": 438087485692,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(438087485692),
//--TRIMMABLE-BOUNDARY-START(665720752380),
    {
      "p": 131073,
      "i": [
        {
          "n": "namedParameter",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 339303237884,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 631361014012,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 821500,
      "h": 665720752380,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(665720752380),
//--TRIMMABLE-BOUNDARY-START(133144807676),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634088188,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 545461668092,
        "f": 83886081
      },
      "n": "BgMusicPlaying",
      "d": 821500,
      "h": 133144807676,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144807676),
//--TRIMMABLE-BOUNDARY-START(167504546044),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173695740,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 588411341052,
        "f": 83886081
      },
      "n": "Font",
      "d": 821500,
      "h": 167504546044,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504546044),
//--TRIMMABLE-BOUNDARY-START(184684415228),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313533434108,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 614181144828,
        "f": 83886081
      },
      "n": "FontSize",
      "d": 821500,
      "h": 184684415228,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684415228),
//--TRIMMABLE-BOUNDARY-START(171799513340),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287763630332,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 597001275644,
        "f": 83886081
      },
      "n": "FontColor",
      "d": 821500,
      "h": 171799513340,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799513340),
//--TRIMMABLE-BOUNDARY-START(176094480636),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296353564924,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 605591210236,
        "f": 83886081
      },
      "n": "FontHighlightColor",
      "d": 821500,
      "h": 176094480636,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176094480636),
//--TRIMMABLE-BOUNDARY-START(115964938492),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864284412,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 528281798908,
        "f": 83886081
      },
      "n": "BackgroundBanner",
      "d": 821500,
      "h": 115964938492,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964938492),
//--TRIMMABLE-BOUNDARY-START(120259905788),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210454219004,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 536871733500,
        "f": 83886081
      },
      "n": "BackgroundColor",
      "d": 821500,
      "h": 120259905788,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259905788),
//--TRIMMABLE-BOUNDARY-START(146029709564),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403891964,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 571231471868,
        "f": 83886081
      },
      "n": "ButtonControlFontSize",
      "d": 821500,
      "h": 146029709564,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029709564),
//--TRIMMABLE-BOUNDARY-START(137439774972),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236224022780,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 554051602684,
        "f": 83886081
      },
      "n": "ButtonControlBackgroundColor",
      "d": 821500,
      "h": 137439774972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439774972),
//--TRIMMABLE-BOUNDARY-START(141734742268),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813957372,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 562641537276,
        "f": 83886081
      },
      "n": "ButtonControlColor",
      "d": 821500,
      "h": 141734742268,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734742268),
//--TRIMMABLE-BOUNDARY-START(150324676860),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993826556,
        "f": 50331649
      },
      "n": "Controls",
      "d": 821500,
      "h": 150324676860,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324676860)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(450972387580),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "RaisePropertyChanged",
      "d": 821500,
      "h": 450972387580,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(450972387580),
//--TRIMMABLE-BOUNDARY-START(481037158652),
    {
      "r": $.$$.STT.Task$$($.$EVvT.LCFCM.IMarkdownPlusTemplateFactory).$h,
      "p": [
        {
          "n": "importId",
          "p": 10455382
        }
      ],
      "n": "ResolveImport",
      "d": 821500,
      "h": 481037158652,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(481037158652),
//--TRIMMABLE-BOUNDARY-START(154619644156),
    {
      "r": $.$$.STT.ValueTask$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverRootClosure).$h,
      "p": [
        {
          "n": "global",
          "p": 1804540
        },
        {
          "n": "templateString",
          "p": 1310721
        },
        {
          "n": "iteratorIndex",
          "p": 655361
        }
      ],
      "n": "CreateClosure",
      "d": 821500,
      "h": 154619644156,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(154619644156),
//--TRIMMABLE-BOUNDARY-START(498217027836),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": 43122689
        }
      ],
      "n": "SafeExecute",
      "d": 821500,
      "h": 498217027836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(498217027836),
//--TRIMMABLE-BOUNDARY-START(502511995132),
    {
      "r": 178454529,
      "p": [
        {
          "n": "action",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h
        }
      ],
      "n": "SafeExecute",
      "o": "@$1",
      "d": 821500,
      "h": 502511995132,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(502511995132),
//--TRIMMABLE-BOUNDARY-START(506806962428),
    {
      "r": (T) => $.$$.STT.Task$$(T).$h,
      "p": [
        {
          "n": "action",
          "p": (T) => $.$$.S.Func$$($.$$.STT.Task$$(T)).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "SafeExecute",
      "o": "@$2",
      "d": 821500,
      "h": 506806962428,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(506806962428),
//--TRIMMABLE-BOUNDARY-START(476742191356),
    {
      "r": 65537,
      "n": "RequestRendering",
      "d": 821500,
      "h": 476742191356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(476742191356),
//--TRIMMABLE-BOUNDARY-START(128849840380),
    {
      "r": 65537,
      "n": "BeginNewRender",
      "d": 821500,
      "h": 128849840380,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(128849840380),
//--TRIMMABLE-BOUNDARY-START(446677420284),
    {
      "r": 65537,
      "n": "RaiseAfterRender",
      "d": 821500,
      "h": 446677420284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(446677420284),
//--TRIMMABLE-BOUNDARY-START(485332125948),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "ResolveParameter",
      "d": 821500,
      "h": 485332125948,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(485332125948)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295788796),
    {
      "t": $.$fPer.LCFCS$3.IServiceProxy$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory).$h,
      "n": "_resolverFactory",
      "d": 821500,
      "h": 4295788796,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295788796),
//--TRIMMABLE-BOUNDARY-START(163209578748),
    {
      "t": 262145,
      "n": "firstRenderAfterNewQuestion",
      "d": 821500,
      "h": 163209578748,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(163209578748),
//--TRIMMABLE-BOUNDARY-START(429497551100),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "n": "namedParameters",
      "d": 821500,
      "h": 429497551100,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(429497551100)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(90195134716),
    {
      "p": [
        {
          "n": "resolver",
          "p": $.$fPer.LCFCS$3.IServiceProxy$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory).$h
        },
        {
          "n": "resolverKey",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 821500,
      "h": 90195134716,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195134716),
//--TRIMMABLE-BOUNDARY-START(85900167420),
    {
      "p": [
        {
          "n": "resolver",
          "p": 1476860
        },
        {
          "n": "resolverKey",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 821500,
      "h": 85900167420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900167420)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(433792518396),
    {
      "e": $.$$.S.EventHandler$$($.$$.S.Boolean).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$$.S.Boolean).$h
          }
        ],
        "n": "add_OnAfterRender",
        "d": 821500,
        "h": 98785069308,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$$.S.Boolean).$h
          }
        ],
        "n": "remove_OnAfterRender",
        "d": 821500,
        "h": 459562322172,
        "f": 285212673
      },
      "n": "OnAfterRender",
      "d": 821500,
      "h": 433792518396,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(433792518396),
//--TRIMMABLE-BOUNDARY-START(442382452988),
    {
      "e": 1376274,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "add_PropertyChanged",
        "d": 821500,
        "h": 107375003900,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1376274
          }
        ],
        "n": "remove_PropertyChanged",
        "d": 821500,
        "h": 468152256764,
        "f": 285212673
      },
      "n": "PropertyChanged",
      "d": 821500,
      "h": 442382452988,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(442382452988)
  ],
  "h": 821500
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(821500)
        
        

        //--TRIMMABLE-BOUNDARY-START(690428)
        $asm.$str(`$EVvT.LCFCM.MarkdownPlusCompiledToken`, ($self) => class MarkdownPlusCompiledToken extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(25770494204)
            $ctor$4(/*Stringy*/ expression, /*object*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770494204);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Expression = $.$clone(expression);
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770494204)
            
            //--TRIMMABLE-BOUNDARY-START(21475526908)
            $ctor$3(/*Stringy*/ expression, /*Func<MarkdownPlusContext, object?>*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475526908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Expression = $.$clone(expression);
                    this.ValueDelegate = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475526908)
            
            //--TRIMMABLE-BOUNDARY-START(34360428796)
            /*Stringy*/ Expression;
            //--TRIMMABLE-BOUNDARY-END(34360428796)
            
            //--TRIMMABLE-BOUNDARY-START(94489970940)
            /*object?*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(94489970940)
            
            //--TRIMMABLE-BOUNDARY-START(98784938236)
            /*Func<MarkdownPlusContext, object?>?*/ ValueDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(98784938236)
            
            //--TRIMMABLE-BOUNDARY-START(30065461500)
            /*T */ Execute(T, /*MarkdownPlusContext?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065461500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Value !== null)
                {
                    return $.$cast(this.Value, T);
                }
                if (this.ValueDelegate !== null)
                {
                    if (context !== null)
                    {
                        return $.$cast(this.ValueDelegate.Invoke(context), T);
                    }
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Context required");
                }
                return $.$default(T);
            }
            //--TRIMMABLE-BOUNDARY-END(30065461500)
            
            //--TRIMMABLE-BOUNDARY-START(90195003644)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195003644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFC.Stringy.op_Implicit$1(this.Expression);
            }
            //--TRIMMABLE-BOUNDARY-END(90195003644)
            
            //--TRIMMABLE-BOUNDARY-START(17180559612)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180559612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180559612)
            
            //--TRIMMABLE-BOUNDARY-START(17180559612)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180559612)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Expression = this.Expression.$clone();
                copy.Value = this.Value;
                copy.ValueDelegate = this.ValueDelegate;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34360428796)
                this.Expression = $.$default($.$fPer.LCFC.Stringy);
                //--TRIMMABLE-BOUNDARY-END(34360428796)
                
            }
            static $h = 690428;
            static $z = 21;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360428796),
    {
      "p": 64915798,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950363388,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720167164,
        "f": 83886081
      },
      "n": "Expression",
      "d": 690428,
      "h": 34360428796,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360428796),
//--TRIMMABLE-BOUNDARY-START(94489970940),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540297980,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310101756,
        "f": 83886081
      },
      "n": "Value",
      "d": 690428,
      "h": 94489970940,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489970940),
//--TRIMMABLE-BOUNDARY-START(98784938236),
    {
      "p": $.$$.S.Func$$$($.$EVvT.LCFCM.MarkdownPlusContext, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130232572,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900036348,
        "f": 83886081
      },
      "n": "ValueDelegate",
      "d": 690428,
      "h": 98784938236,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784938236)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065461500),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "context",
          "p": 821500
        }
      ],
      "g": [
        "T"
      ],
      "n": "Execute",
      "d": 690428,
      "h": 30065461500,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(30065461500),
//--TRIMMABLE-BOUNDARY-START(90195003644),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 690428,
      "h": 90195003644,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195003644)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770494204),
    {
      "p": [
        {
          "n": "expression",
          "p": 64915798
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 690428,
      "h": 25770494204,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770494204),
//--TRIMMABLE-BOUNDARY-START(21475526908),
    {
      "p": [
        {
          "n": "expression",
          "p": 64915798
        },
        {
          "n": "value",
          "p": $.$$.S.Func$$$($.$EVvT.LCFCM.MarkdownPlusContext, $.$$.S.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 690428,
      "h": 21475526908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475526908),
//--TRIMMABLE-BOUNDARY-START(17180559612),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 690428,
      "h": 17180559612,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180559612)
  ],
  "h": 690428
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusCompiledToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusCompiledToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(690428)
        
        

        //--TRIMMABLE-BOUNDARY-START(1345788)
        $asm.$str(`$EVvT.LCFCM.MarkdownPlusTemplate`, ($self) => class MarkdownPlusTemplate extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38656051452)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(38656051452)
            
            //--TRIMMABLE-BOUNDARY-START(34361084156)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361084156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCS$6.StringExtension.LimitLength(this.Value, 16, true) ?? super.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(34361084156)
            
            //--TRIMMABLE-BOUNDARY-START(30066116860)
            static /*MarkdownPlusTemplate */ op_Implicit(/*string*/ q)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066116860);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTemplate()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTemplate;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Value = q;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066116860)
            
            //--TRIMMABLE-BOUNDARY-START(8591280380)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591280380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591280380)
            
            //--TRIMMABLE-BOUNDARY-START(8591280380)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8591280380)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Value = this.Value;
                return copy;
            }
            static $h = 1345788;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656051452),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181214972,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25771149564,
        "f": 83886081
      },
      "n": "Value",
      "d": 1345788,
      "h": 38656051452,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "InputType",
              "v": 11,
              "t": 47614294
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656051452)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361084156),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1345788,
      "h": 34361084156,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361084156)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591280380),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1345788,
      "h": 8591280380,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591280380)
  ],
  "h": 1345788
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTemplate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTemplate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1345788)
        
        

        //--TRIMMABLE-BOUNDARY-START(2001148)
        $asm.$str(`$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy<>`, (T) => $asm.$gt(`$EVvT.LCFCM.MarkdownPlusTokenResolverParameterProxy<>`, [T], ($self) => class MarkdownPlusTokenResolverParameterProxy$$ extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12886903036)
            /*MarkdownPlusTokenResolverClosure*/ closure = null;
            //--TRIMMABLE-BOUNDARY-END(12886903036)
            
            //--TRIMMABLE-BOUNDARY-START(8591935740)
            $ctor$3(/*MarkdownPlusTokenResolverClosure*/ closure)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591935740);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.closure = closure;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591935740)
            
            //--TRIMMABLE-BOUNDARY-START(55836575996)
            /*T*/ get_Item$2(/*string*/ name)
            {
                return this.closure.Get(T, name);
            }
            /*void*/ set_Item$2(/*string*/ name, /*T*/ value)
            {
                this.closure.Set(T, $.$fPer.LCFC.Stringy.op_Implicit$3(name), value);
            }
            //--TRIMMABLE-BOUNDARY-END(55836575996)
            
            //--TRIMMABLE-BOUNDARY-START(51541608700)
            /*T*/ get_Item$1(/*int*/ index)
            {
                return this.closure.Get(T, "_" + index);
            }
            /*void*/ set_Item$1(/*int*/ index, /*T*/ value)
            {
                this.closure.Set(T, $.$fPer.LCFC.Stringy.op_Implicit$3("_" + index), value);
            }
            //--TRIMMABLE-BOUNDARY-END(51541608700)
            
            //--TRIMMABLE-BOUNDARY-START(4296968444)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296968444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296968444)
            
            //--TRIMMABLE-BOUNDARY-START(4296968444)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296968444)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.closure = this.closure;
                return copy;
            }
            static $H = 2001148;
            static $h = 2001148;
            static $g = 1;
            static $z = 4;
            static $f = 0b1011000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836575996),
    {
      "p": T?.$h??1572864,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "H": 30066772220,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47246641404,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 83886081
      },
      "n": "Item",
      "o": "@$2",
      "d": this.$h,
      "H": 55836575996,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836575996),
//--TRIMMABLE-BOUNDARY-START(51541608700),
    {
      "p": T?.$h??1572864,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "H": 21476837628,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 38656706812,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "H": 51541608700,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541608700)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886903036),
    {
      "t": 1673468,
      "n": "closure",
      "d": this.$h,
      "H": 12886903036,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886903036)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591935740),
    {
      "p": [
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 8591935740,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591935740),
//--TRIMMABLE-BOUNDARY-START(4296968444),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4296968444,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296968444)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 2001148,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverParameterProxy<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTokenResolverParameterProxy$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2001148)
        
        

        //--TRIMMABLE-BOUNDARY-START(1542396)
        $asm.$str(`$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo`, ($self) => class MarkdownPlusTokenMethodResolverParameterInfo extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21476378876)
            $ctor$3(/*string*/ names, /*string*/ description)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476378876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Names = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [names], null, null);
                    this.Description = description;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476378876)
            
            //--TRIMMABLE-BOUNDARY-START(25771346172)
            $ctor$4(/*string[]*/ names, /*string*/ description)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771346172);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Names = names;
                    this.Description = description;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771346172)
            
            //--TRIMMABLE-BOUNDARY-START(60131084540)
            /*string[]*/ Names = null;
            //--TRIMMABLE-BOUNDARY-END(60131084540)
            
            //--TRIMMABLE-BOUNDARY-START(30066313468)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(30066313468)
            
            //--TRIMMABLE-BOUNDARY-START(64426051836)
            /*bool*/ Required = false;
            //--TRIMMABLE-BOUNDARY-END(64426051836)
            
            //--TRIMMABLE-BOUNDARY-START(17181411580)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181411580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181411580)
            
            //--TRIMMABLE-BOUNDARY-START(17181411580)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17181411580)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Names = this.Names;
                copy.Description = this.Description;
                copy.Required = this.Required;
                return copy;
            }
            static $h = 1542396;
            static $z = 9;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131084540),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246182652,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605921020,
        "f": 83886081
      },
      "n": "Names",
      "d": 1542396,
      "h": 60131084540,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131084540),
//--TRIMMABLE-BOUNDARY-START(30066313468),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656248060,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015986428,
        "f": 83886081
      },
      "n": "Description",
      "d": 1542396,
      "h": 30066313468,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066313468),
//--TRIMMABLE-BOUNDARY-START(64426051836),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836117244,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195855612,
        "f": 83886081
      },
      "n": "Required",
      "d": 1542396,
      "h": 64426051836,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426051836)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476378876),
    {
      "p": [
        {
          "n": "names",
          "p": 1310721
        },
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1542396,
      "h": 21476378876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476378876),
//--TRIMMABLE-BOUNDARY-START(25771346172),
    {
      "p": [
        {
          "n": "names",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1542396,
      "h": 25771346172,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771346172),
//--TRIMMABLE-BOUNDARY-START(17181411580),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1542396,
      "h": 17181411580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181411580)
  ],
  "h": 1542396
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenMethodResolverParameterInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTokenMethodResolverParameterInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1542396)
        
        

        //--TRIMMABLE-BOUNDARY-START(887036)
        $asm.$str(`$EVvT.LCFCM.MarkdownPlusDeferedParameterResolver`, ($self) => class MarkdownPlusDeferedParameterResolver extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17180756220)
            /*MarkdownPlusTokenResolverClosure*/ context = null;
            //--TRIMMABLE-BOUNDARY-END(17180756220)
            
            //--TRIMMABLE-BOUNDARY-START(42950559996)
            /*Func<MarkdownPlusTokenResolverClosure, IEnumerable<MarkdownPlusToken>?>?*/ valueProvider = null;
            //--TRIMMABLE-BOUNDARY-END(42950559996)
            
            //--TRIMMABLE-BOUNDARY-START(12885788924)
            $ctor$3(/*MarkdownPlusTokenResolverClosure*/ context, /*Stringy*/ token, /*Func<MarkdownPlusTokenResolverClosure, IEnumerable<MarkdownPlusToken>?>?*/ valueProvider)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885788924);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.context = context;
                    this.valueProvider = valueProvider;
                    this.Token = $.$clone(token);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885788924)
            
            //--TRIMMABLE-BOUNDARY-START(34360625404)
            /*Stringy*/ Token;
            //--TRIMMABLE-BOUNDARY-END(34360625404)
            
            //--TRIMMABLE-BOUNDARY-START(30065658108)
            /*IEnumerable<MarkdownPlusToken>? */ GetValue(/*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065658108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let vl = (this.valueProvider?.Invoke(closure) ?? null);
                if (vl === null)
                {
                    /*var*/ let value;
                    /*var*/ let ok = this.context.ResolveParameter($.$fPer.LCFC.Stringy.op_Implicit$1(this.Token), $.$ref(() => value, ($v) => value = $v, $.$$.S.Object), 0);
                    if (ok)
                    {
                        vl = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$EVvT.LCFCM.MarkdownPlusToken), [new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(value)], null, null);
                    }
                }
                return vl;
            }
            //--TRIMMABLE-BOUNDARY-END(30065658108)
            
            //--TRIMMABLE-BOUNDARY-START(38655592700)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655592700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let closure = null;
                try
                {
                    closure = new $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure().$ctor$2(this.context);
                    /*var*/ let vl = this.GetValue(closure);
                    if (vl !== null)
                    {
                        return $.$$.S.String.Join$12($.$EVvT.LCFCM.MarkdownPlusToken, "", vl);
                    }
                    return $.$fPer.LCFC.Stringy.op_Implicit$1(this.Token);
                }
                finally
                {
                    closure?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655592700)
            
            //--TRIMMABLE-BOUNDARY-START(8590821628)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590821628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590821628)
            
            //--TRIMMABLE-BOUNDARY-START(8590821628)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590821628)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.context = this.context;
                copy.valueProvider = this.valueProvider;
                copy.Token = this.Token.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34360625404)
                this.Token = $.$default($.$fPer.LCFC.Stringy);
                //--TRIMMABLE-BOUNDARY-END(34360625404)
                
            }
            static $h = 887036;
            static $z = 21;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360625404),
    {
      "p": 64915798,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770690812,
        "f": 50331649
      },
      "n": "Token",
      "d": 887036,
      "h": 34360625404,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360625404)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065658108),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "p": [
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "GetValue",
      "d": 887036,
      "h": 30065658108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065658108),
//--TRIMMABLE-BOUNDARY-START(38655592700),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 887036,
      "h": 38655592700,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655592700)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180756220),
    {
      "t": 1673468,
      "n": "context",
      "d": 887036,
      "h": 17180756220,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180756220),
//--TRIMMABLE-BOUNDARY-START(42950559996),
    {
      "t": $.$$.S.Func$$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure, $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken)).$h,
      "n": "valueProvider",
      "d": 887036,
      "h": 42950559996,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950559996)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885788924),
    {
      "p": [
        {
          "n": "context",
          "p": 1673468
        },
        {
          "n": "token",
          "p": 64915798
        },
        {
          "n": "valueProvider",
          "p": $.$$.S.Func$$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure, $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken)).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 887036,
      "h": 12885788924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885788924),
//--TRIMMABLE-BOUNDARY-START(8590821628),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 887036,
      "h": 8590821628,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590821628)
  ],
  "h": 887036
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusDeferedParameterResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusDeferedParameterResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(887036)
        
        

        //--TRIMMABLE-BOUNDARY-START(1411324)
        $asm.$str(`$EVvT.LCFCM.MarkdownPlusToken`, ($self) => class MarkdownPlusToken extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21476247804)
            $ctor$3(/*object?*/ token)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476247804);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let t;
                    if ($.$is(token, $.$EVvT.LCFCM.MarkdownPlusToken, { set $v($v){ t = $v; } }))
                    {
                        this.Value = t.Value;
                        this.Name = t.Name;
                        this.Order = t.Order;
                    }
                    else 
                    {
                        this.Value = token;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476247804)
            
            //--TRIMMABLE-BOUNDARY-START(90195724540)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(90195724540)
            
            //--TRIMMABLE-BOUNDARY-START(214749776124)
            /*int?*/ Order = null;
            //--TRIMMABLE-BOUNDARY-END(214749776124)
            
            //--TRIMMABLE-BOUNDARY-START(287764220156)
            /*object?*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(287764220156)
            
            //--TRIMMABLE-BOUNDARY-START(81605789948)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605789948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca1__;
                return ((__ca1__ = this.Value) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.GetHashCode) : super.GetHashCode());
            }
            //--TRIMMABLE-BOUNDARY-END(81605789948)
            
            //--TRIMMABLE-BOUNDARY-START(25771215100)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771215100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let tk;
                if ($.$is(obj, $.$EVvT.LCFCM.MarkdownPlusToken, { set $v($v){ tk = $v; } }) && tk.Value !== null)
                {
                    return $.$dspc(tk.Value, $.$$.S.Object, ($t) => $t.Equals$1, this.Value);
                }
                return super.Equals$1(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(25771215100)
            
            //--TRIMMABLE-BOUNDARY-START(283469252860)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469252860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(this.Value, $.$$.S.Delegate))
                {
                    return this.Name;
                }
                /*object?*/ let __ca2__;
                return _ = ((__ca2__ = this.Value) !== null ? $.$dspc(__ca2__, $.$$.S.Object, ($t) => $t.ToString) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(283469252860)
            
            //--TRIMMABLE-BOUNDARY-START(270584350972)
            /*MarkdownPlusToken*/ get_Item$1(/*int*/ index)
            {
                let en;
                if ($.$is(this.Value, $.$$.SC$1.IEnumerable, { set $v($v){ en = $v; } }))
                {
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.Object, $.$sl.SL.Enumerable.Cast($.$$.S.Object, en), index));
                }
                return new $.$EVvT.LCFCM.MarkdownPlusToken();
            }
            //--TRIMMABLE-BOUNDARY-END(270584350972)
            
            //--TRIMMABLE-BOUNDARY-START(274879318268)
            /*MarkdownPlusToken*/ get_Item$2(/*string*/ token)
            {
                let en;
                if ($.$is(this.Value, $.$$.SC$1.IEnumerable, { set $v($v){ en = $v; } }))
                {
                    /*var*/ let i;
                    if ($.$$.S.Int32.TryParse$6(token, $.$ref(() => i, ($v) => i = $v, $.$$.S.Int32)))
                    {
                        return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.Object, $.$sl.SL.Enumerable.Cast($.$$.S.Object, en), i));
                    }
                }
                return new $.$EVvT.LCFCM.MarkdownPlusToken();
            }
            //--TRIMMABLE-BOUNDARY-END(274879318268)
            
            //--TRIMMABLE-BOUNDARY-START(279174285564)
            /*MarkdownPlusToken*/ get_Item$3(/*MarkdownPlusToken*/ token)
            {
                let en;
                if ($.$is(this.Value, $.$$.SC$1.IEnumerable, { set $v($v){ en = $v; } }))
                {
                    /*var*/ let i;
                    if ($.$$.S.Int32.TryParse$6(token.ToString(), $.$ref(() => i, ($v) => i = $v, $.$$.S.Int32)))
                    {
                        return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$sl.SL.Enumerable.ElementAtOrDefault$1($.$$.S.Object, $.$sl.SL.Enumerable.Cast($.$$.S.Object, en), i));
                    }
                }
                return new $.$EVvT.LCFCM.MarkdownPlusToken();
            }
            //--TRIMMABLE-BOUNDARY-END(279174285564)
            
            //--TRIMMABLE-BOUNDARY-START(257699449084)
            static /*MarkdownPlusToken */ op_Implicit$4(/*Stringy*/ _string)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(257699449084);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$clone(_string));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257699449084)
            
            //--TRIMMABLE-BOUNDARY-START(266289383676)
            static /*MarkdownPlusToken */ op_Implicit$6(/*string?*/ _string)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266289383676);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(_string);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266289383676)
            
            //--TRIMMABLE-BOUNDARY-START(261994416380)
            static /*MarkdownPlusToken */ op_Implicit$5(/*ReadOnlyMemory<char>*/ _string)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261994416380);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(_string);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261994416380)
            
            //--TRIMMABLE-BOUNDARY-START(253404481788)
            static /*string? */ op_Implicit$3(/*MarkdownPlusToken*/ _string)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253404481788);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return _string.ToString();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253404481788)
            
            //--TRIMMABLE-BOUNDARY-START(85900757244)
            static /*Stringy */ op_Implicit(/*MarkdownPlusToken*/ _string)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900757244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca3__;
                return $.$fPer.LCFC.Stringy.op_Implicit$3(_ = ((__ca3__ = _string.Value) !== null ? $.$dspc(__ca3__, $.$$.S.Object, ($t) => $t.ToString) : null));
            }
            //--TRIMMABLE-BOUNDARY-END(85900757244)
            
            //--TRIMMABLE-BOUNDARY-START(244814547196)
            static /*double */ op_Implicit$1(/*MarkdownPlusToken*/ _string)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244814547196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.Parse$7($.$dspc(_string.Value, $.$$.S.Object, ($t) => $t.ToString));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244814547196)
            
            //--TRIMMABLE-BOUNDARY-START(249109514492)
            static /*int */ op_Implicit$2(/*MarkdownPlusToken*/ _string)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249109514492);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Int32.Parse$7($.$dspc(_string.Value, $.$$.S.Object, ($t) => $t.ToString));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249109514492)
            
            //--TRIMMABLE-BOUNDARY-START(133145397500)
            static /*bool */ op_Equality$3(/*MarkdownPlusToken*/ s, /*MarkdownPlusToken*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145397500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca4__;
                return s.Value === n.Value || (((__ca4__ = s.Value) !== null ? $.$dspc(__ca4__, $.$$.S.Object, ($t) => $t.Equals$1, n.Value) : false));
            }
            //--TRIMMABLE-BOUNDARY-END(133145397500)
            
            //--TRIMMABLE-BOUNDARY-START(167505135868)
            static /*bool */ op_Inequality$3(/*MarkdownPlusToken*/ s, /*MarkdownPlusToken*/ n)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505135868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca5__;
                return !(s.Value === n.Value || (((__ca5__ = s.Value) !== null ? $.$dspc(__ca5__, $.$$.S.Object, ($t) => $t.Equals$1, n.Value) : false)));
            }
            //--TRIMMABLE-BOUNDARY-END(167505135868)
            
            //--TRIMMABLE-BOUNDARY-START(128850430204)
            static /*bool */ op_Equality$2(/*MarkdownPlusToken*/ s, /*string*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850430204);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return s.ToString() === n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850430204)
            
            //--TRIMMABLE-BOUNDARY-START(163210168572)
            static /*bool */ op_Inequality$2(/*MarkdownPlusToken*/ s, /*string*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163210168572);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return s.ToString() !== n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163210168572)
            
            //--TRIMMABLE-BOUNDARY-START(124555462908)
            static /*bool */ op_Equality$1(/*MarkdownPlusToken*/ s, /*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124555462908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return s.ToString() === $.$$.S.Int32.ToString.call(n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124555462908)
            
            //--TRIMMABLE-BOUNDARY-START(158915201276)
            static /*bool */ op_Inequality$1(/*MarkdownPlusToken*/ s, /*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158915201276);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return s.ToString() !== $.$$.S.Int32.ToString.call(n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915201276)
            
            //--TRIMMABLE-BOUNDARY-START(150325266684)
            static /*bool */ op_GreaterThanOrEqual$1(/*MarkdownPlusToken*/ s, /*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150325266684);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Int32.Parse$7(s.ToString() ?? "") >= n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325266684)
            
            //--TRIMMABLE-BOUNDARY-START(184685005052)
            static /*bool */ op_LessThanOrEqual$1(/*MarkdownPlusToken*/ s, /*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184685005052);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Int32.Parse$7(s.ToString() ?? "") <= n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184685005052)
            
            //--TRIMMABLE-BOUNDARY-START(141735332092)
            static /*bool */ op_GreaterThan$1(/*MarkdownPlusToken*/ s, /*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141735332092);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Int32.Parse$7(s.ToString() ?? "") > n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141735332092)
            
            //--TRIMMABLE-BOUNDARY-START(176095070460)
            static /*bool */ op_LessThan$1(/*MarkdownPlusToken*/ s, /*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176095070460);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Int32.Parse$7(s.ToString() ?? "") < n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176095070460)
            
            //--TRIMMABLE-BOUNDARY-START(98785659132)
            static /*int */ op_Addition$1(/*MarkdownPlusToken*/ s, /*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785659132);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (($.$$.S.Int32.Parse$7(s.ToString() ?? "") + n) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785659132)
            
            //--TRIMMABLE-BOUNDARY-START(206159841532)
            static /*int */ op_Subtraction$1(/*MarkdownPlusToken*/ s, /*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159841532);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (($.$$.S.Int32.Parse$7(s.ToString() ?? "") - n) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159841532)
            
            //--TRIMMABLE-BOUNDARY-START(193274939644)
            static /*int */ op_Multiply$1(/*MarkdownPlusToken*/ s, /*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274939644);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (($.$$.S.Int32.Parse$7(s.ToString() ?? "") * n) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274939644)
            
            //--TRIMMABLE-BOUNDARY-START(111670561020)
            static /*int */ op_Division$1(/*MarkdownPlusToken*/ s, /*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670561020);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.trunc($.$$.S.Int32.Parse$7(s.ToString() ?? "") / n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670561020)
            
            //--TRIMMABLE-BOUNDARY-START(120260495612)
            static /*bool */ op_Equality(/*MarkdownPlusToken*/ s, /*double*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260495612);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return s.ToString() === $.$$.S.Double.ToString.call(n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120260495612)
            
            //--TRIMMABLE-BOUNDARY-START(154620233980)
            static /*bool */ op_Inequality(/*MarkdownPlusToken*/ s, /*double*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154620233980);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return s.ToString() !== $.$$.S.Double.ToString.call(n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154620233980)
            
            //--TRIMMABLE-BOUNDARY-START(146030299388)
            static /*bool */ op_GreaterThanOrEqual(/*MarkdownPlusToken*/ s, /*double*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146030299388);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.Parse$7(s.ToString() ?? "") >= n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146030299388)
            
            //--TRIMMABLE-BOUNDARY-START(180390037756)
            static /*bool */ op_LessThanOrEqual(/*MarkdownPlusToken*/ s, /*double*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180390037756);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.Parse$7(s.ToString() ?? "") <= n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180390037756)
            
            //--TRIMMABLE-BOUNDARY-START(137440364796)
            static /*bool */ op_GreaterThan(/*MarkdownPlusToken*/ s, /*double*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137440364796);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.Parse$7(s.ToString() ?? "") > n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137440364796)
            
            //--TRIMMABLE-BOUNDARY-START(171800103164)
            static /*bool */ op_LessThan(/*MarkdownPlusToken*/ s, /*double*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171800103164);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.Parse$7(s.ToString() ?? "") < n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171800103164)
            
            //--TRIMMABLE-BOUNDARY-START(94490691836)
            static /*double */ op_Addition(/*MarkdownPlusToken*/ s, /*double*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490691836);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.Parse$7(s.ToString() ?? "") + n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490691836)
            
            //--TRIMMABLE-BOUNDARY-START(201864874236)
            static /*double */ op_Subtraction(/*MarkdownPlusToken*/ s, /*double*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201864874236);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.Parse$7(s.ToString() ?? "") - n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864874236)
            
            //--TRIMMABLE-BOUNDARY-START(188979972348)
            static /*double */ op_Multiply(/*MarkdownPlusToken*/ s, /*double*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188979972348);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.Parse$7(s.ToString() ?? "") * n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979972348)
            
            //--TRIMMABLE-BOUNDARY-START(107375593724)
            static /*double */ op_Division(/*MarkdownPlusToken*/ s, /*double*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375593724);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Double.Parse$7(s.ToString() ?? "") / n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375593724)
            
            //--TRIMMABLE-BOUNDARY-START(103080626428)
            static /*double */ op_Addition$2(/*MarkdownPlusToken*/ a, /*MarkdownPlusToken*/ b)
            {
                /*var*/ let aa;
                /*var*/ let bb;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080626428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca6__;
                /*object?*/ let __ca7__;
                if ($.$$.S.Double.TryParse$6(((__ca6__ = a.Value) !== null ? $.$dspc(__ca6__, $.$$.S.Object, ($t) => $t.ToString) : null), $.$ref(() => aa, ($v) => aa = $v, $.$$.S.Double)) && $.$$.S.Double.TryParse$6(((__ca7__ = b.Value) !== null ? $.$dspc(__ca7__, $.$$.S.Object, ($t) => $t.ToString) : null), $.$ref(() => bb, ($v) => bb = $v, $.$$.S.Double)))
                {
                    return (aa + bb);
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(103080626428)
            
            //--TRIMMABLE-BOUNDARY-START(210454808828)
            static /*double */ op_Subtraction$2(/*MarkdownPlusToken*/ a, /*MarkdownPlusToken*/ b)
            {
                /*var*/ let aa;
                /*var*/ let bb;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454808828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca8__;
                /*object?*/ let __ca9__;
                if ($.$$.S.Double.TryParse$6(((__ca8__ = a.Value) !== null ? $.$dspc(__ca8__, $.$$.S.Object, ($t) => $t.ToString) : null), $.$ref(() => aa, ($v) => aa = $v, $.$$.S.Double)) && $.$$.S.Double.TryParse$6(((__ca9__ = b.Value) !== null ? $.$dspc(__ca9__, $.$$.S.Object, ($t) => $t.ToString) : null), $.$ref(() => bb, ($v) => bb = $v, $.$$.S.Double)))
                {
                    return aa - bb;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(210454808828)
            
            //--TRIMMABLE-BOUNDARY-START(197569906940)
            static /*double */ op_Multiply$2(/*MarkdownPlusToken*/ a, /*MarkdownPlusToken*/ b)
            {
                /*var*/ let aa;
                /*var*/ let bb;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569906940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca10__;
                /*object?*/ let __ca11__;
                if ($.$$.S.Double.TryParse$6(((__ca10__ = a.Value) !== null ? $.$dspc(__ca10__, $.$$.S.Object, ($t) => $t.ToString) : null), $.$ref(() => aa, ($v) => aa = $v, $.$$.S.Double)) && $.$$.S.Double.TryParse$6(((__ca11__ = b.Value) !== null ? $.$dspc(__ca11__, $.$$.S.Object, ($t) => $t.ToString) : null), $.$ref(() => bb, ($v) => bb = $v, $.$$.S.Double)))
                {
                    return aa * bb;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(197569906940)
            
            //--TRIMMABLE-BOUNDARY-START(115965528316)
            static /*double */ op_Division$2(/*MarkdownPlusToken*/ a, /*MarkdownPlusToken*/ b)
            {
                /*var*/ let aa;
                /*var*/ let bb;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965528316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca12__;
                /*object?*/ let __ca13__;
                if ($.$$.S.Double.TryParse$6(((__ca12__ = a.Value) !== null ? $.$dspc(__ca12__, $.$$.S.Object, ($t) => $t.ToString) : null), $.$ref(() => aa, ($v) => aa = $v, $.$$.S.Double)) && $.$$.S.Double.TryParse$6(((__ca13__ = b.Value) !== null ? $.$dspc(__ca13__, $.$$.S.Object, ($t) => $t.ToString) : null), $.$ref(() => bb, ($v) => bb = $v, $.$$.S.Double)))
                {
                    return aa / bb;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(115965528316)
            
            //--TRIMMABLE-BOUNDARY-START(8612251990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IReadOnlyValueProvider.Value.get
            get LCFCD$IReadOnlyValueProvider$Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12907219286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(8612251990)
            
            //--TRIMMABLE-BOUNDARY-START(17181280508)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181280508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181280508)
            
            //--TRIMMABLE-BOUNDARY-START(17181280508)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17181280508)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.Order = this.Order;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 1411324;
            static $z = 13;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195724540),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130953468,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339710716,
        "f": 83886081
      },
      "n": "Name",
      "d": 1411324,
      "h": 90195724540,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195724540),
//--TRIMMABLE-BOUNDARY-START(214749776124),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720888060,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231929645308,
        "f": 83886081
      },
      "n": "Order",
      "d": 1411324,
      "h": 214749776124,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214749776124),
//--TRIMMABLE-BOUNDARY-START(287764220156),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310822652,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240519579900,
        "f": 83886081
      },
      "n": "Value",
      "d": 1411324,
      "h": 287764220156,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287764220156),
//--TRIMMABLE-BOUNDARY-START(270584350972),
    {
      "p": 1411324,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361149692,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 1411324,
      "h": 270584350972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270584350972),
//--TRIMMABLE-BOUNDARY-START(274879318268),
    {
      "p": 1411324,
      "i": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951084284,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 1411324,
      "h": 274879318268,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(274879318268),
//--TRIMMABLE-BOUNDARY-START(279174285564),
    {
      "p": 1411324,
      "i": [
        {
          "n": "token",
          "p": 1411324
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541018876,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$3",
      "d": 1411324,
      "h": 279174285564,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279174285564)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605789948),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1411324,
      "h": 81605789948,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605789948),
//--TRIMMABLE-BOUNDARY-START(25771215100),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1411324,
      "h": 25771215100,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771215100),
//--TRIMMABLE-BOUNDARY-START(283469252860),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1411324,
      "h": 283469252860,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(283469252860)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476247804),
    {
      "p": [
        {
          "n": "token",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1411324,
      "h": 21476247804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476247804),
//--TRIMMABLE-BOUNDARY-START(17181280508),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1411324,
      "h": 17181280508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181280508)
  ],
  "h": 1411324
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IReadOnlyValueProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1411324)
        
        

        //--TRIMMABLE-BOUNDARY-START(2263292)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusDefineTokenResolver`, ($self) => class MarkdownPlusDefineTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362001660)
            /*string */ get Invocation()
            {
                return "define/gdefine";
            }
            //--TRIMMABLE-BOUNDARY-END(34362001660)
            
            //--TRIMMABLE-BOUNDARY-START(8592197884)
            /*string */ get Description()
            {
                return "Define a constant expression that can later be expanded into other expression using ##name##.\r\nIf you define as ``define(sum, \"$p1+$p2\")``, this can later be inserted into other expression with ``if(##sum##>2, 1, 0)`` and will expand into ``if($p1+$p2>2,1,0)``.\r\n\r\nExample: ``define(sum, \"$p1+$p2\")`` \r\nUsage: ``##sum##``\r\n";
            }
            //--TRIMMABLE-BOUNDARY-END(8592197884)
            
            //--TRIMMABLE-BOUNDARY-START(30067034364)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The name of the expression");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t2 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i2 = new $t2();
                        $i2.$ctor$3("0", "The expression value/equvalent");
                        $i2.Required = true;
                        return $i2;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067034364)
            
            //--TRIMMABLE-BOUNDARY-START(38656968956)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656968956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let target = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                if ($.$fPer.LCFC.Stringy.op_Implicit$1(method) === "gdefine")
                {
                    closure.Global.Set($.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$fPer.LCFC.Stringy.op_Implicit$3($.$strNN("__define__."/*MarkdownPlusConst.DefinePrefix*/) + $.$strNN(target)), parameters);
                }
                else 
                {
                    closure.Set($.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$fPer.LCFC.Stringy.op_Implicit$3($.$strNN("__define__."/*MarkdownPlusConst.DefinePrefix*/) + $.$strNN(target)), parameters);
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38656968956)
            
            //--TRIMMABLE-BOUNDARY-START(4297230588)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297230588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297230588)
            
            //--TRIMMABLE-BOUNDARY-START(4297230588)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297230588)
            
            static $h = 2263292;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362001660),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772067068,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2263292,
      "h": 34362001660,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362001660),
//--TRIMMABLE-BOUNDARY-START(8592197884),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182132476,
        "f": 50364417
      },
      "n": "Description",
      "d": 2263292,
      "h": 8592197884,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592197884)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067034364),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2263292,
      "h": 30067034364,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067034364),
//--TRIMMABLE-BOUNDARY-START(38656968956),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2263292,
      "h": 38656968956,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656968956)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297230588),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2263292,
      "h": 4297230588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297230588)
  ],
  "h": 2263292
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusDefineTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusDefineTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2263292)
        
        

        //--TRIMMABLE-BOUNDARY-START(2394364)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusHelpTokenResolver`, ($self) => class MarkdownPlusHelpTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362132732)
            /*string */ get Invocation()
            {
                return "help";
            }
            //--TRIMMABLE-BOUNDARY-END(34362132732)
            
            //--TRIMMABLE-BOUNDARY-START(8592328956)
            /*string */ get Description()
            {
                return "Display a help message about the question.\r\n\r\nExample: ``help(This is how you do it)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592328956)
            
            //--TRIMMABLE-BOUNDARY-START(30067165436)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("-1", "The messages to display");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067165436)
            
            //--TRIMMABLE-BOUNDARY-START(38657100028)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657100028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let markdownClosure = $.$cast(context, $.$EVvT.LCFCM.MarkdownPlusTokenResolverRootClosure);
                markdownClosure.HelpTokens = parameters.Values;
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38657100028)
            
            //--TRIMMABLE-BOUNDARY-START(4297361660)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297361660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297361660)
            
            //--TRIMMABLE-BOUNDARY-START(4297361660)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297361660)
            
            static $h = 2394364;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362132732),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772198140,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2394364,
      "h": 34362132732,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362132732),
//--TRIMMABLE-BOUNDARY-START(8592328956),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182263548,
        "f": 50364417
      },
      "n": "Description",
      "d": 2394364,
      "h": 8592328956,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592328956)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067165436),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2394364,
      "h": 30067165436,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067165436),
//--TRIMMABLE-BOUNDARY-START(38657100028),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2394364,
      "h": 38657100028,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657100028)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297361660),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2394364,
      "h": 4297361660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297361660)
  ],
  "h": 2394364
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusHelpTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusHelpTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2394364)
        
        

        //--TRIMMABLE-BOUNDARY-START(2722044)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusNumberTokenResolver`, ($self) => class MarkdownPlusNumberTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362460412)
            /*string */ get Invocation()
            {
                return "number";
            }
            //--TRIMMABLE-BOUNDARY-END(34362460412)
            
            //--TRIMMABLE-BOUNDARY-START(8592656636)
            /*string */ get Description()
            {
                return "Represent an explicit number.\r\n\r\nExample: ``number(2)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592656636)
            
            //--TRIMMABLE-BOUNDARY-START(30067493116)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The number to create. eg ``number(2)``");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067493116)
            
            //--TRIMMABLE-BOUNDARY-START(38657427708)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657427708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let value = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                let d;
                if ($.$is(value.Value, $.$$.S.Double, { set $v($v){ d = $v; } }))
                {
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$box(d, $.$$.S.Double));
                }
                let i;
                if ($.$is(value.Value, $.$$.S.Int32, { set $v($v){ i = $v; } }))
                {
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$box(i, $.$$.S.Int32));
                }
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$box($.$$.S.Double.Parse$7(value.ToString()), $.$$.S.Double));
            }
            //--TRIMMABLE-BOUNDARY-END(38657427708)
            
            //--TRIMMABLE-BOUNDARY-START(4297689340)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297689340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297689340)
            
            //--TRIMMABLE-BOUNDARY-START(4297689340)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297689340)
            
            static $h = 2722044;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362460412),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772525820,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2722044,
      "h": 34362460412,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362460412),
//--TRIMMABLE-BOUNDARY-START(8592656636),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182591228,
        "f": 50364417
      },
      "n": "Description",
      "d": 2722044,
      "h": 8592656636,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592656636)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067493116),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2722044,
      "h": 30067493116,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067493116),
//--TRIMMABLE-BOUNDARY-START(38657427708),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2722044,
      "h": 38657427708,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657427708)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297689340),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2722044,
      "h": 4297689340,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297689340)
  ],
  "h": 2722044
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusNumberTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusNumberTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2722044)
        
        

        //--TRIMMABLE-BOUNDARY-START(2328828)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusEvalTokenResolver`, ($self) => class MarkdownPlusEvalTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(38657034492)
            /*string */ get Invocation()
            {
                return "eval";
            }
            //--TRIMMABLE-BOUNDARY-END(38657034492)
            
            //--TRIMMABLE-BOUNDARY-START(12887230716)
            /*string */ get Description()
            {
                return "Evaluate an expression.\r\n\r\nExample: ``eval(2+4)``";
            }
            //--TRIMMABLE-BOUNDARY-END(12887230716)
            
            //--TRIMMABLE-BOUNDARY-START(34362067196)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The expression to evaluate. eg ``eval($p1*2)``");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(34362067196)
            
            //--TRIMMABLE-BOUNDARY-START(4297296124)
            /*IEnumerable<MarkdownPlusToken> */ _ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusToken))().$ctor$1(function*()
                {
                    let $en2 = parameters.Values.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let parameter = $en2.Current;
                        {
                            yield closure.EvaluateExpression($.$clone(parameter), null);
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(4297296124)
            
            //--TRIMMABLE-BOUNDARY-START(42952001788)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952001788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = this._ResolveToken($.$clone(method), parameters, closure);
                if ($.$fPer.LCFC.ArrayCompare.Count(parameters) > 1)
                {
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$sl.SL.Enumerable.Select$1($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Object, result, new ($.$$.S.Func$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Object))().$ctor(this,  (/*r*/ r) =>
                    {
                        return r.Value;
                    }, $dynhIk ??= {"r":131073,"p":[{"n":"r","p":1411324}],"n":"","d":2328828,"h":0,"f":17825794})));
                }
                return $.$sl.SL.Enumerable.Single$1($.$EVvT.LCFCM.MarkdownPlusToken, result);
            }
            //--TRIMMABLE-BOUNDARY-END(42952001788)
            
            //--TRIMMABLE-BOUNDARY-START(8592263420)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592263420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592263420)
            
            //--TRIMMABLE-BOUNDARY-START(8592263420)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592263420)
            
            static $h = 2328828;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38657034492),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067099900,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2328828,
      "h": 38657034492,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38657034492),
//--TRIMMABLE-BOUNDARY-START(12887230716),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477165308,
        "f": 50364417
      },
      "n": "Description",
      "d": 2328828,
      "h": 12887230716,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12887230716)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362067196),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2328828,
      "h": 34362067196,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34362067196),
//--TRIMMABLE-BOUNDARY-START(4297296124),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "_ResolveToken",
      "d": 2328828,
      "h": 4297296124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297296124),
//--TRIMMABLE-BOUNDARY-START(42952001788),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2328828,
      "h": 42952001788,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952001788)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592263420),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2328828,
      "h": 8592263420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592263420)
  ],
  "h": 2328828
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusEvalTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusEvalTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2328828)
        
        

        //--TRIMMABLE-BOUNDARY-START(3049724)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusStringTokenResolver`, ($self) => class MarkdownPlusStringTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362788092)
            /*string */ get Invocation()
            {
                return "string/str";
            }
            //--TRIMMABLE-BOUNDARY-END(34362788092)
            
            //--TRIMMABLE-BOUNDARY-START(8592984316)
            /*string */ get Description()
            {
                return "Represent an explicit string.\r\n\r\nExample: ``string(abc)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592984316)
            
            //--TRIMMABLE-BOUNDARY-START(30067820796)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The string to create. eg ``string(abc)``");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067820796)
            
            //--TRIMMABLE-BOUNDARY-START(38657755388)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657755388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let value = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6(value.ToString());
            }
            //--TRIMMABLE-BOUNDARY-END(38657755388)
            
            //--TRIMMABLE-BOUNDARY-START(4298017020)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298017020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298017020)
            
            //--TRIMMABLE-BOUNDARY-START(4298017020)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298017020)
            
            static $h = 3049724;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362788092),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772853500,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 3049724,
      "h": 34362788092,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362788092),
//--TRIMMABLE-BOUNDARY-START(8592984316),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182918908,
        "f": 50364417
      },
      "n": "Description",
      "d": 3049724,
      "h": 8592984316,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592984316)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067820796),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 3049724,
      "h": 30067820796,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067820796),
//--TRIMMABLE-BOUNDARY-START(38657755388),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 3049724,
      "h": 38657755388,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657755388)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298017020),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3049724,
      "h": 4298017020,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298017020)
  ],
  "h": 3049724
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusStringTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusStringTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3049724)
        
        

        //--TRIMMABLE-BOUNDARY-START(2525436)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusIfTokenResolver`, ($self) => class MarkdownPlusIfTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362263804)
            /*string */ get Invocation()
            {
                return "if";
            }
            //--TRIMMABLE-BOUNDARY-END(34362263804)
            
            //--TRIMMABLE-BOUNDARY-START(8592460028)
            /*string */ get Description()
            {
                return "Conditionally execute a statement.\r\n\r\nExample: ``if(1>2, greater, less)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592460028)
            
            //--TRIMMABLE-BOUNDARY-START(30067296508)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The condition expression");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t2 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i2 = new $t2();
                        $i2.$ctor$3("1", "If the condition is true, this statement is executed");
                        $i2.Required = true;
                        return $i2;
                    })();
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("2", "If the condition is false, this statement is executed");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067296508)
            
            //--TRIMMABLE-BOUNDARY-START(38657231100)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657231100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/  function AsBool(/*MarkdownPlusToken*/ expression)
                {
                    /*bool*/ let _if = false;
                    let bl;
                    if ($.$is(expression.Value, $.$$.S.Boolean, { set $v($v){ bl = $v; } }))
                    {
                        _if = bl;
                    }
                    else 
                    {
                        if (expression.Value !== null)
                        {
                            /*var*/ let v = closure.EvaluateExpression(expression.Value, null);
                            let ii;
                            if ($.$is(v.Value, $.$$.S.Int32, { set $v($v){ ii = $v; } }))
                            {
                                _if = ii > 0;
                            }
                            let dd;
                            if ($.$is(v.Value, $.$$.S.Double, { set $v($v){ dd = $v; } }))
                            {
                                _if = dd > 0;
                            }
                            else 
                            {
                                _if = v.Value !== null;
                            }
                        }
                    }
                    return _if;
                }
                if (parameters.Count > 3)
                {
                    /*var*/ let parametersCount = parameters.Count;
                    for(/*int*/ let i = 0; i < (parametersCount & ~1); i += 2)
                    {
                        /*var*/ let expression = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredParameterValue(parameters, i, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                        /*var*/ let then = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredParameterValue(parameters, ((i + 1) | 0), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                        if (AsBool.call(this, $.$clone(expression)))
                        {
                            return then;
                        }
                    }
                    if ((parametersCount & 1) === 1)
                    {
                        /*var*/ let $else = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, ((parametersCount - 1) | 0), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                        return $else;
                    }
                    return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
                }
                else 
                {
                    /*var*/ let expression = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                    /*var*/ let then = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                    /*var*/ let $else = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, 2, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                    /*bool*/ let condition = AsBool.call(this, $.$clone(expression));
                    if (condition)
                    {
                        return then;
                    }
                    else 
                    {
                        return $else;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657231100)
            
            //--TRIMMABLE-BOUNDARY-START(4297492732)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297492732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297492732)
            
            //--TRIMMABLE-BOUNDARY-START(4297492732)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297492732)
            
            static $h = 2525436;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362263804),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772329212,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2525436,
      "h": 34362263804,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362263804),
//--TRIMMABLE-BOUNDARY-START(8592460028),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182394620,
        "f": 50364417
      },
      "n": "Description",
      "d": 2525436,
      "h": 8592460028,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592460028)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067296508),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2525436,
      "h": 30067296508,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067296508),
//--TRIMMABLE-BOUNDARY-START(38657231100),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2525436,
      "h": 38657231100,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657231100)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297492732),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2525436,
      "h": 4297492732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297492732)
  ],
  "h": 2525436
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusIfTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusIfTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2525436)
        
        

        //--TRIMMABLE-BOUNDARY-START(3115260)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusStyleTokenResolver`, ($self) => class MarkdownPlusStyleTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362853628)
            /*string */ get Invocation()
            {
                return "style/gstyle";
            }
            //--TRIMMABLE-BOUNDARY-END(34362853628)
            
            //--TRIMMABLE-BOUNDARY-START(8593049852)
            /*string */ get Description()
            {
                return "Style all elements with a name using this styles.\r\n\r\nExample: ``style(flex, bgc:red)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8593049852)
            
            //--TRIMMABLE-BOUNDARY-START(30067886332)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("0", "The name of the element to style.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("-1", "Styles to apply");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067886332)
            
            //--TRIMMABLE-BOUNDARY-START(38657820924)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657820924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let target = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                if ($.$fPer.LCFC.Stringy.op_Implicit$1(method) === "gstyle")
                {
                    context.Global.Set($.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$fPer.LCFC.Stringy.op_Implicit$3($.$strNN("styles."/*MarkdownPlusConst.StylePrefix*/) + $.$strNN(target)), parameters);
                }
                else 
                {
                    context.Set($.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), $.$fPer.LCFC.Stringy.op_Implicit$3($.$strNN("styles."/*MarkdownPlusConst.StylePrefix*/) + $.$strNN(target)), parameters);
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38657820924)
            
            //--TRIMMABLE-BOUNDARY-START(4298082556)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298082556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298082556)
            
            //--TRIMMABLE-BOUNDARY-START(4298082556)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298082556)
            
            static $h = 3115260;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362853628),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772919036,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 3115260,
      "h": 34362853628,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362853628),
//--TRIMMABLE-BOUNDARY-START(8593049852),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182984444,
        "f": 50364417
      },
      "n": "Description",
      "d": 3115260,
      "h": 8593049852,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593049852)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067886332),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 3115260,
      "h": 30067886332,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067886332),
//--TRIMMABLE-BOUNDARY-START(38657820924),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 3115260,
      "h": 38657820924,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657820924)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298082556),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3115260,
      "h": 4298082556,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298082556)
  ],
  "h": 3115260
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusStyleTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusStyleTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3115260)
        
        

        //--TRIMMABLE-BOUNDARY-START(2656508)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusInitTokenResolver`, ($self) => class MarkdownPlusInitTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362394876)
            /*string */ get Invocation()
            {
                return "init";
            }
            //--TRIMMABLE-BOUNDARY-END(34362394876)
            
            //--TRIMMABLE-BOUNDARY-START(8592591100)
            /*string */ get Description()
            {
                return "Initialize variables of a template/skill. The initialized variables can be overriden by the skill importing the template.\r\n\r\nExample: ``init(min:1, max:5)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592591100)
            
            //--TRIMMABLE-BOUNDARY-START(30067427580)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("-1", "The name value pair of the variables");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067427580)
            
            //--TRIMMABLE-BOUNDARY-START(38657362172)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657362172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en1 = parameters.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let p = $en1.Current;
                    {
                        /*var*/ let key = $.$$.S.String.StartsWith$3.call(p.Key, "$"/*MarkdownPlusConst.VariableStartIdentifier*/) ? p.Key : $.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/) + $.$strNN(p.Key);
                        if (context.Importer === null || !context.LocalParameters.SCG$IReadOnlyDictionary$$$$ContainsKey(key))
                        {
                            context.Set($.$EVvT.LCFCM.MarkdownPlusToken, $.$fPer.LCFC.Stringy.op_Implicit$3(key), p.Value);
                        }
                    }
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38657362172)
            
            //--TRIMMABLE-BOUNDARY-START(4297623804)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297623804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297623804)
            
            //--TRIMMABLE-BOUNDARY-START(4297623804)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297623804)
            
            static $h = 2656508;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362394876),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772460284,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2656508,
      "h": 34362394876,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362394876),
//--TRIMMABLE-BOUNDARY-START(8592591100),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182525692,
        "f": 50364417
      },
      "n": "Description",
      "d": 2656508,
      "h": 8592591100,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592591100)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067427580),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2656508,
      "h": 30067427580,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067427580),
//--TRIMMABLE-BOUNDARY-START(38657362172),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2656508,
      "h": 38657362172,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657362172)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297623804),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2656508,
      "h": 4297623804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297623804)
  ],
  "h": 2656508
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusInitTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusInitTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2656508)
        
        

        //--TRIMMABLE-BOUNDARY-START(2459900)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusHiddenTokenResolver`, ($self) => class MarkdownPlusHiddenTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362198268)
            /*string */ get Invocation()
            {
                return "hide";
            }
            //--TRIMMABLE-BOUNDARY-END(34362198268)
            
            //--TRIMMABLE-BOUNDARY-START(8592394492)
            /*string */ get Description()
            {
                return "Execute, but hide the result.\r\n\r\nExample: ``hidden(random(1,5)=>$p1)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592394492)
            
            //--TRIMMABLE-BOUNDARY-START(30067230972)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("-1", "What to execute");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067230972)
            
            //--TRIMMABLE-BOUNDARY-START(38657165564)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657165564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38657165564)
            
            //--TRIMMABLE-BOUNDARY-START(4297427196)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297427196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297427196)
            
            //--TRIMMABLE-BOUNDARY-START(4297427196)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297427196)
            
            static $h = 2459900;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362198268),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772263676,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2459900,
      "h": 34362198268,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362198268),
//--TRIMMABLE-BOUNDARY-START(8592394492),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182329084,
        "f": 50364417
      },
      "n": "Description",
      "d": 2459900,
      "h": 8592394492,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592394492)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067230972),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2459900,
      "h": 30067230972,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067230972),
//--TRIMMABLE-BOUNDARY-START(38657165564),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2459900,
      "h": 38657165564,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657165564)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297427196),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2459900,
      "h": 4297427196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297427196)
  ],
  "h": 2459900
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusHiddenTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusHiddenTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2459900)
        
        

        //--TRIMMABLE-BOUNDARY-START(2918652)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusRepeatTokenResolver`, ($self) => class MarkdownPlusRepeatTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362657020)
            /*string */ get Invocation()
            {
                return "repeat/list";
            }
            //--TRIMMABLE-BOUNDARY-END(34362657020)
            
            //--TRIMMABLE-BOUNDARY-START(8592853244)
            /*string */ get Description()
            {
                return "Repeat in certain number of times. The contents can access variables defined by the repeater as \r\n\r\n$i: the current overall iterator index of the repeater\r\n\r\nExample: ``repeat(2,2,eval($i+\" repeat\"))``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592853244)
            
            //--TRIMMABLE-BOUNDARY-START(30067689724)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The number of times to repeat");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["eg", "eager"], null, null), "Eagerly execute the contents");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("i", "The name to use in place of $i for the overall iterator index");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("-1", "The content to be repeated");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067689724)
            
            //--TRIMMABLE-BOUNDARY-START(38657624316)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657624316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let n = $.$$.S.Int32.Parse$7($.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)));
                /*var*/ let separator = $.$EVvT.LCFCM.MarkdownPlusUtility.GetSeparator(parameters);
                /*var*/ let eager = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "eg", "eager" ], null, null));
                /*var*/ let repeatIteratorName = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "i" ], null, null));
                if (repeatIteratorName !== null)
                {
                    repeatIteratorName = "$" + $.$strNN(repeatIteratorName);
                }
                /*var*/ let val = $.$sl.SL.Enumerable.Last$1($.$EVvT.LCFCM.MarkdownPlusToken, parameters.Values);
                /*Dictionary<int, IEnumerable<MarkdownPlusToken>>*/ let keyedColumn = new ($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken)))().$ctor$1();
                /*var*/ let values = $.$sl.SL.Enumerable.Select$1($.$$.S.Int32, $.$$.S.Object, $.$sl.SL.Enumerable.Range(1, ((n + (separator !== null ? ((n - 1) | 0) : 0)) | 0)), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Object))().$ctor(this,  (/*i*/ i) =>
                {
                    if (separator !== null && (i & 1) === 1)
                    {
                        return separator;
                    }
                    let defered;
                    if ($.$is(val.Value, $.$EVvT.LCFCM.MarkdownPlusDeferedParameterResolver, { set $v($v){ defered = $v; } }))
                    {
                        /*var*/ let views;
                        /*int*/ let iteratorIndex = i;
                        if (separator !== null)
                        {
                            iteratorIndex /= 2;
                        }
                        if (!keyedColumn.TryGetValue(iteratorIndex, $.$ref(() => views, ($v) => views = $v, $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken))))
                        {
                            /*var*/ let iclosure = new $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure().$ctor$2(closure);
                            iclosure.Set($.$$.S.Int32, $.$fPer.LCFC.Stringy.op_Implicit$3(repeatIteratorName ?? "$i"/*MarkdownPlusConst.DefaultRepeatIteratorIndexName*/), iteratorIndex);
                            views = defered.GetValue(iclosure);
                        }
                        return views;
                    }
                    return val;
                }, $hojxij ??= {"r":131073,"p":[{"n":"i","p":655361}],"n":"","d":2918652,"h":0,"f":17825794}));
                if (eager !== null || $.$fPer.LCFC.Stringy.op_Implicit$1(method) === "list")
                {
                    values = $.$sl.SL.Enumerable.ToList($.$$.S.Object, values);
                }
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(values);
            }
            //--TRIMMABLE-BOUNDARY-END(38657624316)
            
            //--TRIMMABLE-BOUNDARY-START(4297885948)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297885948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297885948)
            
            //--TRIMMABLE-BOUNDARY-START(4297885948)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297885948)
            
            static $h = 2918652;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362657020),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772722428,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2918652,
      "h": 34362657020,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362657020),
//--TRIMMABLE-BOUNDARY-START(8592853244),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182787836,
        "f": 50364417
      },
      "n": "Description",
      "d": 2918652,
      "h": 8592853244,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592853244)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067689724),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2918652,
      "h": 30067689724,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067689724),
//--TRIMMABLE-BOUNDARY-START(38657624316),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2918652,
      "h": 38657624316,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657624316)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297885948),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2918652,
      "h": 4297885948,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297885948)
  ],
  "h": 2918652
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusRepeatTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusRepeatTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2918652)
        
        

        //--TRIMMABLE-BOUNDARY-START(2787580)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusRandomTokenResolver`, ($self) => class MarkdownPlusRandomTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362525948)
            /*string */ get Invocation()
            {
                return "random/rand";
            }
            //--TRIMMABLE-BOUNDARY-END(34362525948)
            
            //--TRIMMABLE-BOUNDARY-START(8592722172)
            /*string */ get Description()
            {
                return "Generate a random object or number.\r\n\r\nExampe: ``random(1,5)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592722172)
            
            //--TRIMMABLE-BOUNDARY-START(30067558652)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The object class to generate. eg ``random(image/animal)``\r\nThe maximum number to generate. eg ``random(5)``.\r\nThe minimum and maximum number to generate. eg ``random(1,5)``.");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("1", "The maximum number to generate. eg ``random(5)``.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("2", "The maximum number to generate. eg ``random(1,5)``.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("not", "The number(s) not to include in the generation. eg ``random(5, not:3)``");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067558652)
            
            //--TRIMMABLE-BOUNDARY-START(38657493244)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                /*var*/ let min;
                /*var*/ let max;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657493244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (parameters.Count === 0)
                {
                    return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6(`Error: Random requires at least one parameter`);
                }
                let en;
                if (parameters.Count === 1 && $.$is($.$sl.SL.Enumerable.First$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken), parameters).Value.Value, $.$$.SC$1.IEnumerable, { set $v($v){ en = $v; } }))
                {
                    /*var*/ let ens = $.$sl.SL.Enumerable.Cast($.$$.S.Object, en);
                    /*var*/ let index = $.$$.S.Random.Shared.Next$2($.$fPer.LCFC.ArrayCompare.Count(ens));
                    return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$sl.SL.Enumerable.ElementAt$1($.$$.S.Object, ens, index));
                }
                /*var*/ let pCount = parameters.Count;
                /*var*/ let exclude = $.$EVvT.LCFCM.MarkdownPlusUtility.GetParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "not" ], null, null));
                /*var*/ let unique = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "u", "unique" ], null, null));
                /*var*/ let p1 = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                if (pCount < 2)
                {
                    /*var*/ let vv;
                    if ($.$$.S.Int32.TryParse$6(p1, $.$ref(() => vv, ($v) => vv = $v, $.$$.S.Int32)))
                    {
                        return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$box($.$$.S.Random.Shared.Next$2(((vv + 1) | 0)), $.$$.S.Int32));
                    }
                    else 
                    {
                        /*var*/ let objName = $.$strNN("/" + $.$strNN($.$$.S.String.Trim$1.call($.$$.S.String.Replace$3.call(p1, "\\", "/"), /*/*/ 47))) + "/";
                        /*System.Collections.Generic.IEnumerable<string>?*/ let __ca1__;
                        /*var*/ let assets = ((__ca1__ = closure.Context.Assets) !== null ? $.$sl.SL.Enumerable.ToList($.$$.S.String, $.$sl.SL.Enumerable.Where($.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*o*/ o) =>
                        {
                            return $.$$.S.String.Contains$3.call(o, objName) || $.$$.S.String.Contains$3.call(o, objName);
                        }, $kbEtIe ??= {"r":262145,"p":[{"n":"o","p":1310721}],"n":"","d":2787580,"h":0,"f":17825794}))) : null);
                        if ($.$$.S.Int32.op_GreaterThan((assets?.Count ?? null), 0))
                        {
                            /*var*/ let objectPath = assets.get_Item($.$$.S.Random.Shared.Next$2(assets.Count));
                            /*var*/ let paths = $.$fPer.LCFCS$6.StringExtension.SplitByPath($.$fPer.LCFC.StringyExtension.AsStringy$1(objectPath));
                            return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3((() =>
                            {
                                //new $.$fPer.LCFC.IconDescriptor()
                                const $t3 = $.$fPer.LCFC.IconDescriptor;
                                const $i3 = new $t3();
                                $i3.$ctor$2();
                                $i3.Title = $.$fPer.LCFCS$6.StringExtension.CapitalizeFirstLetter($.$$.S.String.Replace$3.call($.$$.SI.Path.GetFileNameWithoutExtension$1($.$fPer.LCFC.Stringy.op_Implicit$1(paths.get_Item$1(((paths.Length - 1) | 0)))), "_", " "));
                                $i3.Category = $.$fPer.LCFC.Stringy.op_Implicit$1(paths.get_Item$1(((paths.Length - 2) | 0)));
                                $i3.Icon = objectPath;
                                return $i3;
                            })());
                        }
                    }
                }
                if ($.$$.S.Int32.TryParse$6(p1, $.$ref(() => min, ($v) => min = $v, $.$$.S.Int32)) && $.$$.S.Int32.TryParse$6($.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)), $.$ref(() => max, ($v) => max = $v, $.$$.S.Int32)))
                {
                    /*int*/ let randCount = -1;
                    /*List<int>?*/ let rands = null;
                    /*int*/  function Generate()
                    {
                        if ((exclude.Value !== null && (((max - min) | 0)) >= 1) || (unique !== null && rands !== null && (((max - min) | 0)) >= randCount))
                        {
                            /*var*/ let _excludeNumber;
                            /*IEnumerable<int?>?*/ let excludeNumbers = null;
                            let excludes;
                            if ($.$$.S.Int32.TryParse$6(exclude.ToString(), $.$ref(() => _excludeNumber, ($v) => _excludeNumber = $v, $.$$.S.Int32)))
                            {
                                excludeNumbers = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeNullable($.$$.S.Int32).$type, [ _excludeNumber ], null, null);
                            }
                            else if ($.$is(exclude.Value, $.$$.SC$1.IEnumerable, { set $v($v){ excludes = $v; } }))
                            {
                                excludeNumbers = $.$sl.SL.Enumerable.ToList($.$typeNullable($.$$.S.Int32), $.$sl.SL.Enumerable.Select$1($.$$.S.Object, $.$typeNullable($.$$.S.Int32), $.$sl.SL.Enumerable.Cast($.$$.S.Object, excludes), new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Nullable$$($.$$.S.Int32)))().$ctor(this,  (/*s*/ s) =>
                                {
                                    /*var*/ let _excludeNumber;
                                    /*object*/ let __ca2__;
                                    if ($.$$.S.Int32.TryParse$6(((__ca2__ = s) !== null ? $.$dsp(__ca2__, $.$$.S.Object, ($t) => $t.ToString) : null), $.$ref(() => _excludeNumber, ($v) => _excludeNumber = $v, $.$$.S.Int32)))
                                    {
                                        return _excludeNumber;
                                    }
                                    return null;
                                }, $Cnxndg ??= {"r":$.$typeNullable($.$$.S.Int32).$h,"p":[{"n":"s","p":131073}],"n":"","d":2787580,"h":0,"f":17825794})));
                            }
                            do
                            {
                                /*int*/ let v = $.$$.S.Random.Shared.Next$1(min, ((max + 1) | 0));
                                if (excludeNumbers !== null && $.$sl.SL.Enumerable.Contains$1($.$typeNullable($.$$.S.Int32), excludeNumbers, v))
                                {
                                    continue;
                                }
                                if (rands !== null && rands.Contains(v))
                                {
                                    continue;
                                }
                                return v;
                            }
                            while(true);
                        }
                        return $.$$.S.Random.Shared.Next$1(min, ((max + 1) | 0));
                    }
                    if ($.$$.S.Int32.TryParse$6($.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 2, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)), $.$ref(() => randCount, ($v) => randCount = $v, $.$$.S.Int32)) && randCount > 0)
                    {
                        rands ??= new ($.$$.SCG.List$$($.$$.S.Int32))().$ctor$1();
                        for(/*int*/ let i = 0; i < randCount; i++)
                        {
                            rands.Add(Generate.call(this));
                        }
                        return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(rands);
                    }
                    else 
                    {
                        return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3($.$box(Generate.call(this), $.$$.S.Int32));
                    }
                }
                return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
            }
            //--TRIMMABLE-BOUNDARY-END(38657493244)
            
            //--TRIMMABLE-BOUNDARY-START(4297754876)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297754876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297754876)
            
            //--TRIMMABLE-BOUNDARY-START(4297754876)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297754876)
            
            static $h = 2787580;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362525948),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772591356,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2787580,
      "h": 34362525948,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362525948),
//--TRIMMABLE-BOUNDARY-START(8592722172),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182656764,
        "f": 50364417
      },
      "n": "Description",
      "d": 2787580,
      "h": 8592722172,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592722172)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067558652),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2787580,
      "h": 30067558652,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067558652),
//--TRIMMABLE-BOUNDARY-START(38657493244),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2787580,
      "h": 38657493244,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657493244)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297754876),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2787580,
      "h": 4297754876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297754876)
  ],
  "h": 2787580
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusRandomTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusRandomTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2787580)
        
        

        //--TRIMMABLE-BOUNDARY-START(2853116)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusRepeat2DTokenResolver`, ($self) => class MarkdownPlusRepeat2DTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362591484)
            /*string */ get Invocation()
            {
                return "repeat2d/matrix/matrix2d";
            }
            //--TRIMMABLE-BOUNDARY-END(34362591484)
            
            //--TRIMMABLE-BOUNDARY-START(8592787708)
            /*string */ get Description()
            {
                return "Repeat 2 dimensional in certain number of times. The contents can access variables defined by the repeater as \r\n\r\n$i: the current overall iterator index of the repeater\r\n\r\n$ix: the current x index of the repeater\r\n\r\n$iy: the current y index of the repeater\r\n\r\nExample: ``repeat2d(2,2,eval($ix+\" . \"+$iy+\" repeat\"))``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592787708)
            
            //--TRIMMABLE-BOUNDARY-START(30067624188)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The number of times to repeat in x direction");
                        $i1.Required = true;
                        return $i1;
                    })();
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t2 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i2 = new $t2();
                        $i2.$ctor$3("1", "The number of times to repeat in y direction");
                        $i2.Required = true;
                        return $i2;
                    })();
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["eg", "eager"], null, null), "Eagerly execute the contents");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("i", "The name to use in place of $i for the overall iterator index");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("ix", "The name to use in place of $ix for the x iterator index");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("iy", "The name to use in place of $i for the y iterator index");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("-1", "The content to be repeated");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067624188)
            
            //--TRIMMABLE-BOUNDARY-START(38657558780)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657558780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let nY = $.$$.S.Int32.Parse$7($.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)));
                /*var*/ let nX = $.$$.S.Int32.Parse$7($.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, 1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null)));
                /*var*/ let separator = $.$EVvT.LCFCM.MarkdownPlusUtility.GetSeparator(parameters);
                /*var*/ let eager = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "eg", "eager" ], null, null));
                /*var*/ let repeatIteratorName = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "i" ], null, null));
                if (repeatIteratorName !== null)
                {
                    repeatIteratorName = "$" + $.$strNN(repeatIteratorName);
                }
                /*var*/ let xRepeatIteratorName = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "ix" ], null, null));
                if (xRepeatIteratorName !== null)
                {
                    xRepeatIteratorName = "$" + $.$strNN(xRepeatIteratorName);
                }
                /*var*/ let yRepeatIteratorName = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "iy" ], null, null));
                if (yRepeatIteratorName !== null)
                {
                    yRepeatIteratorName = "$" + $.$strNN(yRepeatIteratorName);
                }
                /*var*/ let val = $.$sl.SL.Enumerable.Last$1($.$EVvT.LCFCM.MarkdownPlusToken, parameters.Values);
                /*Dictionary<(int, int), IEnumerable<MarkdownPlusToken>>*/ let keyedColumn = new ($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32), $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken)))().$ctor$1();
                /*var*/ let values = $.$sl.SL.Enumerable.Select$1($.$$.S.Int32, $.$$.SCG.IEnumerable$$($.$$.S.Object), $.$sl.SL.Enumerable.Range(1, ((nY + (separator !== null ? ((nY - 1) | 0) : 0)) | 0)), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ iY) =>
                {
                    /*var*/ let xValues = $.$sl.SL.Enumerable.Select$1($.$$.S.Int32, $.$$.S.Object, $.$sl.SL.Enumerable.Range(1, ((nX + (separator !== null ? ((nX - 1) | 0) : 0)) | 0)), new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.Object))().$ctor(this,  (/*iX*/ iX) =>
                    {
                        /*var*/ let views;
                        if (separator !== null && (iX & 1) === 1)
                        {
                            return separator;
                        }
                        if (!keyedColumn.TryGetValue(new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(iX, iY), $.$ref(() => views, ($v) => views = $v, $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken))))
                        {
                            let defered;
                            if ($.$is(val.Value, $.$EVvT.LCFCM.MarkdownPlusDeferedParameterResolver, { set $v($v){ defered = $v; } }))
                            {
                                /*var*/ let iclosure = new $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure().$ctor$2(closure);
                                /*int*/ let iteratorIndex = iX;
                                if (separator !== null)
                                {
                                    iteratorIndex /= 2;
                                }
                                iclosure.Set($.$$.S.Int32, $.$fPer.LCFC.Stringy.op_Implicit$3(repeatIteratorName ?? "$i"/*MarkdownPlusConst.DefaultRepeatIteratorIndexName*/), iteratorIndex);
                                iclosure.Set($.$$.S.Int32, $.$fPer.LCFC.Stringy.op_Implicit$3(xRepeatIteratorName ?? $.$strNN("$i"/*MarkdownPlusConst.DefaultRepeatIteratorIndexName*/) + "x"), iX);
                                iclosure.Set($.$$.S.Int32, $.$fPer.LCFC.Stringy.op_Implicit$3(yRepeatIteratorName ?? $.$strNN("$i"/*MarkdownPlusConst.DefaultRepeatIteratorIndexName*/) + "y"), iY);
                                views = defered.GetValue(iclosure);
                                if (views !== null)
                                {
                                    keyedColumn.set_Item(new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(iX, iY), views);
                                }
                                return views;
                            }
                            else 
                            {
                                return val;
                            }
                        }
                        return val;
                    }, $HyNApb ??= {"r":131073,"p":[{"n":"iX","p":655361}],"n":"","d":2853116,"h":0,"f":17825794}));
                    if (eager !== null || $.$fPer.LCFC.Stringy.op_Implicit$1(method) === "list2d")
                    {
                        xValues = $.$sl.SL.Enumerable.ToList($.$$.S.Object, xValues);
                    }
                    return xValues;
                }, $SJTMbd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"iY","p":655361}],"n":"","d":2853116,"h":0,"f":17825794}));
                if (eager !== null || $.$fPer.LCFC.Stringy.op_Implicit$1(method) === "list2d")
                {
                    values = $.$sl.SL.Enumerable.ToList($.$$.SCG.IEnumerable$$($.$$.S.Object), values);
                }
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(values);
            }
            //--TRIMMABLE-BOUNDARY-END(38657558780)
            
            //--TRIMMABLE-BOUNDARY-START(4297820412)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297820412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297820412)
            
            //--TRIMMABLE-BOUNDARY-START(4297820412)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297820412)
            
            static $h = 2853116;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362591484),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772656892,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2853116,
      "h": 34362591484,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362591484),
//--TRIMMABLE-BOUNDARY-START(8592787708),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182722300,
        "f": 50364417
      },
      "n": "Description",
      "d": 2853116,
      "h": 8592787708,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592787708)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067624188),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2853116,
      "h": 30067624188,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067624188),
//--TRIMMABLE-BOUNDARY-START(38657558780),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2853116,
      "h": 38657558780,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657558780)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297820412),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2853116,
      "h": 4297820412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297820412)
  ],
  "h": 2853116
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusRepeat2DTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusRepeat2DTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2853116)
        
        

        //--TRIMMABLE-BOUNDARY-START(2984188)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusShuffleTokenResolver`, ($self) => class MarkdownPlusShuffleTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362722556)
            /*string */ get Invocation()
            {
                return "shuffle";
            }
            //--TRIMMABLE-BOUNDARY-END(34362722556)
            
            //--TRIMMABLE-BOUNDARY-START(8592918780)
            /*string */ get Description()
            {
                return "Randomly rearrange contents.\r\n\r\nExample: ``shuffle(1,2,3,4)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592918780)
            
            //--TRIMMABLE-BOUNDARY-START(30067755260)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$3("-1", "The Contents to rearrange.");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "ord", "order" ], null, null), "Export the shuffled order to a named variable");
                    yield new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "ordtype", "ordertype" ], null, null), "Export the shuffled order as array of int or string with start index 1. Default to string");
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067755260)
            
            //--TRIMMABLE-BOUNDARY-START(38657689852)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ closure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657689852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let shuffledOrderName = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "ord", "order" ], null, null));
                /*var*/ let shuffledOrderType = $.$EVvT.LCFCM.MarkdownPlusUtility.GetStringParameterValue(parameters, -1, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "ordtype", "ordertype" ], null, null));
                /*List<MarkdownPlusToken>*/ let list = new ($.$$.SCG.List$$($.$EVvT.LCFCM.MarkdownPlusToken))().$ctor$1();
                let $en1 = parameters.Values.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let value = $en1.Current;
                    {
                        let e;
                        if ($.$is(value.Value, $.$$.SC$1.IEnumerable, { set $v($v){ e = $v; } }))
                        {
                            list.AddRange($.$sl.SL.Enumerable.Select$1($.$$.S.Object, $.$EVvT.LCFCM.MarkdownPlusToken, $.$sl.SL.Enumerable.Cast($.$$.S.Object, e), new ($.$$.S.Func$$$($.$$.S.Object, $.$EVvT.LCFCM.MarkdownPlusToken))().$ctor(this,  (/*e*/ e) =>
                            {
                                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(e);
                            }, $dDZKTb ??= {"r":1411324,"p":[{"n":"e","p":131073}],"n":"","d":2984188,"h":0,"f":17825794})));
                        }
                        else 
                        {
                            list.Add($.$clone(value));
                        }
                    }
                }
                /*List<int>?*/ let shuffledOrder = shuffledOrderName !== null ? new ($.$$.SCG.List$$($.$$.S.Int32))().$ctor$1() : null;
                /*var*/ let shuffled = $.$sl.SL.Enumerable.ToList($.$EVvT.LCFCM.MarkdownPlusToken, $.$sl.SL.Enumerable.Select$1($.$$.S.ValueTuple$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32), $.$EVvT.LCFCM.MarkdownPlusToken, $.$sl.SL.Enumerable.OrderBy$1($.$$.S.ValueTuple$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32), $.$$.S.Int32, $.$sl.SL.Enumerable.Select($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.ValueTuple$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32), list, new ($.$$.S.Func$$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32)))().$ctor(this,  (/*s*/ s, /*i*/ i) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32))().$ctor$3($.$clone(s), i);
                }, $zWSCfe ??= {"r":$.$$.S.ValueTuple$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32).$h,"p":[{"n":"s","p":1411324},{"n":"i","p":655361}],"n":"","d":2984188,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32), $.$$.S.Int32))().$ctor(this,  (/*p*/ p) =>
                {
                    return $.$$.S.Random.Shared.Next();
                }, $auWTHg ??= {"r":655361,"p":[{"n":"p","p":$.$$.S.ValueTuple$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32).$h}],"n":"","d":2984188,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32), $.$EVvT.LCFCM.MarkdownPlusToken))().$ctor(this,  (/*o*/ o) =>
                {
                    if (shuffledOrder !== null)
                    {
                        shuffledOrder.Add(((o.Item2 + 1) | 0));
                    }
                    return $.$with(o.Item1, ($clone) =>
                    {
                        $clone.Order = ((o.Item2 + 1) | 0);
                    });
                }, $NkiVze ??= {"r":1411324,"p":[{"n":"o","p":$.$$.S.ValueTuple$$$($.$EVvT.LCFCM.MarkdownPlusToken, $.$$.S.Int32).$h}],"n":"","d":2984188,"h":0,"f":17825794})));
                if (shuffledOrderName !== null && shuffledOrder !== null)
                {
                    if (shuffledOrderType === "int")
                    {
                        closure.RootClosure.Set($.$$.SCG.List$$($.$$.S.Int32), $.$fPer.LCFC.Stringy.op_Implicit$3($.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/) + $.$strNN(shuffledOrderName)), shuffledOrder);
                    }
                    else 
                    {
                        closure.RootClosure.Set($.$$.S.String, $.$fPer.LCFC.Stringy.op_Implicit$3($.$strNN("$"/*MarkdownPlusConst.VariableStartIdentifier*/) + $.$strNN(shuffledOrderName)), $.$$.S.String.Join$5("", $.$sl.SL.Enumerable.Select$1($.$$.S.Int32, $.$$.S.String, shuffledOrder, new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.S.String))().$ctor(this,  (/*s*/ s) =>
                        {
                            return $.$$.S.Int32.ToString.call(s);
                        }, $kIugse ??= {"r":1310721,"p":[{"n":"s","p":655361}],"n":"","d":2984188,"h":0,"f":17825794}))));
                    }
                }
                return new $.$EVvT.LCFCM.MarkdownPlusToken().$ctor$3(shuffled);
            }
            //--TRIMMABLE-BOUNDARY-END(38657689852)
            
            //--TRIMMABLE-BOUNDARY-START(4297951484)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297951484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297951484)
            
            //--TRIMMABLE-BOUNDARY-START(4297951484)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297951484)
            
            static $h = 2984188;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362722556),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772787964,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2984188,
      "h": 34362722556,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362722556),
//--TRIMMABLE-BOUNDARY-START(8592918780),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182853372,
        "f": 50364417
      },
      "n": "Description",
      "d": 2984188,
      "h": 8592918780,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592918780)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067755260),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2984188,
      "h": 30067755260,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067755260),
//--TRIMMABLE-BOUNDARY-START(38657689852),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "closure",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2984188,
      "h": 38657689852,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657689852)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297951484),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2984188,
      "h": 4297951484,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297951484)
  ],
  "h": 2984188
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusShuffleTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusShuffleTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2984188)
        
        

        //--TRIMMABLE-BOUNDARY-START(2590972)
        $asm.$cls(`$EVvT.LCFCMR.MarkdownPlusImportTokenResolver`, ($self) => class MarkdownPlusImportTokenResolver extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase
        {
            //--TRIMMABLE-BOUNDARY-START(34362329340)
            /*string */ get Invocation()
            {
                return "import";
            }
            //--TRIMMABLE-BOUNDARY-END(34362329340)
            
            //--TRIMMABLE-BOUNDARY-START(8592525564)
            /*string */ get Description()
            {
                return "Import a template into a skill.\r\n\r\nExample: ``import(12345, min:1, max:10)``";
            }
            //--TRIMMABLE-BOUNDARY-END(8592525564)
            
            //--TRIMMABLE-BOUNDARY-START(30067362044)
            /*IEnumerable<MarkdownPlusTokenMethodResolverParameterInfo> */ GetParameterInfos()
            {
                return new ($.$$.N.YieldToIterator$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo))().$ctor$1(function*()
                {
                    yield (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo()
                        const $t1 = $.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo;
                        const $i1 = new $t1();
                        $i1.$ctor$3("0", "The id of the template");
                        $i1.Required = true;
                        return $i1;
                    })();
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(30067362044)
            
            //--TRIMMABLE-BOUNDARY-START(38657296636)
            /*MarkdownPlusToken */ ResolveToken(/*Stringy*/ method, /*Dictionary<string, MarkdownPlusToken>*/ parameters, /*MarkdownPlusTokenResolverClosure*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657296636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let root;
                if ($.$is(context, $.$EVvT.LCFCM.MarkdownPlusTokenResolverRootClosure, { set $v($v){ root = $v; } }))
                {
                    /*var*/ let id = $.$EVvT.LCFCM.MarkdownPlusUtility.GetRequiredStringParameterValue(parameters, 0, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [  ], null, null));
                    root.ImportedTemplates.Add(new $.$EVvT.LCFCM.MarkdownPlusTokenResolverImport().$ctor$1(root, id, parameters));
                    return $.$EVvT.LCFCM.MarkdownPlusToken.op_Implicit$6("");
                }
                throw new $.$$.S.InvalidOperationException().$ctor$12("import can only be used in root closure");
            }
            //--TRIMMABLE-BOUNDARY-END(38657296636)
            
            //--TRIMMABLE-BOUNDARY-START(4297558268)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297558268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297558268)
            
            //--TRIMMABLE-BOUNDARY-START(4297558268)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297558268)
            
            static $h = 2590972;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362329340),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772394748,
        "f": 50364417
      },
      "n": "Invocation",
      "d": 2590972,
      "h": 34362329340,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362329340),
//--TRIMMABLE-BOUNDARY-START(8592525564),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182460156,
        "f": 50364417
      },
      "n": "Description",
      "d": 2590972,
      "h": 8592525564,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592525564)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067362044),
    {
      "r": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusTokenMethodResolverParameterInfo).$h,
      "n": "GetParameterInfos",
      "d": 2590972,
      "h": 30067362044,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067362044),
//--TRIMMABLE-BOUNDARY-START(38657296636),
    {
      "r": 1411324,
      "p": [
        {
          "n": "method",
          "p": 64915798
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$EVvT.LCFCM.MarkdownPlusToken).$h
        },
        {
          "n": "context",
          "p": 1673468
        }
      ],
      "n": "ResolveToken",
      "d": 2590972,
      "h": 38657296636,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38657296636)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297558268),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2590972,
      "h": 4297558268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297558268)
  ],
  "h": 2590972
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$EVvT.LCFCM.IMarkdownPlusTokenMethodResolver, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.Resolvers.MarkdownPlusImportTokenResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}Resolvers${separator}MarkdownPlusImportTokenResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2590972)
        
        

        //--TRIMMABLE-BOUNDARY-START(1083644)
        $asm.$str(`$EVvT.LCFCM.MarkdownPlusRepeat`, ($self) => class MarkdownPlusRepeat extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(34360822012)
            /*MarkdownPlusRepeatType*/ Mode = 0;
            //--TRIMMABLE-BOUNDARY-END(34360822012)
            
            //--TRIMMABLE-BOUNDARY-START(68720560380)
            /*int*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(68720560380)
            
            //--TRIMMABLE-BOUNDARY-START(60130625788)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130625788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Mode === 1/*MarkdownPlusRepeatType.Cycles*/)
                {
                    return `for ${$.$strNN(this.Value)} cycles`;
                }
                if (this.Mode === 2/*MarkdownPlusRepeatType.Scores*/)
                {
                    return `until scores ${$.$strNN(this.Value)}`;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(60130625788)
            
            //--TRIMMABLE-BOUNDARY-START(38655789308)
            static /*MarkdownPlusRepeat */ Parse(/*string*/ s, /*IFormatProvider?*/ provider)
            {
                /*var*/ let val;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655789308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$EVvT.LCFCM.MarkdownPlusRepeat.TryParse(s, provider, $.$ref(() => val, ($v) => val = $v, $.$EVvT.LCFCM.MarkdownPlusRepeat));
                return val;
            }
            //--TRIMMABLE-BOUNDARY-END(38655789308)
            
            //--TRIMMABLE-BOUNDARY-START(64425593084)
            static /*bool */ TryParse(/*string?*/ s, /*IFormatProvider?*/ provider, /*out MarkdownPlusRepeat*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425593084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                /*var*/ let split = ((__ca1__ = s) !== null ? $.$$.S.String.Split$1.call(__ca1__, /* */ 32, 0) : null);
                /*int*/ let num = 0;
                /*int*/ let num_i = -1;
                /*string[]?*/ let __ca2__;
                /*var*/ let hasNum = ((__ca2__ = split) !== null ? $.$sl.SL.Enumerable.Any($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$sl.SL.Enumerable.Select($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), __ca2__, new ($.$$.S.Func$$$$($.$$.S.String, $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32)))().$ctor(this,  (/*s*/ s, /*i*/ i) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32))().$ctor$3(s, i);
                }, $pIWQzb ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h,"p":[{"n":"s","p":1310721},{"n":"i","p":655361}],"n":"","d":1083644,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    if ($.$$.S.Int32.TryParse$6(s.Item1, $.$ref(() => num, ($v) => num = $v, $.$$.S.Int32)))
                    {
                        num_i = s.Item2;
                        return true;
                    }
                    return false;
                }, $BmnYke ??= {"r":262145,"p":[{"n":"s","p":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h}],"n":"","d":1083644,"h":0,"f":17825794})) : false);
                /*MarkdownPlusRepeatType*/ let mode = 1/*MarkdownPlusRepeatType.Cycles*/;
                /*string[]?*/ let __ca3__;
                /*var*/ let hasMode = ((__ca3__ = split) !== null ? $.$sl.SL.Enumerable.Any($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$sl.SL.Enumerable.Select($.$$.S.String, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), __ca3__, new ($.$$.S.Func$$$$($.$$.S.String, $.$$.S.Int32, $.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32)))().$ctor(this,  (/*s*/ s, /*i*/ i) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32))().$ctor$3(s, i);
                }, $oEBvck ??= {"r":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h,"p":[{"n":"s","p":1310721},{"n":"i","p":655361}],"n":"","d":1083644,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32), $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    if (s.Item2 === num_i)
                    {
                        return false;
                    }
                    return $.$$.S.Enum.TryParse$9($.$EVvT.LCFCM.MarkdownPlusRepeatType, s.Item1, true, $.$ref(() => mode, ($v) => mode = $v, $.$EVvT.LCFCM.MarkdownPlusRepeatType));
                }, $WEdBlg ??= {"r":262145,"p":[{"n":"s","p":$.$$.S.ValueTuple$$$($.$$.S.String, $.$$.S.Int32).$h}],"n":"","d":1083644,"h":0,"f":17825794})) : false);
                if (hasMode && hasNum)
                {
                    result.$v = (() =>
                    {
                        //new $.$EVvT.LCFCM.MarkdownPlusRepeat()
                        const $t4 = $.$EVvT.LCFCM.MarkdownPlusRepeat;
                        const $i4 = new $t4();
                        $i4.$ctor$2();
                        $i4.Mode = mode;
                        $i4.Value = num;
                        return $i4;
                    })();
                    return true;
                }
                result.$v = new $.$EVvT.LCFCM.MarkdownPlusRepeat();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(64425593084)
            
            //--TRIMMABLE-BOUNDARY-START(4392222721)
            //Generated interface implemetation for System.IParsable<LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusRepeat>.Parse(string, System.IFormatProvider?)
            static S$IParsable$LivingThing$Core$Frameworks$Common$MarkdownPlus$MarkdownPlusRepeat$Parse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392222721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$EVvT.LCFCM.MarkdownPlusRepeat.Parse(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392222721)
            
            //--TRIMMABLE-BOUNDARY-START(8687190017)
            //Generated interface implemetation for System.IParsable<LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusRepeat>.TryParse(string?, System.IFormatProvider?, out LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusRepeat)
            static S$IParsable$LivingThing$Core$Frameworks$Common$MarkdownPlus$MarkdownPlusRepeat$TryParse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8687190017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$EVvT.LCFCM.MarkdownPlusRepeat.TryParse(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8687190017)
            
            //--TRIMMABLE-BOUNDARY-START(12885985532)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885985532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885985532)
            
            //--TRIMMABLE-BOUNDARY-START(12885985532)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885985532)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Mode = this.Mode;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 1083644;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360822012),
    {
      "p": 1214716,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475920124,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245723900,
        "f": 83886081
      },
      "n": "Mode",
      "d": 1083644,
      "h": 34360822012,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360822012),
//--TRIMMABLE-BOUNDARY-START(68720560380),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065854716,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835658492,
        "f": 83886081
      },
      "n": "Value",
      "d": 1083644,
      "h": 68720560380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720560380)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130625788),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1083644,
      "h": 60130625788,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130625788),
//--TRIMMABLE-BOUNDARY-START(38655789308),
    {
      "r": 1083644,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "provider",
          "p": 91226113
        }
      ],
      "n": "Parse",
      "d": 1083644,
      "h": 38655789308,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655789308),
//--TRIMMABLE-BOUNDARY-START(64425593084),
    {
      "r": 262145,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "provider",
          "p": 91226113
        },
        {
          "n": "result",
          "p": 1083644,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1083644,
      "h": 64425593084,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425593084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885985532),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1083644,
      "h": 12885985532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885985532)
  ],
  "h": 1083644,
  "a": [
    {
      "t": 2197846,
      "c": 12887099734,
      "n": [
        {
          "n": "InputType",
          "v": 81,
          "t": 47614294
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IValueDataType, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$$.S.IParsable$$($.$EVvT.LCFCM.MarkdownPlusRepeat) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusRepeat`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusRepeat`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1083644)
        
        

        //--TRIMMABLE-BOUNDARY-START(1476860)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusTokenMethodResolverFactory`, ($self) => class MarkdownPlusTokenMethodResolverFactory extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*IMarkdownPlusTokenMethodResolver?*/ Invoke(/*$.$$.S.String*/ invocationName, /*$.$$.S.Nullable$$*/ key, /**/ parent)
            {
                return this.$nativeFunction.call(this.$target, invocationName, key, parent);
            }
            static $h = 1476860;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181346044),
    {
      "r": 624892,
      "p": [
        {
          "n": "invocationName",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "parent",
          "p": 624892
        }
      ],
      "n": "Invoke",
      "d": 1476860,
      "h": 17181346044,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181346044),
//--TRIMMABLE-BOUNDARY-START(8591411452),
    {
      "r": 90570753,
      "p": [
        {
          "n": "invocationName",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "parent",
          "p": 624892
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1476860,
      "h": 8591411452,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591411452),
//--TRIMMABLE-BOUNDARY-START(12886378748),
    {
      "r": 624892,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 1476860,
      "h": 12886378748,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886378748)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296444156),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1476860,
      "h": 4296444156,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296444156)
  ],
  "h": 1476860
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenMethodResolverFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTokenMethodResolverFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1476860)
        
        

        //--TRIMMABLE-BOUNDARY-START(1214716)
        $asm.$str(`$EVvT.LCFCM.MarkdownPlusRepeatType`, ($self) => class MarkdownPlusRepeatType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Cycles = 1;
            static Scores = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1214716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Cycles": 1n,
                    "Scores": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296182012)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296182012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296182012)
            
            //--TRIMMABLE-BOUNDARY-START(4296182012)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296182012)
            
            static $h = 1214716;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886116604),
    {
      "t": 1214716,
      "n": "None",
      "d": 1214716,
      "h": 12886116604,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886116604),
//--TRIMMABLE-BOUNDARY-START(8591149308),
    {
      "t": 1214716,
      "n": "Cycles",
      "d": 1214716,
      "h": 8591149308,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591149308),
//--TRIMMABLE-BOUNDARY-START(17181083900),
    {
      "t": 1214716,
      "n": "Scores",
      "d": 1214716,
      "h": 17181083900,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181083900)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296182012),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1214716,
      "h": 4296182012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296182012)
  ],
  "h": 1214716
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusRepeatType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusRepeatType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1214716)
        
        

        //--TRIMMABLE-BOUNDARY-START(1804540)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusTokenResolverGlobalClosure`, ($self) => class MarkdownPlusTokenResolverGlobalClosure extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure
        {
            //--TRIMMABLE-BOUNDARY-START(25771608316)
            /*Interpreter*/ Interpreter = null;
            //--TRIMMABLE-BOUNDARY-END(25771608316)
            
            //--TRIMMABLE-BOUNDARY-START(8591739132)
            $ctor$3(/*MarkdownPlusContext*/ context)
            {
                super.$ctor$1(context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591739132);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.InitializeInterpreter();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591739132)
            
            //--TRIMMABLE-BOUNDARY-START(21476641020)
            /*void */ InitializeInterpreter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476641020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Interpreter.Reference$3($.$sl.SL.Enumerable.$type);
                this.Interpreter.Reference$3($.$$.S.Math.$type);
                this.Interpreter.Reference$3($.$$.S.Int32.$type);
                this.Interpreter.Reference$3($.$$.S.Double.$type);
                this.Interpreter.Reference$3($.$$.S.String.$type);
                this.Interpreter.Reference$2($.$EVvT.LCFCM.MarkdownPlusUtilityMethods.$type, "mardownplus"/*MarkdownPlusUtilityMethods.InvocationName*/);
                this.Interpreter.SetVariable$2($.$EVvT.LCFCM.MarkdownPlusTokenResolverGlobalClosure, "global", this);
            }
            //--TRIMMABLE-BOUNDARY-END(21476641020)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771608316)
                this.Interpreter = new $.$HnZw.D.Interpreter().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(25771608316)
                
            }
            static $h = 1804540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771608316),
    {
      "p": 1028211,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181673724,
        "f": 50331656
      },
      "n": "Interpreter",
      "d": 1804540,
      "h": 25771608316,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(25771608316)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476641020),
    {
      "r": 65537,
      "n": "InitializeInterpreter",
      "d": 1804540,
      "h": 21476641020,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476641020)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591739132),
    {
      "p": [
        {
          "n": "context",
          "p": 821500
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1804540,
      "h": 8591739132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591739132)
  ],
  "h": 1804540
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverGlobalClosure`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTokenResolverGlobalClosure`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1804540)
        
        

        //--TRIMMABLE-BOUNDARY-START(1935612)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusTokenResolverMethodClosure`, ($self) => class MarkdownPlusTokenResolverMethodClosure extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure
        {
            //--TRIMMABLE-BOUNDARY-START(4296902908)
            $ctor$3(/*MarkdownPlusTokenResolverClosure*/ parent)
            {
                super.$ctor$2(parent);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296902908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296902908)
            
            //--TRIMMABLE-BOUNDARY-START(8591870204)
            /*void */ Set(T, /*Stringy*/ name, /*T*/ val)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591870204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (name.get_Item$1(0) === $.$$.S.String.get_Chars.call("$"/*MarkdownPlusConst.VariableStartIdentifier*/, 0))
                {
                    this.ParentScope.Set(T, $.$clone(name), val);
                }
                else 
                {
                    /*var*/ let isNamed = !$.$$.S.Int32.TryParse$6($.$fPer.LCFC.Stringy.op_Implicit$1(name), $.$discardRef());
                    if (isNamed)
                    {
                        name = $.$fPer.LCFC.Stringy.op_Implicit$3("$"/*MarkdownPlusConst.VariableStartIdentifier*/ + $.$strNN(name.ToString()));
                    }
                    super.Set(T, $.$clone(name), val);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591870204)
            
            static $h = 1935612;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591870204),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 64915798
        },
        {
          "n": "val",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Set",
      "d": 1935612,
      "h": 8591870204,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591870204)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296902908),
    {
      "p": [
        {
          "n": "parent",
          "p": 1673468
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1935612,
      "h": 4296902908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296902908)
  ],
  "h": 1935612
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverMethodClosure`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTokenResolverMethodClosure`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1935612)
        
        

        //--TRIMMABLE-BOUNDARY-START(2066684)
        $asm.$cls(`$EVvT.LCFCM.MarkdownPlusTokenResolverRootClosure`, ($self) => class MarkdownPlusTokenResolverRootClosure extends $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure
        {
            //--TRIMMABLE-BOUNDARY-START(4297033980)
            /*string?*/ _templateString = null;
            //--TRIMMABLE-BOUNDARY-END(4297033980)
            
            //--TRIMMABLE-BOUNDARY-START(38656772348)
            $ctor$3(/*MarkdownPlusTokenResolverGlobalClosure*/ global, /*MarkdownPlusContext*/ context, /*string?*/ templateString)
            {
                super.$ctor$1(context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656772348);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Global$1 = global;
                    global.Children.Add(this);
                    this._templateString = templateString;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656772348)
            
            //--TRIMMABLE-BOUNDARY-START(141735987452)
            /*int*/ IteratorIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(141735987452)
            
            //--TRIMMABLE-BOUNDARY-START(128851085564)
            /*MarkdownPlusTokenResolverGlobalClosure*/ Global$1 = null;
            //--TRIMMABLE-BOUNDARY-END(128851085564)
            
            //--TRIMMABLE-BOUNDARY-START(137441020156)
            /*List<MarkdownPlusTokenResolverImport>*/ ImportedTemplates = null;
            //--TRIMMABLE-BOUNDARY-END(137441020156)
            
            //--TRIMMABLE-BOUNDARY-START(188980627708)
            /*Theme*/ Theme;
            //--TRIMMABLE-BOUNDARY-END(188980627708)
            
            //--TRIMMABLE-BOUNDARY-START(146030954748)
            /*IEnumerable<MarkdownPlusToken>?*/ QuestionTokens = null;
            //--TRIMMABLE-BOUNDARY-END(146030954748)
            
            //--TRIMMABLE-BOUNDARY-START(133146052860)
            /*IEnumerable<MarkdownPlusToken>?*/ HelpTokens = null;
            //--TRIMMABLE-BOUNDARY-END(133146052860)
            
            //--TRIMMABLE-BOUNDARY-START(197570562300)
            /*IEnumerable<KeyValuePair<string, object?>> */ get Variables()
            {
                return this.LocalParameters;
            }
            //--TRIMMABLE-BOUNDARY-END(197570562300)
            
            //--TRIMMABLE-BOUNDARY-START(150325922044)
            /*bool */ ResolveParameter(/*string*/ name, /*out object?*/ value, /*int*/ depth)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325922044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (depth > 20)
                {
                    value.$v = null;
                    return false;
                }
                /*var*/ let ok = super.ResolveParameter(name, value, depth);
                if (ok)
                {
                    return ok;
                }
                let $en2 = this.ImportedTemplates.GetEnumerator();
                while ($en2.MoveNext())
                {
                    let $import = $en2.Current;
                    {
                        if ($import.ImportedClosure !== null)
                        {
                            let $en3 = $import.ImportedClosure.SCG$IEnumerable$$$GetEnumerator();
                            while ($en3.SC$1$IEnumerator$MoveNext())
                            {
                                let closure = $en3.SCG$IEnumerator$$$Current;
                                {
                                    ok = closure.ResolveParameter(name, value, ((depth + 1) | 0));
                                    if (ok)
                                    {
                                        return ok;
                                    }
                                }
                            }
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(150325922044)
            
            //--TRIMMABLE-BOUNDARY-START(47246706940)
            /*ObservableCollection<IQueryOption>*/ ChosenAnswers = null;
            //--TRIMMABLE-BOUNDARY-END(47246706940)
            
            //--TRIMMABLE-BOUNDARY-START(42951739644)
            /*IEnumerable<IQueryOption> */ get Answers()
            {
                return this.ChosenAnswers;
            }
            //--TRIMMABLE-BOUNDARY-END(42951739644)
            
            //--TRIMMABLE-BOUNDARY-START(193275595004)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275595004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._templateString;
            }
            //--TRIMMABLE-BOUNDARY-END(193275595004)
            
            //--TRIMMABLE-BOUNDARY-START(12885330172)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusMarkdownAnswerEditor.ChosenAnswers.get
            get LCFCM$IMarkdownPlusMarkdownAnswerEditor$ChosenAnswers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295395580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ChosenAnswers;
            }
            //--TRIMMABLE-BOUNDARY-END(12885330172)
            
            //--TRIMMABLE-BOUNDARY-START(8590166268)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusDebuggable.Variables.get
            get LCFCM$IMarkdownPlusDebuggable$Variables()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885133564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Variables;
            }
            //--TRIMMABLE-BOUNDARY-END(8590166268)
            
            //--TRIMMABLE-BOUNDARY-START(17180166396)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusMarkdown.QuestionTokens.get
            get LCFCM$IMarkdownPlusMarkdown$QuestionTokens()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770100988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.QuestionTokens;
            }
            //--TRIMMABLE-BOUNDARY-END(17180166396)
            
            //--TRIMMABLE-BOUNDARY-START(8590231804)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MarkdownPlus.IMarkdownPlusMarkdown.HelpTokens.get
            get LCFCM$IMarkdownPlusMarkdown$HelpTokens()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475133692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HelpTokens;
            }
            //--TRIMMABLE-BOUNDARY-END(8590231804)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(137441020156)
                this.ImportedTemplates = new ($.$$.SCG.List$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverImport))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(137441020156)
                
                //--TRIMMABLE-BOUNDARY-START(188980627708)
                this.Theme = $.$default($.$fPer.LCFC.Theme);
                //--TRIMMABLE-BOUNDARY-END(188980627708)
                
                //--TRIMMABLE-BOUNDARY-START(47246706940)
                this.ChosenAnswers = new ($.$so.SCO.ObservableCollection$$($.$fPer.LCFCD.IQueryOption))().$ctor$3();
                //--TRIMMABLE-BOUNDARY-END(47246706940)
                
            }
            static $h = 2066684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$EVvT.LCFCM.MarkdownPlusTokenResolverClosure; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(141735987452),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786314492,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176095725820,
        "f": 83886081
      },
      "n": "IteratorIndex",
      "d": 2066684,
      "h": 141735987452,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141735987452),
//--TRIMMABLE-BOUNDARY-START(128851085564),
    {
      "p": 1804540,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016510716,
        "f": 50331649
      },
      "n": "Global",
      "o": "@$1",
      "d": 2066684,
      "h": 128851085564,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(128851085564),
//--TRIMMABLE-BOUNDARY-START(137441020156),
    {
      "p": $.$$.SCG.List$$($.$EVvT.LCFCM.MarkdownPlusTokenResolverImport).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196379900,
        "f": 50331649
      },
      "n": "ImportedTemplates",
      "d": 2066684,
      "h": 137441020156,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137441020156),
//--TRIMMABLE-BOUNDARY-START(188980627708),
    {
      "p": 65309014,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966183676,
        "f": 50331649
      },
      "n": "Theme",
      "d": 2066684,
      "h": 188980627708,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188980627708),
//--TRIMMABLE-BOUNDARY-START(146030954748),
    {
      "p": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376249084,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184685660412,
        "f": 83886081
      },
      "n": "QuestionTokens",
      "d": 2066684,
      "h": 146030954748,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146030954748),
//--TRIMMABLE-BOUNDARY-START(133146052860),
    {
      "p": $.$$.SCG.IEnumerable$$($.$EVvT.LCFCM.MarkdownPlusToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606445308,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505791228,
        "f": 83886081
      },
      "n": "HelpTokens",
      "d": 2066684,
      "h": 133146052860,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146052860),
//--TRIMMABLE-BOUNDARY-START(197570562300),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556118268,
        "f": 50331649
      },
      "n": "Variables",
      "d": 2066684,
      "h": 197570562300,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197570562300),
//--TRIMMABLE-BOUNDARY-START(47246706940),
    {
      "p": $.$so.SCO.ObservableCollection$$($.$fPer.LCFCD.IQueryOption).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426576124,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915856636,
        "f": 83886081
      },
      "n": "ChosenAnswers",
      "d": 2066684,
      "h": 47246706940,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246706940),
//--TRIMMABLE-BOUNDARY-START(42951739644),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IQueryOption).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836641532,
        "f": 50331649
      },
      "n": "Answers",
      "d": 2066684,
      "h": 42951739644,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951739644)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150325922044),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073,
          "f": 2
        },
        {
          "n": "depth",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "ResolveParameter",
      "d": 2066684,
      "h": 150325922044,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150325922044),
//--TRIMMABLE-BOUNDARY-START(193275595004),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2066684,
      "h": 193275595004,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193275595004)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297033980),
    {
      "t": 1310721,
      "n": "_templateString",
      "d": 2066684,
      "h": 4297033980,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297033980)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38656772348),
    {
      "p": [
        {
          "n": "global",
          "p": 1804540
        },
        {
          "n": "context",
          "p": 821500
        },
        {
          "n": "templateString",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2066684,
      "h": 38656772348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656772348)
  ],
  "h": 2066684
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$EVvT.LCFCM.IMarkdownPlusMarkdownAnswerEditor, $.$EVvT.LCFCM.IMarkdownPlusMarkdownAnswer, $.$EVvT.LCFCM.IMarkdownPlusDebuggable, $.$EVvT.LCFCM.IMarkdownPlusMarkdown ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MarkdownPlus.MarkdownPlusTokenResolverRootClosure`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MarkdownPlus${separator}MarkdownPlusTokenResolverRootClosure`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2066684)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.DynamicExpresso.Core", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic"));
})();
//--TRIMMABLE-BOUNDARY-END(35068)
