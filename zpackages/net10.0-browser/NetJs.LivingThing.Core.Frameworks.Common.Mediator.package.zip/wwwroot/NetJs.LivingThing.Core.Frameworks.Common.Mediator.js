
//--TRIMMABLE-BOUNDARY-START(20842)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer) {
    "use strict";
    let _;
    let $gxWSKk;
    let $SAhIIe;
    let $hoOGeb;
    let $CsInki;
    let $fBLCjc;
    let $CVRjIa;
    let $aEiOle;
    let $KQqJed;
    let $kAVOGi;
    let $SVntda;
    let $dtFAAd;
    let $dNEXob;
    let $VcNLBi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Mediator", 
    {
  "h": 20842,
  "f": "LivingThing.Core.Frameworks.Common.Mediator",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Mediator",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Mediator",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1200490)
        $asm.$cls(`$tUcV.LCFCM.IResponse<>`, (T) => $asm.$gt(`$tUcV.LCFCM.IResponse<>`, [T], ($self) => class IResponse$$
        {
            static $H = 1200490;
            static $h = 1200490;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 1200490,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.IResponse<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}IResponse$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1200490)
        
        

        //--TRIMMABLE-BOUNDARY-START(1790314)
        $asm.$cls(`$tUcV.LCFCMP.IRequestPostProcessor<,>`, (/*in*/ TRequest, /*in*/ TResponse) => $asm.$gt(`$tUcV.LCFCMP.IRequestPostProcessor<,>`, [/*in*/ TRequest, /*in*/ TResponse], ($self) => class IRequestPostProcessor$$$
        {
            static $H = 1790314;
            static $h = 1790314;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296757610),
    {
      "r": 178454529,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864,
          "f": 32
        },
        {
          "n": "response",
          "p": TResponse?.$h??1638400,
          "f": 32
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Process",
      "o": `LCFCMP$IRequestPostProcessor$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Process`,
      "d": this.$h,
      "H": 4296757610,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296757610)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "f": 16
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse",
      "f": 16
    }
  ],
  "r": 2,
  "H": 1790314,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.IRequestPostProcessor<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}IRequestPostProcessor$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1790314)
        
        

        //--TRIMMABLE-BOUNDARY-START(1528170)
        $asm.$cls(`$tUcV.LCFCMP.IRequestExceptionAction<,>`, (/*in*/ TRequest, /*in*/ TException) => $asm.$gt(`$tUcV.LCFCMP.IRequestExceptionAction<,>`, [/*in*/ TRequest, /*in*/ TException], ($self) => class IRequestExceptionAction$$$
        {
            static $H = 1528170;
            static $h = 1528170;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296495466),
    {
      "r": 178454529,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864,
          "f": 32
        },
        {
          "n": "exception",
          "p": TException?.$h??1638400,
          "f": 32
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Execute",
      "o": `LCFCMP$IRequestExceptionAction$${TRequest.$getFullName('$')}$${TException.$getFullName('$')}$Execute`,
      "d": this.$h,
      "H": 4296495466,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296495466)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "f": 16
    },
    {
      "h": TException?.$h??1638400,
      "n": "TException",
      "f": 16,
      "c": [80805889
      ]
    }
  ],
  "r": 2,
  "H": 1528170,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.IRequestExceptionAction<${TRequest?.$fullName},${TException?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}IRequestExceptionAction$${TRequest?.$getFullName(separator)}$${TException?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1528170)
        
        

        //--TRIMMABLE-BOUNDARY-START(151914)
        $asm.$cls(`$tUcV.LCFCM.IBaseRequest`, ($self) => class IBaseRequest
        {
            static $h = 151914;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 151914
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.IBaseRequest`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}IBaseRequest`; }
        });
        //--TRIMMABLE-BOUNDARY-END(151914)
        
        

        //--TRIMMABLE-BOUNDARY-START(1855850)
        $asm.$cls(`$tUcV.LCFCMP.IRequestPreProcessor<>`, (/*in*/ TRequest) => $asm.$gt(`$tUcV.LCFCMP.IRequestPreProcessor<>`, [/*in*/ TRequest], ($self) => class IRequestPreProcessor$$
        {
            static $H = 1855850;
            static $h = 1855850;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296823146),
    {
      "r": 178454529,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864,
          "f": 32
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Process",
      "o": `LCFCMP$IRequestPreProcessor$${TRequest.$getFullName('$')}$Process`,
      "d": this.$h,
      "H": 4296823146,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296823146)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "f": 16
    }
  ],
  "r": 1,
  "H": 1855850,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.IRequestPreProcessor<${TRequest?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}IRequestPreProcessor$${TRequest?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1855850)
        
        

        //--TRIMMABLE-BOUNDARY-START(872810)
        $asm.$cls(`$tUcV.LCFCM.IPipelineBehavior<,>`, (/*in*/ TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCM.IPipelineBehavior<,>`, [/*in*/ TRequest, TResponse], ($self) => class IPipelineBehavior$$$
        {
            static $H = 872810;
            static $h = 872810;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295840106),
    {
      "r": $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864,
          "f": 32
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "next",
          "p": $.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse).$h
        }
      ],
      "n": "Handle",
      "o": `LCFCM$IPipelineBehavior$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Handle`,
      "d": this.$h,
      "H": 4295840106,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295840106)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "f": 16
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 872810,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.IPipelineBehavior<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}IPipelineBehavior$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(872810)
        
        

        //--TRIMMABLE-BOUNDARY-START(217450)
        $asm.$cls(`$tUcV.LCFCM.IMediator`, ($self) => class IMediator
        {
            static $h = 217450;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180086634),
    {
      "r": (TResponse) => $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "request",
          "p": (TResponse) => $.$tUcV.LCFCM.IRequest$$(TResponse).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "TResponse"
      ],
      "n": "Send",
      "o": "LCFCM$IMediator$Send$1",
      "d": 217450,
      "h": 17180086634,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(17180086634),
//--TRIMMABLE-BOUNDARY-START(12885119338),
    {
      "r": $.$$.STT.Task$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "request",
          "p": 131073
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "Send",
      "o": "LCFCM$IMediator$Send",
      "d": 217450,
      "h": 12885119338,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885119338),
//--TRIMMABLE-BOUNDARY-START(4295184746),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": 131073
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "Publish",
      "o": "LCFCM$IMediator$Publish",
      "d": 217450,
      "h": 4295184746,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295184746),
//--TRIMMABLE-BOUNDARY-START(8590152042),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": (TNotification) => TNotification.$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "TNotification"
      ],
      "n": "Publish",
      "o": "LCFCM$IMediator$Publish$1",
      "d": 217450,
      "h": 8590152042,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590152042)
  ],
  "h": 217450
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.IMediator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}IMediator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(217450)
        
        

        //--TRIMMABLE-BOUNDARY-START(348522)
        $asm.$cls(`$tUcV.LCFCM.INotificationHandler<>`, (/*in*/ TNotification) => $asm.$gt(`$tUcV.LCFCM.INotificationHandler<>`, [/*in*/ TNotification], ($self) => class INotificationHandler$$
        {
            static $H = 348522;
            static $h = 348522;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295315818),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": TNotification?.$h??1572864,
          "f": 32
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "o": `LCFCM$INotificationHandler$${TNotification.$getFullName('$')}$Handle`,
      "d": this.$h,
      "H": 4295315818,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295315818)
  ],
  "s": [
    {
      "h": TNotification?.$h??1572864,
      "n": "TNotification",
      "f": 16,
      "c": [282986
      ]
    }
  ],
  "r": 1,
  "H": 348522,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.INotificationHandler<${TNotification?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}INotificationHandler$${TNotification?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(348522)
        
        

        //--TRIMMABLE-BOUNDARY-START(1069418)
        $asm.$cls(`$tUcV.LCFCM.IRequestHandler<,>`, (/*in*/ TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCM.IRequestHandler<,>`, [/*in*/ TRequest, TResponse], ($self) => class IRequestHandler$$$
        {
            static $H = 1069418;
            static $h = 1069418;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296036714),
    {
      "r": $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864,
          "f": 32
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "o": `LCFCM$IRequestHandler$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Handle`,
      "d": this.$h,
      "H": 4296036714,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296036714)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "f": 16,
      "c": [$.$tUcV.LCFCM.IRequest$$(TResponse).$h
      ]
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 1069418,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.IRequestHandler<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}IRequestHandler$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1069418)
        
        

        //--TRIMMABLE-BOUNDARY-START(282986)
        $asm.$cls(`$tUcV.LCFCM.INotification`, ($self) => class INotification
        {
            static $h = 282986;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 282986
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.INotification`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}INotification`; }
        });
        //--TRIMMABLE-BOUNDARY-END(282986)
        
        

        //--TRIMMABLE-BOUNDARY-START(1659242)
        $asm.$cls(`$tUcV.LCFCMP.IRequestExceptionHandler<,,>`, (/*in*/ TRequest, TResponse, TException) => $asm.$gt(`$tUcV.LCFCMP.IRequestExceptionHandler<,,>`, [/*in*/ TRequest, TResponse, TException], ($self) => class IRequestExceptionHandler$$$$
        {
            static $H = 1659242;
            static $h = 1659242;
            static $g = 3;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296626538),
    {
      "r": 178454529,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864,
          "f": 32
        },
        {
          "n": "exception",
          "p": TException?.$h??1703936
        },
        {
          "n": "state",
          "p": $.$tUcV.LCFCMP.RequestExceptionHandlerState$$(TResponse).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "o": `LCFCMP$IRequestExceptionHandler$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$${TException.$getFullName('$')}$Handle`,
      "d": this.$h,
      "H": 4296626538,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296626538)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "f": 16
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    },
    {
      "h": TException?.$h??1703936,
      "n": "TException",
      "c": [80805889
      ]
    }
  ],
  "r": 3,
  "H": 1659242,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.IRequestExceptionHandler<${TRequest?.$fullName},${TResponse?.$fullName},${TException?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}IRequestExceptionHandler$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$${TException?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1659242)
        
        

        //--TRIMMABLE-BOUNDARY-START(1003882)
        $asm.$cls(`$tUcV.LCFCM.IRequest<>`, (/*out*/ TResponse) => $asm.$gt(`$tUcV.LCFCM.IRequest<>`, [/*out*/ TResponse], ($self) => class IRequest$$
        {
            static $H = 1003882;
            static $h = 1003882;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TResponse?.$h??1572864,
      "n": "TResponse",
      "f": 32
    }
  ],
  "r": 1,
  "H": 1003882,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IBaseRequest ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.IRequest<${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}IRequest$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1003882)
        
        

        //--TRIMMABLE-BOUNDARY-START(479594)
        $asm.$cls(`$tUcV.LCFCMI.NotificationHandlerWrapper`, ($self) => class NotificationHandlerWrapper extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295446890)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295446890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295446890)
            
            //--TRIMMABLE-BOUNDARY-START(4295446890)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295446890)
            
            static $h = 479594;
            static $f = 0b110000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590414186),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": 282986
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "serviceFactory",
          "p": 62949718
        },
        {
          "n": "publish",
          "p": $.$$.S.Func$$$$$($.$$.SCG.IEnumerable$$($.$$.S.Func$$$$($.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task)), $.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task).$h
        }
      ],
      "n": "Handle",
      "d": 479594,
      "h": 8590414186,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590414186)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295446890),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 479594,
      "h": 4295446890,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295446890)
  ],
  "h": 479594
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Internal.NotificationHandlerWrapper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Internal${separator}NotificationHandlerWrapper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(479594)
        
        

        //--TRIMMABLE-BOUNDARY-START(676202)
        $asm.$cls(`$tUcV.LCFCMI.RequestHandlerBase`, ($self) => class RequestHandlerBase extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590610794)
            static /*THandler */ GetHandler(THandler, /*ServiceFactory*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590610794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*THandler*/ let handler;
                try
                {
                    handler = $.$fPer.LCFCS$3.ServiceFactoryExtensions.Get$1(THandler, factory);
                }
                catch(e)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$11(`Error constructing handler for request of type ${$.$strNN(THandler.$type.ToString())}. Register your handlers with the container. See the samples in GitHub for examples.`, e);
                }
                if (handler === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Handler was not found for request of type ${$.$strNN(THandler.$type.ToString())}. Register your handlers with the container. See the samples in GitHub for examples.`);
                }
                return handler;
            }
            //--TRIMMABLE-BOUNDARY-END(8590610794)
            
            //--TRIMMABLE-BOUNDARY-START(4295643498)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295643498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295643498)
            
            //--TRIMMABLE-BOUNDARY-START(4295643498)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295643498)
            
            static $h = 676202;
            static $f = 0b110000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885578090),
    {
      "r": $.$$.STT.Task$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "request",
          "p": 131073
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "serviceFactory",
          "p": 62949718
        }
      ],
      "n": "Handle",
      "d": 676202,
      "h": 12885578090,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885578090),
//--TRIMMABLE-BOUNDARY-START(8590610794),
    {
      "r": (THandler) => THandler.$h,
      "p": [
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "THandler"
      ],
      "n": "GetHandler",
      "d": 676202,
      "h": 8590610794,
      "f": 16908324
    },
//--TRIMMABLE-BOUNDARY-END(8590610794)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295643498),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 676202,
      "h": 4295643498,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295643498)
  ],
  "h": 676202
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Internal.RequestHandlerBase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Internal${separator}RequestHandlerBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(676202)
        
        

        //--TRIMMABLE-BOUNDARY-START(1331562)
        $asm.$cls(`$tUcV.LCFCM.NotificationHandler<>`, (TNotification) => $asm.$gt(`$tUcV.LCFCM.NotificationHandler<>`, [TNotification], ($self) => class NotificationHandler$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886233450)
            /*Task */ [`LCFCM$INotificationHandler$${TNotification.$getFullName('$')}$Handle`](/*TNotification*/ notification, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886233450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Handle(notification);
                return $.$tUcV.LCFCM.Unit.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(12886233450)
            
            //--TRIMMABLE-BOUNDARY-START(4296298858)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296298858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296298858)
            
            //--TRIMMABLE-BOUNDARY-START(4296298858)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296298858)
            
            static $H = 1331562;
            static $h = 1331562;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591266154),
    {
      "r": 65537,
      "p": [
        {
          "n": "notification",
          "p": TNotification?.$h??1572864
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 8591266154,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8591266154)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296298858),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296298858,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296298858)
  ],
  "s": [
    {
      "h": TNotification?.$h??1572864,
      "n": "TNotification",
      "c": [282986
      ]
    }
  ],
  "r": 1,
  "H": 1331562,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.INotificationHandler$$(TNotification) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.NotificationHandler<${TNotification?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}NotificationHandler$${TNotification?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1331562)
        
        

        //--TRIMMABLE-BOUNDARY-START(1921386)
        $asm.$cls(`$tUcV.LCFCMP.RequestExceptionAction<,>`, (TRequest, TException) => $asm.$gt(`$tUcV.LCFCMP.RequestExceptionAction<,>`, [TRequest, TException], ($self) => class RequestExceptionAction$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886823274)
            /*Task */ [`LCFCMP$IRequestExceptionAction$${TRequest.$getFullName('$')}$${TException.$getFullName('$')}$Execute`](/*TRequest*/ request, /*TException*/ exception, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886823274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Execute(request, exception);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12886823274)
            
            //--TRIMMABLE-BOUNDARY-START(4296888682)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296888682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296888682)
            
            //--TRIMMABLE-BOUNDARY-START(4296888682)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296888682)
            
            static $H = 1921386;
            static $h = 1921386;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591855978),
    {
      "r": 65537,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "exception",
          "p": TException?.$h??1638400
        }
      ],
      "n": "Execute",
      "d": this.$h,
      "H": 8591855978,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8591855978)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296888682),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296888682,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296888682)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest"
    },
    {
      "h": TException?.$h??1638400,
      "n": "TException",
      "c": [80805889
      ]
    }
  ],
  "r": 2,
  "H": 1921386,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCMP.IRequestExceptionAction$$$(TRequest, TException) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.RequestExceptionAction<${TRequest?.$fullName},${TException?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}RequestExceptionAction$${TRequest?.$getFullName(separator)}$${TException?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1921386)
        
        

        //--TRIMMABLE-BOUNDARY-START(2511210)
        $asm.$cls(`$tUcV.LCFCM.RequestHandler<,>`, (TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCM.RequestHandler<,>`, [TRequest, TResponse], ($self) => class RequestHandler$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887413098)
            /*Task<TResponse> */ [`LCFCM$IRequestHandler$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Handle`](/*TRequest*/ request, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887413098);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.Task.FromResult(TResponse, this.Handle(request));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887413098)
            
            //--TRIMMABLE-BOUNDARY-START(4297478506)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297478506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297478506)
            
            //--TRIMMABLE-BOUNDARY-START(4297478506)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297478506)
            
            static $H = 2511210;
            static $h = 2511210;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592445802),
    {
      "r": TResponse?.$h??1638400,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 8592445802,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8592445802)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297478506),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4297478506,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297478506)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "c": [$.$tUcV.LCFCM.IRequest$$(TResponse).$h
      ]
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 2511210,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IRequestHandler$$$(TRequest, TResponse) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.RequestHandler<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}RequestHandler$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2511210)
        
        

        //--TRIMMABLE-BOUNDARY-START(2117994)
        $asm.$cls(`$tUcV.LCFCMP.RequestExceptionHandler<,,>`, (TRequest, TResponse, TException) => $asm.$gt(`$tUcV.LCFCMP.RequestExceptionHandler<,,>`, [TRequest, TResponse, TException], ($self) => class RequestExceptionHandler$$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887019882)
            /*Task */ [`LCFCMP$IRequestExceptionHandler$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$${TException.$getFullName('$')}$Handle`](/*TRequest*/ request, /*TException*/ exception, /*RequestExceptionHandlerState<TResponse>*/ state, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887019882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Handle(request, exception, state);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12887019882)
            
            //--TRIMMABLE-BOUNDARY-START(4297085290)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297085290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297085290)
            
            //--TRIMMABLE-BOUNDARY-START(4297085290)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297085290)
            
            static $H = 2117994;
            static $h = 2117994;
            static $g = 3;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592052586),
    {
      "r": 65537,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "exception",
          "p": TException?.$h??1703936
        },
        {
          "n": "state",
          "p": $.$tUcV.LCFCMP.RequestExceptionHandlerState$$(TResponse).$h
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 8592052586,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8592052586)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297085290),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4297085290,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297085290)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest"
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    },
    {
      "h": TException?.$h??1703936,
      "n": "TException",
      "c": [80805889
      ]
    }
  ],
  "r": 3,
  "H": 2117994,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCMP.IRequestExceptionHandler$$$$(TRequest, TResponse, TException) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.RequestExceptionHandler<${TRequest?.$fullName},${TResponse?.$fullName},${TException?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}RequestExceptionHandler$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$${TException?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2117994)
        
        

        //--TRIMMABLE-BOUNDARY-START(741738)
        $asm.$cls(`$tUcV.LCFCMI.RequestHandlerWrapper<>`, (TResponse) => $asm.$gt(`$tUcV.LCFCMI.RequestHandlerWrapper<>`, [TResponse], ($self) => class RequestHandlerWrapper$$ extends $.$tUcV.LCFCMI.RequestHandlerBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295709034)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295709034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295709034)
            
            //--TRIMMABLE-BOUNDARY-START(4295709034)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295709034)
            
            static $H = 741738;
            static $h = 741738;
            static $g = 1;
            static $f = 0b1110000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$tUcV.LCFCMI.RequestHandlerBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590676330),
    {
      "r": $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "request",
          "p": $.$tUcV.LCFCM.IRequest$$(TResponse).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "serviceFactory",
          "p": 62949718
        }
      ],
      "n": "Handle",
      "o": "@$1",
      "d": this.$h,
      "H": 8590676330,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590676330)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295709034),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4295709034,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295709034)
  ],
  "s": [
    {
      "h": TResponse?.$h??1572864,
      "n": "TResponse"
    }
  ],
  "r": 1,
  "H": 741738,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Internal.RequestHandlerWrapper<${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Internal${separator}RequestHandlerWrapper$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(741738)
        
        

        //--TRIMMABLE-BOUNDARY-START(2249066)
        $asm.$cls(`$tUcV.LCFCMP.RequestExceptionHandlerState<>`, (TResponse) => $asm.$gt(`$tUcV.LCFCMP.RequestExceptionHandlerState<>`, [TResponse], ($self) => class RequestExceptionHandlerState$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361987434)
            /*bool*/ Handled = false;
            //--TRIMMABLE-BOUNDARY-END(34361987434)
            
            //--TRIMMABLE-BOUNDARY-START(38656954730)
            /*TResponse*/ Response = $.$default(TResponse);
            //--TRIMMABLE-BOUNDARY-END(38656954730)
            
            //--TRIMMABLE-BOUNDARY-START(60131791210)
            /*void */ SetHandled(/*TResponse*/ response)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131791210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Handled = true;
                this.Response = response;
            }
            //--TRIMMABLE-BOUNDARY-END(60131791210)
            
            //--TRIMMABLE-BOUNDARY-START(12887150954)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887150954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887150954)
            
            //--TRIMMABLE-BOUNDARY-START(12887150954)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12887150954)
            
            static $H = 2249066;
            static $h = 2249066;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361987434),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21477085546,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47246889322,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 83886082
      },
      "n": "Handled",
      "d": this.$h,
      "H": 34361987434,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361987434),
//--TRIMMABLE-BOUNDARY-START(38656954730),
    {
      "p": TResponse?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30067020138,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 55836823914,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 83886082
      },
      "n": "Response",
      "d": this.$h,
      "H": 38656954730,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656954730)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131791210),
    {
      "r": 65537,
      "p": [
        {
          "n": "response",
          "p": TResponse?.$h??1572864,
          "f": 65
        }
      ],
      "n": "SetHandled",
      "d": this.$h,
      "H": 60131791210,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131791210)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887150954),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12887150954,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887150954)
  ],
  "s": [
    {
      "h": TResponse?.$h??1572864,
      "n": "TResponse"
    }
  ],
  "r": 1,
  "H": 2249066,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.RequestExceptionHandlerState<${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}RequestExceptionHandlerState$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2249066)
        
        

        //--TRIMMABLE-BOUNDARY-START(414058)
        $asm.$cls(`$tUcV.LCFCMI.HandlersOrderer`, ($self) => class HandlersOrderer
        {
            //--TRIMMABLE-BOUNDARY-START(4295381354)
            static /*IList<object> */ Prioritize(TRequest, /*IList<object>*/ handlers, /*TRequest*/ request)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295381354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (handlers.SCG$ICollection$$$Count < 2)
                {
                    return handlers;
                }
                /*var*/ let requestObjectDetails = new $.$tUcV.LCFCMI.ObjectDetails().$ctor$1($.$box(request, TRequest));
                /*var*/ let handlerObjectsDetails = $.$sl.SL.Enumerable.ToList($.$tUcV.LCFCMI.ObjectDetails, $.$sl.SL.Enumerable.Select$1($.$$.S.Object, $.$tUcV.LCFCMI.ObjectDetails, handlers, new ($.$$.S.Func$$$($.$$.S.Object, $.$tUcV.LCFCMI.ObjectDetails))().$ctor(this,  (/*s*/ s) =>
                {
                    return new $.$tUcV.LCFCMI.ObjectDetails().$ctor$1(s);
                }, $dtFAAd ??= {"r":610666,"p":[{"n":"s","p":131073}],"n":"","d":414058,"h":0,"f":17825794})));
                /*var*/ let uniqueHandlers = $.$sl.SL.Enumerable.ToArray($.$tUcV.LCFCMI.ObjectDetails, $.$tUcV.LCFCMI.HandlersOrderer.RemoveOverridden(handlerObjectsDetails));
                $.$$.S.Array.Sort$8($.$tUcV.LCFCMI.ObjectDetails, uniqueHandlers, requestObjectDetails);
                return $.$sl.SL.Enumerable.ToList($.$$.S.Object, $.$sl.SL.Enumerable.Select$1($.$tUcV.LCFCMI.ObjectDetails, $.$$.S.Object, uniqueHandlers, new ($.$$.S.Func$$$($.$tUcV.LCFCMI.ObjectDetails, $.$$.S.Object))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.Value;
                }, $dNEXob ??= {"r":131073,"p":[{"n":"s","p":610666}],"n":"","d":414058,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(4295381354)
            
            //--TRIMMABLE-BOUNDARY-START(8590348650)
            static /*IEnumerable<ObjectDetails> */ RemoveOverridden(/*IList<ObjectDetails>*/ handlersData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590348650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < ((handlersData.SCG$ICollection$$$Count - 1) | 0); i++)
                {
                    for(/*int*/ let j = ((i + 1) | 0); j < handlersData.SCG$ICollection$$$Count; j++)
                    {
                        if (handlersData.SCG$IList$$$get_Item(i).IsOverridden || handlersData.SCG$IList$$$get_Item(j).IsOverridden)
                        {
                            continue;
                        }
                        if (handlersData.SCG$IList$$$get_Item(i).Type.IsAssignableFrom(handlersData.SCG$IList$$$get_Item(j).Type))
                        {
                            handlersData.SCG$IList$$$get_Item(i).IsOverridden = true;
                        }
                        else if (handlersData.SCG$IList$$$get_Item(j).Type.IsAssignableFrom(handlersData.SCG$IList$$$get_Item(i).Type))
                        {
                            handlersData.SCG$IList$$$get_Item(j).IsOverridden = true;
                        }
                    }
                }
                return $.$sl.SL.Enumerable.Where($.$tUcV.LCFCMI.ObjectDetails, handlersData, new ($.$$.S.Func$$$($.$tUcV.LCFCMI.ObjectDetails, $.$$.S.Boolean))().$ctor(this,  (/*w*/ w) =>
                {
                    return !w.IsOverridden;
                }, $VcNLBi ??= {"r":262145,"p":[{"n":"w","p":610666}],"n":"","d":414058,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590348650)
            
            static $h = 414058;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295381354),
    {
      "r": $.$$.SCG.IList$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "handlers",
          "p": $.$$.SCG.IList$$($.$$.S.Object).$h
        },
        {
          "n": "request",
          "p": (TRequest) => TRequest.$h
        }
      ],
      "g": [
        "TRequest"
      ],
      "n": "Prioritize",
      "d": 414058,
      "h": 4295381354,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295381354),
//--TRIMMABLE-BOUNDARY-START(8590348650),
    {
      "r": $.$$.SCG.IEnumerable$$($.$tUcV.LCFCMI.ObjectDetails).$h,
      "p": [
        {
          "n": "handlersData",
          "p": $.$$.SCG.IList$$($.$tUcV.LCFCMI.ObjectDetails).$h
        }
      ],
      "n": "RemoveOverridden",
      "d": 414058,
      "h": 8590348650,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590348650)
  ],
  "h": 414058
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Internal.HandlersOrderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Internal${separator}HandlersOrderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(414058)
        
        

        //--TRIMMABLE-BOUNDARY-START(2380138)
        $asm.$cls(`$tUcV.LCFCMP.RequestPostProcessorBehavior<,>`, (TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCMP.RequestPostProcessorBehavior<,>`, [TRequest, TResponse], ($self) => class RequestPostProcessorBehavior$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297347434)
            /*IEnumerable<IRequestPostProcessor<TRequest, TResponse>>*/ _postProcessors = null;
            //--TRIMMABLE-BOUNDARY-END(4297347434)
            
            //--TRIMMABLE-BOUNDARY-START(8592314730)
            $ctor$1(/*IEnumerable<IRequestPostProcessor<TRequest, TResponse>>*/ postProcessors)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592314730);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._postProcessors = postProcessors;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592314730)
            
            //--TRIMMABLE-BOUNDARY-START(12887282026)
            /*Task<TResponse> *//*async*/  Handle(/*TRequest*/ request, /*CancellationToken*/ cancellationToken, /*RequestHandlerDelegate<TResponse>*/ next)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TResponse), TResponse, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887282026);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let response = ($t1 = next.Invoke().ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    let $en2 = this._postProcessors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let processor = $en2.SCG$IEnumerator$$$Current;
                        {
                            let $t3, $r3;
                            ($t3 = processor[`LCFCMP$IRequestPostProcessor$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Process`](request, response, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, response);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12887282026)
            
            //--TRIMMABLE-BOUNDARY-START(4295840106)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.IPipelineBehavior<TRequest, TResponse>.Handle(TRequest, System.Threading.CancellationToken, LivingThing.Core.Frameworks.Common.Mediator.RequestHandlerDelegate<TResponse>)
            [`LCFCM$IPipelineBehavior$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Handle`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295840106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295840106)
            
            static $H = 2380138;
            static $h = 2380138;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887282026),
    {
      "r": $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "next",
          "p": $.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse).$h
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 12887282026,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12887282026)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297347434),
    {
      "t": $.$$.SCG.IEnumerable$$($.$tUcV.LCFCMP.IRequestPostProcessor$$$(TRequest, TResponse)).$h,
      "n": "_postProcessors",
      "d": this.$h,
      "H": 4297347434,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297347434)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592314730),
    {
      "p": [
        {
          "n": "postProcessors",
          "p": $.$$.SCG.IEnumerable$$($.$tUcV.LCFCMP.IRequestPostProcessor$$$(TRequest, TResponse)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8592314730,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592314730)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest"
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 2380138,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IPipelineBehavior$$$(TRequest, TResponse) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.RequestPostProcessorBehavior<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}RequestPostProcessorBehavior$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2380138)
        
        

        //--TRIMMABLE-BOUNDARY-START(2707818)
        $asm.$cls(`$tUcV.LCFCM.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592642410)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592642410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$tUcV.LCFCM.IMediator, $.$tUcV.LCFCM.Mediator, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592642410)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$tUcV.LCFCM.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297675114)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297675114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297675114)
            
            //--TRIMMABLE-BOUNDARY-START(4297675114)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297675114)
            
            static $h = 2707818;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592642410),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2707818,
      "h": 8592642410,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592642410)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297675114),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2707818,
      "h": 4297675114,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297675114)
  ],
  "h": 2707818
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2707818)
        
        

        //--TRIMMABLE-BOUNDARY-START(2445674)
        $asm.$cls(`$tUcV.LCFCMP.RequestPreProcessorBehavior<,>`, (TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCMP.RequestPreProcessorBehavior<,>`, [TRequest, TResponse], ($self) => class RequestPreProcessorBehavior$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297412970)
            /*IEnumerable<IRequestPreProcessor<TRequest>>*/ _preProcessors = null;
            //--TRIMMABLE-BOUNDARY-END(4297412970)
            
            //--TRIMMABLE-BOUNDARY-START(8592380266)
            $ctor$1(/*IEnumerable<IRequestPreProcessor<TRequest>>*/ preProcessors)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592380266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._preProcessors = preProcessors;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592380266)
            
            //--TRIMMABLE-BOUNDARY-START(12887347562)
            /*Task<TResponse> *//*async*/  Handle(/*TRequest*/ request, /*CancellationToken*/ cancellationToken, /*RequestHandlerDelegate<TResponse>*/ next)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TResponse), TResponse, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887347562);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en1 = this._preProcessors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let processor = $en1.SCG$IEnumerator$$$Current;
                        {
                            let $t2, $r2;
                            ($t2 = processor[`LCFCMP$IRequestPreProcessor$${TRequest.$getFullName('$')}$Process`](request, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = next.Invoke().ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12887347562)
            
            //--TRIMMABLE-BOUNDARY-START(4295840106)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.IPipelineBehavior<TRequest, TResponse>.Handle(TRequest, System.Threading.CancellationToken, LivingThing.Core.Frameworks.Common.Mediator.RequestHandlerDelegate<TResponse>)
            [`LCFCM$IPipelineBehavior$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Handle`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295840106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295840106)
            
            static $H = 2445674;
            static $h = 2445674;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887347562),
    {
      "r": $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "next",
          "p": $.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse).$h
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 12887347562,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12887347562)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297412970),
    {
      "t": $.$$.SCG.IEnumerable$$($.$tUcV.LCFCMP.IRequestPreProcessor$$(TRequest)).$h,
      "n": "_preProcessors",
      "d": this.$h,
      "H": 4297412970,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297412970)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592380266),
    {
      "p": [
        {
          "n": "preProcessors",
          "p": $.$$.SCG.IEnumerable$$($.$tUcV.LCFCMP.IRequestPreProcessor$$(TRequest)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8592380266,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592380266)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest"
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 2445674,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IPipelineBehavior$$$(TRequest, TResponse) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.RequestPreProcessorBehavior<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}RequestPreProcessorBehavior$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2445674)
        
        

        //--TRIMMABLE-BOUNDARY-START(2052458)
        $asm.$cls(`$tUcV.LCFCMP.RequestExceptionActionProcessorBehavior<,>`, (TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCMP.RequestExceptionActionProcessorBehavior<,>`, [TRequest, TResponse], ($self) => class RequestExceptionActionProcessorBehavior$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297019754)
            /*ServiceFactory*/ _serviceFactory = null;
            //--TRIMMABLE-BOUNDARY-END(4297019754)
            
            //--TRIMMABLE-BOUNDARY-START(8591987050)
            $ctor$1(/*ServiceFactory*/ serviceFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591987050);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._serviceFactory = serviceFactory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591987050)
            
            //--TRIMMABLE-BOUNDARY-START(17181921642)
            /*Task<TResponse> *//*async*/  Handle(/*TRequest*/ request, /*CancellationToken*/ cancellationToken, /*RequestHandlerDelegate<TResponse>*/ next)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TResponse), TResponse, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181921642);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t1, $r1;
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = next.Invoke().ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                    }
                    catch(exception)
                    {
                        /*MethodInfo*/ let actionMethod;
                        /*var*/ let actionsForException = this.GetActionsForException(exception.GetType$1(), request, $.$ref(() => actionMethod, ($v) => actionMethod = $v, $.$$.SR.MethodInfo));
                        let $en3 = actionsForException.SCG$IEnumerable$$$GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let actionForException = $en3.SCG$IEnumerator$$$Current;
                            {
                                let $t4, $r4;
                                ($t4 = ($.$cast(actionMethod.Invoke(actionForException, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [$.$box(request, TRequest), exception, cancellationToken], [-1], null)), $.$$.STT.Task)).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                            }
                        }
                        throw exception;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17181921642)
            
            //--TRIMMABLE-BOUNDARY-START(12886954346)
            /*IList<object> */ GetActionsForException(/*Type*/ exceptionType, /*TRequest*/ request, /*out MethodInfo*/ actionMethodInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886954346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let exceptionActionInterfaceType = $.$tUcV.LCFCMP.IRequestExceptionAction$$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ TRequest.$type, exceptionType ], null, null));
                /*var*/ let enumerableExceptionActionInterfaceType = $.$$.SCG.IEnumerable$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ exceptionActionInterfaceType ], null, null));
                actionMethodInfo.$v = exceptionActionInterfaceType.GetMethod$12("Execute");
                /*var*/ let actionsForException = $.$cast(this._serviceFactory.Invoke(enumerableExceptionActionInterfaceType, true), $.$$.SCG.IEnumerable$$($.$$.S.Object));
                return $.$tUcV.LCFCMI.HandlersOrderer.Prioritize(TRequest, $.$sl.SL.Enumerable.ToList($.$$.S.Object, actionsForException), request);
            }
            //--TRIMMABLE-BOUNDARY-END(12886954346)
            
            //--TRIMMABLE-BOUNDARY-START(4295840106)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.IPipelineBehavior<TRequest, TResponse>.Handle(TRequest, System.Threading.CancellationToken, LivingThing.Core.Frameworks.Common.Mediator.RequestHandlerDelegate<TResponse>)
            [`LCFCM$IPipelineBehavior$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Handle`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295840106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295840106)
            
            static $H = 2052458;
            static $h = 2052458;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181921642),
    {
      "r": $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "next",
          "p": $.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse).$h
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 17181921642,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17181921642),
//--TRIMMABLE-BOUNDARY-START(12886954346),
    {
      "r": $.$$.SCG.IList$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "exceptionType",
          "p": 188547073
        },
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "actionMethodInfo",
          "p": 117571585,
          "f": 2
        }
      ],
      "n": "GetActionsForException",
      "d": this.$h,
      "H": 12886954346,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886954346)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297019754),
    {
      "t": 62949718,
      "n": "_serviceFactory",
      "d": this.$h,
      "H": 4297019754,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297019754)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591987050),
    {
      "p": [
        {
          "n": "serviceFactory",
          "p": 62949718
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8591987050,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591987050)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest"
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 2052458,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IPipelineBehavior$$$(TRequest, TResponse) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.RequestExceptionActionProcessorBehavior<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}RequestExceptionActionProcessorBehavior$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2052458)
        
        

        //--TRIMMABLE-BOUNDARY-START(1266026)
        $asm.$cls(`$tUcV.LCFCM.Mediator`, ($self) => class Mediator extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886167914)
            /*ServiceFactory*/ _serviceFactory = null;
            //--TRIMMABLE-BOUNDARY-END(12886167914)
            
            //--TRIMMABLE-BOUNDARY-START(8591200618)
            /*ConcurrentDictionary<Type, object>*/ static _requestHandlers = null;
            //--TRIMMABLE-BOUNDARY-END(8591200618)
            
            //--TRIMMABLE-BOUNDARY-START(4296233322)
            /*ConcurrentDictionary<Type, NotificationHandlerWrapper>*/ static _notificationHandlers = null;
            //--TRIMMABLE-BOUNDARY-END(4296233322)
            
            //--TRIMMABLE-BOUNDARY-START(21476102506)
            $ctor$1(/*ServiceFactory*/ serviceFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476102506);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._serviceFactory = serviceFactory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476102506)
            
            //--TRIMMABLE-BOUNDARY-START(47245906282)
            /*Task<TResponse> */ Send$1(TResponse, /*IRequest<TResponse>*/ request, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245906282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (request === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("request");
                }
                /*var*/ let requestType = $.$$.S.Object.GetType.call(request);
                /*var*/ let handler = $.$cast($.$tUcV.LCFCM.Mediator._requestHandlers.GetOrAdd(requestType, new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Object))().$ctor(this,  (/*t*/ t) =>
                {
                    return $.$$.S.Activator.CreateInstance$9($.$tUcV.LCFCMI.RequestHandlerWrapperImpl$$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ requestType, TResponse.$type ], null, null)));
                }, $aEiOle ??= {"r":131073,"p":[{"n":"t","p":188547073}],"n":"","d":1266026,"h":0,"f":17825794})), $.$tUcV.LCFCMI.RequestHandlerWrapper$$(TResponse));
                return handler.Handle$1(request, cancellationToken, this._serviceFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(47245906282)
            
            //--TRIMMABLE-BOUNDARY-START(42950938986)
            /*Task<object> */ Send(/*object*/ request, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950938986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (request === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("request");
                }
                /*var*/ let requestType = $.$$.S.Object.GetType.call(request);
                /*var*/ let requestInterfaceType = $.$sl.SL.Enumerable.FirstOrDefault$1($.$$.S.Type, requestType.GetInterfaces(), new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Boolean))().$ctor(this,  (/*i*/ i) =>
                {
                    return i.IsGenericType && i.GetGenericTypeDefinition() === $.$tUcV.LCFCM.IRequest$$().$type;
                }, $KQqJed ??= {"r":262145,"p":[{"n":"i","p":188547073}],"n":"","d":1266026,"h":0,"f":17825794}));
                /*var*/ let isValidRequest = requestInterfaceType !== null;
                if (!isValidRequest)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14(`${$.$strNN("request")} does not implement \$${$.$strNN("IRequest")}`);
                }
                /*var*/ let responseType = $.$$.System.Array.$ReadT1.call(requestInterfaceType.GetGenericArguments(), 0);
                /*var*/ let handler = $.$tUcV.LCFCM.Mediator._requestHandlers.GetOrAdd(requestType, new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Object))().$ctor(this,  (/*t*/ t) =>
                {
                    return $.$$.S.Activator.CreateInstance$9($.$tUcV.LCFCMI.RequestHandlerWrapperImpl$$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ requestType, responseType ], null, null)));
                }, $kAVOGi ??= {"r":131073,"p":[{"n":"t","p":188547073}],"n":"","d":1266026,"h":0,"f":17825794}));
                return ($.$cast(handler, $.$tUcV.LCFCMI.RequestHandlerBase)).Handle(request, cancellationToken, this._serviceFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(42950938986)
            
            //--TRIMMABLE-BOUNDARY-START(30066037098)
            /*Task */ Publish$1(TNotification, /*TNotification*/ notification, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066037098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (notification === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("notification");
                }
                return this.PublishNotification($.$box(notification, TNotification), cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(30066037098)
            
            //--TRIMMABLE-BOUNDARY-START(25771069802)
            /*Task */ Publish(/*object*/ notification, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771069802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (notification === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("notification");
                }
                let instance;
                if ($.$is(notification, $.$tUcV.LCFCM.INotification, { set $v($v){ instance = $v; } }))
                {
                    return this.PublishNotification(instance, cancellationToken);
                }
                throw new $.$$.S.ArgumentException().$ctor$14(`${$.$strNN("notification")} does not implement \$${$.$strNN("INotification")}`);
            }
            //--TRIMMABLE-BOUNDARY-END(25771069802)
            
            //--TRIMMABLE-BOUNDARY-START(34361004394)
            /*Task *//*async*/  PublishCore(/*IEnumerable<Func<INotification, CancellationToken, Task>>*/ allHandlers, /*INotification*/ notification, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361004394);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $en1 = allHandlers.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let handler = $en1.SCG$IEnumerator$$$Current;
                        {
                            let $t2, $r2;
                            ($t2 = handler.Invoke(notification, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34361004394)
            
            //--TRIMMABLE-BOUNDARY-START(38655971690)
            /*Task */ PublishNotification(/*INotification*/ notification, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655971690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let notificationType = $.$$.S.Object.GetType.call(notification);
                /*var*/ let handler = $.$tUcV.LCFCM.Mediator._notificationHandlers.GetOrAdd(notificationType, new ($.$$.S.Func$$$($.$$.S.Type, $.$tUcV.LCFCMI.NotificationHandlerWrapper))().$ctor(this,  (/*t*/ t) =>
                {
                    return $.$cast($.$$.S.Activator.CreateInstance$9($.$tUcV.LCFCMI.NotificationHandlerWrapperImpl$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ notificationType ], null, null))), $.$tUcV.LCFCMI.NotificationHandlerWrapper);
                }, $SVntda ??= {"r":479594,"p":[{"n":"t","p":188547073}],"n":"","d":1266026,"h":0,"f":17825794}));
                return handler.Handle(notification, cancellationToken, this._serviceFactory, new ($.$$.S.Func$$$$$($.$$.SCG.IEnumerable$$($.$$.S.Func$$$$($.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task)), $.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task))().$ctor(this, this.PublishCore));
            }
            //--TRIMMABLE-BOUNDARY-END(38655971690)
            
            //--TRIMMABLE-BOUNDARY-START(17180086634)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.IMediator.Send<TResponse>(LivingThing.Core.Frameworks.Common.Mediator.IRequest<TResponse>, System.Threading.CancellationToken)
            LCFCM$IMediator$Send$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180086634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Send$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180086634)
            
            //--TRIMMABLE-BOUNDARY-START(12885119338)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.IMediator.Send(object, System.Threading.CancellationToken)
            LCFCM$IMediator$Send()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885119338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Send(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885119338)
            
            //--TRIMMABLE-BOUNDARY-START(4295184746)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.IMediator.Publish(object, System.Threading.CancellationToken)
            LCFCM$IMediator$Publish()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295184746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Publish(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295184746)
            
            //--TRIMMABLE-BOUNDARY-START(8590152042)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.IMediator.Publish<TNotification>(TNotification, System.Threading.CancellationToken)
            LCFCM$IMediator$Publish$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590152042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Publish$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590152042)
            
            //--TRIMMABLE-BOUNDARY-START(17181135210)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181135210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8591200618)
                    this._requestHandlers = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$$.S.Object))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(8591200618)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4296233322)
                    this._notificationHandlers = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$tUcV.LCFCMI.NotificationHandlerWrapper))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(4296233322)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181135210)
            
            static $h = 1266026;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245906282),
    {
      "r": (TResponse) => $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "request",
          "p": (TResponse) => $.$tUcV.LCFCM.IRequest$$(TResponse).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "TResponse"
      ],
      "n": "Send",
      "o": "@$1",
      "d": 1266026,
      "h": 47245906282,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(47245906282),
//--TRIMMABLE-BOUNDARY-START(42950938986),
    {
      "r": $.$$.STT.Task$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "request",
          "p": 131073
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "Send",
      "d": 1266026,
      "h": 42950938986,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950938986),
//--TRIMMABLE-BOUNDARY-START(30066037098),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": (TNotification) => TNotification.$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "TNotification"
      ],
      "n": "Publish",
      "o": "@$1",
      "d": 1266026,
      "h": 30066037098,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(30066037098),
//--TRIMMABLE-BOUNDARY-START(25771069802),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": 131073
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "Publish",
      "d": 1266026,
      "h": 25771069802,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771069802),
//--TRIMMABLE-BOUNDARY-START(34361004394),
    {
      "r": 178454529,
      "p": [
        {
          "n": "allHandlers",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.Func$$$$($.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task)).$h
        },
        {
          "n": "notification",
          "p": 282986
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "PublishCore",
      "d": 1266026,
      "h": 34361004394,
      "f": 16781444
    },
//--TRIMMABLE-BOUNDARY-END(34361004394),
//--TRIMMABLE-BOUNDARY-START(38655971690),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": 282986
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "PublishNotification",
      "d": 1266026,
      "h": 38655971690,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655971690)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886167914),
    {
      "t": 62949718,
      "n": "_serviceFactory",
      "d": 1266026,
      "h": 12886167914,
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(12886167914),
//--TRIMMABLE-BOUNDARY-START(8591200618),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$$.S.Object).$h,
      "n": "_requestHandlers",
      "d": 1266026,
      "h": 8591200618,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591200618),
//--TRIMMABLE-BOUNDARY-START(4296233322),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$tUcV.LCFCMI.NotificationHandlerWrapper).$h,
      "n": "_notificationHandlers",
      "d": 1266026,
      "h": 4296233322,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296233322)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476102506),
    {
      "p": [
        {
          "n": "serviceFactory",
          "p": 62949718
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1266026,
      "h": 21476102506,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476102506)
  ],
  "h": 1266026
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IMediator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Mediator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Mediator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1266026)
        
        

        //--TRIMMABLE-BOUNDARY-START(2314602)
        $asm.$cls(`$tUcV.LCFCMP.RequestExceptionProcessorBehavior<,>`, (TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCMP.RequestExceptionProcessorBehavior<,>`, [TRequest, TResponse], ($self) => class RequestExceptionProcessorBehavior$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297281898)
            /*ServiceFactory*/ _serviceFactory = null;
            //--TRIMMABLE-BOUNDARY-END(4297281898)
            
            //--TRIMMABLE-BOUNDARY-START(8592249194)
            $ctor$1(/*ServiceFactory*/ serviceFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592249194);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._serviceFactory = serviceFactory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592249194)
            
            //--TRIMMABLE-BOUNDARY-START(17182183786)
            /*Task<TResponse> *//*async*/  Handle(/*TRequest*/ request, /*CancellationToken*/ cancellationToken, /*RequestHandlerDelegate<TResponse>*/ next)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TResponse), TResponse, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182183786);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t1, $r1;
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = next.Invoke().ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                    }
                    catch(exception)
                    {
                        /*var*/ let state = new ($.$tUcV.LCFCMP.RequestExceptionHandlerState$$(TResponse))().$ctor$1();
                        /*Type*/ let exceptionType = null;
                        while(!state.Handled && exceptionType !== $.$$.S.Exception.$type)
                        {
                            /*MethodInfo*/ let handleMethod;
                            exceptionType = exceptionType === null ? exception.GetType$1() : exceptionType.BaseType;
                            /*var*/ let exceptionHandlers = this.GetExceptionHandlers(request, exceptionType, $.$ref(() => handleMethod, ($v) => handleMethod = $v, $.$$.SR.MethodInfo));
                            let $en3 = exceptionHandlers.SCG$IEnumerable$$$GetEnumerator();
                            while ($en3.SC$1$IEnumerator$MoveNext())
                            {
                                let exceptionHandler = $en3.SCG$IEnumerator$$$Current;
                                {
                                    let $t4, $r4;
                                    ($t4 = ($.$cast(handleMethod.Invoke(exceptionHandler, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [$.$box(request, TRequest), exception, state, cancellationToken], [-1], null)), $.$$.STT.Task)).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                    if (state.Handled)
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                        if (!state.Handled)
                        {
                            throw exception;
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, state.Response);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17182183786)
            
            //--TRIMMABLE-BOUNDARY-START(12887216490)
            /*IList<object> */ GetExceptionHandlers(/*TRequest*/ request, /*Type*/ exceptionType, /*out MethodInfo*/ handleMethodInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887216490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let exceptionHandlerInterfaceType = $.$tUcV.LCFCMP.IRequestExceptionHandler$$$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ TRequest.$type, TResponse.$type, exceptionType ], null, null));
                /*var*/ let enumerableExceptionHandlerInterfaceType = $.$$.SCG.IEnumerable$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ exceptionHandlerInterfaceType ], null, null));
                handleMethodInfo.$v = exceptionHandlerInterfaceType.GetMethod$12("Handle");
                /*var*/ let exceptionHandlers = $.$cast(this._serviceFactory.Invoke(enumerableExceptionHandlerInterfaceType, true), $.$$.SCG.IEnumerable$$($.$$.S.Object));
                return $.$tUcV.LCFCMI.HandlersOrderer.Prioritize(TRequest, $.$sl.SL.Enumerable.ToList($.$$.S.Object, exceptionHandlers), request);
            }
            //--TRIMMABLE-BOUNDARY-END(12887216490)
            
            //--TRIMMABLE-BOUNDARY-START(4295840106)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mediator.IPipelineBehavior<TRequest, TResponse>.Handle(TRequest, System.Threading.CancellationToken, LivingThing.Core.Frameworks.Common.Mediator.RequestHandlerDelegate<TResponse>)
            [`LCFCM$IPipelineBehavior$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Handle`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295840106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295840106)
            
            static $H = 2314602;
            static $h = 2314602;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182183786),
    {
      "r": $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "next",
          "p": $.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse).$h
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 17182183786,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17182183786),
//--TRIMMABLE-BOUNDARY-START(12887216490),
    {
      "r": $.$$.SCG.IList$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "exceptionType",
          "p": 188547073
        },
        {
          "n": "handleMethodInfo",
          "p": 117571585,
          "f": 2
        }
      ],
      "n": "GetExceptionHandlers",
      "d": this.$h,
      "H": 12887216490,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12887216490)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297281898),
    {
      "t": 62949718,
      "n": "_serviceFactory",
      "d": this.$h,
      "H": 4297281898,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297281898)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592249194),
    {
      "p": [
        {
          "n": "serviceFactory",
          "p": 62949718
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8592249194,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592249194)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest"
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 2314602,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IPipelineBehavior$$$(TRequest, TResponse) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.RequestExceptionProcessorBehavior<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}RequestExceptionProcessorBehavior$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2314602)
        
        

        //--TRIMMABLE-BOUNDARY-START(610666)
        $asm.$cls(`$tUcV.LCFCMI.ObjectDetails`, ($self) => class ObjectDetails extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115964727658)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(115964727658)
            
            //--TRIMMABLE-BOUNDARY-START(34360349034)
            /*string*/ AssemblyName = null;
            //--TRIMMABLE-BOUNDARY-END(34360349034)
            
            //--TRIMMABLE-BOUNDARY-START(111669760362)
            /*string*/ Location = null;
            //--TRIMMABLE-BOUNDARY-END(111669760362)
            
            //--TRIMMABLE-BOUNDARY-START(176094269802)
            /*object*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(176094269802)
            
            //--TRIMMABLE-BOUNDARY-START(171799302506)
            /*Type*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(171799302506)
            
            //--TRIMMABLE-BOUNDARY-START(107374793066)
            /*bool*/ IsOverridden = false;
            //--TRIMMABLE-BOUNDARY-END(107374793066)
            
            //--TRIMMABLE-BOUNDARY-START(30065381738)
            $ctor$1(/*object*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065381738);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = value;
                    this.Type = $.$$.S.Object.GetType.call(this.Value);
                    /*var*/ let exceptionHandlerType = $.$$.S.Object.GetType.call(value);
                    this.Name = exceptionHandlerType.Name;
                    this.AssemblyName = exceptionHandlerType.Assembly.GetName().Name;
                    this.Location = $.$$.S.String.Replace$3.call(exceptionHandlerType.Namespace, `${$.$strNN(this.AssemblyName)}.`, $.$$.S.String.Empty);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065381738)
            
            //--TRIMMABLE-BOUNDARY-START(38655316330)
            /*int */ Compare(/*ObjectDetails*/ x, /*ObjectDetails*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655316330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let compareByAssemblyResult = this.CompareByAssembly(x, y);
                if (compareByAssemblyResult !== null)
                {
                    return $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(compareByAssemblyResult);
                }
                /*var*/ let compareByNamespaceResult = this.CompareByNamespace(x, y);
                if (compareByNamespaceResult !== null)
                {
                    return $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(compareByNamespaceResult);
                }
                return this.CompareByLocation(x, y);
            }
            //--TRIMMABLE-BOUNDARY-END(38655316330)
            
            //--TRIMMABLE-BOUNDARY-START(42950283626)
            /*int? */ CompareByAssembly(/*ObjectDetails*/ x, /*ObjectDetails*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950283626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (x.AssemblyName === this.AssemblyName && y.AssemblyName !== this.AssemblyName)
                {
                    return -1;
                }
                else if (x.AssemblyName !== this.AssemblyName && y.AssemblyName === this.AssemblyName)
                {
                    return 1;
                }
                else if (x.AssemblyName !== this.AssemblyName && y.AssemblyName !== this.AssemblyName)
                {
                    return 0;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(42950283626)
            
            //--TRIMMABLE-BOUNDARY-START(51540218218)
            /*int? */ CompareByNamespace(/*ObjectDetails*/ x, /*ObjectDetails*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540218218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.StartsWith$3.call(x.Location, this.Location) && !$.$$.S.String.StartsWith$3.call(y.Location, this.Location))
                {
                    return -1;
                }
                else if (!$.$$.S.String.StartsWith$3.call(x.Location, this.Location) && $.$$.S.String.StartsWith$3.call(y.Location, this.Location))
                {
                    return 1;
                }
                else if ($.$$.S.String.StartsWith$3.call(x.Location, this.Location) && $.$$.S.String.StartsWith$3.call(y.Location, this.Location))
                {
                    return 0;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(51540218218)
            
            //--TRIMMABLE-BOUNDARY-START(47245250922)
            /*int */ CompareByLocation(/*ObjectDetails*/ x, /*ObjectDetails*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245250922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.StartsWith$3.call(this.Location, x.Location) && !$.$$.S.String.StartsWith$3.call(this.Location, y.Location))
                {
                    return -1;
                }
                else if (!$.$$.S.String.StartsWith$3.call(this.Location, x.Location) && $.$$.S.String.StartsWith$3.call(this.Location, y.Location))
                {
                    return 1;
                }
                else if (x.Location.length > y.Location.length)
                {
                    return -1;
                }
                else if (x.Location.length < y.Location.length)
                {
                    return 1;
                }
                else 
                {
                    return 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245250922)
            
            //--TRIMMABLE-BOUNDARY-START(4355129345)
            //Generated interface implemetation for System.Collections.Generic.IComparer<LivingThing.Core.Frameworks.Common.Mediator.Internal.ObjectDetails>.Compare(LivingThing.Core.Frameworks.Common.Mediator.Internal.ObjectDetails?, LivingThing.Core.Frameworks.Common.Mediator.Internal.ObjectDetails?)
            SCG$IComparer$LivingThing$Core$Frameworks$Common$Mediator$Internal$ObjectDetails$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355129345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355129345)
            
            static $h = 610666;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964727658),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899956586,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324466026,
        "f": 83886082
      },
      "n": "Name",
      "d": 610666,
      "h": 115964727658,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964727658),
//--TRIMMABLE-BOUNDARY-START(34360349034),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130152810,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554662250,
        "f": 83886082
      },
      "n": "AssemblyName",
      "d": 610666,
      "h": 34360349034,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360349034),
//--TRIMMABLE-BOUNDARY-START(111669760362),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310021994,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734531434,
        "f": 83886082
      },
      "n": "Location",
      "d": 610666,
      "h": 111669760362,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669760362),
//--TRIMMABLE-BOUNDARY-START(176094269802),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079825770,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504335210,
        "f": 83886082
      },
      "n": "Value",
      "d": 610666,
      "h": 176094269802,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176094269802),
//--TRIMMABLE-BOUNDARY-START(171799302506),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489891178,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914400618,
        "f": 83886082
      },
      "n": "Type",
      "d": 610666,
      "h": 171799302506,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799302506),
//--TRIMMABLE-BOUNDARY-START(107374793066),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720087402,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144596842,
        "f": 83886081
      },
      "n": "IsOverridden",
      "d": 610666,
      "h": 107374793066,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374793066)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655316330),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": 610666
        },
        {
          "n": "y",
          "p": 610666
        }
      ],
      "n": "Compare",
      "d": 610666,
      "h": 38655316330,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655316330),
//--TRIMMABLE-BOUNDARY-START(42950283626),
    {
      "r": $.$typeNullable($.$$.S.Int32).$h,
      "p": [
        {
          "n": "x",
          "p": 610666
        },
        {
          "n": "y",
          "p": 610666
        }
      ],
      "n": "CompareByAssembly",
      "d": 610666,
      "h": 42950283626,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950283626),
//--TRIMMABLE-BOUNDARY-START(51540218218),
    {
      "r": $.$typeNullable($.$$.S.Int32).$h,
      "p": [
        {
          "n": "x",
          "p": 610666
        },
        {
          "n": "y",
          "p": 610666
        }
      ],
      "n": "CompareByNamespace",
      "d": 610666,
      "h": 51540218218,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540218218),
//--TRIMMABLE-BOUNDARY-START(47245250922),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": 610666
        },
        {
          "n": "y",
          "p": 610666
        }
      ],
      "n": "CompareByLocation",
      "d": 610666,
      "h": 47245250922,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245250922)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065381738),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 610666,
      "h": 30065381738,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065381738)
  ],
  "h": 610666
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IComparer$$($.$tUcV.LCFCMI.ObjectDetails) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Internal.ObjectDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Internal${separator}ObjectDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(610666)
        
        

        //--TRIMMABLE-BOUNDARY-START(545130)
        $asm.$cls(`$tUcV.LCFCMI.NotificationHandlerWrapperImpl<>`, (TNotification) => $asm.$gt(`$tUcV.LCFCMI.NotificationHandlerWrapperImpl<>`, [TNotification], ($self) => class NotificationHandlerWrapperImpl$$ extends $.$tUcV.LCFCMI.NotificationHandlerWrapper
        {
            //--TRIMMABLE-BOUNDARY-START(8590479722)
            /*Task */ Handle(/*INotification*/ notification, /*CancellationToken*/ cancellationToken, /*ServiceFactory*/ serviceFactory, /*Func<IEnumerable<Func<INotification, CancellationToken, Task>>, INotification, CancellationToken, Task>*/ publish)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590479722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let handlers = $.$sl.SL.Enumerable.Select$1($.$tUcV.LCFCM.INotificationHandler$$(TNotification), $.$$.S.Func$$$$($.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task), $.$fPer.LCFCS$3.ServiceFactoryExtensions.GetInstances($.$tUcV.LCFCM.INotificationHandler$$(TNotification), serviceFactory), new ($.$$.S.Func$$$($.$tUcV.LCFCM.INotificationHandler$$(TNotification), $.$$.S.Func$$$$($.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task)))().$ctor(this,  (/**/ x) =>
                {
                    return new ($.$$.S.Func$$$$($.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task))().$ctor(this,  (/*theNotification*/ theNotification, /*theToken*/ theToken) =>
                    {
                        return x[`LCFCM$INotificationHandler$${TNotification.$getFullName('$')}$Handle`]($.$cast(theNotification, TNotification), theToken);
                    }, $gxWSKk ??= {"r":178454529,"p":[{"n":"theNotification","p":282986},{"n":"theToken","p":170852353}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }, $SAhIIe ??= {"r":$.$$.S.Func$$$$($.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task).$h,"p":[{"n":"x","p":$.$tUcV.LCFCM.INotificationHandler$$(TNotification).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return publish.Invoke(handlers, notification, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(8590479722)
            
            //--TRIMMABLE-BOUNDARY-START(4295512426)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295512426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295512426)
            
            //--TRIMMABLE-BOUNDARY-START(4295512426)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295512426)
            
            static $H = 545130;
            static $h = 545130;
            static $g = 1;
            static $f = 0b1010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$tUcV.LCFCMI.NotificationHandlerWrapper; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590479722),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": 282986
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "serviceFactory",
          "p": 62949718
        },
        {
          "n": "publish",
          "p": $.$$.S.Func$$$$$($.$$.SCG.IEnumerable$$($.$$.S.Func$$$$($.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task)), $.$tUcV.LCFCM.INotification, $.$$.ST$1.CancellationToken, $.$$.STT.Task).$h
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 8590479722,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590479722)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295512426),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4295512426,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295512426)
  ],
  "s": [
    {
      "h": TNotification?.$h??1572864,
      "n": "TNotification",
      "c": [282986
      ]
    }
  ],
  "r": 1,
  "H": 545130,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Internal.NotificationHandlerWrapperImpl<${TNotification?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Internal${separator}NotificationHandlerWrapperImpl$${TNotification?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(545130)
        
        

        //--TRIMMABLE-BOUNDARY-START(2773354)
        $asm.$str(`$tUcV.LCFCM.Unit`, ($self) => class Unit extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(51542380906)
            /*Unit*/ static Value;
            //--TRIMMABLE-BOUNDARY-END(51542380906)
            
            //--TRIMMABLE-BOUNDARY-START(42952446314)
            /*Task<Unit>*/ static Task = null;
            //--TRIMMABLE-BOUNDARY-END(42952446314)
            
            //--TRIMMABLE-BOUNDARY-START(12887675242)
            /*int */ CompareTo(/*Unit*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887675242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(12887675242)
            
            //--TRIMMABLE-BOUNDARY-START(38657479018)
            /*int */ S$IComparable$CompareTo(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657479018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(38657479018)
            
            //--TRIMMABLE-BOUNDARY-START(25772577130)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772577130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(25772577130)
            
            //--TRIMMABLE-BOUNDARY-START(21477609834)
            /*bool */ Equals$2(/*Unit*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477609834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21477609834)
            
            //--TRIMMABLE-BOUNDARY-START(17182642538)
            /*bool */ Equals$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182642538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$is(obj, $.$tUcV.LCFCM.Unit);
            }
            //--TRIMMABLE-BOUNDARY-END(17182642538)
            
            //--TRIMMABLE-BOUNDARY-START(30067544426)
            static /*bool */ op_Equality(/*Unit*/ first, /*Unit*/ second)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067544426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30067544426)
            
            //--TRIMMABLE-BOUNDARY-START(34362511722)
            static /*bool */ op_Inequality(/*Unit*/ first, /*Unit*/ second)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362511722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(34362511722)
            
            //--TRIMMABLE-BOUNDARY-START(47247413610)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247413610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "()";
            }
            //--TRIMMABLE-BOUNDARY-END(47247413610)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Frameworks.Common.Mediator.Unit>.Equals(LivingThing.Core.Frameworks.Common.Mediator.Unit)
            S$IEquatable$LivingThing$Core$Frameworks$Common$Mediator$Unit$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(4385865729)
            //Generated interface implemetation for System.IComparable<LivingThing.Core.Frameworks.Common.Mediator.Unit>.CompareTo(LivingThing.Core.Frameworks.Common.Mediator.Unit)
            S$IComparable$LivingThing$Core$Frameworks$Common$Mediator$Unit$CompareTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385865729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CompareTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385865729)
            
            //--TRIMMABLE-BOUNDARY-START(8592707946)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592707946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592707946)
            
            //--TRIMMABLE-BOUNDARY-START(8592707946)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592707946)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(4297740650)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297740650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(51542380906)
                    this.Value = new $.$tUcV.LCFCM.Unit().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(51542380906)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42952446314)
                    this.Task = $.$$.STT.Task.FromResult($.$tUcV.LCFCM.Unit, $.$tUcV.LCFCM.Unit.Value);
                    //--TRIMMABLE-BOUNDARY-END(42952446314)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297740650)
            
            static $h = 2773354;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887675242),
    {
      "r": 655361,
      "p": [
        {
          "n": "other",
          "p": 2773354
        }
      ],
      "n": "CompareTo",
      "d": 2773354,
      "h": 12887675242,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887675242),
//--TRIMMABLE-BOUNDARY-START(25772577130),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2773354,
      "h": 25772577130,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772577130),
//--TRIMMABLE-BOUNDARY-START(21477609834),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 2773354
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 2773354,
      "h": 21477609834,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477609834),
//--TRIMMABLE-BOUNDARY-START(17182642538),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2773354,
      "h": 17182642538,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182642538),
//--TRIMMABLE-BOUNDARY-START(47247413610),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2773354,
      "h": 47247413610,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47247413610)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51542380906),
    {
      "t": 2773354,
      "n": "Value",
      "d": 2773354,
      "h": 51542380906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51542380906),
//--TRIMMABLE-BOUNDARY-START(42952446314),
    {
      "t": $.$$.STT.Task$$($.$tUcV.LCFCM.Unit).$h,
      "n": "Task",
      "d": 2773354,
      "h": 42952446314,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42952446314)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592707946),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2773354,
      "h": 8592707946,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592707946)
  ],
  "h": 2773354
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$tUcV.LCFCM.Unit), $.$$.S.IComparable$$($.$tUcV.LCFCM.Unit), $.$$.S.IComparable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Unit`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Unit`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2773354)
        
        

        //--TRIMMABLE-BOUNDARY-START(1134954)
        $asm.$cls(`$tUcV.LCFCM.IRequestHandler<>`, (/*in*/ TRequest) => $asm.$gt(`$tUcV.LCFCM.IRequestHandler<>`, [/*in*/ TRequest], ($self) => class IRequestHandler$$
        {
            static $H = 1134954;
            static $h = 1134954;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "f": 16,
      "c": [$.$tUcV.LCFCM.IRequest$$($.$tUcV.LCFCM.Unit).$h
      ]
    }
  ],
  "r": 1,
  "H": 1134954,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IRequestHandler$$$(TRequest, $.$tUcV.LCFCM.Unit) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.IRequestHandler<${TRequest?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}IRequestHandler$${TRequest?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1134954)
        
        

        //--TRIMMABLE-BOUNDARY-START(938346)
        $asm.$cls(`$tUcV.LCFCM.IRequest`, ($self) => class IRequest
        {
            static $h = 938346;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 938346
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IRequest$$($.$tUcV.LCFCM.Unit), $.$tUcV.LCFCM.IBaseRequest ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.IRequest`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}IRequest`; }
        });
        //--TRIMMABLE-BOUNDARY-END(938346)
        
        

        //--TRIMMABLE-BOUNDARY-START(807274)
        $asm.$cls(`$tUcV.LCFCMI.RequestHandlerWrapperImpl<,>`, (TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCMI.RequestHandlerWrapperImpl<,>`, [TRequest, TResponse], ($self) => class RequestHandlerWrapperImpl$$$ extends $.$tUcV.LCFCMI.RequestHandlerWrapper$$(TResponse)
        {
            //--TRIMMABLE-BOUNDARY-START(12885709162)
            /*Task<object> */ Handle(/*object*/ request, /*CancellationToken*/ cancellationToken, /*ServiceFactory*/ serviceFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885709162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle$1($.$cast(request, $.$tUcV.LCFCM.IRequest$$(TResponse)), cancellationToken, serviceFactory).ContinueWith$43($.$$.S.Object, new ($.$$.S.Func$$$($.$$.STT.Task$$(TResponse), $.$$.S.Object))().$ctor(this,  (/*t*/ t) =>
                {
                    return $.$box(t.Result, TResponse);
                }, $hoOGeb ??= {"r":131073,"p":[{"n":"t","p":$.$$.STT.Task$$(TResponse).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(12885709162)
            
            //--TRIMMABLE-BOUNDARY-START(8590741866)
            /*Task<TResponse> */ Handle$1(/*IRequest<TResponse>*/ request, /*CancellationToken*/ cancellationToken, /*ServiceFactory*/ serviceFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590741866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task<TResponse>*/  function Handler()
                {
                    {
                        return $.$tUcV.LCFCMI.RequestHandlerBase.GetHandler($.$tUcV.LCFCM.IRequestHandler$$$(TRequest, TResponse), serviceFactory)[`LCFCM$IRequestHandler$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Handle`]($.$cast(request, TRequest), cancellationToken);
                    }
                }
                return $.$sl.SL.Enumerable.Aggregate$1($.$tUcV.LCFCM.IPipelineBehavior$$$(TRequest, TResponse), $.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse), $.$sl.SL.Enumerable.Reverse($.$tUcV.LCFCM.IPipelineBehavior$$$(TRequest, TResponse), $.$fPer.LCFCS$3.ServiceFactoryExtensions.GetInstances($.$tUcV.LCFCM.IPipelineBehavior$$$(TRequest, TResponse), serviceFactory)), new ($.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse))().$ctor(this, Handler, $CsInki ??= {"r":$.$$.STT.Task$$(TResponse).$h,"n":"Handler","d":this.$h,"H":0,"h":0,"f":16777218}), new ($.$$.S.Func$$$$($.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse), $.$tUcV.LCFCM.IPipelineBehavior$$$(TRequest, TResponse), $.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse)))().$ctor(this,  (/*next*/ next, /*pipeline*/ pipeline) =>
                {
                    return new ($.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse))().$ctor(this,  () =>
                    {
                        return pipeline[`LCFCM$IPipelineBehavior$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$Handle`]($.$cast(request, TRequest), cancellationToken, next);
                    }, $fBLCjc ??= {"r":$.$$.STT.Task$$(TResponse).$h,"n":"","d":this.$h,"H":0,"h":0,"f":17825794});
                }, $CVRjIa ??= {"r":$.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse).$h,"p":[{"n":"next","p":$.$tUcV.LCFCM.RequestHandlerDelegate$$(TResponse).$h},{"n":"pipeline","p":$.$tUcV.LCFCM.IPipelineBehavior$$$(TRequest, TResponse).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})).Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(8590741866)
            
            //--TRIMMABLE-BOUNDARY-START(4295774570)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295774570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295774570)
            
            //--TRIMMABLE-BOUNDARY-START(4295774570)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295774570)
            
            static $H = 807274;
            static $h = 807274;
            static $g = 2;
            static $f = 0b1010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$tUcV.LCFCMI.RequestHandlerWrapper$$(TResponse); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885709162),
    {
      "r": $.$$.STT.Task$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "request",
          "p": 131073
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "serviceFactory",
          "p": 62949718
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 12885709162,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885709162),
//--TRIMMABLE-BOUNDARY-START(8590741866),
    {
      "r": $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "request",
          "p": $.$tUcV.LCFCM.IRequest$$(TResponse).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "serviceFactory",
          "p": 62949718
        }
      ],
      "n": "Handle",
      "o": "@$1",
      "d": this.$h,
      "H": 8590741866,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590741866)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295774570),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 4295774570,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295774570)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "c": [$.$tUcV.LCFCM.IRequest$$(TResponse).$h
      ]
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 807274,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Internal.RequestHandlerWrapperImpl<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Internal${separator}RequestHandlerWrapperImpl$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(807274)
        
        

        //--TRIMMABLE-BOUNDARY-START(2642282)
        $asm.$cls(`$tUcV.LCFCM.RequestHandlerDelegate<>`, (TResponse) => $asm.$gt(`$tUcV.LCFCM.RequestHandlerDelegate<>`, [TResponse], ($self) => class RequestHandlerDelegate$$ extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Task<TResponse>*/ Invoke()
            {
                return this.$nativeFunction.call(this.$target, );
            }
            static $H = 2642282;
            static $h = 2642282;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182511466),
    {
      "r": $.$$.STT.Task$$(TResponse).$h,
      "n": "Invoke",
      "d": this.$h,
      "H": 17182511466,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17182511466),
//--TRIMMABLE-BOUNDARY-START(8592576874),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "H": 8592576874,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8592576874),
//--TRIMMABLE-BOUNDARY-START(12887544170),
    {
      "r": $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "H": 12887544170,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12887544170)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297609578),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4297609578,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297609578)
  ],
  "s": [
    {
      "h": TResponse?.$h??1572864,
      "n": "TResponse"
    }
  ],
  "r": 1,
  "H": 2642282,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.RequestHandlerDelegate<${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}RequestHandlerDelegate$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2642282)
        
        

        //--TRIMMABLE-BOUNDARY-START(86378)
        $asm.$cls(`$tUcV.LCFCM.AsyncRequestHandler<>`, (TRequest) => $asm.$gt(`$tUcV.LCFCM.AsyncRequestHandler<>`, [TRequest], ($self) => class AsyncRequestHandler$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12884988266)
            /*Task<Unit> *//*async*/  [`LCFCM$IRequestHandler$${TRequest.$getFullName('$')}$LivingThing$Core$Frameworks$Common$Mediator$Unit$Handle`](/*TRequest*/ request, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$tUcV.LCFCM.Unit), $.$tUcV.LCFCM.Unit, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884988266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Handle(request, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$tUcV.LCFCM.Unit.Value);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12884988266)
            
            //--TRIMMABLE-BOUNDARY-START(4295053674)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295053674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295053674)
            
            //--TRIMMABLE-BOUNDARY-START(4295053674)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295053674)
            
            static $H = 86378;
            static $h = 86378;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590020970),
    {
      "r": 178454529,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 8590020970,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8590020970)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295053674),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295053674,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295053674)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "c": [938346
      ]
    }
  ],
  "r": 1,
  "H": 86378,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IRequestHandler$$(TRequest), $.$tUcV.LCFCM.IRequestHandler$$$(TRequest, $.$tUcV.LCFCM.Unit) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.AsyncRequestHandler<${TRequest?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}AsyncRequestHandler$${TRequest?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(86378)
        
        

        //--TRIMMABLE-BOUNDARY-START(2576746)
        $asm.$cls(`$tUcV.LCFCM.RequestHandler<>`, (TRequest) => $asm.$gt(`$tUcV.LCFCM.RequestHandler<>`, [TRequest], ($self) => class RequestHandler$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887478634)
            /*Task<Unit> */ [`LCFCM$IRequestHandler$${TRequest.$getFullName('$')}$LivingThing$Core$Frameworks$Common$Mediator$Unit$Handle`](/*TRequest*/ request, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887478634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Handle(request);
                return $.$tUcV.LCFCM.Unit.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(12887478634)
            
            //--TRIMMABLE-BOUNDARY-START(4297544042)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297544042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297544042)
            
            //--TRIMMABLE-BOUNDARY-START(4297544042)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297544042)
            
            static $H = 2576746;
            static $h = 2576746;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592511338),
    {
      "r": 65537,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 8592511338,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8592511338)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297544042),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4297544042,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297544042)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "c": [938346
      ]
    }
  ],
  "r": 1,
  "H": 2576746,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCM.IRequestHandler$$(TRequest), $.$tUcV.LCFCM.IRequestHandler$$$(TRequest, $.$tUcV.LCFCM.Unit) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.RequestHandler<${TRequest?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}RequestHandler$${TRequest?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2576746)
        
        

        //--TRIMMABLE-BOUNDARY-START(1593706)
        $asm.$cls(`$tUcV.LCFCMP.IRequestExceptionAction<>`, (/*in*/ TRequest) => $asm.$gt(`$tUcV.LCFCMP.IRequestExceptionAction<>`, [/*in*/ TRequest], ($self) => class IRequestExceptionAction$$
        {
            static $H = 1593706;
            static $h = 1593706;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "f": 16
    }
  ],
  "r": 1,
  "H": 1593706,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCMP.IRequestExceptionAction$$$(TRequest, $.$$.S.Exception) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.IRequestExceptionAction<${TRequest?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}IRequestExceptionAction$${TRequest?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1593706)
        
        

        //--TRIMMABLE-BOUNDARY-START(1724778)
        $asm.$cls(`$tUcV.LCFCMP.IRequestExceptionHandler<,>`, (/*in*/ TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCMP.IRequestExceptionHandler<,>`, [/*in*/ TRequest, TResponse], ($self) => class IRequestExceptionHandler$$$
        {
            static $H = 1724778;
            static $h = 1724778;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "f": 16
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 1724778,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCMP.IRequestExceptionHandler$$$$(TRequest, TResponse, $.$$.S.Exception) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.IRequestExceptionHandler<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}IRequestExceptionHandler$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1724778)
        
        

        //--TRIMMABLE-BOUNDARY-START(1397098)
        $asm.$cls(`$tUcV.LCFCMP.AsyncRequestExceptionAction<>`, (TRequest) => $asm.$gt(`$tUcV.LCFCMP.AsyncRequestExceptionAction<>`, [TRequest], ($self) => class AsyncRequestExceptionAction$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886298986)
            /*Task *//*async*/  [`LCFCMP$IRequestExceptionAction$${TRequest.$getFullName('$')}$System$Exception$Execute`](/*TRequest*/ request, /*Exception*/ exception, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886298986);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Execute(request, exception, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12886298986)
            
            //--TRIMMABLE-BOUNDARY-START(4296364394)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296364394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296364394)
            
            //--TRIMMABLE-BOUNDARY-START(4296364394)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296364394)
            
            static $H = 1397098;
            static $h = 1397098;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591331690),
    {
      "r": 178454529,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "exception",
          "p": 80805889
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Execute",
      "d": this.$h,
      "H": 8591331690,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8591331690)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296364394),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296364394,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296364394)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest",
      "c": [938346
      ]
    }
  ],
  "r": 1,
  "H": 1397098,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCMP.IRequestExceptionAction$$(TRequest), $.$tUcV.LCFCMP.IRequestExceptionAction$$$(TRequest, $.$$.S.Exception) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.AsyncRequestExceptionAction<${TRequest?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}AsyncRequestExceptionAction$${TRequest?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1397098)
        
        

        //--TRIMMABLE-BOUNDARY-START(1986922)
        $asm.$cls(`$tUcV.LCFCMP.RequestExceptionAction<>`, (TRequest) => $asm.$gt(`$tUcV.LCFCMP.RequestExceptionAction<>`, [TRequest], ($self) => class RequestExceptionAction$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886888810)
            /*Task */ [`LCFCMP$IRequestExceptionAction$${TRequest.$getFullName('$')}$System$Exception$Execute`](/*TRequest*/ request, /*Exception*/ exception, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886888810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Execute(request, exception);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12886888810)
            
            //--TRIMMABLE-BOUNDARY-START(4296954218)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296954218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296954218)
            
            //--TRIMMABLE-BOUNDARY-START(4296954218)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296954218)
            
            static $H = 1986922;
            static $h = 1986922;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591921514),
    {
      "r": 65537,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "Execute",
      "d": this.$h,
      "H": 8591921514,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8591921514)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296954218),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296954218,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296954218)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest"
    }
  ],
  "r": 1,
  "H": 1986922,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCMP.IRequestExceptionAction$$(TRequest), $.$tUcV.LCFCMP.IRequestExceptionAction$$$(TRequest, $.$$.S.Exception) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.RequestExceptionAction<${TRequest?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}RequestExceptionAction$${TRequest?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1986922)
        
        

        //--TRIMMABLE-BOUNDARY-START(1462634)
        $asm.$cls(`$tUcV.LCFCMP.AsyncRequestExceptionHandler<,>`, (TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCMP.AsyncRequestExceptionHandler<,>`, [TRequest, TResponse], ($self) => class AsyncRequestExceptionHandler$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886364522)
            /*Task *//*async*/  [`LCFCMP$IRequestExceptionHandler$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$System$Exception$Handle`](/*TRequest*/ request, /*Exception*/ exception, /*RequestExceptionHandlerState<TResponse>*/ state, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886364522);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.Handle(request, exception, state, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12886364522)
            
            //--TRIMMABLE-BOUNDARY-START(4296429930)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296429930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296429930)
            
            //--TRIMMABLE-BOUNDARY-START(4296429930)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296429930)
            
            static $H = 1462634;
            static $h = 1462634;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591397226),
    {
      "r": 178454529,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "exception",
          "p": 80805889
        },
        {
          "n": "state",
          "p": $.$tUcV.LCFCMP.RequestExceptionHandlerState$$(TResponse).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 8591397226,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8591397226)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296429930),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296429930,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296429930)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest"
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 1462634,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCMP.IRequestExceptionHandler$$$(TRequest, TResponse), $.$tUcV.LCFCMP.IRequestExceptionHandler$$$$(TRequest, TResponse, $.$$.S.Exception) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.AsyncRequestExceptionHandler<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}AsyncRequestExceptionHandler$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1462634)
        
        

        //--TRIMMABLE-BOUNDARY-START(2183530)
        $asm.$cls(`$tUcV.LCFCMP.RequestExceptionHandler<,>`, (TRequest, TResponse) => $asm.$gt(`$tUcV.LCFCMP.RequestExceptionHandler<,>`, [TRequest, TResponse], ($self) => class RequestExceptionHandler$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887085418)
            /*Task */ [`LCFCMP$IRequestExceptionHandler$${TRequest.$getFullName('$')}$${TResponse.$getFullName('$')}$System$Exception$Handle`](/*TRequest*/ request, /*Exception*/ exception, /*RequestExceptionHandlerState<TResponse>*/ state, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887085418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Handle(request, exception, state);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12887085418)
            
            //--TRIMMABLE-BOUNDARY-START(4297150826)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297150826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297150826)
            
            //--TRIMMABLE-BOUNDARY-START(4297150826)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297150826)
            
            static $H = 2183530;
            static $h = 2183530;
            static $g = 2;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592118122),
    {
      "r": 65537,
      "p": [
        {
          "n": "request",
          "p": TRequest?.$h??1572864
        },
        {
          "n": "exception",
          "p": 80805889
        },
        {
          "n": "state",
          "p": $.$tUcV.LCFCMP.RequestExceptionHandlerState$$(TResponse).$h
        }
      ],
      "n": "Handle",
      "d": this.$h,
      "H": 8592118122,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8592118122)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297150826),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4297150826,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297150826)
  ],
  "s": [
    {
      "h": TRequest?.$h??1572864,
      "n": "TRequest"
    },
    {
      "h": TResponse?.$h??1638400,
      "n": "TResponse"
    }
  ],
  "r": 2,
  "H": 2183530,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$tUcV.LCFCMP.IRequestExceptionHandler$$$(TRequest, TResponse), $.$tUcV.LCFCMP.IRequestExceptionHandler$$$$(TRequest, TResponse, $.$$.S.Exception) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mediator.Pipeline.RequestExceptionHandler<${TRequest?.$fullName},${TResponse?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mediator${separator}Pipeline${separator}RequestExceptionHandler$${TRequest?.$getFullName(separator)}$${TResponse?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2183530)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(20842)
