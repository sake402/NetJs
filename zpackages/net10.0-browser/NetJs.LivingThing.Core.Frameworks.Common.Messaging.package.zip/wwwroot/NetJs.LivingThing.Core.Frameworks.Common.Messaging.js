
//--TRIMMABLE-BOUNDARY-START(13788)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt, $kVHt, $Iaui, $uvJL) {
    "use strict";
    let _;
    let $eTelld;
    let $xTyuah;
    let $oyQOXa;
    let $RMMrde;
    let $WsoRPb;
    let $cZuJqj;
    let $aWIVBc;
    let $uIYElg;
    let $xkhxTa;
    let $KdHvOi;
    let $AoJFJb;
    let $ZOEdRc;
    let $wDOhyb;
    let $vZIoYc;
    let $fZFXZh;
    let $siXVUj;
    let $dgXdJk;
    let $sQvStb;
    let $qpFDRg;
    let $qiISag;
    let $looVaj;
    let $nrGnua;
    let $rPwsOg;
    let $HiiBhf;
    let $AcfhKd;
    let $AZjQxe;
    let $QxuRbe;
    let $pAUaMj;
    let $OMFbZa;
    let $jQjWVh;
    let $TEotYg;
    let $xJDmSk;
    let $olWwFb;
    let $xxKkHi;
    let $qonyAd;
    let $YslaHh;
    let $gRQvVe;
    let $jmGAWf;
    let $ecqLQe;
    let $POpgLb;
    let $PVIZlf;
    let $HwEkZa;
    let $rzzxcg;
    let $ydDcDg;
    let $xKcGga;
    let $uRPSkc;
    let $XkogWh;
    let $lCqEWh;
    let $bvXesa;
    let $atPkKk;
    let $WvRoIj;
    let $vYvJwj;
    let $KinIki;
    let $lAWfke;
    let $DMrQgc;
    let $WDxJAg;
    let $zfRtDc;
    let $RTRecj;
    let $Nhdmaf;
    let $uuVRbh;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Messaging", 
    {
  "h": 13788,
  "f": "LivingThing.Core.Frameworks.Common.Messaging",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Messaging",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Messaging",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(865756)
        $asm.$cls(`$UrvY.LCFCM.IMessenger`, ($self) => class IMessenger
        {
            //--TRIMMABLE-BOUNDARY-START(4295833052)
            /*string*/ static LivingThing$Core$Frameworks$Common$Messaging$IMessenger$DNDChannel = null;
            //--TRIMMABLE-BOUNDARY-END(4295833052)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295833052)
                    this.LivingThing$Core$Frameworks$Common$Messaging$IMessenger$DNDChannel = "dnd/N-Alert";
                    //--TRIMMABLE-BOUNDARY-END(4295833052)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 865756;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065636828),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475702236,
        "f": 50331905
      },
      "n": "MessengerName",
      "o": "LCFCM$IMessenger$MessengerName",
      "d": 865756,
      "h": 30065636828,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065636828),
//--TRIMMABLE-BOUNDARY-START(25770669532),
    {
      "p": 48728406,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885767644,
        "f": 50331905
      },
      "n": "MessageChannels",
      "o": "LCFCM$IMessenger$MessageChannels",
      "d": 865756,
      "h": 25770669532,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770669532)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655571420),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "fromName",
          "p": 1310721
        },
        {
          "n": "title",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1062364
        },
        {
          "n": "recipients",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "Send",
      "o": "LCFCM$IMessenger$Send$1",
      "d": 865756,
      "h": 38655571420,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655571420),
//--TRIMMABLE-BOUNDARY-START(34360604124),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "config",
          "p": 1127900
        }
      ],
      "n": "Send",
      "o": "LCFCM$IMessenger$Send",
      "d": 865756,
      "h": 34360604124,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360604124)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295833052),
    {
      "t": 1310721,
      "n": "DNDChannel",
      "o": "LivingThing$Core$Frameworks$Common$Messaging$IMessenger$DNDChannel",
      "d": 865756,
      "h": 4295833052,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295833052)
  ],
  "h": 865756
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessenger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessenger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(865756)
        
        

        //--TRIMMABLE-BOUNDARY-START(734684)
        $asm.$cls(`$UrvY.LCFCM.IMessageRecipientIdContainer`, ($self) => class IMessageRecipientIdContainer
        {
            static $h = 734684;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295701980),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885636572,
        "f": 50331905
      },
      "n": "ClientIds",
      "o": "LCFCM$IMessageRecipientIdContainer$ClientIds",
      "d": 734684,
      "h": 4295701980,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295701980)
  ],
  "h": 734684
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessageRecipientIdContainer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessageRecipientIdContainer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(734684)
        
        

        //--TRIMMABLE-BOUNDARY-START(407004)
        $asm.$cls(`$UrvY.LCFCM.IMessagePipeFactory`, ($self) => class IMessagePipeFactory
        {
            static $h = 407004;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295374300),
    {
      "p": $.$so.SCO.ObservableCollection$$($.$UrvY.LCFCM.MessagePipeClient).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180276188,
        "f": 50331905
      },
      "n": "Clients",
      "o": "LCFCM$IMessagePipeFactory$Clients",
      "d": 407004,
      "h": 4295374300,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295374300)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065178076),
    {
      "r": 65537,
      "g": [
        "T"
      ],
      "n": "RegisterKnownMessageType",
      "o": "LCFCM$IMessagePipeFactory$RegisterKnownMessageType",
      "d": 407004,
      "h": 30065178076,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(30065178076),
//--TRIMMABLE-BOUNDARY-START(25770210780),
    {
      "r": $.$$.STT.ValueTask$$($.$UrvY.LCFCM.IMessagePipe).$h,
      "p": [
        {
          "n": "pipesId",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h
        },
        {
          "n": "metadata",
          "p": 1190345,
          "f": 65
        }
      ],
      "n": "Join",
      "o": "LCFCM$IMessagePipeFactory$Join",
      "d": 407004,
      "h": 25770210780,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770210780),
//--TRIMMABLE-BOUNDARY-START(34360145372),
    {
      "r": 181338113,
      "p": [
        {
          "n": "pipe",
          "p": 341468
        },
        {
          "n": "metadata",
          "p": 1190345
        }
      ],
      "n": "UpdateMetadata",
      "o": "LCFCM$IMessagePipeFactory$UpdateMetadata",
      "d": 407004,
      "h": 34360145372,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360145372),
//--TRIMMABLE-BOUNDARY-START(21475243484),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient)).$h,
      "p": [
        {
          "n": "pipeId",
          "p": 56789334
        }
      ],
      "n": "GetClients",
      "o": "LCFCM$IMessagePipeFactory$GetClients",
      "d": 407004,
      "h": 21475243484,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475243484),
//--TRIMMABLE-BOUNDARY-START(8590341596),
    {
      "r": 181338113,
      "p": [
        {
          "n": "message",
          "p": (T) => T.$h
        },
        {
          "n": "pipesId",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h
        },
        {
          "n": "clientsId",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "needsAck",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "retainSeconds",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "g": [
        "T"
      ],
      "n": "FeedAsync",
      "o": "LCFCM$IMessagePipeFactory$FeedAsync",
      "d": 407004,
      "h": 8590341596,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590341596)
  ],
  "h": 407004
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessagePipeFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(407004)
        
        

        //--TRIMMABLE-BOUNDARY-START(800220)
        $asm.$cls(`$UrvY.LCFCM.IMessagingRemoteService`, ($self) => class IMessagingRemoteService
        {
            static $h = 800220;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295767516),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "model",
          "p": 1127900
        }
      ],
      "n": "SendMessage",
      "o": "LCFCM$IMessagingRemoteService$SendMessage",
      "d": 800220,
      "h": 4295767516,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295767516)
  ],
  "h": 800220
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessagingRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessagingRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(800220)
        
        

        //--TRIMMABLE-BOUNDARY-START(931292)
        $asm.$cls(`$UrvY.LCFCM.IPlatformMessenger`, ($self) => class IPlatformMessenger
        {
            //--TRIMMABLE-BOUNDARY-START(21475767772)
            /*ReactiveObservable<NotificationModel>? */ get LCFCM$IPlatformMessenger$Notification()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475767772)
            
            static $h = 931292;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770735068),
    {
      "p": $.$fPer.LCFCR.ReactiveObservable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180800476,
        "f": 50331905
      },
      "n": "UserToken",
      "o": "LCFCM$IPlatformMessenger$UserToken",
      "d": 931292,
      "h": 25770735068,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770735068),
//--TRIMMABLE-BOUNDARY-START(21475767772),
    {
      "p": $.$fPer.LCFCR.ReactiveObservable$$($.$Iaui.LCFCM.NotificationModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590865884,
        "f": 50331777
      },
      "n": "Notification",
      "o": "LCFCM$IPlatformMessenger$Notification",
      "d": 931292,
      "h": 21475767772,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21475767772)
  ],
  "h": 931292
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UrvY.LCFCM.IMessenger ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IPlatformMessenger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IPlatformMessenger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(931292)
        
        

        //--TRIMMABLE-BOUNDARY-START(210396)
        $asm.$cls(`$UrvY.LCFCM.IMessageComposerProvider`, ($self) => class IMessageComposerProvider
        {
            //--TRIMMABLE-BOUNDARY-START(8590144988)
            /*string? */ get LCFCM$IMessageComposerProvider$EmailLayoutRoute()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590144988)
            
            static $h = 210396;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295177692),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180079580,
        "f": 50331905
      },
      "n": "ContactType",
      "o": "LCFCM$IMessageComposerProvider$ContactType",
      "d": 210396,
      "h": 4295177692,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295177692),
//--TRIMMABLE-BOUNDARY-START(8590144988),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770014172,
        "f": 50331777
      },
      "n": "EmailLayoutRoute",
      "o": "LCFCM$IMessageComposerProvider$EmailLayoutRoute",
      "d": 210396,
      "h": 8590144988,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(8590144988)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064981468),
    {
      "r": $.$fPer.LCFCD.Pager$$($.$fPer.LCFCC$2.IContact).$h,
      "n": "GetContacts",
      "o": "LCFCM$IMessageComposerProvider$GetContacts",
      "d": 210396,
      "h": 30064981468,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30064981468)
  ],
  "h": 210396
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessageComposerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessageComposerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(210396)
        
        

        //--TRIMMABLE-BOUNDARY-START(341468)
        $asm.$cls(`$UrvY.LCFCM.IMessagePipe`, ($self) => class IMessagePipe
        {
            static $h = 341468;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065112540),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770145244,
        "f": 50331905
      },
      "n": "PipesId",
      "o": "LCFCM$IMessagePipe$PipesId",
      "d": 341468,
      "h": 30065112540,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065112540),
//--TRIMMABLE-BOUNDARY-START(4295308764),
    {
      "p": 1390044,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180210652,
        "f": 50331905
      },
      "n": "Client",
      "o": "LCFCM$IMessagePipe$Client",
      "d": 341468,
      "h": 4295308764,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295308764)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590276060),
    {
      "r": 181338113,
      "p": [
        {
          "n": "message",
          "p": (T) => T.$h
        },
        {
          "n": "pipesId",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h,
          "f": 65
        },
        {
          "n": "clientsId",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "needsAck",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "retainSeconds",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "g": [
        "T"
      ],
      "n": "FeedAsync",
      "o": "LCFCM$IMessagePipe$FeedAsync",
      "d": 341468,
      "h": 8590276060,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590276060),
//--TRIMMABLE-BOUNDARY-START(34360079836),
    {
      "r": 91095041,
      "p": [
        {
          "n": "handler",
          "p": (T) => $.$$.S.Action$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Subscribe",
      "o": "LCFCM$IMessagePipe$Subscribe",
      "d": 341468,
      "h": 34360079836,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(34360079836)
  ],
  "h": 341468
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessagePipe`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessagePipe`; }
        });
        //--TRIMMABLE-BOUNDARY-END(341468)
        
        

        //--TRIMMABLE-BOUNDARY-START(275932)
        $asm.$cls(`$UrvY.LCFCM.IMessageComposerProvider<>`, (TContact) => $asm.$gt(`$UrvY.LCFCM.IMessageComposerProvider<>`, [TContact], ($self) => class IMessageComposerProvider$$
        {
            //--TRIMMABLE-BOUNDARY-START(8590210524)
            /*Type */ get LCFCM$IMessageComposerProvider$ContactType()
            {
                return TContact.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8590210524)
            
            //--TRIMMABLE-BOUNDARY-START(21475112412)
            /*Pager<IContact> */ LCFCM$IMessageComposerProvider$GetContacts()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475112412);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$fPer.LCFCD.Paging.Cast$1(TContact, $.$fPer.LCFCC$2.IContact, this.LCFCM$IMessageComposerProvider$$$GetContacts());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475112412)
            
            static $H = 275932;
            static $h = 275932;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590210524),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180145116,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331650
      },
      "n": "{210396}.ContactType",
      "o": "LCFCM$IMessageComposerProvider$ContactType",
      "d": this.$h,
      "H": 8590210524,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8590210524)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295243228),
    {
      "r": $.$fPer.LCFCD.Pager$$(TContact).$h,
      "n": "GetContacts",
      "o": "LCFCM$IMessageComposerProvider$$$GetContacts",
      "d": this.$h,
      "H": 4295243228,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 553648385
    },
//--TRIMMABLE-BOUNDARY-END(4295243228)
  ],
  "s": [
    {
      "h": TContact?.$h??1572864,
      "n": "TContact",
      "c": [5081430
      ]
    }
  ],
  "r": 1,
  "H": 275932,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UrvY.LCFCM.IMessageComposerProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessageComposerProvider<${TContact?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessageComposerProvider$${TContact?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(275932)
        
        

        //--TRIMMABLE-BOUNDARY-START(472540)
        $asm.$cls(`$UrvY.LCFCM.IMessagePipeHubClient`, ($self) => class IMessagePipeHubClient
        {
            static $h = 472540;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295439836),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1390044
        }
      ],
      "n": "NotifyJoined",
      "o": "LCFCM$IMessagePipeHubClient$NotifyJoined",
      "d": 472540,
      "h": 4295439836,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295439836),
//--TRIMMABLE-BOUNDARY-START(8590407132),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1390044
        }
      ],
      "n": "NotifyLeave",
      "o": "LCFCM$IMessagePipeHubClient$NotifyLeave",
      "d": 472540,
      "h": 8590407132,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590407132),
//--TRIMMABLE-BOUNDARY-START(12885374428),
    {
      "r": 178454529,
      "p": [
        {
          "n": "message",
          "p": 1914332
        }
      ],
      "n": "ReceiveMessage",
      "o": "LCFCM$IMessagePipeHubClient$ReceiveMessage",
      "d": 472540,
      "h": 12885374428,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885374428)
  ],
  "h": 472540,
  "a": [
    {
      "t": 454470,
      "c": 12885356358
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IPluginHubClient, $.$kVHt.LCFCH.IWebSocketClientHub, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessagePipeHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(472540)
        
        

        //--TRIMMABLE-BOUNDARY-START(603612)
        $asm.$cls(`$UrvY.LCFCM.IMessagePipeHubServer`, ($self) => class IMessagePipeHubServer
        {
            static $h = 603612;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295570908),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient)).$h,
      "p": [
        {
          "n": "pipeId",
          "p": 56789334
        }
      ],
      "n": "GetClients",
      "o": "LCFCM$IMessagePipeHubServer$GetClients",
      "d": 603612,
      "h": 4295570908,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295570908),
//--TRIMMABLE-BOUNDARY-START(8590538204),
    {
      "r": $.$$.STT.Task$$($.$UrvY.LCFCM.MessagePipeClient).$h,
      "p": [
        {
          "n": "pipesId",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h
        },
        {
          "n": "metadata",
          "p": 1190345,
          "f": 65
        }
      ],
      "n": "JoinGroup",
      "o": "LCFCM$IMessagePipeHubServer$JoinGroup",
      "d": 603612,
      "h": 8590538204,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590538204),
//--TRIMMABLE-BOUNDARY-START(21475440092),
    {
      "r": 178454529,
      "p": [
        {
          "n": "metadata",
          "p": 1190345
        }
      ],
      "n": "UpdateClientMetadata",
      "o": "LCFCM$IMessagePipeHubServer$UpdateClientMetadata",
      "d": 603612,
      "h": 21475440092,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475440092),
//--TRIMMABLE-BOUNDARY-START(12885505500),
    {
      "r": 178454529,
      "p": [
        {
          "n": "pipesId",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h
        }
      ],
      "n": "LeaveGroup",
      "o": "LCFCM$IMessagePipeHubServer$LeaveGroup",
      "d": 603612,
      "h": 12885505500,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885505500),
//--TRIMMABLE-BOUNDARY-START(17180472796),
    {
      "r": 178454529,
      "p": [
        {
          "n": "message",
          "p": 1914332
        }
      ],
      "n": "Send",
      "o": "LCFCM$IMessagePipeHubServer$Send",
      "d": 603612,
      "h": 17180472796,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180472796)
  ],
  "h": 603612,
  "a": [
    {
      "t": 454470,
      "c": 12885356358
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$kVHt.LCFCH.IPluginHubServer, $.$kVHt.LCFCH.IWebSocketServerHub$$$($.$UrvY.LCFCM.IMessagePipeHubServer, $.$UrvY.LCFCM.IMessagePipeHubClient), $.$kVHt.LCFCH.IWebSocketServerHub$$($.$UrvY.LCFCM.IMessagePipeHubClient), $.$kVHt.LCFCH.IWebSocketServerHub, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeHubServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessagePipeHubServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(603612)
        
        

        //--TRIMMABLE-BOUNDARY-START(1783260)
        $asm.$cls(`$UrvY.LCFCM.MessagePipeMessageAcknowledge`, ($self) => class MessagePipeMessageAcknowledge extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476619740)
            /*int*/ RequestId = 0;
            //--TRIMMABLE-BOUNDARY-END(21476619740)
            
            //--TRIMMABLE-BOUNDARY-START(8591717852)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591717852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591717852)
            
            //--TRIMMABLE-BOUNDARY-START(8591717852)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591717852)
            
            static $h = 1783260;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476619740),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181652444,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066554332,
        "f": 83886081
      },
      "n": "RequestId",
      "d": 1783260,
      "h": 21476619740,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476619740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591717852),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1783260,
      "h": 8591717852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591717852)
  ],
  "h": 1783260
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessagePipeMessageAcknowledge`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessagePipeMessageAcknowledge`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1783260)
        
        

        //--TRIMMABLE-BOUNDARY-START(1979868)
        $asm.$cls(`$UrvY.LCFCM.PipeMessageModelCustomAttributesProvider`, ($self) => class PipeMessageModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296947164)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296947164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296947164)
            
            static $h = 1979868;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296947164),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1979868,
      "h": 4296947164,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296947164)
  ],
  "h": 1979868
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}PipeMessageModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1979868)
        
        

        //--TRIMMABLE-BOUNDARY-START(79324)
        $asm.$cls(`$UrvY.LCFCM.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295046620)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295046620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UrvY.LCFCM.MessageFormatting.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UrvY.LCFCM.MessageFormattingCustomAttributesProvider, $.$UrvY.LCFCM.MessageFormattingCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UrvY.LCFCM.PipeMessageModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UrvY.LCFCM.PipeMessageModelCustomAttributesProvider, $.$UrvY.LCFCM.PipeMessageModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$UrvY.LCFCM.RetainedPipeMessageModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelCustomAttributesProvider, $.$UrvY.LCFCM.RetainedPipeMessageModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295046620)
            
            static $h = 79324;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295046620),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 79324,
      "h": 4295046620,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295046620)
  ],
  "h": 79324
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(79324)
        
        

        //--TRIMMABLE-BOUNDARY-START(2176476)
        $asm.$cls(`$UrvY.LCFCM.RetainedPipeMessageModel`, ($self) => class RetainedPipeMessageModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115966293468)
            /*string*/ OriginConnectionId = null;
            //--TRIMMABLE-BOUNDARY-END(115966293468)
            
            //--TRIMMABLE-BOUNDARY-START(120261260764)
            /*IEnumerable<RoutePath>*/ PipesId = null;
            //--TRIMMABLE-BOUNDARY-END(120261260764)
            
            //--TRIMMABLE-BOUNDARY-START(42951849436)
            /*IEnumerable<string>?*/ ClientsId = null;
            //--TRIMMABLE-BOUNDARY-END(42951849436)
            
            //--TRIMMABLE-BOUNDARY-START(184685770204)
            /*string*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(184685770204)
            
            //--TRIMMABLE-BOUNDARY-START(47246816732)
            /*string?*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(47246816732)
            
            //--TRIMMABLE-BOUNDARY-START(38656882140)
            /*int*/ AckRequestId = 0;
            //--TRIMMABLE-BOUNDARY-END(38656882140)
            
            //--TRIMMABLE-BOUNDARY-START(51541784028)
            /*DateTime*/ Expiry;
            //--TRIMMABLE-BOUNDARY-END(51541784028)
            
            //--TRIMMABLE-BOUNDARY-START(34361914844)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361914844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361914844)
            
            //--TRIMMABLE-BOUNDARY-START(34361914844)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34361914844)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51541784028)
                this.Expiry = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(51541784028)
                
            }
            static $h = 2176476;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115966293468),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491456988,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210933724,
        "f": 83886081
      },
      "n": "OriginConnectionId",
      "d": 2176476,
      "h": 115966293468,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966293468),
//--TRIMMABLE-BOUNDARY-START(120261260764),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081391580,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800868316,
        "f": 83886081
      },
      "n": "PipesId",
      "d": 2176476,
      "h": 120261260764,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120261260764),
//--TRIMMABLE-BOUNDARY-START(42951849436),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721653212,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137441129948,
        "f": 83886081
      },
      "n": "ClientsId",
      "d": 2176476,
      "h": 42951849436,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951849436),
//--TRIMMABLE-BOUNDARY-START(184685770204),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671326172,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390802908,
        "f": 83886081
      },
      "n": "Type",
      "d": 2176476,
      "h": 184685770204,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184685770204),
//--TRIMMABLE-BOUNDARY-START(47246816732),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311587804,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146031064540,
        "f": 83886081
      },
      "n": "Data",
      "d": 2176476,
      "h": 47246816732,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246816732),
//--TRIMMABLE-BOUNDARY-START(38656882140),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131718620,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128851195356,
        "f": 83886081
      },
      "n": "AckRequestId",
      "d": 2176476,
      "h": 38656882140,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656882140),
//--TRIMMABLE-BOUNDARY-START(51541784028),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901522396,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620999132,
        "f": 83886081
      },
      "n": "Expiry",
      "d": 2176476,
      "h": 51541784028,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541784028)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361914844),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2176476,
      "h": 34361914844,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361914844)
  ],
  "h": 2176476
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}RetainedPipeMessageModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2176476)
        
        

        //--TRIMMABLE-BOUNDARY-START(1717724)
        $asm.$cls(`$UrvY.LCFCM.MessagePipeFactoryExtension`, ($self) => class MessagePipeFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(8591652316)
            static /*ValueTask<IMessagePipe> */ Join(/*this IMessagePipeFactory*/ factory, /*RoutePath*/ pipeId, /*WebSocketClientMetadata*/ metadata)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591652316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return factory.LCFCM$IMessagePipeFactory$Join($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCR$3.RoutePath), [pipeId], null, null), $.$clone(metadata));
            }
            //--TRIMMABLE-BOUNDARY-END(8591652316)
            
            //--TRIMMABLE-BOUNDARY-START(4296685020)
            static /*ValueTask */ FeedAsync(T, /*this IMessagePipeFactory*/ factory, /*T*/ message, /*RoutePath*/ pipeId, /*IEnumerable<string>?*/ clientsId, /*bool*/ needsAck, /*int*/ retainSeconds)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296685020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return factory.LCFCM$IMessagePipeFactory$FeedAsync(T, message, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCR$3.RoutePath), [pipeId], null, null), clientsId, needsAck, retainSeconds);
            }
            //--TRIMMABLE-BOUNDARY-END(4296685020)
            
            static $h = 1717724;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591652316),
    {
      "r": $.$$.STT.ValueTask$$($.$UrvY.LCFCM.IMessagePipe).$h,
      "p": [
        {
          "n": "factory",
          "p": 407004
        },
        {
          "n": "pipeId",
          "p": 56789334
        },
        {
          "n": "metadata",
          "p": 1190345,
          "f": 65
        }
      ],
      "n": "Join",
      "d": 1717724,
      "h": 8591652316,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591652316),
//--TRIMMABLE-BOUNDARY-START(4296685020),
    {
      "r": 181338113,
      "p": [
        {
          "n": "factory",
          "p": 407004
        },
        {
          "n": "message",
          "p": (T) => T.$h
        },
        {
          "n": "pipeId",
          "p": 56789334
        },
        {
          "n": "clientsId",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "needsAck",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "retainSeconds",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "g": [
        "T"
      ],
      "n": "FeedAsync",
      "d": 1717724,
      "h": 4296685020,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4296685020)
  ],
  "h": 1717724
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessagePipeFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessagePipeFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1717724)
        
        

        //--TRIMMABLE-BOUNDARY-START(996828)
        $asm.$cls(`$UrvY.LCFCM.MessageAttachment`, ($self) => class MessageAttachment extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68720473564)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(68720473564)
            
            //--TRIMMABLE-BOUNDARY-START(64425506268)
            /*string?*/ Link = null;
            //--TRIMMABLE-BOUNDARY-END(64425506268)
            
            //--TRIMMABLE-BOUNDARY-START(107375179228)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(107375179228)
            
            //--TRIMMABLE-BOUNDARY-START(25770800604)
            /*Stream?*/ Content = null;
            //--TRIMMABLE-BOUNDARY-END(25770800604)
            
            //--TRIMMABLE-BOUNDARY-START(21475833308)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475833308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475833308)
            
            //--TRIMMABLE-BOUNDARY-START(21475833308)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475833308)
            
            static $h = 996828;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720473564),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540604380,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490277340,
        "f": 83886081
      },
      "n": "Name",
      "d": 996828,
      "h": 68720473564,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720473564),
//--TRIMMABLE-BOUNDARY-START(64425506268),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950669788,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900342748,
        "f": 83886081
      },
      "n": "Link",
      "d": 996828,
      "h": 64425506268,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425506268),
//--TRIMMABLE-BOUNDARY-START(107375179228),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130538972,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080211932,
        "f": 83886081
      },
      "n": "Value",
      "d": 996828,
      "h": 107375179228,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375179228),
//--TRIMMABLE-BOUNDARY-START(25770800604),
    {
      "p": 95748097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360735196,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310408156,
        "f": 83886081
      },
      "n": "Content",
      "d": 996828,
      "h": 25770800604,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770800604)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475833308),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 996828,
      "h": 21475833308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475833308)
  ],
  "h": 996828
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessageAttachment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessageAttachment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(996828)
        
        

        //--TRIMMABLE-BOUNDARY-START(1848796)
        $asm.$cls(`$UrvY.LCFCM.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296816092)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296816092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$UrvY.LCFCM.IMessagePipeHubClient, $.$UrvY.LCFCM.IMessagePipeHubClient_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$UrvY.LCFCM.IMessagePipeHubClient_Mocking().$ctor$2(impl);
                }, $xTyuah ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1848796,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$UrvY.LCFCM.IMessagePipeHubServer, $.$UrvY.LCFCM.IMessagePipeHubServer_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$UrvY.LCFCM.IMessagePipeHubServer_Mocking().$ctor$2(impl);
                }, $oyQOXa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1848796,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$kVHt.LCFCH.IWebSocketServerHub$$$($.$UrvY.LCFCM.IMessagePipeHubServer, $.$UrvY.LCFCM.IMessagePipeHubClient), $.$UrvY.LCFCM.IMessagePipeHubServer_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$UrvY.LCFCM.IMessagePipeHubServer_Mocking().$ctor$2(impl);
                }, $RMMrde ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1848796,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$kVHt.LCFCH.IWebSocketServerHub$$($.$UrvY.LCFCM.IMessagePipeHubClient), $.$UrvY.LCFCM.IMessagePipeHubServer_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$UrvY.LCFCM.IMessagePipeHubServer_Mocking().$ctor$2(impl);
                }, $WsoRPb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1848796,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4296816092)
            
            static $h = 1848796;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296816092),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 1848796,
      "h": 4296816092,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296816092)
  ],
  "h": 1848796
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1848796)
        
        

        //--TRIMMABLE-BOUNDARY-START(144860)
        $asm.$cls(`$UrvY.LCFCM.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295112156)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295112156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295112156)
            
            static $h = 144860;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295112156),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 144860,
      "h": 4295112156,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295112156)
  ],
  "h": 144860
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(144860)
        
        

        //--TRIMMABLE-BOUNDARY-START(1914332)
        $asm.$cls(`$UrvY.LCFCM.PipeMessageModel`, ($self) => class PipeMessageModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(124555965916)
            /*string*/ static ServerOriginConnectionId = null;
            //--TRIMMABLE-BOUNDARY-END(124555965916)
            
            //--TRIMMABLE-BOUNDARY-START(115966031324)
            /*string*/ OriginConnectionId = null;
            //--TRIMMABLE-BOUNDARY-END(115966031324)
            
            //--TRIMMABLE-BOUNDARY-START(51541521884)
            /*IEnumerable<RoutePath>*/ DestinationPipesId = null;
            //--TRIMMABLE-BOUNDARY-END(51541521884)
            
            //--TRIMMABLE-BOUNDARY-START(47246554588)
            /*IEnumerable<string>?*/ DestinationClientsConnectionId = null;
            //--TRIMMABLE-BOUNDARY-END(47246554588)
            
            //--TRIMMABLE-BOUNDARY-START(188980475356)
            /*string*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(188980475356)
            
            //--TRIMMABLE-BOUNDARY-START(42951587292)
            /*string?*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(42951587292)
            
            //--TRIMMABLE-BOUNDARY-START(38656619996)
            /*int*/ AckRequestId = 0;
            //--TRIMMABLE-BOUNDARY-END(38656619996)
            
            //--TRIMMABLE-BOUNDARY-START(120260998620)
            /*int*/ RetainSeconds = 0;
            //--TRIMMABLE-BOUNDARY-END(120260998620)
            
            //--TRIMMABLE-BOUNDARY-START(34361652700)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361652700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361652700)
            
            //--TRIMMABLE-BOUNDARY-START(34361652700)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34361652700)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(124555965916)
                    this.ServerOriginConnectionId = "__ServerOriginConnectionId__";
                    //--TRIMMABLE-BOUNDARY-END(124555965916)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1914332;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115966031324),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491194844,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505638876,
        "f": 83886081
      },
      "n": "OriginConnectionId",
      "d": 1914332,
      "h": 115966031324,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966031324),
//--TRIMMABLE-BOUNDARY-START(51541521884),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901260252,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915704284,
        "f": 83886081
      },
      "n": "DestinationPipesId",
      "d": 1914332,
      "h": 51541521884,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541521884),
//--TRIMMABLE-BOUNDARY-START(47246554588),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311325660,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325769692,
        "f": 83886081
      },
      "n": "DestinationClientsConnectionId",
      "d": 1914332,
      "h": 47246554588,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246554588),
//--TRIMMABLE-BOUNDARY-START(188980475356),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671064028,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184685508060,
        "f": 83886081
      },
      "n": "Type",
      "d": 1914332,
      "h": 188980475356,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188980475356),
//--TRIMMABLE-BOUNDARY-START(42951587292),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721391068,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735835100,
        "f": 83886081
      },
      "n": "Data",
      "d": 1914332,
      "h": 42951587292,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951587292),
//--TRIMMABLE-BOUNDARY-START(38656619996),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131456476,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145900508,
        "f": 83886081
      },
      "n": "AckRequestId",
      "d": 1914332,
      "h": 38656619996,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656619996),
//--TRIMMABLE-BOUNDARY-START(120260998620),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081129436,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176095573468,
        "f": 83886081
      },
      "n": "RetainSeconds",
      "d": 1914332,
      "h": 120260998620,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260998620)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124555965916),
    {
      "t": 1310721,
      "n": "ServerOriginConnectionId",
      "d": 1914332,
      "h": 124555965916,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124555965916)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361652700),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1914332,
      "h": 34361652700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361652700)
  ],
  "h": 1914332
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}PipeMessageModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1914332)
        
        

        //--TRIMMABLE-BOUNDARY-START(1258972)
        $asm.$cls(`$UrvY.LCFCM.MessageFormattingCustomAttributesProvider`, ($self) => class MessageFormattingCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296226268)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296226268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296226268)
            
            static $h = 1258972;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296226268),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1258972,
      "h": 4296226268,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296226268)
  ],
  "h": 1258972
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessageFormattingCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessageFormattingCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1258972)
        
        

        //--TRIMMABLE-BOUNDARY-START(2504156)
        $asm.$cls(`$UrvY.LCFCM.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297471452)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297471452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$UrvY.LCFCM.MessagePipeClientTypeDescriptorBuilder.Register();
                $.$UrvY.LCFCM.PipeMessageModelTypeDescriptorBuilder.Register();
                $.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4297471452)
            
            static $h = 2504156;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297471452),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 2504156,
      "h": 4297471452,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297471452)
  ],
  "h": 2504156
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2504156)
        
        

        //--TRIMMABLE-BOUNDARY-START(1586652)
        $asm.$cls(`$UrvY.LCFCM.MessagePipeExtension`, ($self) => class MessagePipeExtension
        {
            //--TRIMMABLE-BOUNDARY-START(8591521244)
            static /*string */ GetRemoteInvocationUrl(/*this IMessagePipe*/ messagePipe, /*bool*/ clientSpecific)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591521244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `MessagePipe/${$.$strNN($.$$.S.String.Join$12($.$fPer.LCFCR$3.RoutePath, ",", messagePipe.LCFCM$IMessagePipe$PipesId))}${$.$strNN((clientSpecific ? "/" + $.$strNN(messagePipe.LCFCM$IMessagePipe$Client.ClientId) : ""))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(8591521244)
            
            //--TRIMMABLE-BOUNDARY-START(4296553948)
            static /*Task<T> */ Await(T, /*this IMessagePipe*/ messagePipe, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296553948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TaskCompletionSource<T>*/ let task = new ($.$$.STT.TaskCompletionSource$$(T))().$ctor$1();
                /*IDisposable?*/ let dispose = null;
                dispose = messagePipe.LCFCM$IMessagePipe$Subscribe(T, new ($.$$.S.Action$$(T))().$ctor(this,  (/*value*/ value) =>
                {
                    task.TrySetResult(value);
                    dispose?.S$IDisposable$Dispose();
                }, $cZuJqj ??= {"r":65537,"p":[{"n":"value","p":(T) => T.$h}],"n":"","d":1586652,"h":0,"f":17825794}));
                token.Register$1(new $.$$.S.Action().$ctor(this,  () =>
                {
                    task.TrySetCanceled();
                    dispose.S$IDisposable$Dispose();
                }, $aWIVBc ??= {"r":65537,"n":"","d":1586652,"h":0,"f":17825794}));
                return task.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(4296553948)
            
            //--TRIMMABLE-BOUNDARY-START(12886488540)
            static /*Task *//*async*/  TryFeedAckAsync(T, /*this IMessagePipe*/ messagePipe, /*T*/ data, /*int*/ retry, /*IEnumerable<RoutePath>?*/ pipesId, /*IEnumerable<string>?*/ clientsId)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886488540);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    while(retry > 0)
                    {
                        try
                        {
                            let $t1, $r1;
                            ($t1 = messagePipe.LCFCM$IMessagePipe$FeedAsync(T, data, pipesId, clientsId, true, 0), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                        catch($e)
                        {
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12886488540)
            
            static $h = 1586652;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591521244),
    {
      "r": 1310721,
      "p": [
        {
          "n": "messagePipe",
          "p": 341468
        },
        {
          "n": "clientSpecific",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "GetRemoteInvocationUrl",
      "d": 1586652,
      "h": 8591521244,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591521244),
//--TRIMMABLE-BOUNDARY-START(4296553948),
    {
      "r": (T) => $.$$.STT.Task$$(T).$h,
      "p": [
        {
          "n": "messagePipe",
          "p": 341468
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "g": [
        "T"
      ],
      "n": "Await",
      "d": 1586652,
      "h": 4296553948,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4296553948),
//--TRIMMABLE-BOUNDARY-START(12886488540),
    {
      "r": 178454529,
      "p": [
        {
          "n": "messagePipe",
          "p": 341468
        },
        {
          "n": "data",
          "p": (T) => T.$h
        },
        {
          "n": "retry",
          "p": 655361,
          "f": 65,
          "v": 3
        },
        {
          "n": "pipesId",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h,
          "f": 65
        },
        {
          "n": "clientsId",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryFeedAckAsync",
      "d": 1586652,
      "h": 12886488540,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(12886488540)
  ],
  "h": 1586652
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessagePipeExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessagePipeExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1586652)
        
        

        //--TRIMMABLE-BOUNDARY-START(2242012)
        $asm.$cls(`$UrvY.LCFCM.RetainedPipeMessageModelCustomAttributesProvider`, ($self) => class RetainedPipeMessageModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297209308)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297209308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297209308)
            
            static $h = 2242012;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297209308),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2242012,
      "h": 4297209308,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297209308)
  ],
  "h": 2242012
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}RetainedPipeMessageModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2242012)
        
        

        //--TRIMMABLE-BOUNDARY-START(2110940)
        $asm.$cls(`$UrvY.LCFCM.PipeMessageModelTypeDescriptorBuilder`, ($self) => class PipeMessageModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592045532)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592045532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UrvY.LCFCM.PipeMessageModelTypeDescriptor()
                        const $t1 = $.$UrvY.LCFCM.PipeMessageModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $OMFbZa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2110940,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UrvY.LCFCM.PipeMessageModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592045532)
            
            //--TRIMMABLE-BOUNDARY-START(4297078236)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297078236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297078236)
            
            //--TRIMMABLE-BOUNDARY-START(4297078236)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297078236)
            
            static $h = 2110940;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592045532),
    {
      "r": 65537,
      "n": "Register",
      "d": 2110940,
      "h": 8592045532,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592045532)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297078236),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2110940,
      "h": 4297078236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297078236)
  ],
  "h": 2110940
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}PipeMessageModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2110940)
        
        

        //--TRIMMABLE-BOUNDARY-START(2373084)
        $asm.$cls(`$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptorBuilder`, ($self) => class RetainedPipeMessageModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592307676)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592307676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor()
                        const $t1 = $.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xKcGga ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2373084,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UrvY.LCFCM.RetainedPipeMessageModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592307676)
            
            //--TRIMMABLE-BOUNDARY-START(4297340380)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297340380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297340380)
            
            //--TRIMMABLE-BOUNDARY-START(4297340380)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297340380)
            
            static $h = 2373084;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592307676),
    {
      "r": 65537,
      "n": "Register",
      "d": 2373084,
      "h": 8592307676,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592307676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297340380),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2373084,
      "h": 4297340380,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297340380)
  ],
  "h": 2373084
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}RetainedPipeMessageModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2373084)
        
        

        //--TRIMMABLE-BOUNDARY-START(1521116)
        $asm.$cls(`$UrvY.LCFCM.MessagePipeClientTypeDescriptorBuilder`, ($self) => class MessagePipeClientTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591455708)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591455708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$UrvY.LCFCM.MessagePipeClientTypeDescriptor()
                        const $t1 = $.$UrvY.LCFCM.MessagePipeClientTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $AoJFJb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1521116,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$UrvY.LCFCM.MessagePipeClient.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591455708)
            
            //--TRIMMABLE-BOUNDARY-START(4296488412)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296488412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296488412)
            
            //--TRIMMABLE-BOUNDARY-START(4296488412)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296488412)
            
            static $h = 1521116;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591455708),
    {
      "r": 65537,
      "n": "Register",
      "d": 1521116,
      "h": 8591455708,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591455708)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296488412),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1521116,
      "h": 4296488412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296488412)
  ],
  "h": 1521116
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClientTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessagePipeClientTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1521116)
        
        

        //--TRIMMABLE-BOUNDARY-START(1127900)
        $asm.$cls(`$UrvY.LCFCM.MessageConfiguration`, ($self) => class MessageConfiguration extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68720604636)
            /*MessageChannelTypes*/ Channel = 0;
            //--TRIMMABLE-BOUNDARY-END(68720604636)
            
            //--TRIMMABLE-BOUNDARY-START(103080343004)
            /*string?*/ FromName = null;
            //--TRIMMABLE-BOUNDARY-END(103080343004)
            
            //--TRIMMABLE-BOUNDARY-START(98785375708)
            /*string?*/ FromAddress = null;
            //--TRIMMABLE-BOUNDARY-END(98785375708)
            
            //--TRIMMABLE-BOUNDARY-START(309238773212)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(309238773212)
            
            //--TRIMMABLE-BOUNDARY-START(64425637340)
            /*MessageBody*/ Body;
            //--TRIMMABLE-BOUNDARY-END(64425637340)
            
            //--TRIMMABLE-BOUNDARY-START(206159558108)
            /*string?*/ ImageUrl = null;
            //--TRIMMABLE-BOUNDARY-END(206159558108)
            
            //--TRIMMABLE-BOUNDARY-START(73015571932)
            /*string?*/ ClickAction = null;
            //--TRIMMABLE-BOUNDARY-END(73015571932)
            
            //--TRIMMABLE-BOUNDARY-START(77310539228)
            /*string?*/ ClickText = null;
            //--TRIMMABLE-BOUNDARY-END(77310539228)
            
            //--TRIMMABLE-BOUNDARY-START(81605506524)
            /*IEnumerable<string>*/ Destination = null;
            //--TRIMMABLE-BOUNDARY-END(81605506524)
            
            //--TRIMMABLE-BOUNDARY-START(60130670044)
            /*IEnumerable<MessageAttachment>?*/ Attachments = null;
            //--TRIMMABLE-BOUNDARY-END(60130670044)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Frameworks.Common.Messaging.MessageConfiguration>.Equals(LivingThing.Core.Frameworks.Common.Messaging.MessageConfiguration?)
            S$IEquatable$LivingThing$Core$Frameworks$Common$Messaging$MessageConfiguration$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(51540735452)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540735452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540735452)
            
            //--TRIMMABLE-BOUNDARY-START(51540735452)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(51540735452)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Channel = this.Channel;
                copy.FromName = this.FromName;
                copy.FromAddress = this.FromAddress;
                copy.Title = this.Title;
                copy.Body = this.Body.$clone();
                copy.ImageUrl = this.ImageUrl;
                copy.ClickAction = this.ClickAction;
                copy.ClickText = this.ClickText;
                copy.Destination = this.Destination;
                copy.Attachments = this.Attachments;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425637340)
                this.Body = $.$default($.$UrvY.LCFCM.MessageBody);
                //--TRIMMABLE-BOUNDARY-END(64425637340)
                
                //--TRIMMABLE-BOUNDARY-START(81605506524)
                this.Destination = null;
                //--TRIMMABLE-BOUNDARY-END(81605506524)
                
            }
            //Begin generated record members
            /*Type*/ get EqualityContract() { return $.$typeOf($.$UrvY.LCFCM.MessageConfiguration); }
            /*string*/ ToString()
            {
                let stringBuilder = new $.$$.ST.StringBuilder().$ctor$1();
                stringBuilder.Append$21("MessageConfiguration");
                stringBuilder.Append$21("{");
                if (this.PrintMembers(stringBuilder))
                {
                    stringBuilder.Append$21(" ");
                }
                stringBuilder.Append$21("}");
                return stringBuilder.ToString();
            }
            /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
            {
                stringBuilder.Append$21("Channel = ");
                stringBuilder.Append$21($.$dsp(this.Channel, $.$$.S.Object, ($t) => $t.ToString));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("FromName = ");
                stringBuilder.Append$21(this.FromName);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("FromAddress = ");
                stringBuilder.Append$21(this.FromAddress);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Title = ");
                stringBuilder.Append$21(this.Title);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Body = ");
                stringBuilder.Append$21(this.Body.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ImageUrl = ");
                stringBuilder.Append$21(this.ImageUrl);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ClickAction = ");
                stringBuilder.Append$21(this.ClickAction);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ClickText = ");
                stringBuilder.Append$21(this.ClickText);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Destination = ");
                stringBuilder.Append$21($.$dsp(this.Destination, $.$$.S.Object, ($t) => $t.ToString));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Attachments = ");
                stringBuilder.Append$21($.$dsp(this.Attachments, $.$$.S.Object, ($t) => $t.ToString));
                return true;
            }
            /*bool*/ Equals$2(/*MessageConfiguration*/ other)
            {
                return this === other || (other !== null && this.EqualityContract == other.EqualityContract && this.Channel === other.Channel && $.$$.S.String.op_Equality(this.FromName, other.FromName) && $.$$.S.String.op_Equality(this.FromAddress, other.FromAddress) && $.$$.S.String.op_Equality(this.Title, other.Title) && $.$$.SCG.EqualityComparer$$($.$UrvY.LCFCM.MessageBody).Default.Equals$2(this.Body, other.Body) && $.$$.S.String.op_Equality(this.ImageUrl, other.ImageUrl) && $.$$.S.String.op_Equality(this.ClickAction, other.ClickAction) && $.$$.S.String.op_Equality(this.ClickText, other.ClickText) && $.$$.SCG.EqualityComparer$$($.$$.SCG.IEnumerable$$($.$$.S.String)).Default.Equals$2(this.Destination, other.Destination) && $.$$.SCG.EqualityComparer$$($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessageAttachment)).Default.Equals$2(this.Attachments, other.Attachments));
            }
            /*int*/ GetHashCode()
            {
                return $.$$.SCG.EqualityComparer$$($.$$.S.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$fPer.LCFC.MessageChannelTypes).Default.GetHashCode$1(this.Channel) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.FromName) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.FromAddress) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.Title) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$UrvY.LCFCM.MessageBody).Default.GetHashCode$1(this.Body) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.ImageUrl) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.ClickAction) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.ClickText) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.SCG.IEnumerable$$($.$$.S.String)).Default.GetHashCode$1(this.Destination) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessageAttachment)).Default.GetHashCode$1(this.Attachments) * -1521134295;
            }
            static /*bool*/ op_Inequality(/*MessageConfiguration*/ left, /*MessageConfiguration*/ right)
            {
                return !(this.op_Equality(left, right));
            }
            static /*bool*/ op_Equality(/*MessageConfiguration*/ left, /*MessageConfiguration*/ right)
            {
                return left === right || (left !== null && left.Equals$2(right));
            }
            Deconstruct(/*out LivingThing.Core.Frameworks.Common.MessageChannelTypes*/ $Channel, /*out string?*/ $FromName, /*out string?*/ $FromAddress, /*out string?*/ $Title, /*out LivingThing.Core.Frameworks.Common.Messaging.MessageBody*/ $Body, /*out string?*/ $ImageUrl, /*out string?*/ $ClickAction, /*out string?*/ $ClickText, /*out System.Collections.Generic.IEnumerable<string>*/ $Destination, /*out System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Messaging.MessageAttachment>?*/ $Attachments)
            {
                $Channel.$v = this.Channel;
                $FromName.$v = this.FromName;
                $FromAddress.$v = this.FromAddress;
                $Title.$v = this.Title;
                $Body.$v = this.Body;
                $ImageUrl.$v = this.ImageUrl;
                $ClickAction.$v = this.ClickAction;
                $ClickText.$v = this.ClickText;
                $Destination.$v = this.Destination;
                $Attachments.$v = this.Attachments;
            }
            //End generated record member3s
            static $h = 1127900;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900473820),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209885148,
        "f": 50331780
      },
      "n": "EqualityContract",
      "d": 1127900,
      "h": 85900473820,
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(85900473820),
//--TRIMMABLE-BOUNDARY-START(68720604636),
    {
      "p": 48728406,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850146780,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814263772,
        "f": 83886081
      },
      "n": "Channel",
      "d": 1127900,
      "h": 68720604636,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720604636),
//--TRIMMABLE-BOUNDARY-START(103080343004),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389754332,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763936732,
        "f": 83886081
      },
      "n": "FromName",
      "d": 1127900,
      "h": 103080343004,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103080343004),
//--TRIMMABLE-BOUNDARY-START(98785375708),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799819740,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279174002140,
        "f": 83886081
      },
      "n": "FromAddress",
      "d": 1127900,
      "h": 98785375708,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785375708),
//--TRIMMABLE-BOUNDARY-START(309238773212),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569623516,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943805916,
        "f": 83886081
      },
      "n": "Title",
      "d": 1127900,
      "h": 309238773212,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(309238773212),
//--TRIMMABLE-BOUNDARY-START(64425637340),
    {
      "p": 1062364,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260212188,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224329180,
        "f": 83886081
      },
      "n": "Body",
      "d": 1127900,
      "h": 64425637340,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425637340),
//--TRIMMABLE-BOUNDARY-START(206159558108),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979688924,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353871324,
        "f": 83886081
      },
      "n": "ImageUrl",
      "d": 1127900,
      "h": 206159558108,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206159558108),
//--TRIMMABLE-BOUNDARY-START(73015571932),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440081372,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404198364,
        "f": 83886081
      },
      "n": "ClickAction",
      "d": 1127900,
      "h": 73015571932,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 7,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015571932),
//--TRIMMABLE-BOUNDARY-START(77310539228),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030015964,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261994132956,
        "f": 83886081
      },
      "n": "ClickText",
      "d": 1127900,
      "h": 77310539228,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310539228),
//--TRIMMABLE-BOUNDARY-START(81605506524),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619950556,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270584067548,
        "f": 83886081
      },
      "n": "Destination",
      "d": 1127900,
      "h": 81605506524,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 9,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605506524),
//--TRIMMABLE-BOUNDARY-START(60130670044),
    {
      "p": $.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessageAttachment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670277596,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634394588,
        "f": 83886081
      },
      "n": "Attachments",
      "d": 1127900,
      "h": 60130670044,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130670044)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(313533740508),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1127900,
      "h": 313533740508,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(313533740508),
//--TRIMMABLE-BOUNDARY-START(219044459996),
    {
      "r": 262145,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        }
      ],
      "n": "PrintMembers",
      "d": 1127900,
      "h": 219044459996,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(219044459996),
//--TRIMMABLE-BOUNDARY-START(201864590812),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1127900,
      "h": 201864590812,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201864590812),
//--TRIMMABLE-BOUNDARY-START(90195441116),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1127900,
      "h": 90195441116,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195441116),
//--TRIMMABLE-BOUNDARY-START(94490408412),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1127900
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1127900,
      "h": 94490408412,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(94490408412),
//--TRIMMABLE-BOUNDARY-START(25770931676),
    {
      "r": 1127900,
      "n": "\u003CClone\u003E$",
      "o": "$$$",
      "d": 1127900,
      "h": 25770931676,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770931676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835702748),
    {
      "p": [
        {
          "n": "original",
          "p": 1127900
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1127900,
      "h": 55835702748,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(55835702748),
//--TRIMMABLE-BOUNDARY-START(51540735452),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1127900,
      "h": 51540735452,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540735452)
  ],
  "h": 1127900
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$UrvY.LCFCM.MessageConfiguration) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessageConfiguration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessageConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1127900)
        
        

        //--TRIMMABLE-BOUNDARY-START(2438620)
        $asm.$cls(`$UrvY.LCFCM.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592373212)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592373212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$UrvY.LCFCM.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$UrvY.LCFCM.IMessagePipeFactory, $.$UrvY.LCFCM.MessagePipeFactory, services);
                $.$UrvY.LCFCM.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$UrvY.LCFCM.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$UrvY.LCFCM.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592373212)
            
            //--TRIMMABLE-BOUNDARY-START(12887340508)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887340508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_MessagePipeFactory(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$UrvY.LCFCM.MessagePipeFactory().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$kVHt.LCFCH.IHubConnector$$$($.$UrvY.LCFCM.IMessagePipeHubClient, $.$UrvY.LCFCM.IMessagePipeHubServer), provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$kVHt.LCFCH.IHubConnector$$$($.$UrvY.LCFCM.IMessagePipeHubClient, $.$UrvY.LCFCM.IMessagePipeHubServer), provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$UrvY.LCFCM.IMessagePipeFactory.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$UrvY.LCFCM.ServiceRegistrar, Get_MessagePipeFactory, $eTelld ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_MessagePipeFactory","d":2438620,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12887340508)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$UrvY.LCFCM.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297405916)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297405916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297405916)
            
            //--TRIMMABLE-BOUNDARY-START(4297405916)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297405916)
            
            static $h = 2438620;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592373212),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2438620,
      "h": 8592373212,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592373212),
//--TRIMMABLE-BOUNDARY-START(12887340508),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 2438620,
      "h": 12887340508,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12887340508)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297405916),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2438620,
      "h": 4297405916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297405916)
  ],
  "h": 2438620
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2438620)
        
        

        //--TRIMMABLE-BOUNDARY-START(1324508)
        $asm.$cls(`$UrvY.LCFCM.MessagePipe`, ($self) => class MessagePipe extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38656030172)
            /*MessagePipeFactory*/ factory = null;
            //--TRIMMABLE-BOUNDARY-END(38656030172)
            
            //--TRIMMABLE-BOUNDARY-START(12886226396)
            $ctor$1(/*MessagePipeFactory*/ factory, /*IEnumerable<RoutePath>*/ pipesId)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886226396);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.factory = factory;
                    this.PipesId = pipesId;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886226396)
            
            //--TRIMMABLE-BOUNDARY-START(77310735836)
            /*IEnumerable<RoutePath>*/ PipesId = null;
            //--TRIMMABLE-BOUNDARY-END(77310735836)
            
            //--TRIMMABLE-BOUNDARY-START(25771128284)
            /*MessagePipeClient*/ Client;
            //--TRIMMABLE-BOUNDARY-END(25771128284)
            
            //--TRIMMABLE-BOUNDARY-START(42950997468)
            /*ValueTask */ FeedAsync(T, /*T*/ message, /*IEnumerable<RoutePath>?*/ pipesId, /*IEnumerable<string>?*/ clientsId, /*bool*/ needsAck, /*int*/ retainSeconds)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950997468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _message = (() =>
                {
                    //new $.$UrvY.LCFCM.PipeMessageModel()
                    const $t1 = $.$UrvY.LCFCM.PipeMessageModel;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.OriginConnectionId = $.$firstOf(this.factory.HubConnector.LCFCH$IHubConnector$$$ConnectionId, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("ConnectionId Invalid") });
                    $i1.Type = (T.$type.IsInterface || T.$type.IsAbstract$1) ? $.$$.S.Object.GetType.call(message).FullName : T.$type.FullName;
                    $i1.Data = $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(T, message, true, false, true, false, false, false, false, "FeedAsync", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Messaging\\MessagePipe.cs", "FeedAsync", 34));
                    $i1.DestinationPipesId = pipesId ?? this.PipesId;
                    $i1.DestinationClientsConnectionId = clientsId;
                    $i1.AckRequestId = needsAck ? $.$$.S.Random.Shared.Next() : 0;
                    $i1.RetainSeconds = retainSeconds;
                    return $i1;
                })();
                return this.factory.Send(_message);
            }
            //--TRIMMABLE-BOUNDARY-END(42950997468)
            
            //--TRIMMABLE-BOUNDARY-START(68720801244)
            /*Dictionary<Type, List<Action<object?>>>*/ handlers = null;
            //--TRIMMABLE-BOUNDARY-END(68720801244)
            
            //--TRIMMABLE-BOUNDARY-START(98785572316)
            /*IDisposable */ Subscribe(T, /*Action<T>*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785572316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<Action<object?>>?*/ let list = null;
                if (!this.handlers.TryGetValue(T.$type, $.$ref(() => list, ($v) => list = $v, $.$$.SCG.List$$($.$$.S.Action$$($.$$.S.Object)))))
                {
                    list = new ($.$$.SCG.List$$($.$$.S.Action$$($.$$.S.Object)))().$ctor$1();
                    this.handlers.set_Item(T.$type, list);
                }
                /*Action<object?>*/ let aa = new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*v*/ v) =>
                {
                    return handler.Invoke($.$cast(v, T));
                }, $uIYElg ??= {"r":65537,"p":[{"n":"v","p":131073}],"n":"","d":1324508,"h":0,"f":17825794});
                list.Add(aa);
                this.factory.RegisterKnownMessageType(T);
                return new $.$fPer.LCFC.DisposableDelegate().$ctor$3(new $.$$.S.Action().$ctor(this,  () =>
                {
                    return list.Remove(aa);
                }, $xkhxTa ??= {"r":65537,"n":"","d":1324508,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(98785572316)
            
            //--TRIMMABLE-BOUNDARY-START(64425833948)
            /*void */ Handle(/*Type*/ type, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425833948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en3 = this.handlers.GetEnumerator();
                while ($en3.MoveNext())
                {
                    let handler = $en3.Current;
                    {
                        if (handler.Key.IsAssignableFrom(type))
                        {
                            $.$sl.SL.Enumerable.ToList($.$$.S.Action$$($.$$.S.Object), handler.Value).ForEach(new ($.$$.S.Action$$($.$$.S.Action$$($.$$.S.Object)))().$ctor(this,  (/*handle*/ handle) =>
                            {
                                try
                                {
                                    handle.Invoke(value);
                                }
                                catch($e)
                                {
                                }
                            }, $KdHvOi ??= {"r":65537,"p":[{"n":"handle","p":$.$$.S.Action$$($.$$.S.Object).$h}],"n":"","d":1324508,"h":0,"f":17825794}));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425833948)
            
            //--TRIMMABLE-BOUNDARY-START(73015768540)
            /*EventHandler?*/ OnDisposed = null;
            //--TRIMMABLE-BOUNDARY-END(73015768540)
            
            //--TRIMMABLE-BOUNDARY-START(73015768540)
            //--TRIMMABLE-BOUNDARY-START(21476160988)
            add_OnDisposed(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476160988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDisposed = $.$$.S.Delegate.Combine$2(this.OnDisposed, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21476160988)
            
            //--TRIMMABLE-BOUNDARY-START(85900670428)
            remove_OnDisposed(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900670428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDisposed = $.$$.S.Delegate.Remove(this.OnDisposed, value);
            }
            //--TRIMMABLE-BOUNDARY-END(85900670428)
            
            //--TRIMMABLE-BOUNDARY-END(73015768540)
            
            //--TRIMMABLE-BOUNDARY-START(30066095580)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066095580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = this.factory.Remove(this);
                this.OnDisposed?.Invoke(this, $.$$.S.EventArgs.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(30066095580)
            
            //--TRIMMABLE-BOUNDARY-START(34361062876)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361062876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = this.factory.Remove(this), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34361062876)
            
            //--TRIMMABLE-BOUNDARY-START(25770145244)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipe.PipesId.get
            get LCFCM$IMessagePipe$PipesId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065112540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PipesId;
            }
            //--TRIMMABLE-BOUNDARY-END(25770145244)
            
            //--TRIMMABLE-BOUNDARY-START(17180210652)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipe.Client.get
            get LCFCM$IMessagePipe$Client()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295308764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Client;
            }
            //--TRIMMABLE-BOUNDARY-END(17180210652)
            
            //--TRIMMABLE-BOUNDARY-START(8590276060)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipe.FeedAsync<T>(T, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Routing.RoutePath>?, System.Collections.Generic.IEnumerable<string>?, bool, int)
            LCFCM$IMessagePipe$FeedAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590276060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FeedAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590276060)
            
            //--TRIMMABLE-BOUNDARY-START(34360079836)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipe.Subscribe<T>(System.Action<T>)
            LCFCM$IMessagePipe$Subscribe()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360079836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Subscribe(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34360079836)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(4385472513)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            S$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385472513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385472513)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771128284)
                this.Client = $.$default($.$UrvY.LCFCM.MessagePipeClient);
                //--TRIMMABLE-BOUNDARY-END(25771128284)
                
                //--TRIMMABLE-BOUNDARY-START(68720801244)
                this.handlers = new ($.$$.SCG.Dictionary$$$($.$$.S.Type, $.$$.SCG.List$$($.$$.S.Action$$($.$$.S.Object))))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(68720801244)
                
            }
            static $h = 1324508;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310735836),
    {
      "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130866652,
        "f": 50331649
      },
      "n": "PipesId",
      "d": 1324508,
      "h": 77310735836,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310735836),
//--TRIMMABLE-BOUNDARY-START(25771128284),
    {
      "p": 1390044,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540932060,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490605020,
        "f": 83886088
      },
      "n": "Client",
      "d": 1324508,
      "h": 25771128284,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771128284)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950997468),
    {
      "r": 181338113,
      "p": [
        {
          "n": "message",
          "p": (T) => T.$h
        },
        {
          "n": "pipesId",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h,
          "f": 65
        },
        {
          "n": "clientsId",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "needsAck",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "retainSeconds",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "g": [
        "T"
      ],
      "n": "FeedAsync",
      "d": 1324508,
      "h": 42950997468,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(42950997468),
//--TRIMMABLE-BOUNDARY-START(98785572316),
    {
      "r": 91095041,
      "p": [
        {
          "n": "handler",
          "p": (T) => $.$$.S.Action$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Subscribe",
      "d": 1324508,
      "h": 98785572316,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(98785572316),
//--TRIMMABLE-BOUNDARY-START(64425833948),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Handle",
      "d": 1324508,
      "h": 64425833948,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64425833948),
//--TRIMMABLE-BOUNDARY-START(30066095580),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1324508,
      "h": 30066095580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066095580),
//--TRIMMABLE-BOUNDARY-START(34361062876),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 1324508,
      "h": 34361062876,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34361062876)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656030172),
    {
      "t": 1652188,
      "n": "factory",
      "d": 1324508,
      "h": 38656030172,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656030172),
//--TRIMMABLE-BOUNDARY-START(68720801244),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.Type, $.$$.SCG.List$$($.$$.S.Action$$($.$$.S.Object))).$h,
      "n": "handlers",
      "d": 1324508,
      "h": 68720801244,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720801244)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886226396),
    {
      "p": [
        {
          "n": "factory",
          "p": 1652188
        },
        {
          "n": "pipesId",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1324508,
      "h": 12886226396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886226396)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(73015768540),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_OnDisposed",
        "d": 1324508,
        "h": 21476160988,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_OnDisposed",
        "d": 1324508,
        "h": 85900670428,
        "f": 285212673
      },
      "n": "OnDisposed",
      "d": 1324508,
      "h": 73015768540,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(73015768540)
  ],
  "h": 1324508
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UrvY.LCFCM.IMessagePipe, $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessagePipe`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessagePipe`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1324508)
        
        

        //--TRIMMABLE-BOUNDARY-START(1652188)
        $asm.$cls(`$UrvY.LCFCM.MessagePipeFactory`, ($self) => class MessagePipeFactory extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066423260)
            /*int*/ static ConnectionTimeOut = 10000;
            //--TRIMMABLE-BOUNDARY-END(30066423260)
            
            //--TRIMMABLE-BOUNDARY-START(60131194332)
            /*IHubConnector<IMessagePipeHubClient, IMessagePipeHubServer>*/ HubConnector = null;
            //--TRIMMABLE-BOUNDARY-END(60131194332)
            
            //--TRIMMABLE-BOUNDARY-START(17181521372)
            $ctor$1(/*IHubConnector<IMessagePipeHubClient, IMessagePipeHubServer>*/ hubConnector)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181521372);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.HubConnector = hubConnector;
                    hubConnector.LCFCH$IHubConnector$$$Subscribe(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181521372)
            
            //--TRIMMABLE-BOUNDARY-START(81606030812)
            /*List<MessagePipe>*/ pipes = null;
            //--TRIMMABLE-BOUNDARY-END(81606030812)
            
            //--TRIMMABLE-BOUNDARY-START(25771455964)
            /*ObservableCollection<MessagePipeClient>*/ Clients = null;
            //--TRIMMABLE-BOUNDARY-END(25771455964)
            
            //--TRIMMABLE-BOUNDARY-START(64426161628)
            /*ValueTask<IMessagePipe> *//*async*/  Join(/*IEnumerable<RoutePath>*/ pipesId, /*WebSocketClientMetadata*/ metadata)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$UrvY.LCFCM.IMessagePipe), $.$UrvY.LCFCM.IMessagePipe, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426161628);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.HubConnector.LCFCH$IHubConnector$$$EnsureConnected(10000/*ConnectionTimeOut*/), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*EventHandler*/ let rejoinGroup = new $.$$.S.EventHandler().$ctor(this, /*async*/  (/*s*/ s, /*e*/ e) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                        {
                            try
                            {
                                let $t2, $r2;
                                ($t2 = this.HubConnector.LCFCH$IHubConnector$$$$Execute$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubClient$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubServer$1($.$UrvY.LCFCM.MessagePipeClient, new ($.$$.S.Func$$$($.$UrvY.LCFCM.IMessagePipeHubServer, $.$$.STT.ValueTask$$($.$UrvY.LCFCM.MessagePipeClient)))().$ctor(this,  (/*pipeHub*/ pipeHub) =>
                                {
                                    return new ($.$$.STT.ValueTask$$($.$UrvY.LCFCM.MessagePipeClient))().$ctor$5(pipeHub.LCFCM$IMessagePipeHubServer$JoinGroup(pipesId, $.$clone(metadata)));
                                }, $dgXdJk ??= {"r":$.$$.STT.ValueTask$$($.$UrvY.LCFCM.MessagePipeClient).$h,"p":[{"n":"pipeHub","p":603612}],"n":"","d":1652188,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            }
                            catch($e)
                            {
                            }
                        });
                    }, $sQvStb ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"e","p":80543745}],"n":"","d":1652188,"h":0,"f":17829890});
                    this.HubConnector.LCFCH$IHubConnector$$$add_OnConnected(rejoinGroup);
                    /*var*/ let client = ($t3 = this.HubConnector.LCFCH$IHubConnector$$$$Execute$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubClient$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubServer$1($.$UrvY.LCFCM.MessagePipeClient, new ($.$$.S.Func$$$($.$UrvY.LCFCM.IMessagePipeHubServer, $.$$.STT.ValueTask$$($.$UrvY.LCFCM.MessagePipeClient)))().$ctor(this,  (/*pipeHub*/ pipeHub) =>
                    {
                        return new ($.$$.STT.ValueTask$$($.$UrvY.LCFCM.MessagePipeClient))().$ctor$5(pipeHub.LCFCM$IMessagePipeHubServer$JoinGroup(pipesId, $.$clone(metadata)));
                    }, $qpFDRg ??= {"r":$.$$.STT.ValueTask$$($.$UrvY.LCFCM.MessagePipeClient).$h,"p":[{"n":"pipeHub","p":603612}],"n":"","d":1652188,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    $.$$.SD.Debug.Assert$4(this.HubConnector.LCFCH$IHubConnector$$$ConnectionId === client.ClientId, "HubConnector.ConnectionId == client.ClientId");
                    /*var*/ let pipe = new $.$UrvY.LCFCM.MessagePipe().$ctor$1(this, pipesId);
                    this.pipes.Add(pipe);
                    pipe.Client = $.$clone(client);
                    pipe.add_OnDisposed(new $.$$.S.EventHandler().$ctor(this,  (/*s*/ s, /*e*/ e) =>
                    {
                        return this.HubConnector.LCFCH$IHubConnector$$$remove_OnConnected(rejoinGroup);
                    }, $qiISag ??= {"r":65537,"p":[{"n":"s","p":131073},{"n":"e","p":80543745}],"n":"","d":1652188,"h":0,"f":17825794}));
                    return $.$$.N.AsyncResolver.Result($asnycContext, pipe);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64426161628)
            
            //--TRIMMABLE-BOUNDARY-START(103080867292)
            /*ValueTask *//*async*/  UpdateMetadata(/*IMessagePipe*/ pipe, /*WebSocketClientMetadata*/ metadata)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080867292);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = this.HubConnector.LCFCH$IHubConnector$$$EnsureConnected(10000/*ConnectionTimeOut*/), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    /*var*/ let client = pipe.LCFCM$IMessagePipe$Client;
                    ($t5 = this.HubConnector.LCFCH$IHubConnector$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubClient$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubServer$Execute(new ($.$$.S.Func$$$($.$UrvY.LCFCM.IMessagePipeHubServer, $.$$.STT.ValueTask))().$ctor(this,  (/*pipeHub*/ pipeHub) =>
                    {
                        return new $.$$.STT.ValueTask().$ctor$5(pipeHub.LCFCM$IMessagePipeHubServer$UpdateClientMetadata($.$clone(metadata)));
                    }, $looVaj ??= {"r":181338113,"p":[{"n":"pipeHub","p":603612}],"n":"","d":1652188,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    /*var*/ let _pipe = $.$cast(pipe, $.$UrvY.LCFCM.MessagePipe);
                    _pipe.Client = $.$with(_pipe.Client, ($clone) =>
                    {
                        $clone.Metadata = $.$clone(metadata);
                    });
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103080867292)
            
            //--TRIMMABLE-BOUNDARY-START(94490932700)
            /*ValueTask *//*async*/  Remove(/*MessagePipe*/ pipe)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490932700);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t6 = this.HubConnector.LCFCH$IHubConnector$$$EnsureConnected(10000/*ConnectionTimeOut*/), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    ($t7 = this.HubConnector.LCFCH$IHubConnector$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubClient$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubServer$Execute(new ($.$$.S.Func$$$($.$UrvY.LCFCM.IMessagePipeHubServer, $.$$.STT.ValueTask))().$ctor(this,  (/*pipeHub*/ pipeHub) =>
                    {
                        return new $.$$.STT.ValueTask().$ctor$5(pipeHub.LCFCM$IMessagePipeHubServer$LeaveGroup(pipe.PipesId));
                    }, $nrGnua ??= {"r":181338113,"p":[{"n":"pipeHub","p":603612}],"n":"","d":1652188,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    this.pipes.Remove(pipe);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94490932700)
            
            //--TRIMMABLE-BOUNDARY-START(55836227036)
            /*ValueTask<IEnumerable<MessagePipeClient>?> *//*async*/  GetClients(/*RoutePath*/ pipeId)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient)), $.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient), async ($asnycContext) => 
                {
                    let $t8, $r8;
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836227036);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t8 = this.HubConnector.LCFCH$IHubConnector$$$EnsureConnected(10000/*ConnectionTimeOut*/), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t9 = this.HubConnector.LCFCH$IHubConnector$$$$Execute$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubClient$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubServer$1($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient), new ($.$$.S.Func$$$($.$UrvY.LCFCM.IMessagePipeHubServer, $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient))))().$ctor(this,  (/**/ hub) =>
                    {
                        return new ($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient)))().$ctor$5(hub.LCFCM$IMessagePipeHubServer$GetClients($.$clone(pipeId)));
                    }, $rPwsOg ??= {"r":$.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient)).$h,"p":[{"n":"hub","p":603612}],"n":"","d":1652188,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55836227036)
            
            //--TRIMMABLE-BOUNDARY-START(21476488668)
            /*ConcurrentDictionary<int, TaskCompletionSource>?*/ awaitingAck = null;
            //--TRIMMABLE-BOUNDARY-END(21476488668)
            
            //--TRIMMABLE-BOUNDARY-START(98785899996)
            /*ValueTask *//*async*/  Send(/*PipeMessageModel*/ message)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t10, $r10;
                    let $t11, $r11;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785899996);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t10 = this.HubConnector.LCFCH$IHubConnector$$$EnsureConnected(10000/*ConnectionTimeOut*/), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    ($t11 = this.HubConnector.LCFCH$IHubConnector$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubClient$LivingThing$Core$Frameworks$Common$Messaging$IMessagePipeHubServer$Execute(new ($.$$.S.Func$$$($.$UrvY.LCFCM.IMessagePipeHubServer, $.$$.STT.ValueTask))().$ctor(this,  (/**/ server) =>
                    {
                        return new $.$$.STT.ValueTask().$ctor$5(server.LCFCM$IMessagePipeHubServer$Send(message));
                    }, $HiiBhf ??= {"r":181338113,"p":[{"n":"server","p":603612}],"n":"","d":1652188,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    if (message.AckRequestId > 0)
                    {
                        let $t12, $r12;
                        /*CancellationTokenSource*/ let cts = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                        /*TaskCompletionSource*/ let tcs = new $.$$.STT.TaskCompletionSource().$ctor$1();
                        this.awaitingAck ??= new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$$.STT.TaskCompletionSource))().$ctor$1();
                        this.awaitingAck.set_Item$1(message.AckRequestId, tcs);
                        cts.CancelAfter(15000);
                        cts.Token.Register$1(new $.$$.S.Action().$ctor(this,  () =>
                        {
                            $.$$.SCG.CollectionExtensions.Remove($.$$.S.Int32, $.$$.STT.TaskCompletionSource, this.awaitingAck, message.AckRequestId, $.$discardRef());
                            tcs.TrySetCanceled();
                        }, $AcfhKd ??= {"r":65537,"n":"","d":1652188,"h":0,"f":17825794}));
                        ($t12 = tcs.Task, ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(98785899996)
            
            //--TRIMMABLE-BOUNDARY-START(34361390556)
            /*ValueTask *//*async*/  FeedAsync(T, /*T*/ message, /*IEnumerable<RoutePath>*/ pipesId, /*IEnumerable<string>?*/ clientsId, /*bool*/ needsAck, /*int*/ retainSeconds)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t13, $r13;
                    let $t15, $r15;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361390556);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t13 = this.HubConnector.LCFCH$IHubConnector$$$EnsureConnected(10000/*ConnectionTimeOut*/), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                    /*var*/ let _message = (() =>
                    {
                        //new $.$UrvY.LCFCM.PipeMessageModel()
                        const $t14 = $.$UrvY.LCFCM.PipeMessageModel;
                        const $i14 = new $t14();
                        $i14.$ctor$1();
                        $i14.OriginConnectionId = this.HubConnector.LCFCH$IHubConnector$$$ConnectionId;
                        $i14.Type = T.$type.FullName;
                        $i14.Data = $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(T, message, true, false, true, false, false, false, false, "FeedAsync", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Messaging\\MessagePipeFactory.cs", "FeedAsync", 120));
                        $i14.DestinationPipesId = pipesId;
                        $i14.DestinationClientsConnectionId = clientsId;
                        $i14.AckRequestId = needsAck ? $.$$.S.Random.Shared.Next() : 0;
                        $i14.RetainSeconds = retainSeconds;
                        return $i14;
                    })();
                    ($t15 = this.Send(_message), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34361390556)
            
            //--TRIMMABLE-BOUNDARY-START(68721128924)
            /*ConcurrentDictionary<string, Type>*/ static knownMessageTypes = null;
            //--TRIMMABLE-BOUNDARY-END(68721128924)
            
            //--TRIMMABLE-BOUNDARY-START(90195965404)
            /*void */ RegisterKnownMessageType(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195965404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$UrvY.LCFCM.MessagePipeFactory.knownMessageTypes.set_Item$1(T.$type.FullName, T.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(90195965404)
            
            //--TRIMMABLE-BOUNDARY-START(85900998108)
            /*Task *//*async*/  ReceiveMessage(/*PipeMessageModel*/ message)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900998108);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (message.Type === $.$UrvY.LCFCM.MessagePipeMessageAcknowledge.$type.FullName)
                    {
                        /*var*/ let ack = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$UrvY.LCFCM.MessagePipeMessageAcknowledge, message.Data, false, "ReceiveMessage", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Messaging\\MessagePipeFactory.cs", "ReceiveMessage", 140);
                        if ($.$$.S.Int32.op_GreaterThan((ack?.RequestId ?? null), 0))
                        {
                            /*var*/ let task;
                            if ((this.awaitingAck?.TryRemove$1(ack.RequestId, $.$ref(() => task, ($v) => task = $v, $.$$.STT.TaskCompletionSource)) ?? null) ?? false)
                            {
                                task.SetResult();
                            }
                        }
                        else 
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("Message ack must have a request Id");
                        }
                    }
                    else 
                    {
                        /*var*/ let handlers = $.$sl.SL.Enumerable.Where($.$UrvY.LCFCM.MessagePipe, this.pipes, new ($.$$.S.Func$$$($.$UrvY.LCFCM.MessagePipe, $.$$.S.Boolean))().$ctor(this,  (/*pipe*/ pipe) =>
                        {
                            return $.$sl.SL.Enumerable.Any($.$fPer.LCFCR$3.RoutePath, pipe.PipesId, new ($.$$.S.Func$$$($.$fPer.LCFCR$3.RoutePath, $.$$.S.Boolean))().$ctor(this,  (/*pipeId*/ pipeId) =>
                            {
                                return $.$sl.SL.Enumerable.Any($.$fPer.LCFCR$3.RoutePath, message.DestinationPipesId, new ($.$$.S.Func$$$($.$fPer.LCFCR$3.RoutePath, $.$$.S.Boolean))().$ctor(this,  (/*messagePipeId*/ messagePipeId) =>
                                {
                                    return $.$fPer.LCFCR$3.RoutePath.op_Equality$2(pipeId, messagePipeId);
                                }, $AZjQxe ??= {"r":262145,"p":[{"n":"messagePipeId","p":56789334}],"n":"","d":1652188,"h":0,"f":17825794}));
                            }, $QxuRbe ??= {"r":262145,"p":[{"n":"pipeId","p":56789334}],"n":"","d":1652188,"h":0,"f":17825794})) && (message.DestinationClientsConnectionId === null || $.$sl.SL.Enumerable.Contains$1($.$$.S.String, message.DestinationClientsConnectionId, pipe.Client.ClientId));
                        }, $pAUaMj ??= {"r":262145,"p":[{"n":"pipe","p":1324508}],"n":"","d":1652188,"h":0,"f":17825794}));
                        if ($.$sl.SL.Enumerable.Any$1($.$UrvY.LCFCM.MessagePipe, handlers))
                        {
                            /*Type?*/ let type;
                            $.$UrvY.LCFCM.MessagePipeFactory.knownMessageTypes.TryGetValue(message.Type, $.$ref(() => type, ($v) => type = $v, $.$$.S.Type));
                            type ??= $.$$.S.Type.GetType$8(message.Type);
                            if (type !== null)
                            {
                                /*var*/ let value = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerializeAs$2(message.Data, type);
                                let $en18 = handlers.SCG$IEnumerable$$$GetEnumerator();
                                while ($en18.SC$1$IEnumerator$MoveNext())
                                {
                                    let handler = $en18.SCG$IEnumerator$$$Current;
                                    {
                                        handler.Handle(type, value);
                                    }
                                }
                            }
                        }
                        if (message.AckRequestId > 0)
                        {
                            let $t19, $r19;
                            ($t19 = this.Send((() =>
                            {
                                //new $.$UrvY.LCFCM.PipeMessageModel()
                                const $t20 = $.$UrvY.LCFCM.PipeMessageModel;
                                const $i20 = new $t20();
                                $i20.$ctor$1();
                                $i20.OriginConnectionId = $.$firstOf(this.HubConnector.LCFCH$IHubConnector$$$ConnectionId, () => { throw new $.$$.S.InvalidOperationException().$ctor$12("ConnectionId Invalid") });
                                $i20.Type = $.$UrvY.LCFCM.MessagePipeMessageAcknowledge.$type.FullName;
                                $i20.Data = $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$UrvY.LCFCM.MessagePipeMessageAcknowledge, (() =>
                                {
                                    //new $.$UrvY.LCFCM.MessagePipeMessageAcknowledge()
                                    const $t21 = $.$UrvY.LCFCM.MessagePipeMessageAcknowledge;
                                    const $i21 = new $t21();
                                    $i21.$ctor$1();
                                    $i21.RequestId = message.AckRequestId;
                                    return $i21;
                                })(), true, false, true, false, false, false, false, "ReceiveMessage", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Messaging\\MessagePipeFactory.cs", "ReceiveMessage", 176));
                                $i20.DestinationPipesId = $.$sl.SL.Enumerable.Empty($.$fPer.LCFCR$3.RoutePath);
                                $i20.DestinationClientsConnectionId = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [message.OriginConnectionId], null, null);
                                return $i20;
                            })()), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85900998108)
            
            //--TRIMMABLE-BOUNDARY-START(73016096220)
            /*Task */ NotifyJoined(/*MessagePipeClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016096220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Clients.Add($.$clone(client));
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(73016096220)
            
            //--TRIMMABLE-BOUNDARY-START(77311063516)
            /*Task */ NotifyLeave(/*MessagePipeClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311063516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Clients.Remove($.$clone(client));
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(77311063516)
            
            //--TRIMMABLE-BOUNDARY-START(17180276188)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeFactory.Clients.get
            get LCFCM$IMessagePipeFactory$Clients()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295374300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clients;
            }
            //--TRIMMABLE-BOUNDARY-END(17180276188)
            
            //--TRIMMABLE-BOUNDARY-START(30065178076)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeFactory.RegisterKnownMessageType<T>()
            LCFCM$IMessagePipeFactory$RegisterKnownMessageType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065178076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterKnownMessageType(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065178076)
            
            //--TRIMMABLE-BOUNDARY-START(25770210780)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeFactory.Join(System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Routing.RoutePath>, LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadata)
            LCFCM$IMessagePipeFactory$Join()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770210780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Join(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770210780)
            
            //--TRIMMABLE-BOUNDARY-START(34360145372)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeFactory.UpdateMetadata(LivingThing.Core.Frameworks.Common.Messaging.IMessagePipe, LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadata)
            LCFCM$IMessagePipeFactory$UpdateMetadata()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360145372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UpdateMetadata(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34360145372)
            
            //--TRIMMABLE-BOUNDARY-START(21475243484)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeFactory.GetClients(LivingThing.Core.Frameworks.Common.Routing.RoutePath)
            LCFCM$IMessagePipeFactory$GetClients()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475243484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetClients(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475243484)
            
            //--TRIMMABLE-BOUNDARY-START(8590341596)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeFactory.FeedAsync<T>(T, System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Routing.RoutePath>, System.Collections.Generic.IEnumerable<string>?, bool, int)
            LCFCM$IMessagePipeFactory$FeedAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590341596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FeedAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590341596)
            
            //--TRIMMABLE-BOUNDARY-START(4295439836)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeHubClient.NotifyJoined(LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient)
            LCFCM$IMessagePipeHubClient$NotifyJoined()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295439836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NotifyJoined(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295439836)
            
            //--TRIMMABLE-BOUNDARY-START(8590407132)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeHubClient.NotifyLeave(LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient)
            LCFCM$IMessagePipeHubClient$NotifyLeave()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590407132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NotifyLeave(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590407132)
            
            //--TRIMMABLE-BOUNDARY-START(12885374428)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeHubClient.ReceiveMessage(LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel)
            LCFCM$IMessagePipeHubClient$ReceiveMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885374428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReceiveMessage(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885374428)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81606030812)
                this.pipes = new ($.$$.SCG.List$$($.$UrvY.LCFCM.MessagePipe))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(81606030812)
                
                //--TRIMMABLE-BOUNDARY-START(25771455964)
                this.Clients = new ($.$so.SCO.ObservableCollection$$($.$UrvY.LCFCM.MessagePipeClient))().$ctor$3();
                //--TRIMMABLE-BOUNDARY-END(25771455964)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12886554076)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886554076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(68721128924)
                    this.knownMessageTypes = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.Type))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(68721128924)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886554076)
            
            static $h = 1652188;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131194332),
    {
      "p": $.$kVHt.LCFCH.IHubConnector$$$($.$UrvY.LCFCM.IMessagePipeHubClient, $.$UrvY.LCFCM.IMessagePipeHubServer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541259740,
        "f": 50331656
      },
      "n": "HubConnector",
      "d": 1652188,
      "h": 60131194332,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(60131194332),
//--TRIMMABLE-BOUNDARY-START(25771455964),
    {
      "p": $.$so.SCO.ObservableCollection$$($.$UrvY.LCFCM.MessagePipeClient).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951325148,
        "f": 50331649
      },
      "n": "Clients",
      "d": 1652188,
      "h": 25771455964,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771455964)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64426161628),
    {
      "r": $.$$.STT.ValueTask$$($.$UrvY.LCFCM.IMessagePipe).$h,
      "p": [
        {
          "n": "pipesId",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h
        },
        {
          "n": "metadata",
          "p": 1190345,
          "f": 65
        }
      ],
      "n": "Join",
      "d": 1652188,
      "h": 64426161628,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(64426161628),
//--TRIMMABLE-BOUNDARY-START(103080867292),
    {
      "r": 181338113,
      "p": [
        {
          "n": "pipe",
          "p": 341468
        },
        {
          "n": "metadata",
          "p": 1190345
        }
      ],
      "n": "UpdateMetadata",
      "d": 1652188,
      "h": 103080867292,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(103080867292),
//--TRIMMABLE-BOUNDARY-START(94490932700),
    {
      "r": 181338113,
      "p": [
        {
          "n": "pipe",
          "p": 1324508
        }
      ],
      "n": "Remove",
      "d": 1652188,
      "h": 94490932700,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(94490932700),
//--TRIMMABLE-BOUNDARY-START(55836227036),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient)).$h,
      "p": [
        {
          "n": "pipeId",
          "p": 56789334
        }
      ],
      "n": "GetClients",
      "d": 1652188,
      "h": 55836227036,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(55836227036),
//--TRIMMABLE-BOUNDARY-START(98785899996),
    {
      "r": 181338113,
      "p": [
        {
          "n": "message",
          "p": 1914332
        }
      ],
      "n": "Send",
      "d": 1652188,
      "h": 98785899996,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(98785899996),
//--TRIMMABLE-BOUNDARY-START(34361390556),
    {
      "r": 181338113,
      "p": [
        {
          "n": "message",
          "p": (T) => T.$h
        },
        {
          "n": "pipesId",
          "p": $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$h
        },
        {
          "n": "clientsId",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "needsAck",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "retainSeconds",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "g": [
        "T"
      ],
      "n": "FeedAsync",
      "d": 1652188,
      "h": 34361390556,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(34361390556),
//--TRIMMABLE-BOUNDARY-START(90195965404),
    {
      "r": 65537,
      "g": [
        "T"
      ],
      "n": "RegisterKnownMessageType",
      "d": 1652188,
      "h": 90195965404,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(90195965404),
//--TRIMMABLE-BOUNDARY-START(85900998108),
    {
      "r": 178454529,
      "p": [
        {
          "n": "message",
          "p": 1914332
        }
      ],
      "n": "ReceiveMessage",
      "d": 1652188,
      "h": 85900998108,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(85900998108),
//--TRIMMABLE-BOUNDARY-START(73016096220),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1390044
        }
      ],
      "n": "NotifyJoined",
      "d": 1652188,
      "h": 73016096220,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016096220),
//--TRIMMABLE-BOUNDARY-START(77311063516),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1390044
        }
      ],
      "n": "NotifyLeave",
      "d": 1652188,
      "h": 77311063516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311063516)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066423260),
    {
      "t": 655361,
      "n": "ConnectionTimeOut",
      "d": 1652188,
      "h": 30066423260,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30066423260),
//--TRIMMABLE-BOUNDARY-START(81606030812),
    {
      "t": $.$$.SCG.List$$($.$UrvY.LCFCM.MessagePipe).$h,
      "n": "pipes",
      "d": 1652188,
      "h": 81606030812,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81606030812),
//--TRIMMABLE-BOUNDARY-START(21476488668),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$$.STT.TaskCompletionSource).$h,
      "n": "awaitingAck",
      "d": 1652188,
      "h": 21476488668,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476488668),
//--TRIMMABLE-BOUNDARY-START(68721128924),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.Type).$h,
      "n": "knownMessageTypes",
      "d": 1652188,
      "h": 68721128924,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68721128924)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181521372),
    {
      "p": [
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$$($.$UrvY.LCFCM.IMessagePipeHubClient, $.$UrvY.LCFCM.IMessagePipeHubServer).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1652188,
      "h": 17181521372,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181521372)
  ],
  "h": 1652188
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$UrvY.LCFCM.IMessagePipeFactory, $.$UrvY.LCFCM.IMessagePipeHubClient, $.$kVHt.LCFCH.IPluginHubClient, $.$kVHt.LCFCH.IWebSocketClientHub, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessagePipeFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessagePipeFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1652188)
        
        

        //--TRIMMABLE-BOUNDARY-START(1062364)
        $asm.$str(`$UrvY.LCFCM.MessageBody`, ($self) => class MessageBody extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(64425571804)
            /*string*/ Message = null;
            //--TRIMMABLE-BOUNDARY-END(64425571804)
            
            //--TRIMMABLE-BOUNDARY-START(17180931548)
            /*MessageFormatting*/ Formatting = 0;
            //--TRIMMABLE-BOUNDARY-END(17180931548)
            
            //--TRIMMABLE-BOUNDARY-START(90195375580)
            /*string */ get Text()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835637212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Formatting)
                {
                    case 1/*MessageFormatting.Markdown*/:
                    return $.$fPer.LCFCS$6.StringExtension.RemoveMarkdownFormatting(this.Message, null);
                    case 2/*MessageFormatting.Html*/:
                    return $.$swh.SW.HttpUtility.HtmlDecode$1($.$fPer.LCFCS$6.StringExtension.RemoveHtmlFormatting(this.Message));
                }
                return this.Message;
            }
            //--TRIMMABLE-BOUNDARY-END(90195375580)
            
            //--TRIMMABLE-BOUNDARY-START(60130604508)
            /*string */ GetMarkdown(/*string?*/ entitiesSupported)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130604508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Formatting)
                {
                    case 2/*MessageFormatting.Html*/:
                    return $.$fPer.LCFCS$6.StringExtension.MarkdownLiteral($.$swh.SW.HttpUtility.HtmlDecode$1($.$fPer.LCFCS$6.StringExtension.RemoveHtmlFormatting(this.Message)), null, entitiesSupported);
                }
                return $.$fPer.LCFCS$6.StringExtension.MarkdownLiteral(this.Message, null, entitiesSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(60130604508)
            
            //--TRIMMABLE-BOUNDARY-START(98785310172)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785310172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Message;
            }
            //--TRIMMABLE-BOUNDARY-END(98785310172)
            
            //--TRIMMABLE-BOUNDARY-START(25770866140)
            static /*MessageBody */ FromMarkdown(/*string*/ text)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770866140);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$UrvY.LCFCM.MessageBody()
                        const $t3 = $.$UrvY.LCFCM.MessageBody;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Message = text;
                        $i3.Formatting = 1/*MessageFormatting.Markdown*/;
                        return $i3;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770866140)
            
            //--TRIMMABLE-BOUNDARY-START(21475898844)
            static /*MessageBody */ FromHtml(/*string*/ text)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475898844);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$UrvY.LCFCM.MessageBody()
                        const $t4 = $.$UrvY.LCFCM.MessageBody;
                        const $i4 = new $t4();
                        $i4.$ctor$2();
                        $i4.Message = text;
                        $i4.Formatting = 2/*MessageFormatting.Html*/;
                        return $i4;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475898844)
            
            //--TRIMMABLE-BOUNDARY-START(30065833436)
            static /*MessageBody */ FromText(/*string*/ text)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065833436);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$UrvY.LCFCM.MessageBody()
                        const $t5 = $.$UrvY.LCFCM.MessageBody;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Message = text;
                        $i5.Formatting = 0/*MessageFormatting.None*/;
                        return $i5;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065833436)
            
            //--TRIMMABLE-BOUNDARY-START(94490342876)
            static /*MessageBody */ op_Implicit$1(/*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490342876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*MessageFormatting*/ let formatting = 0/*MessageFormatting.None*/;
                if ($.$$.S.String.Contains$1.call(text, /***/ 42) || $.$$.S.String.Contains$1.call(text, /*_*/ 95) || $.$$.S.String.Contains$1.call(text, /*`*/ 96))
                {
                    formatting = 1/*MessageFormatting.Markdown*/;
                }
                return (() =>
                {
                    //new $.$UrvY.LCFCM.MessageBody()
                    const $t6 = $.$UrvY.LCFCM.MessageBody;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Message = text;
                    $i6.Formatting = formatting;
                    return $i6;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(94490342876)
            
            //--TRIMMABLE-BOUNDARY-START(85900408284)
            static /*string */ op_Implicit(/*MessageBody*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900408284);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return message.Message;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900408284)
            
            //--TRIMMABLE-BOUNDARY-START(12885964252)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885964252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885964252)
            
            //--TRIMMABLE-BOUNDARY-START(12885964252)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885964252)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Message = this.Message;
                copy.Formatting = this.Formatting;
                return copy;
            }
            static $h = 1062364;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425571804),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245702620,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605440988,
        "f": 83886081
      },
      "n": "Message",
      "d": 1062364,
      "h": 64425571804,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425571804),
//--TRIMMABLE-BOUNDARY-START(17180931548),
    {
      "p": 1193436,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655768028,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015506396,
        "f": 83886081
      },
      "n": "Formatting",
      "d": 1062364,
      "h": 17180931548,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180931548),
//--TRIMMABLE-BOUNDARY-START(90195375580),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835637212,
        "f": 50331649
      },
      "n": "Text",
      "d": 1062364,
      "h": 90195375580,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195375580)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130604508),
    {
      "r": 1310721,
      "p": [
        {
          "n": "entitiesSupported",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetMarkdown",
      "d": 1062364,
      "h": 60130604508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130604508),
//--TRIMMABLE-BOUNDARY-START(98785310172),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1062364,
      "h": 98785310172,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785310172),
//--TRIMMABLE-BOUNDARY-START(25770866140),
    {
      "r": 1062364,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "FromMarkdown",
      "d": 1062364,
      "h": 25770866140,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770866140),
//--TRIMMABLE-BOUNDARY-START(21475898844),
    {
      "r": 1062364,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "FromHtml",
      "d": 1062364,
      "h": 21475898844,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475898844),
//--TRIMMABLE-BOUNDARY-START(30065833436),
    {
      "r": 1062364,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "FromText",
      "d": 1062364,
      "h": 30065833436,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065833436)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885964252),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1062364,
      "h": 12885964252,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885964252)
  ],
  "h": 1062364
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessageBody`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessageBody`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1062364)
        
        

        //--TRIMMABLE-BOUNDARY-START(1390044)
        $asm.$str(`$UrvY.LCFCM.MessagePipeClient`, ($self) => class MessagePipeClient extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17181259228)
            /*string*/ ClientId = null;
            //--TRIMMABLE-BOUNDARY-END(17181259228)
            
            //--TRIMMABLE-BOUNDARY-START(42951063004)
            /*WebSocketClientMetadata*/ Metadata;
            //--TRIMMABLE-BOUNDARY-END(42951063004)
            
            //--TRIMMABLE-BOUNDARY-START(64425899484)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425899484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.ClientId)}${$.$strNN((this.Metadata.DisplayName !== null ? ` => ${$.$strNN(this.Metadata.DisplayName)}` : ""))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(64425899484)
            
            //--TRIMMABLE-BOUNDARY-START(21476226524)
            /*bool */ Equals$2(/*MessagePipeClient*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476226524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ClientId === other.ClientId;
            }
            //--TRIMMABLE-BOUNDARY-END(21476226524)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient>.Equals(LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient)
            S$IEquatable$LivingThing$Core$Frameworks$Common$Messaging$MessagePipeClient$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(12886291932)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886291932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886291932)
            
            //--TRIMMABLE-BOUNDARY-START(12886291932)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886291932)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ClientId = this.ClientId;
                copy.Metadata = this.Metadata.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42951063004)
                this.Metadata = $.$default($.$kVHt.LCFCH.WebSocketClientMetadata);
                //--TRIMMABLE-BOUNDARY-END(42951063004)
                
            }
            static $h = 1390044;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181259228),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066161116,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540997596,
        "f": 83886081
      },
      "n": "ClientId",
      "d": 1390044,
      "h": 17181259228,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181259228),
//--TRIMMABLE-BOUNDARY-START(42951063004),
    {
      "p": 1190345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656095708,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130932188,
        "f": 83886081
      },
      "n": "Metadata",
      "d": 1390044,
      "h": 42951063004,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951063004)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425899484),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1390044,
      "h": 64425899484,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425899484),
//--TRIMMABLE-BOUNDARY-START(21476226524),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1390044
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1390044,
      "h": 21476226524,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476226524)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886291932),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1390044,
      "h": 12886291932,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886291932)
  ],
  "h": 1390044,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$UrvY.LCFCM.MessagePipeClient) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessagePipeClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1390044)
        
        

        //--TRIMMABLE-BOUNDARY-START(538076)
        $asm.$cls(`$UrvY.LCFCM.IMessagePipeHubClient_Mocking`, ($self) => class IMessagePipeHubClient_Mocking extends $.$zHIt.LCFCM.MockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295505372)
            $ctor$2(/*IMockImplement*/ impl)
            {
                super.$ctor$1(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295505372);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295505372)
            
            //--TRIMMABLE-BOUNDARY-START(8590472668)
            /*System.Threading.Tasks.Task */ LCFCM$IMessagePipeHubClient$NotifyJoined(/*LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590472668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$UrvY.LCFCM.IMessagePipeHubClient.$type;
                    $i1.ReturnType = $.$$.S.Void.$type;
                    $i1.MethodName = "NotifyJoined";
                    return $i1;
                })();
                return this.InvokeAsync$1($.$UrvY.LCFCM.IMessagePipeHubClient, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$UrvY.LCFCM.MessagePipeClient.$type, $.$clone(client)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590472668)
            
            //--TRIMMABLE-BOUNDARY-START(12885439964)
            /*System.Threading.Tasks.Task */ LCFCM$IMessagePipeHubClient$NotifyLeave(/*LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient*/ client)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885439964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$UrvY.LCFCM.IMessagePipeHubClient.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "NotifyLeave";
                    return $i2;
                })();
                return this.InvokeAsync$1($.$UrvY.LCFCM.IMessagePipeHubClient, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$UrvY.LCFCM.MessagePipeClient.$type, $.$clone(client)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885439964)
            
            //--TRIMMABLE-BOUNDARY-START(17180407260)
            /*System.Threading.Tasks.Task */ LCFCM$IMessagePipeHubClient$ReceiveMessage(/*LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180407260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$UrvY.LCFCM.IMessagePipeHubClient.$type;
                    $i3.ReturnType = $.$$.S.Void.$type;
                    $i3.MethodName = "ReceiveMessage";
                    return $i3;
                })();
                return this.InvokeAsync$1($.$UrvY.LCFCM.IMessagePipeHubClient, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$UrvY.LCFCM.PipeMessageModel.$type, message) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180407260)
            
            static $h = 538076;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$zHIt.LCFCM.MockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295505372),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 538076,
      "h": 4295505372,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295505372)
  ],
  "h": 538076
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$UrvY.LCFCM.IMessagePipeHubClient, $.$kVHt.LCFCH.IPluginHubClient, $.$kVHt.LCFCH.IWebSocketClientHub, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeHubClient_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessagePipeHubClient_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(538076)
        
        

        //--TRIMMABLE-BOUNDARY-START(669148)
        $asm.$cls(`$UrvY.LCFCM.IMessagePipeHubServer_Mocking`, ($self) => class IMessagePipeHubServer_Mocking extends $.$zHIt.LCFCM.MockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295636444)
            $ctor$2(/*IMockImplement*/ impl)
            {
                super.$ctor$1(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295636444);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295636444)
            
            //--TRIMMABLE-BOUNDARY-START(8590603740)
            /*System.Threading.Tasks.Task<System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient>?> */ LCFCM$IMessagePipeHubServer$GetClients(/*LivingThing.Core.Frameworks.Common.Routing.RoutePath*/ pipeId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590603740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$UrvY.LCFCM.IMessagePipeHubServer.$type;
                    $i1.ReturnType = $.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient).$type;
                    $i1.MethodName = "GetClients";
                    return $i1;
                })();
                return this.InvokeAsync($.$UrvY.LCFCM.IMessagePipeHubServer, $.$$.SCG.IEnumerable$$($.$UrvY.LCFCM.MessagePipeClient), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCR$3.RoutePath.$type, $.$clone(pipeId)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590603740)
            
            //--TRIMMABLE-BOUNDARY-START(12885571036)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient> */ LCFCM$IMessagePipeHubServer$JoinGroup(/*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Routing.RoutePath>*/ pipesId, /*LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadata*/ metadata)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885571036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$UrvY.LCFCM.IMessagePipeHubServer.$type;
                    $i2.ReturnType = $.$UrvY.LCFCM.MessagePipeClient.$type;
                    $i2.MethodName = "JoinGroup";
                    return $i2;
                })();
                return this.InvokeAsync($.$UrvY.LCFCM.IMessagePipeHubServer, $.$UrvY.LCFCM.MessagePipeClient, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$type, pipesId), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$kVHt.LCFCH.WebSocketClientMetadata.$type, $.$clone(metadata)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885571036)
            
            //--TRIMMABLE-BOUNDARY-START(25770472924)
            /*System.Threading.Tasks.Task */ LCFCM$IMessagePipeHubServer$UpdateClientMetadata(/*LivingThing.Core.Frameworks.Common.Hub.WebSocketClientMetadata*/ metadata)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770472924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$UrvY.LCFCM.IMessagePipeHubServer.$type;
                    $i3.ReturnType = $.$$.S.Void.$type;
                    $i3.MethodName = "UpdateClientMetadata";
                    return $i3;
                })();
                return this.InvokeAsync$1($.$UrvY.LCFCM.IMessagePipeHubServer, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$kVHt.LCFCH.WebSocketClientMetadata.$type, $.$clone(metadata)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770472924)
            
            //--TRIMMABLE-BOUNDARY-START(17180538332)
            /*System.Threading.Tasks.Task */ LCFCM$IMessagePipeHubServer$LeaveGroup(/*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Routing.RoutePath>*/ pipesId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180538332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$UrvY.LCFCM.IMessagePipeHubServer.$type;
                    $i4.ReturnType = $.$$.S.Void.$type;
                    $i4.MethodName = "LeaveGroup";
                    return $i4;
                })();
                return this.InvokeAsync$1($.$UrvY.LCFCM.IMessagePipeHubServer, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath).$type, pipesId) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180538332)
            
            //--TRIMMABLE-BOUNDARY-START(21475505628)
            /*System.Threading.Tasks.Task */ LCFCM$IMessagePipeHubServer$Send(/*LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475505628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$UrvY.LCFCM.IMessagePipeHubServer.$type;
                    $i5.ReturnType = $.$$.S.Void.$type;
                    $i5.MethodName = "Send";
                    return $i5;
                })();
                return this.InvokeAsync$1($.$UrvY.LCFCM.IMessagePipeHubServer, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$UrvY.LCFCM.PipeMessageModel.$type, message) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475505628)
            
            static $h = 669148;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$zHIt.LCFCM.MockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295636444),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 669148,
      "h": 4295636444,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295636444)
  ],
  "h": 669148
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$UrvY.LCFCM.IMessagePipeHubServer, $.$kVHt.LCFCH.IPluginHubServer, $.$kVHt.LCFCH.IWebSocketServerHub$$$($.$UrvY.LCFCM.IMessagePipeHubServer, $.$UrvY.LCFCM.IMessagePipeHubClient), $.$kVHt.LCFCH.IWebSocketServerHub$$($.$UrvY.LCFCM.IMessagePipeHubClient), $.$kVHt.LCFCH.IWebSocketServerHub, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.IMessagePipeHubServer_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}IMessagePipeHubServer_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(669148)
        
        

        //--TRIMMABLE-BOUNDARY-START(1193436)
        $asm.$str(`$UrvY.LCFCM.MessageFormatting`, ($self) => class MessageFormatting extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Markdown = 1;
            static Html = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1193436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Markdown": 1n,
                    "Html": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296160732)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296160732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296160732)
            
            //--TRIMMABLE-BOUNDARY-START(4296160732)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296160732)
            
            static $h = 1193436;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181062620),
    {
      "t": 1193436,
      "n": "None",
      "d": 1193436,
      "h": 17181062620,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181062620),
//--TRIMMABLE-BOUNDARY-START(12886095324),
    {
      "t": 1193436,
      "n": "Markdown",
      "d": 1193436,
      "h": 12886095324,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886095324),
//--TRIMMABLE-BOUNDARY-START(8591128028),
    {
      "t": 1193436,
      "n": "Html",
      "d": 1193436,
      "h": 8591128028,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591128028)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296160732),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1193436,
      "h": 4296160732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296160732)
  ],
  "h": 1193436
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessageFormatting`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessageFormatting`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1193436)
        
        

        //--TRIMMABLE-BOUNDARY-START(2045404)
        $asm.$cls(`$UrvY.LCFCM.PipeMessageModelTypeDescriptor`, ($self) => class PipeMessageModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UrvY.LCFCM.PipeMessageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297012700)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297012700);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UrvY.LCFCM.PipeMessageModelTypeDescriptor.GenerateProperties($.$UrvY.LCFCM.PipeMessageModel, this, factory);
                    }, $jQjWVh ??= {"r":65537,"n":"","d":2045404,"h":0,"f":17825794}), 0, "PipeMessageModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Messaging\\PipeMessageModel_LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModelTypeDescriptorBuilder.g.cs", "PipeMessageModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297012700)
            
            //--TRIMMABLE-BOUNDARY-START(12886947292)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886947292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OriginConnectionId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.PipeMessageModel.$type, $.$discardRef(), "OriginConnectionId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OriginConnectionId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "OriginConnectionId";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UrvY.LCFCM.PipeMessageModel)).OriginConnectionId);
                        }, $TEotYg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2045404,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.OriginConnectionId = value.AsReference($.$$.S.String);
                        }, $xJDmSk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2045404,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DestinationPipesId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.PipeMessageModel.$type, $.$discardRef(), "DestinationPipesId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DestinationPipesId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "DestinationPipesId";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath), ($.$cast(target, $.$UrvY.LCFCM.PipeMessageModel)).DestinationPipesId);
                        }, $olWwFb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2045404,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.DestinationPipesId = value.AsReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath));
                        }, $xxKkHi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2045404,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DestinationClientsConnectionId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.PipeMessageModel.$type, $.$discardRef(), "DestinationClientsConnectionId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DestinationClientsConnectionId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "DestinationClientsConnectionId";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$UrvY.LCFCM.PipeMessageModel)).DestinationClientsConnectionId);
                        }, $qonyAd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2045404,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DestinationClientsConnectionId = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $YslaHh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2045404,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.PipeMessageModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Type";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UrvY.LCFCM.PipeMessageModel)).Type);
                        }, $gRQvVe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2045404,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.Type = value.AsReference($.$$.S.String);
                        }, $jmGAWf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2045404,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Data"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.PipeMessageModel.$type, $.$discardRef(), "Data", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Data")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Data";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UrvY.LCFCM.PipeMessageModel)).Data);
                        }, $ecqLQe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2045404,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Data = value.AsReference($.$$.S.String);
                        }, $POpgLb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2045404,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AckRequestId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.PipeMessageModel.$type, $.$discardRef(), "AckRequestId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AckRequestId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "AckRequestId";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$UrvY.LCFCM.PipeMessageModel)).AckRequestId);
                        }, $PVIZlf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2045404,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.AckRequestId = value.AsInt();
                        }, $HwEkZa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2045404,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RetainSeconds"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.PipeMessageModel.$type, $.$discardRef(), "RetainSeconds", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RetainSeconds")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "RetainSeconds";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$UrvY.LCFCM.PipeMessageModel)).RetainSeconds);
                        }, $rzzxcg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2045404,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.PipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.RetainSeconds = value.AsInt();
                        }, $ydDcDg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2045404,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886947292)
            
            //--TRIMMABLE-BOUNDARY-START(17181914588)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181914588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _OriginConnectionId = _target.OriginConnectionId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OriginConnectionId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _OriginConnectionId, ($v) => _OriginConnectionId = $v, $.$$.S.String)))
                    {
                        _target.OriginConnectionId = _OriginConnectionId;
                    }
                }
                {
                    /*var*/ let _DestinationPipesId = _target.DestinationPipesId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DestinationPipesId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath, property, $.$ref(() => _DestinationPipesId, ($v) => _DestinationPipesId = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath))))
                    {
                        _target.DestinationPipesId = _DestinationPipesId;
                        if (_DestinationPipesId !== null)
                        {
                            let $en17 = _DestinationPipesId.SCG$IEnumerable$$$GetEnumerator();
                            while ($en17.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en17.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCR$3.RoutePath, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath, property, $.$ref(() => _DestinationPipesId, ($v) => _DestinationPipesId = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath)));
                    }
                }
                {
                    /*var*/ let _DestinationClientsConnectionId = _target.DestinationClientsConnectionId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DestinationClientsConnectionId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _DestinationClientsConnectionId, ($v) => _DestinationClientsConnectionId = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.DestinationClientsConnectionId = _DestinationClientsConnectionId;
                        if (_DestinationClientsConnectionId !== null)
                        {
                            let $en22 = _DestinationClientsConnectionId.SCG$IEnumerable$$$GetEnumerator();
                            while ($en22.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en22.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _DestinationClientsConnectionId, ($v) => _DestinationClientsConnectionId = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Type, ($v) => _Type = $v, $.$$.S.String)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _Data = _target.Data;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Data"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Data, ($v) => _Data = $v, $.$$.S.String)))
                    {
                        _target.Data = _Data;
                    }
                }
                {
                    /*var*/ let _AckRequestId = _target.AckRequestId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AckRequestId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _AckRequestId, ($v) => _AckRequestId = $v, $.$$.S.Int32)))
                    {
                        _target.AckRequestId = _AckRequestId;
                    }
                }
                {
                    /*var*/ let _RetainSeconds = _target.RetainSeconds;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RetainSeconds"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _RetainSeconds, ($v) => _RetainSeconds = $v, $.$$.S.Int32)))
                    {
                        _target.RetainSeconds = _RetainSeconds;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181914588)
            
            //--TRIMMABLE-BOUNDARY-START(8591979996)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591979996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UrvY.LCFCM.PipeMessageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UrvY.LCFCM.PipeMessageModel)))
                {
                    /*var*/ let result = $.$UrvY.LCFCM.PipeMessageModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$UrvY.LCFCM.PipeMessageModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UrvY.LCFCM.PipeMessageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UrvY.LCFCM.PipeMessageModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591979996)
            
            static $h = 2045404;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UrvY.LCFCM.PipeMessageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886947292),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2045404,
      "h": 12886947292,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886947292),
//--TRIMMABLE-BOUNDARY-START(17181914588),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1914332,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2045404,
      "h": 17181914588,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181914588),
//--TRIMMABLE-BOUNDARY-START(8591979996),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1914332,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2045404,
      "h": 8591979996,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591979996)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297012700),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2045404,
      "h": 4297012700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297012700)
  ],
  "h": 2045404
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UrvY.LCFCM.PipeMessageModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.PipeMessageModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}PipeMessageModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2045404)
        
        

        //--TRIMMABLE-BOUNDARY-START(2307548)
        $asm.$cls(`$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor`, ($self) => class RetainedPipeMessageModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UrvY.LCFCM.RetainedPipeMessageModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297274844)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297274844);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor.GenerateProperties($.$UrvY.LCFCM.RetainedPipeMessageModel, this, factory);
                    }, $uRPSkc ??= {"r":65537,"n":"","d":2307548,"h":0,"f":17825794}), 0, "RetainedPipeMessageModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Messaging\\RetainedPipeMessageModel_LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModelTypeDescriptorBuilder.g.cs", "RetainedPipeMessageModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297274844)
            
            //--TRIMMABLE-BOUNDARY-START(12887209436)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887209436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OriginConnectionId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.RetainedPipeMessageModel.$type, $.$discardRef(), "OriginConnectionId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OriginConnectionId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "OriginConnectionId";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UrvY.LCFCM.RetainedPipeMessageModel)).OriginConnectionId);
                        }, $XkogWh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2307548,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OriginConnectionId = value.AsReference($.$$.S.String);
                        }, $lCqEWh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2307548,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("PipesId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.RetainedPipeMessageModel.$type, $.$discardRef(), "PipesId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("PipesId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "PipesId";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath), ($.$cast(target, $.$UrvY.LCFCM.RetainedPipeMessageModel)).PipesId);
                        }, $bvXesa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2307548,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.PipesId = value.AsReference($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath));
                        }, $atPkKk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2307548,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ClientsId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.RetainedPipeMessageModel.$type, $.$discardRef(), "ClientsId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ClientsId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "ClientsId";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$$.S.String), ($.$cast(target, $.$UrvY.LCFCM.RetainedPipeMessageModel)).ClientsId);
                        }, $WvRoIj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2307548,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ClientsId = value.AsReference($.$$.SCG.IEnumerable$$($.$$.S.String));
                        }, $vYvJwj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2307548,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.RetainedPipeMessageModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Type";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UrvY.LCFCM.RetainedPipeMessageModel)).Type);
                        }, $KinIki ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2307548,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Type = value.AsReference($.$$.S.String);
                        }, $lAWfke ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2307548,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Data"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.RetainedPipeMessageModel.$type, $.$discardRef(), "Data", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Data")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Data";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UrvY.LCFCM.RetainedPipeMessageModel)).Data);
                        }, $DMrQgc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2307548,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Data = value.AsReference($.$$.S.String);
                        }, $WDxJAg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2307548,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AckRequestId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.RetainedPipeMessageModel.$type, $.$discardRef(), "AckRequestId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AckRequestId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "AckRequestId";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$UrvY.LCFCM.RetainedPipeMessageModel)).AckRequestId);
                        }, $zfRtDc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2307548,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.AckRequestId = value.AsInt();
                        }, $RTRecj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2307548,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Expiry"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.RetainedPipeMessageModel.$type, $.$discardRef(), "Expiry", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Expiry")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Expiry";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$UrvY.LCFCM.RetainedPipeMessageModel)).Expiry);
                        }, $Nhdmaf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2307548,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Expiry = value.AsDateTime();
                        }, $uuVRbh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2307548,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887209436)
            
            //--TRIMMABLE-BOUNDARY-START(17182176732)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182176732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _OriginConnectionId = _target.OriginConnectionId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OriginConnectionId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _OriginConnectionId, ($v) => _OriginConnectionId = $v, $.$$.S.String)))
                    {
                        _target.OriginConnectionId = _OriginConnectionId;
                    }
                }
                {
                    /*var*/ let _PipesId = _target.PipesId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("PipesId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath, property, $.$ref(() => _PipesId, ($v) => _PipesId = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath))))
                    {
                        _target.PipesId = _PipesId;
                        if (_PipesId !== null)
                        {
                            let $en17 = _PipesId.SCG$IEnumerable$$$GetEnumerator();
                            while ($en17.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en17.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCR$3.RoutePath, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath), $.$fPer.LCFCR$3.RoutePath, property, $.$ref(() => _PipesId, ($v) => _PipesId = $v, $.$$.SCG.IEnumerable$$($.$fPer.LCFCR$3.RoutePath)));
                    }
                }
                {
                    /*var*/ let _ClientsId = _target.ClientsId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ClientsId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$$.S.String)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _ClientsId, ($v) => _ClientsId = $v, $.$$.SCG.IEnumerable$$($.$$.S.String))))
                    {
                        _target.ClientsId = _ClientsId;
                        if (_ClientsId !== null)
                        {
                            let $en22 = _ClientsId.SCG$IEnumerable$$$GetEnumerator();
                            while ($en22.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en22.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$$.S.String)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$$.S.String), $.$$.S.String, property, $.$ref(() => _ClientsId, ($v) => _ClientsId = $v, $.$$.SCG.IEnumerable$$($.$$.S.String)));
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Type, ($v) => _Type = $v, $.$$.S.String)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _Data = _target.Data;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Data"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Data, ($v) => _Data = $v, $.$$.S.String)))
                    {
                        _target.Data = _Data;
                    }
                }
                {
                    /*var*/ let _AckRequestId = _target.AckRequestId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AckRequestId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _AckRequestId, ($v) => _AckRequestId = $v, $.$$.S.Int32)))
                    {
                        _target.AckRequestId = _AckRequestId;
                    }
                }
                {
                    /*var*/ let _Expiry = _target.Expiry;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Expiry"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _Expiry, ($v) => _Expiry = $v, null, true)))
                    {
                        _target.Expiry = _Expiry;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182176732)
            
            //--TRIMMABLE-BOUNDARY-START(8592242140)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592242140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                if (_target === null)
                {
                    return false;
                }
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UrvY.LCFCM.RetainedPipeMessageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UrvY.LCFCM.RetainedPipeMessageModel)))
                {
                    /*var*/ let result = $.$UrvY.LCFCM.RetainedPipeMessageModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$UrvY.LCFCM.RetainedPipeMessageModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UrvY.LCFCM.RetainedPipeMessageModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$UrvY.LCFCM.RetainedPipeMessageModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592242140)
            
            static $h = 2307548;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UrvY.LCFCM.RetainedPipeMessageModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887209436),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2307548,
      "h": 12887209436,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887209436),
//--TRIMMABLE-BOUNDARY-START(17182176732),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2176476,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2307548,
      "h": 17182176732,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182176732),
//--TRIMMABLE-BOUNDARY-START(8592242140),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2176476,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2307548,
      "h": 8592242140,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592242140)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297274844),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2307548,
      "h": 4297274844,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297274844)
  ],
  "h": 2307548
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UrvY.LCFCM.RetainedPipeMessageModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.RetainedPipeMessageModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}RetainedPipeMessageModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2307548)
        
        

        //--TRIMMABLE-BOUNDARY-START(1455580)
        $asm.$cls(`$UrvY.LCFCM.MessagePipeClientTypeDescriptor`, ($self) => class MessagePipeClientTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UrvY.LCFCM.MessagePipeClient)
        {
            //--TRIMMABLE-BOUNDARY-START(4296422876)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296422876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$UrvY.LCFCM.MessagePipeClientTypeDescriptor.GenerateProperties($.$UrvY.LCFCM.MessagePipeClient, this, factory);
                    }, $ZOEdRc ??= {"r":65537,"n":"","d":1455580,"h":0,"f":17825794}), 0, "MessagePipeClientTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Messaging\\MessagePipeClient_LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClientTypeDescriptorBuilder.g.cs", "MessagePipeClientTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296422876)
            
            //--TRIMMABLE-BOUNDARY-START(12886357468)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886357468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ClientId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.MessagePipeClient.$type, $.$discardRef(), "ClientId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ClientId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ClientId";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.MessagePipeClientTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$UrvY.LCFCM.MessagePipeClient)).ClientId);
                        }, $wDOhyb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1455580,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.MessagePipeClientTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$UrvY.LCFCM.MessagePipeClient, target).$v.ClientId = value.AsReference($.$$.S.String);
                        }, $vZIoYc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1455580,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Metadata"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$UrvY.LCFCM.MessagePipeClient.$type, $.$discardRef(), "Metadata", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Metadata")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$kVHt.LCFCH.WebSocketClientMetadata, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Metadata";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.MessagePipeClientTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$kVHt.LCFCH.WebSocketClientMetadata, ($.$cast(target, $.$UrvY.LCFCM.MessagePipeClient)).Metadata);
                        }, $fZFXZh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1455580,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$UrvY.LCFCM.MessagePipeClientTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$UrvY.LCFCM.MessagePipeClient, target).$v.Metadata = value.AsValue($.$kVHt.LCFCH.WebSocketClientMetadata);
                        }, $siXVUj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1455580,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886357468)
            
            //--TRIMMABLE-BOUNDARY-START(17181324764)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181324764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _ClientId = _target.ClientId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ClientId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ClientId, ($v) => _ClientId = $v, $.$$.S.String)))
                    {
                        _target.ClientId = _ClientId;
                    }
                }
                {
                    /*var*/ let _Metadata = _target.Metadata;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Metadata"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$kVHt.LCFCH.WebSocketClientMetadata));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$kVHt.LCFCH.WebSocketClientMetadata, () => _Metadata, ($v) => _Metadata = $v, null, true)))
                    {
                        _target.Metadata = $.$clone(_Metadata);
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181324764)
            
            //--TRIMMABLE-BOUNDARY-START(8591390172)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClient*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591390172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$UrvY.LCFCM.MessagePipeClient, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$UrvY.LCFCM.MessagePipeClient, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$UrvY.LCFCM.MessagePipeClientTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$UrvY.LCFCM.MessagePipeClient, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$UrvY.LCFCM.MessagePipeClient, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$UrvY.LCFCM.MessagePipeClient, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591390172)
            
            static $h = 1455580;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$UrvY.LCFCM.MessagePipeClient); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886357468),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1455580,
      "h": 12886357468,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886357468),
//--TRIMMABLE-BOUNDARY-START(17181324764),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1390044,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1455580,
      "h": 17181324764,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181324764),
//--TRIMMABLE-BOUNDARY-START(8591390172),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1390044,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1455580,
      "h": 8591390172,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591390172)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296422876),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1455580,
      "h": 4296422876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296422876)
  ],
  "h": 1455580
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$UrvY.LCFCM.MessagePipeClient), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Messaging.MessagePipeClientTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Messaging${separator}MessagePipeClientTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1455580)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.RPC"));
})();
//--TRIMMABLE-BOUNDARY-END(13788)
