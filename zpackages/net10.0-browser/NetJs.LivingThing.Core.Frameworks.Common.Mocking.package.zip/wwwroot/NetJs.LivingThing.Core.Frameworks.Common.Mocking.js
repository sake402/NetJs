
//--TRIMMABLE-BOUNDARY-START(61254)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer) {
    "use strict";
    let _;
    let $vOsiJa;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Mocking", 
    {
  "h": 61254,
  "f": "LivingThing.Core.Frameworks.Common.Mocking",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Mocking",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Mocking",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(126790)
        $asm.$cls(`$zHIt.LCFCM.IMocked`, ($self) => class IMocked
        {
            static $h = 126790;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 126790
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.IMocked`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}IMocked`; }
        });
        //--TRIMMABLE-BOUNDARY-END(126790)
        
        

        //--TRIMMABLE-BOUNDARY-START(257862)
        $asm.$cls(`$zHIt.LCFCM.ITestMock`, ($self) => class ITestMock
        {
            static $h = 257862;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885159750),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590192454,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 21475094342,
        "f": 83886337
      },
      "n": "Property",
      "o": "LCFCM$ITestMock$Property",
      "d": 257862,
      "h": 12885159750,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885159750)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770061638),
    {
      "r": 65537,
      "n": "Test1",
      "o": "LCFCM$ITestMock$Test1",
      "d": 257862,
      "h": 25770061638,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770061638),
//--TRIMMABLE-BOUNDARY-START(30065028934),
    {
      "r": 655361,
      "n": "Test2",
      "o": "LCFCM$ITestMock$Test2",
      "d": 257862,
      "h": 30065028934,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065028934),
//--TRIMMABLE-BOUNDARY-START(34359996230),
    {
      "r": 655361,
      "p": [
        {
          "n": "a",
          "p": 655361
        }
      ],
      "n": "Test3",
      "o": "LCFCM$ITestMock$Test3",
      "d": 257862,
      "h": 34359996230,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34359996230)
  ],
  "h": 257862,
  "a": [
    {
      "t": 454470,
      "c": 12885356358
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.ITestMock`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}ITestMock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(257862)
        
        

        //--TRIMMABLE-BOUNDARY-START(192326)
        $asm.$cls(`$zHIt.LCFCM.IMockImplement`, ($self) => class IMockImplement
        {
            static $h = 192326;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295159622),
    {
      "r": (TInterface, TResult) => TResult.$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "Invoke",
      "o": "LCFCM$IMockImplement$Invoke",
      "d": 192326,
      "h": 4295159622,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(4295159622),
//--TRIMMABLE-BOUNDARY-START(8590126918),
    {
      "r": (TInterface, TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "InvokeAsync",
      "o": "LCFCM$IMockImplement$InvokeAsync",
      "d": 192326,
      "h": 8590126918,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8590126918)
  ],
  "h": 192326
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.IMockImplement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}IMockImplement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(192326)
        
        

        //--TRIMMABLE-BOUNDARY-START(585542)
        $asm.$cls(`$zHIt.LCFCM.MockBase`, ($self) => class MockBase extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475422022)
            /*IMockImplement*/ impl = null;
            //--TRIMMABLE-BOUNDARY-END(21475422022)
            
            //--TRIMMABLE-BOUNDARY-START(8590520134)
            $ctor$1(/*IMockImplement*/ impl)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590520134);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.impl = impl;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590520134)
            
            //--TRIMMABLE-BOUNDARY-START(30065356614)
            /*void */ Invoke$1(TInterface, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065356614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.impl.LCFCM$IMockImplement$Invoke(TInterface, $.$$.S.Object, $.$clone(context), parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(30065356614)
            
            //--TRIMMABLE-BOUNDARY-START(25770389318)
            /*TResult */ Invoke(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770389318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.impl.LCFCM$IMockImplement$Invoke(TInterface, TResult, $.$clone(context), parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(25770389318)
            
            //--TRIMMABLE-BOUNDARY-START(34360323910)
            /*Task<TResult> */ InvokeAsync(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360323910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.impl.LCFCM$IMockImplement$InvokeAsync(TInterface, TResult, $.$clone(context), parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(34360323910)
            
            //--TRIMMABLE-BOUNDARY-START(38655291206)
            /*Task */ InvokeAsync$1(TInterface, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655291206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.impl.LCFCM$IMockImplement$InvokeAsync(TInterface, $.$$.S.Object, $.$clone(context), parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(38655291206)
            
            //--TRIMMABLE-BOUNDARY-START(42950258502)
            /*ValueTask<TResult> */ InvokeValueAsync(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950258502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$$.STT.ValueTask$$(TResult))().$ctor$5(this.impl.LCFCM$IMockImplement$InvokeAsync(TInterface, TResult, $.$clone(context), parameters));
            }
            //--TRIMMABLE-BOUNDARY-END(42950258502)
            
            //--TRIMMABLE-BOUNDARY-START(47245225798)
            /*ValueTask */ InvokeValueAsync$1(TInterface, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245225798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.STT.ValueTask().$ctor$5(this.impl.LCFCM$IMockImplement$InvokeAsync(TInterface, $.$$.S.Object, $.$clone(context), parameters));
            }
            //--TRIMMABLE-BOUNDARY-END(47245225798)
            
            static $h = 585542;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475422022),
    {
      "p": 192326,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180454726,
        "f": 50331652
      },
      "n": "impl",
      "d": 585542,
      "h": 21475422022,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(21475422022)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065356614),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface"
      ],
      "n": "Invoke",
      "o": "@$1",
      "d": 585542,
      "h": 30065356614,
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(30065356614),
//--TRIMMABLE-BOUNDARY-START(25770389318),
    {
      "r": (TInterface, TResult) => TResult.$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "Invoke",
      "d": 585542,
      "h": 25770389318,
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(25770389318),
//--TRIMMABLE-BOUNDARY-START(34360323910),
    {
      "r": (TInterface, TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "InvokeAsync",
      "d": 585542,
      "h": 34360323910,
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(34360323910),
//--TRIMMABLE-BOUNDARY-START(38655291206),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface"
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 585542,
      "h": 38655291206,
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(38655291206),
//--TRIMMABLE-BOUNDARY-START(42950258502),
    {
      "r": (TInterface, TResult) => $.$$.STT.ValueTask$$(TResult).$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "InvokeValueAsync",
      "d": 585542,
      "h": 42950258502,
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(42950258502),
//--TRIMMABLE-BOUNDARY-START(47245225798),
    {
      "r": 181338113,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface"
      ],
      "n": "InvokeValueAsync",
      "o": "@$1",
      "d": 585542,
      "h": 47245225798,
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(47245225798)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590520134),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 585542,
      "h": 8590520134,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590520134)
  ],
  "h": 585542
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockBase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(585542)
        
        

        //--TRIMMABLE-BOUNDARY-START(913222)
        $asm.$cls(`$zHIt.LCFCM.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295880518)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295880518);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$zHIt.LCFCM.ITestMock, $.$zHIt.LCFCM.ITestMock_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$zHIt.LCFCM.ITestMock_Mocking().$ctor$2(impl);
                }, $vOsiJa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":913222,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295880518)
            
            static $h = 913222;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295880518),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 913222,
      "h": 4295880518,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295880518)
  ],
  "h": 913222
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(913222)
        
        

        //--TRIMMABLE-BOUNDARY-START(388934)
        $asm.$cls(`$zHIt.LCFCM.Mock`, ($self) => class Mock
        {
            //--TRIMMABLE-BOUNDARY-START(12885290822)
            static /*T? */ Interface$2(T, /*IMockImplement*/ handler, /*bool*/ required)
            {
                /*var*/ let proxy;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885290822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$zHIt.LCFCM.MockFactory.TryGetMockedService$1(T, handler, $.$ref(() => proxy, ($v) => proxy = $v, T)))
                {
                    return proxy;
                }
                if (required)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`You must define ${$.$strNN("MockAttribute")} on ${$.$strNN(T.$type.FullName)} to use this api`);
                }
                return $.$default(T);
            }
            //--TRIMMABLE-BOUNDARY-END(12885290822)
            
            //--TRIMMABLE-BOUNDARY-START(4295356230)
            static /*object? */ Interface(/*Type*/ type, /*IMockImplement*/ handler, /*bool*/ required)
            {
                /*var*/ let proxy;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295356230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$zHIt.LCFCM.MockFactory.TryGetMockedService(type, handler, $.$ref(() => proxy, ($v) => proxy = $v, $.$$.S.Object)))
                {
                    return proxy;
                }
                if (required)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`You must define ${$.$strNN("MockAttribute")} on ${$.$strNN(type.FullName)} to use this api`);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4295356230)
            
            //--TRIMMABLE-BOUNDARY-START(17180258118)
            static /*T? */ Interface$3(T, /*MockHandler*/ handler, /*bool*/ required)
            {
                /*var*/ let proxy;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180258118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$zHIt.LCFCM.MockFactory.TryGetMockedService$1(T, new $.$zHIt.LCFCM.MockHandlerImplement().$ctor$1(handler), $.$ref(() => proxy, ($v) => proxy = $v, T)))
                {
                    return proxy;
                }
                if (required)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`You must define ${$.$strNN("MockAttribute")} on ${$.$strNN(T.$type.FullName)} to use this api`);
                }
                return $.$default(T);
            }
            //--TRIMMABLE-BOUNDARY-END(17180258118)
            
            //--TRIMMABLE-BOUNDARY-START(8590323526)
            static /*object? */ Interface$1(/*Type*/ type, /*MockHandler*/ handler, /*bool*/ required)
            {
                /*var*/ let proxy;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590323526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$zHIt.LCFCM.MockFactory.TryGetMockedService(type, new $.$zHIt.LCFCM.MockHandlerImplement().$ctor$1(handler), $.$ref(() => proxy, ($v) => proxy = $v, $.$$.S.Object)))
                {
                    return proxy;
                }
                if (required === true)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`You must define ${$.$strNN("MockAttribute")} on ${$.$strNN(type.FullName)} to use this api`);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590323526)
            
            static $h = 388934;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885290822),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "handler",
          "p": 192326
        },
        {
          "n": "required",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "g": [
        "T"
      ],
      "n": "Interface",
      "o": "@$2",
      "d": 388934,
      "h": 12885290822,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885290822),
//--TRIMMABLE-BOUNDARY-START(4295356230),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "handler",
          "p": 192326
        },
        {
          "n": "required",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Interface",
      "d": 388934,
      "h": 4295356230,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295356230),
//--TRIMMABLE-BOUNDARY-START(17180258118),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "handler",
          "p": 782150
        },
        {
          "n": "required",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "g": [
        "T"
      ],
      "n": "Interface",
      "o": "@$3",
      "d": 388934,
      "h": 17180258118,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180258118),
//--TRIMMABLE-BOUNDARY-START(8590323526),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "handler",
          "p": 782150
        },
        {
          "n": "required",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Interface",
      "o": "@$1",
      "d": 388934,
      "h": 8590323526,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590323526)
  ],
  "h": 388934
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.Mock`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}Mock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(388934)
        
        

        //--TRIMMABLE-BOUNDARY-START(651078)
        $asm.$cls(`$zHIt.LCFCM.MockFactory`, ($self) => class MockFactory
        {
            //--TRIMMABLE-BOUNDARY-START(716614)
            static $_MockContext;
            static get MockContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(716614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$zHIt.LCFCM.MockFactory;
                return $cls.$_MockContext ??= $asm.$nstr(`$zHIt.LCFCM.MockFactory.MockContext`, ($self) => class MockContext extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885618502)
                    /*MockServiceFactory*/ Factory = null;
                    //--TRIMMABLE-BOUNDARY-END(12885618502)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590651206)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590651206);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590651206)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590651206)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590651206)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Factory = this.Factory;
                        return copy;
                    }
                    static $h = 716614;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885618502),
    {
      "p": 1109830,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475553094,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065487686,
        "f": 83886081
      },
      "n": "Factory",
      "d": 716614,
      "h": 12885618502,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885618502)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590651206),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 716614,
      "h": 8590651206,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590651206)
  ],
  "d": 651078,
  "h": 716614
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockFactory+MockContext`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockFactory${separator}MockContext`; }
                }, $cls, ($v) => $cls.$_MockContext = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(716614)
            
            //--TRIMMABLE-BOUNDARY-START(8590585670)
            /*Dictionary<Type, MockContext>*/ static generatedProxies = null;
            //--TRIMMABLE-BOUNDARY-END(8590585670)
            
            //--TRIMMABLE-BOUNDARY-START(12885552966)
            static /*void */ Register(TMockInterface, TGeneratedType, /*MockServiceFactory*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885552966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.generatedProxies.Add(TMockInterface.$type, (() =>
                {
                    //new $.$zHIt.LCFCM.MockFactory.MockContext()
                    const $t1 = $.$zHIt.LCFCM.MockFactory.MockContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Factory = factory;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(12885552966)
            
            //--TRIMMABLE-BOUNDARY-START(21475487558)
            static /*bool */ TryGetMockedService$1(TService, /*IMockImplement*/ impl, /*out TService?*/ service)
            {
                /*var*/ let context;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475487558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$zHIt.LCFCM.MockFactory.generatedProxies.TryGetValue(TService.$type, $.$ref(() => context, ($v) => context = $v, $.$zHIt.LCFCM.MockFactory.MockContext)))
                {
                    service.$v = $.$cast((context.Factory.Invoke(impl)), TService);
                    return true;
                }
                service.$v = $.$default(TService);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475487558)
            
            //--TRIMMABLE-BOUNDARY-START(17180520262)
            static /*bool */ TryGetMockedService(/*Type*/ type, /*IMockImplement*/ impl, /*out object?*/ service)
            {
                /*var*/ let context;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180520262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$zHIt.LCFCM.MockFactory.generatedProxies.TryGetValue(type, $.$ref(() => context, ($v) => context = $v, $.$zHIt.LCFCM.MockFactory.MockContext)))
                {
                    service.$v = (context.Factory.Invoke(impl));
                    return true;
                }
                service.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180520262)
            
            //--TRIMMABLE-BOUNDARY-START(4295618374)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295618374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590585670)
                    this.generatedProxies = new ($.$$.SCG.Dictionary$$$($.$$.S.Type, $.$zHIt.LCFCM.MockFactory.MockContext))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(8590585670)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295618374)
            
            static $h = 651078;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885552966),
    {
      "r": 65537,
      "p": [
        {
          "n": "factory",
          "p": 1109830
        }
      ],
      "g": [
        "TMockInterface",
        "TGeneratedType"
      ],
      "n": "Register",
      "d": 651078,
      "h": 12885552966,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885552966),
//--TRIMMABLE-BOUNDARY-START(21475487558),
    {
      "r": 262145,
      "p": [
        {
          "n": "impl",
          "p": 192326
        },
        {
          "n": "service",
          "p": (TService) => TService.$h,
          "f": 2
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryGetMockedService",
      "o": "@$1",
      "d": 651078,
      "h": 21475487558,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(21475487558),
//--TRIMMABLE-BOUNDARY-START(17180520262),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "impl",
          "p": 192326
        },
        {
          "n": "service",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetMockedService",
      "d": 651078,
      "h": 17180520262,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180520262)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590585670),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.Type, $.$zHIt.LCFCM.MockFactory.MockContext).$h,
      "n": "generatedProxies",
      "d": 651078,
      "h": 8590585670,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590585670)
  ],
  "h": 651078
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$zHIt.LCFCM.MockFactory.MockContext ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(651078)
        
        

        //--TRIMMABLE-BOUNDARY-START(847686)
        $asm.$cls(`$zHIt.LCFCM.MockHandlerImplement`, ($self) => class MockHandlerImplement extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590782278)
            /*MockHandler*/ handler = null;
            //--TRIMMABLE-BOUNDARY-END(8590782278)
            
            //--TRIMMABLE-BOUNDARY-START(4295814982)
            $ctor$1(/*MockHandler*/ handler)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295814982);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.handler = handler;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295814982)
            
            //--TRIMMABLE-BOUNDARY-START(12885749574)
            /*TResult */ Invoke(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885749574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(this.handler.Invoke($.$clone(context), parameters), TResult);
            }
            //--TRIMMABLE-BOUNDARY-END(12885749574)
            
            //--TRIMMABLE-BOUNDARY-START(17180716870)
            /*Task<TResult> *//*async*/  InvokeAsync(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TResult), TResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180716870);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let couldBeTask = this.handler.Invoke($.$clone(context), parameters);
                    let task;
                    if ($.$is(couldBeTask, $.$$.STT.Task, { set $v($v){ task = $v; } }))
                    {
                        let $t1, $r1;
                        ($t1 = task, ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        if ($.$$.S.Object.GetType.call(task).IsGenericType)
                        {
                            /*var*/ let rType = $.$$.System.Array.$ReadT1.call($.$$.S.Object.GetType.call(task).GetGenericArguments(), 0);
                            if (rType !== $.$$.S.Void.$type && rType.FullName !== "System.Threading.Tasks.VoidTaskResult")
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, (task).Result);
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$default(TResult));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17180716870)
            
            //--TRIMMABLE-BOUNDARY-START(4295159622)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mocking.IMockImplement.Invoke<TInterface, TResult>(LivingThing.Core.Frameworks.Common.Mocking.MockMethodContext, params LivingThing.Core.Frameworks.Common.Mocking.MockMethodParameter[])
            LCFCM$IMockImplement$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295159622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295159622)
            
            //--TRIMMABLE-BOUNDARY-START(8590126918)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mocking.IMockImplement.InvokeAsync<TInterface, TResult>(LivingThing.Core.Frameworks.Common.Mocking.MockMethodContext, params LivingThing.Core.Frameworks.Common.Mocking.MockMethodParameter[])
            LCFCM$IMockImplement$InvokeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590126918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590126918)
            
            static $h = 847686;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885749574),
    {
      "r": (TInterface, TResult) => TResult.$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "Invoke",
      "d": 847686,
      "h": 12885749574,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(12885749574),
//--TRIMMABLE-BOUNDARY-START(17180716870),
    {
      "r": (TInterface, TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "InvokeAsync",
      "d": 847686,
      "h": 17180716870,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(17180716870)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590782278),
    {
      "t": 782150,
      "n": "handler",
      "d": 847686,
      "h": 8590782278,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590782278)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295814982),
    {
      "p": [
        {
          "n": "handler",
          "p": 782150
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 847686,
      "h": 4295814982,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295814982)
  ],
  "h": 847686
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMockImplement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockHandlerImplement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockHandlerImplement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(847686)
        
        

        //--TRIMMABLE-BOUNDARY-START(454470)
        $asm.$cls(`$zHIt.LCFCM.MockAttribute`, ($self) => class MockAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12885356358)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885356358);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885356358)
            
            //--TRIMMABLE-BOUNDARY-START(17180323654)
            $ctor$3(/*params Type[]*/ moreTypes)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180323654);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Types = moreTypes;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180323654)
            
            //--TRIMMABLE-BOUNDARY-START(21475290950)
            /*Type?*/ BaseType = null;
            //--TRIMMABLE-BOUNDARY-END(21475290950)
            
            //--TRIMMABLE-BOUNDARY-START(60129996614)
            /*Type[]?*/ Types = null;
            //--TRIMMABLE-BOUNDARY-END(60129996614)
            
            //--TRIMMABLE-BOUNDARY-START(12885356358)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885356358)
            
            static $h = 454470;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475290950),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065225542,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245094726,
        "f": 83886081
      },
      "n": "BaseType",
      "d": 454470,
      "h": 21475290950,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475290950),
//--TRIMMABLE-BOUNDARY-START(60129996614),
    {
      "p": $.$typeArray($.$$.S.Type).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655160134,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835029318,
        "f": 83886081
      },
      "n": "Types",
      "d": 454470,
      "h": 60129996614,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129996614)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885356358),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 454470,
      "h": 12885356358,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885356358),
//--TRIMMABLE-BOUNDARY-START(17180323654),
    {
      "p": [
        {
          "n": "moreTypes",
          "p": $.$typeArray($.$$.S.Type).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 454470,
      "h": 17180323654,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180323654)
  ],
  "h": 454470,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1024,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(454470)
        
        

        //--TRIMMABLE-BOUNDARY-START(978758)
        $asm.$str(`$zHIt.LCFCM.MockMethodContext`, ($self) => class MockMethodContext extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(68720455494)
            /*MockBase*/ Mock = null;
            //--TRIMMABLE-BOUNDARY-END(68720455494)
            
            //--TRIMMABLE-BOUNDARY-START(25770782534)
            /*Type*/ DeclaringType = null;
            //--TRIMMABLE-BOUNDARY-END(25770782534)
            
            //--TRIMMABLE-BOUNDARY-START(73015422790)
            /*Type*/ ReturnType = null;
            //--TRIMMABLE-BOUNDARY-END(73015422790)
            
            //--TRIMMABLE-BOUNDARY-START(64425488198)
            /*string*/ MethodName = null;
            //--TRIMMABLE-BOUNDARY-END(64425488198)
            
            //--TRIMMABLE-BOUNDARY-START(21475815238)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475815238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475815238)
            
            //--TRIMMABLE-BOUNDARY-START(21475815238)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475815238)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Mock = this.Mock;
                copy.DeclaringType = this.DeclaringType;
                copy.ReturnType = this.ReturnType;
                copy.MethodName = this.MethodName;
                return copy;
            }
            static $h = 978758;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720455494),
    {
      "p": 585542,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540586310,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785226566,
        "f": 83886081
      },
      "n": "Mock",
      "d": 978758,
      "h": 68720455494,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720455494),
//--TRIMMABLE-BOUNDARY-START(25770782534),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360717126,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605357382,
        "f": 83886081
      },
      "n": "DeclaringType",
      "d": 978758,
      "h": 25770782534,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770782534),
//--TRIMMABLE-BOUNDARY-START(73015422790),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130520902,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375161158,
        "f": 83886081
      },
      "n": "ReturnType",
      "d": 978758,
      "h": 73015422790,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015422790),
//--TRIMMABLE-BOUNDARY-START(64425488198),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950651718,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195291974,
        "f": 83886081
      },
      "n": "MethodName",
      "d": 978758,
      "h": 64425488198,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425488198)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475815238),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 978758,
      "h": 21475815238,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475815238)
  ],
  "h": 978758
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockMethodContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockMethodContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(978758)
        
        

        //--TRIMMABLE-BOUNDARY-START(1044294)
        $asm.$str(`$zHIt.LCFCM.MockMethodParameter`, ($self) => class MockMethodParameter extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(30065815366)
            $ctor$4(/*Type?*/ type, /*object?*/ parameter)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065815366);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = null;
                    this.ParameterType = type;
                    /*System.Type?*/ let __ca1__;
                    /*string?*/ let __ca2__;
                    this.Type = ((__ca1__ = type) !== null ? ((__ca2__ = __ca1__.FullName) !== null ? $.$fPer.LCFC.EncryptUtility.QuickHash256$2(__ca2__, null) : null) : null);
                    this.Parameter = parameter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065815366)
            
            //--TRIMMABLE-BOUNDARY-START(25770848070)
            $ctor$3(/*string?*/ name, /*Type?*/ type, /*object?*/ parameter)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770848070);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.ParameterType = type;
                    /*System.Type?*/ let __ca3__;
                    /*string?*/ let __ca4__;
                    this.Type = ((__ca3__ = type) !== null ? ((__ca4__ = __ca3__.FullName) !== null ? $.$fPer.LCFC.EncryptUtility.QuickHash256$2(__ca4__, null) : null) : null);
                    this.Parameter = parameter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770848070)
            
            //--TRIMMABLE-BOUNDARY-START(68720521030)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(68720521030)
            
            //--TRIMMABLE-BOUNDARY-START(120260128582)
            /*string?*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(120260128582)
            
            //--TRIMMABLE-BOUNDARY-START(77310455622)
            /*Type?*/ ParameterType = null;
            //--TRIMMABLE-BOUNDARY-END(77310455622)
            
            //--TRIMMABLE-BOUNDARY-START(73015488326)
            /*object?*/ Parameter = null;
            //--TRIMMABLE-BOUNDARY-END(73015488326)
            
            //--TRIMMABLE-BOUNDARY-START(115965161286)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965161286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Type)} ${$.$strNN(this.Name)} = ${$.$strNN($.$dspc(this.Parameter, $.$$.S.Object, ($t) => $t.ToString))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(115965161286)
            
            //--TRIMMABLE-BOUNDARY-START(21475880774)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475880774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475880774)
            
            //--TRIMMABLE-BOUNDARY-START(21475880774)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475880774)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.Type = this.Type;
                copy.ParameterType = this.ParameterType;
                copy.Parameter = this.Parameter;
                return copy;
            }
            static $h = 1044294;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720521030),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655749958,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900390214,
        "f": 83886081
      },
      "n": "Name",
      "d": 1044294,
      "h": 68720521030,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "n",
              "t": 1310721
            }
          ]
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "n",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720521030),
//--TRIMMABLE-BOUNDARY-START(120260128582),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425553734,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670193990,
        "f": 83886081
      },
      "n": "Type",
      "d": 1044294,
      "h": 120260128582,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "t",
              "t": 1310721
            }
          ]
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "t",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120260128582),
//--TRIMMABLE-BOUNDARY-START(77310455622),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835619142,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080259398,
        "f": 83886081
      },
      "n": "ParameterType",
      "d": 1044294,
      "h": 77310455622,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310455622),
//--TRIMMABLE-BOUNDARY-START(73015488326),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245684550,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490324806,
        "f": 83886081
      },
      "n": "Parameter",
      "d": 1044294,
      "h": 73015488326,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "p",
              "t": 1310721
            }
          ]
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "p",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015488326)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115965161286),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1044294,
      "h": 115965161286,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115965161286)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065815366),
    {
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "parameter",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1044294,
      "h": 30065815366,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065815366),
//--TRIMMABLE-BOUNDARY-START(25770848070),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "parameter",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1044294,
      "h": 25770848070,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770848070),
//--TRIMMABLE-BOUNDARY-START(21475880774),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1044294,
      "h": 21475880774,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475880774)
  ],
  "h": 1044294
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockMethodParameter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockMethodParameter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1044294)
        
        

        //--TRIMMABLE-BOUNDARY-START(323398)
        $asm.$cls(`$zHIt.LCFCM.ITestMock_Mocking`, ($self) => class ITestMock_Mocking extends $.$zHIt.LCFCM.MockBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295290694)
            $ctor$2(/*IMockImplement*/ impl)
            {
                super.$ctor$1(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295290694);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295290694)
            
            //--TRIMMABLE-BOUNDARY-START(17180192582)
            /*int */ get LCFCM$ITestMock$Property()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885225286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$zHIt.LCFCM.ITestMock.$type;
                    $i1.ReturnType = $.$$.S.Int32.$type;
                    $i1.MethodName = "get_Property";
                    return $i1;
                })();
                return this.Invoke($.$zHIt.LCFCM.ITestMock, $.$$.S.Int32, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            /*int */ set LCFCM$ITestMock$Property(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770127174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$zHIt.LCFCM.ITestMock.$type;
                    $i2.ReturnType = $.$$.S.Void.$type;
                    $i2.MethodName = "set_Property";
                    return $i2;
                })();
                this.Invoke$1($.$zHIt.LCFCM.ITestMock, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(value, $.$$.S.Int32)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180192582)
            
            //--TRIMMABLE-BOUNDARY-START(30065094470)
            /*void */ LCFCM$ITestMock$Test1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065094470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$zHIt.LCFCM.ITestMock.$type;
                    $i3.ReturnType = $.$$.S.Void.$type;
                    $i3.MethodName = "Test1";
                    return $i3;
                })();
                this.Invoke$1($.$zHIt.LCFCM.ITestMock, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30065094470)
            
            //--TRIMMABLE-BOUNDARY-START(34360061766)
            /*int */ LCFCM$ITestMock$Test2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360061766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$zHIt.LCFCM.ITestMock.$type;
                    $i4.ReturnType = $.$$.S.Int32.$type;
                    $i4.MethodName = "Test2";
                    return $i4;
                })();
                return this.Invoke($.$zHIt.LCFCM.ITestMock, $.$$.S.Int32, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34360061766)
            
            //--TRIMMABLE-BOUNDARY-START(38655029062)
            /*int */ LCFCM$ITestMock$Test3(/*int*/ a)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655029062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$zHIt.LCFCM.ITestMock.$type;
                    $i5.ReturnType = $.$$.S.Int32.$type;
                    $i5.MethodName = "Test3";
                    return $i5;
                })();
                return this.Invoke($.$zHIt.LCFCM.ITestMock, $.$$.S.Int32, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Int32.$type, $.$box(a, $.$$.S.Int32)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(38655029062)
            
            static $h = 323398;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$zHIt.LCFCM.MockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180192582),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885225286,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25770127174,
        "f": 83886082
      },
      "n": "{257862}.Property",
      "o": "LCFCM$ITestMock$Property",
      "d": 323398,
      "h": 17180192582,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17180192582)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295290694),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 323398,
      "h": 4295290694,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295290694)
  ],
  "h": 323398
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$zHIt.LCFCM.ITestMock ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.ITestMock_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}ITestMock_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(323398)
        
        

        //--TRIMMABLE-BOUNDARY-START(782150)
        $asm.$cls(`$zHIt.LCFCM.MockHandler`, ($self) => class MockHandler extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*object?*/ Invoke(/**/ context, /**/ parameters)
            {
                return this.$nativeFunction.call(this.$target, context, parameters);
            }
            static $h = 782150;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180651334),
    {
      "r": 131073,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "n": "Invoke",
      "d": 782150,
      "h": 17180651334,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180651334),
//--TRIMMABLE-BOUNDARY-START(8590716742),
    {
      "r": 90570753,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 782150,
      "h": 8590716742,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590716742),
//--TRIMMABLE-BOUNDARY-START(12885684038),
    {
      "r": 131073,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 782150,
      "h": 12885684038,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885684038)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295749446),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 782150,
      "h": 4295749446,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295749446)
  ],
  "h": 782150
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(782150)
        
        

        //--TRIMMABLE-BOUNDARY-START(1109830)
        $asm.$cls(`$zHIt.LCFCM.MockServiceFactory`, ($self) => class MockServiceFactory extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*MockBase*/ Invoke(/**/ impl)
            {
                return this.$nativeFunction.call(this.$target, impl);
            }
            static $h = 1109830;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180979014),
    {
      "r": 585542,
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": "Invoke",
      "d": 1109830,
      "h": 17180979014,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180979014),
//--TRIMMABLE-BOUNDARY-START(8591044422),
    {
      "r": 90570753,
      "p": [
        {
          "n": "impl",
          "p": 192326
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1109830,
      "h": 8591044422,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591044422),
//--TRIMMABLE-BOUNDARY-START(12886011718),
    {
      "r": 585542,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 1109830,
      "h": 12886011718,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886011718)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296077126),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1109830,
      "h": 4296077126,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296077126)
  ],
  "h": 1109830
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockServiceFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockServiceFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1109830)
        
        

        //--TRIMMABLE-BOUNDARY-START(520006)
        $asm.$cls(`$zHIt.LCFCM.MockAttribute<>`, (TBase) => $asm.$gt(`$zHIt.LCFCM.MockAttribute<>`, [TBase], ($self) => class MockAttribute$$ extends $.$zHIt.LCFCM.MockAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295487302)
            $ctor$4()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295487302);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295487302)
            
            //--TRIMMABLE-BOUNDARY-START(8590454598)
            $ctor$5(/*params Type[]*/ moreTypes)
            {
                super.$ctor$3(moreTypes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590454598);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590454598)
            
            //--TRIMMABLE-BOUNDARY-START(4295487302)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295487302)
            
            static $H = 520006;
            static $h = 520006;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$zHIt.LCFCM.MockAttribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295487302),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 4295487302,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295487302),
//--TRIMMABLE-BOUNDARY-START(8590454598),
    {
      "p": [
        {
          "n": "moreTypes",
          "p": $.$typeArray($.$$.S.Type).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8590454598,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590454598)
  ],
  "s": [
    {
      "h": TBase?.$h??1572864,
      "n": "TBase"
    }
  ],
  "r": 1,
  "H": 520006,
  "h": this.$h,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1024,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Mocking.MockAttribute<${TBase?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Mocking${separator}MockAttribute$${TBase?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(520006)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(61254)
