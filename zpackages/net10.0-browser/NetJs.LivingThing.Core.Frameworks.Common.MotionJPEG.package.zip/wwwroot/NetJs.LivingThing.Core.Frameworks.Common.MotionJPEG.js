
//--TRIMMABLE-BOUNDARY-START(49149)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer) {
    "use strict";
    let _;
    let $vEWQMe;
    let $MBDXqi;
    let $nJMRbi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.MotionJPEG", 
    {
  "h": 49149,
  "f": "LivingThing.Core.Frameworks.Common.MotionJPEG",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.MotionJPEG",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.MotionJPEG",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(114685)
        $asm.$cls(`$bHuH.LCFCM.IMotionJPEGFrameParser`, ($self) => class IMotionJPEGFrameParser
        {
            static $h = 114685;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295081981),
    {
      "r": $.$$.STT.Task$$($.$bHuH.LCFCM.MotionJPEGFrameInfo).$h,
      "p": [
        {
          "n": "packet",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "ParseJPEGFrame",
      "o": "LCFCM$IMotionJPEGFrameParser$ParseJPEGFrame",
      "d": 114685,
      "h": 4295081981,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295081981)
  ],
  "h": 114685
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGFrameParser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MotionJPEG${separator}IMotionJPEGFrameParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(114685)
        
        

        //--TRIMMABLE-BOUNDARY-START(245757)
        $asm.$cls(`$bHuH.LCFCM.IMotionJPEGHttpClient`, ($self) => class IMotionJPEGHttpClient
        {
            static $h = 245757;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590180349),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770049533,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34359984125,
        "f": 83886337
      },
      "n": "ContentType",
      "o": "LCFCM$IMotionJPEGHttpClient$ContentType",
      "d": 245757,
      "h": 8590180349,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590180349)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295213053),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddHeader",
      "o": "LCFCM$IMotionJPEGHttpClient$AddHeader",
      "d": 245757,
      "h": 4295213053,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295213053),
//--TRIMMABLE-BOUNDARY-START(38654951421),
    {
      "r": 178454529,
      "n": "Start",
      "o": "LCFCM$IMotionJPEGHttpClient$Start",
      "d": 245757,
      "h": 38654951421,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38654951421),
//--TRIMMABLE-BOUNDARY-START(47244886013),
    {
      "r": 178454529,
      "p": [
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "encoding",
          "p": 166723585,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "LCFCM$IMotionJPEGHttpClient$WriteAsync$1",
      "d": 245757,
      "h": 47244886013,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47244886013),
//--TRIMMABLE-BOUNDARY-START(42949918717),
    {
      "r": 178454529,
      "p": [
        {
          "n": "data",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "WriteAsync",
      "o": "LCFCM$IMotionJPEGHttpClient$WriteAsync",
      "d": 245757,
      "h": 42949918717,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42949918717),
//--TRIMMABLE-BOUNDARY-START(17180114941),
    {
      "r": 178454529,
      "n": "FlushAsync",
      "o": "LCFCM$IMotionJPEGHttpClient$FlushAsync",
      "d": 245757,
      "h": 17180114941,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180114941),
//--TRIMMABLE-BOUNDARY-START(12885147645),
    {
      "r": 178454529,
      "n": "EndAsync",
      "o": "LCFCM$IMotionJPEGHttpClient$EndAsync",
      "d": 245757,
      "h": 12885147645,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885147645)
  ],
  "h": 245757
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGHttpClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MotionJPEG${separator}IMotionJPEGHttpClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(245757)
        
        

        //--TRIMMABLE-BOUNDARY-START(180221)
        $asm.$cls(`$bHuH.LCFCM.IMotionJPEGFrameServer`, ($self) => class IMotionJPEGFrameServer
        {
            static $h = 180221;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180049405),
    {
      "p": $.$$.SCG.IEnumerable$$($.$bHuH.LCFCM.IMotionJPEGStream).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590114813,
        "f": 50331905
      },
      "n": "Streams",
      "o": "LCFCM$IMotionJPEGFrameServer$Streams",
      "d": 180221,
      "h": 17180049405,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180049405)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885082109),
    {
      "r": 311293,
      "p": [
        {
          "n": "id",
          "p": 1310721
        },
        {
          "n": "create",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "GetStream",
      "o": "LCFCM$IMotionJPEGFrameServer$GetStream",
      "d": 180221,
      "h": 12885082109,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885082109),
//--TRIMMABLE-BOUNDARY-START(21475016701),
    {
      "r": 65537,
      "p": [
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "parser",
          "p": 114685
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "TryStart",
      "o": "LCFCM$IMotionJPEGFrameServer$TryStart",
      "d": 180221,
      "h": 21475016701,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475016701)
  ],
  "h": 180221
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGFrameServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MotionJPEG${separator}IMotionJPEGFrameServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(180221)
        
        

        //--TRIMMABLE-BOUNDARY-START(638973)
        $asm.$cls(`$bHuH.LCFCM.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590573565)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590573565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$bHuH.LCFCM.IMotionJPEGFrameServer, $.$bHuH.LCFCM.MotionJPEGUDPFrameServer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590573565)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$bHuH.LCFCM.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295606269)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295606269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295606269)
            
            //--TRIMMABLE-BOUNDARY-START(4295606269)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295606269)
            
            static $h = 638973;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590573565),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 638973,
      "h": 8590573565,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590573565)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295606269),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 638973,
      "h": 4295606269,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295606269)
  ],
  "h": 638973
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MotionJPEG.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MotionJPEG${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(638973)
        
        

        //--TRIMMABLE-BOUNDARY-START(573437)
        $asm.$cls(`$bHuH.LCFCM.MotionJPEGUDPFrameServer`, ($self) => class MotionJPEGUDPFrameServer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885475325)
            /*Dictionary<string, MotionJPEGStream>*/ clients = null;
            //--TRIMMABLE-BOUNDARY-END(12885475325)
            
            //--TRIMMABLE-BOUNDARY-START(47245213693)
            /*IEnumerable<IMotionJPEGStream> */ get Streams()
            {
                return $.$$.N.InterfaceVarianceStubHandler.Create(this.clients.Values, $.$$.SCG.IEnumerable$$($.$bHuH.LCFCM.MotionJPEGStream), $.$$.SCG.IEnumerable$$($.$bHuH.LCFCM.IMotionJPEGStream));
            }
            //--TRIMMABLE-BOUNDARY-END(47245213693)
            
            //--TRIMMABLE-BOUNDARY-START(4295540733)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295540733);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295540733)
            
            //--TRIMMABLE-BOUNDARY-START(34360311805)
            /*IMotionJPEGStream? */ GetStream(/*string*/ deviceId, /*bool*/ create)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360311805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.clients.ContainsKey(deviceId))
                {
                    return this.clients.get_Item(deviceId);
                }
                if (create)
                {
                    let $t1;
                    return this.clients.set_Item(deviceId, $t1 = (new $.$bHuH.LCFCM.MotionJPEGStream().$ctor$1(deviceId))), $t1;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34360311805)
            
            //--TRIMMABLE-BOUNDARY-START(42950246397)
            /*List<int>*/ started = null;
            //--TRIMMABLE-BOUNDARY-END(42950246397)
            
            //--TRIMMABLE-BOUNDARY-START(51540180989)
            /*void */ TryStart(/*int*/ port, /*IMotionJPEGFrameParser*/ parser, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540180989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.started.Contains(port))
                {
                    /*UdpClient*/ let udp = new $.$sns.SNS.UdpClient().$ctor$4(new $.$snp.SN.IPEndPoint().$ctor$3($.$snp.SN.IPAddress.Any, port));
                    _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                    {
                        return this.Run(port, udp, parser, token);
                    }, $nJMRbi ??= {"r":178454529,"n":"","d":573437,"h":0,"f":17825794}));
                    this.started.Add(port);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540180989)
            
            //--TRIMMABLE-BOUNDARY-START(8590508029)
            /*Dictionary<string, bool>*/ allowedDevices = null;
            //--TRIMMABLE-BOUNDARY-END(8590508029)
            
            //--TRIMMABLE-BOUNDARY-START(38655279101)
            /*Task *//*async*/  Run(/*int*/ port, /*UdpClient*/ udp, /*IMotionJPEGFrameParser*/ parser, /*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655279101);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    while(!this.disposed)
                    {
                        try
                        {
                            let $t2, $r2;
                            let $t3, $r3;
                            /*var*/ let received = ($t2 = udp.ReceiveAsync().ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            /*var*/ let info = ($t3 = parser.LCFCM$IMotionJPEGFrameParser$ParseJPEGFrame(received.Buffer).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                            if (info.Id !== null)
                            {
                                if (!this.clients.ContainsKey(info.Id))
                                {
                                    this.clients.set_Item(info.Id, new $.$bHuH.LCFCM.MotionJPEGStream().$ctor$1(info.Id));
                                }
                                this.clients.get_Item(info.Id).Receive(info.Frame);
                            }
                        }
                        catch($e)
                        {
                            if ($e instanceof $.$$.S.OperationCanceledException)
                            {
                            }
                            else if ($e instanceof $.$$.S.Exception)
                            {
                            }
                            else
                            {
                                throw $e;
                            }
                        }
                    }
                    udp.Close();
                    udp.Dispose();
                    this.started.Remove(port);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655279101)
            
            //--TRIMMABLE-BOUNDARY-START(21475409917)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(21475409917)
            
            //--TRIMMABLE-BOUNDARY-START(17180442621)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180442621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.disposed = true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180442621)
            
            //--TRIMMABLE-BOUNDARY-START(8590114813)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGFrameServer.Streams.get
            get LCFCM$IMotionJPEGFrameServer$Streams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180049405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Streams;
            }
            //--TRIMMABLE-BOUNDARY-END(8590114813)
            
            //--TRIMMABLE-BOUNDARY-START(12885082109)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGFrameServer.GetStream(string, bool)
            LCFCM$IMotionJPEGFrameServer$GetStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885082109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStream(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885082109)
            
            //--TRIMMABLE-BOUNDARY-START(21475016701)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGFrameServer.TryStart(int, LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGFrameParser, System.Threading.CancellationToken)
            LCFCM$IMotionJPEGFrameServer$TryStart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475016701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryStart(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475016701)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(4295540733)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295540733)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885475325)
                this.clients = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$bHuH.LCFCM.MotionJPEGStream))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12885475325)
                
                //--TRIMMABLE-BOUNDARY-START(42950246397)
                this.started = new ($.$$.SCG.List$$($.$$.S.Int32))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(42950246397)
                
                //--TRIMMABLE-BOUNDARY-START(8590508029)
                this.allowedDevices = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Boolean))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590508029)
                
            }
            static $h = 573437;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245213693),
    {
      "p": $.$$.SCG.IEnumerable$$($.$bHuH.LCFCM.IMotionJPEGStream).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065344509,
        "f": 50331649
      },
      "n": "Streams",
      "d": 573437,
      "h": 47245213693,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245213693)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360311805),
    {
      "r": 311293,
      "p": [
        {
          "n": "deviceId",
          "p": 1310721
        },
        {
          "n": "create",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "GetStream",
      "d": 573437,
      "h": 34360311805,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360311805),
//--TRIMMABLE-BOUNDARY-START(51540180989),
    {
      "r": 65537,
      "p": [
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "parser",
          "p": 114685
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "TryStart",
      "d": 573437,
      "h": 51540180989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540180989),
//--TRIMMABLE-BOUNDARY-START(38655279101),
    {
      "r": 178454529,
      "p": [
        {
          "n": "port",
          "p": 655361
        },
        {
          "n": "udp",
          "p": 1900592
        },
        {
          "n": "parser",
          "p": 114685
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "Run",
      "d": 573437,
      "h": 38655279101,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(38655279101),
//--TRIMMABLE-BOUNDARY-START(17180442621),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 573437,
      "h": 17180442621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180442621)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885475325),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$bHuH.LCFCM.MotionJPEGStream).$h,
      "n": "clients",
      "d": 573437,
      "h": 12885475325,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885475325),
//--TRIMMABLE-BOUNDARY-START(42950246397),
    {
      "t": $.$$.SCG.List$$($.$$.S.Int32).$h,
      "n": "started",
      "d": 573437,
      "h": 42950246397,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950246397),
//--TRIMMABLE-BOUNDARY-START(8590508029),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Boolean).$h,
      "n": "allowedDevices",
      "d": 573437,
      "h": 8590508029,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590508029),
//--TRIMMABLE-BOUNDARY-START(21475409917),
    {
      "t": 262145,
      "n": "disposed",
      "d": 573437,
      "h": 21475409917,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475409917)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295540733),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 573437,
      "h": 4295540733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295540733)
  ],
  "h": 573437
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bHuH.LCFCM.IMotionJPEGFrameServer, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MotionJPEG.MotionJPEGUDPFrameServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MotionJPEG${separator}MotionJPEGUDPFrameServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(573437)
        
        

        //--TRIMMABLE-BOUNDARY-START(376829)
        $asm.$str(`$bHuH.LCFCM.MotionJPEGFrameInfo`, ($self) => class MotionJPEGFrameInfo extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38655082493)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(38655082493)
            
            //--TRIMMABLE-BOUNDARY-START(17180246013)
            /*ReadOnlyMemory<byte>*/ Frame;
            //--TRIMMABLE-BOUNDARY-END(17180246013)
            
            //--TRIMMABLE-BOUNDARY-START(12885278717)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885278717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885278717)
            
            //--TRIMMABLE-BOUNDARY-START(12885278717)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885278717)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Id = this.Id;
                copy.Frame = this.Frame.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180246013)
                this.Frame = $.$default($.$$.S.ReadOnlyMemory$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(17180246013)
                
            }
            static $h = 376829;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655082493),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360115197,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834951677,
        "f": 83886081
      },
      "n": "Id",
      "d": 376829,
      "h": 38655082493,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655082493),
//--TRIMMABLE-BOUNDARY-START(17180246013),
    {
      "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770180605,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245017085,
        "f": 83886081
      },
      "n": "Frame",
      "d": 376829,
      "h": 17180246013,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180246013)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885278717),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 376829,
      "h": 12885278717,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885278717)
  ],
  "h": 376829
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MotionJPEG.MotionJPEGFrameInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MotionJPEG${separator}MotionJPEGFrameInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(376829)
        
        

        //--TRIMMABLE-BOUNDARY-START(311293)
        $asm.$cls(`$bHuH.LCFCM.IMotionJPEGStream`, ($self) => class IMotionJPEGStream
        {
            static $h = 311293;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475147773),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590245885,
        "f": 50331905
      },
      "n": "Id",
      "o": "LCFCM$IMotionJPEGStream$Id",
      "d": 311293,
      "h": 21475147773,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475147773),
//--TRIMMABLE-BOUNDARY-START(25770115069),
    {
      "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180180477,
        "f": 50331905
      },
      "n": "LastFrame",
      "o": "LCFCM$IMotionJPEGStream$LastFrame",
      "d": 311293,
      "h": 25770115069,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770115069)
  ],
  "h": 311293
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IObservable$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MotionJPEG${separator}IMotionJPEGStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(311293)
        
        

        //--TRIMMABLE-BOUNDARY-START(442365)
        $asm.$cls(`$bHuH.LCFCM.MotionJPEGHttpStream`, ($self) => class MotionJPEGHttpStream extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60129984509)
            /*string*/ static PART_BOUNDARY = null;
            //--TRIMMABLE-BOUNDARY-END(60129984509)
            
            //--TRIMMABLE-BOUNDARY-START(8590376957)
            /*string*/ static _STREAM_CONTENT_TYPE = null;
            //--TRIMMABLE-BOUNDARY-END(8590376957)
            
            //--TRIMMABLE-BOUNDARY-START(4295409661)
            /*string*/ static _STREAM_BOUNDARY = null;
            //--TRIMMABLE-BOUNDARY-END(4295409661)
            
            //--TRIMMABLE-BOUNDARY-START(12885344253)
            /*string*/ static _STREAM_PART = null;
            //--TRIMMABLE-BOUNDARY-END(12885344253)
            
            //--TRIMMABLE-BOUNDARY-START(42950115325)
            /*IMotionJPEGHttpClient*/ http = null;
            //--TRIMMABLE-BOUNDARY-END(42950115325)
            
            //--TRIMMABLE-BOUNDARY-START(77309853693)
            /*bool*/ video = false;
            //--TRIMMABLE-BOUNDARY-END(77309853693)
            
            //--TRIMMABLE-BOUNDARY-START(30065213437)
            /*IDisposable*/ dispose = null;
            //--TRIMMABLE-BOUNDARY-END(30065213437)
            
            //--TRIMMABLE-BOUNDARY-START(64424951805)
            /*TaskCompletionSource<object>*/ task = null;
            //--TRIMMABLE-BOUNDARY-END(64424951805)
            
            //--TRIMMABLE-BOUNDARY-START(68719919101)
            /*Task */ get Task()
            {
                return this.task.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(68719919101)
            
            //--TRIMMABLE-BOUNDARY-START(73014886397)
            /*bool*/ useChunkedEncoding = false;
            //--TRIMMABLE-BOUNDARY-END(73014886397)
            
            //--TRIMMABLE-BOUNDARY-START(17180311549)
            $ctor$1(/*IMotionJPEGStream*/ client, /*IMotionJPEGHttpClient*/ http, /*bool*/ video)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180311549);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!video)
                    {
                        http.LCFCM$IMotionJPEGHttpClient$ContentType = "image/jpeg";
                    }
                    else 
                    {
                        http.LCFCM$IMotionJPEGHttpClient$ContentType = "multipart/x-mixed-replace;boundary=0123456789ABCDEF"/*_STREAM_CONTENT_TYPE*/;
                    }
                    if (this.useChunkedEncoding)
                    {
                        http.LCFCM$IMotionJPEGHttpClient$AddHeader("Transfer-Encoding", "chunked");
                    }
                    http.LCFCM$IMotionJPEGHttpClient$AddHeader("Access-Control-Allow-Origin", "*");
                    http.LCFCM$IMotionJPEGHttpClient$Start();
                    this.http = http;
                    this.video = video;
                    this.dispose = client[`S$IObservable$System$ReadOnlyMemory$System$Byte$$Subscribe`](this);
                    if (client.LCFCM$IMotionJPEGStream$LastFrame.Length > 0)
                    {
                        this.OnNext(client.LCFCM$IMotionJPEGStream$LastFrame);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180311549)
            
            //--TRIMMABLE-BOUNDARY-START(47245082621)
            /*void */ OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245082621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47245082621)
            
            //--TRIMMABLE-BOUNDARY-START(51540049917)
            /*void */ OnError(/*Exception*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540049917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51540049917)
            
            //--TRIMMABLE-BOUNDARY-START(85899788285)
            /*Task *//*async*/  WriteChunk$1(/*string*/ chunk)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899788285);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.http.LCFCM$IMotionJPEGHttpClient$WriteAsync$1((() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendFormatted($.$box(chunk.length, $.$$.S.Int32), null, "X");
                        $handler.AppendLiteral("\r\n");
                        return $handler.ToStringAndClear                ();
                    })(), $.$$.ST.Encoding.ASCII).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    ($t2 = this.http.LCFCM$IMotionJPEGHttpClient$WriteAsync$1(chunk, $.$$.ST.Encoding.ASCII).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    ($t3 = this.http.LCFCM$IMotionJPEGHttpClient$WriteAsync$1("\r\n", $.$$.ST.Encoding.ASCII).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899788285)
            
            //--TRIMMABLE-BOUNDARY-START(81604820989)
            /*Task *//*async*/  WriteChunk(/*ReadOnlyMemory<byte>*/ chunk)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604820989);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t4 = this.http.LCFCM$IMotionJPEGHttpClient$WriteAsync$1((() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendFormatted($.$box(chunk.Length, $.$$.S.Int32), null, "X");
                        $handler.AppendLiteral("\r\n");
                        return $handler.ToStringAndClear                ();
                    })(), $.$$.ST.Encoding.ASCII).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    ($t5 = this.http.LCFCM$IMotionJPEGHttpClient$WriteAsync(chunk).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    ($t6 = this.http.LCFCM$IMotionJPEGHttpClient$WriteAsync$1("\r\n", $.$$.ST.Encoding.ASCII).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(81604820989)
            
            //--TRIMMABLE-BOUNDARY-START(25770246141)
            /*void */ CloseStream(/*Exception*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770246141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.task.Task.IsCompleted)
                {
                    if (e !== null)
                    {
                        this.task.SetException$1(e);
                    }
                    else 
                    {
                        this.task.SetResult(null);
                    }
                }
                this.dispose.S$IDisposable$Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(25770246141)
            
            //--TRIMMABLE-BOUNDARY-START(21475278845)
            /*bool*/ busy = false;
            //--TRIMMABLE-BOUNDARY-END(21475278845)
            
            //--TRIMMABLE-BOUNDARY-START(55835017213)
            /*void *//*async*/  OnNext(/*ReadOnlyMemory<byte>*/ value)
            {
                return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835017213);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.busy)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    try
                    {
                        this.busy = true;
                        if (this.video)
                        {
                            let $t13, $r13;
                            /*var*/ let streamPart = $.$$.S.String.Format$9("Content-Type: image/jpeg\r\nContent-Length: {0}\r\n\r\n"/*_STREAM_PART*/, $.$box(value.Length, $.$$.S.Int32));
                            if (this.useChunkedEncoding)
                            {
                                let $t7, $r7;
                                let $t8, $r8;
                                let $t9, $r9;
                                ($t7 = this.WriteChunk$1("\r\n--0123456789ABCDEF\r\n"/*_STREAM_BOUNDARY*/).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                ($t8 = this.WriteChunk$1(streamPart).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                ($t9 = this.WriteChunk(value).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                            }
                            else 
                            {
                                let $t10, $r10;
                                let $t11, $r11;
                                let $t12, $r12;
                                ($t10 = this.http.LCFCM$IMotionJPEGHttpClient$WriteAsync$1("\r\n--0123456789ABCDEF\r\n"/*_STREAM_BOUNDARY*/, null).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                                ($t11 = this.http.LCFCM$IMotionJPEGHttpClient$WriteAsync$1(streamPart, null).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                                ($t12 = this.http.LCFCM$IMotionJPEGHttpClient$WriteAsync(value).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                            }
                            ($t13 = this.http.LCFCM$IMotionJPEGHttpClient$FlushAsync().ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                        }
                        else 
                        {
                            let $t14, $r14;
                            let $t15, $r15;
                            ($t14 = this.http.LCFCM$IMotionJPEGHttpClient$WriteAsync(value).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                            ($t15 = this.http.LCFCM$IMotionJPEGHttpClient$EndAsync().ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                        }
                        if (!this.video)
                        {
                            this.CloseStream(null);
                        }
                    }
                    catch(e)
                    {
                        this.CloseStream(e);
                    }
                    finally
                    {
                        {
                            this.busy = false;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55835017213)
            
            //--TRIMMABLE-BOUNDARY-START(12982091777)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnNext(System.ReadOnlyMemory<byte>)
            S$IObserver$$$OnNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12982091777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnNext(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12982091777)
            
            //--TRIMMABLE-BOUNDARY-START(8687124481)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnError(System.Exception)
            S$IObserver$$$OnError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8687124481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnError(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8687124481)
            
            //--TRIMMABLE-BOUNDARY-START(4392157185)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnCompleted()
            S$IObserver$$$OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392157185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnCompleted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392157185)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64424951805)
                this.task = new ($.$$.STT.TaskCompletionSource$$($.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(64424951805)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(60129984509)
                    this.PART_BOUNDARY = "0123456789ABCDEF";
                    //--TRIMMABLE-BOUNDARY-END(60129984509)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590376957)
                    this._STREAM_CONTENT_TYPE = "multipart/x-mixed-replace;boundary=0123456789ABCDEF";
                    //--TRIMMABLE-BOUNDARY-END(8590376957)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295409661)
                    this._STREAM_BOUNDARY = "\r\n--0123456789ABCDEF\r\n";
                    //--TRIMMABLE-BOUNDARY-END(4295409661)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885344253)
                    this._STREAM_PART = "Content-Type: image/jpeg\r\nContent-Length: {0}\r\n\r\n";
                    //--TRIMMABLE-BOUNDARY-END(12885344253)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 442365;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719919101),
    {
      "p": 178454529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655148029,
        "f": 50331649
      },
      "n": "Task",
      "d": 442365,
      "h": 68719919101,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719919101)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245082621),
    {
      "r": 65537,
      "n": "OnCompleted",
      "d": 442365,
      "h": 47245082621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245082621),
//--TRIMMABLE-BOUNDARY-START(51540049917),
    {
      "r": 65537,
      "p": [
        {
          "n": "error",
          "p": 80805889
        }
      ],
      "n": "OnError",
      "d": 442365,
      "h": 51540049917,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540049917),
//--TRIMMABLE-BOUNDARY-START(85899788285),
    {
      "r": 178454529,
      "p": [
        {
          "n": "chunk",
          "p": 1310721
        }
      ],
      "n": "WriteChunk",
      "o": "@$1",
      "d": 442365,
      "h": 85899788285,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(85899788285),
//--TRIMMABLE-BOUNDARY-START(81604820989),
    {
      "r": 178454529,
      "p": [
        {
          "n": "chunk",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "WriteChunk",
      "d": 442365,
      "h": 81604820989,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(81604820989),
//--TRIMMABLE-BOUNDARY-START(25770246141),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "CloseStream",
      "d": 442365,
      "h": 25770246141,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770246141),
//--TRIMMABLE-BOUNDARY-START(55835017213),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "OnNext",
      "d": 442365,
      "h": 55835017213,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(55835017213)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60129984509),
    {
      "t": 1310721,
      "n": "PART_BOUNDARY",
      "d": 442365,
      "h": 60129984509,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60129984509),
//--TRIMMABLE-BOUNDARY-START(8590376957),
    {
      "t": 1310721,
      "n": "_STREAM_CONTENT_TYPE",
      "d": 442365,
      "h": 8590376957,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590376957),
//--TRIMMABLE-BOUNDARY-START(4295409661),
    {
      "t": 1310721,
      "n": "_STREAM_BOUNDARY",
      "d": 442365,
      "h": 4295409661,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295409661),
//--TRIMMABLE-BOUNDARY-START(12885344253),
    {
      "t": 1310721,
      "n": "_STREAM_PART",
      "d": 442365,
      "h": 12885344253,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885344253),
//--TRIMMABLE-BOUNDARY-START(42950115325),
    {
      "t": 245757,
      "n": "http",
      "d": 442365,
      "h": 42950115325,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950115325),
//--TRIMMABLE-BOUNDARY-START(77309853693),
    {
      "t": 262145,
      "n": "video",
      "d": 442365,
      "h": 77309853693,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77309853693),
//--TRIMMABLE-BOUNDARY-START(30065213437),
    {
      "t": 91095041,
      "n": "dispose",
      "d": 442365,
      "h": 30065213437,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065213437),
//--TRIMMABLE-BOUNDARY-START(64424951805),
    {
      "t": $.$$.STT.TaskCompletionSource$$($.$$.S.Object).$h,
      "n": "task",
      "d": 442365,
      "h": 64424951805,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64424951805),
//--TRIMMABLE-BOUNDARY-START(73014886397),
    {
      "t": 262145,
      "n": "useChunkedEncoding",
      "d": 442365,
      "h": 73014886397,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73014886397),
//--TRIMMABLE-BOUNDARY-START(21475278845),
    {
      "t": 262145,
      "n": "busy",
      "d": 442365,
      "h": 21475278845,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475278845)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180311549),
    {
      "p": [
        {
          "n": "client",
          "p": 311293
        },
        {
          "n": "http",
          "p": 245757
        },
        {
          "n": "video",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 442365,
      "h": 17180311549,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180311549)
  ],
  "h": 442365
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IObserver$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MotionJPEG.MotionJPEGHttpStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MotionJPEG${separator}MotionJPEGHttpStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(442365)
        
        

        //--TRIMMABLE-BOUNDARY-START(507901)
        $asm.$cls(`$bHuH.LCFCM.MotionJPEGStream`, ($self) => class MotionJPEGStream extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885409789)
            $ctor$1(/*string*/ id)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885409789);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Id = id;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885409789)
            
            //--TRIMMABLE-BOUNDARY-START(34360246269)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(34360246269)
            
            //--TRIMMABLE-BOUNDARY-START(38655213565)
            /*ReadOnlyMemory<byte>*/ LastFrame;
            //--TRIMMABLE-BOUNDARY-END(38655213565)
            
            //--TRIMMABLE-BOUNDARY-START(42950180861)
            /*List<IObserver<ReadOnlyMemory<byte>>>*/ observers = null;
            //--TRIMMABLE-BOUNDARY-END(42950180861)
            
            //--TRIMMABLE-BOUNDARY-START(60130050045)
            /*IDisposable */ Subscribe(/*IObserver<ReadOnlyMemory<byte>>*/ observer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130050045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        this.observers.Add(observer);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
                return new $.$fPer.LCFC.DisposableDelegate().$ctor$3(new $.$$.S.Action().$ctor(this,  () =>
                {
                    //lock(this)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this)
                        {
                            this.observers.Remove(observer);
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this)
                    }
                }, $vEWQMe ??= {"r":65537,"n":"","d":507901,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(60130050045)
            
            //--TRIMMABLE-BOUNDARY-START(47245148157)
            /*void */ Receive(/*ReadOnlyMemory<byte>*/ jpeg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245148157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.LastFrame = jpeg;
                $.$sl.SL.Enumerable.ToList($.$$.S.IObserver$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte)), this.observers).ForEach(new ($.$$.S.Action$$($.$$.S.IObserver$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))))().$ctor(this,  (/*ob*/ ob) =>
                {
                    return ob.S$IObserver$$$OnNext(jpeg);
                }, $MBDXqi ??= {"r":65537,"p":[{"n":"ob","p":$.$$.S.IObserver$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte)).$h}],"n":"","d":507901,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(47245148157)
            
            //--TRIMMABLE-BOUNDARY-START(8590245885)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGStream.Id.get
            get LCFCM$IMotionJPEGStream$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475147773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(8590245885)
            
            //--TRIMMABLE-BOUNDARY-START(17180180477)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGStream.LastFrame.get
            get LCFCM$IMotionJPEGStream$LastFrame()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770115069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastFrame;
            }
            //--TRIMMABLE-BOUNDARY-END(17180180477)
            
            //--TRIMMABLE-BOUNDARY-START(4392091649)
            //Generated interface implemetation for System.IObservable<System.ReadOnlyMemory<byte>>.Subscribe(System.IObserver<System.ReadOnlyMemory<byte>>)
            [`S$IObservable$System$ReadOnlyMemory$System$Byte$$Subscribe`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392091649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Subscribe(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392091649)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38655213565)
                this.LastFrame = $.$default($.$$.S.ReadOnlyMemory$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(38655213565)
                
                //--TRIMMABLE-BOUNDARY-START(42950180861)
                this.observers = new ($.$$.SCG.List$$($.$$.S.IObserver$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(42950180861)
                
            }
            static $h = 507901;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360246269),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475344381,
        "f": 50331649
      },
      "n": "Id",
      "d": 507901,
      "h": 34360246269,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360246269),
//--TRIMMABLE-BOUNDARY-START(38655213565),
    {
      "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065278973,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835082749,
        "f": 83886082
      },
      "n": "LastFrame",
      "d": 507901,
      "h": 38655213565,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655213565)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130050045),
    {
      "r": 91095041,
      "p": [
        {
          "n": "observer",
          "p": $.$$.S.IObserver$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte)).$h
        }
      ],
      "n": "Subscribe",
      "d": 507901,
      "h": 60130050045,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130050045),
//--TRIMMABLE-BOUNDARY-START(47245148157),
    {
      "r": 65537,
      "p": [
        {
          "n": "jpeg",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "Receive",
      "d": 507901,
      "h": 47245148157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245148157)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950180861),
    {
      "t": $.$$.SCG.List$$($.$$.S.IObserver$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))).$h,
      "n": "observers",
      "d": 507901,
      "h": 42950180861,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950180861)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885409789),
    {
      "p": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 507901,
      "h": 12885409789,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885409789)
  ],
  "h": 507901
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bHuH.LCFCM.IMotionJPEGStream, $.$$.S.IObservable$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.MotionJPEG.MotionJPEGStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}MotionJPEG${separator}MotionJPEGStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(507901)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(49149)
