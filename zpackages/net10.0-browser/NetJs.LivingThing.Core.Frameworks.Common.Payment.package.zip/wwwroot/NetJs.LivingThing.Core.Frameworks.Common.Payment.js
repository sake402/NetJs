
//--TRIMMABLE-BOUNDARY-START(18200)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt, $uvJL) {
    "use strict";
    let _;
    let $kJtSFk;
    let $LqUWqj;
    let $FeTqtf;
    let $kztFtg;
    let $aUlPml;
    let $IwrRVj;
    let $UJmljl;
    let $irERke;
    let $luClrj;
    let $ZXsfRc;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Payment", 
    {
  "h": 18200,
  "f": "LivingThing.Core.Frameworks.Common.Payment",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Payment",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Payment",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(345880)
        $asm.$cls(`$nYKj.LCFCP.IBankingPaymentHandler`, ($self) => class IBankingPaymentHandler
        {
            static $h = 345880;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590280472),
    {
      "r": 262145,
      "p": [
        {
          "n": "paymentReference",
          "p": 1310721
        }
      ],
      "n": "TryIdentifyPaymentReference",
      "o": "LCFCP$IBankingPaymentHandler$TryIdentifyPaymentReference",
      "d": 345880,
      "h": 8590280472,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590280472),
//--TRIMMABLE-BOUNDARY-START(4295313176),
    {
      "r": 178454529,
      "p": [
        {
          "n": "payment",
          "p": 83736
        }
      ],
      "n": "HandlePayment",
      "o": "LCFCP$IBankingPaymentHandler$HandlePayment",
      "d": 345880,
      "h": 4295313176,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295313176)
  ],
  "h": 345880
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IBankingPaymentHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IBankingPaymentHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(345880)
        
        

        //--TRIMMABLE-BOUNDARY-START(1197848)
        $asm.$cls(`$nYKj.LCFCP.IPaymentTierSplitPaymentProvider`, ($self) => class IPaymentTierSplitPaymentProvider
        {
            static $h = 1197848;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886099736),
    {
      "p": $.$$.SCG.Dictionary$$$($.$fPer.LCFCC$2.IContact, $.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591132440,
        "f": 50331905
      },
      "n": "PayeeSplit",
      "o": "LCFCP$IPaymentTierSplitPaymentProvider$PayeeSplit",
      "d": 1197848,
      "h": 12886099736,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886099736)
  ],
  "h": 1197848
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IPaymentTierSplitPaymentProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IPaymentTierSplitPaymentProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1197848)
        
        

        //--TRIMMABLE-BOUNDARY-START(935704)
        $asm.$cls(`$nYKj.LCFCP.IPaymentTierInfoProvider`, ($self) => class IPaymentTierInfoProvider
        {
            static $h = 935704;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295903000),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)).$h,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "serviceUserInformation",
          "p": 131073
        },
        {
          "n": "tierUserInformation",
          "p": 131073
        }
      ],
      "n": "GetInfo",
      "o": "LCFCP$IPaymentTierInfoProvider$GetInfo",
      "d": 935704,
      "h": 4295903000,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295903000)
  ],
  "h": 935704
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IPaymentTierInfoProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IPaymentTierInfoProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(935704)
        
        

        //--TRIMMABLE-BOUNDARY-START(870168)
        $asm.$cls(`$nYKj.LCFCP.IPaymentTierCostProvider`, ($self) => class IPaymentTierCostProvider
        {
            static $h = 870168;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295837464),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.ValueRange$$($.$fPer.LCFCDM.Money)).$h,
      "p": [
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "tierUserInfomation",
          "p": 131073
        },
        {
          "n": "serviceUserInfomation",
          "p": 131073
        }
      ],
      "n": "GetCost",
      "o": "LCFCP$IPaymentTierCostProvider$GetCost",
      "d": 870168,
      "h": 4295837464,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295837464)
  ],
  "h": 870168
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IPaymentTierCostProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IPaymentTierCostProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(870168)
        
        

        //--TRIMMABLE-BOUNDARY-START(1132312)
        $asm.$cls(`$nYKj.LCFCP.IPaymentTierProviderFactory`, ($self) => class IPaymentTierProviderFactory
        {
            static $h = 1132312;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296099608),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$nYKj.LCFCP.IPaymentTierProvider)).$h,
      "n": "GetProviders",
      "o": "LCFCP$IPaymentTierProviderFactory$GetProviders",
      "d": 1132312,
      "h": 4296099608,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296099608)
  ],
  "h": 1132312
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProviderFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IPaymentTierProviderFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1132312)
        
        

        //--TRIMMABLE-BOUNDARY-START(673560)
        $asm.$cls(`$nYKj.LCFCP.IPaymentCashbackProvider`, ($self) => class IPaymentCashbackProvider
        {
            static $h = 673560;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295640856),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCDM.Money).$h,
      "p": [
        {
          "n": "amount",
          "p": 27822422
        },
        {
          "n": "tier",
          "p": 739096
        },
        {
          "n": "tierUserInfomation",
          "p": 131073
        },
        {
          "n": "serviceUserInfomation",
          "p": 131073
        }
      ],
      "n": "GetCashback",
      "o": "LCFCP$IPaymentCashbackProvider$GetCashback",
      "d": 673560,
      "h": 4295640856,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295640856)
  ],
  "h": 673560
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IPaymentCashbackProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IPaymentCashbackProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(673560)
        
        

        //--TRIMMABLE-BOUNDARY-START(542488)
        $asm.$cls(`$nYKj.LCFCP.ICorePaymentProcessor`, ($self) => class ICorePaymentProcessor
        {
            static $h = 542488;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295509784),
    {
      "r": 608024,
      "p": [
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": "Open",
      "o": "LCFCP$ICorePaymentProcessor$Open",
      "d": 542488,
      "h": 4295509784,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295509784)
  ],
  "h": 542488
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.ICorePaymentProcessor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}ICorePaymentProcessor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(542488)
        
        

        //--TRIMMABLE-BOUNDARY-START(411416)
        $asm.$cls(`$nYKj.LCFCP.IBankingRemoteService`, ($self) => class IBankingRemoteService
        {
            static $h = 411416;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295378712),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "amount",
          "p": $.$typeNullable($.$$.S.Double).$h
        }
      ],
      "n": "BeginReceiveFund",
      "o": "LCFCP$IBankingRemoteService$BeginReceiveFund",
      "d": 411416,
      "h": 4295378712,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295378712),
//--TRIMMABLE-BOUNDARY-START(8590346008),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$fPer.LCFCD.Bank)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetBanks",
      "o": "LCFCP$IBankingRemoteService$GetBanks",
      "d": 411416,
      "h": 8590346008,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590346008),
//--TRIMMABLE-BOUNDARY-START(12885313304),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount)).$h,
      "p": [
        {
          "n": "bank",
          "p": 5409110
        },
        {
          "n": "accountNumber",
          "p": 1310721
        }
      ],
      "n": "ResolveAccount",
      "o": "LCFCP$IBankingRemoteService$ResolveAccount",
      "d": 411416,
      "h": 12885313304,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885313304),
//--TRIMMABLE-BOUNDARY-START(17180280600),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult)).$h,
      "p": [
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "account",
          "p": 5474646
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        }
      ],
      "n": "TransferTo",
      "o": "LCFCP$IBankingRemoteService$TransferTo",
      "d": 411416,
      "h": 17180280600,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180280600)
  ],
  "h": 411416,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IBankingRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IBankingRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(411416)
        
        

        //--TRIMMABLE-BOUNDARY-START(608024)
        $asm.$cls(`$nYKj.LCFCP.ICorePaymentTransaction`, ($self) => class ICorePaymentTransaction
        {
            static $h = 608024;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245248280),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360346392,
        "f": 50331905
      },
      "n": "Id",
      "o": "LCFCP$ICorePaymentTransaction$Id",
      "d": 608024,
      "h": 47245248280,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47245248280),
//--TRIMMABLE-BOUNDARY-START(17180477208),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770411800,
        "f": 50331905
      },
      "n": "Description",
      "o": "LCFCP$ICorePaymentTransaction$Description",
      "d": 608024,
      "h": 17180477208,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180477208),
//--TRIMMABLE-BOUNDARY-START(51540215576),
    {
      "p": 542488,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950280984,
        "f": 50331905
      },
      "n": "Processor",
      "o": "LCFCP$ICorePaymentTransaction$Processor",
      "d": 608024,
      "h": 51540215576,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51540215576)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590542616),
    {
      "r": 65537,
      "p": [
        {
          "n": "accountId",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 1310721
        },
        {
          "n": "amount",
          "p": 27822422
        },
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": "Deduct",
      "o": "LCFCP$ICorePaymentTransaction$Deduct",
      "d": 608024,
      "h": 8590542616,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590542616),
//--TRIMMABLE-BOUNDARY-START(12885509912),
    {
      "r": 27822422,
      "p": [
        {
          "n": "accountId",
          "p": 1310721
        }
      ],
      "n": "DepositTo",
      "o": "LCFCP$ICorePaymentTransaction$DepositTo",
      "d": 608024,
      "h": 12885509912,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885509912),
//--TRIMMABLE-BOUNDARY-START(4295575320),
    {
      "r": 178454529,
      "n": "Commit",
      "o": "LCFCP$ICorePaymentTransaction$Commit",
      "d": 608024,
      "h": 4295575320,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295575320)
  ],
  "h": 608024
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.ICorePaymentTransaction`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}ICorePaymentTransaction`; }
        });
        //--TRIMMABLE-BOUNDARY-END(608024)
        
        

        //--TRIMMABLE-BOUNDARY-START(1001240)
        $asm.$cls(`$nYKj.LCFCP.IPaymentTierProvider`, ($self) => class IPaymentTierProvider
        {
            //--TRIMMABLE-BOUNDARY-START(55835576088)
            /*string */ get LCFCP$IPaymentTierProvider$Id()
            {
                return $.$$.S.Object.GetType.call(this).FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(55835576088)
            
            //--TRIMMABLE-BOUNDARY-START(4295968536)
            /*Enum? */ get LCFCP$IPaymentTierProvider$Category()
            {
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(4295968536)
            
            //--TRIMMABLE-BOUNDARY-START(68720477976)
            /*Type? */ get LCFCP$IPaymentTierProvider$UserInformation()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(68720477976)
            
            //--TRIMMABLE-BOUNDARY-START(60130543384)
            /*string? */ get LCFCP$IPaymentTierProvider$ServiceTierName()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(60130543384)
            
            //--TRIMMABLE-BOUNDARY-START(73015445272)
            /*Task */ LCFCP$IPaymentTierProvider$Validate(/*PaymentTierReceiptContext*/ receipt)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015445272);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.Task.FromResult($.$fPer.LCFC.IPaymentOrderTransactionModel, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015445272)
            
            //--TRIMMABLE-BOUNDARY-START(8590935832)
            /*Task<IPaymentOrderTransactionModel?> */ LCFCP$IPaymentTierProvider$Execute(/*PaymentTierReceiptContext*/ receipt)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590935832);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.Task.FromResult($.$fPer.LCFC.IPaymentOrderTransactionModel, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590935832)
            
            static $h = 1001240;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835576088),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770805016,
        "f": 50331777
      },
      "n": "Id",
      "o": "LCFCP$IPaymentTierProvider$Id",
      "d": 1001240,
      "h": 55835576088,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(55835576088),
//--TRIMMABLE-BOUNDARY-START(4295968536),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180870424,
        "f": 50331777
      },
      "n": "Category",
      "o": "LCFCP$IPaymentTierProvider$Category",
      "d": 1001240,
      "h": 4295968536,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(4295968536),
//--TRIMMABLE-BOUNDARY-START(68720477976),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540608792,
        "f": 50331777
      },
      "n": "UserInformation",
      "o": "LCFCP$IPaymentTierProvider$UserInformation",
      "d": 1001240,
      "h": 68720477976,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(68720477976),
//--TRIMMABLE-BOUNDARY-START(60130543384),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360739608,
        "f": 50331777
      },
      "n": "ServiceTierName",
      "o": "LCFCP$IPaymentTierProvider$ServiceTierName",
      "d": 1001240,
      "h": 60130543384,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60130543384),
//--TRIMMABLE-BOUNDARY-START(64425510680),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950674200,
        "f": 50331905
      },
      "n": "ServiceTiers",
      "o": "LCFCP$IPaymentTierProvider$ServiceTiers",
      "d": 1001240,
      "h": 64425510680,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64425510680)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015445272),
    {
      "r": 178454529,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Validate",
      "o": "LCFCP$IPaymentTierProvider$Validate",
      "d": 1001240,
      "h": 73015445272,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(73015445272),
//--TRIMMABLE-BOUNDARY-START(8590935832),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel).$h,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Execute",
      "o": "LCFCP$IPaymentTierProvider$Execute",
      "d": 1001240,
      "h": 8590935832,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590935832)
  ],
  "h": 1001240
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IPaymentTierProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1001240)
        
        

        //--TRIMMABLE-BOUNDARY-START(1066776)
        $asm.$cls(`$nYKj.LCFCP.IPaymentTierProvider<>`, (TTier) => $asm.$gt(`$nYKj.LCFCP.IPaymentTierProvider<>`, [TTier], ($self) => class IPaymentTierProvider$$
        {
            //--TRIMMABLE-BOUNDARY-START(4296034072)
            /*TTier */ get LCFCP$IPaymentTierProvider$$$Category()
            {
                return $.$default(TTier);
            }
            //--TRIMMABLE-BOUNDARY-END(4296034072)
            
            //--TRIMMABLE-BOUNDARY-START(25770870552)
            /*Enum? */ get LCFCP$IPaymentTierProvider$Category()
            {
                return this.LCFCP$IPaymentTierProvider$$$Category;
            }
            //--TRIMMABLE-BOUNDARY-END(25770870552)
            
            //--TRIMMABLE-BOUNDARY-START(47245707032)
            /*Pager<IPaymentTier>? */ get LCFCP$IPaymentTierProvider$ServiceTiers()
            {
                return $.$fPer.LCFCD.Paging.Cast$1($.$nYKj.LCFCP.IPaymentTier$$(TTier), $.$nYKj.LCFCP.IPaymentTier, this.LCFCP$IPaymentTierProvider$$$ServiceTiers);
            }
            //--TRIMMABLE-BOUNDARY-END(47245707032)
            
            static $H = 1066776;
            static $h = 1066776;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296034072),
    {
      "p": TTier?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 12885968664,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50331777
      },
      "n": "Category",
      "o": "LCFCP$IPaymentTierProvider$$$Category",
      "d": this.$h,
      "H": 4296034072,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 538968193
    },
//--TRIMMABLE-BOUNDARY-END(4296034072),
//--TRIMMABLE-BOUNDARY-START(51540674328),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier$$(TTier)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21475903256,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331905
      },
      "n": "ServiceTiers",
      "o": "LCFCP$IPaymentTierProvider$$$ServiceTiers",
      "d": this.$h,
      "H": 51540674328,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(51540674328),
//--TRIMMABLE-BOUNDARY-START(25770870552),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360805144,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331650
      },
      "n": "{1001240}.Category",
      "o": "LCFCP$IPaymentTierProvider$Category",
      "d": this.$h,
      "H": 25770870552,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25770870552),
//--TRIMMABLE-BOUNDARY-START(47245707032),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950739736,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331650
      },
      "n": "{1001240}.ServiceTiers",
      "o": "LCFCP$IPaymentTierProvider$ServiceTiers",
      "d": this.$h,
      "H": 47245707032,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47245707032)
  ],
  "s": [
    {
      "h": TTier?.$h??1572864,
      "n": "TTier",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 1,
  "H": 1066776,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<${TTier?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IPaymentTierProvider$${TTier?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1066776)
        
        

        //--TRIMMABLE-BOUNDARY-START(739096)
        $asm.$cls(`$nYKj.LCFCP.IPaymentTier`, ($self) => class IPaymentTier
        {
            //--TRIMMABLE-BOUNDARY-START(64425248536)
            /*string? */ get LCFCP$IPaymentTier$ServiceTierName()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(64425248536)
            
            //--TRIMMABLE-BOUNDARY-START(77310150424)
            /*Type? */ get LCFCP$IPaymentTier$UserInformation()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(77310150424)
            
            static $h = 739096;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130281240),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475575576,
        "f": 50331905
      },
      "n": "Id",
      "o": "LCFCP$IPaymentTier$Id",
      "d": 739096,
      "h": 60130281240,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60130281240),
//--TRIMMABLE-BOUNDARY-START(73015183128),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245379352,
        "f": 50331905
      },
      "n": "Tier",
      "o": "LCFCP$IPaymentTier$Tier",
      "d": 739096,
      "h": 73015183128,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(73015183128),
//--TRIMMABLE-BOUNDARY-START(4295706392),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885640984,
        "f": 50331905
      },
      "n": "Cost",
      "o": "LCFCP$IPaymentTier$Cost",
      "d": 739096,
      "h": 4295706392,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295706392),
//--TRIMMABLE-BOUNDARY-START(68720215832),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655444760,
        "f": 50331905
      },
      "n": "ServiceTiers",
      "o": "LCFCP$IPaymentTier$ServiceTiers",
      "d": 739096,
      "h": 68720215832,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(68720215832),
//--TRIMMABLE-BOUNDARY-START(64425248536),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065510168,
        "f": 50331777
      },
      "n": "ServiceTierName",
      "o": "LCFCP$IPaymentTier$ServiceTierName",
      "d": 739096,
      "h": 64425248536,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(64425248536),
//--TRIMMABLE-BOUNDARY-START(77310150424),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835313944,
        "f": 50331777
      },
      "n": "UserInformation",
      "o": "LCFCP$IPaymentTier$UserInformation",
      "d": 739096,
      "h": 77310150424,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(77310150424)
  ],
  "h": 739096
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IPaymentTier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IPaymentTier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(739096)
        
        

        //--TRIMMABLE-BOUNDARY-START(804632)
        $asm.$cls(`$nYKj.LCFCP.IPaymentTier<>`, (TTier) => $asm.$gt(`$nYKj.LCFCP.IPaymentTier<>`, [TTier], ($self) => class IPaymentTier$$
        {
            //--TRIMMABLE-BOUNDARY-START(21475641112)
            /*Enum */ get LCFCP$IPaymentTier$Tier()
            {
                return this.LCFCP$IPaymentTier$$$Tier;
            }
            //--TRIMMABLE-BOUNDARY-END(21475641112)
            
            static $H = 804632;
            static $h = 804632;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770608408),
    {
      "p": TTier?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 8590739224,
        "h": Number(BigInt(this.$h)|0x200000000n),
        "f": 50331905
      },
      "n": "Tier",
      "o": "LCFCP$IPaymentTier$$$Tier",
      "d": this.$h,
      "H": 25770608408,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(25770608408),
//--TRIMMABLE-BOUNDARY-START(21475641112),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180673816,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331650
      },
      "n": "{739096}.Tier",
      "o": "LCFCP$IPaymentTier$Tier",
      "d": this.$h,
      "H": 21475641112,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21475641112)
  ],
  "s": [
    {
      "h": TTier?.$h??1572864,
      "n": "TTier",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 1,
  "H": 804632,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IPaymentTier<${TTier?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IPaymentTier$${TTier?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(804632)
        
        

        //--TRIMMABLE-BOUNDARY-START(214808)
        $asm.$cls(`$nYKj.LCFCP.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295182104)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295182104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nYKj.LCFCP.PaymentCategoryType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nYKj.LCFCP.PaymentCategoryTypeCustomAttributesProvider, $.$nYKj.LCFCP.PaymentCategoryTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$nYKj.LCFCP.PaymentMethod.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$nYKj.LCFCP.PaymentMethodCustomAttributesProvider, $.$nYKj.LCFCP.PaymentMethodCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295182104)
            
            static $h = 214808;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295182104),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 214808,
      "h": 4295182104,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295182104)
  ],
  "h": 214808
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(214808)
        
        

        //--TRIMMABLE-BOUNDARY-START(280344)
        $asm.$cls(`$nYKj.LCFCP.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295247640)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295247640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295247640)
            
            static $h = 280344;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295247640),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 280344,
      "h": 4295247640,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295247640)
  ],
  "h": 280344
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(280344)
        
        

        //--TRIMMABLE-BOUNDARY-START(1394456)
        $asm.$cls(`$nYKj.LCFCP.PaymentCategoryTypeCustomAttributesProvider`, ($self) => class PaymentCategoryTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296361752)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296361752)
            
            //--TRIMMABLE-BOUNDARY-START(8591329048)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591329048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$nYKj.LCFCP.PaymentCategoryTypeCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Energy", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Description = "Spendings on utility energy";
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-flash", "//Icon.Bg=#F86512", "//Icon.Fg=#FFFFFF"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Entertainment", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Description = "Spendings on entertainment";
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-music", "//Icon.Bg=#888512", "//Icon.Fg=#FFFFFF"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("VTU", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Description = "Spendings on mobile recharge cards";
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-phone", "//Icon.Bg=#288512", "//Icon.Fg=#FFFFFF"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Transfer", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Description = "Money sent to peer";
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Icon=mdi mdi-transfer", "//Icon.Bg=#589542", "//Icon.Fg=#FFFFFF"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$nYKj.LCFCP.PaymentCategoryTypeCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $luClrj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1394456,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ZXsfRc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1394456,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591329048)
            
            static $h = 1394456;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591329048),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1394456,
      "h": 8591329048,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591329048)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296361752),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1394456,
      "h": 4296361752,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296361752)
  ],
  "h": 1394456
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}PaymentCategoryTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1394456)
        
        

        //--TRIMMABLE-BOUNDARY-START(1525528)
        $asm.$cls(`$nYKj.LCFCP.PaymentMethodCustomAttributesProvider`, ($self) => class PaymentMethodCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296492824)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296492824)
            
            //--TRIMMABLE-BOUNDARY-START(8591460120)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591460120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$nYKj.LCFCP.PaymentMethodCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("None", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$nYKj.LCFCP.PaymentMethodCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $LqUWqj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1525528,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $FeTqtf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1525528,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591460120)
            
            static $h = 1525528;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591460120),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1525528,
      "h": 8591460120,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591460120)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296492824),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1525528,
      "h": 4296492824,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296492824)
  ],
  "h": 1525528
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.PaymentMethodCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}PaymentMethodCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1525528)
        
        

        //--TRIMMABLE-BOUNDARY-START(1263384)
        $asm.$cls(`$nYKj.LCFCP.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296230680)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296230680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$nYKj.LCFCP.IBankingRemoteService, $.$nYKj.LCFCP.IBankingRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$nYKj.LCFCP.IBankingRemoteService_Mocking().$ctor$3(impl);
                }, $kJtSFk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1263384,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4296230680)
            
            static $h = 1263384;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296230680),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 1263384,
      "h": 4296230680,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296230680)
  ],
  "h": 1263384
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1263384)
        
        

        //--TRIMMABLE-BOUNDARY-START(1656600)
        $asm.$cls(`$nYKj.LCFCP.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886558488)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886558488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_BankTransferDeliveryServiceProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$nYKj.LCFCP.BankTransferDeliveryServiceProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$uvJL.LCFCR.IServerRemoteService, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$nYKj.LCFCP.BankTransferDeliveryServiceProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$nYKj.LCFCP.ServiceRegistrar, Get_BankTransferDeliveryServiceProvider, $kztFtg ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_BankTransferDeliveryServiceProvider","d":1656600,"h":0,"f":16777250})));
                /*static object*/  function Get_IPaymentTierProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$nYKj.LCFCP.BankTransferDeliveryServiceProvider, x);
                    }), $aUlPml ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1656600,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$nYKj.LCFCP.IPaymentTierProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$nYKj.LCFCP.ServiceRegistrar, Get_IPaymentTierProvider, $IwrRVj ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPaymentTierProvider","d":1656600,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12886558488)
            
            //--TRIMMABLE-BOUNDARY-START(8591591192)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591591192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$nYKj.LCFCP.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$nYKj.LCFCP.IPaymentTierProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$nYKj.LCFCP.BankTransferDeliveryServiceProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$nYKj.LCFCP.IPaymentTierProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$nYKj.LCFCP.BankTransferDeliveryServiceProvider, x);
                }, $UJmljl ??= {"r":1001240,"p":[{"n":"x","p":327718}],"n":"","d":1656600,"h":0,"f":17825794}));
                $.$nYKj.LCFCP.FastEnumStartupExtension.AddGeneratedFastEnums(services);
                $.$nYKj.LCFCP.MockingFactoryExtension.AddGeneratedMockedServices(services);
                $.$nYKj.LCFCP.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591591192)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$nYKj.LCFCP.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296623896)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296623896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296623896)
            
            //--TRIMMABLE-BOUNDARY-START(4296623896)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296623896)
            
            static $h = 1656600;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886558488),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 1656600,
      "h": 12886558488,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886558488),
//--TRIMMABLE-BOUNDARY-START(8591591192),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1656600,
      "h": 8591591192,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591591192)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296623896),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1656600,
      "h": 4296623896,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296623896)
  ],
  "h": 1656600
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1656600)
        
        

        //--TRIMMABLE-BOUNDARY-START(1591064)
        $asm.$str(`$nYKj.LCFCP.PaymentTierReceiptContext`, ($self) => class PaymentTierReceiptContext extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(180390217496)
            /*IPaymentTier?*/ Tier = null;
            //--TRIMMABLE-BOUNDARY-END(180390217496)
            
            //--TRIMMABLE-BOUNDARY-START(38656296728)
            /*Money*/ AmountPaid;
            //--TRIMMABLE-BOUNDARY-END(38656296728)
            
            //--TRIMMABLE-BOUNDARY-START(111670740760)
            /*string*/ PaymentReference = null;
            //--TRIMMABLE-BOUNDARY-END(111670740760)
            
            //--TRIMMABLE-BOUNDARY-START(42951264024)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(42951264024)
            
            //--TRIMMABLE-BOUNDARY-START(115965708056)
            /*object?*/ ServiceUserInformation = null;
            //--TRIMMABLE-BOUNDARY-END(115965708056)
            
            //--TRIMMABLE-BOUNDARY-START(184685184792)
            /*object?*/ TierUserInformation = null;
            //--TRIMMABLE-BOUNDARY-END(184685184792)
            
            //--TRIMMABLE-BOUNDARY-START(107375773464)
            /*bool*/ IsClient = false;
            //--TRIMMABLE-BOUNDARY-END(107375773464)
            
            //--TRIMMABLE-BOUNDARY-START(34361329432)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361329432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361329432)
            
            //--TRIMMABLE-BOUNDARY-START(34361329432)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(34361329432)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Tier = this.Tier;
                copy.AmountPaid = this.AmountPaid.$clone();
                copy.PaymentReference = this.PaymentReference;
                copy.Description = this.Description;
                copy.ServiceUserInformation = this.ServiceUserInformation;
                copy.TierUserInformation = this.TierUserInformation;
                copy.IsClient = this.IsClient;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38656296728)
                this.AmountPaid = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(38656296728)
                
            }
            static $h = 1591064;
            static $z = 33;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(180390217496),
    {
      "p": 739096,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490871576,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505315608,
        "f": 83886081
      },
      "n": "Tier",
      "d": 1591064,
      "h": 180390217496,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180390217496),
//--TRIMMABLE-BOUNDARY-START(38656296728),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541198616,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555642648,
        "f": 83886081
      },
      "n": "AmountPaid",
      "d": 1591064,
      "h": 38656296728,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656296728),
//--TRIMMABLE-BOUNDARY-START(111670740760),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311002392,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325446424,
        "f": 83886081
      },
      "n": "PaymentReference",
      "d": 1591064,
      "h": 111670740760,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670740760),
//--TRIMMABLE-BOUNDARY-START(42951264024),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131133208,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145577240,
        "f": 83886081
      },
      "n": "Description",
      "d": 1591064,
      "h": 42951264024,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951264024),
//--TRIMMABLE-BOUNDARY-START(115965708056),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900936984,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915381016,
        "f": 83886081
      },
      "n": "ServiceUserInformation",
      "d": 1591064,
      "h": 115965708056,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965708056),
//--TRIMMABLE-BOUNDARY-START(184685184792),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080806168,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176095250200,
        "f": 83886081
      },
      "n": "TierUserInformation",
      "d": 1591064,
      "h": 184685184792,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184685184792),
//--TRIMMABLE-BOUNDARY-START(107375773464),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721067800,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735511832,
        "f": 83886081
      },
      "n": "IsClient",
      "d": 1591064,
      "h": 107375773464,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375773464)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361329432),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1591064,
      "h": 34361329432,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361329432)
  ],
  "h": 1591064
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}PaymentTierReceiptContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1591064)
        
        

        //--TRIMMABLE-BOUNDARY-START(83736)
        $asm.$str(`$nYKj.LCFCP.BankPayment`, ($self) => class BankPayment extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(55834658584)
            /*string*/ Reference = null;
            //--TRIMMABLE-BOUNDARY-END(55834658584)
            
            //--TRIMMABLE-BOUNDARY-START(21474920216)
            /*double*/ AmountPaid = 0;
            //--TRIMMABLE-BOUNDARY-END(21474920216)
            
            //--TRIMMABLE-BOUNDARY-START(25769887512)
            /*double*/ FeesDeducted = 0;
            //--TRIMMABLE-BOUNDARY-END(25769887512)
            
            //--TRIMMABLE-BOUNDARY-START(17179952920)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179952920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17179952920)
            
            //--TRIMMABLE-BOUNDARY-START(17179952920)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17179952920)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Reference = this.Reference;
                copy.AmountPaid = this.AmountPaid;
                copy.FeesDeducted = this.FeesDeducted;
                return copy;
            }
            static $h = 83736;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834658584),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539691288,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604462360,
        "f": 83886081
      },
      "n": "Reference",
      "d": 83736,
      "h": 55834658584,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834658584),
//--TRIMMABLE-BOUNDARY-START(21474920216),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359822104,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424593176,
        "f": 83886081
      },
      "n": "AmountPaid",
      "d": 83736,
      "h": 21474920216,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474920216),
//--TRIMMABLE-BOUNDARY-START(25769887512),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949756696,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014527768,
        "f": 83886081
      },
      "n": "FeesDeducted",
      "d": 83736,
      "h": 25769887512,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25769887512)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17179952920),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 83736,
      "h": 17179952920,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179952920)
  ],
  "h": 83736
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.BankPayment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}BankPayment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(83736)
        
        

        //--TRIMMABLE-BOUNDARY-START(476952)
        $asm.$cls(`$nYKj.LCFCP.IBankingRemoteService_Mocking`, ($self) => class IBankingRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295444248)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295444248);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295444248)
            
            //--TRIMMABLE-BOUNDARY-START(8590411544)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Data.BankAccount>> */ LCFCP$IBankingRemoteService$BeginReceiveFund(/*string*/ walletName, /*double?*/ amount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590411544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$nYKj.LCFCP.IBankingRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount).$type;
                    $i1.MethodName = "BeginReceiveFund";
                    return $i1;
                })();
                return this.InvokeAsync($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeNullable($.$$.S.Double).$type, $.$box(amount, $.$$.S.Double)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590411544)
            
            //--TRIMMABLE-BOUNDARY-START(12885378840)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Data.Bank>> */ LCFCP$IBankingRemoteService$GetBanks(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885378840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$nYKj.LCFCP.IBankingRemoteService.$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$fPer.LCFCD.Bank).$type;
                    $i2.MethodName = "GetBanks";
                    return $i2;
                })();
                return this.InvokeAsync($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$fPer.LCFCD.Bank), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885378840)
            
            //--TRIMMABLE-BOUNDARY-START(17180346136)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Data.BankAccount>> */ LCFCP$IBankingRemoteService$ResolveAccount(/*LivingThing.Core.Frameworks.Common.Data.Bank*/ bank, /*string*/ accountNumber)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180346136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$nYKj.LCFCP.IBankingRemoteService.$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount).$type;
                    $i3.MethodName = "ResolveAccount";
                    return $i3;
                })();
                return this.InvokeAsync($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankAccount), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.Bank.$type, $.$clone(bank)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, accountNumber) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180346136)
            
            //--TRIMMABLE-BOUNDARY-START(21475313432)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Data.BankTransferResult>> */ LCFCP$IBankingRemoteService$TransferTo(/*double*/ amount, /*LivingThing.Core.Frameworks.Common.Data.BankAccount*/ account, /*string*/ transactionDescription)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475313432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$nYKj.LCFCP.IBankingRemoteService.$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult).$type;
                    $i4.MethodName = "TransferTo";
                    return $i4;
                })();
                return this.InvokeAsync($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.BankAccount.$type, $.$clone(account)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionDescription) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475313432)
            
            static $h = 476952;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295444248),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 476952,
      "h": 4295444248,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295444248)
  ],
  "h": 476952
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.IBankingRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}IBankingRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(476952)
        
        

        //--TRIMMABLE-BOUNDARY-START(1459992)
        $asm.$str(`$nYKj.LCFCP.PaymentMethod`, ($self) => class PaymentMethod extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Cash = 1;
            static Card = 2;
            static Wallet = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1459992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Cash": 1n,
                    "Card": 2n,
                    "Wallet": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296427288)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296427288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296427288)
            
            //--TRIMMABLE-BOUNDARY-START(4296427288)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296427288)
            
            static $h = 1459992;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181329176),
    {
      "t": 1459992,
      "n": "None",
      "d": 1459992,
      "h": 17181329176,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181329176),
//--TRIMMABLE-BOUNDARY-START(12886361880),
    {
      "t": 1459992,
      "n": "Cash",
      "d": 1459992,
      "h": 12886361880,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886361880),
//--TRIMMABLE-BOUNDARY-START(8591394584),
    {
      "t": 1459992,
      "n": "Card",
      "d": 1459992,
      "h": 8591394584,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591394584),
//--TRIMMABLE-BOUNDARY-START(21476296472),
    {
      "t": 1459992,
      "n": "Wallet",
      "d": 1459992,
      "h": 21476296472,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476296472)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296427288),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1459992,
      "h": 4296427288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296427288)
  ],
  "h": 1459992
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.PaymentMethod`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}PaymentMethod`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1459992)
        
        

        //--TRIMMABLE-BOUNDARY-START(1328920)
        $asm.$str(`$nYKj.LCFCP.PaymentCategoryType`, ($self) => class PaymentCategoryType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Energy = 1;
            static Entertainment = 2;
            static VTU = 3;
            static Transfer = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1328920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Energy": 1n,
                    "Entertainment": 2n,
                    "VTU": 3n,
                    "Transfer": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296296216)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296296216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296296216)
            
            //--TRIMMABLE-BOUNDARY-START(4296296216)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296296216)
            
            static $h = 1328920;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181198104),
    {
      "t": 1328920,
      "n": "None",
      "d": 1328920,
      "h": 17181198104,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181198104),
//--TRIMMABLE-BOUNDARY-START(8591263512),
    {
      "t": 1328920,
      "n": "Energy",
      "d": 1328920,
      "h": 8591263512,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Spendings on utility energy",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-flash",
                "//Icon.Bg=#F86512",
                "//Icon.Fg=#FFFFFF"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591263512),
//--TRIMMABLE-BOUNDARY-START(12886230808),
    {
      "t": 1328920,
      "n": "Entertainment",
      "d": 1328920,
      "h": 12886230808,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Spendings on entertainment",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-music",
                "//Icon.Bg=#888512",
                "//Icon.Fg=#FFFFFF"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886230808),
//--TRIMMABLE-BOUNDARY-START(25771132696),
    {
      "t": 1328920,
      "n": "VTU",
      "d": 1328920,
      "h": 25771132696,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Spendings on mobile recharge cards",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-phone",
                "//Icon.Bg=#288512",
                "//Icon.Fg=#FFFFFF"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771132696),
//--TRIMMABLE-BOUNDARY-START(21476165400),
    {
      "t": 1328920,
      "n": "Transfer",
      "d": 1328920,
      "h": 21476165400,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Money sent to peer",
              "t": 1310721
            },
            {
              "n": "Options",
              "v": [
                "//Icon=mdi mdi-transfer",
                "//Icon.Bg=#589542",
                "//Icon.Fg=#FFFFFF"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476165400)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296296216),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1328920,
      "h": 4296296216,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296296216)
  ],
  "h": 1328920
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}PaymentCategoryType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1328920)
        
        

        //--TRIMMABLE-BOUNDARY-START(149272)
        $asm.$cls(`$nYKj.LCFCP.BankTransferDeliveryServiceProvider`, ($self) => class BankTransferDeliveryServiceProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295116568)
            /*IServerRemoteService*/ _server = null;
            //--TRIMMABLE-BOUNDARY-END(4295116568)
            
            //--TRIMMABLE-BOUNDARY-START(12885051160)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885051160);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885051160)
            
            //--TRIMMABLE-BOUNDARY-START(107374331672)
            /*Type? */ get UserInformation()
            {
                return $.$fPer.LCFCD.BankAccount.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(107374331672)
            
            //--TRIMMABLE-BOUNDARY-START(21474985752)
            /*string */ get Description()
            {
                return "Bank Transfer";
            }
            //--TRIMMABLE-BOUNDARY-END(21474985752)
            
            //--TRIMMABLE-BOUNDARY-START(90194462488)
            /*IconDescriptor */ get Icon()
            {
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = "mdi mdi-phone"/*MaterialDesignIconNames.Phone*/;
                    $i1.Theme = (() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#146752";
                        $i2.ForegroundColor = "#FFFFFF";
                        return $i2;
                    })();
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(90194462488)
            
            //--TRIMMABLE-BOUNDARY-START(94489429784)
            /*string */ get Name()
            {
                return "BankTransfer";
            }
            //--TRIMMABLE-BOUNDARY-END(94489429784)
            
            //--TRIMMABLE-BOUNDARY-START(103079364376)
            /*string */ get Title()
            {
                return "Bank Transfer";
            }
            //--TRIMMABLE-BOUNDARY-END(103079364376)
            
            //--TRIMMABLE-BOUNDARY-START(17180018456)
            /*PaymentCategoryType */ get Category()
            {
                return 3/*PaymentCategoryType.VTU*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17180018456)
            
            //--TRIMMABLE-BOUNDARY-START(98784397080)
            /*Pager<IPaymentTier<PaymentCategoryType>>?*/ ServiceTiers = null;
            //--TRIMMABLE-BOUNDARY-END(98784397080)
            
            //--TRIMMABLE-BOUNDARY-START(111669298968)
            /*Task */ Validate(/*PaymentTierReceiptContext*/ receipt)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669298968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (receipt.ServiceUserInformation === null || $.$$.S.String.IsNullOrEmpty(($.$cast(receipt.ServiceUserInformation, $.$fPer.LCFCD.BankAccount)).AccountNumber) || $.$$.S.String.IsNullOrEmpty(($.$cast(receipt.ServiceUserInformation, $.$fPer.LCFCD.BankAccount)).Bank.Code))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Please enter all fields");
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(111669298968)
            
            //--TRIMMABLE-BOUNDARY-START(25769953048)
            /*Task<IPaymentOrderTransactionModel?> *//*async*/  Execute(/*PaymentTierReceiptContext*/ receipt)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel), $.$fPer.LCFC.IPaymentOrderTransactionModel, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769953048);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t3 = this.Validate($.$clone(receipt)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    if (receipt.IsClient)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, null);
                    }
                    /*var*/ let account = $.$cast(receipt.ServiceUserInformation, $.$fPer.LCFCD.BankAccount);
                    /*var*/ let result = ($t4 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.BankTransferResult, this._server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$nYKj.LCFCP.IBankingRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult)))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCFCP$IBankingRemoteService$TransferTo($.$fPer.LCFCDM.Money.op_Implicit(receipt.AmountPaid), $.$clone(account), receipt.Description);
                    }, $irERke ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult)).$h,"p":[{"n":"s","p":411416}],"n":"","d":149272,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                    {
                        //new $.$fPer.LCFC.PaymentOrderTransactionModel()
                        const $t5 = $.$fPer.LCFC.PaymentOrderTransactionModel;
                        const $i5 = new $t5();
                        $i5.$ctor$1();
                        $i5.OrderStatus = 5/*PaymentOrderTransactionStatus.Completed*/;
                        $i5.Attributes = (() =>
                        {
                            //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)()
                            const $t6 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object);
                            const $i6 = new $t6();
                            $i6.$ctor$1();
                            $i6.set_Item("Reference", (result?.TransferReference ?? null));
                            return $i6;
                        })();
                        return $i5;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25769953048)
            
            //--TRIMMABLE-BOUNDARY-START(12885968664)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.Category.get
            get LCFCP$IPaymentTierProvider$$$Category()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296034072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Category;
            }
            //--TRIMMABLE-BOUNDARY-END(12885968664)
            
            //--TRIMMABLE-BOUNDARY-START(21475903256)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider<LivingThing.Core.Frameworks.Common.Payment.PaymentCategoryType>.ServiceTiers.get
            get LCFCP$IPaymentTierProvider$$$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540674328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTiers;
            }
            //--TRIMMABLE-BOUNDARY-END(21475903256)
            
            //--TRIMMABLE-BOUNDARY-START(51540608792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.UserInformation.get
            get LCFCP$IPaymentTierProvider$UserInformation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720477976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UserInformation;
            }
            //--TRIMMABLE-BOUNDARY-END(51540608792)
            
            //--TRIMMABLE-BOUNDARY-START(73015445272)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Validate(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Validate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015445272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Validate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(73015445272)
            
            //--TRIMMABLE-BOUNDARY-START(8590935832)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTierProvider.Execute(LivingThing.Core.Frameworks.Common.Payment.PaymentTierReceiptContext)
            LCFCP$IPaymentTierProvider$Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590935832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590935832)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            static $h = 149272;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374331672),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899495192,
        "f": 50331649
      },
      "n": "UserInformation",
      "d": 149272,
      "h": 107374331672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374331672),
//--TRIMMABLE-BOUNDARY-START(21474985752),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949822232,
        "f": 50331649
      },
      "n": "Description",
      "d": 149272,
      "h": 21474985752,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474985752),
//--TRIMMABLE-BOUNDARY-START(90194462488),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539756824,
        "f": 50331649
      },
      "n": "Icon",
      "d": 149272,
      "h": 90194462488,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194462488),
//--TRIMMABLE-BOUNDARY-START(94489429784),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129691416,
        "f": 50331649
      },
      "n": "Name",
      "d": 149272,
      "h": 94489429784,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489429784),
//--TRIMMABLE-BOUNDARY-START(103079364376),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309560600,
        "f": 50331649
      },
      "n": "Title",
      "d": 149272,
      "h": 103079364376,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079364376),
//--TRIMMABLE-BOUNDARY-START(17180018456),
    {
      "p": 1328920,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359887640,
        "f": 50331649
      },
      "n": "Category",
      "d": 149272,
      "h": 17180018456,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180018456),
//--TRIMMABLE-BOUNDARY-START(98784397080),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier$$($.$nYKj.LCFCP.PaymentCategoryType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719626008,
        "f": 50331649
      },
      "n": "ServiceTiers",
      "d": 149272,
      "h": 98784397080,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784397080)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111669298968),
    {
      "r": 178454529,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Validate",
      "d": 149272,
      "h": 111669298968,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669298968),
//--TRIMMABLE-BOUNDARY-START(25769953048),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFC.IPaymentOrderTransactionModel).$h,
      "p": [
        {
          "n": "receipt",
          "p": 1591064
        }
      ],
      "n": "Execute",
      "d": 149272,
      "h": 25769953048,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(25769953048)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295116568),
    {
      "t": 1309651,
      "n": "_server",
      "d": 149272,
      "h": 4295116568,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295116568)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885051160),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 149272,
      "h": 12885051160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885051160)
  ],
  "h": 149272
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTierProvider$$($.$nYKj.LCFCP.PaymentCategoryType), $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Payment.BankTransferDeliveryServiceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Payment${separator}BankTransferDeliveryServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(149272)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC"));
})();
//--TRIMMABLE-BOUNDARY-END(18200)
