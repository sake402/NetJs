
//--TRIMMABLE-BOUNDARY-START(49066)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer) {
    "use strict";
    let _;
    let $iDNNIh;
    let $ABnzkc;
    let $lCmHWc;
    let $rxwLlk;
    let $QgUrWf;
    let $eZncai;
    let $BKKWSj;
    let $WzGfwe;
    let $IcMeKi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", 
    {
  "h": 49066,
  "f": "LivingThing.Core.Frameworks.Common.Pipeline",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Pipeline",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Pipeline",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(507818)
        $asm.$cls(`$fXpo.LCFCPC.IPipelineCollectionProvider<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCPC.IPipelineCollectionProvider<>`, [TPipelineContext], ($self) => class IPipelineCollectionProvider$$
        {
            static $H = 507818;
            static $h = 507818;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885409706),
    {
      "p": $.$fXpo.LCFCPC.IPipelineCollection$$(TPipelineContext).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 8590442410,
        "h": Number(BigInt(this.$h)|0x200000000n),
        "f": 50331905
      },
      "n": "Pipelines",
      "o": `LCFCPC$IPipelineCollectionProvider$${TPipelineContext.$getFullName('$')}$Pipelines`,
      "d": this.$h,
      "H": 12885409706,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885409706)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 507818,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Core.IPipelineCollectionProvider<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Core${separator}IPipelineCollectionProvider$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(507818)
        
        

        //--TRIMMABLE-BOUNDARY-START(442282)
        $asm.$cls(`$fXpo.LCFCPC.IPipelineCollection<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCPC.IPipelineCollection<>`, [TPipelineContext], ($self) => class IPipelineCollection$$
        {
            static $H = 442282;
            static $h = 442282;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295409578),
    {
      "r": this.$h,
      "p": [
        {
          "n": "excludes",
          "p": $.$typeArray($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
          "f": 16
        }
      ],
      "n": "Except",
      "o": `LCFCPC$IPipelineCollection$${TPipelineContext.$getFullName('$')}$Except`,
      "d": this.$h,
      "H": 4295409578,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295409578),
//--TRIMMABLE-BOUNDARY-START(8590376874),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        },
        {
          "n": "finalize",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$(TPipelineContext).$h,
          "f": 65
        }
      ],
      "n": "Feed",
      "o": `LCFCPC$IPipelineCollection$${TPipelineContext.$getFullName('$')}$Feed`,
      "d": this.$h,
      "H": 8590376874,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590376874),
//--TRIMMABLE-BOUNDARY-START(12885344170),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        },
        {
          "n": "finalize",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$(TPipelineContext).$h,
          "f": 65
        }
      ],
      "n": "FeedAsync",
      "o": `LCFCPC$IPipelineCollection$${TPipelineContext.$getFullName('$')}$FeedAsync`,
      "d": this.$h,
      "H": 12885344170,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885344170)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 442282,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Core.IPipelineCollection<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Core${separator}IPipelineCollection$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(442282)
        
        

        //--TRIMMABLE-BOUNDARY-START(901034)
        $asm.$cls(`$fXpo.LCFCP.IPipelineActivator<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCP.IPipelineActivator<>`, [TPipelineContext], ($self) => class IPipelineActivator$$
        {
            static $H = 901034;
            static $h = 901034;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295868330),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
      "n": "Activate",
      "o": `LCFCP$IPipelineActivator$${TPipelineContext.$getFullName('$')}$Activate`,
      "d": this.$h,
      "H": 4295868330,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295868330)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 901034,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.IPipelineActivator<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}IPipelineActivator$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(901034)
        
        

        //--TRIMMABLE-BOUNDARY-START(835498)
        $asm.$cls(`$fXpo.LCFCP.IPipeline<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCP.IPipeline<>`, [TPipelineContext], ($self) => class IPipeline$$
        {
            static $H = 835498;
            static $h = 835498;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180704682),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 8590770090,
        "h": Number(BigInt(this.$h)|0x200000000n),
        "f": 50331905
      },
      "n": "Order",
      "o": "LCFCP$IPipeline$$$Order",
      "d": this.$h,
      "H": 17180704682,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180704682)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885737386),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$(TPipelineContext).$h
        }
      ],
      "n": "Invoke",
      "o": "LCFCP$IPipeline$$$Invoke",
      "d": this.$h,
      "H": 12885737386,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885737386)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 835498,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}IPipeline$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(835498)
        
        

        //--TRIMMABLE-BOUNDARY-START(769962)
        $asm.$cls(`$fXpo.LCFCPC.PipelineContext`, ($self) => class PipelineContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295737258)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295737258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295737258)
            
            //--TRIMMABLE-BOUNDARY-START(4295737258)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295737258)
            
            static $h = 769962;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295737258),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 769962,
      "h": 4295737258,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295737258)
  ],
  "h": 769962
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Core.PipelineContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Core${separator}PipelineContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(769962)
        
        

        //--TRIMMABLE-BOUNDARY-START(311210)
        $asm.$cls(`$fXpo.LCFCPC.BasePipeline<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCPC.BasePipeline<>`, [TPipelineContext], ($self) => class BasePipeline$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475147690)
            /*int */ get Order()
            {
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(21475147690)
            
            //--TRIMMABLE-BOUNDARY-START(17180180394)
            /*Task */ Invoke(/*TPipelineContext*/ context, /*PipelineDelegate<TPipelineContext>*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180180394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return next.Invoke(context);
            }
            //--TRIMMABLE-BOUNDARY-END(17180180394)
            
            //--TRIMMABLE-BOUNDARY-START(8590770090)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<TPipelineContext>.Order.get
            get LCFCP$IPipeline$$$Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180704682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Order;
            }
            //--TRIMMABLE-BOUNDARY-END(8590770090)
            
            //--TRIMMABLE-BOUNDARY-START(12885737386)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<TPipelineContext>.Invoke(TPipelineContext, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<TPipelineContext>)
            LCFCP$IPipeline$$$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885737386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885737386)
            
            //--TRIMMABLE-BOUNDARY-START(4295278506)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295278506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295278506)
            
            //--TRIMMABLE-BOUNDARY-START(4295278506)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295278506)
            
            static $H = 311210;
            static $h = 311210;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475147690),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 12885213098,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50331777
      },
      "n": "Order",
      "d": this.$h,
      "H": 21475147690,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21475147690)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180180394),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        },
        {
          "n": "next",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$(TPipelineContext).$h
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 17180180394,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180180394)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295278506),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295278506,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295278506)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 311210,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCP.IPipeline$$(TPipelineContext) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Core.BasePipeline<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Core${separator}BasePipeline$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(311210)
        
        

        //--TRIMMABLE-BOUNDARY-START(573354)
        $asm.$cls(`$fXpo.LCFCPC.PipelineBuilder<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCPC.PipelineBuilder<>`, [TPipelineContext], ($self) => class PipelineBuilder$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590507946)
            /*List<IPipelineActivator<TPipelineContext>>*/ activators = null;
            //--TRIMMABLE-BOUNDARY-END(8590507946)
            
            //--TRIMMABLE-BOUNDARY-START(12885475242)
            /*PipelineBuilder<TPipelineContext> */ Add(/*params IPipeline<TPipelineContext>[]*/ pipelines)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885475242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.activators.AddRange($.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.Select$1($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$fXpo.LCFCPA.ConstructedPipelineActivator$$(TPipelineContext), pipelines, new ($.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$fXpo.LCFCPA.ConstructedPipelineActivator$$(TPipelineContext)))().$ctor(this,  (/*pipeline*/ pipeline) =>
                {
                    return new ($.$fXpo.LCFCPA.ConstructedPipelineActivator$$(TPipelineContext))().$ctor$1(pipeline);
                }, $lCmHWc ??= {"r":$.$fXpo.LCFCPA.ConstructedPipelineActivator$$(TPipelineContext).$h,"p":[{"n":"pipeline","p":$.$fXpo.LCFCP.IPipeline$$(TPipelineContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), $.$$.SCG.IEnumerable$$($.$fXpo.LCFCPA.ConstructedPipelineActivator$$(TPipelineContext)), $.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipelineActivator$$(TPipelineContext))));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885475242)
            
            //--TRIMMABLE-BOUNDARY-START(21475409834)
            /*PipelineBuilder<TPipelineContext> */ Add$2(TPipeline, /*ServiceFactory*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475409834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.activators.Add(new ($.$fXpo.LCFCPA.ServiceFactoryPipelineActivator$$$(TPipeline, TPipelineContext))().$ctor$1(factory));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475409834)
            
            //--TRIMMABLE-BOUNDARY-START(17180442538)
            /*PipelineBuilder<TPipelineContext> */ Add$1(/*IPipelineActivator<TPipelineContext>*/ activator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180442538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.activators.Add(activator);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180442538)
            
            //--TRIMMABLE-BOUNDARY-START(30065344426)
            /*Func<IPipeline<TPipelineContext>, bool>?*/ filter = null;
            //--TRIMMABLE-BOUNDARY-END(30065344426)
            
            //--TRIMMABLE-BOUNDARY-START(34360311722)
            /*PipelineBuilder<TPipelineContext> */ WithFilter(/*Func<IPipeline<TPipelineContext>, bool>*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360311722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.filter = filter;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360311722)
            
            //--TRIMMABLE-BOUNDARY-START(25770377130)
            /*IPipelineCollection<TPipelineContext> */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770377130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$fXpo.LCFCPC.PipelineCollection$$(TPipelineContext))().$ctor$1($.$sl.SL.Enumerable.ToArray($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$sl.SL.Enumerable.SelectMany$2($.$fXpo.LCFCP.IPipelineActivator$$(TPipelineContext), $.$fXpo.LCFCP.IPipeline$$(TPipelineContext), this.activators, new ($.$$.S.Func$$$($.$fXpo.LCFCP.IPipelineActivator$$(TPipelineContext), $.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext))))().$ctor(this,  (/*a*/ a) =>
                {
                    return a[`LCFCP$IPipelineActivator$${TPipelineContext.$getFullName('$')}$Activate`]();
                }, $rxwLlk ??= {"r":$.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,"p":[{"n":"a","p":$.$fXpo.LCFCP.IPipelineActivator$$(TPipelineContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})))).Filter(this.filter);
            }
            //--TRIMMABLE-BOUNDARY-END(25770377130)
            
            //--TRIMMABLE-BOUNDARY-START(4295540650)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295540650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295540650)
            
            //--TRIMMABLE-BOUNDARY-START(4295540650)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295540650)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590507946)
                this.activators = new ($.$$.SCG.List$$($.$fXpo.LCFCP.IPipelineActivator$$(TPipelineContext)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590507946)
                
            }
            static $H = 573354;
            static $h = 573354;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885475242),
    {
      "r": this.$h,
      "p": [
        {
          "n": "pipelines",
          "p": $.$typeArray($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
          "f": 16
        }
      ],
      "n": "Add",
      "d": this.$h,
      "H": 12885475242,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885475242),
//--TRIMMABLE-BOUNDARY-START(21475409834),
    {
      "r": this.$h,
      "p": [
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TPipeline"
      ],
      "n": "Add",
      "o": "@$2",
      "d": this.$h,
      "H": 21475409834,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(21475409834),
//--TRIMMABLE-BOUNDARY-START(17180442538),
    {
      "r": this.$h,
      "p": [
        {
          "n": "activator",
          "p": $.$fXpo.LCFCP.IPipelineActivator$$(TPipelineContext).$h
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": this.$h,
      "H": 17180442538,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180442538),
//--TRIMMABLE-BOUNDARY-START(34360311722),
    {
      "r": this.$h,
      "p": [
        {
          "n": "filter",
          "p": $.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean).$h
        }
      ],
      "n": "WithFilter",
      "d": this.$h,
      "H": 34360311722,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360311722),
//--TRIMMABLE-BOUNDARY-START(25770377130),
    {
      "r": $.$fXpo.LCFCPC.IPipelineCollection$$(TPipelineContext).$h,
      "n": "Build",
      "d": this.$h,
      "H": 25770377130,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770377130)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590507946),
    {
      "t": $.$$.SCG.List$$($.$fXpo.LCFCP.IPipelineActivator$$(TPipelineContext)).$h,
      "n": "activators",
      "d": this.$h,
      "H": 8590507946,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590507946),
//--TRIMMABLE-BOUNDARY-START(30065344426),
    {
      "t": $.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean).$h,
      "n": "filter",
      "d": this.$h,
      "H": 30065344426,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065344426)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295540650),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295540650,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295540650)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 573354,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Core.PipelineBuilder<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Core${separator}PipelineBuilder$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(573354)
        
        

        //--TRIMMABLE-BOUNDARY-START(180138)
        $asm.$cls(`$fXpo.LCFCPA.DIPipelineActivator<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCPA.DIPipelineActivator<>`, [TPipelineContext], ($self) => class DIPipelineActivator$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885082026)
            /*IEnumerable<IPipeline<TPipelineContext>>*/ pipelines = null;
            //--TRIMMABLE-BOUNDARY-END(12885082026)
            
            //--TRIMMABLE-BOUNDARY-START(4295147434)
            $ctor$1(/*IEnumerable<IPipeline<TPipelineContext>>*/ pipelines)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295147434);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.pipelines = pipelines;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295147434)
            
            //--TRIMMABLE-BOUNDARY-START(8590114730)
            /*IEnumerable<IPipeline<TPipelineContext>> */ Activate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590114730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.pipelines;
            }
            //--TRIMMABLE-BOUNDARY-END(8590114730)
            
            //--TRIMMABLE-BOUNDARY-START(4295868330)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipelineActivator<TPipelineContext>.Activate()
            [`LCFCP$IPipelineActivator$${TPipelineContext.$getFullName('$')}$Activate`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295868330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Activate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295868330)
            
            static $H = 180138;
            static $h = 180138;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590114730),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
      "n": "Activate",
      "d": this.$h,
      "H": 8590114730,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590114730)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885082026),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
      "n": "pipelines",
      "d": this.$h,
      "H": 12885082026,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885082026)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295147434),
    {
      "p": [
        {
          "n": "pipelines",
          "p": $.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295147434,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295147434)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 180138,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCP.IPipelineActivator$$(TPipelineContext) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Activators.DIPipelineActivator<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Activators${separator}DIPipelineActivator$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(180138)
        
        

        //--TRIMMABLE-BOUNDARY-START(376746)
        $asm.$cls(`$fXpo.LCFCPC.DIPipelineCollection<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCPC.DIPipelineCollection<>`, [TPipelineContext], ($self) => class DIPipelineCollection$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295344042)
            /*IEnumerable<IPipeline<TPipelineContext>>*/ _pipelines = null;
            //--TRIMMABLE-BOUNDARY-END(4295344042)
            
            //--TRIMMABLE-BOUNDARY-START(8590311338)
            $ctor$1(/*IEnumerable<IPipeline<TPipelineContext>>*/ pipelines)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590311338);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._pipelines = pipelines;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590311338)
            
            //--TRIMMABLE-BOUNDARY-START(12885278634)
            /*IPipelineCollection<TPipelineContext> */ Except(/*params IPipeline<TPipelineContext>[]*/ excluded)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885278634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._pipelines = $.$sl.SL.Enumerable.ToList($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$sl.SL.Enumerable.Except$1($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), this._pipelines, $.$sl.SL.Enumerable.Where($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), excluded, new ($.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e !== null;
                }, $ABnzkc ??= {"r":262145,"p":[{"n":"e","p":$.$fXpo.LCFCP.IPipeline$$(TPipelineContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}))));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885278634)
            
            //--TRIMMABLE-BOUNDARY-START(17180245930)
            /*void */ Feed(/*TPipelineContext*/ context, /*PipelineDelegate<TPipelineContext>?*/ finalize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180245930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FeedAsync(context, finalize).GetAwaiter().GetResult();
            }
            //--TRIMMABLE-BOUNDARY-END(17180245930)
            
            //--TRIMMABLE-BOUNDARY-START(21475213226)
            /*Task */ FeedAsync(/*TPipelineContext*/ context, /*PipelineDelegate<TPipelineContext>?*/ finalize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475213226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let pipelines = new ($.$fXpo.LCFCPC.PipelineBuilder$$(TPipelineContext))().$ctor$1().Add($.$sl.SL.Enumerable.ToArray($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), this._pipelines)).Build();
                return pipelines[`LCFCPC$IPipelineCollection$${TPipelineContext.$getFullName('$')}$FeedAsync`](context, finalize);
            }
            //--TRIMMABLE-BOUNDARY-END(21475213226)
            
            //--TRIMMABLE-BOUNDARY-START(4295409578)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.Core.IPipelineCollection<TPipelineContext>.Except(params LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<TPipelineContext>[])
            [`LCFCPC$IPipelineCollection$${TPipelineContext.$getFullName('$')}$Except`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295409578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Except(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295409578)
            
            //--TRIMMABLE-BOUNDARY-START(8590376874)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.Core.IPipelineCollection<TPipelineContext>.Feed(TPipelineContext, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<TPipelineContext>?)
            [`LCFCPC$IPipelineCollection$${TPipelineContext.$getFullName('$')}$Feed`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590376874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Feed(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590376874)
            
            //--TRIMMABLE-BOUNDARY-START(12885344170)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.Core.IPipelineCollection<TPipelineContext>.FeedAsync(TPipelineContext, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<TPipelineContext>?)
            [`LCFCPC$IPipelineCollection$${TPipelineContext.$getFullName('$')}$FeedAsync`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885344170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FeedAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885344170)
            
            static $H = 376746;
            static $h = 376746;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885278634),
    {
      "r": $.$fXpo.LCFCPC.IPipelineCollection$$(TPipelineContext).$h,
      "p": [
        {
          "n": "excluded",
          "p": $.$typeArray($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
          "f": 16
        }
      ],
      "n": "Except",
      "d": this.$h,
      "H": 12885278634,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885278634),
//--TRIMMABLE-BOUNDARY-START(17180245930),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        },
        {
          "n": "finalize",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$(TPipelineContext).$h,
          "f": 65
        }
      ],
      "n": "Feed",
      "d": this.$h,
      "H": 17180245930,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180245930),
//--TRIMMABLE-BOUNDARY-START(21475213226),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        },
        {
          "n": "finalize",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$(TPipelineContext).$h,
          "f": 65
        }
      ],
      "n": "FeedAsync",
      "d": this.$h,
      "H": 21475213226,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475213226)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295344042),
    {
      "t": $.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
      "n": "_pipelines",
      "d": this.$h,
      "H": 4295344042,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295344042)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590311338),
    {
      "p": [
        {
          "n": "pipelines",
          "p": $.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590311338,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590311338)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 376746,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCPC.IPipelineCollection$$(TPipelineContext) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Core.DIPipelineCollection<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Core${separator}DIPipelineCollection$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(376746)
        
        

        //--TRIMMABLE-BOUNDARY-START(114602)
        $asm.$cls(`$fXpo.LCFCPA.ConstructedPipelineActivator<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCPA.ConstructedPipelineActivator<>`, [TPipelineContext], ($self) => class ConstructedPipelineActivator$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885016490)
            /*IPipeline<TPipelineContext>*/ pipeline = null;
            //--TRIMMABLE-BOUNDARY-END(12885016490)
            
            //--TRIMMABLE-BOUNDARY-START(4295081898)
            $ctor$1(/*IPipeline<TPipelineContext>*/ pipeline)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295081898);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.pipeline = pipeline;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295081898)
            
            //--TRIMMABLE-BOUNDARY-START(8590049194)
            /*IEnumerable<IPipeline<TPipelineContext>> */ Activate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590049194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)), [this.pipeline], null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590049194)
            
            //--TRIMMABLE-BOUNDARY-START(4295868330)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipelineActivator<TPipelineContext>.Activate()
            [`LCFCP$IPipelineActivator$${TPipelineContext.$getFullName('$')}$Activate`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295868330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Activate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295868330)
            
            static $H = 114602;
            static $h = 114602;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590049194),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
      "n": "Activate",
      "d": this.$h,
      "H": 8590049194,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590049194)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885016490),
    {
      "t": $.$fXpo.LCFCP.IPipeline$$(TPipelineContext).$h,
      "n": "pipeline",
      "d": this.$h,
      "H": 12885016490,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885016490)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295081898),
    {
      "p": [
        {
          "n": "pipeline",
          "p": $.$fXpo.LCFCP.IPipeline$$(TPipelineContext).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295081898,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295081898)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 114602,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCP.IPipelineActivator$$(TPipelineContext) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Activators.ConstructedPipelineActivator<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Activators${separator}ConstructedPipelineActivator$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(114602)
        
        

        //--TRIMMABLE-BOUNDARY-START(638890)
        $asm.$cls(`$fXpo.LCFCPC.PipelineCollection<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCPC.PipelineCollection<>`, [TPipelineContext], ($self) => class PipelineCollection$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360377258)
            /*IPipeline<TPipelineContext>[]*/ pipelines = null;
            //--TRIMMABLE-BOUNDARY-END(34360377258)
            
            //--TRIMMABLE-BOUNDARY-START(4295606186)
            $ctor$1(/*params IPipeline<TPipelineContext>[]*/ pipelines)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295606186);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.pipelines = $.$sl.SL.Enumerable.ToArray($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$sl.SL.Enumerable.OrderBy$1($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Int32, pipelines, new ($.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Int32))().$ctor(this,  (/*p*/ p) =>
                    {
                        return p.LCFCP$IPipeline$$$Order;
                    }, $QgUrWf ??= {"r":655361,"p":[{"n":"p","p":$.$fXpo.LCFCP.IPipeline$$(TPipelineContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295606186)
            
            //--TRIMMABLE-BOUNDARY-START(30065409962)
            /*List<Func<IPipeline<TPipelineContext>, bool>>?*/ filters = null;
            //--TRIMMABLE-BOUNDARY-END(30065409962)
            
            //--TRIMMABLE-BOUNDARY-START(8590573482)
            /*IPipelineCollection<TPipelineContext> */ Except(/*params IPipeline<TPipelineContext>[]*/ excluded)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590573482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.filters ??= new ($.$$.SCG.List$$($.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean)))().$ctor$1();
                this.filters.Add(new ($.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return !$.$sl.SL.Enumerable.Contains$1($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$sl.SL.Enumerable.Where($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), excluded, new ($.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                    {
                        return e !== null;
                    }, $eZncai ??= {"r":262145,"p":[{"n":"e","p":$.$fXpo.LCFCP.IPipeline$$(TPipelineContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), e);
                }, $BKKWSj ??= {"r":262145,"p":[{"n":"e","p":$.$fXpo.LCFCP.IPipeline$$(TPipelineContext).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590573482)
            
            //--TRIMMABLE-BOUNDARY-START(25770442666)
            /*IPipelineCollection<TPipelineContext> */ Filter(/*Func<IPipeline<TPipelineContext>, bool>?*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770442666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (filter !== null)
                {
                    this.filters ??= new ($.$$.SCG.List$$($.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean)))().$ctor$1();
                    this.filters.Add(filter);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770442666)
            
            //--TRIMMABLE-BOUNDARY-START(704426)
            static $_PipelineFeedingContext;
            static get PipelineFeedingContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$fXpo.LCFCPC.PipelineCollection$$(TPipelineContext);
                return $cls.$_PipelineFeedingContext ??= $asm.$ncls(`$fXpo.LCFCPC.PipelineCollection<${TPipelineContext?.$fullName}>.PipelineFeedingContext`, ($self) => class PipelineFeedingContext extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(38655410090)
                    /*int*/ Index = 0;
                    //--TRIMMABLE-BOUNDARY-END(38655410090)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180573610)
                    /*PipelineDelegate<TPipelineContext>?*/ Finalize$1 = null;
                    //--TRIMMABLE-BOUNDARY-END(17180573610)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885606314)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885606314);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885606314)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885606314)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885606314)
                    
                    static $H = 704426;
                    static $h = 704426;
                    static $f = 0b10000000001010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655410090),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360442794,
        "h": Number(BigInt(704426)|0x800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 55835279274,
        "h": Number(BigInt(704426)|0xD00000000n),
        "f": 83886081
      },
      "n": "Index",
      "d": 704426,
      "H": 38655410090,
      "h": Number(BigInt(704426)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655410090),
//--TRIMMABLE-BOUNDARY-START(17180573610),
    {
      "p": $.$fXpo.LCFCP.PipelineDelegate$$(TPipelineContext).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770508202,
        "h": Number(BigInt(704426)|0x600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47245344682,
        "h": Number(BigInt(704426)|0xB00000000n),
        "f": 83886081
      },
      "n": "Finalize",
      "o": "@$1",
      "d": 704426,
      "H": 17180573610,
      "h": Number(BigInt(704426)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180573610)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885606314),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 704426,
      "H": 12885606314,
      "h": Number(BigInt(704426)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885606314)
  ],
  "d": 638890,
  "H": 704426,
  "h": 704426
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Core.PipelineCollection<${TPipelineContext?.$fullName}>+PipelineFeedingContext`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Core${separator}PipelineCollection$${TPipelineContext?.$getFullName(separator)}$${separator}PipelineFeedingContext`; }
                }, $cls, ($v) => $cls.$_PipelineFeedingContext = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(704426)
            
            //--TRIMMABLE-BOUNDARY-START(38655344554)
            /*bool */ ShouldInclude(/*IPipeline<TPipelineContext>*/ pipeline)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655344554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.filters === null)
                {
                    return true;
                }
                return $.$sl.SL.Enumerable.All($.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean), this.filters, new ($.$$.S.Func$$$($.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Invoke(pipeline) === true;
                }, $WzGfwe ??= {"r":262145,"p":[{"n":"e","p":$.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(38655344554)
            
            //--TRIMMABLE-BOUNDARY-START(12885540778)
            /*Task */ Feed(/*TPipelineContext*/ context, /*PipelineFeedingContext*/ pipeContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885540778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (pipeContext.Index < this.pipelines.length)
                {
                    /*IPipeline<TPipelineContext>*/ let pipeline;
                    do
                    {
                        pipeline = $.$$.System.Array.$ReadT1.call(this.pipelines, pipeContext.Index++);
                    }
                    while(!this.ShouldInclude(pipeline));
                    return pipeline.LCFCP$IPipeline$$$Invoke(context, new ($.$fXpo.LCFCP.PipelineDelegate$$(TPipelineContext))().$ctor(this,  (/*ctx*/ ctx) =>
                    {
                        return this.Feed(ctx, pipeContext);
                    }, $IcMeKi ??= {"r":178454529,"p":[{"n":"ctx","p":TPipelineContext?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
                else if (pipeContext.Finalize$1 !== null)
                {
                    return pipeContext.Finalize$1.Invoke(context);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12885540778)
            
            //--TRIMMABLE-BOUNDARY-START(17180508074)
            /*void */ Feed$1(/*TPipelineContext*/ context, /*PipelineDelegate<TPipelineContext>?*/ finalize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180508074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FeedAsync(context, finalize).GetAwaiter().GetResult();
            }
            //--TRIMMABLE-BOUNDARY-END(17180508074)
            
            //--TRIMMABLE-BOUNDARY-START(21475475370)
            /*Task */ FeedAsync(/*TPipelineContext*/ context, /*PipelineDelegate<TPipelineContext>?*/ finalize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475475370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let pipeContext = (() =>
                {
                    //new $.$fXpo.LCFCPC.PipelineCollection$$(TPipelineContext).PipelineFeedingContext()
                    const $t1 = $.$fXpo.LCFCPC.PipelineCollection$$(TPipelineContext).PipelineFeedingContext;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Finalize$1 = finalize;
                    return $i1;
                })();
                return this.Feed(context, pipeContext);
            }
            //--TRIMMABLE-BOUNDARY-END(21475475370)
            
            //--TRIMMABLE-BOUNDARY-START(4295409578)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.Core.IPipelineCollection<TPipelineContext>.Except(params LivingThing.Core.Frameworks.Common.Pipeline.IPipeline<TPipelineContext>[])
            [`LCFCPC$IPipelineCollection$${TPipelineContext.$getFullName('$')}$Except`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295409578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Except(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295409578)
            
            //--TRIMMABLE-BOUNDARY-START(8590376874)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.Core.IPipelineCollection<TPipelineContext>.Feed(TPipelineContext, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<TPipelineContext>?)
            [`LCFCPC$IPipelineCollection$${TPipelineContext.$getFullName('$')}$Feed`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590376874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Feed$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590376874)
            
            //--TRIMMABLE-BOUNDARY-START(12885344170)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.Core.IPipelineCollection<TPipelineContext>.FeedAsync(TPipelineContext, LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<TPipelineContext>?)
            [`LCFCPC$IPipelineCollection$${TPipelineContext.$getFullName('$')}$FeedAsync`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885344170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FeedAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885344170)
            
            static $H = 638890;
            static $h = 638890;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590573482),
    {
      "r": $.$fXpo.LCFCPC.IPipelineCollection$$(TPipelineContext).$h,
      "p": [
        {
          "n": "excluded",
          "p": $.$typeArray($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
          "f": 16
        }
      ],
      "n": "Except",
      "d": this.$h,
      "H": 8590573482,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590573482),
//--TRIMMABLE-BOUNDARY-START(25770442666),
    {
      "r": $.$fXpo.LCFCPC.IPipelineCollection$$(TPipelineContext).$h,
      "p": [
        {
          "n": "filter",
          "p": $.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean).$h
        }
      ],
      "n": "Filter",
      "d": this.$h,
      "H": 25770442666,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770442666),
//--TRIMMABLE-BOUNDARY-START(38655344554),
    {
      "r": 262145,
      "p": [
        {
          "n": "pipeline",
          "p": $.$fXpo.LCFCP.IPipeline$$(TPipelineContext).$h
        }
      ],
      "n": "ShouldInclude",
      "d": this.$h,
      "H": 38655344554,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655344554),
//--TRIMMABLE-BOUNDARY-START(12885540778),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        },
        {
          "n": "pipeContext",
          "p": 704426
        }
      ],
      "n": "Feed",
      "d": this.$h,
      "H": 12885540778,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885540778),
//--TRIMMABLE-BOUNDARY-START(17180508074),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        },
        {
          "n": "finalize",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$(TPipelineContext).$h,
          "f": 65
        }
      ],
      "n": "Feed",
      "o": "@$1",
      "d": this.$h,
      "H": 17180508074,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180508074),
//--TRIMMABLE-BOUNDARY-START(21475475370),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        },
        {
          "n": "finalize",
          "p": $.$fXpo.LCFCP.PipelineDelegate$$(TPipelineContext).$h,
          "f": 65
        }
      ],
      "n": "FeedAsync",
      "d": this.$h,
      "H": 21475475370,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475475370)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360377258),
    {
      "t": $.$typeArray($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
      "n": "pipelines",
      "d": this.$h,
      "H": 34360377258,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360377258),
//--TRIMMABLE-BOUNDARY-START(30065409962),
    {
      "t": $.$$.SCG.List$$($.$$.S.Func$$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$$.S.Boolean)).$h,
      "n": "filters",
      "d": this.$h,
      "H": 30065409962,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065409962)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295606186),
    {
      "p": [
        {
          "n": "pipelines",
          "p": $.$typeArray($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295606186,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295606186)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 638890,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCPC.IPipelineCollection$$(TPipelineContext) ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$fXpo.LCFCPC.PipelineCollection$$(TPipelineContext).PipelineFeedingContext ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Core.PipelineCollection<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Core${separator}PipelineCollection$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(638890)
        
        

        //--TRIMMABLE-BOUNDARY-START(245674)
        $asm.$cls(`$fXpo.LCFCPA.ServiceFactoryPipelineActivator<,>`, (T, TPipelineContext) => $asm.$gt(`$fXpo.LCFCPA.ServiceFactoryPipelineActivator<,>`, [T, TPipelineContext], ($self) => class ServiceFactoryPipelineActivator$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885147562)
            /*ServiceFactory*/ factory = null;
            //--TRIMMABLE-BOUNDARY-END(12885147562)
            
            //--TRIMMABLE-BOUNDARY-START(4295212970)
            $ctor$1(/*ServiceFactory*/ factory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295212970);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.factory = factory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295212970)
            
            //--TRIMMABLE-BOUNDARY-START(8590180266)
            /*IEnumerable<IPipeline<TPipelineContext>> */ Activate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590180266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Select$1(T, $.$fXpo.LCFCP.IPipeline$$(TPipelineContext), $.$fPer.LCFCS$3.ServiceFactoryExtensions.GetInstances(T, this.factory), new ($.$$.S.Func$$$(T, $.$fXpo.LCFCP.IPipeline$$(TPipelineContext)))().$ctor(this,  (/*p*/ p) =>
                {
                    return $.$box(p, T);
                }, $iDNNIh ??= {"r":$.$fXpo.LCFCP.IPipeline$$(TPipelineContext).$h,"p":[{"n":"p","p":T?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8590180266)
            
            //--TRIMMABLE-BOUNDARY-START(4295868330)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Pipeline.IPipelineActivator<TPipelineContext>.Activate()
            [`LCFCP$IPipelineActivator$${TPipelineContext.$getFullName('$')}$Activate`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295868330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Activate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295868330)
            
            static $H = 245674;
            static $h = 245674;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590180266),
    {
      "r": $.$$.SCG.IEnumerable$$($.$fXpo.LCFCP.IPipeline$$(TPipelineContext)).$h,
      "n": "Activate",
      "d": this.$h,
      "H": 8590180266,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590180266)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885147562),
    {
      "t": 62949718,
      "n": "factory",
      "d": this.$h,
      "H": 12885147562,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885147562)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295212970),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295212970,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295212970)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "c": [$.$fXpo.LCFCP.IPipeline$$(TPipelineContext).$h
      ]
    },
    {
      "h": TPipelineContext?.$h??1638400,
      "n": "TPipelineContext"
    }
  ],
  "r": 2,
  "H": 245674,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fXpo.LCFCP.IPipelineActivator$$(TPipelineContext) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.Activators.ServiceFactoryPipelineActivator<${T?.$fullName},${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}Activators${separator}ServiceFactoryPipelineActivator$${T?.$getFullName(separator)}$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(245674)
        
        

        //--TRIMMABLE-BOUNDARY-START(966570)
        $asm.$cls(`$fXpo.LCFCP.PipelineDelegate<>`, (TPipelineContext) => $asm.$gt(`$fXpo.LCFCP.PipelineDelegate<>`, [TPipelineContext], ($self) => class PipelineDelegate$$ extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Task*/ Invoke(/**/ context)
            {
                return this.$nativeFunction.call(this.$target, context);
            }
            static $H = 966570;
            static $h = 966570;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180835754),
    {
      "r": 178454529,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 17180835754,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180835754),
//--TRIMMABLE-BOUNDARY-START(8590901162),
    {
      "r": 90570753,
      "p": [
        {
          "n": "context",
          "p": TPipelineContext?.$h??1572864
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "H": 8590901162,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590901162),
//--TRIMMABLE-BOUNDARY-START(12885868458),
    {
      "r": 178454529,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "H": 12885868458,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885868458)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295933866),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4295933866,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295933866)
  ],
  "s": [
    {
      "h": TPipelineContext?.$h??1572864,
      "n": "TPipelineContext"
    }
  ],
  "r": 1,
  "H": 966570,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Pipeline.PipelineDelegate<${TPipelineContext?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Pipeline${separator}PipelineDelegate$${TPipelineContext?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(966570)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(49066)
