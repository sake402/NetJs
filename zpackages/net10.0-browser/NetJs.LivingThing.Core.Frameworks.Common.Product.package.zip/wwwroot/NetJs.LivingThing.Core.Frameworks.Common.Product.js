
//--TRIMMABLE-BOUNDARY-START(46016)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt, $Iaui, $uvJL, $nYKj) {
    "use strict";
    let _;
    let $nxXzId;
    let $gcqIRa;
    let $AQxuwk;
    let $QXpiyf;
    let $iCWZNf;
    let $rzQBgi;
    let $OKTSlk;
    let $gAalrb;
    let $Mqrbgh;
    let $UUEwba;
    let $GjTZei;
    let $uHBqWb;
    let $rWwDQa;
    let $YmzZha;
    let $xawTHg;
    let $pUGyOj;
    let $BUThDa;
    let $rKxuCc;
    let $PWcxYd;
    let $QyJnli;
    let $WLHAge;
    let $IbpRib;
    let $YyBsbe;
    let $CMgXdf;
    let $jaJTac;
    let $kgmxNi;
    let $gEyfUc;
    let $rxESfk;
    let $BkvZKa;
    let $GTpEva;
    let $FoPkDi;
    let $Jmofnh;
    let $dajFpc;
    let $qslgPg;
    let $vqWrdf;
    let $ZcuPWc;
    let $VppTSi;
    let $jpcLia;
    let $yxiNIg;
    let $TeiBEj;
    let $nCsuPj;
    let $MhOCwg;
    let $XDGXcc;
    let $jNfcyb;
    let $aKLpOj;
    let $GXcEWg;
    let $cyvbnj;
    let $VgIvWd;
    let $PcxKEh;
    let $JcrwPa;
    let $xOcqDc;
    let $Yxvfba;
    let $xRonUe;
    let $XZonOh;
    let $qugmph;
    let $xkbuBk;
    let $JEoctf;
    let $RsFsqb;
    let $NzspZj;
    let $liwyib;
    let $QfmYfa;
    let $emlwpj;
    let $lsxnAd;
    let $rLcsSa;
    let $ymQcwi;
    let $kZQaVg;
    let $GRvTbi;
    let $xgGWSa;
    let $lmpCYg;
    let $lodVme;
    let $emznTj;
    let $LFWQbk;
    let $rGvLEd;
    let $iGedde;
    let $yugPgb;
    let $nRgiGg;
    let $nTohZk;
    let $aebDll;
    let $TQYUNc;
    let $reJcna;
    let $UKzTqb;
    let $gLjTlf;
    let $MGAXmf;
    let $uMOZtf;
    let $IZztnb;
    let $qVcmob;
    let $uTmnRd;
    let $TdLlAk;
    let $xLAwrg;
    let $ZMhyoe;
    let $FSsGJa;
    let $weRMah;
    let $WsTCrj;
    let $ljvMFa;
    let $BSORrb;
    let $PHhqal;
    let $zAfDQj;
    let $JyGHRi;
    let $cYRDCh;
    let $YfSSZj;
    let $YODzsi;
    let $UMlNxc;
    let $nnwDRb;
    let $goCwbd;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Product", 
    {
  "h": 46016,
  "f": "LivingThing.Core.Frameworks.Common.Product",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Product",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Product",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(3257280)
        $asm.$cls(`$AvdQ.LCFCP.IInvoicePayment`, ($self) => class IInvoicePayment
        {
            static $h = 3257280;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593191872),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773061056,
        "f": 50331905
      },
      "n": "Date",
      "o": "LCFCP$IInvoicePayment$Date",
      "d": 3257280,
      "h": 8593191872,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8593191872),
//--TRIMMABLE-BOUNDARY-START(4298224576),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183126464,
        "f": 50331905
      },
      "n": "Amount",
      "o": "LCFCP$IInvoicePayment$Amount",
      "d": 3257280,
      "h": 4298224576,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4298224576)
  ],
  "h": 3257280
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IInvoicePayment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IInvoicePayment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3257280)
        
        

        //--TRIMMABLE-BOUNDARY-START(2536384)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueSettings`, ($self) => class ICatalogueSettings
        {
            static $h = 2536384;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38657242048),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772340160,
        "f": 50331905
      },
      "n": "VATRate",
      "o": "LCFCP$ICatalogueSettings$VATRate",
      "d": 2536384,
      "h": 38657242048,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38657242048),
//--TRIMMABLE-BOUNDARY-START(30067307456),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592470976,
        "f": 50331905
      },
      "n": "Location",
      "o": "LCFCP$ICatalogueSettings$Location",
      "d": 2536384,
      "h": 30067307456,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30067307456),
//--TRIMMABLE-BOUNDARY-START(34362274752),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182405568,
        "f": 50331905
      },
      "n": "ReceiptPrologue",
      "o": "LCFCP$ICatalogueSettings$ReceiptPrologue",
      "d": 2536384,
      "h": 34362274752,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34362274752)
  ],
  "h": 2536384
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2536384)
        
        

        //--TRIMMABLE-BOUNDARY-START(4174784)
        $asm.$cls(`$AvdQ.LCFCP.IProductServicesClient`, ($self) => class IProductServicesClient
        {
            static $h = 4174784;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4174784
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IProductServicesClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IProductServicesClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4174784)
        
        

        //--TRIMMABLE-BOUNDARY-START(1881024)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueDeal`, ($self) => class ICatalogueDeal
        {
            static $h = 1881024;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656586688),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361619392,
        "f": 50331905
      },
      "n": "StartTime",
      "o": "LCFCP$ICatalogueDeal$StartTime",
      "d": 1881024,
      "h": 38656586688,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38656586688),
//--TRIMMABLE-BOUNDARY-START(8591815616),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771684800,
        "f": 50331905
      },
      "n": "EndTime",
      "o": "LCFCP$ICatalogueDeal$EndTime",
      "d": 1881024,
      "h": 8591815616,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591815616),
//--TRIMMABLE-BOUNDARY-START(4296848320),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181750208,
        "f": 50331905
      },
      "n": "DealCost",
      "o": "LCFCP$ICatalogueDeal$DealCost",
      "d": 1881024,
      "h": 4296848320,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296848320)
  ],
  "h": 1881024
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueDeal`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueDeal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1881024)
        
        

        //--TRIMMABLE-BOUNDARY-START(2077632)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueOrderItemModel`, ($self) => class ICatalogueOrderItemModel
        {
            //--TRIMMABLE-BOUNDARY-START(47246717888)
            /*Money */ get LCFCP$ICatalogueOrderItemModel$TotalAmount()
            {
                return $.$fPer.LCFCDM.Money.op_Addition($.$fPer.LCFCDM.Money.op_Multiply(this.LCFCP$ICatalogueOrderItemModel$Catalogue.LCFCP$ICatalogueModel$UnitCost, this.LCFCP$ICatalogueOrderItemModel$UnitQuantity), $.$fPer.LCFCDM.Money.op_Multiply(this.LCFCP$ICatalogueOrderItemModel$Catalogue.LCFCP$ICatalogueModel$PackCost, this.LCFCP$ICatalogueOrderItemModel$PackQuantity));
            }
            //--TRIMMABLE-BOUNDARY-END(47246717888)
            
            static $h = 2077632;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4297044928),
    {
      "p": 1946560,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886979520,
        "f": 50331905
      },
      "n": "Catalogue",
      "o": "LCFCP$ICatalogueOrderItemModel$Catalogue",
      "d": 2077632,
      "h": 4297044928,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4297044928),
//--TRIMMABLE-BOUNDARY-START(51541685184),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656783296,
        "f": 50331905
      },
      "n": "UnitQuantity",
      "o": "LCFCP$ICatalogueOrderItemModel$UnitQuantity",
      "d": 2077632,
      "h": 51541685184,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51541685184),
//--TRIMMABLE-BOUNDARY-START(42951750592),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476914112,
        "f": 50331905
      },
      "n": "PackQuantity",
      "o": "LCFCP$ICatalogueOrderItemModel$PackQuantity",
      "d": 2077632,
      "h": 42951750592,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42951750592),
//--TRIMMABLE-BOUNDARY-START(47246717888),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066848704,
        "f": 50331777
      },
      "n": "TotalAmount",
      "o": "LCFCP$ICatalogueOrderItemModel$TotalAmount",
      "d": 2077632,
      "h": 47246717888,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(47246717888)
  ],
  "h": 2077632
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueOrderItemModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueOrderItemModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2077632)
        
        

        //--TRIMMABLE-BOUNDARY-START(3126208)
        $asm.$cls(`$AvdQ.LCFCP.IInvoiceModel`, ($self) => class IInvoiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(197571621824)
            /*Money */ get LCFCP$IInvoiceModel$Total()
            {
                return new $.$fPer.LCFCDM.Money().$ctor$3($.$sl.SL.Enumerable.Sum$16($.$AvdQ.LCFCP.IInvoiceItem, this.LCFCP$IInvoiceModel$Catalogues, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoiceItem, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$fPer.LCFCDM.Money.op_Implicit(c.LCFCP$IInvoiceItem$DiscountedTotal);
                }, $jaJTac ??= {"r":1179649,"p":[{"n":"c","p":3060672}],"n":"","d":3126208,"h":0,"f":17825794})), 1/*MoneyUnitTypes.Naira*/);
            }
            //--TRIMMABLE-BOUNDARY-END(197571621824)
            
            //--TRIMMABLE-BOUNDARY-START(21477962688)
            /*Money */ get LCFCP$IInvoiceModel$DiscountCost()
            {
                return new $.$fPer.LCFCDM.Money().$ctor$3($.$sl.SL.Enumerable.Sum$16($.$AvdQ.LCFCP.IInvoiceItem, this.LCFCP$IInvoiceModel$Catalogues, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoiceItem, $.$$.S.Double))().$ctor(this,  (/**/ c) =>
                {
                    return $.$fPer.LCFCDM.Money.op_Implicit(c.LCFCP$IInvoiceItem$DiscountedTotal);
                }, $kgmxNi ??= {"r":1179649,"p":[{"n":"c","p":3060672}],"n":"","d":3126208,"h":0,"f":17825794})) * ((this.LCFCP$IInvoiceModel$Discount ?? 0) / 100), 1/*MoneyUnitTypes.Naira*/);
            }
            //--TRIMMABLE-BOUNDARY-END(21477962688)
            
            //--TRIMMABLE-BOUNDARY-START(201866589120)
            /*Money */ get LCFCP$IInvoiceModel$TotalDiscounted()
            {
                return new $.$fPer.LCFCDM.Money().$ctor$3($.$sl.SL.Enumerable.Sum$16($.$AvdQ.LCFCP.IInvoiceItem, this.LCFCP$IInvoiceModel$Catalogues, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoiceItem, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$fPer.LCFCDM.Money.op_Implicit(c.LCFCP$IInvoiceItem$DiscountedTotal);
                }, $gEyfUc ??= {"r":1179649,"p":[{"n":"c","p":3060672}],"n":"","d":3126208,"h":0,"f":17825794})) * ((100 - (this.LCFCP$IInvoiceModel$Discount ?? 0)) / 100), 1/*MoneyUnitTypes.Naira*/);
            }
            //--TRIMMABLE-BOUNDARY-END(201866589120)
            
            //--TRIMMABLE-BOUNDARY-START(206161556416)
            /*Money */ get LCFCP$IInvoiceModel$TotalPayments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916916160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.IInvoicePayment>?*/ let __ca1__;
                return new $.$fPer.LCFCDM.Money().$ctor$3(((__ca1__ = this.LCFCP$IInvoiceModel$Payments) !== null ? $.$sl.SL.Enumerable.Sum$16($.$AvdQ.LCFCP.IInvoicePayment, __ca1__, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.IInvoicePayment, $.$$.S.Double))().$ctor(this,  (/*c*/ c) =>
                {
                    return $.$fPer.LCFCDM.Money.op_Implicit(c.LCFCP$IInvoicePayment$Amount);
                }, $rxESfk ??= {"r":1179649,"p":[{"n":"c","p":3257280}],"n":"","d":3126208,"h":0,"f":17825794})) : 0), 1/*MoneyUnitTypes.Naira*/);
            }
            //--TRIMMABLE-BOUNDARY-END(206161556416)
            
            //--TRIMMABLE-BOUNDARY-START(4298093504)
            /*Money */ get LCFCP$IInvoiceModel$Balance()
            {
                return $.$fPer.LCFCDM.Money.op_Subtraction(this.LCFCP$IInvoiceModel$TotalDiscounted, this.LCFCP$IInvoiceModel$TotalPayments);
            }
            //--TRIMMABLE-BOUNDARY-END(4298093504)
            
            static $h = 3126208;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(193276654528),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133147112384,
        "f": 50331905
      },
      "n": "Title",
      "o": "LCFCP$IInvoiceModel$Title",
      "d": 3126208,
      "h": 193276654528,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(193276654528),
//--TRIMMABLE-BOUNDARY-START(171801818048),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197439424,
        "f": 50331905
      },
      "n": "InvoiceNumber",
      "o": "LCFCP$IInvoiceModel$InvoiceNumber",
      "d": 3126208,
      "h": 171801818048,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(171801818048),
//--TRIMMABLE-BOUNDARY-START(163211883456),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017570240,
        "f": 50331905
      },
      "n": "InvoiceDate",
      "o": "LCFCP$IInvoiceModel$InvoiceDate",
      "d": 3126208,
      "h": 163211883456,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(163211883456),
//--TRIMMABLE-BOUNDARY-START(176096785344),
    {
      "p": 5081430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787374016,
        "f": 50331905
      },
      "n": "InvoiceTo",
      "o": "LCFCP$IInvoiceModel$InvoiceTo",
      "d": 3126208,
      "h": 176096785344,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(176096785344),
//--TRIMMABLE-BOUNDARY-START(167506850752),
    {
      "p": 5081430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607504832,
        "f": 50331905
      },
      "n": "InvoiceFrom",
      "o": "LCFCP$IInvoiceModel$InvoiceFrom",
      "d": 3126208,
      "h": 167506850752,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(167506850752),
//--TRIMMABLE-BOUNDARY-START(184686719936),
    {
      "p": 3912640,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115967243200,
        "f": 50331905
      },
      "n": "Payment",
      "o": "LCFCP$IInvoiceModel$Payment",
      "d": 3126208,
      "h": 184686719936,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(184686719936),
//--TRIMMABLE-BOUNDARY-START(8593060800),
    {
      "p": 5474646,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657831872,
        "f": 50331905
      },
      "n": "Bank",
      "o": "LCFCP$IInvoiceModel$Bank",
      "d": 3126208,
      "h": 8593060800,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8593060800),
//--TRIMMABLE-BOUNDARY-START(12888028096),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247766464,
        "f": 50331905
      },
      "n": "Catalogues",
      "o": "LCFCP$IInvoiceModel$Catalogues",
      "d": 3126208,
      "h": 12888028096,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12888028096),
//--TRIMMABLE-BOUNDARY-START(188981687232),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoicePayment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124557177792,
        "f": 50331905
      },
      "n": "Payments",
      "o": "LCFCP$IInvoiceModel$Payments",
      "d": 3126208,
      "h": 188981687232,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(188981687232),
//--TRIMMABLE-BOUNDARY-START(17182995392),
    {
      "p": $.$typeNullable($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837701056,
        "f": 50331905
      },
      "n": "Discount",
      "o": "LCFCP$IInvoiceModel$Discount",
      "d": 3126208,
      "h": 17182995392,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17182995392),
//--TRIMMABLE-BOUNDARY-START(180391752640),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107377308608,
        "f": 50331905
      },
      "n": "MinimumPartPayment",
      "o": "LCFCP$IInvoiceModel$MinimumPartPayment",
      "d": 3126208,
      "h": 180391752640,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(180391752640),
//--TRIMMABLE-BOUNDARY-START(197571621824),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141737046976,
        "f": 50331777
      },
      "n": "Total",
      "o": "LCFCP$IInvoiceModel$Total",
      "d": 3126208,
      "h": 197571621824,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(197571621824),
//--TRIMMABLE-BOUNDARY-START(21477962688),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427635648,
        "f": 50331777
      },
      "n": "DiscountCost",
      "o": "LCFCP$IInvoiceModel$DiscountCost",
      "d": 3126208,
      "h": 21477962688,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21477962688),
//--TRIMMABLE-BOUNDARY-START(201866589120),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150326981568,
        "f": 50331777
      },
      "n": "TotalDiscounted",
      "o": "LCFCP$IInvoiceModel$TotalDiscounted",
      "d": 3126208,
      "h": 201866589120,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(201866589120),
//--TRIMMABLE-BOUNDARY-START(206161556416),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158916916160,
        "f": 50331777
      },
      "n": "TotalPayments",
      "o": "LCFCP$IInvoiceModel$TotalPayments",
      "d": 3126208,
      "h": 206161556416,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(206161556416),
//--TRIMMABLE-BOUNDARY-START(4298093504),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067897280,
        "f": 50331777
      },
      "n": "Balance",
      "o": "LCFCP$IInvoiceModel$Balance",
      "d": 3126208,
      "h": 4298093504,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(4298093504)
  ],
  "h": 3126208
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IInvoiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IInvoiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3126208)
        
        

        //--TRIMMABLE-BOUNDARY-START(2929600)
        $asm.$cls(`$AvdQ.LCFCP.IEditableCatalogueOrderItemModel`, ($self) => class IEditableCatalogueOrderItemModel
        {
            static $h = 2929600;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4297896896),
    {
      "p": 2798528,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887831488,
        "f": 50331905
      },
      "n": "Catalogue",
      "o": "LCFCP$IEditableCatalogueOrderItemModel$Catalogue",
      "d": 2929600,
      "h": 4297896896,
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(4297896896),
//--TRIMMABLE-BOUNDARY-START(55837504448),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067700672,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51542537152,
        "f": 83886337
      },
      "n": "UnitQuantity",
      "o": "LCFCP$IEditableCatalogueOrderItemModel$UnitQuantity",
      "d": 2929600,
      "h": 55837504448,
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(55837504448),
//--TRIMMABLE-BOUNDARY-START(34362667968),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477766080,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42952602560,
        "f": 83886337
      },
      "n": "PackQuantity",
      "o": "LCFCP$IEditableCatalogueOrderItemModel$PackQuantity",
      "d": 2929600,
      "h": 34362667968,
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(34362667968)
  ],
  "h": 2929600
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueOrderItemModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IEditableCatalogueOrderItemModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IEditableCatalogueOrderItemModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2929600)
        
        

        //--TRIMMABLE-BOUNDARY-START(3060672)
        $asm.$cls(`$AvdQ.LCFCP.IInvoiceItem`, ($self) => class IInvoiceItem
        {
            //--TRIMMABLE-BOUNDARY-START(12887962560)
            /*Money */ get LCFCP$IInvoiceItem$DiscountedCost()
            {
                return $.$fPer.LCFCDM.Money.op_Implicit$1((this.LCFCP$IInvoiceItem$Discount ?? 0) / 100) * $.$fPer.LCFCDM.Money.op_Implicit(this.LCFCP$IInvoiceItem$Cost);
            }
            //--TRIMMABLE-BOUNDARY-END(12887962560)
            
            //--TRIMMABLE-BOUNDARY-START(77312472000)
            /*Money */ get LCFCP$IInvoiceItem$Total()
            {
                return $.$fPer.LCFCDM.Money.op_Multiply(this.LCFCP$IInvoiceItem$Cost, this.LCFCP$IInvoiceItem$Quantity);
            }
            //--TRIMMABLE-BOUNDARY-END(77312472000)
            
            //--TRIMMABLE-BOUNDARY-START(8592995264)
            /*double? */ get LCFCP$IInvoiceItem$Discount()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8592995264)
            
            //--TRIMMABLE-BOUNDARY-START(17182929856)
            /*Money */ get LCFCP$IInvoiceItem$DiscountedTotal()
            {
                return $.$fPer.LCFCDM.Money.op_Implicit$1((100 - (this.LCFCP$IInvoiceItem$Discount ?? 0)) / 100) * $.$fPer.LCFCDM.Money.op_Implicit(this.LCFCP$IInvoiceItem$Total);
            }
            //--TRIMMABLE-BOUNDARY-END(17182929856)
            
            static $h = 3060672;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4298027968),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772864448,
        "f": 50331905
      },
      "n": "Cost",
      "o": "LCFCP$IInvoiceItem$Cost",
      "d": 3060672,
      "h": 4298027968,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4298027968),
//--TRIMMABLE-BOUNDARY-START(73017504704),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132602816,
        "f": 50331905
      },
      "n": "Quantity",
      "o": "LCFCP$IInvoiceItem$Quantity",
      "d": 3060672,
      "h": 73017504704,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(73017504704),
//--TRIMMABLE-BOUNDARY-START(12887962560),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952733632,
        "f": 50331777
      },
      "n": "DiscountedCost",
      "o": "LCFCP$IInvoiceItem$DiscountedCost",
      "d": 3060672,
      "h": 12887962560,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(12887962560),
//--TRIMMABLE-BOUNDARY-START(77312472000),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722537408,
        "f": 50331777
      },
      "n": "Total",
      "o": "LCFCP$IInvoiceItem$Total",
      "d": 3060672,
      "h": 77312472000,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(77312472000),
//--TRIMMABLE-BOUNDARY-START(8592995264),
    {
      "p": $.$typeNullable($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362799040,
        "f": 50331777
      },
      "n": "Discount",
      "o": "LCFCP$IInvoiceItem$Discount",
      "d": 3060672,
      "h": 8592995264,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(8592995264),
//--TRIMMABLE-BOUNDARY-START(17182929856),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542668224,
        "f": 50331777
      },
      "n": "DiscountedTotal",
      "o": "LCFCP$IInvoiceItem$DiscountedTotal",
      "d": 3060672,
      "h": 17182929856,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(17182929856)
  ],
  "h": 3060672
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IInvoiceItem`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IInvoiceItem`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3060672)
        
        

        //--TRIMMABLE-BOUNDARY-START(2208704)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueOrderModel`, ($self) => class ICatalogueOrderModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297176000)
            /*Money */ get LCFCP$ICatalogueOrderModel$Amount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182077888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.ICatalogueOrderItemModel>?*/ let __ca1__;
                return $.$fPer.LCFCDM.Money.op_Implicit$1((__ca1__ = this.LCFCP$ICatalogueOrderModel$Items) !== null ? $.$sl.SL.Enumerable.Sum$16($.$AvdQ.LCFCP.ICatalogueOrderItemModel, __ca1__, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel, $.$$.S.Double))().$ctor(this,  (/*i*/ i) =>
                {
                    return $.$fPer.LCFCDM.Money.op_Implicit(i.LCFCP$ICatalogueOrderItemModel$TotalAmount);
                }, $Mqrbgh ??= {"r":1179649,"p":[{"n":"i","p":2077632}],"n":"","d":2208704,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(4297176000)
            
            static $h = 2208704;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592143296),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772012480,
        "f": 50331905
      },
      "n": "DateCreated",
      "o": "LCFCP$ICatalogueOrderModel$DateCreated",
      "d": 2208704,
      "h": 8592143296,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8592143296),
//--TRIMMABLE-BOUNDARY-START(38656914368),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueOrderItemModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361947072,
        "f": 50331905
      },
      "n": "Items",
      "o": "LCFCP$ICatalogueOrderModel$Items",
      "d": 2208704,
      "h": 38656914368,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38656914368),
//--TRIMMABLE-BOUNDARY-START(4297176000),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182077888,
        "f": 50331777
      },
      "n": "Amount",
      "o": "LCFCP$ICatalogueOrderModel$Amount",
      "d": 2208704,
      "h": 4297176000,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(4297176000)
  ],
  "h": 2208704
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueOrderModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueOrderModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2208704)
        
        

        //--TRIMMABLE-BOUNDARY-START(1749952)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueCategoryModel`, ($self) => class ICatalogueCategoryModel
        {
            static $h = 1749952;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656455616),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066521024,
        "f": 50331905
      },
      "n": "SKU",
      "o": "LCFCP$ICatalogueCategoryModel$SKU",
      "d": 1749952,
      "h": 38656455616,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38656455616),
//--TRIMMABLE-BOUNDARY-START(34361488320),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476586432,
        "f": 50331905
      },
      "n": "Link",
      "o": "LCFCP$ICatalogueCategoryModel$Link",
      "d": 1749952,
      "h": 34361488320,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34361488320),
//--TRIMMABLE-BOUNDARY-START(4296717248),
    {
      "p": 504768,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886651840,
        "f": 50331905
      },
      "n": "Flags",
      "o": "LCFCP$ICatalogueCategoryModel$Flags",
      "d": 1749952,
      "h": 4296717248,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296717248)
  ],
  "h": 1749952
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueCategoryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueCategoryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1749952)
        
        

        //--TRIMMABLE-BOUNDARY-START(2339776)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueProvider`, ($self) => class ICatalogueProvider
        {
            //--TRIMMABLE-BOUNDARY-START(64426849216)
            /*Pager<IPaymentTier>? */ get LCFCP$IPaymentTierProvider$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131881920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.Frameworks.Common.Data.Pager<LivingThing.Core.Frameworks.Common.Product.IProductCatalogueModel>?*/ let __ca1__;
                /*LivingThing.Core.Frameworks.Common.Data.Pager<LivingThing.Core.Frameworks.Common.Product.IServiceCatalogueModel>?*/ let __ca2__;
                return $.$fPer.LCFCD.Paging.Concat($.$nYKj.LCFCP.IPaymentTier, ((__ca1__ = this.LCFCP$ICatalogueProvider$Products) !== null ? $.$fPer.LCFCD.Paging.Cast$1($.$AvdQ.LCFCP.IProductCatalogueModel, $.$nYKj.LCFCP.IPaymentTier, __ca1__) : null), ((__ca2__ = this.LCFCP$ICatalogueProvider$Services) !== null ? $.$fPer.LCFCD.Paging.Cast$1($.$AvdQ.LCFCP.IServiceCatalogueModel, $.$nYKj.LCFCP.IPaymentTier, __ca2__) : null), true);
            }
            //--TRIMMABLE-BOUNDARY-END(64426849216)
            
            static $h = 2339776;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592274368),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ICatalogueCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772143552,
        "f": 50331905
      },
      "n": "Categories",
      "o": "LCFCP$ICatalogueProvider$Categories",
      "d": 2339776,
      "h": 8592274368,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8592274368),
//--TRIMMABLE-BOUNDARY-START(4297307072),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ICatalogueCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182208960,
        "f": 50331905
      },
      "n": "Brands",
      "o": "LCFCP$ICatalogueProvider$Brands",
      "d": 2339776,
      "h": 4297307072,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4297307072),
//--TRIMMABLE-BOUNDARY-START(68721816512),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.IProductCatalogueModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362078144,
        "f": 50331905
      },
      "n": "Products",
      "o": "LCFCP$ICatalogueProvider$Products",
      "d": 2339776,
      "h": 68721816512,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(68721816512),
//--TRIMMABLE-BOUNDARY-START(73016783808),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.IServiceCatalogueModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952012736,
        "f": 50331905
      },
      "n": "Services",
      "o": "LCFCP$ICatalogueProvider$Services",
      "d": 2339776,
      "h": 73016783808,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(73016783808),
//--TRIMMABLE-BOUNDARY-START(77311751104),
    {
      "p": 2536384,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541947328,
        "f": 50331905
      },
      "n": "Settings",
      "o": "LCFCP$ICatalogueProvider$Settings",
      "d": 2339776,
      "h": 77311751104,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(77311751104),
//--TRIMMABLE-BOUNDARY-START(64426849216),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131881920,
        "f": 50331650
      },
      "n": "{1001240}.ServiceTiers",
      "o": "LCFCP$IPaymentTierProvider$ServiceTiers",
      "d": 2339776,
      "h": 64426849216,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64426849216)
  ],
  "h": 2339776
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2339776)
        
        

        //--TRIMMABLE-BOUNDARY-START(2470848)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueProvider<,>`, (TServiceTierType, TFeatureType) => $asm.$gt(`$AvdQ.LCFCP.ICatalogueProvider<,>`, [TServiceTierType, TFeatureType], ($self) => class ICatalogueProvider$$$
        {
            //--TRIMMABLE-BOUNDARY-START(30067241920)
            /*Pager<ICatalogueCategoryModel>? */ get LCFCP$ICatalogueProvider$Categories()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(30067241920)
            
            //--TRIMMABLE-BOUNDARY-START(25772274624)
            /*Pager<ICatalogueCategoryModel>? */ get LCFCP$ICatalogueProvider$Brands()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(25772274624)
            
            //--TRIMMABLE-BOUNDARY-START(77311882176)
            /*Pager<IProductCatalogueModel>? */ get LCFCP$ICatalogueProvider$Products()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(77311882176)
            
            //--TRIMMABLE-BOUNDARY-START(81606849472)
            /*Pager<IServiceCatalogueModel>? */ get LCFCP$ICatalogueProvider$Services()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(81606849472)
            
            //--TRIMMABLE-BOUNDARY-START(85901816768)
            /*ICatalogueSettings? */ get LCFCP$ICatalogueProvider$Settings()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(85901816768)
            
            //--TRIMMABLE-BOUNDARY-START(21477307328)
            /*Pager<IPaymentTier>? */ get LCFCP$IPaymentTierProvider$ServiceTiers()
            {
                return $.$fPer.LCFCD.Paging.Cast$1($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatureType), $.$nYKj.LCFCP.IPaymentTier, this.LCFCP$ICatalogueProvider$$$$ServiceTiers);
            }
            //--TRIMMABLE-BOUNDARY-END(21477307328)
            
            static $H = 2470848;
            static $h = 2470848;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067241920),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ICatalogueCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47247111104,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331650
      },
      "n": "{2339776}.Categories",
      "o": "LCFCP$ICatalogueProvider$Categories",
      "d": this.$h,
      "H": 30067241920,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30067241920),
//--TRIMMABLE-BOUNDARY-START(25772274624),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ICatalogueCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38657176512,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331650
      },
      "n": "{2339776}.Brands",
      "o": "LCFCP$ICatalogueProvider$Brands",
      "d": this.$h,
      "H": 25772274624,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25772274624),
//--TRIMMABLE-BOUNDARY-START(77311882176),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.IProductCatalogueModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55837045696,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331650
      },
      "n": "{2339776}.Products",
      "o": "LCFCP$ICatalogueProvider$Products",
      "d": this.$h,
      "H": 77311882176,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(77311882176),
//--TRIMMABLE-BOUNDARY-START(81606849472),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.IServiceCatalogueModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64426980288,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331650
      },
      "n": "{2339776}.Services",
      "o": "LCFCP$ICatalogueProvider$Services",
      "d": this.$h,
      "H": 81606849472,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(81606849472),
//--TRIMMABLE-BOUNDARY-START(85901816768),
    {
      "p": 2536384,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73016914880,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331650
      },
      "n": "{2339776}.Settings",
      "o": "LCFCP$ICatalogueProvider$Settings",
      "d": this.$h,
      "H": 85901816768,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(85901816768),
//--TRIMMABLE-BOUNDARY-START(90196784064),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatureType)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 8592405440,
        "h": Number(BigInt(this.$h)|0x200000000n),
        "f": 50331905
      },
      "n": "ServiceTiers",
      "o": "LCFCP$ICatalogueProvider$$$$ServiceTiers",
      "d": this.$h,
      "H": 90196784064,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(90196784064),
//--TRIMMABLE-BOUNDARY-START(21477307328),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17182340032,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331650
      },
      "n": "{1001240}.ServiceTiers",
      "o": "LCFCP$IPaymentTierProvider$ServiceTiers",
      "d": this.$h,
      "H": 21477307328,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21477307328)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TFeatureType?.$h??1638400,
      "n": "TFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 2470848,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider<${TServiceTierType?.$fullName},${TFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueProvider$${TServiceTierType?.$getFullName(separator)}$${TFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2470848)
        
        

        //--TRIMMABLE-BOUNDARY-START(2405312)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueProvider<,,>`, (/*out*/ TDisiciminator, TServiceTierType, TFeatureType) => $asm.$gt(`$AvdQ.LCFCP.ICatalogueProvider<,,>`, [/*out*/ TDisiciminator, TServiceTierType, TFeatureType], ($self) => class ICatalogueProvider$$$$
        {
            static $H = 2405312;
            static $h = 2405312;
            static $g = 3;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TDisiciminator?.$h??1572864,
      "n": "TDisiciminator",
      "f": 32
    },
    {
      "h": TServiceTierType?.$h??1638400,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TFeatureType?.$h??1703936,
      "n": "TFeatureType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 3,
  "H": 2405312,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueProvider$$$(TServiceTierType, TFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider<${TDisiciminator?.$fullName},${TServiceTierType?.$fullName},${TFeatureType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueProvider$${TDisiciminator?.$getFullName(separator)}$${TServiceTierType?.$getFullName(separator)}$${TFeatureType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2405312)
        
        

        //--TRIMMABLE-BOUNDARY-START(1946560)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueModel`, ($self) => class ICatalogueModel
        {
            //--TRIMMABLE-BOUNDARY-START(304944624576)
            /*string? */ get LCFCP$IPaymentTier$Id()
            {
                return this.LCFCP$ICatalogueModel$SKU;
            }
            //--TRIMMABLE-BOUNDARY-END(304944624576)
            
            //--TRIMMABLE-BOUNDARY-START(17181815744)
            /*IEnumerable<string>? */ get LCFCP$ICatalogueModel$Categories()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(17181815744)
            
            //--TRIMMABLE-BOUNDARY-START(240520115136)
            /*DateTime? */ get LCFCP$ICatalogueModel$LaunchDate()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(240520115136)
            
            //--TRIMMABLE-BOUNDARY-START(352189264832)
            /*int */ get LCFCP$ICatalogueModel$UnitQuantity()
            {
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(352189264832)
            
            //--TRIMMABLE-BOUNDARY-START(266289918912)
            /*Money */ get LCFCP$IPaymentTier$Cost()
            {
                return this.LCFCP$ICatalogueModel$UnitCost;
            }
            //--TRIMMABLE-BOUNDARY-END(266289918912)
            
            //--TRIMMABLE-BOUNDARY-START(322124493760)
            /*Money */ get LCFCP$ICatalogueModel$PackCost()
            {
                return new $.$fPer.LCFCDM.Money();
            }
            //--TRIMMABLE-BOUNDARY-END(322124493760)
            
            //--TRIMMABLE-BOUNDARY-START(326419461056)
            /*int */ get LCFCP$ICatalogueModel$PackQuantity()
            {
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(326419461056)
            
            //--TRIMMABLE-BOUNDARY-START(347894297536)
            /*int */ get LCFCP$ICatalogueModel$UnitInPack()
            {
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(347894297536)
            
            //--TRIMMABLE-BOUNDARY-START(317829526464)
            /*Money? */ get LCFCP$ICatalogueModel$OldCost()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(317829526464)
            
            //--TRIMMABLE-BOUNDARY-START(4296913856)
            /*IEnumerable<CatalogueAccessories>? */ get LCFCP$ICatalogueModel$Accessories()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4296913856)
            
            //--TRIMMABLE-BOUNDARY-START(223340245952)
            /*IEnumerable<CatalogueAccessories>? */ LCFCP$ICatalogueModel$GetAccessories(/*ICatalogueVariantModel?*/ variant)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340245952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.CatalogueAccessories>?*/ let __ca1__;
                return _ = ((__ca1__ = this.LCFCP$ICatalogueModel$Accessories) !== null ? $.$sl.SL.Enumerable.Where($.$AvdQ.LCFCP.CatalogueAccessories, __ca1__, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.CatalogueAccessories, $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    /*LivingThing.Core.Frameworks.Common.Product.ICatalogueVariantModel?*/ let __ca2__;
                    /*System.Collections.Generic.IEnumerable<string>?*/ let __ca3__;
                    return e.SKU === null || (((__ca2__ = variant) !== null ? ((__ca3__ = __ca2__.LCFCP$ICatalogueVariantModel$AccessoriesId) !== null ? $.$sl.SL.Enumerable.Contains$1($.$$.S.String, __ca3__, e.SKU) : false) : false));
                }, $FoPkDi ??= {"r":262145,"p":[{"n":"e","p":308160}],"n":"","d":1946560,"h":0,"f":17825794})) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(223340245952)
            
            //--TRIMMABLE-BOUNDARY-START(227635213248)
            /*Money */ LCFCP$ICatalogueModel$GetCost(/*ICatalogueVariantModel?*/ variant)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635213248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (variant === null)
                {
                    return $.$clone(this.LCFCP$ICatalogueModel$UnitCost);
                }
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.CatalogueAccessories>?*/ let __ca4__;
                /*var*/ let accCost = ((__ca4__ = this.LCFCP$ICatalogueModel$GetAccessories(variant)) !== null ? $.$sl.SL.Enumerable.Aggregate$2($.$fPer.LCFCDM.Money, $.$sl.SL.Enumerable.Select$1($.$AvdQ.LCFCP.CatalogueAccessories, $.$fPer.LCFCDM.Money, __ca4__, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.CatalogueAccessories, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.Cost;
                }, $Jmofnh ??= {"r":27822422,"p":[{"n":"c","p":308160}],"n":"","d":1946560,"h":0,"f":17825794})), new ($.$$.S.Func$$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*a*/ a, /**/ b) =>
                {
                    return $.$fPer.LCFCDM.Money.op_Addition(a, b);
                }, $dajFpc ??= {"r":27822422,"p":[{"n":"a","p":27822422},{"n":"b","p":27822422}],"n":"","d":1946560,"h":0,"f":17825794})) : new $.$fPer.LCFCDM.Money());
                return $.$fPer.LCFCDM.Money.op_Addition(this.LCFCP$ICatalogueModel$UnitCost, accCost);
            }
            //--TRIMMABLE-BOUNDARY-END(227635213248)
            
            //--TRIMMABLE-BOUNDARY-START(231930180544)
            /*Money */ LCFCP$ICatalogueModel$GetOldCost(/*ICatalogueVariantModel?*/ variant)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930180544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (variant === null)
                {
                    return this.LCFCP$ICatalogueModel$OldCost ?? new $.$fPer.LCFCDM.Money();
                }
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.CatalogueAccessories>?*/ let __ca5__;
                /*var*/ let accOldCost = ((__ca5__ = this.LCFCP$ICatalogueModel$GetAccessories(variant)) !== null ? $.$sl.SL.Enumerable.Aggregate$2($.$fPer.LCFCDM.Money, $.$sl.SL.Enumerable.Select$1($.$AvdQ.LCFCP.CatalogueAccessories, $.$fPer.LCFCDM.Money, __ca5__, new ($.$$.S.Func$$$($.$AvdQ.LCFCP.CatalogueAccessories, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.OldCost ?? new $.$fPer.LCFCDM.Money();
                }, $qslgPg ??= {"r":27822422,"p":[{"n":"c","p":308160}],"n":"","d":1946560,"h":0,"f":17825794})), new ($.$$.S.Func$$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*a*/ a, /*b*/ b) =>
                {
                    return $.$fPer.LCFCDM.Money.op_Addition(a, b);
                }, $vqWrdf ??= {"r":27822422,"p":[{"n":"a","p":27822422},{"n":"b","p":27822422}],"n":"","d":1946560,"h":0,"f":17825794})) : new $.$fPer.LCFCDM.Money());
                return $.$fPer.LCFCDM.Money.op_Addition((this.LCFCP$ICatalogueModel$OldCost ?? new $.$fPer.LCFCDM.Money()), accOldCost);
            }
            //--TRIMMABLE-BOUNDARY-END(231930180544)
            
            //--TRIMMABLE-BOUNDARY-START(25771750336)
            /*IEnumerable<CatalogueFeature>? */ get LCFCP$ICatalogueModel$Features()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(25771750336)
            
            //--TRIMMABLE-BOUNDARY-START(356484232128)
            /*IEnumerable<CatalogueUseCase>? */ get LCFCP$ICatalogueModel$UseCases()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(356484232128)
            
            //--TRIMMABLE-BOUNDARY-START(12886848448)
            /*IEnumerable<CatalogueBenefit>? */ get LCFCP$ICatalogueModel$Benefits()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(12886848448)
            
            //--TRIMMABLE-BOUNDARY-START(335009395648)
            /*IEnumerable<CatalogueSpecification>? */ get LCFCP$ICatalogueModel$Specifications()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(335009395648)
            
            //--TRIMMABLE-BOUNDARY-START(360779199424)
            /*IEnumerable<ICatalogueVariantModel>? */ get LCFCP$ICatalogueModel$Variants()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(360779199424)
            
            //--TRIMMABLE-BOUNDARY-START(309239591872)
            /*Pager<IPaymentTier>? */ get LCFCP$IPaymentTier$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059722688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Product.ICatalogueVariantModel>?*/ let __ca6__;
                return _ = ((__ca6__ = this.LCFCP$ICatalogueModel$Variants) !== null ? $.$fPer.LCFCD.Paging.GetPager($.$nYKj.LCFCP.IPaymentTier, $.$sl.SL.Enumerable.Cast($.$nYKj.LCFCP.IPaymentTier, __ca6__), null) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(309239591872)
            
            //--TRIMMABLE-BOUNDARY-START(365074166720)
            /*IEnumerable<CatalogueVideo>? */ get LCFCP$ICatalogueModel$Videos()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(365074166720)
            
            //--TRIMMABLE-BOUNDARY-START(21476783040)
            /*IEnumerable<ICatalogueDeal>? */ get LCFCP$ICatalogueModel$Deals()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21476783040)
            
            //--TRIMMABLE-BOUNDARY-START(244815082432)
            /*string? */ get LCFCP$ICatalogueModel$Link()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(244815082432)
            
            //--TRIMMABLE-BOUNDARY-START(339304362944)
            /*IEnumerable<TagModel>? */ get LCFCP$ICatalogueModel$Tags()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(339304362944)
            
            //--TRIMMABLE-BOUNDARY-START(261994951616)
            /*IParentHierachy? */ get LCFCD$IParentHierachy$Parent()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(261994951616)
            
            //--TRIMMABLE-BOUNDARY-START(249110049728)
            /*ValueTask<IEnumerable<IChildrenHierachy>?> */ LCFCD$IChildrenHierachy$GetChildren()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249110049728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.ValueTask.FromResult($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy), null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249110049728)
            
            //--TRIMMABLE-BOUNDARY-START(313534559168)
            /*Enum? */ get LCFCP$IPaymentTier$Tier()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(313534559168)
            
            static $h = 1946560;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(330714428352),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325801920,
        "f": 50331905
      },
      "n": "SKU",
      "o": "LCFCP$ICatalogueModel$SKU",
      "d": 1946560,
      "h": 330714428352,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(330714428352),
//--TRIMMABLE-BOUNDARY-START(304944624576),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283469788096,
        "f": 50331650
      },
      "n": "{739096}.Id",
      "o": "LCFCP$IPaymentTier$Id",
      "d": 1946560,
      "h": 304944624576,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(304944624576),
//--TRIMMABLE-BOUNDARY-START(17181815744),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426456000,
        "f": 50331777
      },
      "n": "Categories",
      "o": "LCFCP$ICatalogueModel$Categories",
      "d": 1946560,
      "h": 17181815744,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(17181815744),
//--TRIMMABLE-BOUNDARY-START(30066717632),
    {
      "p": 832448,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196259776,
        "f": 50331905
      },
      "n": "Flags",
      "o": "LCFCP$ICatalogueModel$Flags",
      "d": 1946560,
      "h": 30066717632,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30066717632),
//--TRIMMABLE-BOUNDARY-START(8591881152),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246586816,
        "f": 50331905
      },
      "n": "BannerImage",
      "o": "LCFCP$ICatalogueModel$BannerImage",
      "d": 1946560,
      "h": 8591881152,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591881152),
//--TRIMMABLE-BOUNDARY-START(236225147840),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786194368,
        "f": 50331905
      },
      "n": "Images",
      "o": "LCFCP$ICatalogueModel$Images",
      "d": 1946560,
      "h": 236225147840,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(236225147840),
//--TRIMMABLE-BOUNDARY-START(240520115136),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376128960,
        "f": 50331777
      },
      "n": "LaunchDate",
      "o": "LCFCP$ICatalogueModel$LaunchDate",
      "d": 1946560,
      "h": 240520115136,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(240520115136),
//--TRIMMABLE-BOUNDARY-START(343599330240),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095605696,
        "f": 50331905
      },
      "n": "UnitCost",
      "o": "LCFCP$ICatalogueModel$UnitCost",
      "d": 1946560,
      "h": 343599330240,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(343599330240),
//--TRIMMABLE-BOUNDARY-START(352189264832),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193275474880,
        "f": 50331777
      },
      "n": "UnitQuantity",
      "o": "LCFCP$ICatalogueModel$UnitQuantity",
      "d": 1946560,
      "h": 352189264832,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(352189264832),
//--TRIMMABLE-BOUNDARY-START(266289918912),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274879853504,
        "f": 50331650
      },
      "n": "{739096}.Cost",
      "o": "LCFCP$IPaymentTier$Cost",
      "d": 1946560,
      "h": 266289918912,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(266289918912),
//--TRIMMABLE-BOUNDARY-START(322124493760),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145932736,
        "f": 50331777
      },
      "n": "PackCost",
      "o": "LCFCP$ICatalogueModel$PackCost",
      "d": 1946560,
      "h": 322124493760,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(322124493760),
//--TRIMMABLE-BOUNDARY-START(326419461056),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735867328,
        "f": 50331777
      },
      "n": "PackQuantity",
      "o": "LCFCP$ICatalogueModel$PackQuantity",
      "d": 1946560,
      "h": 326419461056,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(326419461056),
//--TRIMMABLE-BOUNDARY-START(347894297536),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685540288,
        "f": 50331777
      },
      "n": "UnitInPack",
      "o": "LCFCP$ICatalogueModel$UnitInPack",
      "d": 1946560,
      "h": 347894297536,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(347894297536),
//--TRIMMABLE-BOUNDARY-START(317829526464),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555998144,
        "f": 50331777
      },
      "n": "OldCost",
      "o": "LCFCP$ICatalogueModel$OldCost",
      "d": 1946560,
      "h": 317829526464,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(317829526464),
//--TRIMMABLE-BOUNDARY-START(4296913856),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueAccessories).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656652224,
        "f": 50331777
      },
      "n": "Accessories",
      "o": "LCFCP$ICatalogueModel$Accessories",
      "d": 1946560,
      "h": 4296913856,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(4296913856),
//--TRIMMABLE-BOUNDARY-START(25771750336),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueFeature).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606325184,
        "f": 50331777
      },
      "n": "Features",
      "o": "LCFCP$ICatalogueModel$Features",
      "d": 1946560,
      "h": 25771750336,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25771750336),
//--TRIMMABLE-BOUNDARY-START(356484232128),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueUseCase).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201865409472,
        "f": 50331777
      },
      "n": "UseCases",
      "o": "LCFCP$ICatalogueModel$UseCases",
      "d": 1946560,
      "h": 356484232128,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(356484232128),
//--TRIMMABLE-BOUNDARY-START(12886848448),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueBenefit).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836521408,
        "f": 50331777
      },
      "n": "Benefits",
      "o": "LCFCP$ICatalogueModel$Benefits",
      "d": 1946560,
      "h": 12886848448,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(12886848448),
//--TRIMMABLE-BOUNDARY-START(335009395648),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueSpecification).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915736512,
        "f": 50331777
      },
      "n": "Specifications",
      "o": "LCFCP$ICatalogueModel$Specifications",
      "d": 1946560,
      "h": 335009395648,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(335009395648),
//--TRIMMABLE-BOUNDARY-START(360779199424),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueVariantModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210455344064,
        "f": 50331777
      },
      "n": "Variants",
      "o": "LCFCP$ICatalogueModel$Variants",
      "d": 1946560,
      "h": 360779199424,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(360779199424),
//--TRIMMABLE-BOUNDARY-START(309239591872),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292059722688,
        "f": 50331650
      },
      "n": "{739096}.ServiceTiers",
      "o": "LCFCP$IPaymentTier$ServiceTiers",
      "d": 1946560,
      "h": 309239591872,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(309239591872),
//--TRIMMABLE-BOUNDARY-START(365074166720),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueVideo).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219045278656,
        "f": 50331777
      },
      "n": "Videos",
      "o": "LCFCP$ICatalogueModel$Videos",
      "d": 1946560,
      "h": 365074166720,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(365074166720),
//--TRIMMABLE-BOUNDARY-START(21476783040),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueDeal).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016390592,
        "f": 50331777
      },
      "n": "Deals",
      "o": "LCFCP$ICatalogueModel$Deals",
      "d": 1946560,
      "h": 21476783040,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21476783040),
//--TRIMMABLE-BOUNDARY-START(244815082432),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966063552,
        "f": 50331777
      },
      "n": "Link",
      "o": "LCFCP$ICatalogueModel$Link",
      "d": 1946560,
      "h": 244815082432,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(244815082432),
//--TRIMMABLE-BOUNDARY-START(339304362944),
    {
      "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.TagModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505671104,
        "f": 50331777
      },
      "n": "Tags",
      "o": "LCFCP$ICatalogueModel$Tags",
      "d": 1946560,
      "h": 339304362944,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(339304362944),
//--TRIMMABLE-BOUNDARY-START(261994951616),
    {
      "p": 20875606,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257699984320,
        "f": 50331650
      },
      "n": "{20875606}.Parent",
      "o": "LCFCD$IParentHierachy$Parent",
      "d": 1946560,
      "h": 261994951616,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(261994951616),
//--TRIMMABLE-BOUNDARY-START(313534559168),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300649657280,
        "f": 50331650
      },
      "n": "{739096}.Tier",
      "o": "LCFCP$IPaymentTier$Tier",
      "d": 1946560,
      "h": 313534559168,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(313534559168)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(223340245952),
    {
      "r": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueAccessories).$h,
      "p": [
        {
          "n": "variant",
          "p": 2667456
        }
      ],
      "n": "GetAccessories",
      "o": "LCFCP$ICatalogueModel$GetAccessories",
      "d": 1946560,
      "h": 223340245952,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(223340245952),
//--TRIMMABLE-BOUNDARY-START(227635213248),
    {
      "r": 27822422,
      "p": [
        {
          "n": "variant",
          "p": 2667456
        }
      ],
      "n": "GetCost",
      "o": "LCFCP$ICatalogueModel$GetCost",
      "d": 1946560,
      "h": 227635213248,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(227635213248),
//--TRIMMABLE-BOUNDARY-START(231930180544),
    {
      "r": 27822422,
      "p": [
        {
          "n": "variant",
          "p": 2667456
        }
      ],
      "n": "GetOldCost",
      "o": "LCFCP$ICatalogueModel$GetOldCost",
      "d": 1946560,
      "h": 231930180544,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(231930180544)
  ],
  "h": 1946560
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1946560)
        
        

        //--TRIMMABLE-BOUNDARY-START(4043712)
        $asm.$cls(`$AvdQ.LCFCP.IProductCatalogueModel`, ($self) => class IProductCatalogueModel
        {
            static $h = 4043712;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 4043712
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IProductCatalogueModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IProductCatalogueModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4043712)
        
        

        //--TRIMMABLE-BOUNDARY-START(4240320)
        $asm.$cls(`$AvdQ.LCFCP.IServiceCatalogueModel`, ($self) => class IServiceCatalogueModel
        {
            static $h = 4240320;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12889142208),
    {
      "p": 5682112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8594174912,
        "f": 50331905
      },
      "n": "ServiceType",
      "o": "LCFCP$IServiceCatalogueModel$ServiceType",
      "d": 4240320,
      "h": 12889142208,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12889142208)
  ],
  "h": 4240320
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IServiceCatalogueModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IServiceCatalogueModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4240320)
        
        

        //--TRIMMABLE-BOUNDARY-START(2667456)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueVariantModel`, ($self) => class ICatalogueVariantModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297634752)
            /*IEnumerable<string>? */ get LCFCP$ICatalogueVariantModel$AccessoriesId()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4297634752)
            
            static $h = 2667456;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4297634752),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887569344,
        "f": 50331777
      },
      "n": "AccessoriesId",
      "o": "LCFCP$ICatalogueVariantModel$AccessoriesId",
      "d": 2667456,
      "h": 4297634752,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(4297634752)
  ],
  "h": 2667456
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueVariantModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueVariantModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2667456)
        
        

        //--TRIMMABLE-BOUNDARY-START(2798528)
        $asm.$cls(`$AvdQ.LCFCP.IEditableCatalogueModel`, ($self) => class IEditableCatalogueModel
        {
            static $h = 2798528;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952471488),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182667712,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38657504192,
        "f": 83886337
      },
      "n": "UnitQuantity",
      "o": "LCFCP$IEditableCatalogueModel$UnitQuantity",
      "d": 2798528,
      "h": 42952471488,
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(42952471488),
//--TRIMMABLE-BOUNDARY-START(21477635008),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8592733120,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30067569600,
        "f": 83886337
      },
      "n": "PackQuantity",
      "o": "LCFCP$IEditableCatalogueModel$PackQuantity",
      "d": 2798528,
      "h": 21477635008,
      "f": 538968321
    },
//--TRIMMABLE-BOUNDARY-END(21477635008)
  ],
  "h": 2798528
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IEditableCatalogueModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IEditableCatalogueModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2798528)
        
        

        //--TRIMMABLE-BOUNDARY-START(177088)
        $asm.$cls(`$AvdQ.LCFCP.BaseProductCatalogueProvider`, ($self) => class BaseProductCatalogueProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115964294080)
            /*string */ get Name()
            {
                return $.$$.S.Object.GetType.call(this).Name;
            }
            //--TRIMMABLE-BOUNDARY-END(115964294080)
            
            //--TRIMMABLE-BOUNDARY-START(30064948160)
            /*string?*/ $Description = null;
            /*string? */ get Description()
            {
                return this.$Description;
            }
             /*string? */ set Description(value)
            {
                this.$Description = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30064948160)
            
            //--TRIMMABLE-BOUNDARY-START(111669326784)
            /*IconDescriptor*/ $Icon;
            /*IconDescriptor */ get Icon()
            {
                return this.$Icon;
            }
             /*IconDescriptor */ set Icon(value)
            {
                this.$Icon = value;
            }
            //--TRIMMABLE-BOUNDARY-END(111669326784)
            
            //--TRIMMABLE-BOUNDARY-START(25769980864)
            /*Pager<ICatalogueCategoryModel>? */ get Categories()
            {
                return $.$fPer.LCFCD.Paging.GetPager($.$AvdQ.LCFCP.ICatalogueCategoryModel, $.$sl.SL.Enumerable.Empty($.$AvdQ.LCFCP.ICatalogueCategoryModel), null);
            }
            //--TRIMMABLE-BOUNDARY-END(25769980864)
            
            //--TRIMMABLE-BOUNDARY-START(21475013568)
            /*Pager<ICatalogueCategoryModel>? */ get Brands()
            {
                return $.$fPer.LCFCD.Paging.GetPager($.$AvdQ.LCFCP.ICatalogueCategoryModel, $.$sl.SL.Enumerable.Empty($.$AvdQ.LCFCP.ICatalogueCategoryModel), null);
            }
            //--TRIMMABLE-BOUNDARY-END(21475013568)
            
            //--TRIMMABLE-BOUNDARY-START(120259261376)
            /*Pager<IProductCatalogueModel>? */ get Products()
            {
                return $.$fPer.LCFCD.Paging.GetPager($.$AvdQ.LCFCP.IProductCatalogueModel, $.$sl.SL.Enumerable.Empty($.$AvdQ.LCFCP.IProductCatalogueModel), null);
            }
            //--TRIMMABLE-BOUNDARY-END(120259261376)
            
            //--TRIMMABLE-BOUNDARY-START(124554228672)
            /*Pager<IServiceCatalogueModel>? */ get Services()
            {
                return $.$fPer.LCFCD.Paging.GetPager($.$AvdQ.LCFCP.IServiceCatalogueModel, $.$sl.SL.Enumerable.Empty($.$AvdQ.LCFCP.IServiceCatalogueModel), null);
            }
            //--TRIMMABLE-BOUNDARY-END(124554228672)
            
            //--TRIMMABLE-BOUNDARY-START(128849195968)
            /*ICatalogueSettings?*/ $Settings = null;
            /*ICatalogueSettings? */ get Settings()
            {
                return this.$Settings;
            }
             /*ICatalogueSettings? */ set Settings(value)
            {
                this.$Settings = value;
            }
            //--TRIMMABLE-BOUNDARY-END(128849195968)
            
            //--TRIMMABLE-BOUNDARY-START(25772143552)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider.Categories.get
            get LCFCP$ICatalogueProvider$Categories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592274368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Categories;
            }
            //--TRIMMABLE-BOUNDARY-END(25772143552)
            
            //--TRIMMABLE-BOUNDARY-START(17182208960)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider.Brands.get
            get LCFCP$ICatalogueProvider$Brands()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297307072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Brands;
            }
            //--TRIMMABLE-BOUNDARY-END(17182208960)
            
            //--TRIMMABLE-BOUNDARY-START(34362078144)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider.Products.get
            get LCFCP$ICatalogueProvider$Products()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721816512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Products;
            }
            //--TRIMMABLE-BOUNDARY-END(34362078144)
            
            //--TRIMMABLE-BOUNDARY-START(42952012736)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider.Services.get
            get LCFCP$ICatalogueProvider$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016783808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(42952012736)
            
            //--TRIMMABLE-BOUNDARY-START(51541947328)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueProvider.Settings.get
            get LCFCP$ICatalogueProvider$Settings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311751104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Settings;
            }
            //--TRIMMABLE-BOUNDARY-END(51541947328)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17180046272)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180046272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180046272)
            
            //--TRIMMABLE-BOUNDARY-START(17180046272)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180046272)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(111669326784)
                this.$Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(111669326784)
                
            }
            static $h = 177088;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964294080),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014621120,
        "f": 50331777
      },
      "n": "Name",
      "d": 177088,
      "h": 115964294080,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(115964294080),
//--TRIMMABLE-BOUNDARY-START(133144163264),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374359488,
        "f": 50331905
      },
      "n": "Title",
      "d": 177088,
      "h": 133144163264,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(133144163264),
//--TRIMMABLE-BOUNDARY-START(30064948160),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834751936,
        "f": 50331777
      },
      "n": "Description",
      "d": 177088,
      "h": 30064948160,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(30064948160),
//--TRIMMABLE-BOUNDARY-START(111669326784),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424686528,
        "f": 50331777
      },
      "n": "Icon",
      "d": 177088,
      "h": 111669326784,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(111669326784),
//--TRIMMABLE-BOUNDARY-START(25769980864),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ICatalogueCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244817344,
        "f": 50331777
      },
      "n": "Categories",
      "d": 177088,
      "h": 25769980864,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25769980864),
//--TRIMMABLE-BOUNDARY-START(21475013568),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ICatalogueCategoryModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654882752,
        "f": 50331777
      },
      "n": "Brands",
      "d": 177088,
      "h": 21475013568,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21475013568),
//--TRIMMABLE-BOUNDARY-START(120259261376),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.IProductCatalogueModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604555712,
        "f": 50331777
      },
      "n": "Products",
      "d": 177088,
      "h": 120259261376,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(120259261376),
//--TRIMMABLE-BOUNDARY-START(124554228672),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.IServiceCatalogueModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194490304,
        "f": 50331777
      },
      "n": "Services",
      "d": 177088,
      "h": 124554228672,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(124554228672),
//--TRIMMABLE-BOUNDARY-START(128849195968),
    {
      "p": 2536384,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784424896,
        "f": 50331777
      },
      "n": "Settings",
      "d": 177088,
      "h": 128849195968,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(128849195968)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180046272),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 177088,
      "h": 17180046272,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(17180046272)
  ],
  "h": 177088
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.BaseProductCatalogueProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}BaseProductCatalogueProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(177088)
        
        

        //--TRIMMABLE-BOUNDARY-START(701376)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueFAQ`, ($self) => class CatalogueFAQ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655407040)
            /*string?*/ Question = null;
            //--TRIMMABLE-BOUNDARY-END(38655407040)
            
            //--TRIMMABLE-BOUNDARY-START(17180570560)
            /*string?*/ Answer = null;
            //--TRIMMABLE-BOUNDARY-END(17180570560)
            
            //--TRIMMABLE-BOUNDARY-START(12885603264)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885603264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885603264)
            
            //--TRIMMABLE-BOUNDARY-START(12885603264)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885603264)
            
            static $h = 701376;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655407040),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360439744,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835276224,
        "f": 83886081
      },
      "n": "Question",
      "d": 701376,
      "h": 38655407040,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655407040),
//--TRIMMABLE-BOUNDARY-START(17180570560),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770505152,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245341632,
        "f": 83886081
      },
      "n": "Answer",
      "d": 701376,
      "h": 17180570560,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180570560)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885603264),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 701376,
      "h": 12885603264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885603264)
  ],
  "h": 701376
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueFAQ`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueFAQ`; }
        });
        //--TRIMMABLE-BOUNDARY-END(701376)
        
        

        //--TRIMMABLE-BOUNDARY-START(373696)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueBenefit`, ($self) => class CatalogueBenefit extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(107374556096)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(107374556096)
            
            //--TRIMMABLE-BOUNDARY-START(64424883136)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(64424883136)
            
            //--TRIMMABLE-BOUNDARY-START(25770177472)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(25770177472)
            
            //--TRIMMABLE-BOUNDARY-START(68719850432)
            /*string?*/ IconColor = null;
            //--TRIMMABLE-BOUNDARY-END(68719850432)
            
            //--TRIMMABLE-BOUNDARY-START(21475210176)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475210176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475210176)
            
            //--TRIMMABLE-BOUNDARY-START(21475210176)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475210176)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64424883136)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(64424883136)
                
            }
            static $h = 373696;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374556096),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129915840,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079588800,
        "f": 83886081
      },
      "n": "Title",
      "d": 373696,
      "h": 107374556096,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374556096),
//--TRIMMABLE-BOUNDARY-START(64424883136),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950046656,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899719616,
        "f": 83886081
      },
      "n": "Icon",
      "d": 373696,
      "h": 64424883136,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424883136),
//--TRIMMABLE-BOUNDARY-START(25770177472),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360112064,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309785024,
        "f": 83886081
      },
      "n": "Description",
      "d": 373696,
      "h": 25770177472,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770177472),
//--TRIMMABLE-BOUNDARY-START(68719850432),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539981248,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489654208,
        "f": 83886081
      },
      "n": "IconColor",
      "d": 373696,
      "h": 68719850432,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719850432)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475210176),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 373696,
      "h": 21475210176,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475210176)
  ],
  "h": 373696
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueBenefit`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueBenefit`; }
        });
        //--TRIMMABLE-BOUNDARY-END(373696)
        
        

        //--TRIMMABLE-BOUNDARY-START(111552)
        $asm.$cls(`$AvdQ.LCFCP.ActionButton`, ($self) => class ActionButton extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(107374293952)
            /*string*/ Text = null;
            //--TRIMMABLE-BOUNDARY-END(107374293952)
            
            //--TRIMMABLE-BOUNDARY-START(60129653696)
            /*string*/ Icon = null;
            //--TRIMMABLE-BOUNDARY-END(60129653696)
            
            //--TRIMMABLE-BOUNDARY-START(64424620992)
            /*string*/ Link = null;
            //--TRIMMABLE-BOUNDARY-END(64424620992)
            
            //--TRIMMABLE-BOUNDARY-START(68719588288)
            /*Action*/ OnClick = null;
            //--TRIMMABLE-BOUNDARY-END(68719588288)
            
            //--TRIMMABLE-BOUNDARY-START(21474948032)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474948032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474948032)
            
            //--TRIMMABLE-BOUNDARY-START(21474948032)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21474948032)
            
            static $h = 111552;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374293952),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834686400,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079326656,
        "f": 83886081
      },
      "n": "Text",
      "d": 111552,
      "h": 107374293952,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374293952),
//--TRIMMABLE-BOUNDARY-START(60129653696),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064882624,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309522880,
        "f": 83886081
      },
      "n": "Icon",
      "d": 111552,
      "h": 60129653696,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129653696),
//--TRIMMABLE-BOUNDARY-START(64424620992),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654817216,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899457472,
        "f": 83886081
      },
      "n": "Link",
      "d": 111552,
      "h": 64424620992,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424620992),
//--TRIMMABLE-BOUNDARY-START(68719588288),
    {
      "p": 43122689,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244751808,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489392064,
        "f": 83886081
      },
      "n": "OnClick",
      "d": 111552,
      "h": 68719588288,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719588288)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21474948032),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 111552,
      "h": 21474948032,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474948032)
  ],
  "h": 111552
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ActionButton`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ActionButton`; }
        });
        //--TRIMMABLE-BOUNDARY-END(111552)
        
        

        //--TRIMMABLE-BOUNDARY-START(1029056)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueTestimonial`, ($self) => class CatalogueTestimonial extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655734720)
            /*string?*/ CustomerName = null;
            //--TRIMMABLE-BOUNDARY-END(38655734720)
            
            //--TRIMMABLE-BOUNDARY-START(30065800128)
            /*string?*/ CustomerCompany = null;
            //--TRIMMABLE-BOUNDARY-END(30065800128)
            
            //--TRIMMABLE-BOUNDARY-START(42950702016)
            /*string?*/ CustomerRole = null;
            //--TRIMMABLE-BOUNDARY-END(42950702016)
            
            //--TRIMMABLE-BOUNDARY-START(34360767424)
            /*string?*/ CustomerImage = null;
            //--TRIMMABLE-BOUNDARY-END(34360767424)
            
            //--TRIMMABLE-BOUNDARY-START(90195342272)
            /*IEnumerable<string>?*/ ProductImages = null;
            //--TRIMMABLE-BOUNDARY-END(90195342272)
            
            //--TRIMMABLE-BOUNDARY-START(25770832832)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770832832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770832832)
            
            //--TRIMMABLE-BOUNDARY-START(25770832832)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770832832)
            
            static $h = 1029056;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655734720),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720505792,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965146048,
        "f": 83886081
      },
      "n": "CustomerName",
      "d": 1029056,
      "h": 38655734720,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655734720),
//--TRIMMABLE-BOUNDARY-START(30065800128),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540636608,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785276864,
        "f": 83886081
      },
      "n": "CustomerCompany",
      "d": 1029056,
      "h": 30065800128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065800128),
//--TRIMMABLE-BOUNDARY-START(42950702016),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310440384,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555080640,
        "f": 83886081
      },
      "n": "CustomerRole",
      "d": 1029056,
      "h": 42950702016,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950702016),
//--TRIMMABLE-BOUNDARY-START(34360767424),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130571200,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375211456,
        "f": 83886081
      },
      "n": "CustomerImage",
      "d": 1029056,
      "h": 34360767424,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360767424),
//--TRIMMABLE-BOUNDARY-START(90195342272),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900374976,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145015232,
        "f": 83886081
      },
      "n": "ProductImages",
      "d": 1029056,
      "h": 90195342272,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195342272)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770832832),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1029056,
      "h": 25770832832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770832832)
  ],
  "h": 1029056
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueTestimonial`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueTestimonial`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1029056)
        
        

        //--TRIMMABLE-BOUNDARY-START(635840)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueExtension`, ($self) => class CatalogueExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295603136)
            static /*bool */ IsNew(/*this ICatalogueModel*/ cataloge)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295603136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(cataloge.LCFCP$ICatalogueModel$LaunchDate) && $.$$.S.TimeSpan.op_LessThan($.$$.S.DateTime.op_Subtraction$1($.$$.S.DateTime.UtcNow, $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(cataloge.LCFCP$ICatalogueModel$LaunchDate)), $.$$.S.TimeSpan.FromDays$2(30));
            }
            //--TRIMMABLE-BOUNDARY-END(4295603136)
            
            static $h = 635840;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295603136),
    {
      "r": 262145,
      "p": [
        {
          "n": "cataloge",
          "p": 1946560
        }
      ],
      "n": "IsNew",
      "d": 635840,
      "h": 4295603136,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295603136)
  ],
  "h": 635840
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(635840)
        
        

        //--TRIMMABLE-BOUNDARY-START(1094592)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueUseCase`, ($self) => class CatalogueUseCase extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835669440)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(55835669440)
            
            //--TRIMMABLE-BOUNDARY-START(17180963776)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(17180963776)
            
            //--TRIMMABLE-BOUNDARY-START(12885996480)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885996480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885996480)
            
            //--TRIMMABLE-BOUNDARY-START(12885996480)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885996480)
            
            static $h = 1094592;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835669440),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360832960,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540702144,
        "f": 83886081
      },
      "n": "Title",
      "d": 1094592,
      "h": 55835669440,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835669440),
//--TRIMMABLE-BOUNDARY-START(17180963776),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770898368,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950767552,
        "f": 83886081
      },
      "n": "Description",
      "d": 1094592,
      "h": 17180963776,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180963776)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885996480),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1094592,
      "h": 12885996480,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885996480)
  ],
  "h": 1094592
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueUseCase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueUseCase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1094592)
        
        

        //--TRIMMABLE-BOUNDARY-START(1225664)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueVideo`, ($self) => class CatalogueVideo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835800512)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(55835800512)
            
            //--TRIMMABLE-BOUNDARY-START(34360964032)
            /*string?*/ Link = null;
            //--TRIMMABLE-BOUNDARY-END(34360964032)
            
            //--TRIMMABLE-BOUNDARY-START(12886127552)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886127552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886127552)
            
            //--TRIMMABLE-BOUNDARY-START(12886127552)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886127552)
            
            static $h = 1225664;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835800512),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065996736,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540833216,
        "f": 83886081
      },
      "n": "Title",
      "d": 1225664,
      "h": 55835800512,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835800512),
//--TRIMMABLE-BOUNDARY-START(34360964032),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476062144,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950898624,
        "f": 83886081
      },
      "n": "Link",
      "d": 1225664,
      "h": 34360964032,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360964032)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886127552),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1225664,
      "h": 12886127552,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886127552)
  ],
  "h": 1225664
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueVideo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueVideo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1225664)
        
        

        //--TRIMMABLE-BOUNDARY-START(963520)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueSpecification`, ($self) => class CatalogueSpecification extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51540571072)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(51540571072)
            
            //--TRIMMABLE-BOUNDARY-START(55835538368)
            /*string?*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(55835538368)
            
            //--TRIMMABLE-BOUNDARY-START(12885865408)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885865408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885865408)
            
            //--TRIMMABLE-BOUNDARY-START(12885865408)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885865408)
            
            static $h = 963520;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540571072),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475800000,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38655669184,
        "f": 83886081
      },
      "n": "Title",
      "d": 963520,
      "h": 51540571072,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540571072),
//--TRIMMABLE-BOUNDARY-START(55835538368),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065734592,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245603776,
        "f": 83886081
      },
      "n": "Value",
      "d": 963520,
      "h": 55835538368,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835538368)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885865408),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 963520,
      "h": 12885865408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885865408)
  ],
  "h": 963520
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueSpecification`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueSpecification`; }
        });
        //--TRIMMABLE-BOUNDARY-END(963520)
        
        

        //--TRIMMABLE-BOUNDARY-START(766912)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueFeature`, ($self) => class CatalogueFeature extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(133144753088)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(133144753088)
            
            //--TRIMMABLE-BOUNDARY-START(81605145536)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(81605145536)
            
            //--TRIMMABLE-BOUNDARY-START(30065537984)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(30065537984)
            
            //--TRIMMABLE-BOUNDARY-START(85900112832)
            /*string?*/ IconColor = null;
            //--TRIMMABLE-BOUNDARY-END(85900112832)
            
            //--TRIMMABLE-BOUNDARY-START(34360505280)
            /*string?*/ DescriptionLink = null;
            //--TRIMMABLE-BOUNDARY-END(34360505280)
            
            //--TRIMMABLE-BOUNDARY-START(25770570688)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770570688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770570688)
            
            //--TRIMMABLE-BOUNDARY-START(25770570688)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770570688)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81605145536)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(81605145536)
                
            }
            static $h = 766912;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144753088),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310178240,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849785792,
        "f": 83886081
      },
      "n": "Title",
      "d": 766912,
      "h": 133144753088,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144753088),
//--TRIMMABLE-BOUNDARY-START(81605145536),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130309056,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669916608,
        "f": 83886081
      },
      "n": "Icon",
      "d": 766912,
      "h": 81605145536,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605145536),
//--TRIMMABLE-BOUNDARY-START(30065537984),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950439872,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490047424,
        "f": 83886081
      },
      "n": "Description",
      "d": 766912,
      "h": 30065537984,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065537984),
//--TRIMMABLE-BOUNDARY-START(85900112832),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720243648,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259851200,
        "f": 83886081
      },
      "n": "IconColor",
      "d": 766912,
      "h": 85900112832,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900112832),
//--TRIMMABLE-BOUNDARY-START(34360505280),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540374464,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079982016,
        "f": 83886081
      },
      "n": "DescriptionLink",
      "d": 766912,
      "h": 34360505280,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360505280)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770570688),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 766912,
      "h": 25770570688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770570688)
  ],
  "h": 766912
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueFeature`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueFeature`; }
        });
        //--TRIMMABLE-BOUNDARY-END(766912)
        
        

        //--TRIMMABLE-BOUNDARY-START(308160)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueAccessories`, ($self) => class CatalogueAccessories extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(98784555968)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(98784555968)
            
            //--TRIMMABLE-BOUNDARY-START(38655013824)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(38655013824)
            
            //--TRIMMABLE-BOUNDARY-START(94489588672)
            /*IEnumerable<string>?*/ Images = null;
            //--TRIMMABLE-BOUNDARY-END(94489588672)
            
            //--TRIMMABLE-BOUNDARY-START(158914098112)
            /*string?*/ SKU = null;
            //--TRIMMABLE-BOUNDARY-END(158914098112)
            
            //--TRIMMABLE-BOUNDARY-START(103079523264)
            /*Money?*/ OldCost = null;
            //--TRIMMABLE-BOUNDARY-END(103079523264)
            
            //--TRIMMABLE-BOUNDARY-START(34360046528)
            /*Money*/ Cost;
            //--TRIMMABLE-BOUNDARY-END(34360046528)
            
            //--TRIMMABLE-BOUNDARY-START(30065079232)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065079232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065079232)
            
            //--TRIMMABLE-BOUNDARY-START(30065079232)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30065079232)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(103079523264)
                this.OldCost = null;
                //--TRIMMABLE-BOUNDARY-END(103079523264)
                
                //--TRIMMABLE-BOUNDARY-START(34360046528)
                this.Cost = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(34360046528)
                
            }
            static $h = 308160;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784555968),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014752192,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439261632,
        "f": 83886081
      },
      "n": "Name",
      "d": 308160,
      "h": 98784555968,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784555968),
//--TRIMMABLE-BOUNDARY-START(38655013824),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834883008,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259392448,
        "f": 83886081
      },
      "n": "Description",
      "d": 308160,
      "h": 38655013824,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655013824),
//--TRIMMABLE-BOUNDARY-START(94489588672),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424817600,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849327040,
        "f": 83886081
      },
      "n": "Images",
      "d": 308160,
      "h": 94489588672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489588672),
//--TRIMMABLE-BOUNDARY-START(158914098112),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194621376,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619130816,
        "f": 83886081
      },
      "n": "SKU",
      "d": 308160,
      "h": 158914098112,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914098112),
//--TRIMMABLE-BOUNDARY-START(103079523264),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604686784,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029196224,
        "f": 83886081
      },
      "n": "OldCost",
      "d": 308160,
      "h": 103079523264,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079523264),
//--TRIMMABLE-BOUNDARY-START(34360046528),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244948416,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669457856,
        "f": 83886081
      },
      "n": "Cost",
      "d": 308160,
      "h": 34360046528,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360046528)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065079232),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 308160,
      "h": 30065079232,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065079232)
  ],
  "h": 308160
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueAccessories`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueAccessories`; }
        });
        //--TRIMMABLE-BOUNDARY-END(308160)
        
        

        //--TRIMMABLE-BOUNDARY-START(2274240)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueOrderModelCustomAttributesProvider`, ($self) => class ICatalogueOrderModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297241536)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297241536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297241536)
            
            static $h = 2274240;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297241536),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2274240,
      "h": 4297241536,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297241536)
  ],
  "h": 2274240
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueOrderModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueOrderModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2274240)
        
        

        //--TRIMMABLE-BOUNDARY-START(2732992)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueVariantModelCustomAttributesProvider`, ($self) => class ICatalogueVariantModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297700288)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297700288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297700288)
            
            static $h = 2732992;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297700288),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2732992,
      "h": 4297700288,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297700288)
  ],
  "h": 2732992
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueVariantModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueVariantModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2732992)
        
        

        //--TRIMMABLE-BOUNDARY-START(2864064)
        $asm.$cls(`$AvdQ.LCFCP.IEditableCatalogueModelCustomAttributesProvider`, ($self) => class IEditableCatalogueModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297831360)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297831360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297831360)
            
            static $h = 2864064;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297831360),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2864064,
      "h": 4297831360,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297831360)
  ],
  "h": 2864064
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IEditableCatalogueModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IEditableCatalogueModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2864064)
        
        

        //--TRIMMABLE-BOUNDARY-START(1553344)
        $asm.$cls(`$AvdQ.LCFCP.DynamicServiceTierTypeCustomAttributesProvider`, ($self) => class DynamicServiceTierTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296520640)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296520640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296520640)
            
            static $h = 1553344;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296520640),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1553344,
      "h": 4296520640,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296520640)
  ],
  "h": 1553344
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.DynamicServiceTierTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}DynamicServiceTierTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1553344)
        
        

        //--TRIMMABLE-BOUNDARY-START(570304)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueCategoryFlagsCustomAttributesProvider`, ($self) => class CatalogueCategoryFlagsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295537600)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295537600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295537600)
            
            static $h = 570304;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295537600),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 570304,
      "h": 4295537600,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295537600)
  ],
  "h": 570304
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueCategoryFlagsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueCategoryFlagsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(570304)
        
        

        //--TRIMMABLE-BOUNDARY-START(2012096)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueModelCustomAttributesProvider`, ($self) => class ICatalogueModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296979392)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296979392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296979392)
            
            static $h = 2012096;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296979392),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2012096,
      "h": 4296979392,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296979392)
  ],
  "h": 2012096
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2012096)
        
        

        //--TRIMMABLE-BOUNDARY-START(3650496)
        $asm.$cls(`$AvdQ.LCFCP.InvoiceModelCustomAttributesProvider`, ($self) => class InvoiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298617792)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298617792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298617792)
            
            static $h = 3650496;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298617792),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3650496,
      "h": 4298617792,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298617792)
  ],
  "h": 3650496
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3650496)
        
        

        //--TRIMMABLE-BOUNDARY-START(1422272)
        $asm.$cls(`$AvdQ.LCFCP.DynamicServiceFeatureTypeCustomAttributesProvider`, ($self) => class DynamicServiceFeatureTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296389568)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296389568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296389568)
            
            static $h = 1422272;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296389568),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1422272,
      "h": 4296389568,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296389568)
  ],
  "h": 1422272
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.DynamicServiceFeatureTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}DynamicServiceFeatureTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1422272)
        
        

        //--TRIMMABLE-BOUNDARY-START(2601920)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueSettingsCustomAttributesProvider`, ($self) => class ICatalogueSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297569216)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297569216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297569216)
            
            static $h = 2601920;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297569216),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2601920,
      "h": 4297569216,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297569216)
  ],
  "h": 2601920
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2601920)
        
        

        //--TRIMMABLE-BOUNDARY-START(2143168)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueOrderItemModelCustomAttributesProvider`, ($self) => class ICatalogueOrderItemModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297110464)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297110464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297110464)
            
            static $h = 2143168;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297110464),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2143168,
      "h": 4297110464,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297110464)
  ],
  "h": 2143168
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueOrderItemModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueOrderItemModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2143168)
        
        

        //--TRIMMABLE-BOUNDARY-START(4109248)
        $asm.$cls(`$AvdQ.LCFCP.IProductCatalogueModelCustomAttributesProvider`, ($self) => class IProductCatalogueModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299076544)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299076544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4299076544)
            
            static $h = 4109248;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299076544),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4109248,
      "h": 4299076544,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299076544)
  ],
  "h": 4109248
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IProductCatalogueModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IProductCatalogueModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4109248)
        
        

        //--TRIMMABLE-BOUNDARY-START(1684416)
        $asm.$cls(`$AvdQ.LCFCP.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296651712)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296651712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4296651712)
            
            static $h = 1684416;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296651712),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 1684416,
      "h": 4296651712,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296651712)
  ],
  "h": 1684416
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1684416)
        
        

        //--TRIMMABLE-BOUNDARY-START(3388352)
        $asm.$cls(`$AvdQ.LCFCP.InvoiceItemModelCustomAttributesProvider`, ($self) => class InvoiceItemModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298355648)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298355648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298355648)
            
            static $h = 3388352;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298355648),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3388352,
      "h": 4298355648,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298355648)
  ],
  "h": 3388352
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoiceItemModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoiceItemModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3388352)
        
        

        //--TRIMMABLE-BOUNDARY-START(3191744)
        $asm.$cls(`$AvdQ.LCFCP.IInvoiceModelCustomAttributesProvider`, ($self) => class IInvoiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298159040)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298159040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298159040)
            
            static $h = 3191744;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298159040),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3191744,
      "h": 4298159040,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298159040)
  ],
  "h": 3191744
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IInvoiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IInvoiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3191744)
        
        

        //--TRIMMABLE-BOUNDARY-START(2995136)
        $asm.$cls(`$AvdQ.LCFCP.IEditableCatalogueOrderItemModelCustomAttributesProvider`, ($self) => class IEditableCatalogueOrderItemModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297962432)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297962432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297962432)
            
            static $h = 2995136;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297962432),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2995136,
      "h": 4297962432,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297962432)
  ],
  "h": 2995136
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IEditableCatalogueOrderItemModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IEditableCatalogueOrderItemModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2995136)
        
        

        //--TRIMMABLE-BOUNDARY-START(5813184)
        $asm.$cls(`$AvdQ.LCFCP.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4300780480)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300780480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$AvdQ.LCFCP.InvoiceItemModelTypeDescriptorBuilder.Register();
                $.$AvdQ.LCFCP.InvoiceModelTypeDescriptorBuilder.Register();
                $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptorBuilder.Register();
                $.$fPer.LCFCD$1.SystemTypeDescriptor.RegisterLazyTypeDescriptorRegistrar($.$AvdQ.LCFCP.ServiceTierModel$$().$type, new ($.$$.S.Action$$($.$typeArray($.$$.S.Type)))().$ctor(this,  (/**/ types) =>
                {
                    return $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptorBuilder$$().$type.MakeGenericType(types).GetMethod$9("Register", 8/*System.Reflection.BindingFlags.Static*/ | 16/*System.Reflection.BindingFlags.Public*/).Invoke(null, null);
                }, $AQxuwk ??= {"r":65537,"p":[{"n":"types","p":$.$typeArray($.$$.S.Type).$h}],"n":"","d":5813184,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.RegisterLazyTypeDescriptorRegistrar($.$AvdQ.LCFCP.ServiceTierModel$$$().$type, new ($.$$.S.Action$$($.$typeArray($.$$.S.Type)))().$ctor(this,  (/**/ types) =>
                {
                    return $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptorBuilder$$$().$type.MakeGenericType(types).GetMethod$9("Register", 8/*System.Reflection.BindingFlags.Static*/ | 16/*System.Reflection.BindingFlags.Public*/).Invoke(null, null);
                }, $QXpiyf ??= {"r":65537,"p":[{"n":"types","p":$.$typeArray($.$$.S.Type).$h}],"n":"","d":5813184,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4300780480)
            
            static $h = 5813184;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300780480),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 5813184,
      "h": 4300780480,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4300780480)
  ],
  "h": 5813184
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5813184)
        
        

        //--TRIMMABLE-BOUNDARY-START(1815488)
        $asm.$cls(`$AvdQ.LCFCP.ICatalogueCategoryModelCustomAttributesProvider`, ($self) => class ICatalogueCategoryModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296782784)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296782784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296782784)
            
            static $h = 1815488;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296782784),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1815488,
      "h": 4296782784,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296782784)
  ],
  "h": 1815488
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ICatalogueCategoryModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ICatalogueCategoryModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1815488)
        
        

        //--TRIMMABLE-BOUNDARY-START(4699072)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierFlagsCustomAttributesProvider`, ($self) => class ServiceTierFlagsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299666368)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299666368)
            
            //--TRIMMABLE-BOUNDARY-START(8594633664)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594633664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AvdQ.LCFCP.ServiceTierFlagsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AvdQ.LCFCP.ServiceTierFlagsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $nxXzId ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4699072,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $gcqIRa ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4699072,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594633664)
            
            static $h = 4699072;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594633664),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4699072,
      "h": 8594633664,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594633664)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299666368),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4699072,
      "h": 4299666368,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299666368)
  ],
  "h": 4699072
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierFlagsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierFlagsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4699072)
        
        

        //--TRIMMABLE-BOUNDARY-START(3978176)
        $asm.$cls(`$AvdQ.LCFCP.InvoicePaymentMethodCustomAttributesProvider`, ($self) => class InvoicePaymentMethodCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298945472)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298945472)
            
            //--TRIMMABLE-BOUNDARY-START(8593912768)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593912768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AvdQ.LCFCP.InvoicePaymentMethodCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AvdQ.LCFCP.InvoicePaymentMethodCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $OKTSlk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3978176,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $gAalrb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3978176,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593912768)
            
            static $h = 3978176;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593912768),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3978176,
      "h": 8593912768,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593912768)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298945472),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3978176,
      "h": 4298945472,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298945472)
  ],
  "h": 3978176
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoicePaymentMethodCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoicePaymentMethodCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3978176)
        
        

        //--TRIMMABLE-BOUNDARY-START(897984)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueFlagsCustomAttributesProvider`, ($self) => class CatalogueFlagsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295865280)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295865280)
            
            //--TRIMMABLE-BOUNDARY-START(8590832576)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590832576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AvdQ.LCFCP.CatalogueFlagsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t4 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i4 = new $t4();
                        $i4.$ctor$7(7, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i4.set_Item("Featured", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Description = "Add product to featured tab";
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("CostNegotiable", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Description = "Allow buyers to offer price on this product";
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("AuctionBidding", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Description = "Allow buyers to offer price on this product";
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("HasVariation", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Description = "Product has more than one variation";
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("Published", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Description = "Publish this product to shoppers";
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("TrackInventory", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Description = "Enable Inventory for this catalogue";
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i4.set_Item("Default", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i4;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AvdQ.LCFCP.CatalogueFlagsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $uHBqWb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":897984,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $rWwDQa ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":897984,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590832576)
            
            static $h = 897984;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590832576),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 897984,
      "h": 8590832576,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590832576)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295865280),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 897984,
      "h": 4295865280,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295865280)
  ],
  "h": 897984
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueFlagsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueFlagsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(897984)
        
        

        //--TRIMMABLE-BOUNDARY-START(5747648)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTypeCustomAttributesProvider`, ($self) => class ServiceTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300714944)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4300714944)
            
            //--TRIMMABLE-BOUNDARY-START(8595682240)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595682240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AvdQ.LCFCP.ServiceTypeCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AvdQ.LCFCP.ServiceTypeCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $iCWZNf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":5747648,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $rzQBgi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":5747648,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8595682240)
            
            static $h = 5747648;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595682240),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5747648,
      "h": 8595682240,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595682240)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4300714944),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 5747648,
      "h": 4300714944,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4300714944)
  ],
  "h": 5747648
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5747648)
        
        

        //--TRIMMABLE-BOUNDARY-START(5092288)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider<>`, (TServiceTierType) => $asm.$gt(`$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider<>`, [TServiceTierType], ($self) => class ServiceTierModelCustomAttributesProvider$$
        {
            //--TRIMMABLE-BOUNDARY-START(4300059584)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4300059584)
            
            //--TRIMMABLE-BOUNDARY-START(8595026880)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595026880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider$$(TServiceTierType).compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ServiceType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (8);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider$$(TServiceTierType).compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $UUEwba ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $GjTZei ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8595026880)
            
            static $H = 5092288;
            static $h = 5092288;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595026880),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": this.$h,
      "H": 8595026880,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595026880)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4300059584),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": this.$h,
      "H": 4300059584,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4300059584)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 1,
  "H": 5092288,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelCustomAttributesProvider<${TServiceTierType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelCustomAttributesProvider$${TServiceTierType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(5092288)
        
        

        //--TRIMMABLE-BOUNDARY-START(3519424)
        $asm.$cls(`$AvdQ.LCFCP.InvoiceItemModelTypeDescriptorBuilder`, ($self) => class InvoiceItemModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593454016)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593454016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AvdQ.LCFCP.InvoiceItemModelTypeDescriptor()
                        const $t1 = $.$AvdQ.LCFCP.InvoiceItemModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Product.InvoiceItemModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xawTHg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3519424,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AvdQ.LCFCP.InvoiceItemModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593454016)
            
            //--TRIMMABLE-BOUNDARY-START(4298486720)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298486720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298486720)
            
            //--TRIMMABLE-BOUNDARY-START(4298486720)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298486720)
            
            static $h = 3519424;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593454016),
    {
      "r": 65537,
      "n": "Register",
      "d": 3519424,
      "h": 8593454016,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593454016)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298486720),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3519424,
      "h": 4298486720,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298486720)
  ],
  "h": 3519424
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoiceItemModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoiceItemModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3519424)
        
        

        //--TRIMMABLE-BOUNDARY-START(5616576)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelTypeDescriptorBuilder<>`, (TServiceTierType) => $asm.$gt(`$AvdQ.LCFCP.ServiceTierModelTypeDescriptorBuilder<>`, [TServiceTierType], ($self) => class ServiceTierModelTypeDescriptorBuilder$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595551168)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595551168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$(TServiceTierType)()
                        const $t1 = $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$(TServiceTierType);
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType>");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QyJnli ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType).$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595551168)
            
            //--TRIMMABLE-BOUNDARY-START(4300583872)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300583872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300583872)
            
            //--TRIMMABLE-BOUNDARY-START(4300583872)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300583872)
            
            static $H = 5616576;
            static $h = 5616576;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595551168),
    {
      "r": 65537,
      "n": "Register",
      "d": this.$h,
      "H": 8595551168,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595551168)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300583872),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4300583872,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300583872)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 1,
  "H": 5616576,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelTypeDescriptorBuilder<${TServiceTierType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelTypeDescriptorBuilder$${TServiceTierType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(5616576)
        
        

        //--TRIMMABLE-BOUNDARY-START(3781568)
        $asm.$cls(`$AvdQ.LCFCP.InvoiceModelTypeDescriptorBuilder`, ($self) => class InvoiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593716160)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593716160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AvdQ.LCFCP.InvoiceModelTypeDescriptor()
                        const $t1 = $.$AvdQ.LCFCP.InvoiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Product.InvoiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $jpcLia ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3781568,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AvdQ.LCFCP.InvoiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593716160)
            
            //--TRIMMABLE-BOUNDARY-START(4298748864)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298748864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298748864)
            
            //--TRIMMABLE-BOUNDARY-START(4298748864)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298748864)
            
            static $h = 3781568;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593716160),
    {
      "r": 65537,
      "n": "Register",
      "d": 3781568,
      "h": 8593716160,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593716160)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298748864),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3781568,
      "h": 4298748864,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298748864)
  ],
  "h": 3781568
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3781568)
        
        

        //--TRIMMABLE-BOUNDARY-START(5157824)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelCustomAttributesProviderRegistrar1`, ($self) => class ServiceTierModelCustomAttributesProviderRegistrar1
        {
            //--TRIMMABLE-BOUNDARY-START(4300125120)
            static /*void */ AddGeneratedFastAttributesOfServiceTierModel(TServiceTierType, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300125120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType).$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider$$(TServiceTierType), $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider$$(TServiceTierType).GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4300125120)
            
            static $h = 5157824;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300125120),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TServiceTierType"
      ],
      "n": "AddGeneratedFastAttributesOfServiceTierModel",
      "d": 5157824,
      "h": 4300125120,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4300125120)
  ],
  "h": 5157824
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelCustomAttributesProviderRegistrar1`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelCustomAttributesProviderRegistrar1`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5157824)
        
        

        //--TRIMMABLE-BOUNDARY-START(1618880)
        $asm.$cls(`$AvdQ.LCFCP.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296586176)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296586176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.CatalogueCategoryFlags.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.CatalogueCategoryFlagsCustomAttributesProvider, $.$AvdQ.LCFCP.CatalogueCategoryFlagsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ICatalogueCategoryModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ICatalogueCategoryModelCustomAttributesProvider, $.$AvdQ.LCFCP.ICatalogueCategoryModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.CatalogueFlags.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.CatalogueFlagsCustomAttributesProvider, $.$AvdQ.LCFCP.CatalogueFlagsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.DynamicServiceFeatureType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.DynamicServiceFeatureTypeCustomAttributesProvider, $.$AvdQ.LCFCP.DynamicServiceFeatureTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.DynamicServiceTierType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.DynamicServiceTierTypeCustomAttributesProvider, $.$AvdQ.LCFCP.DynamicServiceTierTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ICatalogueModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ICatalogueModelCustomAttributesProvider, $.$AvdQ.LCFCP.ICatalogueModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.IEditableCatalogueModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.IEditableCatalogueModelCustomAttributesProvider, $.$AvdQ.LCFCP.IEditableCatalogueModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ICatalogueOrderItemModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ICatalogueOrderItemModelCustomAttributesProvider, $.$AvdQ.LCFCP.ICatalogueOrderItemModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ICatalogueOrderModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ICatalogueOrderModelCustomAttributesProvider, $.$AvdQ.LCFCP.ICatalogueOrderModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ICatalogueSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ICatalogueSettingsCustomAttributesProvider, $.$AvdQ.LCFCP.ICatalogueSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ICatalogueVariantModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ICatalogueVariantModelCustomAttributesProvider, $.$AvdQ.LCFCP.ICatalogueVariantModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.IEditableCatalogueOrderItemModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.IEditableCatalogueOrderItemModelCustomAttributesProvider, $.$AvdQ.LCFCP.IEditableCatalogueOrderItemModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.InvoiceItemModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.InvoiceItemModelCustomAttributesProvider, $.$AvdQ.LCFCP.InvoiceItemModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.IInvoiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.IInvoiceModelCustomAttributesProvider, $.$AvdQ.LCFCP.IInvoiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.InvoiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.InvoiceModelCustomAttributesProvider, $.$AvdQ.LCFCP.InvoiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.InvoicePaymentMethod.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.InvoicePaymentMethodCustomAttributesProvider, $.$AvdQ.LCFCP.InvoicePaymentMethodCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.IProductCatalogueModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.IProductCatalogueModelCustomAttributesProvider, $.$AvdQ.LCFCP.IProductCatalogueModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.IServiceCatalogueModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.IServiceCatalogueModelCustomAttributesProvider, $.$AvdQ.LCFCP.IServiceCatalogueModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ServiceTierFlags.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ServiceTierFlagsCustomAttributesProvider, $.$AvdQ.LCFCP.ServiceTierFlagsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ServiceTierModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider, $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ServiceType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ServiceTypeCustomAttributesProvider, $.$AvdQ.LCFCP.ServiceTypeCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4296586176)
            
            static $h = 1618880;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296586176),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 1618880,
      "h": 4296586176,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296586176)
  ],
  "h": 1618880
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1618880)
        
        

        //--TRIMMABLE-BOUNDARY-START(4305856)
        $asm.$cls(`$AvdQ.LCFCP.IServiceCatalogueModelCustomAttributesProvider`, ($self) => class IServiceCatalogueModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299273152)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299273152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4299273152)
            
            static $h = 4305856;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299273152),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4305856,
      "h": 4299273152,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299273152)
  ],
  "h": 4305856
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.IServiceCatalogueModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}IServiceCatalogueModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4305856)
        
        

        //--TRIMMABLE-BOUNDARY-START(5485504)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelTypeDescriptorBuilder`, ($self) => class ServiceTierModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595420096)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595420096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor()
                        const $t1 = $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $liwyib ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5485504,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AvdQ.LCFCP.ServiceTierModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595420096)
            
            //--TRIMMABLE-BOUNDARY-START(4300452800)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300452800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300452800)
            
            //--TRIMMABLE-BOUNDARY-START(4300452800)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300452800)
            
            static $h = 5485504;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595420096),
    {
      "r": 65537,
      "n": "Register",
      "d": 5485504,
      "h": 8595420096,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595420096)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300452800),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5485504,
      "h": 4300452800,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300452800)
  ],
  "h": 5485504
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5485504)
        
        

        //--TRIMMABLE-BOUNDARY-START(5026752)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider<,>`, (TServiceTierType, TFeatures) => $asm.$gt(`$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider<,>`, [TServiceTierType, TFeatures], ($self) => class ServiceTierModelCustomAttributesProvider$$$
        {
            //--TRIMMABLE-BOUNDARY-START(4299994048)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299994048)
            
            //--TRIMMABLE-BOUNDARY-START(8594961344)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594961344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider$$$(TServiceTierType, TFeatures).compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ServiceType", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (8);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ServiceFeatures", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (9);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider$$$(TServiceTierType, TFeatures).compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $BkvZKa ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $GTpEva ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594961344)
            
            static $H = 5026752;
            static $h = 5026752;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594961344),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": this.$h,
      "H": 8594961344,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594961344)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299994048),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": this.$h,
      "H": 4299994048,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299994048)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TFeatures?.$h??1638400,
      "n": "TFeatures",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 5026752,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelCustomAttributesProvider<${TServiceTierType?.$fullName},${TFeatures?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelCustomAttributesProvider$${TServiceTierType?.$getFullName(separator)}$${TFeatures?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(5026752)
        
        

        //--TRIMMABLE-BOUNDARY-START(4961216)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider`, ($self) => class ServiceTierModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299928512)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299928512)
            
            //--TRIMMABLE-BOUNDARY-START(8594895808)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594895808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(16, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Name", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Title", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Description", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (2);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Limit", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (3);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LimitQuantification", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (4);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Duration", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (5);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Cost", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Order = (6);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("AmountQualification", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Order = (7);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Icon", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ParentTier", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ServiceTiers", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t13 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$4();
                            $i13.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ServiceTierName", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t14 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$4();
                            $i14.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Service", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t15 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i15 = new $t15();
                            $i15.$ctor$4();
                            $i15.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i15;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Features", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t16 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i16 = new $t16();
                            $i16.$ctor$4();
                            $i16.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i16;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CalculateCost", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t17 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i17 = new $t17();
                            $i17.$ctor$4();
                            $i17.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i17;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("UserInformation", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t18 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i18 = new $t18();
                            $i18.$ctor$4();
                            $i18.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i18;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ZcuPWc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4961216,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $VppTSi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4961216,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594895808)
            
            static $h = 4961216;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594895808),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4961216,
      "h": 8594895808,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594895808)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299928512),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4961216,
      "h": 4299928512,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299928512)
  ],
  "h": 4961216
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4961216)
        
        

        //--TRIMMABLE-BOUNDARY-START(5223360)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelCustomAttributesProviderRegistrar2`, ($self) => class ServiceTierModelCustomAttributesProviderRegistrar2
        {
            //--TRIMMABLE-BOUNDARY-START(4300190656)
            static /*void */ AddGeneratedFastAttributesOfServiceTierModel(TServiceTierType, TFeatures, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300190656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures).$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider$$$(TServiceTierType, TFeatures), $.$AvdQ.LCFCP.ServiceTierModelCustomAttributesProvider$$$(TServiceTierType, TFeatures).GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4300190656)
            
            static $h = 5223360;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300190656),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TServiceTierType",
        "TFeatures"
      ],
      "n": "AddGeneratedFastAttributesOfServiceTierModel",
      "d": 5223360,
      "h": 4300190656,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4300190656)
  ],
  "h": 5223360
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelCustomAttributesProviderRegistrar2`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelCustomAttributesProviderRegistrar2`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5223360)
        
        

        //--TRIMMABLE-BOUNDARY-START(5551040)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelTypeDescriptorBuilder<,>`, (TServiceTierType, TFeatures) => $asm.$gt(`$AvdQ.LCFCP.ServiceTierModelTypeDescriptorBuilder<,>`, [TServiceTierType, TFeatures], ($self) => class ServiceTierModelTypeDescriptorBuilder$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595485632)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595485632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$$(TServiceTierType, TFeatures)()
                        const $t1 = $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$$(TServiceTierType, TFeatures);
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TFeatures>");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $Yxvfba ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures).$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595485632)
            
            //--TRIMMABLE-BOUNDARY-START(4300518336)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300518336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300518336)
            
            //--TRIMMABLE-BOUNDARY-START(4300518336)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300518336)
            
            static $H = 5551040;
            static $h = 5551040;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595485632),
    {
      "r": 65537,
      "n": "Register",
      "d": this.$h,
      "H": 8595485632,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595485632)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300518336),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4300518336,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300518336)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TFeatures?.$h??1638400,
      "n": "TFeatures",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 5551040,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelTypeDescriptorBuilder<${TServiceTierType?.$fullName},${TFeatures?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelTypeDescriptorBuilder$${TServiceTierType?.$getFullName(separator)}$${TFeatures?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(5551040)
        
        

        //--TRIMMABLE-BOUNDARY-START(1291200)
        $asm.$cls(`$AvdQ.LCFCP.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181160384)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17181160384)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4296258496)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296258496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296258496)
            
            //--TRIMMABLE-BOUNDARY-START(4296258496)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296258496)
            
            static $h = 1291200;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181160384),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886193088,
        "f": 50331649
      },
      "n": "Paths",
      "d": 1291200,
      "h": 17181160384,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181160384)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296258496),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1291200,
      "h": 4296258496,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296258496)
  ],
  "h": 1291200
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1291200)
        
        

        //--TRIMMABLE-BOUNDARY-START(3584960)
        $asm.$cls(`$AvdQ.LCFCP.InvoiceModel`, ($self) => class InvoiceModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(279176459200)
            /*string?*/ Title = null;
            //--TRIMMABLE-BOUNDARY-END(279176459200)
            
            //--TRIMMABLE-BOUNDARY-START(171802276800)
            /*string?*/ InvoiceNumber = null;
            //--TRIMMABLE-BOUNDARY-END(171802276800)
            
            //--TRIMMABLE-BOUNDARY-START(163212342208)
            /*DateTime*/ InvoiceDate;
            //--TRIMMABLE-BOUNDARY-END(163212342208)
            
            //--TRIMMABLE-BOUNDARY-START(176097244096)
            /*IContact?*/ InvoiceTo = null;
            //--TRIMMABLE-BOUNDARY-END(176097244096)
            
            //--TRIMMABLE-BOUNDARY-START(167507309504)
            /*IContact?*/ InvoiceFrom = null;
            //--TRIMMABLE-BOUNDARY-END(167507309504)
            
            //--TRIMMABLE-BOUNDARY-START(184687178688)
            /*InvoicePaymentMethod*/ Payment = 0;
            //--TRIMMABLE-BOUNDARY-END(184687178688)
            
            //--TRIMMABLE-BOUNDARY-START(55838159808)
            /*BankAccount*/ Bank;
            //--TRIMMABLE-BOUNDARY-END(55838159808)
            
            //--TRIMMABLE-BOUNDARY-START(60133127104)
            /*IEnumerable<IInvoiceItem>*/ Catalogues = null;
            //--TRIMMABLE-BOUNDARY-END(60133127104)
            
            //--TRIMMABLE-BOUNDARY-START(188982145984)
            /*IEnumerable<IInvoicePayment>?*/ Payments = null;
            //--TRIMMABLE-BOUNDARY-END(188982145984)
            
            //--TRIMMABLE-BOUNDARY-START(64428094400)
            /*double?*/ Discount = null;
            //--TRIMMABLE-BOUNDARY-END(64428094400)
            
            //--TRIMMABLE-BOUNDARY-START(180392211392)
            /*Money?*/ MinimumPartPayment = null;
            //--TRIMMABLE-BOUNDARY-END(180392211392)
            
            //--TRIMMABLE-BOUNDARY-START(133147112384)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.Title.get
            get LCFCP$IInvoiceModel$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276654528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(133147112384)
            
            //--TRIMMABLE-BOUNDARY-START(90197439424)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.InvoiceNumber.get
            get LCFCP$IInvoiceModel$InvoiceNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801818048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvoiceNumber;
            }
            //--TRIMMABLE-BOUNDARY-END(90197439424)
            
            //--TRIMMABLE-BOUNDARY-START(73017570240)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.InvoiceDate.get
            get LCFCP$IInvoiceModel$InvoiceDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211883456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvoiceDate;
            }
            //--TRIMMABLE-BOUNDARY-END(73017570240)
            
            //--TRIMMABLE-BOUNDARY-START(98787374016)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.InvoiceTo.get
            get LCFCP$IInvoiceModel$InvoiceTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096785344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvoiceTo;
            }
            //--TRIMMABLE-BOUNDARY-END(98787374016)
            
            //--TRIMMABLE-BOUNDARY-START(81607504832)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.InvoiceFrom.get
            get LCFCP$IInvoiceModel$InvoiceFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506850752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvoiceFrom;
            }
            //--TRIMMABLE-BOUNDARY-END(81607504832)
            
            //--TRIMMABLE-BOUNDARY-START(115967243200)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.Payment.get
            get LCFCP$IInvoiceModel$Payment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184686719936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Payment;
            }
            //--TRIMMABLE-BOUNDARY-END(115967243200)
            
            //--TRIMMABLE-BOUNDARY-START(38657831872)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.Bank.get
            get LCFCP$IInvoiceModel$Bank()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593060800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Bank;
            }
            //--TRIMMABLE-BOUNDARY-END(38657831872)
            
            //--TRIMMABLE-BOUNDARY-START(47247766464)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.Catalogues.get
            get LCFCP$IInvoiceModel$Catalogues()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888028096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Catalogues;
            }
            //--TRIMMABLE-BOUNDARY-END(47247766464)
            
            //--TRIMMABLE-BOUNDARY-START(124557177792)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.Payments.get
            get LCFCP$IInvoiceModel$Payments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981687232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Payments;
            }
            //--TRIMMABLE-BOUNDARY-END(124557177792)
            
            //--TRIMMABLE-BOUNDARY-START(55837701056)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.Discount.get
            get LCFCP$IInvoiceModel$Discount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182995392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Discount;
            }
            //--TRIMMABLE-BOUNDARY-END(55837701056)
            
            //--TRIMMABLE-BOUNDARY-START(107377308608)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceModel.MinimumPartPayment.get
            get LCFCP$IInvoiceModel$MinimumPartPayment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391752640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MinimumPartPayment;
            }
            //--TRIMMABLE-BOUNDARY-END(107377308608)
            
            //--TRIMMABLE-BOUNDARY-START(51543192512)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543192512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51543192512)
            
            //--TRIMMABLE-BOUNDARY-START(51543192512)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(51543192512)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(163212342208)
                this.InvoiceDate = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(163212342208)
                
                //--TRIMMABLE-BOUNDARY-START(55838159808)
                this.Bank = $.$default($.$fPer.LCFCD.BankAccount);
                //--TRIMMABLE-BOUNDARY-END(55838159808)
                
                //--TRIMMABLE-BOUNDARY-START(60133127104)
                this.Catalogues = $.$sl.SL.Enumerable.Empty($.$AvdQ.LCFCP.IInvoiceItem);
                //--TRIMMABLE-BOUNDARY-END(60133127104)
                
                //--TRIMMABLE-BOUNDARY-START(180392211392)
                this.MinimumPartPayment = null;
                //--TRIMMABLE-BOUNDARY-END(180392211392)
                
            }
            static $h = 3584960;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(279176459200),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158917374912,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274881491904,
        "f": 83886081
      },
      "n": "Title",
      "d": 3584960,
      "h": 279176459200,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279176459200),
//--TRIMMABLE-BOUNDARY-START(171802276800),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115967701952,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231931818944,
        "f": 83886081
      },
      "n": "InvoiceNumber",
      "d": 3584960,
      "h": 171802276800,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171802276800),
//--TRIMMABLE-BOUNDARY-START(163212342208),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787832768,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214751949760,
        "f": 83886081
      },
      "n": "InvoiceDate",
      "d": 3584960,
      "h": 163212342208,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163212342208),
//--TRIMMABLE-BOUNDARY-START(176097244096),
    {
      "p": 5081430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124557636544,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240521753536,
        "f": 83886081
      },
      "n": "InvoiceTo",
      "d": 3584960,
      "h": 176097244096,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176097244096),
//--TRIMMABLE-BOUNDARY-START(167507309504),
    {
      "p": 5081430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107377767360,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223341884352,
        "f": 83886081
      },
      "n": "InvoiceFrom",
      "d": 3584960,
      "h": 167507309504,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167507309504),
//--TRIMMABLE-BOUNDARY-START(184687178688),
    {
      "p": 3912640,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141737505728,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257701622720,
        "f": 83886081
      },
      "n": "Payment",
      "d": 3584960,
      "h": 184687178688,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184687178688),
//--TRIMMABLE-BOUNDARY-START(55838159808),
    {
      "p": 5474646,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73018028992,
        "f": 50331649
      },
      "n": "Bank",
      "d": 3584960,
      "h": 55838159808,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55838159808),
//--TRIMMABLE-BOUNDARY-START(60133127104),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607963584,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197572080576,
        "f": 83886081
      },
      "n": "Catalogues",
      "d": 3584960,
      "h": 60133127104,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60133127104),
//--TRIMMABLE-BOUNDARY-START(188982145984),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoicePayment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150327440320,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266291557312,
        "f": 83886081
      },
      "n": "Payments",
      "d": 3584960,
      "h": 188982145984,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188982145984),
//--TRIMMABLE-BOUNDARY-START(64428094400),
    {
      "p": $.$typeNullable($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197898176,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206162015168,
        "f": 83886081
      },
      "n": "Discount",
      "d": 3584960,
      "h": 64428094400,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64428094400),
//--TRIMMABLE-BOUNDARY-START(180392211392),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133147571136,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249111688128,
        "f": 83886081
      },
      "n": "MinimumPartPayment",
      "d": 3584960,
      "h": 180392211392,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180392211392)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51543192512),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3584960,
      "h": 51543192512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51543192512)
  ],
  "h": 3584960
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.IInvoiceModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3584960)
        
        

        //--TRIMMABLE-BOUNDARY-START(3322816)
        $asm.$cls(`$AvdQ.LCFCP.InvoiceItemModel`, ($self) => class InvoiceItemModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51542930368)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(51542930368)
            
            //--TRIMMABLE-BOUNDARY-START(21478159296)
            /*Money*/ Cost;
            //--TRIMMABLE-BOUNDARY-END(21478159296)
            
            //--TRIMMABLE-BOUNDARY-START(55837897664)
            /*int*/ Quantity = 0;
            //--TRIMMABLE-BOUNDARY-END(55837897664)
            
            //--TRIMMABLE-BOUNDARY-START(25772864448)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceItem.Cost.get
            get LCFCP$IInvoiceItem$Cost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298027968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Cost;
            }
            //--TRIMMABLE-BOUNDARY-END(25772864448)
            
            //--TRIMMABLE-BOUNDARY-START(60132602816)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IInvoiceItem.Quantity.get
            get LCFCP$IInvoiceItem$Quantity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017504704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Quantity;
            }
            //--TRIMMABLE-BOUNDARY-END(60132602816)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17183192000)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183192000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183192000)
            
            //--TRIMMABLE-BOUNDARY-START(17183192000)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17183192000)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21478159296)
                this.Cost = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(21478159296)
                
                //--TRIMMABLE-BOUNDARY-START(55837897664)
                this.Quantity = 1;
                //--TRIMMABLE-BOUNDARY-END(55837897664)
                
            }
            static $h = 3322816;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542930368),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658028480,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73017766848,
        "f": 83886081
      },
      "n": "Name",
      "d": 3322816,
      "h": 51542930368,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542930368),
//--TRIMMABLE-BOUNDARY-START(21478159296),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068093888,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64427832256,
        "f": 83886081
      },
      "n": "Cost",
      "d": 3322816,
      "h": 21478159296,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21478159296),
//--TRIMMABLE-BOUNDARY-START(55837897664),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247963072,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81607701440,
        "f": 83886081
      },
      "n": "Quantity",
      "d": 3322816,
      "h": 55837897664,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55837897664)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183192000),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3322816,
      "h": 17183192000,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183192000)
  ],
  "h": 3322816
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.IInvoiceItem, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoiceItemModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoiceItemModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3322816)
        
        

        //--TRIMMABLE-BOUNDARY-START(439232)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueCategory`, ($self) => class CatalogueCategory extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115964556224)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(115964556224)
            
            //--TRIMMABLE-BOUNDARY-START(167504163776)
            /*string */ get Title()
            {
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(167504163776)
            
            //--TRIMMABLE-BOUNDARY-START(25770243008)
            /*string*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(25770243008)
            
            //--TRIMMABLE-BOUNDARY-START(103079654336)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(103079654336)
            
            //--TRIMMABLE-BOUNDARY-START(107374621632)
            /*string*/ id = null;
            //--TRIMMABLE-BOUNDARY-END(107374621632)
            
            //--TRIMMABLE-BOUNDARY-START(163209196480)
            /*string */ get SKU()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899785152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let __ca1__;
                return this.id ?? ((__ca1__ = this.Name) !== null ? $.$$.S.String.Replace$3.call(__ca1__, " ", "-") : null);
            }
            /*string */ set SKU(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914229184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.id = value;
            }
            //--TRIMMABLE-BOUNDARY-END(163209196480)
            
            //--TRIMMABLE-BOUNDARY-START(111669588928)
            /*string */ get Link()
            {
                return `Category/${$.$strNN(this.SKU)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(111669588928)
            
            //--TRIMMABLE-BOUNDARY-START(34360177600)
            /*CatalogueCategoryFlags*/ Flags = 0;
            //--TRIMMABLE-BOUNDARY-END(34360177600)
            
            //--TRIMMABLE-BOUNDARY-START(171799131072)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799131072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(171799131072)
            
            //--TRIMMABLE-BOUNDARY-START(98784687040)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784687040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.GetHashCode.call(this.SKU);
            }
            //--TRIMMABLE-BOUNDARY-END(98784687040)
            
            //--TRIMMABLE-BOUNDARY-START(30065210304)
            /*bool */ Equals$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065210304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let c;
                if ($.$is(obj, $.$AvdQ.LCFCP.CatalogueCategory, { set $v($v){ c = $v; } }))
                {
                    return c.SKU === this.SKU;
                }
                return $.$$.S.Object.Equals$1.call(this, obj);
            }
            //--TRIMMABLE-BOUNDARY-END(30065210304)
            
            //--TRIMMABLE-BOUNDARY-START(30066521024)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueCategoryModel.SKU.get
            get LCFCP$ICatalogueCategoryModel$SKU()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656455616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SKU;
            }
            //--TRIMMABLE-BOUNDARY-END(30066521024)
            
            //--TRIMMABLE-BOUNDARY-START(21476586432)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueCategoryModel.Link.get
            get LCFCP$ICatalogueCategoryModel$Link()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361488320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Link;
            }
            //--TRIMMABLE-BOUNDARY-END(21476586432)
            
            //--TRIMMABLE-BOUNDARY-START(12886651840)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueCategoryModel.Flags.get
            get LCFCP$ICatalogueCategoryModel$Flags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296717248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Flags;
            }
            //--TRIMMABLE-BOUNDARY-END(12886651840)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(21475275712)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475275712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475275712)
            
            //--TRIMMABLE-BOUNDARY-START(21475275712)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475275712)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(103079654336)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(103079654336)
                
                //--TRIMMABLE-BOUNDARY-START(34360177600)
                this.Flags = 1;
                //--TRIMMABLE-BOUNDARY-END(34360177600)
                
            }
            static $h = 439232;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964556224),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309850560,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324294592,
        "f": 83886081
      },
      "n": "Name",
      "d": 439232,
      "h": 115964556224,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964556224),
//--TRIMMABLE-BOUNDARY-START(167504163776),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489719744,
        "f": 50331649
      },
      "n": "Title",
      "d": 439232,
      "h": 167504163776,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504163776),
//--TRIMMABLE-BOUNDARY-START(25770243008),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950112192,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554490816,
        "f": 83886081
      },
      "n": "Description",
      "d": 439232,
      "h": 25770243008,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770243008),
//--TRIMMABLE-BOUNDARY-START(103079654336),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129981376,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734360000,
        "f": 83886081
      },
      "n": "Icon",
      "d": 439232,
      "h": 103079654336,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079654336),
//--TRIMMABLE-BOUNDARY-START(163209196480),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899785152,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914229184,
        "f": 83886081
      },
      "n": "SKU",
      "d": 439232,
      "h": 163209196480,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209196480),
//--TRIMMABLE-BOUNDARY-START(111669588928),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719915968,
        "f": 50331649
      },
      "n": "Link",
      "d": 439232,
      "h": 111669588928,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669588928),
//--TRIMMABLE-BOUNDARY-START(34360177600),
    {
      "p": 504768,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540046784,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144425408,
        "f": 83886081
      },
      "n": "Flags",
      "d": 439232,
      "h": 34360177600,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360177600)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(171799131072),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 439232,
      "h": 171799131072,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171799131072),
//--TRIMMABLE-BOUNDARY-START(98784687040),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 439232,
      "h": 98784687040,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784687040),
//--TRIMMABLE-BOUNDARY-START(30065210304),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 439232,
      "h": 30065210304,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065210304)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(107374621632),
    {
      "t": 1310721,
      "n": "id",
      "d": 439232,
      "h": 107374621632,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107374621632)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475275712),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 439232,
      "h": 21475275712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475275712)
  ],
  "h": 439232
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueCategoryModel, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueCategory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueCategory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(439232)
        
        

        //--TRIMMABLE-BOUNDARY-START(4764608)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModel`, ($self) => class ServiceTierModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(386551821248)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(386551821248)
            
            //--TRIMMABLE-BOUNDARY-START(588415284160)
            /*string? */ get Title()
            {
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(588415284160)
            
            //--TRIMMABLE-BOUNDARY-START(115968881600)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(115968881600)
            
            //--TRIMMABLE-BOUNDARY-START(360782017472)
            /*int*/ Limit = 0;
            //--TRIMMABLE-BOUNDARY-END(360782017472)
            
            //--TRIMMABLE-BOUNDARY-START(369371952064)
            /*string?*/ LimitQuantification = null;
            //--TRIMMABLE-BOUNDARY-END(369371952064)
            
            //--TRIMMABLE-BOUNDARY-START(120263848896)
            /*TimeSpan?*/ Duration = null;
            //--TRIMMABLE-BOUNDARY-END(120263848896)
            
            //--TRIMMABLE-BOUNDARY-START(111673914304)
            /*Money*/ Cost;
            //--TRIMMABLE-BOUNDARY-END(111673914304)
            
            //--TRIMMABLE-BOUNDARY-START(94494045120)
            /*string?*/ AmountQualification = null;
            //--TRIMMABLE-BOUNDARY-END(94494045120)
            
            //--TRIMMABLE-BOUNDARY-START(347897115584)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(347897115584)
            
            //--TRIMMABLE-BOUNDARY-START(395141755840)
            /*ServiceTierModel?*/ ParentTier = null;
            //--TRIMMABLE-BOUNDARY-END(395141755840)
            
            //--TRIMMABLE-BOUNDARY-START(412321625024)
            /*Pager<ServiceTierModel>?*/ ServiceTiers = null;
            //--TRIMMABLE-BOUNDARY-END(412321625024)
            
            //--TRIMMABLE-BOUNDARY-START(408026657728)
            /*string?*/ ServiceTierName = null;
            //--TRIMMABLE-BOUNDARY-END(408026657728)
            
            //--TRIMMABLE-BOUNDARY-START(403731690432)
            /*Enum*/ $Service = 0;
            /*Enum */ get Service()
            {
                return this.$Service;
            }
             /*Enum */ set Service(value)
            {
                this.$Service = value;
            }
            //--TRIMMABLE-BOUNDARY-END(403731690432)
            
            //--TRIMMABLE-BOUNDARY-START(133148750784)
            /*Enum*/ $Features = 0;
            /*Enum */ get Features()
            {
                return this.$Features;
            }
             /*Enum */ set Features(value)
            {
                this.$Features = value;
            }
            //--TRIMMABLE-BOUNDARY-END(133148750784)
            
            //--TRIMMABLE-BOUNDARY-START(107378947008)
            /*ServiceSubscriptionTierCostCalculator?*/ CalculateCost = null;
            //--TRIMMABLE-BOUNDARY-END(107378947008)
            
            //--TRIMMABLE-BOUNDARY-START(365076984768)
            /*string?*/ LimitLabel = null;
            //--TRIMMABLE-BOUNDARY-END(365076984768)
            
            //--TRIMMABLE-BOUNDARY-START(124558816192)
            /*string?*/ DurationLabel = null;
            //--TRIMMABLE-BOUNDARY-END(124558816192)
            
            //--TRIMMABLE-BOUNDARY-START(597005218752)
            /*Type?*/ UserInformation = null;
            //--TRIMMABLE-BOUNDARY-END(597005218752)
            
            //--TRIMMABLE-BOUNDARY-START(352192082880)
            /*string?*/ id = null;
            //--TRIMMABLE-BOUNDARY-END(352192082880)
            
            //--TRIMMABLE-BOUNDARY-START(356487050176)
            /*string */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219048096704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.id ?? this.Name;
            }
            /*string */ set Id(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489631036352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.id = value;
            }
            //--TRIMMABLE-BOUNDARY-END(356487050176)
            
            //--TRIMMABLE-BOUNDARY-START(399436723136)
            /*SchemaAttribute?*/ Schema = null;
            //--TRIMMABLE-BOUNDARY-END(399436723136)
            
            //--TRIMMABLE-BOUNDARY-START(343602148288)
            /*ValueTask<IEnumerable<IChildrenHierachy>?> *//*async*/  GetChildren()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy)), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(343602148288);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.ServiceTiers !== null)
                    {
                        let $t1, $r1;
                        /*var*/ let v = ($t1 = this.ServiceTiers.Invoke($.$fPer.LCFCD.DataFilter.Default), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.N.InterfaceVarianceStubHandler.Create(v.Data, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ServiceTierModel), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy)));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(343602148288)
            
            //--TRIMMABLE-BOUNDARY-START(579825349568)
            /*object?*/ Tag = null;
            //--TRIMMABLE-BOUNDARY-END(579825349568)
            
            //--TRIMMABLE-BOUNDARY-START(390846788544)
            /*IParentHierachy? */ get Parent()
            {
                return this.ParentTier;
            }
            //--TRIMMABLE-BOUNDARY-END(390846788544)
            
            //--TRIMMABLE-BOUNDARY-START(382256853952)
            /*Pager<IPaymentTier>? */ get LCFCP$IPaymentTier$ServiceTiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377961886656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.Frameworks.Common.Data.Pager<LivingThing.Core.Frameworks.Common.Product.ServiceTierModel>?*/ let __ca1__;
                return _ = ((__ca1__ = this.ServiceTiers) !== null ? $.$fPer.LCFCD.Paging.Cast$1($.$AvdQ.LCFCP.ServiceTierModel, $.$nYKj.LCFCP.IPaymentTier, __ca1__) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(382256853952)
            
            //--TRIMMABLE-BOUNDARY-START(584120316864)
            /*Enum */ get Tier()
            {
                return this.Service;
            }
            //--TRIMMABLE-BOUNDARY-END(584120316864)
            
            //--TRIMMABLE-BOUNDARY-START(98789012416)
            /*IDictionary<string, object?>?*/ Attributes = null;
            //--TRIMMABLE-BOUNDARY-END(98789012416)
            
            //--TRIMMABLE-BOUNDARY-START(103083979712)
            /*ServiceTierModel */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103083979712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ServiceTiers !== null)
                {
                    let $en2 = this.ServiceTiers.Invoke($.$fPer.LCFCD.DataFilter.Default).Result.Data.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let c = $en2.SCG$IEnumerator$$$Current;
                        {
                            c.ParentTier = this;
                            c.Build();
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(103083979712)
            
            //--TRIMMABLE-BOUNDARY-START(128853783488)
            /*bool */ Equals$2(/*ServiceTierModel?*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128853783488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return other === this || this.Id === (other?.Id ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(128853783488)
            
            //--TRIMMABLE-BOUNDARY-START(592710251456)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592710251456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name ?? $.$$.S.Object.ToString.call(this);
            }
            //--TRIMMABLE-BOUNDARY-END(592710251456)
            
            //--TRIMMABLE-BOUNDARY-START(21475575576)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTier.Id.get
            get LCFCP$IPaymentTier$Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130281240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(21475575576)
            
            //--TRIMMABLE-BOUNDARY-START(47245379352)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTier.Tier.get
            get LCFCP$IPaymentTier$Tier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015183128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Tier;
            }
            //--TRIMMABLE-BOUNDARY-END(47245379352)
            
            //--TRIMMABLE-BOUNDARY-START(12885640984)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTier.Cost.get
            get LCFCP$IPaymentTier$Cost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295706392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Cost;
            }
            //--TRIMMABLE-BOUNDARY-END(12885640984)
            
            //--TRIMMABLE-BOUNDARY-START(30065510168)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTier.ServiceTierName.get
            get LCFCP$IPaymentTier$ServiceTierName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425248536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceTierName;
            }
            //--TRIMMABLE-BOUNDARY-END(30065510168)
            
            //--TRIMMABLE-BOUNDARY-START(55835313944)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTier.UserInformation.get
            get LCFCP$IPaymentTier$UserInformation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310150424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UserInformation;
            }
            //--TRIMMABLE-BOUNDARY-END(55835313944)
            
            //--TRIMMABLE-BOUNDARY-START(8610810198)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IParentHierachy.Parent.get
            get LCFCD$IParentHierachy$Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12905777494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parent;
            }
            //--TRIMMABLE-BOUNDARY-END(8610810198)
            
            //--TRIMMABLE-BOUNDARY-START(4310927702)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IChildrenHierachy.GetChildren()
            LCFCD$IChildrenHierachy$GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4310927702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChildren(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4310927702)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Frameworks.Common.Product.ServiceTierModel>.Equals(LivingThing.Core.Frameworks.Common.Product.ServiceTierModel?)
            S$IEquatable$LivingThing$Core$Frameworks$Common$Product$ServiceTierModel$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(12903156054)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDynamicDataContainer.Attributes.get
            get LCFCD$IDynamicDataContainer$Attributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313221462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Attributes;
            }
            //--TRIMMABLE-BOUNDARY-END(12903156054)
            
            //--TRIMMABLE-BOUNDARY-START(30083025238)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDynamicDataContainer.Attributes.set
            set LCFCD$IDynamicDataContainer$Attributes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313221462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Attributes = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30083025238)
            
            //--TRIMMABLE-BOUNDARY-START(12907153750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IReadOnlyDynamicDataContainer.Attributes.get
            get LCFCD$IReadOnlyDynamicDataContainer$Attributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4317219158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Attributes;
            }
            //--TRIMMABLE-BOUNDARY-END(12907153750)
            
            //--TRIMMABLE-BOUNDARY-START(90199077824)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90199077824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(90199077824)
            
            //--TRIMMABLE-BOUNDARY-START(90199077824)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(90199077824)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(120263848896)
                this.Duration = null;
                //--TRIMMABLE-BOUNDARY-END(120263848896)
                
                //--TRIMMABLE-BOUNDARY-START(111673914304)
                this.Cost = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(111673914304)
                
                //--TRIMMABLE-BOUNDARY-START(347897115584)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(347897115584)
                
            }
            static $h = 4764608;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(386551821248),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253407835072,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 523990774720,
        "f": 83886081
      },
      "n": "Name",
      "d": 4764608,
      "h": 386551821248,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(386551821248),
//--TRIMMABLE-BOUNDARY-START(588415284160),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330717246400,
        "f": 50331649
      },
      "n": "Title",
      "d": 4764608,
      "h": 588415284160,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(588415284160),
//--TRIMMABLE-BOUNDARY-START(115968881600),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176098423744,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 455271297984,
        "f": 83886081
      },
      "n": "Description",
      "d": 4764608,
      "h": 115968881600,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115968881600),
//--TRIMMABLE-BOUNDARY-START(360782017472),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227638031296,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 498220970944,
        "f": 83886081
      },
      "n": "Limit",
      "d": 4764608,
      "h": 360782017472,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(360782017472),
//--TRIMMABLE-BOUNDARY-START(369371952064),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244817900480,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 515400840128,
        "f": 83886081
      },
      "n": "LimitQuantification",
      "d": 4764608,
      "h": 369371952064,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(369371952064),
//--TRIMMABLE-BOUNDARY-START(120263848896),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184688358336,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 463861232576,
        "f": 83886081
      },
      "n": "Duration",
      "d": 4764608,
      "h": 120263848896,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120263848896),
//--TRIMMABLE-BOUNDARY-START(111673914304),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167508489152,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 446681363392,
        "f": 83886081
      },
      "n": "Cost",
      "d": 4764608,
      "h": 111673914304,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111673914304),
//--TRIMMABLE-BOUNDARY-START(94494045120),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141738685376,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 420911559616,
        "f": 83886081
      },
      "n": "AmountQualification",
      "d": 4764608,
      "h": 94494045120,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 7,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94494045120),
//--TRIMMABLE-BOUNDARY-START(347897115584),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210458162112,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 481041101760,
        "f": 83886081
      },
      "n": "Icon",
      "d": 4764608,
      "h": 347897115584,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(347897115584),
//--TRIMMABLE-BOUNDARY-START(395141755840),
    {
      "p": 4764608,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270587704256,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 532580709312,
        "f": 83886081
      },
      "n": "ParentTier",
      "d": 4764608,
      "h": 395141755840,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(395141755840),
//--TRIMMABLE-BOUNDARY-START(412321625024),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304947442624,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 558350513088,
        "f": 83886081
      },
      "n": "ServiceTiers",
      "d": 4764608,
      "h": 412321625024,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(412321625024),
//--TRIMMABLE-BOUNDARY-START(408026657728),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296357508032,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 549760578496,
        "f": 83886081
      },
      "n": "ServiceTierName",
      "d": 4764608,
      "h": 408026657728,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(408026657728),
//--TRIMMABLE-BOUNDARY-START(403731690432),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287767573440,
        "f": 50331777
      },
      "n": "Service",
      "d": 4764608,
      "h": 403731690432,
      "f": 2097281,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(403731690432),
//--TRIMMABLE-BOUNDARY-START(133148750784),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201868227520,
        "f": 50331777
      },
      "n": "Features",
      "d": 4764608,
      "h": 133148750784,
      "f": 2097281,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133148750784),
//--TRIMMABLE-BOUNDARY-START(107378947008),
    {
      "p": 4568000,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158918554560,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 438091428800,
        "f": 83886081
      },
      "n": "CalculateCost",
      "d": 4764608,
      "h": 107378947008,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107378947008),
//--TRIMMABLE-BOUNDARY-START(365076984768),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236227965888,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 506810905536,
        "f": 83886081
      },
      "n": "LimitLabel",
      "d": 4764608,
      "h": 365076984768,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(365076984768),
//--TRIMMABLE-BOUNDARY-START(124558816192),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193278292928,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 472451167168,
        "f": 83886081
      },
      "n": "DurationLabel",
      "d": 4764608,
      "h": 124558816192,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124558816192),
//--TRIMMABLE-BOUNDARY-START(597005218752),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339307180992,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 575530382272,
        "f": 83886081
      },
      "n": "UserInformation",
      "d": 4764608,
      "h": 597005218752,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(597005218752),
//--TRIMMABLE-BOUNDARY-START(356487050176),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219048096704,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 489631036352,
        "f": 83886081
      },
      "n": "Id",
      "d": 4764608,
      "h": 356487050176,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(356487050176),
//--TRIMMABLE-BOUNDARY-START(399436723136),
    {
      "p": 2197846,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279177638848,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 541170643904,
        "f": 83886081
      },
      "n": "Schema",
      "d": 4764608,
      "h": 399436723136,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(399436723136),
//--TRIMMABLE-BOUNDARY-START(579825349568),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313537377216,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 566940447680,
        "f": 83886081
      },
      "n": "Tag",
      "d": 4764608,
      "h": 579825349568,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(579825349568),
//--TRIMMABLE-BOUNDARY-START(390846788544),
    {
      "p": 20875606,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261997769664,
        "f": 50331649
      },
      "n": "Parent",
      "d": 4764608,
      "h": 390846788544,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(390846788544),
//--TRIMMABLE-BOUNDARY-START(382256853952),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$nYKj.LCFCP.IPaymentTier).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 377961886656,
        "f": 50331650
      },
      "n": "{739096}.ServiceTiers",
      "o": "LCFCP$IPaymentTier$ServiceTiers",
      "d": 4764608,
      "h": 382256853952,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(382256853952),
//--TRIMMABLE-BOUNDARY-START(584120316864),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322127311808,
        "f": 50331649
      },
      "n": "Tier",
      "d": 4764608,
      "h": 584120316864,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(584120316864),
//--TRIMMABLE-BOUNDARY-START(98789012416),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150328619968,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 429501494208,
        "f": 83886081
      },
      "n": "Attributes",
      "d": 4764608,
      "h": 98789012416,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98789012416)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(343602148288),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy)).$h,
      "n": "GetChildren",
      "d": 4764608,
      "h": 343602148288,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(343602148288),
//--TRIMMABLE-BOUNDARY-START(103083979712),
    {
      "r": 4764608,
      "n": "Build",
      "d": 4764608,
      "h": 103083979712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103083979712),
//--TRIMMABLE-BOUNDARY-START(128853783488),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 4764608
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 4764608,
      "h": 128853783488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128853783488),
//--TRIMMABLE-BOUNDARY-START(592710251456),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 4764608,
      "h": 592710251456,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(592710251456)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(352192082880),
    {
      "t": 1310721,
      "n": "id",
      "d": 4764608,
      "h": 352192082880,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(352192082880)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(90199077824),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4764608,
      "h": 90199077824,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90199077824)
  ],
  "h": 4764608
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$$.S.IEquatable$$($.$AvdQ.LCFCP.ServiceTierModel), $.$fPer.LCFCD.IDynamicDataContainer, $.$fPer.LCFCD.IReadOnlyDynamicDataContainer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4764608)
        
        

        //--TRIMMABLE-BOUNDARY-START(3847104)
        $asm.$str(`$AvdQ.LCFCP.InvoicePayment`, ($self) => class InvoicePayment extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38658552768)
            /*string*/ PaymentReference = null;
            //--TRIMMABLE-BOUNDARY-END(38658552768)
            
            //--TRIMMABLE-BOUNDARY-START(17183716288)
            /*OneOf<Money, Discount>*/ Amount;
            //--TRIMMABLE-BOUNDARY-END(17183716288)
            
            //--TRIMMABLE-BOUNDARY-START(12888748992)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888748992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888748992)
            
            //--TRIMMABLE-BOUNDARY-START(12888748992)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12888748992)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PaymentReference = this.PaymentReference;
                copy.Amount = this.Amount.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17183716288)
                this.Amount = $.$default($.$fPer.LCFCO.OneOf$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Discount));
                //--TRIMMABLE-BOUNDARY-END(17183716288)
                
            }
            static $h = 3847104;
            static $z = 32;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38658552768),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363585472,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838421952,
        "f": 83886081
      },
      "n": "PaymentReference",
      "d": 3847104,
      "h": 38658552768,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38658552768),
//--TRIMMABLE-BOUNDARY-START(17183716288),
    {
      "p": $.$fPer.LCFCO.OneOf$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Discount).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773650880,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47248487360,
        "f": 83886081
      },
      "n": "Amount",
      "d": 3847104,
      "h": 17183716288,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183716288)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888748992),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3847104,
      "h": 12888748992,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888748992)
  ],
  "h": 3847104
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoicePayment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoicePayment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3847104)
        
        

        //--TRIMMABLE-BOUNDARY-START(4502464)
        $asm.$str(`$AvdQ.LCFCP.ServiceCost`, ($self) => class ServiceCost extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(124558554048)
            /*Dictionary<string, Money>?*/ Miscellaneous = null;
            //--TRIMMABLE-BOUNDARY-END(124558554048)
            
            //--TRIMMABLE-BOUNDARY-START(133148488640)
            /*Money*/ Service;
            //--TRIMMABLE-BOUNDARY-END(133148488640)
            
            //--TRIMMABLE-BOUNDARY-START(30069273536)
            /*Discount*/ Discount;
            //--TRIMMABLE-BOUNDARY-END(30069273536)
            
            //--TRIMMABLE-BOUNDARY-START(25774306240)
            /*Money?*/ Commission = null;
            //--TRIMMABLE-BOUNDARY-END(25774306240)
            
            //--TRIMMABLE-BOUNDARY-START(188983063488)
            /*Money*/ get_Item$1(/*string*/ name)
            {
                /*System.Collections.Generic.Dictionary<string, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>?*/ let __ca1__;
                return ((__ca1__ = this.Miscellaneous) !== null ? $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$fPer.LCFCDM.Money, __ca1__, name) : new $.$fPer.LCFCDM.Money());
            }
            /*void*/ set_Item$1(/*string*/ name, /*Money*/ value)
            {
                this.Miscellaneous ??= new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCDM.Money))().$ctor$1();
                this.Miscellaneous.set_Item(name, $.$clone(value));
            }
            //--TRIMMABLE-BOUNDARY-END(188983063488)
            
            //--TRIMMABLE-BOUNDARY-START(38659208128)
            /*Money */ get Entry()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73018946496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.Dictionary<string, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>?*/ let __ca2__;
                return ((__ca2__ = this.Miscellaneous) !== null ? $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$fPer.LCFCDM.Money, __ca2__, "Entry") : new $.$fPer.LCFCDM.Money());
            }
            /*Money */ set Entry(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158918292416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Miscellaneous ??= new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCDM.Money))().$ctor$1();
                this.Miscellaneous.set_Item("Entry", $.$clone(value));
            }
            //--TRIMMABLE-BOUNDARY-END(38659208128)
            
            //--TRIMMABLE-BOUNDARY-START(128853521344)
            /*Money */ get MiscTotal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98788750272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.Dictionary<string, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>?*/ let __ca3__;
                return ((__ca3__ = this.Miscellaneous) !== null ? $.$sl.SL.Enumerable.Aggregate$1($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money, __ca3__.Values, new $.$fPer.LCFCDM.Money(), new ($.$$.S.Func$$$$($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.Money))().$ctor(this,  (/*a*/ a, /*b*/ b) =>
                {
                    return $.$fPer.LCFCDM.Money.op_Addition(a, b);
                }, $YmzZha ??= {"r":27822422,"p":[{"n":"a","p":27822422},{"n":"b","p":27822422}],"n":"","d":4502464,"h":0,"f":17825794})) : new $.$fPer.LCFCDM.Money());
            }
            //--TRIMMABLE-BOUNDARY-END(128853521344)
            
            //--TRIMMABLE-BOUNDARY-START(197572998080)
            /*Money */ get Total()
            {
                return $.$fPer.LCFCDM.Money.op_Addition(this.MiscTotal, this.Discount.Apply($.$clone(this.Service), 100));
            }
            //--TRIMMABLE-BOUNDARY-END(197572998080)
            
            //--TRIMMABLE-BOUNDARY-START(34364240832)
            /*Money */ get DiscountAmount()
            {
                return $.$fPer.LCFCDM.Money.op_Subtraction(this.Service, this.Discount.Apply($.$clone(this.Service), 100));
            }
            //--TRIMMABLE-BOUNDARY-END(34364240832)
            
            //--TRIMMABLE-BOUNDARY-START(120263586752)
            /*bool */ HasValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120263586752);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$fPer.LCFCDM.MeasurementUnitExtensions.HasValue($.$fPer.LCFCDM.Money, $.$fPer.LCFCDM.MoneyUnitTypes, this.Total);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120263586752)
            
            //--TRIMMABLE-BOUNDARY-START(193278030784)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193278030784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Total.ToString$1(0);
            }
            //--TRIMMABLE-BOUNDARY-END(193278030784)
            
            //--TRIMMABLE-BOUNDARY-START(21479338944)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479338944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21479338944)
            
            //--TRIMMABLE-BOUNDARY-START(21479338944)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21479338944)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Miscellaneous = this.Miscellaneous;
                copy.Service = this.Service.$clone();
                copy.Discount = this.Discount.$clone();
                copy.Commission = this.Commission?.$clone() ?? null;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133148488640)
                this.Service = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(133148488640)
                
                //--TRIMMABLE-BOUNDARY-START(30069273536)
                this.Discount = $.$default($.$fPer.LCFCDM.Discount);
                //--TRIMMABLE-BOUNDARY-END(30069273536)
                
                //--TRIMMABLE-BOUNDARY-START(25774306240)
                this.Commission = null;
                //--TRIMMABLE-BOUNDARY-END(25774306240)
                
            }
            static $h = 4502464;
            static $z = 41;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124558554048),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90198815680,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176098161600,
        "f": 83886081
      },
      "n": "Miscellaneous",
      "d": 4502464,
      "h": 124558554048,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124558554048),
//--TRIMMABLE-BOUNDARY-START(133148488640),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107378684864,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184688096192,
        "f": 83886081
      },
      "n": "Service",
      "d": 4502464,
      "h": 133148488640,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133148488640),
//--TRIMMABLE-BOUNDARY-START(30069273536),
    {
      "p": 26446166,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55839077312,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150328357824,
        "f": 83886081
      },
      "n": "Discount",
      "d": 4502464,
      "h": 30069273536,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30069273536),
//--TRIMMABLE-BOUNDARY-START(25774306240),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47249142720,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141738423232,
        "f": 83886081
      },
      "n": "Commission",
      "d": 4502464,
      "h": 25774306240,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25774306240),
//--TRIMMABLE-BOUNDARY-START(188983063488),
    {
      "p": 27822422,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 81608881088,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167508227008,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 4502464,
      "h": 188983063488,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188983063488),
//--TRIMMABLE-BOUNDARY-START(38659208128),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73018946496,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158918292416,
        "f": 83886081
      },
      "n": "Entry",
      "d": 4502464,
      "h": 38659208128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38659208128),
//--TRIMMABLE-BOUNDARY-START(128853521344),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98788750272,
        "f": 50331649
      },
      "n": "MiscTotal",
      "d": 4502464,
      "h": 128853521344,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128853521344),
//--TRIMMABLE-BOUNDARY-START(197572998080),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115968619456,
        "f": 50331649
      },
      "n": "Total",
      "d": 4502464,
      "h": 197572998080,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197572998080),
//--TRIMMABLE-BOUNDARY-START(34364240832),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64429011904,
        "f": 50331649
      },
      "n": "DiscountAmount",
      "d": 4502464,
      "h": 34364240832,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34364240832)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120263586752),
    {
      "r": 262145,
      "n": "HasValue",
      "d": 4502464,
      "h": 120263586752,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120263586752),
//--TRIMMABLE-BOUNDARY-START(193278030784),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 4502464,
      "h": 193278030784,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193278030784)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21479338944),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4502464,
      "h": 21479338944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21479338944)
  ],
  "h": 4502464
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IJsonSerializableDataConvert ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceCost`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceCost`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4502464)
        
        

        //--TRIMMABLE-BOUNDARY-START(4568000)
        $asm.$cls(`$AvdQ.LCFCP.ServiceSubscriptionTierCostCalculator`, ($self) => class ServiceSubscriptionTierCostCalculator extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Money*/ Invoke(/**/ tier, /*$.$$.S.Int32*/ limits, /*$.$$.S.Int32*/ months)
            {
                return this.$nativeFunction.call(this.$target, tier, limits, months);
            }
            static $h = 4568000;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17184437184),
    {
      "r": 27822422,
      "p": [
        {
          "n": "tier",
          "p": 4764608
        },
        {
          "n": "limits",
          "p": 655361,
          "f": 4
        },
        {
          "n": "months",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "Invoke",
      "d": 4568000,
      "h": 17184437184,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17184437184),
//--TRIMMABLE-BOUNDARY-START(8594502592),
    {
      "r": 90570753,
      "p": [
        {
          "n": "tier",
          "p": 4764608
        },
        {
          "n": "limits",
          "p": 655361,
          "f": 4
        },
        {
          "n": "months",
          "p": 655361,
          "f": 4
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 4568000,
      "h": 8594502592,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8594502592),
//--TRIMMABLE-BOUNDARY-START(12889469888),
    {
      "r": 27822422,
      "p": [
        {
          "n": "limits",
          "p": 655361,
          "f": 4
        },
        {
          "n": "months",
          "p": 655361,
          "f": 4
        },
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 4568000,
      "h": 12889469888,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12889469888)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299535296),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4568000,
      "h": 4299535296,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299535296)
  ],
  "h": 4568000
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceSubscriptionTierCostCalculator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceSubscriptionTierCostCalculator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4568000)
        
        

        //--TRIMMABLE-BOUNDARY-START(1487808)
        $asm.$str(`$AvdQ.LCFCP.DynamicServiceTierType`, ($self) => class DynamicServiceTierType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1487808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
        
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296455104)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296455104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296455104)
            
            //--TRIMMABLE-BOUNDARY-START(4296455104)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296455104)
            
            static $h = 1487808;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296455104),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1487808,
      "h": 4296455104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296455104)
  ],
  "h": 1487808
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.DynamicServiceTierType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}DynamicServiceTierType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1487808)
        
        

        //--TRIMMABLE-BOUNDARY-START(832448)
        $asm.$str(`$AvdQ.LCFCP.CatalogueFlags`, ($self) => class CatalogueFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Featured = 1;
            static CostNegotiable = 2;
            static AuctionBidding = 4;
            static HasVariation = 8;
            static Published = 16;
            static TrackInventory = 32;
            static Default = 16;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(832448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Featured": 1n,
                    "CostNegotiable": 2n,
                    "AuctionBidding": 4n,
                    "HasVariation": 8n,
                    "Published": 16n,
                    "TrackInventory": 32n,
                    "Default": 16n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295799744)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295799744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295799744)
            
            //--TRIMMABLE-BOUNDARY-START(4295799744)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295799744)
            
            static $h = 832448;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065603520),
    {
      "t": 832448,
      "n": "None",
      "d": 832448,
      "h": 30065603520,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065603520),
//--TRIMMABLE-BOUNDARY-START(21475668928),
    {
      "t": 832448,
      "n": "Featured",
      "d": 832448,
      "h": 21475668928,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Add product to featured tab",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475668928),
//--TRIMMABLE-BOUNDARY-START(12885734336),
    {
      "t": 832448,
      "n": "CostNegotiable",
      "d": 832448,
      "h": 12885734336,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Allow buyers to offer price on this product",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885734336),
//--TRIMMABLE-BOUNDARY-START(8590767040),
    {
      "t": 832448,
      "n": "AuctionBidding",
      "d": 832448,
      "h": 8590767040,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Allow buyers to offer price on this product",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590767040),
//--TRIMMABLE-BOUNDARY-START(25770636224),
    {
      "t": 832448,
      "n": "HasVariation",
      "d": 832448,
      "h": 25770636224,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Product has more than one variation",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770636224),
//--TRIMMABLE-BOUNDARY-START(34360570816),
    {
      "t": 832448,
      "n": "Published",
      "d": 832448,
      "h": 34360570816,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Publish this product to shoppers",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360570816),
//--TRIMMABLE-BOUNDARY-START(38655538112),
    {
      "t": 832448,
      "n": "TrackInventory",
      "d": 832448,
      "h": 38655538112,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Description",
              "v": "Enable Inventory for this catalogue",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655538112),
//--TRIMMABLE-BOUNDARY-START(17180701632),
    {
      "t": 832448,
      "n": "Default",
      "d": 832448,
      "h": 17180701632,
      "f": 4194337,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180701632)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295799744),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 832448,
      "h": 4295799744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295799744)
  ],
  "h": 832448,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(832448)
        
        

        //--TRIMMABLE-BOUNDARY-START(5682112)
        $asm.$str(`$AvdQ.LCFCP.ServiceType`, ($self) => class ServiceType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static OnPremise = 1;
            static Cloud = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5682112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "OnPremise": 1n,
                    "Cloud": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4300649408)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300649408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300649408)
            
            //--TRIMMABLE-BOUNDARY-START(4300649408)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4300649408)
            
            static $h = 5682112;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890584000),
    {
      "t": 5682112,
      "n": "None",
      "d": 5682112,
      "h": 12890584000,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890584000),
//--TRIMMABLE-BOUNDARY-START(17185551296),
    {
      "t": 5682112,
      "n": "OnPremise",
      "d": 5682112,
      "h": 17185551296,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17185551296),
//--TRIMMABLE-BOUNDARY-START(8595616704),
    {
      "t": 5682112,
      "n": "Cloud",
      "d": 5682112,
      "h": 8595616704,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8595616704)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300649408),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5682112,
      "h": 4300649408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300649408)
  ],
  "h": 5682112,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5682112)
        
        

        //--TRIMMABLE-BOUNDARY-START(1356736)
        $asm.$str(`$AvdQ.LCFCP.DynamicServiceFeatureType`, ($self) => class DynamicServiceFeatureType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1356736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
        
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296324032)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296324032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296324032)
            
            //--TRIMMABLE-BOUNDARY-START(4296324032)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296324032)
            
            static $h = 1356736;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296324032),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1356736,
      "h": 4296324032,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296324032)
  ],
  "h": 1356736
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.DynamicServiceFeatureType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}DynamicServiceFeatureType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1356736)
        
        

        //--TRIMMABLE-BOUNDARY-START(3912640)
        $asm.$str(`$AvdQ.LCFCP.InvoicePaymentMethod`, ($self) => class InvoicePaymentMethod extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static BankTransfer = 1;
            static MasterCard = 2;
            static Coupon = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3912640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "BankTransfer": 1n,
                    "MasterCard": 2n,
                    "Coupon": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298879936)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298879936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298879936)
            
            //--TRIMMABLE-BOUNDARY-START(4298879936)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298879936)
            
            static $h = 3912640;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21478749120),
    {
      "t": 3912640,
      "n": "None",
      "d": 3912640,
      "h": 21478749120,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478749120),
//--TRIMMABLE-BOUNDARY-START(8593847232),
    {
      "t": 3912640,
      "n": "BankTransfer",
      "d": 3912640,
      "h": 8593847232,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593847232),
//--TRIMMABLE-BOUNDARY-START(17183781824),
    {
      "t": 3912640,
      "n": "MasterCard",
      "d": 3912640,
      "h": 17183781824,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183781824),
//--TRIMMABLE-BOUNDARY-START(12888814528),
    {
      "t": 3912640,
      "n": "Coupon",
      "d": 3912640,
      "h": 12888814528,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888814528)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298879936),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3912640,
      "h": 4298879936,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298879936)
  ],
  "h": 3912640,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoicePaymentMethod`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoicePaymentMethod`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3912640)
        
        

        //--TRIMMABLE-BOUNDARY-START(504768)
        $asm.$str(`$AvdQ.LCFCP.CatalogueCategoryFlags`, ($self) => class CatalogueCategoryFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Featured = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(504768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Featured": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295472064)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295472064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295472064)
            
            //--TRIMMABLE-BOUNDARY-START(4295472064)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295472064)
            
            static $h = 504768;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885406656),
    {
      "t": 504768,
      "n": "None",
      "d": 504768,
      "h": 12885406656,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885406656),
//--TRIMMABLE-BOUNDARY-START(8590439360),
    {
      "t": 504768,
      "n": "Featured",
      "d": 504768,
      "h": 8590439360,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590439360)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295472064),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 504768,
      "h": 4295472064,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295472064)
  ],
  "h": 504768
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueCategoryFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueCategoryFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(504768)
        
        

        //--TRIMMABLE-BOUNDARY-START(4633536)
        $asm.$str(`$AvdQ.LCFCP.ServiceTierFlags`, ($self) => class ServiceTierFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4633536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
        
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4299600832)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299600832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299600832)
            
            //--TRIMMABLE-BOUNDARY-START(4299600832)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299600832)
            
            static $h = 4633536;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299600832),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4633536,
      "h": 4299600832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299600832)
  ],
  "h": 4633536,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4633536)
        
        

        //--TRIMMABLE-BOUNDARY-START(4830144)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModel<,>`, (TServiceTierType, TFeatures) => $asm.$gt(`$AvdQ.LCFCP.ServiceTierModel<,>`, [TServiceTierType, TFeatures], ($self) => class ServiceTierModel$$$ extends $.$AvdQ.LCFCP.ServiceTierModel
        {
            //--TRIMMABLE-BOUNDARY-START(64429339584)
            /*TServiceTierType*/ ServiceType = $.$default(TServiceTierType);
            //--TRIMMABLE-BOUNDARY-END(64429339584)
            
            //--TRIMMABLE-BOUNDARY-START(60134372288)
            /*TFeatures*/ ServiceFeatures = $.$default(TFeatures);
            //--TRIMMABLE-BOUNDARY-END(60134372288)
            
            //--TRIMMABLE-BOUNDARY-START(55839404992)
            /*Enum */ get Service()
            {
                return this.ServiceType;
            }
            //--TRIMMABLE-BOUNDARY-END(55839404992)
            
            //--TRIMMABLE-BOUNDARY-START(17184699328)
            /*Enum */ get Features()
            {
                return this.ServiceFeatures;
            }
            //--TRIMMABLE-BOUNDARY-END(17184699328)
            
            //--TRIMMABLE-BOUNDARY-START(12889732032)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889732032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889732032)
            
            //--TRIMMABLE-BOUNDARY-START(12889732032)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12889732032)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64429339584)
                this.ServiceType = $.$default(TServiceTierType);
                //--TRIMMABLE-BOUNDARY-END(64429339584)
                
                //--TRIMMABLE-BOUNDARY-START(60134372288)
                this.ServiceFeatures = $.$default(TFeatures);
                //--TRIMMABLE-BOUNDARY-END(60134372288)
                
            }
            static $H = 4830144;
            static $h = 4830144;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$AvdQ.LCFCP.ServiceTierModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64429339584),
    {
      "p": TServiceTierType?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51544437696,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 81609208768,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 83886081
      },
      "n": "ServiceType",
      "d": this.$h,
      "H": 64429339584,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64429339584),
//--TRIMMABLE-BOUNDARY-START(60134372288),
    {
      "p": TFeatures?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42954503104,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 73019274176,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 83886081
      },
      "n": "ServiceFeatures",
      "d": this.$h,
      "H": 60134372288,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 9,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60134372288),
//--TRIMMABLE-BOUNDARY-START(55839404992),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34364568512,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50364417
      },
      "n": "Service",
      "d": this.$h,
      "H": 55839404992,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55839404992),
//--TRIMMABLE-BOUNDARY-START(17184699328),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25774633920,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50364417
      },
      "n": "Features",
      "d": this.$h,
      "H": 17184699328,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17184699328)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889732032),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 12889732032,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889732032)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TFeatures?.$h??1638400,
      "n": "TFeatures",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 4830144,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$$.S.IEquatable$$($.$AvdQ.LCFCP.ServiceTierModel), $.$fPer.LCFCD.IDynamicDataContainer, $.$fPer.LCFCD.IReadOnlyDynamicDataContainer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<${TServiceTierType?.$fullName},${TFeatures?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModel$${TServiceTierType?.$getFullName(separator)}$${TFeatures?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(4830144)
        
        

        //--TRIMMABLE-BOUNDARY-START(4895680)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModel<>`, (TServiceTierType) => $asm.$gt(`$AvdQ.LCFCP.ServiceTierModel<>`, [TServiceTierType], ($self) => class ServiceTierModel$$ extends $.$AvdQ.LCFCP.ServiceTierModel
        {
            //--TRIMMABLE-BOUNDARY-START(51544503232)
            /*TServiceTierType*/ ServiceType = $.$default(TServiceTierType);
            //--TRIMMABLE-BOUNDARY-END(51544503232)
            
            //--TRIMMABLE-BOUNDARY-START(47249535936)
            /*Enum */ get Service()
            {
                return this.ServiceType;
            }
            //--TRIMMABLE-BOUNDARY-END(47249535936)
            
            //--TRIMMABLE-BOUNDARY-START(42954568640)
            /*TServiceTierType */ get LCFCP$IPaymentTier$$$Tier()
            {
                return this.ServiceType;
            }
            //--TRIMMABLE-BOUNDARY-END(42954568640)
            
            //--TRIMMABLE-BOUNDARY-START(12889797568)
            /*ServiceTierModel<TServiceTierType> */ Build$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889797568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.Build();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889797568)
            
            //--TRIMMABLE-BOUNDARY-START(8594830272)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594830272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594830272)
            
            //--TRIMMABLE-BOUNDARY-START(8594830272)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8594830272)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51544503232)
                this.ServiceType = $.$default(TServiceTierType);
                //--TRIMMABLE-BOUNDARY-END(51544503232)
                
            }
            static $H = 4895680;
            static $h = 4895680;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$AvdQ.LCFCP.ServiceTierModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51544503232),
    {
      "p": TServiceTierType?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30069666752,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 60134437824,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 83886081
      },
      "n": "ServiceType",
      "d": this.$h,
      "H": 51544503232,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51544503232),
//--TRIMMABLE-BOUNDARY-START(47249535936),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21479732160,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364417
      },
      "n": "Service",
      "d": this.$h,
      "H": 47249535936,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47249535936),
//--TRIMMABLE-BOUNDARY-START(42954568640),
    {
      "p": TServiceTierType?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38659601344,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331650
      },
      "n": "{$.$nYKj.LCFCP.IPaymentTier$$(TServiceTierType).$h}.Tier",
      "o": "LCFCP$IPaymentTier$$$Tier",
      "d": this.$h,
      "H": 42954568640,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42954568640)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889797568),
    {
      "r": this.$h,
      "n": "Build",
      "o": "@$1",
      "d": this.$h,
      "H": 12889797568,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 553648129
    },
//--TRIMMABLE-BOUNDARY-END(12889797568)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594830272),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 8594830272,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594830272)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 1,
  "H": 4895680,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$AvdQ.LCFCP.ServiceTierModel), $.$fPer.LCFCD.IDynamicDataContainer, $.$fPer.LCFCD.IReadOnlyDynamicDataContainer, $.$nYKj.LCFCP.IPaymentTier$$(TServiceTierType), $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<${TServiceTierType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModel$${TServiceTierType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(4895680)
        
        

        //--TRIMMABLE-BOUNDARY-START(3716032)
        $asm.$cls(`$AvdQ.LCFCP.InvoiceModelTypeDescriptor`, ($self) => class InvoiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AvdQ.LCFCP.InvoiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298683328)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298683328);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AvdQ.LCFCP.InvoiceModelTypeDescriptor.GenerateProperties($.$AvdQ.LCFCP.InvoiceModel, this, factory);
                    }, $yxiNIg ??= {"r":65537,"n":"","d":3716032,"h":0,"f":17825794}), 0, "InvoiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Product\\IInvoiceModel_LivingThing.Core.Frameworks.Common.Product.InvoiceModelTypeDescriptorBuilder.g.cs", "InvoiceModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298683328)
            
            //--TRIMMABLE-BOUNDARY-START(12888617920)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888617920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Title";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).Title);
                        }, $TeiBEj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("InvoiceNumber"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "InvoiceNumber", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("InvoiceNumber")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "InvoiceNumber";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).InvoiceNumber);
                        }, $nCsuPj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("InvoiceDate"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "InvoiceDate", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("InvoiceDate")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "InvoiceDate";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).InvoiceDate);
                        }, $MhOCwg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("InvoiceTo"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "InvoiceTo", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("InvoiceTo")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCC$2.IContact, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "InvoiceTo";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCC$2.IContact, ($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).InvoiceTo);
                        }, $XDGXcc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("InvoiceFrom"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "InvoiceFrom", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("InvoiceFrom")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCC$2.IContact, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "InvoiceFrom";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCC$2.IContact, ($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).InvoiceFrom);
                        }, $jNfcyb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Payment"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "Payment", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Payment")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AvdQ.LCFCP.InvoicePaymentMethod, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Payment";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$AvdQ.LCFCP.InvoicePaymentMethod, ($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).Payment);
                        }, $aKLpOj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Bank"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "Bank", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Bank")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.BankAccount, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Bank";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCD.BankAccount, ($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).Bank);
                        }, $GXcEWg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Catalogues"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "Catalogues", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Catalogues")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Catalogues";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem), ($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).Catalogues);
                        }, $cyvbnj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Catalogues = value.AsReference($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem));
                        }, $VgIvWd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Payments"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "Payments", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Payments")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoicePayment), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Payments";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoicePayment), ($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).Payments);
                        }, $PcxKEh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Discount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "Discount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Discount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.Double), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Discount";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.Double, ($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).Discount);
                        }, $JcrwPa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MinimumPartPayment"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceModel.$type, $.$discardRef(), "MinimumPartPayment", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MinimumPartPayment")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$fPer.LCFCDM.Money), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "MinimumPartPayment";
                        $i21.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$fPer.LCFCDM.Money, ($.$cast(target, $.$AvdQ.LCFCP.InvoiceModel)).MinimumPartPayment);
                        }, $xOcqDc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3716032,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888617920)
            
            //--TRIMMABLE-BOUNDARY-START(17183585216)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Product.InvoiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183585216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _InvoiceNumber = _target.InvoiceNumber;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("InvoiceNumber"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _InvoiceNumber, ($v) => _InvoiceNumber = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _InvoiceDate = _target.InvoiceDate;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("InvoiceDate"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _InvoiceDate, ($v) => _InvoiceDate = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _InvoiceTo = _target.InvoiceTo;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("InvoiceTo"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCC$2.IContact));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _InvoiceTo, ($v) => _InvoiceTo = $v, $.$fPer.LCFCC$2.IContact)))
                    {
                    }
                }
                {
                    /*var*/ let _InvoiceFrom = _target.InvoiceFrom;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("InvoiceFrom"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCC$2.IContact));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _InvoiceFrom, ($v) => _InvoiceFrom = $v, $.$fPer.LCFCC$2.IContact)))
                    {
                    }
                }
                {
                    /*var*/ let _Payment = _target.Payment;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Payment"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AvdQ.LCFCP.InvoicePaymentMethod));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$AvdQ.LCFCP.InvoicePaymentMethod, () => _Payment, ($v) => _Payment = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Bank = _target.Bank;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Bank"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.BankAccount));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCD.BankAccount, () => _Bank, ($v) => _Bank = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Catalogues = _target.Catalogues;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Catalogues"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem), $.$AvdQ.LCFCP.IInvoiceItem));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem), $.$AvdQ.LCFCP.IInvoiceItem, property, $.$ref(() => _Catalogues, ($v) => _Catalogues = $v, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem))))
                    {
                        _target.Catalogues = _Catalogues;
                        if (_Catalogues !== null)
                        {
                            let $en35 = _Catalogues.SCG$IEnumerable$$$GetEnumerator();
                            while ($en35.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en35.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$AvdQ.LCFCP.IInvoiceItem)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem), $.$AvdQ.LCFCP.IInvoiceItem, property, $.$ref(() => _Catalogues, ($v) => _Catalogues = $v, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoiceItem)));
                    }
                }
                {
                    /*var*/ let _Payments = _target.Payments;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Payments"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoicePayment)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoicePayment), $.$AvdQ.LCFCP.IInvoicePayment));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoicePayment), $.$AvdQ.LCFCP.IInvoicePayment, property, $.$ref(() => _Payments, ($v) => _Payments = $v, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoicePayment))))
                    {
                        if (_Payments !== null)
                        {
                            let $en40 = _Payments.SCG$IEnumerable$$$GetEnumerator();
                            while ($en40.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en40.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$AvdQ.LCFCP.IInvoicePayment)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoicePayment), $.$AvdQ.LCFCP.IInvoicePayment, property, $.$ref(() => _Payments, ($v) => _Payments = $v, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.IInvoicePayment)));
                    }
                }
                {
                    /*var*/ let _Discount = _target.Discount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Discount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.Double)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.Double), () => _Discount, ($v) => _Discount = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _MinimumPartPayment = _target.MinimumPartPayment;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MinimumPartPayment"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$fPer.LCFCDM.Money)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$fPer.LCFCDM.Money), () => _MinimumPartPayment, ($v) => _MinimumPartPayment = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183585216)
            
            //--TRIMMABLE-BOUNDARY-START(8593650624)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Product.InvoiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593650624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AvdQ.LCFCP.InvoiceModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AvdQ.LCFCP.InvoiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.InvoiceModel)))
                {
                    /*var*/ let result = $.$AvdQ.LCFCP.InvoiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.InvoiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AvdQ.LCFCP.InvoiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.InvoiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593650624)
            
            static $h = 3716032;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AvdQ.LCFCP.InvoiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888617920),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3716032,
      "h": 12888617920,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888617920),
//--TRIMMABLE-BOUNDARY-START(17183585216),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3584960,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3716032,
      "h": 17183585216,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183585216),
//--TRIMMABLE-BOUNDARY-START(8593650624),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3584960,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3716032,
      "h": 8593650624,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593650624)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298683328),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3716032,
      "h": 4298683328,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298683328)
  ],
  "h": 3716032
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AvdQ.LCFCP.InvoiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3716032)
        
        

        //--TRIMMABLE-BOUNDARY-START(3453888)
        $asm.$cls(`$AvdQ.LCFCP.InvoiceItemModelTypeDescriptor`, ($self) => class InvoiceItemModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AvdQ.LCFCP.InvoiceItemModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298421184)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298421184);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AvdQ.LCFCP.InvoiceItemModelTypeDescriptor.GenerateProperties($.$AvdQ.LCFCP.InvoiceItemModel, this, factory);
                    }, $pUGyOj ??= {"r":65537,"n":"","d":3453888,"h":0,"f":17825794}), 0, "InvoiceItemModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Product\\IInvoiceItem_LivingThing.Core.Frameworks.Common.Product.InvoiceItemModelTypeDescriptorBuilder.g.cs", "InvoiceItemModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298421184)
            
            //--TRIMMABLE-BOUNDARY-START(12888355776)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888355776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceItemModel.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Name";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceItemModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceItemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.InvoiceItemModel)).Name);
                        }, $BUThDa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3453888,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Cost"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceItemModel.$type, $.$discardRef(), "Cost", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Cost")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Cost";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceItemModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceItemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$AvdQ.LCFCP.InvoiceItemModel)).Cost);
                        }, $rKxuCc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3453888,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Quantity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.InvoiceItemModel.$type, $.$discardRef(), "Quantity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Quantity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Quantity";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.InvoiceItemModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.InvoiceItemModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$AvdQ.LCFCP.InvoiceItemModel)).Quantity);
                        }, $PWcxYd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3453888,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888355776)
            
            //--TRIMMABLE-BOUNDARY-START(17183323072)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Product.InvoiceItemModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183323072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Cost = _target.Cost;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Cost"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _Cost, ($v) => _Cost = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Quantity = _target.Quantity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Quantity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Quantity, ($v) => _Quantity = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183323072)
            
            //--TRIMMABLE-BOUNDARY-START(8593388480)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Product.InvoiceItemModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593388480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AvdQ.LCFCP.InvoiceItemModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AvdQ.LCFCP.InvoiceItemModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.InvoiceItemModel)))
                {
                    /*var*/ let result = $.$AvdQ.LCFCP.InvoiceItemModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.InvoiceItemModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AvdQ.LCFCP.InvoiceItemModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.InvoiceItemModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593388480)
            
            static $h = 3453888;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AvdQ.LCFCP.InvoiceItemModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888355776),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3453888,
      "h": 12888355776,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888355776),
//--TRIMMABLE-BOUNDARY-START(17183323072),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3322816,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3453888,
      "h": 17183323072,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183323072),
//--TRIMMABLE-BOUNDARY-START(8593388480),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3322816,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3453888,
      "h": 8593388480,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593388480)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298421184),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3453888,
      "h": 4298421184,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298421184)
  ],
  "h": 3453888
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AvdQ.LCFCP.InvoiceItemModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.InvoiceItemModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}InvoiceItemModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3453888)
        
        

        //--TRIMMABLE-BOUNDARY-START(5288896)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelTypeDescriptor`, ($self) => class ServiceTierModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300256192)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300256192);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor.GenerateProperties($.$AvdQ.LCFCP.ServiceTierModel, this, factory);
                    }, $QfmYfa ??= {"r":65537,"n":"","d":5288896,"h":0,"f":17825794}), 0, "ServiceTierModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Product\\ServiceTierModel_LivingThing.Core.Frameworks.Common.Product.ServiceTierModelTypeDescriptorBuilder.g.cs", "ServiceTierModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300256192)
            
            //--TRIMMABLE-BOUNDARY-START(12890190784)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890190784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Name";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Name);
                        }, $emlwpj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Name = value.AsReference($.$$.S.String);
                        }, $lsxnAd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Description";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Description);
                        }, $rLcsSa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Description = value.AsReference($.$$.S.String);
                        }, $ymQcwi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Limit"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Limit", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Limit")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Limit";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Limit);
                        }, $kZQaVg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Limit = value.AsInt();
                        }, $GRvTbi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LimitQuantification"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "LimitQuantification", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LimitQuantification")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "LimitQuantification";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).LimitQuantification);
                        }, $xgGWSa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LimitQuantification = value.AsReference($.$$.S.String);
                        }, $lmpCYg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Duration"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Duration", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Duration")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeNullable($.$$.S.TimeSpan), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Duration";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromNullableValue($.$$.S.TimeSpan, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Duration);
                        }, $lodVme ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Duration = value.AsNullableValue($.$$.S.TimeSpan);
                        }, $emznTj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Cost"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Cost", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Cost")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCDM.Money, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Cost";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFCDM.Money, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Cost);
                        }, $LFWQbk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Cost = value.AsValue($.$fPer.LCFCDM.Money);
                        }, $rGvLEd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AmountQualification"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "AmountQualification", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AmountQualification")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "AmountQualification";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).AmountQualification);
                        }, $iGedde ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.AmountQualification = value.AsReference($.$$.S.String);
                        }, $yugPgb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Title";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Title);
                        }, $nRgiGg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFC.IconDescriptor, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Icon";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$fPer.LCFC.IconDescriptor, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Icon);
                        }, $nTohZk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Icon = value.AsValue($.$fPer.LCFC.IconDescriptor);
                        }, $aebDll ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ParentTier"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "ParentTier", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ParentTier")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AvdQ.LCFCP.ServiceTierModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "ParentTier";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$AvdQ.LCFCP.ServiceTierModel, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).ParentTier);
                        }, $TQYUNc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ParentTier = value.AsReference($.$AvdQ.LCFCP.ServiceTierModel);
                        }, $reJcna ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceTiers"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "ServiceTiers", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceTiers")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "ServiceTiers";
                        $i21.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel), ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).ServiceTiers);
                        }, $UKzTqb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i21.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ServiceTiers = value.AsReference($.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel));
                        }, $gLjTlf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceTierName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "ServiceTierName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceTierName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "ServiceTierName";
                        $i23.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).ServiceTierName);
                        }, $MGAXmf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i23.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ServiceTierName = value.AsReference($.$$.S.String);
                        }, $uMOZtf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Enum, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "Service";
                        $i25.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Enum, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Service);
                        }, $IZztnb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Features"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Features", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Features")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Enum, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t27 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i27 = new $t27();
                        $i27.$ctor$2();
                        $i27.Name = "Features";
                        $i27.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i27.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Enum, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Features);
                        }, $qVcmob ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i27;
                    })()), schemas, null, factory);
                    let $en28 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en28.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en28.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CalculateCost"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "CalculateCost", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CalculateCost")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$AvdQ.LCFCP.ServiceSubscriptionTierCostCalculator, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t29 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i29 = new $t29();
                        $i29.$ctor$2();
                        $i29.Name = "CalculateCost";
                        $i29.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i29.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$AvdQ.LCFCP.ServiceSubscriptionTierCostCalculator, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).CalculateCost);
                        }, $uTmnRd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i29.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CalculateCost = value.AsReference($.$AvdQ.LCFCP.ServiceSubscriptionTierCostCalculator);
                        }, $TdLlAk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i29;
                    })()), schemas, null, factory);
                    let $en30 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en30.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en30.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LimitLabel"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "LimitLabel", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LimitLabel")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t31 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i31 = new $t31();
                        $i31.$ctor$2();
                        $i31.Name = "LimitLabel";
                        $i31.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i31.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).LimitLabel);
                        }, $xLAwrg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i31.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LimitLabel = value.AsReference($.$$.S.String);
                        }, $ZMhyoe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i31;
                    })()), schemas, null, factory);
                    let $en32 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en32.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en32.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("DurationLabel"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "DurationLabel", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("DurationLabel")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t33 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i33 = new $t33();
                        $i33.$ctor$2();
                        $i33.Name = "DurationLabel";
                        $i33.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i33.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).DurationLabel);
                        }, $FSsGJa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i33.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.DurationLabel = value.AsReference($.$$.S.String);
                        }, $weRMah ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i33;
                    })()), schemas, null, factory);
                    let $en34 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en34.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en34.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UserInformation"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "UserInformation", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UserInformation")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Type, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t35 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i35 = new $t35();
                        $i35.$ctor$2();
                        $i35.Name = "UserInformation";
                        $i35.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i35.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Type, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).UserInformation);
                        }, $WsTCrj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i35.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UserInformation = value.AsReference($.$$.S.Type);
                        }, $ljvMFa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i35;
                    })()), schemas, null, factory);
                    let $en36 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en36.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en36.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t37 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i37 = new $t37();
                        $i37.$ctor$2();
                        $i37.Name = "Id";
                        $i37.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i37.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Id);
                        }, $BSORrb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i37.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $PHhqal ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i37;
                    })()), schemas, null, factory);
                    let $en38 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en38.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en38.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Schema"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Schema", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Schema")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCA$1.SchemaAttribute, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t39 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i39 = new $t39();
                        $i39.$ctor$2();
                        $i39.Name = "Schema";
                        $i39.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i39.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCA$1.SchemaAttribute, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Schema);
                        }, $zAfDQj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i39.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Schema = value.AsReference($.$fPer.LCFCA$1.SchemaAttribute);
                        }, $JyGHRi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i39;
                    })()), schemas, null, factory);
                    let $en40 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en40.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en40.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Tag"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Tag", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Tag")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Object, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t41 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i41 = new $t41();
                        $i41.$ctor$2();
                        $i41.Name = "Tag";
                        $i41.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i41.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Object, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Tag);
                        }, $cYRDCh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i41.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Tag = value.AsReference($.$$.S.Object);
                        }, $YfSSZj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i41;
                    })()), schemas, null, factory);
                    let $en42 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en42.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en42.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Parent"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Parent", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Parent")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFCD.IParentHierachy, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t43 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i43 = new $t43();
                        $i43.$ctor$2();
                        $i43.Name = "Parent";
                        $i43.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i43.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$fPer.LCFCD.IParentHierachy, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Parent);
                        }, $YODzsi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i43;
                    })()), schemas, null, factory);
                    let $en44 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en44.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en44.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Tier"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Tier", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Tier")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Enum, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t45 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i45 = new $t45();
                        $i45.$ctor$2();
                        $i45.Name = "Tier";
                        $i45.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i45.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Enum, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Tier);
                        }, $UMlNxc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i45;
                    })()), schemas, null, factory);
                    let $en46 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en46.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en46.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Attributes"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel.$type, $.$discardRef(), "Attributes", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Attributes")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t47 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i47 = new $t47();
                        $i47.$ctor$2();
                        $i47.Name = "Attributes";
                        $i47.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel";
                        $i47.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel)).Attributes);
                        }, $nnwDRb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5288896,"h":0,"f":17825826});
                        $i47.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Attributes = value.AsReference($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object));
                        }, $goCwbd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5288896,"h":0,"f":17825826});
                        return $i47;
                    })()), schemas, null, factory);
                    let $en48 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en48.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en48.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12890190784)
            
            //--TRIMMABLE-BOUNDARY-START(17185158080)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Product.ServiceTierModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185158080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                        _target.Name = _Name;
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                        _target.Description = _Description;
                    }
                }
                {
                    /*var*/ let _Limit = _target.Limit;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Limit"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Limit, ($v) => _Limit = $v, $.$$.S.Int32)))
                    {
                        _target.Limit = _Limit;
                    }
                }
                {
                    /*var*/ let _LimitQuantification = _target.LimitQuantification;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LimitQuantification"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _LimitQuantification, ($v) => _LimitQuantification = $v, $.$$.S.String)))
                    {
                        _target.LimitQuantification = _LimitQuantification;
                    }
                }
                {
                    /*var*/ let _Duration = _target.Duration;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Duration"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Nullable$$($.$$.S.TimeSpan)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$typeNullable($.$$.S.TimeSpan), () => _Duration, ($v) => _Duration = $v, null, true)))
                    {
                        _target.Duration = $.$clone(_Duration);
                    }
                }
                {
                    /*var*/ let _Cost = _target.Cost;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Cost"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCDM.Money));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFCDM.Money, () => _Cost, ($v) => _Cost = $v, null, true)))
                    {
                        _target.Cost = $.$clone(_Cost);
                    }
                }
                {
                    /*var*/ let _AmountQualification = _target.AmountQualification;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AmountQualification"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _AmountQualification, ($v) => _AmountQualification = $v, $.$$.S.String)))
                    {
                        _target.AmountQualification = _AmountQualification;
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFC.IconDescriptor));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFC.IconDescriptor, () => _Icon, ($v) => _Icon = $v, null, true)))
                    {
                        _target.Icon = $.$clone(_Icon);
                    }
                }
                {
                    /*var*/ let _ParentTier = _target.ParentTier;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ParentTier"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ParentTier, ($v) => _ParentTier = $v, $.$AvdQ.LCFCP.ServiceTierModel)))
                    {
                        _target.ParentTier = _ParentTier;
                    }
                }
                {
                    /*var*/ let _ServiceTiers = _target.ServiceTiers;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceTiers"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ServiceTiers, ($v) => _ServiceTiers = $v, $.$fPer.LCFCD.Pager$$($.$AvdQ.LCFCP.ServiceTierModel))))
                    {
                        _target.ServiceTiers = _ServiceTiers;
                    }
                }
                {
                    /*var*/ let _ServiceTierName = _target.ServiceTierName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceTierName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _ServiceTierName, ($v) => _ServiceTierName = $v, $.$$.S.String)))
                    {
                        _target.ServiceTierName = _ServiceTierName;
                    }
                }
                {
                    /*var*/ let _Service = _target.Service;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Enum));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Service, ($v) => _Service = $v, $.$$.S.Enum)))
                    {
                    }
                }
                {
                    /*var*/ let _Features = _target.Features;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Features"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Enum));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Features, ($v) => _Features = $v, $.$$.S.Enum)))
                    {
                    }
                }
                {
                    /*var*/ let _CalculateCost = _target.CalculateCost;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CalculateCost"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$AvdQ.LCFCP.ServiceSubscriptionTierCostCalculator));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _CalculateCost, ($v) => _CalculateCost = $v, $.$AvdQ.LCFCP.ServiceSubscriptionTierCostCalculator)))
                    {
                        _target.CalculateCost = _CalculateCost;
                    }
                }
                {
                    /*var*/ let _LimitLabel = _target.LimitLabel;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LimitLabel"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _LimitLabel, ($v) => _LimitLabel = $v, $.$$.S.String)))
                    {
                        _target.LimitLabel = _LimitLabel;
                    }
                }
                {
                    /*var*/ let _DurationLabel = _target.DurationLabel;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("DurationLabel"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _DurationLabel, ($v) => _DurationLabel = $v, $.$$.S.String)))
                    {
                        _target.DurationLabel = _DurationLabel;
                    }
                }
                {
                    /*var*/ let _UserInformation = _target.UserInformation;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UserInformation"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Type));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _UserInformation, ($v) => _UserInformation = $v, $.$$.S.Type)))
                    {
                        _target.UserInformation = _UserInformation;
                    }
                }
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _Schema = _target.Schema;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Schema"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCA$1.SchemaAttribute));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Schema, ($v) => _Schema = $v, $.$fPer.LCFCA$1.SchemaAttribute)))
                    {
                        _target.Schema = _Schema;
                    }
                }
                {
                    /*var*/ let _Tag = _target.Tag;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Tag"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Object));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Object, property, $.$ref(() => _Tag, ($v) => _Tag = $v, $.$$.S.Object)))
                    {
                        _target.Tag = _Tag;
                    }
                }
                {
                    /*var*/ let _Parent = _target.Parent;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Parent"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFCD.IParentHierachy));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Parent, ($v) => _Parent = $v, $.$fPer.LCFCD.IParentHierachy)))
                    {
                    }
                }
                {
                    /*var*/ let _Tier = _target.Tier;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Tier"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Enum));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Tier, ($v) => _Tier = $v, $.$$.S.Enum)))
                    {
                    }
                }
                {
                    /*var*/ let _Attributes = _target.Attributes;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Attributes"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Attributes, ($v) => _Attributes = $v, $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object))))
                    {
                        _target.Attributes = _Attributes;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185158080)
            
            //--TRIMMABLE-BOUNDARY-START(8595223488)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Product.ServiceTierModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595223488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$AvdQ.LCFCP.ServiceTierModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AvdQ.LCFCP.ServiceTierModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.ServiceTierModel)))
                {
                    /*var*/ let result = $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.ServiceTierModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AvdQ.LCFCP.ServiceTierModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.ServiceTierModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595223488)
            
            static $h = 5288896;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890190784),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5288896,
      "h": 12890190784,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890190784),
//--TRIMMABLE-BOUNDARY-START(17185158080),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4764608,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5288896,
      "h": 17185158080,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185158080),
//--TRIMMABLE-BOUNDARY-START(8595223488),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4764608,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5288896,
      "h": 8595223488,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595223488)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300256192),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5288896,
      "h": 4300256192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300256192)
  ],
  "h": 5288896
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5288896)
        
        

        //--TRIMMABLE-BOUNDARY-START(242624)
        $asm.$cls(`$AvdQ.LCFCP.Catalogue`, ($self) => class Catalogue extends $.$Iaui.LCFCM.EntityModel
        {
            //--TRIMMABLE-BOUNDARY-START(120259326912)
            $ctor$5(/*ICatalogueProvider*/ provider)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259326912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ProviderId = provider.LCFC$INamed$Name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(120259326912)
            
            //--TRIMMABLE-BOUNDARY-START(115964359616)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964359616);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(115964359616)
            
            //--TRIMMABLE-BOUNDARY-START(141734163392)
            /*string?*/ CatalogueName = null;
            //--TRIMMABLE-BOUNDARY-END(141734163392)
            
            //--TRIMMABLE-BOUNDARY-START(730144682944)
            /*string? */ get Title()
            {
                return this.CatalogueName ?? super.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(730144682944)
            
            //--TRIMMABLE-BOUNDARY-START(743029584832)
            /*string?*/ UrlSlug = null;
            //--TRIMMABLE-BOUNDARY-END(743029584832)
            
            //--TRIMMABLE-BOUNDARY-START(154619065280)
            /*string?*/ Description$1 = null;
            //--TRIMMABLE-BOUNDARY-END(154619065280)
            
            //--TRIMMABLE-BOUNDARY-START(442381874112)
            /*string? */ get LCFC$IDescribable$Description()
            {
                return this.Description$1;
            }
            //--TRIMMABLE-BOUNDARY-END(442381874112)
            
            //--TRIMMABLE-BOUNDARY-START(133144228800)
            /*string?*/ BannerImage = null;
            //--TRIMMABLE-BOUNDARY-END(133144228800)
            
            //--TRIMMABLE-BOUNDARY-START(481036579776)
            /*string?*/ ProviderId = null;
            //--TRIMMABLE-BOUNDARY-END(481036579776)
            
            //--TRIMMABLE-BOUNDARY-START(425202004928)
            /*string?*/ id = null;
            //--TRIMMABLE-BOUNDARY-END(425202004928)
            
            //--TRIMMABLE-BOUNDARY-START(708669846464)
            /*string */ get SKU()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712724416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                /*string*/ let __ca2__;
                /*string*/ let __ca3__;
                /*string*/ let __ca4__;
                /*string*/ let __ca5__;
                return this.id ?? $.$strNN($.$strNN(this.ProviderId) + "/") + $.$strNN(((__ca1__ = this.Title) !== null ? ((__ca2__ = $.$$.S.String.Replace$3.call(__ca1__, " ", "-")) !== null ? ((__ca3__ = $.$$.S.String.Replace$3.call(__ca2__, "/", "-")) !== null ? ((__ca4__ = $.$$.S.String.Replace$3.call(__ca3__, "\\", "-")) !== null ? ((__ca5__ = $.$$.S.String.Replace$3.call(__ca4__, "---", "-")) !== null ? $.$$.S.String.Replace$3.call(__ca5__, "--", "-") : null) : null) : null) : null) : null));
            }
            /*string */ set SKU(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627065467840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.String.IsNullOrEmpty($.$$.S.String.Trim$1.call(value, /*/*/ 47)))
                {
                    this.id = value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(708669846464)
            
            //--TRIMMABLE-BOUNDARY-START(438086906816)
            /*string */ get Link()
            {
                return this.UrlSlug ?? this.SKU;
            }
            //--TRIMMABLE-BOUNDARY-END(438086906816)
            
            //--TRIMMABLE-BOUNDARY-START(146029130688)
            /*IEnumerable<string>?*/ Categories = null;
            //--TRIMMABLE-BOUNDARY-END(146029130688)
            
            //--TRIMMABLE-BOUNDARY-START(167503967168)
            /*CatalogueFlags*/ Flags = 0;
            //--TRIMMABLE-BOUNDARY-END(167503967168)
            
            //--TRIMMABLE-BOUNDARY-START(472446645184)
            /*int*/ Order = 0;
            //--TRIMMABLE-BOUNDARY-END(472446645184)
            
            //--TRIMMABLE-BOUNDARY-START(429496972224)
            /*IEnumerable<string>?*/ Images = null;
            //--TRIMMABLE-BOUNDARY-END(429496972224)
            
            //--TRIMMABLE-BOUNDARY-START(433791939520)
            /*DateTime?*/ LaunchDate = null;
            //--TRIMMABLE-BOUNDARY-END(433791939520)
            
            //--TRIMMABLE-BOUNDARY-START(712964813760)
            /*int?*/ Sold = null;
            //--TRIMMABLE-BOUNDARY-END(712964813760)
            
            //--TRIMMABLE-BOUNDARY-START(468151677888)
            /*Money?*/ OldCost = null;
            //--TRIMMABLE-BOUNDARY-END(468151677888)
            
            //--TRIMMABLE-BOUNDARY-START(738734617536)
            /*Money*/ UnitCost;
            //--TRIMMABLE-BOUNDARY-END(738734617536)
            
            //--TRIMMABLE-BOUNDARY-START(124554294208)
            /*IEnumerable<CatalogueAccessories>?*/ Accessories = null;
            //--TRIMMABLE-BOUNDARY-END(124554294208)
            
            //--TRIMMABLE-BOUNDARY-START(163208999872)
            /*IEnumerable<CatalogueFeature>?*/ Features = null;
            //--TRIMMABLE-BOUNDARY-END(163208999872)
            
            //--TRIMMABLE-BOUNDARY-START(137439196096)
            /*IEnumerable<CatalogueBenefit>?*/ Benefits = null;
            //--TRIMMABLE-BOUNDARY-END(137439196096)
            
            //--TRIMMABLE-BOUNDARY-START(747324552128)
            /*IEnumerable<CatalogueUseCase>?*/ UseCases = null;
            //--TRIMMABLE-BOUNDARY-END(747324552128)
            
            //--TRIMMABLE-BOUNDARY-START(717259781056)
            /*IEnumerable<CatalogueSpecification>?*/ Specifications = null;
            //--TRIMMABLE-BOUNDARY-END(717259781056)
            
            //--TRIMMABLE-BOUNDARY-START(751619519424)
            /*IEnumerable<CatalogueVariant>?*/ Variants = null;
            //--TRIMMABLE-BOUNDARY-END(751619519424)
            
            //--TRIMMABLE-BOUNDARY-START(721554748352)
            /*IEnumerable<CatalogueTestimonial>?*/ Testimonials = null;
            //--TRIMMABLE-BOUNDARY-END(721554748352)
            
            //--TRIMMABLE-BOUNDARY-START(158914032576)
            /*IEnumerable<CatalogueFAQ>?*/ FAQs = null;
            //--TRIMMABLE-BOUNDARY-END(158914032576)
            
            //--TRIMMABLE-BOUNDARY-START(755914486720)
            /*IEnumerable<CatalogueVideo>?*/ Videos = null;
            //--TRIMMABLE-BOUNDARY-END(755914486720)
            
            //--TRIMMABLE-BOUNDARY-START(128849261504)
            /*IEnumerable<ActionButton>?*/ Actions = null;
            //--TRIMMABLE-BOUNDARY-END(128849261504)
            
            //--TRIMMABLE-BOUNDARY-START(463856710592)
            /*IEnumerable<ICatalogueVariantModel>? */ get LCFCP$ICatalogueModel$Variants()
            {
                return $.$$.N.InterfaceVarianceStubHandler.Create(this.Variants, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueVariant), $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueVariantModel));
            }
            //--TRIMMABLE-BOUNDARY-END(463856710592)
            
            //--TRIMMABLE-BOUNDARY-START(150324097984)
            /*IEnumerable<ICatalogueDeal>?*/ Deals = null;
            //--TRIMMABLE-BOUNDARY-END(150324097984)
            
            //--TRIMMABLE-BOUNDARY-START(476741612480)
            /*IParentHierachy?*/ Parent = null;
            //--TRIMMABLE-BOUNDARY-END(476741612480)
            
            //--TRIMMABLE-BOUNDARY-START(725849715648)
            /*Enum?*/ Tier = null;
            //--TRIMMABLE-BOUNDARY-END(725849715648)
            
            //--TRIMMABLE-BOUNDARY-START(734439650240)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(734439650240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(734439650240)
            
            //--TRIMMABLE-BOUNDARY-START(420907037632)
            /*ValueTask<IEnumerable<IChildrenHierachy>?> */ GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907037632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.FromResult($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy), $.$$.N.InterfaceVarianceStubHandler.Create(this.Variants, $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueVariant), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy)));
            }
            //--TRIMMABLE-BOUNDARY-END(420907037632)
            
            //--TRIMMABLE-BOUNDARY-START(150325801920)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.SKU.get
            get LCFCP$ICatalogueModel$SKU()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714428352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SKU;
            }
            //--TRIMMABLE-BOUNDARY-END(150325801920)
            
            //--TRIMMABLE-BOUNDARY-START(64426456000)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Categories.get
            get LCFCP$ICatalogueModel$Categories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181815744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Categories;
            }
            //--TRIMMABLE-BOUNDARY-END(64426456000)
            
            //--TRIMMABLE-BOUNDARY-START(90196259776)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Flags.get
            get LCFCP$ICatalogueModel$Flags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066717632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Flags;
            }
            //--TRIMMABLE-BOUNDARY-END(90196259776)
            
            //--TRIMMABLE-BOUNDARY-START(47246586816)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.BannerImage.get
            get LCFCP$ICatalogueModel$BannerImage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591881152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BannerImage;
            }
            //--TRIMMABLE-BOUNDARY-END(47246586816)
            
            //--TRIMMABLE-BOUNDARY-START(98786194368)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Images.get
            get LCFCP$ICatalogueModel$Images()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225147840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Images;
            }
            //--TRIMMABLE-BOUNDARY-END(98786194368)
            
            //--TRIMMABLE-BOUNDARY-START(107376128960)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.LaunchDate.get
            get LCFCP$ICatalogueModel$LaunchDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520115136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LaunchDate;
            }
            //--TRIMMABLE-BOUNDARY-END(107376128960)
            
            //--TRIMMABLE-BOUNDARY-START(176095605696)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.UnitCost.get
            get LCFCP$ICatalogueModel$UnitCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599330240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnitCost;
            }
            //--TRIMMABLE-BOUNDARY-END(176095605696)
            
            //--TRIMMABLE-BOUNDARY-START(124555998144)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.OldCost.get
            get LCFCP$ICatalogueModel$OldCost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829526464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OldCost;
            }
            //--TRIMMABLE-BOUNDARY-END(124555998144)
            
            //--TRIMMABLE-BOUNDARY-START(38656652224)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Accessories.get
            get LCFCP$ICatalogueModel$Accessories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296913856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Accessories;
            }
            //--TRIMMABLE-BOUNDARY-END(38656652224)
            
            //--TRIMMABLE-BOUNDARY-START(81606325184)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Features.get
            get LCFCP$ICatalogueModel$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771750336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(81606325184)
            
            //--TRIMMABLE-BOUNDARY-START(201865409472)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.UseCases.get
            get LCFCP$ICatalogueModel$UseCases()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356484232128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UseCases;
            }
            //--TRIMMABLE-BOUNDARY-END(201865409472)
            
            //--TRIMMABLE-BOUNDARY-START(55836521408)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Benefits.get
            get LCFCP$ICatalogueModel$Benefits()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886848448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Benefits;
            }
            //--TRIMMABLE-BOUNDARY-END(55836521408)
            
            //--TRIMMABLE-BOUNDARY-START(158915736512)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Specifications.get
            get LCFCP$ICatalogueModel$Specifications()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335009395648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Specifications;
            }
            //--TRIMMABLE-BOUNDARY-END(158915736512)
            
            //--TRIMMABLE-BOUNDARY-START(219045278656)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Videos.get
            get LCFCP$ICatalogueModel$Videos()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365074166720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Videos;
            }
            //--TRIMMABLE-BOUNDARY-END(219045278656)
            
            //--TRIMMABLE-BOUNDARY-START(73016390592)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Deals.get
            get LCFCP$ICatalogueModel$Deals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476783040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Deals;
            }
            //--TRIMMABLE-BOUNDARY-END(73016390592)
            
            //--TRIMMABLE-BOUNDARY-START(115966063552)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Link.get
            get LCFCP$ICatalogueModel$Link()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815082432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Link;
            }
            //--TRIMMABLE-BOUNDARY-END(115966063552)
            
            //--TRIMMABLE-BOUNDARY-START(167505671104)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueModel.Tags.get
            get LCFCP$ICatalogueModel$Tags()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304362944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Tags;
            }
            //--TRIMMABLE-BOUNDARY-END(167505671104)
            
            //--TRIMMABLE-BOUNDARY-START(47245379352)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Payment.IPaymentTier.Tier.get
            get LCFCP$IPaymentTier$Tier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015183128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Tier;
            }
            //--TRIMMABLE-BOUNDARY-END(47245379352)
            
            //--TRIMMABLE-BOUNDARY-START(8610810198)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IParentHierachy.Parent.get
            get LCFCD$IParentHierachy$Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12905777494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parent;
            }
            //--TRIMMABLE-BOUNDARY-END(8610810198)
            
            //--TRIMMABLE-BOUNDARY-START(4310927702)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IChildrenHierachy.GetChildren()
            LCFCD$IChildrenHierachy$GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4310927702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChildren(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4310927702)
            
            //--TRIMMABLE-BOUNDARY-START(115964359616)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(115964359616)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(472446645184)
                this.Order = 2147483647;
                //--TRIMMABLE-BOUNDARY-END(472446645184)
                
                //--TRIMMABLE-BOUNDARY-START(433791939520)
                this.LaunchDate = null;
                //--TRIMMABLE-BOUNDARY-END(433791939520)
                
                //--TRIMMABLE-BOUNDARY-START(468151677888)
                this.OldCost = null;
                //--TRIMMABLE-BOUNDARY-END(468151677888)
                
                //--TRIMMABLE-BOUNDARY-START(738734617536)
                this.UnitCost = $.$default($.$fPer.LCFCDM.Money);
                //--TRIMMABLE-BOUNDARY-END(738734617536)
                
            }
            static $h = 242624;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.EntityModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(141734163392),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453640128,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 523986252736,
        "f": 83886081
      },
      "n": "CatalogueName",
      "d": 242624,
      "h": 141734163392,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734163392),
//--TRIMMABLE-BOUNDARY-START(730144682944),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373662397376,
        "f": 50364417
      },
      "n": "Title",
      "d": 242624,
      "h": 730144682944,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(730144682944),
//--TRIMMABLE-BOUNDARY-START(743029584832),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390842266560,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 678605075392,
        "f": 83886081
      },
      "n": "UrlSlug",
      "d": 242624,
      "h": 743029584832,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(743029584832),
//--TRIMMABLE-BOUNDARY-START(154619065280),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223443904,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 541166121920,
        "f": 83886081
      },
      "n": "Description",
      "o": "@$1",
      "d": 242624,
      "h": 154619065280,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(154619065280),
//--TRIMMABLE-BOUNDARY-START(442381874112),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 450971808704,
        "f": 50331650
      },
      "n": "{46827862}.Description",
      "o": "LCFC$IDescribable$Description",
      "d": 242624,
      "h": 442381874112,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(442381874112),
//--TRIMMABLE-BOUNDARY-START(133144228800),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273770944,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 506806383552,
        "f": 83886081
      },
      "n": "BannerImage",
      "d": 242624,
      "h": 133144228800,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144228800),
//--TRIMMABLE-BOUNDARY-START(481036579776),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322122789824,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 618475533248,
        "f": 83886081
      },
      "n": "ProviderId",
      "d": 242624,
      "h": 481036579776,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(481036579776),
//--TRIMMABLE-BOUNDARY-START(708669846464),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330712724416,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 627065467840,
        "f": 83886081
      },
      "n": "SKU",
      "d": 242624,
      "h": 708669846464,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(708669846464),
//--TRIMMABLE-BOUNDARY-START(438086906816),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287763051456,
        "f": 50364417
      },
      "n": "Link",
      "d": 242624,
      "h": 438086906816,
      "f": 2129921,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(438086906816),
//--TRIMMABLE-BOUNDARY-START(146029130688),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043574720,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 532576187328,
        "f": 83886081
      },
      "n": "Categories",
      "d": 242624,
      "h": 146029130688,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029130688),
//--TRIMMABLE-BOUNDARY-START(167503967168),
    {
      "p": 832448,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993247680,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 566935925696,
        "f": 83886081
      },
      "n": "Flags",
      "d": 242624,
      "h": 167503967168,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167503967168),
//--TRIMMABLE-BOUNDARY-START(472446645184),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304942920640,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 601295664064,
        "f": 83886081
      },
      "n": "Order",
      "d": 242624,
      "h": 472446645184,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(472446645184),
//--TRIMMABLE-BOUNDARY-START(429496972224),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583182272,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 575525860288,
        "f": 83886081
      },
      "n": "Images",
      "d": 242624,
      "h": 429496972224,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(429496972224),
//--TRIMMABLE-BOUNDARY-START(433791939520),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173116864,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 584115794880,
        "f": 83886081
      },
      "n": "LaunchDate",
      "d": 242624,
      "h": 433791939520,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(433791939520),
//--TRIMMABLE-BOUNDARY-START(712964813760),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339302659008,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 635655402432,
        "f": 83886081
      },
      "n": "Sold",
      "d": 242624,
      "h": 712964813760,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(712964813760),
//--TRIMMABLE-BOUNDARY-START(468151677888),
    {
      "p": $.$typeNullable($.$fPer.LCFCDM.Money).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296352986048,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 592705729472,
        "f": 83886081
      },
      "n": "OldCost",
      "d": 242624,
      "h": 468151677888,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(468151677888),
//--TRIMMABLE-BOUNDARY-START(738734617536),
    {
      "p": 27822422,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382252331968,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 670015140800,
        "f": 83886081
      },
      "n": "UnitCost",
      "d": 242624,
      "h": 738734617536,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(738734617536),
//--TRIMMABLE-BOUNDARY-START(124554294208),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueAccessories).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093901760,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 489626514368,
        "f": 83886081
      },
      "n": "Accessories",
      "d": 242624,
      "h": 124554294208,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554294208),
//--TRIMMABLE-BOUNDARY-START(163208999872),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueFeature).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403313088,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 558345991104,
        "f": 83886081
      },
      "n": "Features",
      "d": 242624,
      "h": 163208999872,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163208999872),
//--TRIMMABLE-BOUNDARY-START(137439196096),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueBenefit).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863705536,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 515396318144,
        "f": 83886081
      },
      "n": "Benefits",
      "d": 242624,
      "h": 137439196096,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439196096),
//--TRIMMABLE-BOUNDARY-START(747324552128),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueUseCase).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399432201152,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 687195009984,
        "f": 83886081
      },
      "n": "UseCases",
      "d": 242624,
      "h": 747324552128,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(747324552128),
//--TRIMMABLE-BOUNDARY-START(717259781056),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueSpecification).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347892593600,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 644245337024,
        "f": 83886081
      },
      "n": "Specifications",
      "d": 242624,
      "h": 717259781056,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(717259781056),
//--TRIMMABLE-BOUNDARY-START(751619519424),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueVariant).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408022135744,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 695784944576,
        "f": 83886081
      },
      "n": "Variants",
      "d": 242624,
      "h": 751619519424,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(751619519424),
//--TRIMMABLE-BOUNDARY-START(721554748352),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueTestimonial).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356482528192,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 652835271616,
        "f": 83886081
      },
      "n": "Testimonials",
      "d": 242624,
      "h": 721554748352,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(721554748352),
//--TRIMMABLE-BOUNDARY-START(158914032576),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueFAQ).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813378496,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 549756056512,
        "f": 83886081
      },
      "n": "FAQs",
      "d": 242624,
      "h": 158914032576,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914032576),
//--TRIMMABLE-BOUNDARY-START(755914486720),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.CatalogueVideo).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416612070336,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 704374879168,
        "f": 83886081
      },
      "n": "Videos",
      "d": 242624,
      "h": 755914486720,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(755914486720),
//--TRIMMABLE-BOUNDARY-START(128849261504),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ActionButton).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683836352,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 498216448960,
        "f": 83886081
      },
      "n": "Actions",
      "d": 242624,
      "h": 128849261504,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849261504),
//--TRIMMABLE-BOUNDARY-START(463856710592),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueVariantModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 459561743296,
        "f": 50331650
      },
      "n": "{1946560}.Variants",
      "o": "LCFCP$ICatalogueModel$Variants",
      "d": 242624,
      "h": 463856710592,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(463856710592),
//--TRIMMABLE-BOUNDARY-START(150324097984),
    {
      "p": $.$$.SCG.IEnumerable$$($.$AvdQ.LCFCP.ICatalogueDeal).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633509312,
        "f": 50331649
      },
      "n": "Deals",
      "d": 242624,
      "h": 150324097984,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 1039,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324097984),
//--TRIMMABLE-BOUNDARY-START(476741612480),
    {
      "p": 20875606,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313532855232,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 609885598656,
        "f": 83886081
      },
      "n": "Parent",
      "d": 242624,
      "h": 476741612480,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(476741612480),
//--TRIMMABLE-BOUNDARY-START(725849715648),
    {
      "p": 1048577,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365072462784,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 661425206208,
        "f": 83886081
      },
      "n": "Tier",
      "d": 242624,
      "h": 725849715648,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(725849715648)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(734439650240),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 242624,
      "h": 734439650240,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(734439650240),
//--TRIMMABLE-BOUNDARY-START(420907037632),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCD.IChildrenHierachy)).$h,
      "n": "GetChildren",
      "d": 242624,
      "h": 420907037632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(420907037632)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(425202004928),
    {
      "t": 1310721,
      "n": "id",
      "d": 242624,
      "h": 425202004928,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(425202004928)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(120259326912),
    {
      "p": [
        {
          "n": "provider",
          "p": 2339776
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 242624,
      "h": 120259326912,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(120259326912),
//--TRIMMABLE-BOUNDARY-START(115964359616),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 242624,
      "h": 115964359616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964359616)
  ],
  "h": 242624
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.Catalogue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}Catalogue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(242624)
        
        

        //--TRIMMABLE-BOUNDARY-START(5354432)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelTypeDescriptor<,>`, (TServiceTierType, TFeatures) => $asm.$gt(`$AvdQ.LCFCP.ServiceTierModelTypeDescriptor<,>`, [TServiceTierType, TFeatures], ($self) => class ServiceTierModelTypeDescriptor$$$ extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures))
        {
            //--TRIMMABLE-BOUNDARY-START(4300321728)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300321728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$$(TServiceTierType, TFeatures).GenerateProperties($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures), this, factory);
                    }, $xRonUe ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), 0, "ServiceTierModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Product\\ServiceTierModel_LivingThing.Core.Frameworks.Common.Product.ServiceTierModel_TServiceTierType__TFeatures_TypeDescriptorBuilder.g.cs", "ServiceTierModelTypeDescriptor", 41);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300321728)
            
            //--TRIMMABLE-BOUNDARY-START(12890256320)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890256320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures).$type, $.$discardRef(), "ServiceType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From(TServiceTierType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ServiceType";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TFeatures>";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$$(TServiceTierType, TFeatures), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15(TServiceTierType, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures))).ServiceType);
                        }, $XZonOh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$$(TServiceTierType, TFeatures), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ServiceType = value.AsValue(TServiceTierType);
                        }, $qugmph ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceFeatures"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures).$type, $.$discardRef(), "ServiceFeatures", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceFeatures")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From(TFeatures, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ServiceFeatures";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TFeatures>";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$$(TServiceTierType, TFeatures), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15(TFeatures, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures))).ServiceFeatures);
                        }, $xkbuBk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$$(TServiceTierType, TFeatures), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ServiceFeatures = value.AsValue(TFeatures);
                        }, $JEoctf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures).$type, $.$discardRef(), "Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Enum, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Service";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TFeatures>";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$$(TServiceTierType, TFeatures), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Enum, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures))).Service);
                        }, $RsFsqb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Features"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures).$type, $.$discardRef(), "Features", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Features")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Enum, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Features";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TFeatures>";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$$(TServiceTierType, TFeatures), /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Enum, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures))).Features);
                        }, $NzspZj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890256320)
            
            //--TRIMMABLE-BOUNDARY-START(17185223616)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TFeatures>*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185223616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Product.ServiceTierModel?*/ let targetBase = _target;
                $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$AvdQ.LCFCP.ServiceTierModel));
                {
                    /*var*/ let _ServiceType = _target.ServiceType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$(TServiceTierType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT(TServiceTierType, () => _ServiceType, ($v) => _ServiceType = $v, null, true)))
                    {
                        _target.ServiceType = _ServiceType;
                    }
                }
                {
                    /*var*/ let _ServiceFeatures = _target.ServiceFeatures;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceFeatures"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$(TFeatures));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT(TFeatures, () => _ServiceFeatures, ($v) => _ServiceFeatures = $v, null, true)))
                    {
                        _target.ServiceFeatures = _ServiceFeatures;
                    }
                }
                {
                    /*var*/ let _Service = _target.Service;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Enum));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Service, ($v) => _Service = $v, $.$$.S.Enum)))
                    {
                    }
                }
                {
                    /*var*/ let _Features = _target.Features;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Features"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Enum));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Features, ($v) => _Features = $v, $.$$.S.Enum)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185223616)
            
            //--TRIMMABLE-BOUNDARY-START(8595289024)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType, TFeatures>?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595289024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new ($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures))().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures), null, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures))))
                {
                    /*var*/ let result = $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$$(TServiceTierType, TFeatures).VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures)));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures), null, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures)));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595289024)
            
            static $H = 5354432;
            static $h = 5354432;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890256320),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": this.$h,
      "H": 12890256320,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890256320),
//--TRIMMABLE-BOUNDARY-START(17185223616),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": this.$h,
      "H": 17185223616,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185223616),
//--TRIMMABLE-BOUNDARY-START(8595289024),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": this.$h,
      "H": 8595289024,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595289024)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300321728),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4300321728,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300321728)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    },
    {
      "h": TFeatures?.$h??1638400,
      "n": "TFeatures",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 5354432,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel$$$(TServiceTierType, TFeatures)), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelTypeDescriptor<${TServiceTierType?.$fullName},${TFeatures?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelTypeDescriptor$${TServiceTierType?.$getFullName(separator)}$${TFeatures?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(5354432)
        
        

        //--TRIMMABLE-BOUNDARY-START(5419968)
        $asm.$cls(`$AvdQ.LCFCP.ServiceTierModelTypeDescriptor<>`, (TServiceTierType) => $asm.$gt(`$AvdQ.LCFCP.ServiceTierModelTypeDescriptor<>`, [TServiceTierType], ($self) => class ServiceTierModelTypeDescriptor$$ extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType))
        {
            //--TRIMMABLE-BOUNDARY-START(4300387264)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300387264);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$(TServiceTierType).GenerateProperties($.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType), this, factory);
                    }, $WLHAge ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), 0, "ServiceTierModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Product\\ServiceTierModel_LivingThing.Core.Frameworks.Common.Product.ServiceTierModel_TServiceTierType_TypeDescriptorBuilder.g.cs", "ServiceTierModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300387264)
            
            //--TRIMMABLE-BOUNDARY-START(12890321856)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890321856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType).$type, $.$discardRef(), "ServiceType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From(TServiceTierType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ServiceType";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType>";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$(TServiceTierType), /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15(TServiceTierType, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType))).ServiceType);
                        }, $IbpRib ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$(TServiceTierType), /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ServiceType = value.AsValue(TServiceTierType);
                        }, $YyBsbe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType).$type, $.$discardRef(), "Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Enum, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Service";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType>";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$(TServiceTierType), /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Enum, ($.$cast(target, $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType))).Service);
                        }, $CMgXdf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890321856)
            
            //--TRIMMABLE-BOUNDARY-START(17185289152)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType>*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185289152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Product.ServiceTierModel?*/ let targetBase = _target;
                $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$AvdQ.LCFCP.ServiceTierModel));
                {
                    /*var*/ let _ServiceType = _target.ServiceType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$(TServiceTierType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT(TServiceTierType, () => _ServiceType, ($v) => _ServiceType = $v, null, true)))
                    {
                        _target.ServiceType = _ServiceType;
                    }
                }
                {
                    /*var*/ let _Service = _target.Service;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Enum));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Service, ($v) => _Service = $v, $.$$.S.Enum)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185289152)
            
            //--TRIMMABLE-BOUNDARY-START(8595354560)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Product.ServiceTierModel<TServiceTierType>?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595354560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new ($.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType))().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType), null, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType))))
                {
                    /*var*/ let result = $.$AvdQ.LCFCP.ServiceTierModelTypeDescriptor$$(TServiceTierType).VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType)));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType), null, $.$ref(() => _target, ($v) => _target = $v, $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType)));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595354560)
            
            static $H = 5419968;
            static $h = 5419968;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890321856),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": this.$h,
      "H": 12890321856,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890321856),
//--TRIMMABLE-BOUNDARY-START(17185289152),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": this.$h,
      "H": 17185289152,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185289152),
//--TRIMMABLE-BOUNDARY-START(8595354560),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": $.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType).$h,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": this.$h,
      "H": 8595354560,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595354560)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300387264),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4300387264,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300387264)
  ],
  "s": [
    {
      "h": TServiceTierType?.$h??1572864,
      "n": "TServiceTierType",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 1,
  "H": 5419968,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$AvdQ.LCFCP.ServiceTierModel$$(TServiceTierType)), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceTierModelTypeDescriptor<${TServiceTierType?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceTierModelTypeDescriptor$${TServiceTierType?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(5419968)
        
        

        //--TRIMMABLE-BOUNDARY-START(1160128)
        $asm.$cls(`$AvdQ.LCFCP.CatalogueVariant`, ($self) => class CatalogueVariant extends $.$AvdQ.LCFCP.Catalogue
        {
            //--TRIMMABLE-BOUNDARY-START(12886062016)
            /*IEnumerable<string>?*/ AccessoriesId = null;
            //--TRIMMABLE-BOUNDARY-END(12886062016)
            
            //--TRIMMABLE-BOUNDARY-START(12887569344)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.ICatalogueVariantModel.AccessoriesId.get
            get LCFCP$ICatalogueVariantModel$AccessoriesId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297634752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AccessoriesId;
            }
            //--TRIMMABLE-BOUNDARY-END(12887569344)
            
            //--TRIMMABLE-BOUNDARY-START(8591094720)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591094720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591094720)
            
            //--TRIMMABLE-BOUNDARY-START(8591094720)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(8591094720)
            
            static $h = 1160128;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$AvdQ.LCFCP.Catalogue; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886062016),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475996608,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065931200,
        "f": 83886081
      },
      "n": "AccessoriesId",
      "d": 1160128,
      "h": 12886062016,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886062016)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591094720),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1160128,
      "h": 8591094720,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591094720)
  ],
  "h": 1160128
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$AvdQ.LCFCP.ICatalogueVariantModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.CatalogueVariant`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}CatalogueVariant`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1160128)
        
        

        //--TRIMMABLE-BOUNDARY-START(4371392)
        $asm.$cls(`$AvdQ.LCFCP.ProductCatalogue`, ($self) => class ProductCatalogue extends $.$AvdQ.LCFCP.Catalogue
        {
            //--TRIMMABLE-BOUNDARY-START(4299338688)
            $ctor$6()
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299338688);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299338688)
            
            //--TRIMMABLE-BOUNDARY-START(8594305984)
            $ctor$7(/*ICatalogueProvider*/ provider)
            {
                super.$ctor$5(provider);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594305984);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594305984)
            
            //--TRIMMABLE-BOUNDARY-START(4299338688)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4299338688)
            
            static $h = 4371392;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$AvdQ.LCFCP.Catalogue; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299338688),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 4371392,
      "h": 4299338688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299338688),
//--TRIMMABLE-BOUNDARY-START(8594305984),
    {
      "p": [
        {
          "n": "provider",
          "p": 2339776
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 4371392,
      "h": 8594305984,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594305984)
  ],
  "h": 4371392
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$AvdQ.LCFCP.IProductCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ProductCatalogue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ProductCatalogue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4371392)
        
        

        //--TRIMMABLE-BOUNDARY-START(4436928)
        $asm.$cls(`$AvdQ.LCFCP.ServiceCatalogue`, ($self) => class ServiceCatalogue extends $.$AvdQ.LCFCP.ProductCatalogue
        {
            //--TRIMMABLE-BOUNDARY-START(8594371520)
            $ctor$8()
            {
                super.$ctor$6();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8594371520);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594371520)
            
            //--TRIMMABLE-BOUNDARY-START(12889338816)
            $ctor$9(/*ICatalogueProvider*/ provider)
            {
                super.$ctor$7(provider);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889338816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889338816)
            
            //--TRIMMABLE-BOUNDARY-START(25774240704)
            /*ServiceType*/ ServiceType = 0;
            //--TRIMMABLE-BOUNDARY-END(25774240704)
            
            //--TRIMMABLE-BOUNDARY-START(8594174912)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Product.IServiceCatalogueModel.ServiceType.get
            get LCFCP$IServiceCatalogueModel$ServiceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889142208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceType;
            }
            //--TRIMMABLE-BOUNDARY-END(8594174912)
            
            //--TRIMMABLE-BOUNDARY-START(8594371520)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(8594371520)
            
            static $h = 4436928;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$AvdQ.LCFCP.ProductCatalogue; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25774240704),
    {
      "p": 5682112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479273408,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34364175296,
        "f": 83886081
      },
      "n": "ServiceType",
      "d": 4436928,
      "h": 25774240704,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25774240704)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594371520),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 4436928,
      "h": 8594371520,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594371520),
//--TRIMMABLE-BOUNDARY-START(12889338816),
    {
      "p": [
        {
          "n": "provider",
          "p": 2339776
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 4436928,
      "h": 12889338816,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889338816)
  ],
  "h": 4436928
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$AvdQ.LCFCP.IProductCatalogueModel, $.$AvdQ.LCFCP.IServiceCatalogueModel, $.$AvdQ.LCFCP.ICatalogueModel, $.$nYKj.LCFCP.IPaymentTier, $.$fPer.LCFCD.IParentHierachy, $.$fPer.LCFCD.IChildrenHierachy, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Product.ServiceCatalogue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Product${separator}ServiceCatalogue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4436928)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Payment"));
})();
//--TRIMMABLE-BOUNDARY-END(46016)
