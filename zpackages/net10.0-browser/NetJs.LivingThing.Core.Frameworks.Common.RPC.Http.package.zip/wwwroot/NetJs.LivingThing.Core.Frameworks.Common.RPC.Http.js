
//--TRIMMABLE-BOUNDARY-START(62405)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $uvJL) {
    "use strict";
    let _;
    let $nTrxNa;
    let $sNMzZf;
    let $BAfDAh;
    let $RpGLPa;
    let $nTtDQk;
    let $VNQrRh;
    let $TqyoEi;
    let $NIZkQj;
    let $pcfYPf;
    let $uSTYSh;
    let $demybf;
    let $jVKyWb;
    let $tEkEce;
    let $JYulcg;
    let $JzIQWi;
    let $XJUFkb;
    let $zIrODh;
    let $sneDee;
    let $HZErgj;
    let $Mkvvmb;
    let $dLxTYh;
    let $nsqipc;
    let $WmpDve;
    let $uvRDqk;
    let $tYjFcb;
    let $eztpEj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.RPC.Http", 
    {
  "h": 62405,
  "f": "LivingThing.Core.Frameworks.Common.RPC.Http",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.RPC.Http",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.RPC.Http",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(127941)
        $asm.$cls(`$IDVm.LCFCRH.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590062533)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590062533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$IDVm.LCFCRH.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || options.Runtime === 3/*RuntimeType.WasmWeb*/ || options.Runtime === 4/*RuntimeType.WasmMobileApp*/ || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$uvJL.LCFCR.IClientServerRemoteService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$uvJL.LCFCR.IServerRemoteService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$IDVm.LCFCR.HttpRemoteProxyServerRemoteService, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$uvJL.LCFCR.IServerRemoteService))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IDVm.LCFCR.HttpRemoteProxyServerRemoteService, x);
                    }, $nTrxNa ??= {"r":1309651,"p":[{"n":"x","p":327718}],"n":"","d":127941,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$uvJL.LCFCR.IClientServerRemoteService))().$ctor(this,  (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IDVm.LCFCR.HttpRemoteProxyServerRemoteService, x);
                    }, $sNMzZf ??= {"r":719827,"p":[{"n":"x","p":327718}],"n":"","d":127941,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590062533)
            
            //--TRIMMABLE-BOUNDARY-START(12885029829)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885029829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_HttpRemoteProxyServerRemoteService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$IDVm.LCFCR.HttpRemoteProxyServerRemoteService().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$snh.SNH.HttpClient, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$snh.SNH.HttpClient, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFC.IApplicationContextProvider, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFC.IApplicationContextProvider, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFCS$3.ServiceFactory, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFCS$3.ServiceFactory, provider));
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || options.Runtime === 3/*RuntimeType.WasmWeb*/ || options.Runtime === 4/*RuntimeType.WasmMobileApp*/ || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$IDVm.LCFCR.HttpRemoteProxyServerRemoteService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$IDVm.LCFCRH.ServiceRegistrar, Get_HttpRemoteProxyServerRemoteService, $BAfDAh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_HttpRemoteProxyServerRemoteService","d":127941,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IServerRemoteService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IDVm.LCFCR.HttpRemoteProxyServerRemoteService, x);
                    }), $RpGLPa ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":127941,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || options.Runtime === 3/*RuntimeType.WasmWeb*/ || options.Runtime === 4/*RuntimeType.WasmMobileApp*/ || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$uvJL.LCFCR.IServerRemoteService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$IDVm.LCFCRH.ServiceRegistrar, Get_IServerRemoteService, $nTtDQk ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IServerRemoteService","d":127941,"h":0,"f":16777250})));
                }
                /*static object*/  function Get_IClientServerRemoteService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$IDVm.LCFCR.HttpRemoteProxyServerRemoteService, x);
                    }), $VNQrRh ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":127941,"h":0,"f":17825794})).Invoke(provider);
                }
                if (options.Runtime === 2/*RuntimeType.MobileApp*/ || options.Runtime === 3/*RuntimeType.WasmWeb*/ || options.Runtime === 4/*RuntimeType.WasmMobileApp*/ || options.Runtime === 6/*RuntimeType.DesktopApp*/)
                {
                    $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$uvJL.LCFCR.IClientServerRemoteService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$IDVm.LCFCRH.ServiceRegistrar, Get_IClientServerRemoteService, $TqyoEi ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IClientServerRemoteService","d":127941,"h":0,"f":16777250})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885029829)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$IDVm.LCFCRH.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295095237)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295095237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295095237)
            
            //--TRIMMABLE-BOUNDARY-START(4295095237)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295095237)
            
            static $h = 127941;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590062533),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 127941,
      "h": 8590062533,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590062533),
//--TRIMMABLE-BOUNDARY-START(12885029829),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 127941,
      "h": 12885029829,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885029829)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295095237),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 127941,
      "h": 4295095237,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295095237)
  ],
  "h": 127941
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.Http.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}Http${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(127941)
        
        

        //--TRIMMABLE-BOUNDARY-START(193477)
        $asm.$cls(`$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService`, ($self) => class HttpBatchRemoteProxyServerRemoteService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(259013)
            static $_RemoteProxyMethodInfoTask;
            static get RemoteProxyMethodInfoTask()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(259013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService;
                return $cls.$_RemoteProxyMethodInfoTask ??= $asm.$nstr(`$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask`, ($self) => class RemoteProxyMethodInfoTask extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(47244899269)
                    /*RemoteProxyMethodInfo*/ Info;
                    //--TRIMMABLE-BOUNDARY-END(47244899269)
                    
                    //--TRIMMABLE-BOUNDARY-START(81604637637)
                    /*TaskCompletionSource<object?>*/ Task = null;
                    //--TRIMMABLE-BOUNDARY-END(81604637637)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539866565)
                    /*Type*/ ReturnType = null;
                    //--TRIMMABLE-BOUNDARY-END(51539866565)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180128197)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180128197);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180128197)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180128197)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180128197)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Info = this.Info.$clone();
                        copy.Task = this.Task;
                        copy.ReturnType = this.ReturnType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(47244899269)
                        this.Info = $.$default($.$uvJL.LCFCR.RemoteProxyMethodInfo);
                        //--TRIMMABLE-BOUNDARY-END(47244899269)
                        
                    }
                    static $h = 259013;
                    static $z = 24;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47244899269),
    {
      "p": 1768403,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770062789,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129801157,
        "f": 83886081
      },
      "n": "Info",
      "d": 259013,
      "h": 47244899269,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244899269),
//--TRIMMABLE-BOUNDARY-START(81604637637),
    {
      "p": $.$$.STT.TaskCompletionSource$$($.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949931973,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309670341,
        "f": 83886081
      },
      "n": "Task",
      "d": 259013,
      "h": 81604637637,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604637637),
//--TRIMMABLE-BOUNDARY-START(51539866565),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359997381,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719735749,
        "f": 83886081
      },
      "n": "ReturnType",
      "d": 259013,
      "h": 51539866565,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539866565)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180128197),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 259013,
      "h": 17180128197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180128197)
  ],
  "d": 193477,
  "h": 259013
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.HttpBatchRemoteProxyServerRemoteService+RemoteProxyMethodInfoTask`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}HttpBatchRemoteProxyServerRemoteService${separator}RemoteProxyMethodInfoTask`; }
                }, $cls, ($v) => $cls.$_RemoteProxyMethodInfoTask = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(259013)
            
            //--TRIMMABLE-BOUNDARY-START(8590128069)
            /*HttpRemoteProxyServerRemoteService*/ _server = null;
            //--TRIMMABLE-BOUNDARY-END(8590128069)
            
            //--TRIMMABLE-BOUNDARY-START(4295160773)
            /*List<RemoteProxyMethodInfoTask>?[]*/ _batchEntries = null;
            //--TRIMMABLE-BOUNDARY-END(4295160773)
            
            //--TRIMMABLE-BOUNDARY-START(12885095365)
            /*IEnumerable<Stream>?*/ _streams = null;
            //--TRIMMABLE-BOUNDARY-END(12885095365)
            
            //--TRIMMABLE-BOUNDARY-START(21475029957)
            /*int*/ _waitInvokeCount = 0;
            //--TRIMMABLE-BOUNDARY-END(21475029957)
            
            //--TRIMMABLE-BOUNDARY-START(17180062661)
            /*TaskCompletionSource*/ _waitInvoke = null;
            //--TRIMMABLE-BOUNDARY-END(17180062661)
            
            //--TRIMMABLE-BOUNDARY-START(25769997253)
            $ctor$1(/*HttpRemoteProxyServerRemoteService*/ server, /*int*/ count)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769997253);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._server = server;
                    this._waitInvokeCount = count;
                    this._batchEntries = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.List$$($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask)), null, [count], null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769997253)
            
            //--TRIMMABLE-BOUNDARY-START(30064964549)
            /*void */ AddServiceRequestHeader(/*string*/ key, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064964549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._server.AddServiceRequestHeader(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30064964549)
            
            //--TRIMMABLE-BOUNDARY-START(38654899141)
            /*IServiceProxy<TService> */ GetRemoteService(TService, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654899141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let mocked = $.$zHIt.LCFCM.Mock.Interface$2(TService, this, true);
                /*var*/ let service = $.$cast($.$box(mocked, TService), $.$uvJL.LCFCR.RemoteProxyServiceBase);
                service.Options = options;
                return new ($.$fPer.LCFCS$3.DisposableService$$(TService))().$ctor$3(mocked);
            }
            //--TRIMMABLE-BOUNDARY-END(38654899141)
            
            //--TRIMMABLE-BOUNDARY-START(55834768325)
            /*void */ NOP(/*int*/ batchIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834768325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._waitInvokeCount--;
                if (this._waitInvokeCount === 0)
                {
                    this._waitInvoke.SetResult();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834768325)
            
            //--TRIMMABLE-BOUNDARY-START(51539801029)
            /*Task<TResponse> *//*async*/  InvokeRemoteMethod(TService, TResponse, /*string*/ methodName, /*RemoteProxyExecutionContext?*/ options, /*IEnumerable<RemoteProxyMethodParameter>?*/ serviceParameters, /*params RemoteProxyMethodParameter[]*/ parameters)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TResponse), TResponse, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539801029);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._waitInvokeCount === 0)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("Batch completed or already executed.");
                    }
                    if ((options?.InBatchIndex ?? null) === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("Batch Index required");
                    }
                    /*string?*/ let signature = `${$.$strNN(TService.$type.FullName)}.${$.$strNN(methodName)}`;
                    /*var*/ let info = (() =>
                    {
                        //new $.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask()
                        const $t1 = $.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Info = (() =>
                        {
                            //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                            const $t2 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                            const $i2 = new $t2();
                            $i2.$ctor$2();
                            $i2.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(TService.$type, methodName, parameters, $.$ref(() => signature, ($v) => signature = $v, $.$$.S.String), options.HashServiceName ?? true);
                            $i2.Parameters = $.$sl.SL.Enumerable.Select$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$sl.SL.Enumerable.Where($.$uvJL.LCFCR.RemoteProxyMethodParameter, parameters, new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                            {
                                return !(p.Parameter !== null && ($.$is(p.Parameter, $.$$.SI.Stream)));
                            }, $NIZkQj ??= {"r":262145,"p":[{"n":"p","p":2030547}],"n":"","d":193477,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$uvJL.LCFCR.RemoteProxyMethodParameter))().$ctor(this,  (/*c*/ c) =>
                            {
                                return new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(c.ParameterType, c.Parameter);
                            }, $pcfYPf ??= {"r":2030547,"p":[{"n":"c","p":2030547}],"n":"","d":193477,"h":0,"f":17825794}));
                            return $i2;
                        })();
                        $i1.Task = new ($.$$.STT.TaskCompletionSource$$($.$$.S.Object))().$ctor$1();
                        $i1.ReturnType = TResponse.$type;
                        return $i1;
                    })();
                    /*var*/ let streams = $.$sl.SL.Enumerable.Select$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.SI.Stream, $.$sl.SL.Enumerable.Where($.$uvJL.LCFCR.RemoteProxyMethodParameter, parameters, new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                    {
                        return $.$is(p.Parameter, $.$$.SI.Stream);
                    }, $uSTYSh ??= {"r":262145,"p":[{"n":"p","p":2030547}],"n":"","d":193477,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.SI.Stream))().$ctor(this,  (/*p*/ p) =>
                    {
                        return $.$cast(p.Parameter, $.$$.SI.Stream);
                    }, $demybf ??= {"r":95748097,"p":[{"n":"p","p":2030547}],"n":"","d":193477,"h":0,"f":17825794}));
                    if (!$.$sl.SL.Enumerable.Any$1($.$$.SI.Stream, streams))
                    {
                        streams = $.$sl.SL.Enumerable.Select$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.SI.Stream, $.$sl.SL.Enumerable.Where($.$uvJL.LCFCR.RemoteProxyMethodParameter, parameters, new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                        {
                            return $.$is(p.Parameter, $.$uvJL.LCFCR.IRemoteStream);
                        }, $jVKyWb ??= {"r":262145,"p":[{"n":"p","p":2030547}],"n":"","d":193477,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.SI.Stream))().$ctor(this,  (/*p*/ p) =>
                        {
                            return ($.$cast(p.Parameter, $.$uvJL.LCFCR.IRemoteStream)).LCFCR$IRemoteStream$Stream;
                        }, $tEkEce ??= {"r":95748097,"p":[{"n":"p","p":2030547}],"n":"","d":193477,"h":0,"f":17825794}));
                    }
                    if ($.$sl.SL.Enumerable.Any$1($.$$.SI.Stream, streams))
                    {
                        if (this._streams !== null)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12("Only one of the batched methods can use a stream method parameter interface");
                        }
                        this._streams = streams;
                    }
                    if ($.$$.System.Array.$ReadT1.call(this._batchEntries, $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(options.InBatchIndex)) === null)
                    {
                        this._waitInvokeCount--;
                        $.$$.System.Array.$WriteT1.call(this._batchEntries, new ($.$$.SCG.List$$($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask))().$ctor$1(), $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(options.InBatchIndex));
                    }
                    $.$$.System.Array.$ReadT1.call(this._batchEntries, $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(options.InBatchIndex)).Add($.$clone(info));
                    if (this._waitInvokeCount === 0)
                    {
                        this._waitInvoke.TrySetResult();
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$cast(((($t4 = info.Task.Task, ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4))))), TResponse));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51539801029)
            
            //--TRIMMABLE-BOUNDARY-START(42949866437)
            /*TResult */ Invoke(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949866437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(42949866437)
            
            //--TRIMMABLE-BOUNDARY-START(47244833733)
            /*Task<TResult> */ InvokeAsync(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244833733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeRemoteMethod(TInterface, TResult, context.MethodName, ($.$cast(context.Mock, $.$uvJL.LCFCR.RemoteProxyServiceBase)).Options, null, $.$sl.SL.Enumerable.ToArray($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$sl.SL.Enumerable.Select$1($.$zHIt.LCFCM.MockMethodParameter, $.$uvJL.LCFCR.RemoteProxyMethodParameter, parameters, new ($.$$.S.Func$$$($.$zHIt.LCFCM.MockMethodParameter, $.$uvJL.LCFCR.RemoteProxyMethodParameter))().$ctor(this,  (/*p*/ p) =>
                {
                    return $.$uvJL.LCFCR.RemoteProxyMethodParameter.From($.$clone(p));
                }, $JYulcg ??= {"r":2030547,"p":[{"n":"p","p":1044294}],"n":"","d":193477,"h":0,"f":17825794}))));
            }
            //--TRIMMABLE-BOUNDARY-END(47244833733)
            
            //--TRIMMABLE-BOUNDARY-START(34359931845)
            /*Task *//*async*/  Commit(/*IRemoteServiceOptions?*/ options)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359931845);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t5 = this._waitInvoke.Task, ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    /*var*/ let results = $.$firstOf(($t6 = this._server.Post($.$$.S.Object, $.$$.SCG.IEnumerable$$($.$$.S.Object), $.$sl.SL.Enumerable.Select$1($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask, $.$uvJL.LCFCR.RemoteProxyMethodInfo, $.$sl.SL.Enumerable.Where($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask, $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.List$$($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask), $.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask, this._batchEntries, new ($.$$.S.Func$$$($.$$.SCG.List$$($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask), $.$$.SCG.IEnumerable$$($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask)))().$ctor(this,  (/**/ b) =>
                    {
                        return b ?? $.$sl.SL.Enumerable.Empty($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask);
                    }, $JzIQWi ??= {"r":$.$$.SCG.IEnumerable$$($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask).$h,"p":[{"n":"b","p":$.$$.SCG.List$$($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask).$h}],"n":"","d":193477,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask, $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                    {
                        return m.ReturnType !== null;
                    }, $XJUFkb ??= {"r":262145,"p":[{"n":"m","p":259013}],"n":"","d":193477,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask, $.$uvJL.LCFCR.RemoteProxyMethodInfo))().$ctor(this,  (/*m*/ m) =>
                    {
                        return m.Info;
                    }, $zIrODh ??= {"r":1768403,"p":[{"n":"m","p":259013}],"n":"","d":193477,"h":0,"f":17825794})), this._streams, options), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6))), () => { throw new $.$$.S.NullReferenceException().$ctor$12("Result is null") });
                    /*int*/ let batchIndex = 0;
                    let $i7 = 0;
                    let $arr7 = this._batchEntries;
                    while ($i7 < $arr7.length)
                    {
                        let entries = $arr7[$i7++];
                        if (entries !== null)
                        {
                            let $en8 = entries.GetEnumerator();
                            while ($en8.MoveNext())
                            {
                                let entry = $en8.Current;
                                {
                                    /*var*/ let result = $.$sl.SL.Enumerable.ElementAt$1($.$$.S.Object, results, batchIndex);
                                    if (entry.ReturnType === null)
                                    {
                                        continue;
                                    }
                                    else if (entry.ReturnType === $.$$.S.Object.$type)
                                    {
                                        entry.Task.SetResult(null);
                                    }
                                    else 
                                    {
                                        /*object?*/ let typedResult = null;
                                        let element;
                                        let node;
                                        let tdoc;
                                        if ($.$is(result, $.$stj.STJ.JsonElement, { set $v($v){ element = $v; } }))
                                        {
                                            typedResult = $.$stj.STJ.JsonSerializer.Deserialize$19(element, entry.ReturnType, (() =>
                                            {
                                                //new $.$stj.STJ.JsonSerializerOptions()
                                                const $t9 = $.$stj.STJ.JsonSerializerOptions;
                                                const $i9 = new $t9();
                                                $i9.$ctor$1();
                                                $i9.PropertyNameCaseInsensitive = true;
                                                $i9.IgnoreReadOnlyFields = true;
                                                $i9.IgnoreReadOnlyProperties = true;
                                                $i9.ReferenceHandler = $.$stj.STJS$1.ReferenceHandler.Preserve;
                                                return $i9;
                                            })());
                                        }
                                        else if ($.$is(result, $.$stj.STJN.JsonNode, { set $v($v){ node = $v; } }))
                                        {
                                            typedResult = $.$stj.STJ.JsonSerializer.Deserialize$22(node, entry.ReturnType, (() =>
                                            {
                                                //new $.$stj.STJ.JsonSerializerOptions()
                                                const $t10 = $.$stj.STJ.JsonSerializerOptions;
                                                const $i10 = new $t10();
                                                $i10.$ctor$1();
                                                $i10.PropertyNameCaseInsensitive = true;
                                                $i10.IgnoreReadOnlyFields = true;
                                                $i10.IgnoreReadOnlyProperties = true;
                                                $i10.ReferenceHandler = $.$stj.STJS$1.ReferenceHandler.Preserve;
                                                return $i10;
                                            })());
                                        }
                                        else if ($.$is(result, $.$fPer.LCFCST.TypeDescriptorJsonSerializerJsonDocument, { set $v($v){ tdoc = $v; } }))
                                        {
                                            typedResult = tdoc.Deserialize(entry.ReturnType);
                                        }
                                        else 
                                        {
                                            typedResult = result;
                                        }
                                        let wt;
                                        if ($.$is(typedResult, $.$fPer.LCFCD.IWireTransportModel, { set $v($v){ wt = $v; } }) && !wt.LCFCD$IWireTransportModel$Success && wt.LCFCD$IWireTransportModel$Message !== null)
                                        {
                                            /*var*/ let exceptionModel = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, wt.LCFCD$IWireTransportModel$Message, false, "Commit", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC.Http\\HttpBatchRemoteProxyServerRemoteService.cs", "Commit", 198);
                                            /*var*/ let exception = exceptionModel.ToException();
                                            entry.Task.SetException$1(exception);
                                        }
                                        else 
                                        {
                                            entry.Task.SetResult(typedResult);
                                        }
                                    }
                                    batchIndex++;
                                }
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34359931845)
            
            //--TRIMMABLE-BOUNDARY-START(8590588883)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IBatchClientServerRemoteService.NOP(int)
            LCFCR$IBatchClientServerRemoteService$NOP()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590588883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NOP(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590588883)
            
            //--TRIMMABLE-BOUNDARY-START(4295621587)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IBatchClientServerRemoteService.Commit(LivingThing.Core.Frameworks.Common.RPC.IRemoteServiceOptions?)
            LCFCR$IBatchClientServerRemoteService$Commit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295621587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Commit(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295621587)
            
            //--TRIMMABLE-BOUNDARY-START(4296276947)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IServerRemoteService.AddServiceRequestHeader(string, string?)
            LCFCR$IServerRemoteService$AddServiceRequestHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296276947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddServiceRequestHeader(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296276947)
            
            //--TRIMMABLE-BOUNDARY-START(8591244243)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IServerRemoteService.GetRemoteService<TService>(LivingThing.Core.Frameworks.Common.RPC.RemoteProxyExecutionContext?)
            LCFCR$IServerRemoteService$GetRemoteService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591244243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetRemoteService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591244243)
            
            //--TRIMMABLE-BOUNDARY-START(4295159622)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mocking.IMockImplement.Invoke<TInterface, TResult>(LivingThing.Core.Frameworks.Common.Mocking.MockMethodContext, params LivingThing.Core.Frameworks.Common.Mocking.MockMethodParameter[])
            LCFCM$IMockImplement$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295159622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295159622)
            
            //--TRIMMABLE-BOUNDARY-START(8590126918)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mocking.IMockImplement.InvokeAsync<TInterface, TResult>(LivingThing.Core.Frameworks.Common.Mocking.MockMethodContext, params LivingThing.Core.Frameworks.Common.Mocking.MockMethodParameter[])
            LCFCM$IMockImplement$InvokeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590126918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590126918)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180062661)
                this._waitInvoke = new $.$$.STT.TaskCompletionSource().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17180062661)
                
            }
            static $h = 193477;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064964549),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddServiceRequestHeader",
      "d": 193477,
      "h": 30064964549,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064964549),
//--TRIMMABLE-BOUNDARY-START(38654899141),
    {
      "r": (TService) => $.$fPer.LCFCS$3.IServiceProxy$$(TService).$h,
      "p": [
        {
          "n": "options",
          "p": 1702867
        }
      ],
      "g": [
        "TService"
      ],
      "n": "GetRemoteService",
      "d": 193477,
      "h": 38654899141,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(38654899141),
//--TRIMMABLE-BOUNDARY-START(55834768325),
    {
      "r": 65537,
      "p": [
        {
          "n": "batchIndex",
          "p": 655361
        }
      ],
      "n": "NOP",
      "d": 193477,
      "h": 55834768325,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834768325),
//--TRIMMABLE-BOUNDARY-START(51539801029),
    {
      "r": (TService, TResponse) => $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 1702867
        },
        {
          "n": "serviceParameters",
          "p": $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter).$h
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$uvJL.LCFCR.RemoteProxyMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TService",
        "TResponse"
      ],
      "n": "InvokeRemoteMethod",
      "d": 193477,
      "h": 51539801029,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(51539801029),
//--TRIMMABLE-BOUNDARY-START(42949866437),
    {
      "r": (TInterface, TResult) => TResult.$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "Invoke",
      "d": 193477,
      "h": 42949866437,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(42949866437),
//--TRIMMABLE-BOUNDARY-START(47244833733),
    {
      "r": (TInterface, TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "InvokeAsync",
      "d": 193477,
      "h": 47244833733,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(47244833733),
//--TRIMMABLE-BOUNDARY-START(34359931845),
    {
      "r": 178454529,
      "p": [
        {
          "n": "options",
          "p": 1113043
        }
      ],
      "n": "Commit",
      "d": 193477,
      "h": 34359931845,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34359931845)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590128069),
    {
      "t": 324549,
      "n": "_server",
      "d": 193477,
      "h": 8590128069,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590128069),
//--TRIMMABLE-BOUNDARY-START(4295160773),
    {
      "t": $.$typeArray($.$$.SCG.List$$($.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask)).$h,
      "n": "_batchEntries",
      "d": 193477,
      "h": 4295160773,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295160773),
//--TRIMMABLE-BOUNDARY-START(12885095365),
    {
      "t": $.$$.SCG.IEnumerable$$($.$$.SI.Stream).$h,
      "n": "_streams",
      "d": 193477,
      "h": 12885095365,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885095365),
//--TRIMMABLE-BOUNDARY-START(21475029957),
    {
      "t": 655361,
      "n": "_waitInvokeCount",
      "d": 193477,
      "h": 21475029957,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475029957),
//--TRIMMABLE-BOUNDARY-START(17180062661),
    {
      "t": 179568641,
      "n": "_waitInvoke",
      "d": 193477,
      "h": 17180062661,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180062661)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25769997253),
    {
      "p": [
        {
          "n": "server",
          "p": 324549
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 193477,
      "h": 25769997253,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769997253)
  ],
  "h": 193477
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IBatchClientServerRemoteService, $.$uvJL.LCFCR.IServerRemoteService, $.$zHIt.LCFCM.IMockImplement ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService.RemoteProxyMethodInfoTask ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.HttpBatchRemoteProxyServerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}HttpBatchRemoteProxyServerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(193477)
        
        

        //--TRIMMABLE-BOUNDARY-START(324549)
        $asm.$cls(`$IDVm.LCFCR.HttpRemoteProxyServerRemoteService`, ($self) => class HttpRemoteProxyServerRemoteService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360062917)
            /*ServiceFactory*/ Factory = null;
            //--TRIMMABLE-BOUNDARY-END(34360062917)
            
            //--TRIMMABLE-BOUNDARY-START(25770128325)
            /*IAuthenticationService */ get AuthenticationService()
            {
                return $.$fPer.LCFCS$3.ServiceFactoryExtensions.GetRequired$1($.$GfYa.LCFCA.IAuthenticationService, this.Factory);
            }
            //--TRIMMABLE-BOUNDARY-END(25770128325)
            
            //--TRIMMABLE-BOUNDARY-START(30065095621)
            /*IApplicationContextProvider*/ ContextProvider = null;
            //--TRIMMABLE-BOUNDARY-END(30065095621)
            
            //--TRIMMABLE-BOUNDARY-START(17180193733)
            $ctor$1(/*HttpClient*/ http, /*IApplicationContextProvider*/ contextProvider, /*ServiceFactory*/ factory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180193733);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Http = http;
                    this.ContextProvider = contextProvider;
                    this.Factory = factory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180193733)
            
            //--TRIMMABLE-BOUNDARY-START(73014768581)
            /*HttpClient*/ Http = null;
            //--TRIMMABLE-BOUNDARY-END(73014768581)
            
            //--TRIMMABLE-BOUNDARY-START(4295291845)
            /*Dictionary<string, string?>*/ _requestHeader = null;
            //--TRIMMABLE-BOUNDARY-END(4295291845)
            
            //--TRIMMABLE-BOUNDARY-START(94489605061)
            /*IServerRemoteServiceOfflineCache?*/ OfflineCache = null;
            //--TRIMMABLE-BOUNDARY-END(94489605061)
            
            //--TRIMMABLE-BOUNDARY-START(68719801285)
            /*Task *//*async*/  HandleException(/*HttpResponseMessage*/ response)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719801285);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (response.StatusCode === 500/*HttpStatusCode.InternalServerError*/)
                    {
                        let $t1, $r1;
                        /*var*/ let data = ($t1 = response.Content.ReadAsStringAsync().ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        $.$$.SD.Debug.WriteLine$4(data);
                        /*Exception?*/ let exception = null;
                        try
                        {
                            /*var*/ let exceptionModel = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, data, false, "HandleException", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC.Http\\HttpRemoteProxyServerRemoteService.cs", "HandleException", 65);
                            exception = exceptionModel.ToException();
                        }
                        catch($e)
                        {
                        }
                        if (exception !== null)
                        {
                            throw exception;
                        }
                    }
                    throw new $.$$.S.Exception().$ctor$4(response.ReasonPhrase);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68719801285)
            
            //--TRIMMABLE-BOUNDARY-START(103079539653)
            /*Task<TResponse?> *//*async*/  Post$1(TService, TResponse, /*string*/ url, /*IEnumerable<RemoteProxyMethodInfo>*/ infos, /*IEnumerable<Stream>?*/ streams, /*IRemoteServiceOptions?*/ options)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TResponse), TResponse, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079539653);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let offlineCacheKey = this.OfflineCache !== null ? `${$.$strNN(url)}/${$.$strNN(TResponse.$type.FullName)}/${$.$strNN($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodInfo), infos, true, false, true, false, false, false, false, "Post", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC.Http\\HttpRemoteProxyServerRemoteService.cs", "Post", 85).Json)}` : "";
                    /*int*/ let retry = (options?.LCFCR$IRemoteServiceOptions$Retries ?? null) ?? 3;
                    do
                    {
                        try
                        {
                            /*var*/ let client = this.Http;
                            let request = null;
                            try
                            {
                                request = new $.$snh.SNH.HttpRequestMessage().$ctor$2($.$snh.SNH.HttpMethod.Post, url);
                                /*var*/ let host = this.ContextProvider.LCFC$IApplicationContextProvider$RemoteHost;
                                if (host !== null && !$.$$.S.String.StartsWith$3.call(host, "http"))
                                {
                                    host = "https://" + $.$strNN(host);
                                }
                                request.Headers.Add$3("Origin", host);
                                let $en2 = this._requestHeader.GetEnumerator();
                                while ($en2.MoveNext())
                                {
                                    let kv = $en2.Current;
                                    {
                                        if (!((options?.LCFCR$IRemoteServiceOptions$RequestHeader?.SCG$IDictionary$$$$ContainsKey(kv.Key) ?? null) ?? false))
                                        {
                                            request.Headers.TryAddWithoutValidation$3(kv.Key, kv.Value);
                                        }
                                    }
                                }
                                if ((options?.LCFCR$IRemoteServiceOptions$RequestHeader ?? null) !== null)
                                {
                                    let $en3 = options.LCFCR$IRemoteServiceOptions$RequestHeader.SCG$IEnumerable$$$GetEnumerator();
                                    while ($en3.SC$1$IEnumerator$MoveNext())
                                    {
                                        let kv = $en3.SCG$IEnumerator$$$Current;
                                        {
                                            if (kv.Value !== null)
                                            {
                                                request.Headers.TryAddWithoutValidation$3(kv.Key, kv.Value);
                                            }
                                            else 
                                            {
                                                request.Headers.Remove$1(kv.Key);
                                            }
                                        }
                                    }
                                }
                                if ((options?.LCFCR$IRemoteServiceOptions$Authenticate ?? null) ?? true)
                                {
                                    let $t4, $r4;
                                    /*var*/ let auth = ($t4 = this.AuthenticationService.LCFCA$IReadOnlyAuthenticationService$GetAuthenticationToken(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                    if (auth !== null)
                                    {
                                        request.Headers.TryAddWithoutValidation$3("Authorization", auth);
                                    }
                                }
                                if ((options?.LCFCR$IRemoteServiceOptions$Batching ?? null) ?? false)
                                {
                                    request.Headers.TryAddWithoutValidation$3("X-RequestBatch", "Yes");
                                }
                                /*int*/ let id = $.$$.S.Random.Shared.Next$2(256);
                                /*Stopwatch*/ let watch = new $.$$.SD.Stopwatch().$ctor$1();
                                /*var*/ let postParameter = $.$fPer.LCFC.ArrayCompare.Count(infos) === 1 ? $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$uvJL.LCFCR.RemoteProxyMethodInfo, $.$sl.SL.Enumerable.Single$1($.$uvJL.LCFCR.RemoteProxyMethodInfo, infos), true, false, true, false, false, false, false, "Post", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC.Http\\HttpRemoteProxyServerRemoteService.cs", "Post", 145).Json : $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodInfo), infos, true, false, true, false, false, false, false, "Post", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC.Http\\HttpRemoteProxyServerRemoteService.cs", "Post", 145).Json;
                                if (streams === null || !$.$sl.SL.Enumerable.Any$1($.$$.SI.Stream, streams))
                                {
                                    request.Content = new $.$snh.SNH.StringContent().$ctor$8(postParameter);
                                    /*CancellationTokenSource*/ let src = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                                    src.CancelAfter((options?.LCFCR$IRemoteServiceOptions$TimeOut ?? null) ?? 30000);
                                    $.$$.SD.Debug.WriteLine$4(`REQUEST(${$.$strNN(id)}) => ${$.$strNN(postParameter)}`);
                                    watch.Start();
                                    let response = null;
                                    try
                                    {
                                        let $t5, $r5;
                                        let $t8, $r8;
                                        response = ($t5 = client.SendAsync(request, src.Token).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                        if (response.IsSuccessStatusCode)
                                        {
                                            let data = null;
                                            try
                                            {
                                                let $t6, $r6;
                                                data = response.Content.ReadAsStream();
                                                watch.Stop();
                                                $.$$.SD.Debug.WriteLine$4(`RESPONSE(${$.$strNN(id)}, ${$.$strNN(watch.ElapsedMilliseconds)}ms) => ${$.$strNN($.$dspc(data, $.$$.S.Object, ($t) => $t.ToString))}`);
                                                if (TResponse.$type === $.$$.S.Object.$type)
                                                {
                                                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$default(TResponse));
                                                }
                                                /*var*/ let result = ($t6 = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerializeAsync(TResponse, data, false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                                if (this.OfflineCache !== null)
                                                {
                                                    let $t7, $r7;
                                                    ($t7 = this.OfflineCache.LCFCR$IServerRemoteServiceOfflineCache$SetItem(TService, TResponse, offlineCacheKey, result, $.$$.S.TimeSpan.MaxValue), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                                }
                                                return $.$$.N.AsyncResolver.Result($asnycContext, result);
                                            }
                                            finally
                                            {
                                                data?.S$IDisposable$Dispose();
                                            }
                                        }
                                        ($t8 = this.HandleException(response).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                    }
                                    finally
                                    {
                                        response?.S$IDisposable$Dispose();
                                    }
                                }
                                else 
                                {
                                    if ($.$fPer.LCFC.ArrayCompare.Count(streams) === 1)
                                    {
                                        request.Headers.Add$3("X-Data", postParameter);
                                        request.Content = new $.$snh.SNH.StreamContent().$ctor$3($.$sl.SL.Enumerable.Single$1($.$$.SI.Stream, streams));
                                    }
                                    else 
                                    {
                                        /*var*/ let contentLengths = `${$.$strNN(postParameter.length)},${$.$strNN($.$$.S.String.Join$12($.$$.S.Int64, ",", $.$sl.SL.Enumerable.Select$1($.$$.SI.Stream, $.$$.S.Int64, streams, new ($.$$.S.Func$$$($.$$.SI.Stream, $.$$.S.Int64))().$ctor(this,  (/*s*/ s) =>
                                        {
                                            return s.Length;
                                        }, $sneDee ??= {"r":917505,"p":[{"n":"s","p":95748097}],"n":"","d":324549,"h":0,"f":17825794}))))}`;
                                        request.Headers.Add$3("Content-Lengths", contentLengths);
                                        /*var*/ let stream = new $.$fPer.LCFCD.StreamCombiner().$ctor$3($.$sl.SL.Enumerable.Concat($.$$.SI.Stream, $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SI.MemoryStream), [new $.$$.SI.MemoryStream().$ctor$8($.$$.ST.Encoding.UTF8.GetBytes$8(postParameter))], null, null), $.$$.SCG.IEnumerable$$($.$$.SI.MemoryStream), $.$$.SCG.IEnumerable$$($.$$.SI.Stream)), streams));
                                        request.Content = new $.$snh.SNH.StreamContent().$ctor$3(stream);
                                    }
                                    let response = null;
                                    try
                                    {
                                        let $t9, $r9;
                                        let $t12, $r12;
                                        response = ($t9 = client.SendAsync$3(request).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                                        if (response.IsSuccessStatusCode)
                                        {
                                            let $t10, $r10;
                                            if (TResponse.$type === $.$$.S.Object.$type)
                                            {
                                                return $.$$.N.AsyncResolver.Result($asnycContext, $.$default(TResponse));
                                            }
                                            /*var*/ let data = response.Content.ReadAsStream();
                                            /*var*/ let result = ($t10 = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerializeAsync(TResponse, data, false), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                                            if (this.OfflineCache !== null)
                                            {
                                                let $t11, $r11;
                                                ($t11 = this.OfflineCache.LCFCR$IServerRemoteServiceOfflineCache$SetItem(TService, TResponse, offlineCacheKey, result, $.$$.S.TimeSpan.MaxValue), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                                            }
                                            return $.$$.N.AsyncResolver.Result($asnycContext, result);
                                        }
                                        ($t12 = this.HandleException(response).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                                    }
                                    finally
                                    {
                                        response?.S$IDisposable$Dispose();
                                    }
                                }
                            }
                            finally
                            {
                                request?.S$IDisposable$Dispose();
                            }
                        }
                        catch($e)
                        {
                            if ($e instanceof $.$snh.SNH.HttpRequestException)
                            {
                                if (retry > 0)
                                {
                                    retry--;
                                    continue;
                                }
                                if (this.OfflineCache !== null)
                                {
                                    let $t13, $r13;
                                    /*var*/ let offlineCached = ($t13 = this.OfflineCache.LCFCR$IServerRemoteServiceOfflineCache$GetItem(TService, TResponse, offlineCacheKey), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                                    if (offlineCached !== null)
                                    {
                                        return $.$$.N.AsyncResolver.Result($asnycContext, offlineCached);
                                    }
                                }
                                throw $e;
                            }
                            else if ($e instanceof $.$uvJL.LCFCR.RemoteProxyServiceMethodException)
                            {
                                let rse = $e;
                                throw new $.$uvJL.LCFCR.RemoteProxyServiceMethodException().$ctor$6("Server Error! Please retry.", rse);
                            }
                            else if ($e instanceof $.$$.S.Exception)
                            {
                                let he = $e;
                                throw new $.$$.S.Exception().$ctor$3("Network Error! Please retry.", he);
                            }
                            else
                            {
                                throw $e;
                            }
                        }
                        break;
                    }
                    while(true);
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$default(TResponse));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103079539653)
            
            //--TRIMMABLE-BOUNDARY-START(98784572357)
            /*Task<TResponse?> */ Post(TService, TResponse, /*IEnumerable<RemoteProxyMethodInfo>*/ infos, /*IEnumerable<Stream>?*/ streams, /*IRemoteServiceOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784572357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let host = this.ContextProvider.LCFC$IApplicationContextProvider$RemoteHost;
                if (!$.$$.S.String.StartsWith$3.call(host, "http://") && !$.$$.S.String.StartsWith$3.call(host, "https://"))
                {
                    host = $.$strNN(`${$.$strNN((this.ContextProvider.LCFC$IApplicationContextProvider$LocalUri?.Scheme ?? null) ?? "https")}://`) + $.$strNN(host);
                }
                return this.Post$1(TService, TResponse, `${$.$strNN(host)}/${$.$strNN("_"/*HttpExtension.HttpRemoteProcedurePath*/)}`, infos, streams, options);
            }
            //--TRIMMABLE-BOUNDARY-END(98784572357)
            
            //--TRIMMABLE-BOUNDARY-START(85899670469)
            /*Task<TResponse> *//*async*/  InvokeRemoteMethod(TService, TResponse, /*string*/ methodName, /*RemoteProxyExecutionContext?*/ options, /*IEnumerable<RemoteProxyMethodParameter>?*/ serviceParameters, /*params RemoteProxyMethodParameter[]*/ parameters)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TResponse), TResponse, async ($asnycContext) => 
                {
                    let $t16, $r16;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899670469);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*string?*/ let signature = `${$.$strNN(TService.$type.FullName)}.${$.$strNN(methodName)}`;
                    /*var*/ let info = (() =>
                    {
                        //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                        const $t14 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                        const $i14 = new $t14();
                        $i14.$ctor$2();
                        $i14.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(TService.$type, methodName, parameters, $.$ref(() => signature, ($v) => signature = $v, $.$$.S.String), (options?.HashServiceName ?? null) ?? true);
                        $i14.ServiceParameters = serviceParameters;
                        $i14.Parameters = $.$sl.SL.Enumerable.Select$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$sl.SL.Enumerable.Where($.$uvJL.LCFCR.RemoteProxyMethodParameter, parameters, new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                        {
                            return !(p.Parameter !== null && ($.$is(p.Parameter, $.$$.SI.Stream)));
                        }, $HZErgj ??= {"r":262145,"p":[{"n":"p","p":2030547}],"n":"","d":324549,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$uvJL.LCFCR.RemoteProxyMethodParameter))().$ctor(this,  (/*c*/ c) =>
                        {
                            return new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(c.ParameterType, c.Parameter);
                        }, $Mkvvmb ??= {"r":2030547,"p":[{"n":"c","p":2030547}],"n":"","d":324549,"h":0,"f":17825794}));
                        return $i14;
                    })();
                    $.$$.SD.Debug.WriteLine$4(`\"${$.$strNN(info.Service)}\" => ${$.$strNN(signature)}`);
                    /*IEnumerable<Stream>?*/ let streams = $.$sl.SL.Enumerable.Select$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.SI.Stream, $.$sl.SL.Enumerable.Where($.$uvJL.LCFCR.RemoteProxyMethodParameter, parameters, new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                    {
                        return $.$is(p.Parameter, $.$$.SI.Stream);
                    }, $dLxTYh ??= {"r":262145,"p":[{"n":"p","p":2030547}],"n":"","d":324549,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.SI.Stream))().$ctor(this,  (/*p*/ p) =>
                    {
                        return $.$cast(p.Parameter, $.$$.SI.Stream);
                    }, $nsqipc ??= {"r":95748097,"p":[{"n":"p","p":2030547}],"n":"","d":324549,"h":0,"f":17825794}));
                    if (streams === null)
                    {
                        streams = $.$sl.SL.Enumerable.Where($.$$.SI.Stream, $.$sl.SL.Enumerable.Select$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.SI.Stream, $.$sl.SL.Enumerable.Where($.$uvJL.LCFCR.RemoteProxyMethodParameter, parameters, new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                        {
                            return $.$is(p.Parameter, $.$uvJL.LCFCR.IRemoteStream);
                        }, $WmpDve ??= {"r":262145,"p":[{"n":"p","p":2030547}],"n":"","d":324549,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.SI.Stream))().$ctor(this,  (/*p*/ p) =>
                        {
                            return (($.$cast(p.Parameter, $.$uvJL.LCFCR.IRemoteStream))?.LCFCR$IRemoteStream$Stream ?? null);
                        }, $uvRDqk ??= {"r":95748097,"p":[{"n":"p","p":2030547}],"n":"","d":324549,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SI.Stream, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s !== null;
                        }, $tYjFcb ??= {"r":262145,"p":[{"n":"s","p":95748097}],"n":"","d":324549,"h":0,"f":17825794}));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, (($t16 = this.Post(TService, TResponse, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uvJL.LCFCR.RemoteProxyMethodInfo), [info], null, null), streams, options), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899670469)
            
            //--TRIMMABLE-BOUNDARY-START(77309735877)
            /*TResult */ Invoke(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309735877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(77309735877)
            
            //--TRIMMABLE-BOUNDARY-START(81604703173)
            /*Task<TResult> */ InvokeAsync(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604703173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeRemoteMethod(TInterface, TResult, context.MethodName, ($.$cast(context.Mock, $.$uvJL.LCFCR.RemoteProxyServiceBase)).Options, null, $.$sl.SL.Enumerable.ToArray($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$sl.SL.Enumerable.Select$1($.$zHIt.LCFCM.MockMethodParameter, $.$uvJL.LCFCR.RemoteProxyMethodParameter, parameters, new ($.$$.S.Func$$$($.$zHIt.LCFCM.MockMethodParameter, $.$uvJL.LCFCR.RemoteProxyMethodParameter))().$ctor(this,  (/*p*/ p) =>
                {
                    return $.$uvJL.LCFCR.RemoteProxyMethodParameter.From($.$clone(p));
                }, $eztpEj ??= {"r":2030547,"p":[{"n":"p","p":1044294}],"n":"","d":324549,"h":0,"f":17825794}))));
            }
            //--TRIMMABLE-BOUNDARY-END(81604703173)
            
            //--TRIMMABLE-BOUNDARY-START(64424833989)
            /*IServiceProxy<TService> */ GetRemoteService(TService, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424833989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let mocked = $.$zHIt.LCFCM.Mock.Interface$2(TService, this, true);
                /*var*/ let service = $.$cast($.$box(mocked, TService), $.$uvJL.LCFCR.RemoteProxyServiceBase);
                service.Options = options;
                return new ($.$fPer.LCFCS$3.DisposableService$$(TService))().$ctor$3(mocked);
            }
            //--TRIMMABLE-BOUNDARY-END(64424833989)
            
            //--TRIMMABLE-BOUNDARY-START(21475161029)
            /*void */ AddServiceRequestHeader(/*string*/ key, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475161029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._requestHeader.set_Item(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475161029)
            
            //--TRIMMABLE-BOUNDARY-START(90194637765)
            /*IBatchClientServerRemoteService */ LCFCR$IClientServerRemoteService$GetBatchService(/*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194637765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$IDVm.LCFCR.HttpBatchRemoteProxyServerRemoteService().$ctor$1(this, count);
            }
            //--TRIMMABLE-BOUNDARY-END(90194637765)
            
            //--TRIMMABLE-BOUNDARY-START(4296276947)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IServerRemoteService.AddServiceRequestHeader(string, string?)
            LCFCR$IServerRemoteService$AddServiceRequestHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296276947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddServiceRequestHeader(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296276947)
            
            //--TRIMMABLE-BOUNDARY-START(8591244243)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IServerRemoteService.GetRemoteService<TService>(LivingThing.Core.Frameworks.Common.RPC.RemoteProxyExecutionContext?)
            LCFCR$IServerRemoteService$GetRemoteService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591244243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetRemoteService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591244243)
            
            //--TRIMMABLE-BOUNDARY-START(12885818323)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IOfflineCachableServerRemoteService.OfflineCache.set
            set LCFCR$IOfflineCachableServerRemoteService$OfflineCache(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295883731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OfflineCache = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885818323)
            
            //--TRIMMABLE-BOUNDARY-START(4295159622)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mocking.IMockImplement.Invoke<TInterface, TResult>(LivingThing.Core.Frameworks.Common.Mocking.MockMethodContext, params LivingThing.Core.Frameworks.Common.Mocking.MockMethodParameter[])
            LCFCM$IMockImplement$Invoke()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295159622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Invoke(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295159622)
            
            //--TRIMMABLE-BOUNDARY-START(8590126918)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Mocking.IMockImplement.InvokeAsync<TInterface, TResult>(LivingThing.Core.Frameworks.Common.Mocking.MockMethodContext, params LivingThing.Core.Frameworks.Common.Mocking.MockMethodParameter[])
            LCFCM$IMockImplement$InvokeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590126918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590126918)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295291845)
                this._requestHeader = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295291845)
                
            }
            static $h = 324549;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360062917),
    {
      "p": 62949718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539932101,
        "f": 50331652
      },
      "n": "Factory",
      "d": 324549,
      "h": 34360062917,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(34360062917),
//--TRIMMABLE-BOUNDARY-START(25770128325),
    {
      "p": 1655170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949997509,
        "f": 50331650
      },
      "n": "AuthenticationService",
      "d": 324549,
      "h": 25770128325,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25770128325),
//--TRIMMABLE-BOUNDARY-START(94489605061),
    {
      "p": 1375187,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129866693,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669474245,
        "f": 83886081
      },
      "n": "OfflineCache",
      "d": 324549,
      "h": 94489605061,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489605061)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719801285),
    {
      "r": 178454529,
      "p": [
        {
          "n": "response",
          "p": 7864373
        }
      ],
      "n": "HandleException",
      "d": 324549,
      "h": 68719801285,
      "f": 16781316
    },
//--TRIMMABLE-BOUNDARY-END(68719801285),
//--TRIMMABLE-BOUNDARY-START(103079539653),
    {
      "r": (TService, TResponse) => $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "url",
          "p": 1310721
        },
        {
          "n": "infos",
          "p": $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodInfo).$h
        },
        {
          "n": "streams",
          "p": $.$$.SCG.IEnumerable$$($.$$.SI.Stream).$h
        },
        {
          "n": "options",
          "p": 1113043,
          "f": 65
        }
      ],
      "g": [
        "TService",
        "TResponse"
      ],
      "n": "Post",
      "o": "@$1",
      "d": 324549,
      "h": 103079539653,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(103079539653),
//--TRIMMABLE-BOUNDARY-START(98784572357),
    {
      "r": (TService, TResponse) => $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "infos",
          "p": $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodInfo).$h
        },
        {
          "n": "streams",
          "p": $.$$.SCG.IEnumerable$$($.$$.SI.Stream).$h
        },
        {
          "n": "options",
          "p": 1113043,
          "f": 65
        }
      ],
      "g": [
        "TService",
        "TResponse"
      ],
      "n": "Post",
      "d": 324549,
      "h": 98784572357,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(98784572357),
//--TRIMMABLE-BOUNDARY-START(85899670469),
    {
      "r": (TService, TResponse) => $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 1702867
        },
        {
          "n": "serviceParameters",
          "p": $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter).$h
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$uvJL.LCFCR.RemoteProxyMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TService",
        "TResponse"
      ],
      "n": "InvokeRemoteMethod",
      "d": 324549,
      "h": 85899670469,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(85899670469),
//--TRIMMABLE-BOUNDARY-START(77309735877),
    {
      "r": (TInterface, TResult) => TResult.$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "Invoke",
      "d": 324549,
      "h": 77309735877,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(77309735877),
//--TRIMMABLE-BOUNDARY-START(81604703173),
    {
      "r": (TInterface, TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "InvokeAsync",
      "d": 324549,
      "h": 81604703173,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(81604703173),
//--TRIMMABLE-BOUNDARY-START(64424833989),
    {
      "r": (TService) => $.$fPer.LCFCS$3.IServiceProxy$$(TService).$h,
      "p": [
        {
          "n": "options",
          "p": 1702867
        }
      ],
      "g": [
        "TService"
      ],
      "n": "GetRemoteService",
      "d": 324549,
      "h": 64424833989,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(64424833989),
//--TRIMMABLE-BOUNDARY-START(21475161029),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddServiceRequestHeader",
      "d": 324549,
      "h": 21475161029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475161029)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065095621),
    {
      "t": 46041430,
      "n": "ContextProvider",
      "d": 324549,
      "h": 30065095621,
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(30065095621),
//--TRIMMABLE-BOUNDARY-START(73014768581),
    {
      "t": 6488117,
      "n": "Http",
      "d": 324549,
      "h": 73014768581,
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(73014768581),
//--TRIMMABLE-BOUNDARY-START(4295291845),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "_requestHeader",
      "d": 324549,
      "h": 4295291845,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295291845)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180193733),
    {
      "p": [
        {
          "n": "http",
          "p": 6488117
        },
        {
          "n": "contextProvider",
          "p": 46041430
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 324549,
      "h": 17180193733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180193733)
  ],
  "h": 324549
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IClientServerRemoteService, $.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.IOfflineCachableServerRemoteService, $.$zHIt.LCFCM.IMockImplement ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.HttpRemoteProxyServerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}HttpRemoteProxyServerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(324549)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC"));
})();
//--TRIMMABLE-BOUNDARY-END(62405)
