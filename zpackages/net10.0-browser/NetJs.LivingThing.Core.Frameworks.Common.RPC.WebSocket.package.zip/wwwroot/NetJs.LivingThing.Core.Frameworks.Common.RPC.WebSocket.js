
//--TRIMMABLE-BOUNDARY-START(10350)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt, $kVHt, $uvJL) {
    "use strict";
    let _;
    let $ZSlmcj;
    let $kcUmji;
    let $RbNwVh;
    let $YyNHnl;
    let $tkIRWe;
    let $GlGJzf;
    let $KnZMLk;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.RPC.WebSocket", 
    {
  "h": 10350,
  "f": "LivingThing.Core.Frameworks.Common.RPC.WebSocket",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.RPC.WebSocket",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.RPC.WebSocket",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(75886)
        $asm.$cls(`$XvXV.LCFCRW.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12884977774)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884977774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12884977774)
            
            //--TRIMMABLE-BOUNDARY-START(8590010478)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590010478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XvXV.LCFCRW.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$1(services, $.$kVHt.LCFCH.IHubConnector$$$().$type, $.$XvXV.LCFCRW.WebSocketHubConnector$$$().$type);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$1(services, $.$kVHt.LCFCH.IHubConnector$$().$type, $.$XvXV.LCFCRW.WebSocketHubConnector$$().$type);
            }
            //--TRIMMABLE-BOUNDARY-END(8590010478)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XvXV.LCFCRW.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295043182)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295043182);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295043182)
            
            //--TRIMMABLE-BOUNDARY-START(4295043182)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295043182)
            
            static $h = 75886;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12884977774),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 75886,
      "h": 12884977774,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12884977774),
//--TRIMMABLE-BOUNDARY-START(8590010478),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 75886,
      "h": 8590010478,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590010478)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295043182),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 75886,
      "h": 4295043182,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295043182)
  ],
  "h": 75886
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.WebSocket.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}WebSocket${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(75886)
        
        

        //--TRIMMABLE-BOUNDARY-START(141422)
        $asm.$cls(`$XvXV.LCFCRW.WebSocketHubConnector<,>`, (THubClient, THubServer) => $asm.$gt(`$XvXV.LCFCRW.WebSocketHubConnector<,>`, [THubClient, THubServer], ($self) => class WebSocketHubConnector$$$ extends $.$kVHt.LCFCH.BaseClientHubConnector$$$$(THubClient, THubServer, $.$snwc.SNW.ClientWebSocket)
        {
            //--TRIMMABLE-BOUNDARY-START(21474977902)
            /*CancellationTokenSource*/ disposalTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(21474977902)
            
            //--TRIMMABLE-BOUNDARY-START(4295108718)
            $ctor$2(/*IApplicationContextProvider*/ appContext)
            {
                super.$ctor$1(appContext);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295108718);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295108718)
            
            //--TRIMMABLE-BOUNDARY-START(12885043310)
            /*void */ CloseConnection(/*ClientWebSocket*/ connection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885043310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.disposalTokenSource.Cancel();
                if (connection.State === 2/*WebSocketState.Open*/)
                {
                    _ = connection.CloseAsync(1000/*WebSocketCloseStatus.NormalClosure*/, "Bye", $.$$.ST$1.CancellationToken.None);
                }
                connection.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(12885043310)
            
            //--TRIMMABLE-BOUNDARY-START(17180010606)
            /*ClientWebSocket */ CreateConnection(/*ClientWebSocket?*/ currentConnection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180010606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let webSocket = new $.$snwc.SNW.ClientWebSocket().$ctor$2();
                return webSocket;
            }
            //--TRIMMABLE-BOUNDARY-END(17180010606)
            
            //--TRIMMABLE-BOUNDARY-START(38654847086)
            /*bool */ IsConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654847086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this.connection?.State ?? null) === 2/*WebSocketState.Open*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38654847086)
            
            //--TRIMMABLE-BOUNDARY-START(25769945198)
            /*Task */ EnsureConnected(/*int*/ timeOutMs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769945198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this.connection?.State ?? null) === 6/*WebSocketState.Aborted*/)
                {
                    this.connection = null;
                }
                return super.EnsureConnected(timeOutMs);
            }
            //--TRIMMABLE-BOUNDARY-END(25769945198)
            
            //--TRIMMABLE-BOUNDARY-START(42949814382)
            /*ConcurrentDictionary<MethodInfo, Func<object?[], Task>>*/ methodRegistrations = null;
            //--TRIMMABLE-BOUNDARY-END(42949814382)
            
            //--TRIMMABLE-BOUNDARY-START(51539748974)
            /*IDisposable */ OnClientMethod(/*ClientWebSocket*/ connection, /*MethodInfo*/ clientMethod, /*Func<object?[], Task>*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539748974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(clientMethod.DeclaringType.IsInterface, "clientMethod.DeclaringType!.IsInterface");
                this.methodRegistrations.set_Item$1(clientMethod, handler);
                return new $.$fPer.LCFC.DisposableDelegate().$ctor$3(new $.$$.S.Action().$ctor(this,  () =>
                {
                    return $.$$.SCG.CollectionExtensions.Remove($.$$.SR.MethodInfo, $.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$$.STT.Task), this.methodRegistrations, clientMethod, $.$discardRef());
                }, $ZSlmcj ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(51539748974)
            
            //--TRIMMABLE-BOUNDARY-START(8590076014)
            /*ConcurrentDictionary<int, TaskCompletionSource<ArraySegment<byte>>>?*/ awaitingResponses = null;
            //--TRIMMABLE-BOUNDARY-END(8590076014)
            
            //--TRIMMABLE-BOUNDARY-START(55834716270)
            /*Task *//*async*/  ReceiveLoop(/*ClientWebSocket*/ connection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834716270);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let array = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [262144/*WebSocketHubUtility.MessageBufferSize*/], null);
                    while(!this.disposalTokenSource.IsCancellationRequested)
                    {
                        let $t1, $r1;
                        /*var*/ let received = ($t1 = connection.ReceiveAsync(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$3(array, 0, array.length), this.disposalTokenSource.Token), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        /*int*/ let receivedLen = received.Count;
                        while(!received.EndOfMessage)
                        {
                            let $t2, $r2;
                            received = ($t2 = connection.ReceiveAsync(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$3(array, receivedLen, ((array.length - receivedLen) | 0)), this.disposalTokenSource.Token), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            receivedLen += received.Count;
                        }
                        /*var*/ let buffer = new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$3(array, 0, receivedLen);
                        if ($.$$.S.Nullable$$($.$snws.SNW.WebSocketCloseStatus).HasValue$get.call(connection.CloseStatus))
                        {
                            this.NotifyDisconnected();
                            _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                            {
                                return this.StartConnect(null);
                            }, $kcUmji ??= {"r":178454529,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                            return $.$$.N.AsyncResolver.Result($asnycContext,);
                        }
                        if (buffer.get_Item(0) === 0/*WebSocketHubUtility.RequestPrefix*/)
                        {
                            /*var*/ let receivedAsText = $.$$.ST.Encoding.UTF8.GetString(buffer.Array, ((buffer.Offset + 1) | 0), ((buffer.Count - 1) | 0));
                            /*var*/ let methodInfo = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$uvJL.LCFCR.RemoteProxyMethodInfo, receivedAsText, false, "ReceiveLoop", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC.WebSocket\\WebSocketHubConnector.cs", "ReceiveLoop", 115);
                            if (methodInfo.Service !== null && methodInfo.Parameters !== null)
                            {
                                /*var*/ let methodRegistration = $.$sl.SL.Enumerable.SingleOrDefault$1($.$$.SCG.KeyValuePair$$$($.$$.SR.MethodInfo, $.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$$.STT.Task)), this.methodRegistrations, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.SR.MethodInfo, $.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$$.STT.Task)), $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                                {
                                    /*var*/ let signature;
                                    return $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId(m.Key.DeclaringType, m.Key, $.$ref(() => signature, ($v) => signature = $v, $.$$.S.String), true) === methodInfo.Service;
                                }, $RbNwVh ??= {"r":262145,"p":[{"n":"m","p":$.$$.SCG.KeyValuePair$$$($.$$.SR.MethodInfo, $.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$$.STT.Task)).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                if ($.$$.SR.MethodInfo.op_Inequality$2(methodRegistration.Key, null) && $.$$.SR.MethodInfo.op_Inequality$2(methodRegistration.Key, null))
                                {
                                    let $t4, $r4;
                                    /*var*/ let parameterTypes = methodRegistration.Key.GetParameters();
                                    ($t4 = methodRegistration.Value.Invoke($.$sl.SL.Enumerable.ToArray($.$$.S.Object, $.$sl.SL.Enumerable.Select($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.Object, methodInfo.Parameters, new ($.$$.S.Func$$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.Int32, $.$$.S.Object))().$ctor(this,  (/*p*/ p, /*i*/ i) =>
                                    {
                                        let jel;
                                        let tjel;
                                        if ($.$is(p.Parameter, $.$stj.STJ.JsonElement, { set $v($v){ jel = $v; } }))
                                        {
                                            return $.$stj.STJ.JsonSerializer.Deserialize$19(jel, $.$$.System.Array.$ReadT1.call(parameterTypes, i).ParameterType, $.$fPer.LCFCS$1.JsonSerializeExtension.Options);
                                        }
                                        else if ($.$is(p.Parameter, $.$fPer.LCFCST.TypeDescriptorJsonSerializerJsonDocument, { set $v($v){ tjel = $v; } }))
                                        {
                                            return tjel.Deserialize($.$$.System.Array.$ReadT1.call(parameterTypes, i).ParameterType);
                                        }
                                        return $.$fPer.LCFCD.DataConverter.Convert(p.Parameter, $.$$.System.Array.$ReadT1.call(parameterTypes, i).ParameterType);
                                    }, $YyNHnl ??= {"r":131073,"p":[{"n":"p","p":2030547},{"n":"i","p":655361}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})))), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                }
                            }
                        }
                        else if (buffer.get_Item(0) === 1/*WebSocketHubUtility.ResponsePrefix*/)
                        {
                            if (this.awaitingResponses !== null)
                            {
                                /*var*/ let awaitingResponse;
                                /*int*/ let requestId = buffer.get_Item(1) | (buffer.get_Item(2) << 16) >>> 0;
                                if ($.$$.SCG.CollectionExtensions.Remove($.$$.S.Int32, $.$$.STT.TaskCompletionSource$$($.$$.S.ArraySegment$$($.$$.S.Byte)), this.awaitingResponses, requestId, $.$ref(() => awaitingResponse, ($v) => awaitingResponse = $v, $.$$.STT.TaskCompletionSource$$($.$$.S.ArraySegment$$($.$$.S.Byte)))))
                                {
                                    awaitingResponse.TrySetResult(new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$3(buffer.Array, ((((buffer.Offset + 1) | 0) + 2) | 0), ((buffer.Count - (((1 + 2) | 0))) | 0)));
                                }
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55834716270)
            
            //--TRIMMABLE-BOUNDARY-START(47244781678)
            /*int*/ nextRequestId = 0;
            //--TRIMMABLE-BOUNDARY-END(47244781678)
            
            //--TRIMMABLE-BOUNDARY-START(60129683566)
            /*Task<T> *//*async*/  SendAndReceive(T, /*Func<int, Task>*/ send)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(T), T, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129683566);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let invocationId = ++this.nextRequestId;
                    /*var*/ let awaitingResponse = new ($.$$.STT.TaskCompletionSource$$($.$$.S.ArraySegment$$($.$$.S.Byte)))().$ctor$1();
                    this.awaitingResponses ??= new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$$.STT.TaskCompletionSource$$($.$$.S.ArraySegment$$($.$$.S.Byte))))().$ctor$1();
                    this.awaitingResponses.set_Item$1(invocationId, awaitingResponse);
                    ($t6 = send.Invoke(invocationId), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    if (T.$type !== $.$$.S.Object.$type)
                    {
                        let $t7, $r7;
                        /*CancellationTokenSource*/ let cancel = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                        cancel.CancelAfter(15000);
                        cancel.Token.Register$1(new $.$$.S.Action().$ctor(this,  () =>
                        {
                            $.$$.SCG.CollectionExtensions.Remove($.$$.S.Int32, $.$$.STT.TaskCompletionSource$$($.$$.S.ArraySegment$$($.$$.S.Byte)), this.awaitingResponses, invocationId, $.$discardRef());
                            awaitingResponse.TrySetCanceled();
                        }, $tkIRWe ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                        /*var*/ let buffer = ($t7 = awaitingResponse.Task, ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                        /*var*/ let receivedAsText = $.$$.ST.Encoding.UTF8.GetString(buffer.Array, buffer.Offset, buffer.Count);
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3(T, receivedAsText, false, "SendAndReceive", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC.WebSocket\\WebSocketHubConnector.cs", "SendAndReceive", 171));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$default(T));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60129683566)
            
            //--TRIMMABLE-BOUNDARY-START(34359879790)
            /*Task */ InvokeServerMethodFromClientInternal(/*int*/ invocationId, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359879790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(context.DeclaringType.IsInterface, "context.DeclaringType.IsInterface");
                if (this.connection === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Connection not established");
                }
                /*var*/ let ps = $.$sl.SL.Enumerable.ToList($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$sl.SL.Enumerable.Select$1($.$zHIt.LCFCM.MockMethodParameter, $.$uvJL.LCFCR.RemoteProxyMethodParameter, parameters, new ($.$$.S.Func$$$($.$zHIt.LCFCM.MockMethodParameter, $.$uvJL.LCFCR.RemoteProxyMethodParameter))().$ctor(this,  (/*p*/ p) =>
                {
                    return $.$uvJL.LCFCR.RemoteProxyMethodParameter.From($.$clone(p));
                }, $GlGJzf ??= {"r":2030547,"p":[{"n":"p","p":1044294}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                /*var*/ let methodInfo = (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                    const $t8 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(context.DeclaringType, context.MethodName, ps, $.$discardRef(), true);
                    $i8.RequestId = invocationId;
                    $i8.Parameters = ps;
                    return $i8;
                })();
                return $.$kVHt.LCFCH.WebSocketHubUtility.SendRequestOverSocket($.$uvJL.LCFCR.RemoteProxyMethodInfo, this.connection, $.$clone(methodInfo), this.disposalTokenSource.Token);
            }
            //--TRIMMABLE-BOUNDARY-END(34359879790)
            
            //--TRIMMABLE-BOUNDARY-START(64424650862)
            /*Task *//*async*/  StartConnection(/*ClientWebSocket*/ connection)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424650862);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let uri = new $.$spu.S.Uri().$ctor$5(`${$.$strNN(this.Scheme.ToString())}://${$.$strNN(this.Host.ToString())}/${$.$strNN("___"/*HttpExtension.WebSocketRemoteProcedurePath*/)}/${$.$strNN(this.Route)}?connectionId=${$.$strNN(this.ConnectionId)}`);
                    ($t9 = connection.ConnectAsync$1(uri, this.disposalTokenSource.Token), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    _ = this.ReceiveLoop(connection);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64424650862)
            
            //--TRIMMABLE-BOUNDARY-START(30064912494)
            /*Task<TResult> */ InvokeAsync(TInterface, TResult, /*MockMethodContext*/ context, /*params MockMethodParameter[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064912494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SendAndReceive(TResult, new ($.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task))().$ctor(this,  (/*invocationId*/ invocationId) =>
                {
                    return this.InvokeServerMethodFromClientInternal(invocationId, $.$clone(context), parameters);
                }, $KnZMLk ??= {"r":178454529,"p":[{"n":"invocationId","p":655361}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(30064912494)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21474977902)
                this.disposalTokenSource = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(21474977902)
                
                //--TRIMMABLE-BOUNDARY-START(42949814382)
                this.methodRegistrations = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.SR.MethodInfo, $.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$$.STT.Task)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(42949814382)
                
            }
            static $H = 141422;
            static $h = 141422;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$kVHt.LCFCH.BaseClientHubConnector$$$$(THubClient, THubServer, $.$snwc.SNW.ClientWebSocket); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885043310),
    {
      "r": 65537,
      "p": [
        {
          "n": "connection",
          "p": 327785
        }
      ],
      "n": "CloseConnection",
      "d": this.$h,
      "H": 12885043310,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885043310),
//--TRIMMABLE-BOUNDARY-START(17180010606),
    {
      "r": 327785,
      "p": [
        {
          "n": "currentConnection",
          "p": 327785
        }
      ],
      "n": "CreateConnection",
      "d": this.$h,
      "H": 17180010606,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180010606),
//--TRIMMABLE-BOUNDARY-START(38654847086),
    {
      "r": 262145,
      "n": "IsConnected",
      "d": this.$h,
      "H": 38654847086,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38654847086),
//--TRIMMABLE-BOUNDARY-START(25769945198),
    {
      "r": 178454529,
      "p": [
        {
          "n": "timeOutMs",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "EnsureConnected",
      "d": this.$h,
      "H": 25769945198,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25769945198),
//--TRIMMABLE-BOUNDARY-START(51539748974),
    {
      "r": 91095041,
      "p": [
        {
          "n": "connection",
          "p": 327785
        },
        {
          "n": "clientMethod",
          "p": 117571585
        },
        {
          "n": "handler",
          "p": $.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$$.STT.Task).$h
        }
      ],
      "n": "OnClientMethod",
      "d": this.$h,
      "H": 51539748974,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51539748974),
//--TRIMMABLE-BOUNDARY-START(55834716270),
    {
      "r": 178454529,
      "p": [
        {
          "n": "connection",
          "p": 327785
        }
      ],
      "n": "ReceiveLoop",
      "d": this.$h,
      "H": 55834716270,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(55834716270),
//--TRIMMABLE-BOUNDARY-START(60129683566),
    {
      "r": (T) => $.$$.STT.Task$$(T).$h,
      "p": [
        {
          "n": "send",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "SendAndReceive",
      "d": this.$h,
      "H": 60129683566,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(60129683566),
//--TRIMMABLE-BOUNDARY-START(34359879790),
    {
      "r": 178454529,
      "p": [
        {
          "n": "invocationId",
          "p": 655361
        },
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "n": "InvokeServerMethodFromClientInternal",
      "d": this.$h,
      "H": 34359879790,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34359879790),
//--TRIMMABLE-BOUNDARY-START(64424650862),
    {
      "r": 178454529,
      "p": [
        {
          "n": "connection",
          "p": 327785
        }
      ],
      "n": "StartConnection",
      "d": this.$h,
      "H": 64424650862,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16814084
    },
//--TRIMMABLE-BOUNDARY-END(64424650862),
//--TRIMMABLE-BOUNDARY-START(30064912494),
    {
      "r": (TInterface, TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "context",
          "p": 978758
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$zHIt.LCFCM.MockMethodParameter).$h,
          "f": 16
        }
      ],
      "g": [
        "TInterface",
        "TResult"
      ],
      "n": "InvokeAsync",
      "d": this.$h,
      "H": 30064912494,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(30064912494)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21474977902),
    {
      "t": 170983425,
      "n": "disposalTokenSource",
      "d": this.$h,
      "H": 21474977902,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21474977902),
//--TRIMMABLE-BOUNDARY-START(42949814382),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.SR.MethodInfo, $.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$$.STT.Task)).$h,
      "n": "methodRegistrations",
      "d": this.$h,
      "H": 42949814382,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949814382),
//--TRIMMABLE-BOUNDARY-START(8590076014),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Int32, $.$$.STT.TaskCompletionSource$$($.$$.S.ArraySegment$$($.$$.S.Byte))).$h,
      "n": "awaitingResponses",
      "d": this.$h,
      "H": 8590076014,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590076014),
//--TRIMMABLE-BOUNDARY-START(47244781678),
    {
      "t": 655361,
      "n": "nextRequestId",
      "d": this.$h,
      "H": 47244781678,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47244781678)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295108718),
    {
      "p": [
        {
          "n": "appContext",
          "p": 46041430
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4295108718,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295108718)
  ],
  "s": [
    {
      "h": THubClient?.$h??1572864,
      "n": "THubClient",
      "c": [534985
      ]
    },
    {
      "h": THubServer?.$h??1638400,
      "n": "THubServer",
      "f": 1
    }
  ],
  "r": 2,
  "H": 141422,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$zHIt.LCFCM.IMockImplement, $.$kVHt.LCFCH.IHubConnector$$$(THubClient, THubServer), $.$kVHt.LCFCH.IHubConnector$$(THubClient) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.WebSocket.WebSocketHubConnector<${THubClient?.$fullName},${THubServer?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}WebSocket${separator}WebSocketHubConnector$${THubClient?.$getFullName(separator)}$${THubServer?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(141422)
        
        

        //--TRIMMABLE-BOUNDARY-START(206958)
        $asm.$cls(`$XvXV.LCFCRW.WebSocketHubConnector<>`, (THubClient) => $asm.$gt(`$XvXV.LCFCRW.WebSocketHubConnector<>`, [THubClient], ($self) => class WebSocketHubConnector$$ extends $.$XvXV.LCFCRW.WebSocketHubConnector$$$(THubClient, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(4295174254)
            $ctor$3(/*IApplicationContextProvider*/ appContext)
            {
                super.$ctor$2(appContext);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295174254);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295174254)
            
            static $H = 206958;
            static $h = 206958;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XvXV.LCFCRW.WebSocketHubConnector$$$(THubClient, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295174254),
    {
      "p": [
        {
          "n": "appContext",
          "p": 46041430
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 4295174254,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295174254)
  ],
  "s": [
    {
      "h": THubClient?.$h??1572864,
      "n": "THubClient",
      "c": [534985
      ]
    }
  ],
  "r": 1,
  "H": 206958,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$zHIt.LCFCM.IMockImplement, $.$kVHt.LCFCH.IHubConnector$$$(THubClient, $.$$.S.Object), $.$kVHt.LCFCH.IHubConnector$$(THubClient) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.WebSocket.WebSocketHubConnector<${THubClient?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}WebSocket${separator}WebSocketHubConnector$${THubClient?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(206958)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC"));
})();
//--TRIMMABLE-BOUNDARY-END(10350)
