
//--TRIMMABLE-BOUNDARY-START(64467)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt) {
    "use strict";
    let _;
    let $urnzOa;
    let $ugOSbd;
    let $toqWVe;
    let $DEzokl;
    let $cRqeud;
    let $iTZDCb;
    let $BuweHi;
    let $PusKja;
    let $mtxjqh;
    let $WXUwCd;
    let $hHvkfe;
    let $dkWFFk;
    let $GKPHDc;
    let $BKXvSd;
    let $eMcCSk;
    let $jMkBRa;
    let $dEiczk;
    let $yLUDLb;
    let $iNiqPa;
    let $PtFtNj;
    let $iPlBDc;
    let $cupIAk;
    let $HmHIEb;
    let $LrgJfl;
    let $NUVJcf;
    let $TQLWXh;
    let $eXhNYc;
    let $MyuhXc;
    let $DCpujj;
    let $VyttVd;
    let $ulwMEh;
    let $KVVANe;
    let $yIubHj;
    let $fvZycg;
    let $CCUzZa;
    let $RQpFDc;
    let $tuQBWd;
    let $hMEWgd;
    let $ybQelb;
    let $DilFcd;
    let $CkYSlc;
    let $KXbyZe;
    let $AQyeni;
    let $PjMuQj;
    let $OaOkrf;
    let $IhZVmb;
    let $WNgPBg;
    let $CNifoa;
    let $arfkzb;
    let $CRyCej;
    let $tSRoaj;
    let $yUUbWk;
    let $GAROsg;
    let $gvtatb;
    let $ILNkWd;
    let $bAQque;
    let $IOkVrg;
    let $hehxPa;
    let $hazHfd;
    let $bmVyOg;
    let $Rhlmjc;
    let $CxNxei;
    let $VtGWcg;
    let $efiqpa;
    let $eqpCca;
    let $tIvgSd;
    let $yFkuQe;
    let $SvlzLi;
    let $ENwXOi;
    let $ertbgh;
    let $kLdrIc;
    let $LqpuKe;
    let $UFdkFf;
    let $YrrQlg;
    let $jOPuoc;
    let $WbIFvg;
    let $foXzba;
    let $rhvqnb;
    let $BLCLag;
    let $PeAVhi;
    let $VYVFnj;
    let $cOmWHb;
    let $YUODnc;
    let $QeaZQj;
    let $vOYDkl;
    let $dtzHjd;
    let $zxncYh;
    let $EZlwwc;
    let $GGlUEd;
    let $grvAZj;
    let $cCzTUd;
    let $sDIWPh;
    let $CgJEHi;
    let $aGspfd;
    let $gQXSEb;
    let $WdbCHa;
    let $OfBnAd;
    let $VvIcQh;
    let $vedmOb;
    let $fKLwhi;
    let $DDPeLi;
    let $Kxpwig;
    let $JsdKch;
    let $iHobSf;
    let $WJEDri;
    let $YFLSbh;
    let $EvjJml;
    let $WsbPif;
    let $LlcDRf;
    let $rreFxf;
    let $Uissri;
    let $BBTUlg;
    let $GghXmc;
    let $KfiThj;
    let $TvSmBe;
    let $UlOJQe;
    let $hqRTyh;
    let $nJsmlg;
    let $qOmMrd;
    let $IaNlof;
    let $atevil;
    let $DfiOqc;
    let $bAgbak;
    let $MvnNhj;
    let $XxqtYf;
    let $mhiXMd;
    let $EsZIxh;
    let $VTrWJb;
    let $SsxIOb;
    let $HSMuXf;
    let $DmLhDe;
    let $aYfKke;
    let $lKOTCk;
    let $KkXdba;
    let $DNoSzj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.RPC", 
    {
  "h": 64467,
  "f": "LivingThing.Core.Frameworks.Common.RPC",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.RPC",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.RPC",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1375187)
        $asm.$cls(`$uvJL.LCFCR.IServerRemoteServiceOfflineCache`, ($self) => class IServerRemoteServiceOfflineCache
        {
            static $h = 1375187;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296342483),
    {
      "r": (TService, T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "TService",
        "T"
      ],
      "n": "GetItem",
      "o": "LCFCR$IServerRemoteServiceOfflineCache$GetItem",
      "d": 1375187,
      "h": 4296342483,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(4296342483),
//--TRIMMABLE-BOUNDARY-START(8591309779),
    {
      "r": 181338113,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TService, T) => T.$h
        },
        {
          "n": "expiry",
          "p": 186646529
        }
      ],
      "g": [
        "TService",
        "T"
      ],
      "n": "SetItem",
      "o": "LCFCR$IServerRemoteServiceOfflineCache$SetItem",
      "d": 1375187,
      "h": 8591309779,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8591309779)
  ],
  "h": 1375187
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IServerRemoteServiceOfflineCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IServerRemoteServiceOfflineCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1375187)
        
        

        //--TRIMMABLE-BOUNDARY-START(1178579)
        $asm.$cls(`$uvJL.LCFCR.IRemoteStream`, ($self) => class IRemoteStream
        {
            static $h = 1178579;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476015059),
    {
      "p": 95748097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591113171,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 17181047763,
        "f": 83886337
      },
      "n": "Stream",
      "o": "LCFCR$IRemoteStream$Stream",
      "d": 1178579,
      "h": 21476015059,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21476015059)
  ],
  "h": 1178579
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IRemoteStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IRemoteStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1178579)
        
        

        //--TRIMMABLE-BOUNDARY-START(1113043)
        $asm.$cls(`$uvJL.LCFCR.IRemoteServiceOptions`, ($self) => class IRemoteServiceOptions
        {
            static $h = 1113043;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591047635),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065884115,
        "f": 50331905
      },
      "n": "Batching",
      "o": "LCFCR$IRemoteServiceOptions$Batching",
      "d": 1113043,
      "h": 8591047635,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591047635),
//--TRIMMABLE-BOUNDARY-START(12886014931),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655818707,
        "f": 50331905
      },
      "n": "Encrypt",
      "o": "LCFCR$IRemoteServiceOptions$Encrypt",
      "d": 1113043,
      "h": 12886014931,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886014931),
//--TRIMMABLE-BOUNDARY-START(4296080339),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475949523,
        "f": 50331905
      },
      "n": "Authenticate",
      "o": "LCFCR$IRemoteServiceOptions$Authenticate",
      "d": 1113043,
      "h": 4296080339,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296080339),
//--TRIMMABLE-BOUNDARY-START(77310524371),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425622483,
        "f": 50331905
      },
      "n": "TimeOut",
      "o": "LCFCR$IRemoteServiceOptions$TimeOut",
      "d": 1113043,
      "h": 77310524371,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(77310524371),
//--TRIMMABLE-BOUNDARY-START(73015557075),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835687891,
        "f": 50331905
      },
      "n": "Retries",
      "o": "LCFCR$IRemoteServiceOptions$Retries",
      "d": 1113043,
      "h": 73015557075,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(73015557075),
//--TRIMMABLE-BOUNDARY-START(68720589779),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245753299,
        "f": 50331905
      },
      "n": "RequestHeader",
      "o": "LCFCR$IRemoteServiceOptions$RequestHeader",
      "d": 1113043,
      "h": 68720589779,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(68720589779)
  ],
  "h": 1113043
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IRemoteServiceOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IRemoteServiceOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1113043)
        
        

        //--TRIMMABLE-BOUNDARY-START(1309651)
        $asm.$cls(`$uvJL.LCFCR.IServerRemoteService`, ($self) => class IServerRemoteService
        {
            static $h = 1309651;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296276947),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddServiceRequestHeader",
      "o": "LCFCR$IServerRemoteService$AddServiceRequestHeader",
      "d": 1309651,
      "h": 4296276947,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296276947),
//--TRIMMABLE-BOUNDARY-START(8591244243),
    {
      "r": (TService) => $.$fPer.LCFCS$3.IServiceProxy$$(TService).$h,
      "p": [
        {
          "n": "context",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "TService"
      ],
      "n": "GetRemoteService",
      "o": "LCFCR$IServerRemoteService$GetRemoteService",
      "d": 1309651,
      "h": 8591244243,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(8591244243)
  ],
  "h": 1309651
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IServerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IServerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1309651)
        
        

        //--TRIMMABLE-BOUNDARY-START(1244115)
        $asm.$cls(`$uvJL.LCFCR.IServerRemoteFunction<,>`, (TService, TData) => $asm.$gt(`$uvJL.LCFCR.IServerRemoteFunction<,>`, [TService, TData], ($self) => class IServerRemoteFunction$$$
        {
            static $H = 1244115;
            static $h = 1244115;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591178707),
    {
      "r": $.$$.STT.Task$$(TData).$h,
      "p": [
        {
          "n": "reader",
          "p": $.$$.S.Func$$$(TService, $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$(TData))).$h
        }
      ],
      "n": "Execute",
      "o": `LCFCR$IServerRemoteFunction$$$$Execute$${TService.$getFullName('$')}$${TData.$getFullName('$')}$1`,
      "d": this.$h,
      "H": 8591178707,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591178707),
//--TRIMMABLE-BOUNDARY-START(4296211411),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TData)).$h,
      "p": [
        {
          "n": "reader",
          "p": $.$$.S.Func$$$(TService, $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(TData))).$h
        }
      ],
      "n": "Execute",
      "o": `LCFCR$IServerRemoteFunction$${TService.$getFullName('$')}$${TData.$getFullName('$')}$Execute`,
      "d": this.$h,
      "H": 4296211411,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296211411)
  ],
  "s": [
    {
      "h": TService?.$h??1572864,
      "n": "TService",
      "f": 1,
      "c": [48007510
      ]
    },
    {
      "h": TData?.$h??1638400,
      "n": "TData"
    }
  ],
  "r": 2,
  "H": 1244115,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IServerRemoteFunction<${TService?.$fullName},${TData?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IServerRemoteFunction$${TService?.$getFullName(separator)}$${TData?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1244115)
        
        

        //--TRIMMABLE-BOUNDARY-START(916435)
        $asm.$cls(`$uvJL.LCFCR.IOfflineCachableServerRemoteService`, ($self) => class IOfflineCachableServerRemoteService
        {
            static $h = 916435;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295883731),
    {
      "p": 1375187,
      "s": {
        "r": 0,
        "d": 0,
        "h": 12885818323,
        "f": 83886337
      },
      "n": "OfflineCache",
      "o": "LCFCR$IOfflineCachableServerRemoteService$OfflineCache",
      "d": 916435,
      "h": 4295883731,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295883731)
  ],
  "h": 916435
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IOfflineCachableServerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IOfflineCachableServerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(916435)
        
        

        //--TRIMMABLE-BOUNDARY-START(719827)
        $asm.$cls(`$uvJL.LCFCR.IClientServerRemoteService`, ($self) => class IClientServerRemoteService
        {
            static $h = 719827;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295687123),
    {
      "r": 654291,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetBatchService",
      "o": "LCFCR$IClientServerRemoteService$GetBatchService",
      "d": 719827,
      "h": 4295687123,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295687123)
  ],
  "h": 719827
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IServerRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IClientServerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IClientServerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(719827)
        
        

        //--TRIMMABLE-BOUNDARY-START(654291)
        $asm.$cls(`$uvJL.LCFCR.IBatchClientServerRemoteService`, ($self) => class IBatchClientServerRemoteService
        {
            static $h = 654291;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590588883),
    {
      "r": 65537,
      "p": [
        {
          "n": "batchIndex",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "NOP",
      "o": "LCFCR$IBatchClientServerRemoteService$NOP",
      "d": 654291,
      "h": 8590588883,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590588883),
//--TRIMMABLE-BOUNDARY-START(4295621587),
    {
      "r": 178454529,
      "p": [
        {
          "n": "options",
          "p": 1113043
        }
      ],
      "n": "Commit",
      "o": "LCFCR$IBatchClientServerRemoteService$Commit",
      "d": 654291,
      "h": 4295621587,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295621587)
  ],
  "h": 654291
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IServerRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IBatchClientServerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IBatchClientServerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(654291)
        
        

        //--TRIMMABLE-BOUNDARY-START(1047507)
        $asm.$cls(`$uvJL.LCFCR.IRemoteEnumerable<>`, (T) => $asm.$gt(`$uvJL.LCFCR.IRemoteEnumerable<>`, [T], ($self) => class IRemoteEnumerable$$
        {
            static $H = 1047507;
            static $h = 1047507;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296014803),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180916691,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331905
      },
      "n": "Count",
      "o": "LCFCR$IRemoteEnumerable$$$Count",
      "d": this.$h,
      "H": 4296014803,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296014803),
//--TRIMMABLE-BOUNDARY-START(8590982099),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770851283,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47245687763,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 83886337
      },
      "n": "CurrentPage",
      "o": "LCFCR$IRemoteEnumerable$$$CurrentPage",
      "d": this.$h,
      "H": 8590982099,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590982099),
//--TRIMMABLE-BOUNDARY-START(38655753171),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360785875,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 55835622355,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 83886337
      },
      "n": "PageSize",
      "o": "LCFCR$IRemoteEnumerable$$$PageSize",
      "d": this.$h,
      "H": 38655753171,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38655753171)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 1047507,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IAsyncEnumerable$$(T) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IRemoteEnumerable<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IRemoteEnumerable$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1047507)
        
        

        //--TRIMMABLE-BOUNDARY-START(850899)
        $asm.$cls(`$uvJL.LCFCR.IFilteringServerRemoteService`, ($self) => class IFilteringServerRemoteService
        {
            static $h = 850899;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295818195),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885752787,
        "f": 50331905
      },
      "n": "Filter",
      "o": "LCFCR$IFilteringServerRemoteService$Filter",
      "d": 850899,
      "h": 4295818195,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295818195)
  ],
  "h": 850899
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IServerRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IFilteringServerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IFilteringServerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(850899)
        
        

        //--TRIMMABLE-BOUNDARY-START(785363)
        $asm.$cls(`$uvJL.LCFCR.ICRUDDataRemoteService<>`, (TDataModel) => $asm.$gt(`$uvJL.LCFCR.ICRUDDataRemoteService<>`, [TDataModel], ($self) => class ICRUDDataRemoteService$$
        {
            static $H = 785363;
            static $h = 785363;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TDataModel?.$h??1572864,
      "n": "TDataModel"
    }
  ],
  "r": 1,
  "H": 785363,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.ICreateDataService$$(TDataModel), $.$fPer.LCFCD.IReadDataService$$(TDataModel), $.$fPer.LCFCD.IReadManyDataService$$(TDataModel), $.$fPer.LCFCD.IReadSingleDataService$$(TDataModel), $.$fPer.LCFCD.IUpdateDataService$$(TDataModel), $.$fPer.LCFCD.IDeleteDataService$$(TDataModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ICRUDDataRemoteService<${TDataModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ICRUDDataRemoteService$${TDataModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(785363)
        
        

        //--TRIMMABLE-BOUNDARY-START(1440723)
        $asm.$cls(`$uvJL.LCFCR.IServiceRemoteService<,>`, (TServiceModel, TServiceTier) => $asm.$gt(`$uvJL.LCFCR.IServiceRemoteService<,>`, [TServiceModel, TServiceTier], ($self) => class IServiceRemoteService$$$
        {
            static $H = 1440723;
            static $h = 1440723;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296408019),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "contextId",
          "p": 1310721
        },
        {
          "n": "newTier",
          "p": TServiceTier?.$h??1638400
        },
        {
          "n": "expiryDate",
          "p": 65994753
        }
      ],
      "n": "ChangeServiceTier",
      "o": `LCFCR$IServiceRemoteService$${TServiceModel.$getFullName('$')}$${TServiceTier.$getFullName('$')}$ChangeServiceTier`,
      "d": this.$h,
      "H": 4296408019,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296408019)
  ],
  "s": [
    {
      "h": TServiceModel?.$h??1572864,
      "n": "TServiceModel",
      "c": [$.$fPer.LCFCD.IServiceDataModel$$(TServiceTier).$h
      ]
    },
    {
      "h": TServiceTier?.$h??1638400,
      "n": "TServiceTier",
      "f": 2,
      "c": [1048577
      ]
    }
  ],
  "r": 2,
  "H": 1440723,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$(TServiceModel), $.$fPer.LCFCD.ICreateDataService$$(TServiceModel), $.$fPer.LCFCD.IReadDataService$$(TServiceModel), $.$fPer.LCFCD.IReadManyDataService$$(TServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$(TServiceModel), $.$fPer.LCFCD.IUpdateDataService$$(TServiceModel), $.$fPer.LCFCD.IDeleteDataService$$(TServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IServiceRemoteService<${TServiceModel?.$fullName},${TServiceTier?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IServiceRemoteService$${TServiceModel?.$getFullName(separator)}$${TServiceTier?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1440723)
        
        

        //--TRIMMABLE-BOUNDARY-START(2358227)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyServiceBase`, ($self) => class RemoteProxyServiceBase extends $.$zHIt.LCFCM.MockBase
        {
            //--TRIMMABLE-BOUNDARY-START(8592292819)
            $ctor$2(/*IMockImplement*/ impl)
            {
                super.$ctor$1(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592292819);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592292819)
            
            //--TRIMMABLE-BOUNDARY-START(21477194707)
            /*RemoteProxyExecutionContext?*/ Options = null;
            //--TRIMMABLE-BOUNDARY-END(21477194707)
            
            static $h = 2358227;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$zHIt.LCFCM.MockBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477194707),
    {
      "p": 1702867,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182227411,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30067129299,
        "f": 83886081
      },
      "n": "Options",
      "d": 2358227,
      "h": 21477194707,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477194707)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592292819),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2358227,
      "h": 8592292819,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8592292819)
  ],
  "h": 2358227
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceBase`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyServiceBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2358227)
        
        

        //--TRIMMABLE-BOUNDARY-START(326611)
        $asm.$cls(`$uvJL.LCFCR.CRUDRemoteProxyServiceBase<>`, (TDataModel) => $asm.$gt(`$uvJL.LCFCR.CRUDRemoteProxyServiceBase<>`, [TDataModel], ($self) => class CRUDRemoteProxyServiceBase$$ extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295293907)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295293907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295293907)
            
            //--TRIMMABLE-BOUNDARY-START(8590261203)
            /*Task<WireTransportManyModel<TDataModel>> */ Create(/*DataFilter*/ filter, /*TDataModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590261203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync($.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel), $.$fPer.LCFCD.WireTransportManyModel$$(TDataModel), (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray(TDataModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590261203)
            
            //--TRIMMABLE-BOUNDARY-START(17180195795)
            /*Task<WireTransportManyModel<TDataModel>> */ ReadMany(/*DataFilter?*/ filter, /*TDataModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180195795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync($.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel), $.$fPer.LCFCD.WireTransportManyModel$$(TDataModel), (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4(TDataModel.$type, $.$box(_, TDataModel)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180195795)
            
            //--TRIMMABLE-BOUNDARY-START(21475163091)
            /*Task<WireTransportModel<TDataModel>> */ ReadSingle(/*DataFilter*/ filter, /*TDataModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475163091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync($.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel), $.$fPer.LCFCD.WireTransportModel$$(TDataModel), (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4(TDataModel.$type, $.$box(_, TDataModel)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475163091)
            
            //--TRIMMABLE-BOUNDARY-START(25770130387)
            /*Task<WireTransportManyModel<TDataModel>> */ Update(/*DataFilter*/ filter, /*TDataModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770130387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync($.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel), $.$fPer.LCFCD.WireTransportManyModel$$(TDataModel), (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray(TDataModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770130387)
            
            //--TRIMMABLE-BOUNDARY-START(12885228499)
            /*Task<WireTransportManyModel<bool>> */ Delete(/*DataFilter*/ filter, /*TDataModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885228499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InvokeAsync($.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray(TDataModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885228499)
            
            //--TRIMMABLE-BOUNDARY-START(4311517526)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.ICreateDataService<TDataModel>.Create(LivingThing.Core.Frameworks.Common.Data.DataFilter, params TDataModel[])
            [`LCFCD$ICreateDataService$${TDataModel.$getFullName('$')}$Create`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311517526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Create(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311517526)
            
            //--TRIMMABLE-BOUNDARY-START(4317153622)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IReadManyDataService<TDataModel>.ReadMany(LivingThing.Core.Frameworks.Common.Data.DataFilter?, TDataModel?)
            [`LCFCD$IReadManyDataService$${TDataModel.$getFullName('$')}$ReadMany`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4317153622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadMany(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4317153622)
            
            //--TRIMMABLE-BOUNDARY-START(4317415766)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IReadSingleDataService<TDataModel>.ReadSingle(LivingThing.Core.Frameworks.Common.Data.DataFilter, TDataModel?)
            [`LCFCD$IReadSingleDataService$${TDataModel.$getFullName('$')}$ReadSingle`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4317415766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadSingle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4317415766)
            
            //--TRIMMABLE-BOUNDARY-START(4319250774)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IUpdateDataService<TDataModel>.Update(LivingThing.Core.Frameworks.Common.Data.DataFilter, params TDataModel[])
            [`LCFCD$IUpdateDataService$${TDataModel.$getFullName('$')}$Update`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4319250774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Update(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4319250774)
            
            //--TRIMMABLE-BOUNDARY-START(4313024854)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDeleteDataService<TDataModel>.Delete(LivingThing.Core.Frameworks.Common.Data.DataFilter, params TDataModel[])
            LCFCD$IDeleteDataService$$$Delete()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313024854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Delete(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313024854)
            
            static $H = 326611;
            static $h = 326611;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590261203),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(TDataModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "models",
          "p": $.$typeArray(TDataModel).$h
        }
      ],
      "n": "Create",
      "d": this.$h,
      "H": 8590261203,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590261203),
//--TRIMMABLE-BOUNDARY-START(17180195795),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(TDataModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "_",
          "p": TDataModel?.$h??1572864
        }
      ],
      "n": "ReadMany",
      "d": this.$h,
      "H": 17180195795,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180195795),
//--TRIMMABLE-BOUNDARY-START(21475163091),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$(TDataModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "_",
          "p": TDataModel?.$h??1572864
        }
      ],
      "n": "ReadSingle",
      "d": this.$h,
      "H": 21475163091,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475163091),
//--TRIMMABLE-BOUNDARY-START(25770130387),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(TDataModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "models",
          "p": $.$typeArray(TDataModel).$h
        }
      ],
      "n": "Update",
      "d": this.$h,
      "H": 25770130387,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770130387),
//--TRIMMABLE-BOUNDARY-START(12885228499),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "models",
          "p": $.$typeArray(TDataModel).$h
        }
      ],
      "n": "Delete",
      "d": this.$h,
      "H": 12885228499,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885228499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295293907),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 4295293907,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295293907)
  ],
  "s": [
    {
      "h": TDataModel?.$h??1572864,
      "n": "TDataModel"
    }
  ],
  "r": 1,
  "H": 326611,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel), $.$fPer.LCFCD.ICreateDataService$$(TDataModel), $.$fPer.LCFCD.IReadDataService$$(TDataModel), $.$fPer.LCFCD.IReadManyDataService$$(TDataModel), $.$fPer.LCFCD.IReadSingleDataService$$(TDataModel), $.$fPer.LCFCD.IUpdateDataService$$(TDataModel), $.$fPer.LCFCD.IDeleteDataService$$(TDataModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.CRUDRemoteProxyServiceBase<${TDataModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}CRUDRemoteProxyServiceBase$${TDataModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(326611)
        
        

        //--TRIMMABLE-BOUNDARY-START(130003)
        $asm.$cls(`$uvJL.LCFCR._RemoteServiceFilter<>`, (TFilterEnum) => $asm.$gt(`$uvJL.LCFCR._RemoteServiceFilter<>`, [TFilterEnum], ($self) => class _RemoteServiceFilter$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30064901075)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064901075);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064901075)
            
            //--TRIMMABLE-BOUNDARY-START(38654835667)
            /*TFilterEnum*/ Filter = $.$default(TFilterEnum);
            //--TRIMMABLE-BOUNDARY-END(38654835667)
            
            //--TRIMMABLE-BOUNDARY-START(42949802963)
            /*IEnumerable<TFilterEnum>*/ Filters = null;
            //--TRIMMABLE-BOUNDARY-END(42949802963)
            
            //--TRIMMABLE-BOUNDARY-START(163208887251)
            /*string*/ TargetId = null;
            //--TRIMMABLE-BOUNDARY-END(163208887251)
            
            //--TRIMMABLE-BOUNDARY-START(98784377811)
            /*string*/ Parameters = null;
            //--TRIMMABLE-BOUNDARY-END(98784377811)
            
            //--TRIMMABLE-BOUNDARY-START(154618952659)
            /*DateTime?*/ StartDate = null;
            //--TRIMMABLE-BOUNDARY-END(154618952659)
            
            //--TRIMMABLE-BOUNDARY-START(34359868371)
            /*DateTime?*/ EndDate = null;
            //--TRIMMABLE-BOUNDARY-END(34359868371)
            
            //--TRIMMABLE-BOUNDARY-START(158913919955)
            static /*string */ op_Implicit(/*_RemoteServiceFilter<TFilterEnum>*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913919955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCS$1.Serialized.op_Implicit$1($.$fPer.LCFCS$1.JsonSerializeExtension.Serialize($.$uvJL.LCFCR._RemoteServiceFilter$$(TFilterEnum), model, true, false, true, false, false, false, false, "", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC\\RemoteServiceFilter.cs", "", 24));
            }
            //--TRIMMABLE-BOUNDARY-END(158913919955)
            
            //--TRIMMABLE-BOUNDARY-START(167503854547)
            static /*_RemoteServiceFilter<TFilterEnum> */ op_Implicit$1(/*string*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503854547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*string*/ let __ca1__;
                    return _ = ((__ca1__ = model) !== null ? $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3($.$uvJL.LCFCR._RemoteServiceFilter$$(TFilterEnum), __ca1__, false, "", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC\\RemoteServiceFilter.cs", "", 32) : null);
                }
                catch($e)
                {
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(167503854547)
            
            //--TRIMMABLE-BOUNDARY-START(171798821843)
            static /*_RemoteServiceFilter<TFilterEnum> */ With(/*TFilterEnum*/ filter, /*object*/ targetId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798821843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let __ca2__;
                return (() =>
                {
                    //new $.$uvJL.LCFCR._RemoteServiceFilter$$(TFilterEnum)()
                    const $t1 = $.$uvJL.LCFCR._RemoteServiceFilter$$(TFilterEnum);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Filter = filter;
                    $i1.TargetId = ((__ca2__ = targetId) !== null ? $.$dsp(__ca2__, $.$$.S.Object, ($t) => $t.ToString) : null);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(171798821843)
            
            //--TRIMMABLE-BOUNDARY-START(176093789139)
            static /*_RemoteServiceFilter<TFilterEnum> */ With$1(/*TFilterEnum[]*/ filters, /*object*/ targetId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093789139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let __ca3__;
                return (() =>
                {
                    //new $.$uvJL.LCFCR._RemoteServiceFilter$$(TFilterEnum)()
                    const $t2 = $.$uvJL.LCFCR._RemoteServiceFilter$$(TFilterEnum);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.Filters = filters;
                    $i2.TargetId = ((__ca3__ = targetId) !== null ? $.$dsp(__ca3__, $.$$.S.Object, ($t) => $t.ToString) : null);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(176093789139)
            
            //--TRIMMABLE-BOUNDARY-START(30064901075)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(30064901075)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(154618952659)
                this.StartDate = null;
                //--TRIMMABLE-BOUNDARY-END(154618952659)
                
                //--TRIMMABLE-BOUNDARY-START(34359868371)
                this.EndDate = null;
                //--TRIMMABLE-BOUNDARY-END(34359868371)
                
            }
            static $H = 130003;
            static $h = 130003;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654835667),
    {
      "p": TFilterEnum?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60129672147,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 115964246995,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 83886081
      },
      "n": "Filter",
      "d": this.$h,
      "H": 38654835667,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654835667),
//--TRIMMABLE-BOUNDARY-START(42949802963),
    {
      "p": $.$$.SCG.IEnumerable$$(TFilterEnum).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68719606739,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 124554181587,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 83886081
      },
      "n": "Filters",
      "d": this.$h,
      "H": 42949802963,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949802963),
//--TRIMMABLE-BOUNDARY-START(163208887251),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 94489410515,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 150323985363,
        "h": Number(BigInt(this.$h)|0x2300000000n),
        "f": 83886081
      },
      "n": "TargetId",
      "d": this.$h,
      "H": 163208887251,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163208887251),
//--TRIMMABLE-BOUNDARY-START(98784377811),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 77309541331,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 133144116179,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 83886081
      },
      "n": "Parameters",
      "d": this.$h,
      "H": 98784377811,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784377811),
//--TRIMMABLE-BOUNDARY-START(154618952659),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 85899475923,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 141734050771,
        "h": Number(BigInt(this.$h)|0x2100000000n),
        "f": 83886081
      },
      "n": "StartDate",
      "d": this.$h,
      "H": 154618952659,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154618952659),
//--TRIMMABLE-BOUNDARY-START(34359868371),
    {
      "p": $.$typeNullable($.$$.S.DateTime).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51539737555,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 107374312403,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 83886081
      },
      "n": "EndDate",
      "d": this.$h,
      "H": 34359868371,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359868371)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(171798821843),
    {
      "r": this.$h,
      "p": [
        {
          "n": "filter",
          "p": TFilterEnum?.$h??1572864
        },
        {
          "n": "targetId",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "With",
      "d": this.$h,
      "H": 171798821843,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171798821843),
//--TRIMMABLE-BOUNDARY-START(176093789139),
    {
      "r": this.$h,
      "p": [
        {
          "n": "filters",
          "p": $.$typeArray(TFilterEnum).$h
        },
        {
          "n": "targetId",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "With",
      "o": "@$1",
      "d": this.$h,
      "H": 176093789139,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(176093789139)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30064901075),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 30064901075,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064901075)
  ],
  "s": [
    {
      "h": TFilterEnum?.$h??1572864,
      "n": "TFilterEnum"
    }
  ],
  "r": 1,
  "H": 130003,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC._RemoteServiceFilter<${TFilterEnum?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}_RemoteServiceFilter$${TFilterEnum?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(130003)
        
        

        //--TRIMMABLE-BOUNDARY-START(2554835)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelCustomAttributesProvider`, ($self) => class RemoteProxyServiceMethodExceptionModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297522131)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297522131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297522131)
            
            static $h = 2554835;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297522131),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2554835,
      "h": 4297522131,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297522131)
  ],
  "h": 2554835
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyServiceMethodExceptionModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2554835)
        
        

        //--TRIMMABLE-BOUNDARY-START(3472339)
        $asm.$cls(`$uvJL.LCFCR.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298439635)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298439635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptorBuilder.Register();
                $.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptorBuilder.Register();
                $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298439635)
            
            static $h = 3472339;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298439635),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3472339,
      "h": 4298439635,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298439635)
  ],
  "h": 3472339
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3472339)
        
        

        //--TRIMMABLE-BOUNDARY-START(523219)
        $asm.$cls(`$uvJL.LCFCR.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295490515)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295490515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uvJL.LCFCR.RemoteProxyMethodInfo.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoCustomAttributesProvider, $.$uvJL.LCFCR.RemoteProxyMethodInfoCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uvJL.LCFCR.RemoteProxyMethodParameter.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uvJL.LCFCR.RemoteProxyMethodParameterCustomAttributesProvider, $.$uvJL.LCFCR.RemoteProxyMethodParameterCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelCustomAttributesProvider, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295490515)
            
            static $h = 523219;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295490515),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 523219,
      "h": 4295490515,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295490515)
  ],
  "h": 523219
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(523219)
        
        

        //--TRIMMABLE-BOUNDARY-START(2489299)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel`, ($self) => class RemoteProxyServiceMethodExceptionModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(141736410067)
            /*string*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(141736410067)
            
            //--TRIMMABLE-BOUNDARY-START(85901835219)
            /*string*/ Message = null;
            //--TRIMMABLE-BOUNDARY-END(85901835219)
            
            //--TRIMMABLE-BOUNDARY-START(133146475475)
            /*string?*/ StackTrace = null;
            //--TRIMMABLE-BOUNDARY-END(133146475475)
            
            //--TRIMMABLE-BOUNDARY-START(77311900627)
            /*RemoteProxyServiceMethodExceptionModel?*/ InnerException = null;
            //--TRIMMABLE-BOUNDARY-END(77311900627)
            
            //--TRIMMABLE-BOUNDARY-START(81606867923)
            /*IEnumerable<RemoteProxyServiceMethodExceptionModel>?*/ InnerExceptions = null;
            //--TRIMMABLE-BOUNDARY-END(81606867923)
            
            //--TRIMMABLE-BOUNDARY-START(137441442771)
            /*RemoteProxyServiceMethodException */ ToException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441442771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*RemoteProxyServiceMethodException?*/ let innerException = null;
                if (this.InnerException !== null)
                {
                    innerException = this.InnerException.ToException();
                }
                /*var*/ let exception = new $.$uvJL.LCFCR.RemoteProxyServiceMethodException().$ctor$5(this, $.$strNN($.$strNN("Remote Server Error: " + $.$strNN(this.Type)) + "=>") + $.$strNN(this.Message), this.StackTrace, innerException);
                return exception;
            }
            //--TRIMMABLE-BOUNDARY-END(137441442771)
            
            //--TRIMMABLE-BOUNDARY-START(30067260371)
            static /*RemoteProxyServiceMethodExceptionModel */ Build(/*Exception*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067260371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let exception = (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel()
                    const $t1 = $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Type = e.GetType$1().FullName;
                    $i1.Message = e.Message;
                    $i1.StackTrace = e.StackTrace;
                    return $i1;
                })();
                let eag;
                if ($.$is(e, $.$$.S.AggregateException, { set $v($v){ eag = $v; } }) && eag.InnerExceptions !== null)
                {
                    exception.InnerExceptions = $.$sl.SL.Enumerable.ToList($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, $.$sl.SL.Enumerable.Select$1($.$$.S.Exception, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, eag.InnerExceptions, new ($.$$.S.Func$$$($.$$.S.Exception, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel))().$ctor(this,  (/*ine*/ ine) =>
                    {
                        return $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel.Build(ine);
                    }, $ugOSbd ??= {"r":2489299,"p":[{"n":"ine","p":80805889}],"n":"","d":2489299,"h":0,"f":17825794})));
                }
                if (e.InnerException !== null)
                {
                    exception.InnerException = $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel.Build(e.InnerException);
                }
                return exception;
            }
            //--TRIMMABLE-BOUNDARY-END(30067260371)
            
            //--TRIMMABLE-BOUNDARY-START(25772293075)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772293075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772293075)
            
            //--TRIMMABLE-BOUNDARY-START(25772293075)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25772293075)
            
            static $h = 2489299;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(141736410067),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016933331,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128851508179,
        "f": 83886081
      },
      "n": "Type",
      "d": 2489299,
      "h": 141736410067,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141736410067),
//--TRIMMABLE-BOUNDARY-START(85901835219),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837064147,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111671638995,
        "f": 83886081
      },
      "n": "Message",
      "d": 2489299,
      "h": 85901835219,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85901835219),
//--TRIMMABLE-BOUNDARY-START(133146475475),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426998739,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120261573587,
        "f": 83886081
      },
      "n": "StackTrace",
      "d": 2489299,
      "h": 133146475475,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133146475475),
//--TRIMMABLE-BOUNDARY-START(77311900627),
    {
      "p": 2489299,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657194963,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491769811,
        "f": 83886081
      },
      "n": "InnerException",
      "d": 2489299,
      "h": 77311900627,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311900627),
//--TRIMMABLE-BOUNDARY-START(81606867923),
    {
      "p": $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247129555,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081704403,
        "f": 83886081
      },
      "n": "InnerExceptions",
      "d": 2489299,
      "h": 81606867923,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606867923)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137441442771),
    {
      "r": 2423763,
      "n": "ToException",
      "d": 2489299,
      "h": 137441442771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137441442771),
//--TRIMMABLE-BOUNDARY-START(30067260371),
    {
      "r": 2489299,
      "p": [
        {
          "n": "e",
          "p": 80805889
        }
      ],
      "n": "Build",
      "d": 2489299,
      "h": 30067260371,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067260371)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772293075),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2489299,
      "h": 25772293075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772293075)
  ],
  "h": 2489299,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyServiceMethodExceptionModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2489299)
        
        

        //--TRIMMABLE-BOUNDARY-START(2096083)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyMethodParameterCustomAttributesProvider`, ($self) => class RemoteProxyMethodParameterCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297063379)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297063379)
            
            //--TRIMMABLE-BOUNDARY-START(8592030675)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592030675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uvJL.LCFCR.RemoteProxyMethodParameterCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(2);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Name", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("n");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Type", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("t");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Parameter", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t5 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("p");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_Parameter", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t6 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$3("parameter");
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t7 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i7 = new $t7();
                        $i7.$ctor$7(4, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i7.set_Item("Name", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Key = "n";
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i7.set_Item("Type", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Key = "t";
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i7.set_Item("Parameter", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Key = "p";
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i7.set_Item("_Parameter", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Key = "parameter";
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i7;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uvJL.LCFCR.RemoteProxyMethodParameterCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $toqWVe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2096083,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $DEzokl ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2096083,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592030675)
            
            static $h = 2096083;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592030675),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2096083,
      "h": 8592030675,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592030675)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297063379),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2096083,
      "h": 4297063379,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297063379)
  ],
  "h": 2096083
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameterCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyMethodParameterCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2096083)
        
        

        //--TRIMMABLE-BOUNDARY-START(1833939)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyMethodInfoCustomAttributesProvider`, ($self) => class RemoteProxyMethodInfoCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296801235)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296801235)
            
            //--TRIMMABLE-BOUNDARY-START(8591768531)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591768531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$uvJL.LCFCR.RemoteProxyMethodInfoCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$stj.STJS$1.JsonPropertyNameAttribute.$type, $.$stj.STJS$1.JsonAttribute.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Service", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t3 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("s");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("RequestId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t4 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("i");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_Service", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t5 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("service");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ServiceParameters", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t6 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$3("sp");
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Parameters", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t7 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$3("ps");
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("_Parameters", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJS$1.JsonPropertyNameAttribute), [(() =>
                        {
                            //new $.$stj.STJS$1.JsonPropertyNameAttribute()
                            const $t8 = $.$stj.STJS$1.JsonPropertyNameAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$3("parameters");
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$stj.STJS$1.JsonPropertyNameAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$uvJL.LCFCR.RemoteProxyMethodInfoCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $cRqeud ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1833939,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $iTZDCb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1833939,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591768531)
            
            static $h = 1833939;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591768531),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1833939,
      "h": 8591768531,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591768531)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296801235),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1833939,
      "h": 4296801235,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296801235)
  ],
  "h": 1833939
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfoCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyMethodInfoCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1833939)
        
        

        //--TRIMMABLE-BOUNDARY-START(2292691)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptorBuilder`, ($self) => class RemoteProxyMethodParameterTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592227283)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592227283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor()
                        const $t1 = $.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dkWFFk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2292691,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uvJL.LCFCR.RemoteProxyMethodParameter.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592227283)
            
            //--TRIMMABLE-BOUNDARY-START(4297259987)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297259987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297259987)
            
            //--TRIMMABLE-BOUNDARY-START(4297259987)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297259987)
            
            static $h = 2292691;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592227283),
    {
      "r": 65537,
      "n": "Register",
      "d": 2292691,
      "h": 8592227283,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592227283)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297259987),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2292691,
      "h": 4297259987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297259987)
  ],
  "h": 2292691
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameterTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyMethodParameterTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2292691)
        
        

        //--TRIMMABLE-BOUNDARY-START(2685907)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptorBuilder`, ($self) => class RemoteProxyServiceMethodExceptionModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592620499)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592620499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor()
                        const $t1 = $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $cupIAk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2685907,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592620499)
            
            //--TRIMMABLE-BOUNDARY-START(4297653203)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297653203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297653203)
            
            //--TRIMMABLE-BOUNDARY-START(4297653203)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297653203)
            
            static $h = 2685907;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592620499),
    {
      "r": 65537,
      "n": "Register",
      "d": 2685907,
      "h": 8592620499,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592620499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297653203),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2685907,
      "h": 4297653203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297653203)
  ],
  "h": 2685907
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyServiceMethodExceptionModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2685907)
        
        

        //--TRIMMABLE-BOUNDARY-START(3144659)
        $asm.$cls(`$uvJL.LCFCR.ServerRemoteServiceExtension`, ($self) => class ServerRemoteServiceExtension
        {
            //--TRIMMABLE-BOUNDARY-START(94492425171)
            static /*string */ GetCacheKey(T, /*this DataFilter?*/ _filter, /*string?*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492425171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN($.$fPer.LCFCD.DeterministicHashCode.Combine$6($.$$.S.String, $.$fPer.LCFCD.DataFilter, T.$type.FullName, _filter))}/${$.$strNN(key)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(94492425171)
            
            //--TRIMMABLE-BOUNDARY-START(51542752211)
            static /*string */ CacheKeyFor(T, /*string?*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542752211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN($.$fPer.LCFCD.DeterministicHashCode.Combine$7($.$$.S.String, T.$type.FullName))}/${$.$strNN(key)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(51542752211)
            
            //--TRIMMABLE-BOUNDARY-START(55837719507)
            static /*string */ CacheKeyFor$1(TService, T, /*string?*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837719507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN($.$fPer.LCFCD.DeterministicHashCode.Combine$6($.$$.S.String, $.$$.S.String, TService.$type.FullName, T.$type.FullName))}/${$.$strNN(key)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(55837719507)
            
            //--TRIMMABLE-BOUNDARY-START(137442098131)
            static /*ValueTask<T> *//*async*/  RunInterceptors(T, /*DataFilter*/ filter, /*T*/ t)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T), T, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137442098131);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Data.DataFilterInterceptionContext>?*/ let __ca1__;
                    /*var*/ let interceptors = ((__ca1__ = filter.Interceptors) !== null ? $.$sl.SL.Enumerable.Select$1($.$fPer.LCFCD.DataFilterInterceptionContext, $.$$.S.ValueTuple$$$($.$fPer.LCFCD.IDataFilterResponseInterceptor$$(T), $.$$.S.Object), $.$sl.SL.Enumerable.Where($.$fPer.LCFCD.DataFilterInterceptionContext, __ca1__, new ($.$$.S.Func$$$($.$fPer.LCFCD.DataFilterInterceptionContext, $.$$.S.Boolean))().$ctor(this,  (/*i*/ i) =>
                    {
                        return $.$is(i.Interceptor, $.$fPer.LCFCD.IDataFilterResponseInterceptor$$(T));
                    }, $gvtatb ??= {"r":262145,"p":[{"n":"i","p":10127702}],"n":"","d":3144659,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$fPer.LCFCD.DataFilterInterceptionContext, $.$$.S.ValueTuple$$$($.$fPer.LCFCD.IDataFilterResponseInterceptor$$(T), $.$$.S.Object)))().$ctor(this,  (/*i*/ i) =>
                    {
                        return new ($.$$.S.ValueTuple$$$($.$fPer.LCFCD.IDataFilterResponseInterceptor$$(T), $.$$.S.Object))().$ctor$3($.$cast(i.Interceptor, $.$fPer.LCFCD.IDataFilterResponseInterceptor$$(T)), i.Context);
                    }, $ILNkWd ??= {"r":(T) => $.$$.S.ValueTuple$$$($.$fPer.LCFCD.IDataFilterResponseInterceptor$$(T), $.$$.S.Object).$h,"p":[{"n":"i","p":10127702}],"n":"","d":3144659,"h":0,"f":17825794})) : null);
                    if (interceptors !== null)
                    {
                        let $en1 = interceptors.SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let interceptor = $en1.SCG$IEnumerator$$$Current;
                            {
                                let $t2, $r2;
                                t = ($t2 = interceptor.Item1[`LCFCD$IDataFilterResponseInterceptor$${T.$getFullName('$')}$InterceptResponse`](t, filter, interceptor.Item2), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, t);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(137442098131)
            
            //--TRIMMABLE-BOUNDARY-START(141737065427)
            static /*ValueTask<T> *//*async*/  ServerExcuteInternal(T, TState, /*IServerRemoteService*/ server, /*DataFilter*/ filter, /*RemoteProxyExecutionContext?*/ context, /*TState*/ state, /*Func<TState, ValueTask<T>>*/ getPager)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T), T, async ($asnycContext) => 
                {
                    let $t13, $r13;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141737065427);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ValueTask<T?>*/ /*async*/  function TryGetFromCache()
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T), T, async ($asnycContext) => 
                        {
                            if ((context?.DataCache ?? null) !== null)
                            {
                                let $t3, $r3;
                                return $.$$.N.AsyncResolver.Result($asnycContext, ($t3 = $.$fPer.LCFCS$5.DataCacheStorageExtension.GetOrAdd(T, $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, TState, $.$$.S.Func$$$(TState, $.$$.STT.ValueTask$$(T)), $.$uvJL.LCFCR.RemoteProxyExecutionContext), context.DataCache, null, context.CacheKey, new ($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, TState, $.$$.S.Func$$$(TState, $.$$.STT.ValueTask$$(T)), $.$uvJL.LCFCR.RemoteProxyExecutionContext))().$ctor$3(server, state, getPager, context), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, TState, $.$$.S.Func$$$(TState, $.$$.STT.ValueTask$$(T)), $.$uvJL.LCFCR.RemoteProxyExecutionContext), $.$$.STT.ValueTask$$($.$fPer.LCFCD.DataCachePeriod$$(T))))().$ctor($.$uvJL.LCFCR.ServerRemoteServiceExtension, /*static*//*async*/  (/**/ state) =>
                                {
                                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.DataCachePeriod$$(T)), $.$fPer.LCFCD.DataCachePeriod$$(T), async ($asnycContext) => 
                                    {
                                        let $t4, $r4;
                                        let $t6, $r6;
                                        /*var*/ let data = (state.Item4.RunInBackground ?? false) ? ($t4 = $.$$.STT.Task.Run$5(T, new ($.$$.S.Func$$($.$$.STT.Task$$(T)))().$ctor(this, /*async*/  () =>
                                        {
                                            return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(T), T, async ($asnycContext) => 
                                            {
                                                let $t5, $r5;
                                                return ($t5 = state.Item3.Invoke(state.Item2).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                            });
                                        }, $bAQque ??= {"r":(T, TState) => $.$$.STT.Task$$(T).$h,"n":"","d":3144659,"h":0,"f":17829890})), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4))) : ($t6 = state.Item3.Invoke(state.Item2).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                        if (!(state.Item1 !== null && ($.$is(state.Item1, $.$uvJL.LCFCR.IClientServerRemoteService))))
                                        {
                                            data = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3(T, $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(T, data, true, false, true, false, false, false, false, "ServerExcuteInternal", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC\\ServerRemoteServiceExtension.cs", "ServerExcuteInternal", 74).Json, false, "ServerExcuteInternal", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC\\ServerRemoteServiceExtension.cs", "ServerExcuteInternal", 74);
                                        }
                                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                                        {
                                            //new $.$fPer.LCFCD.DataCachePeriod$$(T)()
                                            const $t7 = $.$fPer.LCFCD.DataCachePeriod$$(T);
                                            const $i7 = new $t7();
                                            $i7.$ctor$2();
                                            $i7.Data = data;
                                            $i7.Expiry = state.Item4.CachePeriod ?? $.$$.S.TimeSpan.FromMinutes$2(20n);
                                            return $i7;
                                        })());
                                    });
                                }, $IOkVrg ??= {"r":(T, TState) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.DataCachePeriod$$(T)).$h,"p":[{"n":"state","p":(T, TState) => $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, TState, $.$$.S.Func$$$(TState, $.$$.STT.ValueTask$$(T)), $.$uvJL.LCFCR.RemoteProxyExecutionContext).$h}],"n":"","d":3144659,"h":0,"f":17829922}), null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))));
                            }
                            else 
                            {
                                let $t8, $r8;
                                let $t10, $r10;
                                /*var*/ let data = ((context?.RunInBackground ?? null) ?? false) ? ($t8 = $.$$.STT.Task.Run$5(T, new ($.$$.S.Func$$($.$$.STT.Task$$(T)))().$ctor(this, /*async*/  () =>
                                {
                                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(T), T, async ($asnycContext) => 
                                    {
                                        let $t9, $r9;
                                        return ($t9 = getPager.Invoke(state).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                                    });
                                }, $hehxPa ??= {"r":(T, TState) => $.$$.STT.Task$$(T).$h,"n":"","d":3144659,"h":0,"f":17829890})), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8))) : ($t10 = getPager.Invoke(state).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                                if ((context?.CloneResponse ?? null) !== false && !(server !== null && ($.$is(server, $.$uvJL.LCFCR.IClientServerRemoteService))))
                                {
                                    data = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize(T, $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(T, data, true, false, true, false, false, false, false, "ServerExcuteInternal", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC\\ServerRemoteServiceExtension.cs", "ServerExcuteInternal", 94), false, "ServerExcuteInternal", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC\\ServerRemoteServiceExtension.cs", "ServerExcuteInternal", 94);
                                }
                                return $.$$.N.AsyncResolver.Result($asnycContext, data);
                            }
                        });
                    }
                    /*T?*/ let t = $.$default(T);
                    if ((context?.ServerCache ?? null) !== null)
                    {
                        let $t11, $r11;
                        t = ($t11 = context.ServerCache.LCFCS$5$ICacheProvider$GetOrCreate(T, (context?.CacheKey ?? null) ?? "_", new ($.$$.S.Func$$($.$$.STT.ValueTask$$(T)))().$ctor(this, TryGetFromCache, $hazHfd ??= {"r":(T, TState) => $.$$.STT.ValueTask$$(T).$h,"n":"TryGetFromCache","d":3144659,"h":0,"f":16781314})), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    }
                    else 
                    {
                        let $t12, $r12;
                        t = ($t12 = TryGetFromCache.call(this), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t13 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.RunInterceptors(T, filter, t), ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(141737065427)
            
            //--TRIMMABLE-BOUNDARY-START(133147130835)
            static /*Task<T> */ RunInBackground(T, /*Func<Task<T>>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133147130835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return workItem.Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(133147130835)
            
            //--TRIMMABLE-BOUNDARY-START(98787392467)
            static /*Loader<TDataModel> */ GetLoader(TDataModel, /*this IServerRemoteService*/ server, /*DataFilter*/ loadFilter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787392467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$fPer.LCFCD.Loader$$(TDataModel))().$ctor(this, /*async*/  (/*filter*/ filter) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.DataResult$$(TDataModel)), $.$fPer.LCFCD.DataResult$$(TDataModel), async ($asnycContext) => 
                    {
                        let service = null;
                        try
                        {
                            let $t14, $r14;
                            let $t15, $r15;
                            service = server.LCFCR$IServerRemoteService$GetRemoteService($.$fPer.LCFCD.IReadSingleDataService$$(TDataModel), null);
                            /*var*/ let t = ($t14 = service.LCFCS$3$IServiceProxy$$$Service[`LCFCD$IReadSingleDataService$${TDataModel.$getFullName('$')}$ReadSingle`](filter.OverrideWith(loadFilter), null).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                            t = ($t15 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.RunInterceptors($.$fPer.LCFCD.WireTransportModel$$(TDataModel), filter, $.$clone(t)), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                            if (!t.Success)
                            {
                                throw new $.$$.S.Exception().$ctor$4(t.Message);
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                            {
                                //new $.$fPer.LCFCD.DataResult$$(TDataModel)()
                                const $t16 = $.$fPer.LCFCD.DataResult$$(TDataModel);
                                const $i16 = new $t16();
                                $i16.$ctor$2();
                                $i16.Value = t.Data;
                                return $i16;
                            })());
                        }
                        finally
                        {
                            service?.S$IDisposable$Dispose();
                        }
                    });
                }, $bmVyOg ??= {"r":(TDataModel) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.DataResult$$(TDataModel)).$h,"p":[{"n":"filter","p":9734486}],"n":"","d":3144659,"h":0,"f":17829890});
            }
            //--TRIMMABLE-BOUNDARY-END(98787392467)
            
            //--TRIMMABLE-BOUNDARY-START(103082359763)
            static /*Pager<TDataModel> */ GetPager(TDataModel, /*this IServerRemoteService*/ server, /*DataFilter?*/ filter, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082359763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$fPer.LCFCD.Pager$$(TDataModel))().$ctor(this,  (/*_filter*/ _filter) =>
                {
                    /*var*/ let useFilter = $.$fPer.LCFCD.DataFilter.op_Inequality(filter, null) ? filter.OverrideWith(_filter) : _filter;
                    /*var*/ let key = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetCacheKey(TDataModel, useFilter, (options?.CacheKey ?? null));
                    return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ServerExcuteInternal($.$fPer.LCFCD.PagingDataResult$$(TDataModel), $.$$.S.ValueTuple$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), server, useFilter, $.$with((options ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                    {
                        $clone.CacheKey = key;
                    }), new ($.$$.S.ValueTuple$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext))().$ctor$3(server, useFilter, options), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel))))().$ctor($.$uvJL.LCFCR.ServerRemoteServiceExtension, /*static*//*async*/  (/*state*/ state) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel)), $.$fPer.LCFCD.PagingDataResult$$(TDataModel), async ($asnycContext) => 
                        {
                            let service = null;
                            try
                            {
                                let $t17, $r17;
                                let $t18, $r18;
                                service = state.Item1.LCFCR$IServerRemoteService$GetRemoteService($.$fPer.LCFCD.IReadManyDataService$$(TDataModel), state.Item3);
                                /*var*/ let t = ($t17 = service.LCFCS$3$IServiceProxy$$$Service[`LCFCD$IReadManyDataService$${TDataModel.$getFullName('$')}$ReadMany`](state.Item2, null).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t17, { set $v($v) { $r17 = $v; } }) ? $r17 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t17)));
                                t = ($t18 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.RunInterceptors($.$fPer.LCFCD.WireTransportManyModel$$(TDataModel), state.Item2, $.$clone(t)), ($.$$.N.AsyncResolver.IsCompleted($t18, { set $v($v) { $r18 = $v; } }) ? $r18 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t18)));
                                return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCD.WireTransportManyModel$$(TDataModel).op_Implicit(t));
                            }
                            finally
                            {
                                service?.S$IDisposable$Dispose();
                            }
                        });
                    }, $Rhlmjc ??= {"r":(TDataModel) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel)).$h,"p":[{"n":"state","p":$.$$.S.ValueTuple$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext).$h}],"n":"","d":3144659,"h":0,"f":17829922}));
                }, $CxNxei ??= {"r":(TDataModel) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel)).$h,"p":[{"n":"_filter","p":9734486}],"n":"","d":3144659,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(103082359763)
            
            //--TRIMMABLE-BOUNDARY-START(107377327059)
            static /*Pager<TDataModel> */ GetPager$1(TDataModel, /*this IServerRemoteService*/ server, /*Func<Task<DataFilter>>*/ getFilter, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377327059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$fPer.LCFCD.Pager$$(TDataModel))().$ctor(this, /*async*/  (/*_filter*/ _filter) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel)), $.$fPer.LCFCD.PagingDataResult$$(TDataModel), async ($asnycContext) => 
                    {
                        let $t19, $r19;
                        let $t20, $r20;
                        /*var*/ let useFilter = getFilter !== null ? (($t19 = getFilter.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)))).OverrideWith(_filter) : _filter;
                        /*var*/ let key = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetCacheKey(TDataModel, useFilter, (options?.CacheKey ?? null));
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t20 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ServerExcuteInternal($.$fPer.LCFCD.PagingDataResult$$(TDataModel), $.$$.S.ValueTuple$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), server, useFilter, $.$with((options ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                        {
                            $clone.CacheKey = key;
                        }), new ($.$$.S.ValueTuple$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext))().$ctor$3(server, useFilter, options), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel))))().$ctor($.$uvJL.LCFCR.ServerRemoteServiceExtension, /*static*//*async*/  (/**/ state) =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel)), $.$fPer.LCFCD.PagingDataResult$$(TDataModel), async ($asnycContext) => 
                            {
                                let service = null;
                                try
                                {
                                    let $t21, $r21;
                                    let $t22, $r22;
                                    service = state.Item1.LCFCR$IServerRemoteService$GetRemoteService($.$fPer.LCFCD.IReadManyDataService$$(TDataModel), state.Item3);
                                    /*var*/ let t = ($t21 = service.LCFCS$3$IServiceProxy$$$Service[`LCFCD$IReadManyDataService$${TDataModel.$getFullName('$')}$ReadMany`](state.Item2, null).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                                    t = ($t22 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.RunInterceptors($.$fPer.LCFCD.WireTransportManyModel$$(TDataModel), state.Item2, $.$clone(t)), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)));
                                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCD.WireTransportManyModel$$(TDataModel).op_Implicit(t));
                                }
                                finally
                                {
                                    service?.S$IDisposable$Dispose();
                                }
                            });
                        }, $VtGWcg ??= {"r":(TDataModel) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel)).$h,"p":[{"n":"state","p":$.$$.S.ValueTuple$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext).$h}],"n":"","d":3144659,"h":0,"f":17829922})), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20))));
                    });
                }, $efiqpa ??= {"r":(TDataModel) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel)).$h,"p":[{"n":"_filter","p":9734486}],"n":"","d":3144659,"h":0,"f":17829890});
            }
            //--TRIMMABLE-BOUNDARY-END(107377327059)
            
            //--TRIMMABLE-BOUNDARY-START(111672294355)
            static /*Pager<TDataModel> */ GetPager$2(TService, TDataModel, /*this IServerRemoteService*/ server, /*ServicePagerMethod<TService, TDataModel>*/ reader, /*DataFilter?*/ filter, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111672294355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$fPer.LCFCD.Pager$$(TDataModel))().$ctor(this,  (/**/ _filter) =>
                {
                    /*var*/ let useFilter = $.$fPer.LCFCD.DataFilter.op_Inequality(filter, null) ? filter.OverrideWith(_filter) : _filter;
                    /*var*/ let key = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetCacheKey(TDataModel, useFilter, (options?.CacheKey ?? null));
                    return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ServerExcuteInternal($.$fPer.LCFCD.PagingDataResult$$(TDataModel), $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServicePagerMethod$$$(TService, TDataModel), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), server, useFilter, $.$with((options ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                    {
                        $clone.CacheKey = key;
                    }), new ($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServicePagerMethod$$$(TService, TDataModel), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext))().$ctor$3(server, reader, useFilter, options), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServicePagerMethod$$$(TService, TDataModel), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel))))().$ctor($.$uvJL.LCFCR.ServerRemoteServiceExtension, /*static*//*async*/  (/*state*/ state) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel)), $.$fPer.LCFCD.PagingDataResult$$(TDataModel), async ($asnycContext) => 
                        {
                            let service = null;
                            try
                            {
                                let $t23, $r23;
                                let $t24, $r24;
                                service = state.Item1.LCFCR$IServerRemoteService$GetRemoteService(TService, state.Item4);
                                /*var*/ let t = ($t23 = state.Item2.Invoke(service.LCFCS$3$IServiceProxy$$$Service, state.Item3).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                                t = ($t24 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.RunInterceptors($.$fPer.LCFCD.WireTransportManyModel$$(TDataModel), state.Item3, $.$clone(t)), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)));
                                return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCD.WireTransportManyModel$$(TDataModel).op_Implicit(t));
                            }
                            finally
                            {
                                service?.S$IDisposable$Dispose();
                            }
                        });
                    }, $eqpCca ??= {"r":(TService, TDataModel) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel)).$h,"p":[{"n":"state","p":(TService, TDataModel) => $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServicePagerMethod$$$(TService, TDataModel), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext).$h}],"n":"","d":3144659,"h":0,"f":17829922}));
                }, $tIvgSd ??= {"r":(TService, TDataModel) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$(TDataModel)).$h,"p":[{"n":"_filter","p":9734486}],"n":"","d":3144659,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(111672294355)
            
            //--TRIMMABLE-BOUNDARY-START(158916934611)
            static /*IFilteringServerRemoteService */ WithFilter(/*this IServerRemoteService*/ server, /*DataFilter*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916934611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$uvJL.LCFCR.FilteringServerRemoteService().$ctor$1(server, filter);
            }
            //--TRIMMABLE-BOUNDARY-END(158916934611)
            
            //--TRIMMABLE-BOUNDARY-START(115967261651)
            static /*IServiceProxy<TService> */ GetRemoteService(TService, /*IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115967261651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let service = server.LCFCR$IServerRemoteService$GetRemoteService(TService, options);
                return service;
            }
            //--TRIMMABLE-BOUNDARY-END(115967261651)
            
            //--TRIMMABLE-BOUNDARY-START(73017588691)
            static /*ValueTask<TData?> */ Execute(TService, TData, /*this IServerRemoteService*/ server, /*ServiceModelMethod<TService, IWireTransportModel<TData>>*/ reader, /*DataFilter?*/ filter, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017588691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                filter = filter ?? new $.$fPer.LCFCD.DataFilter().$ctor$1();
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ServerExcuteInternal(TData, $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.RemoteProxyExecutionContext, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.IWireTransportModel$$(TData)), $.$fPer.LCFCD.DataFilter), server, filter, options, new ($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.RemoteProxyExecutionContext, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.IWireTransportModel$$(TData)), $.$fPer.LCFCD.DataFilter))().$ctor$3(server, options, reader, filter), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.RemoteProxyExecutionContext, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.IWireTransportModel$$(TData)), $.$fPer.LCFCD.DataFilter), $.$$.STT.ValueTask$$(TData)))().$ctor($.$uvJL.LCFCR.ServerRemoteServiceExtension, /*static*//*async*/  (/*state*/ state) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(TData), TData, async ($asnycContext) => 
                    {
                        let service = null;
                        try
                        {
                            let $t25, $r25;
                            let $t26, $r26;
                            service = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetRemoteService(TService, state.Item1, state.Item2);
                            /*var*/ let result = ($t25 = state.Item3.Invoke(service.LCFCS$3$IServiceProxy$$$Service).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t25, { set $v($v) { $r25 = $v; } }) ? $r25 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t25)));
                            result = ($t26 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.RunInterceptors($.$fPer.LCFCD.IWireTransportModel$$(TData), state.Item4, result), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                            if (result.LCFCD$IWireTransportModel$Success)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, result.LCFCD$IWireTransportModel$$$Data);
                            }
                            throw new $.$$.S.Exception().$ctor$4(result.LCFCD$IWireTransportModel$Message);
                        }
                        finally
                        {
                            service?.S$IDisposable$Dispose();
                        }
                    });
                }, $yFkuQe ??= {"r":(TService, TData) => $.$$.STT.ValueTask$$(TData).$h,"p":[{"n":"state","p":(TService, TData) => $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.RemoteProxyExecutionContext, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.IWireTransportModel$$(TData)), $.$fPer.LCFCD.DataFilter).$h}],"n":"","d":3144659,"h":0,"f":17829922}));
            }
            //--TRIMMABLE-BOUNDARY-END(73017588691)
            
            //--TRIMMABLE-BOUNDARY-START(81607523283)
            static /*ValueTask<TData> */ Execute$2(TService, TData, /*this IServerRemoteService*/ server, /*ServiceModelMethod<TService, WireTransportModel<TData>>*/ reader, /*DataFilter?*/ filter, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607523283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                filter = filter ?? new $.$fPer.LCFCD.DataFilter().$ctor$1();
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ServerExcuteInternal(TData, $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportModel$$(TData)), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), server, filter, $.$with((options ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                {
                    $clone.CacheKey = $.$uvJL.LCFCR.ServerRemoteServiceExtension.CacheKeyFor$1(TService, TData, (options?.CacheKey ?? null));
                }), new ($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportModel$$(TData)), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext))().$ctor$3(server, reader, filter, options), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportModel$$(TData)), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), $.$$.STT.ValueTask$$(TData)))().$ctor($.$uvJL.LCFCR.ServerRemoteServiceExtension, /*static*//*async*/  (/*state*/ state) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(TData), TData, async ($asnycContext) => 
                    {
                        let service = null;
                        try
                        {
                            let $t27, $r27;
                            let $t28, $r28;
                            service = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetRemoteService(TService, state.Item1, state.Item4);
                            /*var*/ let result = ($t27 = state.Item2.Invoke(service.LCFCS$3$IServiceProxy$$$Service).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27)));
                            result = ($t28 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.RunInterceptors($.$fPer.LCFCD.WireTransportModel$$(TData), state.Item3, $.$clone(result)), ($.$$.N.AsyncResolver.IsCompleted($t28, { set $v($v) { $r28 = $v; } }) ? $r28 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t28)));
                            if (result.Success)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, result.Data);
                            }
                            throw new $.$$.S.Exception().$ctor$4(result.Message);
                        }
                        finally
                        {
                            service?.S$IDisposable$Dispose();
                        }
                    });
                }, $SvlzLi ??= {"r":(TService, TData) => $.$$.STT.ValueTask$$(TData).$h,"p":[{"n":"state","p":(TService, TData) => $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportModel$$(TData)), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext).$h}],"n":"","d":3144659,"h":0,"f":17829922}));
            }
            //--TRIMMABLE-BOUNDARY-END(81607523283)
            
            //--TRIMMABLE-BOUNDARY-START(77312555987)
            static /*ValueTask<WireTransportManyModel<TData>> */ Execute$1(TService, TData, /*this IServerRemoteService*/ server, /*ServiceModelMethod<TService, WireTransportManyModel<TData>>*/ reader, /*DataFilter?*/ filter, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312555987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                filter = filter ?? new $.$fPer.LCFCD.DataFilter().$ctor$1();
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ServerExcuteInternal($.$fPer.LCFCD.WireTransportManyModel$$(TData), $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportManyModel$$(TData)), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), server, filter, $.$with((options ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                {
                    $clone.CacheKey = $.$uvJL.LCFCR.ServerRemoteServiceExtension.CacheKeyFor$1(TService, TData, (options?.CacheKey ?? null));
                }), new ($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportManyModel$$(TData)), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext))().$ctor$3(server, reader, filter, options), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportManyModel$$(TData)), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(TData))))().$ctor($.$uvJL.LCFCR.ServerRemoteServiceExtension, /*static*//*async*/  (/*state*/ state) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(TData)), $.$fPer.LCFCD.WireTransportManyModel$$(TData), async ($asnycContext) => 
                    {
                        let service = null;
                        try
                        {
                            let $t29, $r29;
                            let $t30, $r30;
                            service = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetRemoteService(TService, state.Item1, state.Item4);
                            /*var*/ let result = ($t29 = state.Item2.Invoke(service.LCFCS$3$IServiceProxy$$$Service).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t29, { set $v($v) { $r29 = $v; } }) ? $r29 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t29)));
                            result = ($t30 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.RunInterceptors($.$fPer.LCFCD.WireTransportManyModel$$(TData), state.Item3, $.$clone(result)), ($.$$.N.AsyncResolver.IsCompleted($t30, { set $v($v) { $r30 = $v; } }) ? $r30 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t30)));
                            if (result.Success)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, result);
                            }
                            throw new $.$$.S.Exception().$ctor$4(result.Message ?? "Unknown Error");
                        }
                        finally
                        {
                            service?.S$IDisposable$Dispose();
                        }
                    });
                }, $ENwXOi ??= {"r":(TService, TData) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(TData)).$h,"p":[{"n":"state","p":(TService, TData) => $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportManyModel$$(TData)), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext).$h}],"n":"","d":3144659,"h":0,"f":17829922}));
            }
            //--TRIMMABLE-BOUNDARY-END(77312555987)
            
            //--TRIMMABLE-BOUNDARY-START(90197457875)
            static /*ValueTask<object?> */ Execute$4(TService, /*this IServerRemoteService*/ server, /*ServiceModelMethod<TService, WireTransportModel>*/ reader, /*DataFilter?*/ filter, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197457875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                filter = filter ?? new $.$fPer.LCFCD.DataFilter().$ctor$1();
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ServerExcuteInternal($.$$.S.Object, $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportModel), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), server, filter, $.$with((options ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                {
                    $clone.CacheKey = $.$uvJL.LCFCR.ServerRemoteServiceExtension.CacheKeyFor(TService, (options?.CacheKey ?? null));
                }), new ($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportModel), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext))().$ctor$3(server, reader, filter, options), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportModel), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), $.$$.STT.ValueTask$$($.$$.S.Object)))().$ctor($.$uvJL.LCFCR.ServerRemoteServiceExtension, /*static*//*async*/  (/*state*/ state) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                    {
                        let service = null;
                        try
                        {
                            let $t31, $r31;
                            let $t32, $r32;
                            service = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetRemoteService(TService, state.Item1, state.Item4);
                            /*var*/ let result = ($t31 = state.Item2.Invoke(service.LCFCS$3$IServiceProxy$$$Service).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t31, { set $v($v) { $r31 = $v; } }) ? $r31 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t31)));
                            result = ($t32 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.RunInterceptors($.$fPer.LCFCD.WireTransportModel, state.Item3, $.$clone(result)), ($.$$.N.AsyncResolver.IsCompleted($t32, { set $v($v) { $r32 = $v; } }) ? $r32 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t32)));
                            if (result.Success)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, result.Data);
                            }
                            throw new $.$$.S.Exception().$ctor$4(result.Message);
                        }
                        finally
                        {
                            service?.S$IDisposable$Dispose();
                        }
                    });
                }, $ertbgh ??= {"r":$.$$.STT.ValueTask$$($.$$.S.Object).$h,"p":[{"n":"state","p":(TService) => $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportModel), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext).$h}],"n":"","d":3144659,"h":0,"f":17829922}));
            }
            //--TRIMMABLE-BOUNDARY-END(90197457875)
            
            //--TRIMMABLE-BOUNDARY-START(85902490579)
            static /*ValueTask<object?> */ Execute$3(TService, /*this IServerRemoteService*/ server, /*ServiceMethod<TService>*/ reader, /*DataFilter?*/ filter, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902490579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                filter = filter ?? new $.$fPer.LCFCD.DataFilter().$ctor$1();
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ServerExcuteInternal($.$$.S.Object, $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceMethod$$(TService), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), server, filter, $.$with((options ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                {
                    $clone.CacheKey = $.$uvJL.LCFCR.ServerRemoteServiceExtension.CacheKeyFor(TService, (options?.CacheKey ?? null));
                }), new ($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceMethod$$(TService), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext))().$ctor$3(server, reader, filter, options), new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceMethod$$(TService), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext), $.$$.STT.ValueTask$$($.$$.S.Object)))().$ctor($.$uvJL.LCFCR.ServerRemoteServiceExtension, /*static*//*async*/  (/**/ state) =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                    {
                        let service = null;
                        try
                        {
                            let $t33, $r33;
                            service = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetRemoteService(TService, state.Item1, state.Item4);
                            ($t33 = state.Item2.Invoke(service.LCFCS$3$IServiceProxy$$$Service).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t33, { set $v($v) { $r33 = $v; } }) ? $r33 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t33)));
                            return $.$$.N.AsyncResolver.Result($asnycContext, null);
                        }
                        finally
                        {
                            service?.S$IDisposable$Dispose();
                        }
                    });
                }, $kLdrIc ??= {"r":$.$$.STT.ValueTask$$($.$$.S.Object).$h,"p":[{"n":"state","p":(TService) => $.$$.S.ValueTuple$$$$$($.$uvJL.LCFCR.IServerRemoteService, $.$uvJL.LCFCR.ServiceMethod$$(TService), $.$fPer.LCFCD.DataFilter, $.$uvJL.LCFCR.RemoteProxyExecutionContext).$h}],"n":"","d":3144659,"h":0,"f":17829922}));
            }
            //--TRIMMABLE-BOUNDARY-END(85902490579)
            
            //--TRIMMABLE-BOUNDARY-START(120262228947)
            static /*void */ NOP(/*this IServerRemoteService*/ server)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262228947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let batchServer;
                if ($.$is(server, $.$uvJL.LCFCR.IBatchClientServerRemoteService, { set $v($v){ batchServer = $v; } }))
                {
                    batchServer.LCFCR$IBatchClientServerRemoteService$NOP(-1);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120262228947)
            
            //--TRIMMABLE-BOUNDARY-START(4298111955)
            static /*ValueTask<IEnumerable<Task<object?>>> *//*async*/  BatchExecute(/*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*params Func<IServerRemoteService, Task<object?>>[]*/ executors)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.STT.Task$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.STT.Task$$($.$$.S.Object)), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298111955);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    context ??= new $.$uvJL.LCFCR.RemoteProxyExecutionContext().$ctor$1();
                    let clientServer;
                    if ($.$is(server, $.$uvJL.LCFCR.IClientServerRemoteService, { set $v($v){ clientServer = $v; } }))
                    {
                        let $t35, $r35;
                        context.RunInBackground = false;
                        /*var*/ let clientBatchServer = clientServer.LCFCR$IClientServerRemoteService$GetBatchService(executors.length);
                        /*List<Task<object?>>*/ let tasks = new ($.$$.SCG.List$$($.$$.STT.Task$$($.$$.S.Object)))().$ctor$1();
                        /*int*/ let i = 0;
                        let $i34 = 0;
                        let $arr34 = executors;
                        while ($i34 < $arr34.length)
                        {
                            let executor = $arr34[$i34++];
                            /*var*/ let task = executor.Invoke(new $.$uvJL.LCFCR.BatchItemClientServerRemoteService().$ctor$1(clientBatchServer, i));
                            tasks.Add(task);
                            i++;
                        }
                        ($t35 = clientBatchServer.LCFCR$IBatchClientServerRemoteService$Commit((() =>
                        {
                            //new $.$uvJL.LCFCR.RemoteProxyExecutionContext()
                            const $t36 = $.$uvJL.LCFCR.RemoteProxyExecutionContext;
                            const $i36 = new $t36();
                            $i36.$ctor$1();
                            $i36.TimeOut = context.TimeOut;
                            $i36.Authenticate = context.Authenticate;
                            $i36.Retries = context.Retries;
                            $i36.Batching = true;
                            return $i36;
                        })()), ($.$$.N.AsyncResolver.IsCompleted($t35, { set $v($v) { $r35 = $v; } }) ? $r35 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t35)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, tasks);
                    }
                    else 
                    {
                        let $t38, $r38;
                        /*List<Task<object?>>*/ let tasks = new ($.$$.SCG.List$$($.$$.STT.Task$$($.$$.S.Object)))().$ctor$1();
                        let $i37 = 0;
                        let $arr37 = executors;
                        while ($i37 < $arr37.length)
                        {
                            let executor = $arr37[$i37++];
                            tasks.Add(executor.Invoke(server));
                        }
                        ($t38 = $.$$.STT.Task.WhenAll$3($.$$.S.Object, tasks), ($.$$.N.AsyncResolver.IsCompleted($t38, { set $v($v) { $r38 = $v; } }) ? $r38 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t38)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, tasks);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4298111955)
            
            //--TRIMMABLE-BOUNDARY-START(47247784915)
            static /*ValueTask<T1> *//*async*/  BatchExecuteT$9(T1, /*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*Func<IServerRemoteService, ValueTask<T1>>*/ executor1)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T1), T1, async ($asnycContext) => 
                {
                    let $t39, $r39;
                    let $t41, $r41;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47247784915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let results = ($t39 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.BatchExecute(server, context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))), [ new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t40, $r40;
                            return $.$box(($t40 = executor1.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t40, { set $v($v) { $r40 = $v; } }) ? $r40 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t40))), T1);
                        });
                    }, $LqpuKe ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t39, { set $v($v) { $r39 = $v; } }) ? $r39 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t39)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$cast((($t41 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 0), ($.$$.N.AsyncResolver.IsCompleted($t41, { set $v($v) { $r41 = $v; } }) ? $r41 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t41)))), T1));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47247784915)
            
            //--TRIMMABLE-BOUNDARY-START(42952817619)
            static /*ValueTask<(T1, T2)> *//*async*/  BatchExecuteT$8(T1, T2, /*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*Func<IServerRemoteService, ValueTask<T1>>*/ executor1, /*Func<IServerRemoteService, ValueTask<T2>>*/ executor2)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$(T1, T2)), $.$$.S.ValueTuple$$$(T1, T2), async ($asnycContext) => 
                {
                    let $t42, $r42;
                    let $t45, $r45;
                    let $t46, $r46;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952817619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let results = ($t42 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.BatchExecute(server, context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))), [ new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t43, $r43;
                            return $.$box(($t43 = executor1.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t43, { set $v($v) { $r43 = $v; } }) ? $r43 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t43))), T1);
                        });
                    }, $UFdkFf ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t44, $r44;
                            return $.$box(($t44 = executor2.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t44, { set $v($v) { $r44 = $v; } }) ? $r44 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t44))), T2);
                        });
                    }, $YrrQlg ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t42, { set $v($v) { $r42 = $v; } }) ? $r42 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t42)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$(T1, T2))().$ctor$3($.$cast((($t45 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 0), ($.$$.N.AsyncResolver.IsCompleted($t45, { set $v($v) { $r45 = $v; } }) ? $r45 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t45)))), T1), $.$cast((($t46 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 1), ($.$$.N.AsyncResolver.IsCompleted($t46, { set $v($v) { $r46 = $v; } }) ? $r46 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t46)))), T2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42952817619)
            
            //--TRIMMABLE-BOUNDARY-START(38657850323)
            static /*ValueTask<(T1, T2, T3)> *//*async*/  BatchExecuteT$7(T1, T2, T3, /*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*Func<IServerRemoteService, ValueTask<T1>>*/ executor1, /*Func<IServerRemoteService, ValueTask<T2>>*/ executor2, /*Func<IServerRemoteService, ValueTask<T3>>*/ executor3)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$(T1, T2, T3)), $.$$.S.ValueTuple$$$$(T1, T2, T3), async ($asnycContext) => 
                {
                    let $t47, $r47;
                    let $t51, $r51;
                    let $t52, $r52;
                    let $t53, $r53;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657850323);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let results = ($t47 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.BatchExecute(server, context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))), [ new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t48, $r48;
                            return $.$box(($t48 = executor1.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t48, { set $v($v) { $r48 = $v; } }) ? $r48 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t48))), T1);
                        });
                    }, $jOPuoc ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t49, $r49;
                            return $.$box(($t49 = executor2.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t49, { set $v($v) { $r49 = $v; } }) ? $r49 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t49))), T2);
                        });
                    }, $WbIFvg ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t50, $r50;
                            return $.$box(($t50 = executor3.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t50, { set $v($v) { $r50 = $v; } }) ? $r50 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t50))), T3);
                        });
                    }, $foXzba ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t47, { set $v($v) { $r47 = $v; } }) ? $r47 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t47)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$$(T1, T2, T3))().$ctor$3($.$cast((($t51 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 0), ($.$$.N.AsyncResolver.IsCompleted($t51, { set $v($v) { $r51 = $v; } }) ? $r51 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t51)))), T1), $.$cast((($t52 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 1), ($.$$.N.AsyncResolver.IsCompleted($t52, { set $v($v) { $r52 = $v; } }) ? $r52 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t52)))), T2), $.$cast((($t53 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 2), ($.$$.N.AsyncResolver.IsCompleted($t53, { set $v($v) { $r53 = $v; } }) ? $r53 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t53)))), T3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38657850323)
            
            //--TRIMMABLE-BOUNDARY-START(34362883027)
            static /*ValueTask<(T1, T2, T3, T4)> *//*async*/  BatchExecuteT$6(T1, T2, T3, T4, /*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*Func<IServerRemoteService, ValueTask<T1>>*/ executor1, /*Func<IServerRemoteService, ValueTask<T2>>*/ executor2, /*Func<IServerRemoteService, ValueTask<T3>>*/ executor3, /*Func<IServerRemoteService, ValueTask<T4>>*/ executor4)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$(T1, T2, T3, T4)), $.$$.S.ValueTuple$$$$$(T1, T2, T3, T4), async ($asnycContext) => 
                {
                    let $t54, $r54;
                    let $t59, $r59;
                    let $t60, $r60;
                    let $t61, $r61;
                    let $t62, $r62;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362883027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let results = ($t54 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.BatchExecute(server, context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))), [ new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t55, $r55;
                            return $.$box(($t55 = executor1.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t55, { set $v($v) { $r55 = $v; } }) ? $r55 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t55))), T1);
                        });
                    }, $rhvqnb ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t56, $r56;
                            return $.$box(($t56 = executor2.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t56, { set $v($v) { $r56 = $v; } }) ? $r56 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t56))), T2);
                        });
                    }, $BLCLag ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t57, $r57;
                            return $.$box(($t57 = executor3.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t57, { set $v($v) { $r57 = $v; } }) ? $r57 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t57))), T3);
                        });
                    }, $PeAVhi ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t58, $r58;
                            return $.$box(($t58 = executor4.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t58, { set $v($v) { $r58 = $v; } }) ? $r58 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t58))), T4);
                        });
                    }, $VYVFnj ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t54, { set $v($v) { $r54 = $v; } }) ? $r54 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t54)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$$$(T1, T2, T3, T4))().$ctor$3($.$cast((($t59 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 0), ($.$$.N.AsyncResolver.IsCompleted($t59, { set $v($v) { $r59 = $v; } }) ? $r59 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t59)))), T1), $.$cast((($t60 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 1), ($.$$.N.AsyncResolver.IsCompleted($t60, { set $v($v) { $r60 = $v; } }) ? $r60 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t60)))), T2), $.$cast((($t61 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 2), ($.$$.N.AsyncResolver.IsCompleted($t61, { set $v($v) { $r61 = $v; } }) ? $r61 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t61)))), T3), $.$cast((($t62 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 3), ($.$$.N.AsyncResolver.IsCompleted($t62, { set $v($v) { $r62 = $v; } }) ? $r62 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t62)))), T4)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34362883027)
            
            //--TRIMMABLE-BOUNDARY-START(30067915731)
            static /*ValueTask<(T1, T2, T3, T4, T5)> *//*async*/  BatchExecuteT$5(T1, T2, T3, T4, T5, /*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*Func<IServerRemoteService, ValueTask<T1>>*/ executor1, /*Func<IServerRemoteService, ValueTask<T2>>*/ executor2, /*Func<IServerRemoteService, ValueTask<T3>>*/ executor3, /*Func<IServerRemoteService, ValueTask<T4>>*/ executor4, /*Func<IServerRemoteService, ValueTask<T5>>*/ executor5)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$(T1, T2, T3, T4, T5)), $.$$.S.ValueTuple$$$$$$(T1, T2, T3, T4, T5), async ($asnycContext) => 
                {
                    let $t63, $r63;
                    let $t69, $r69;
                    let $t70, $r70;
                    let $t71, $r71;
                    let $t72, $r72;
                    let $t73, $r73;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067915731);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let results = ($t63 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.BatchExecute(server, context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))), [ new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t64, $r64;
                            return $.$box(($t64 = executor1.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t64, { set $v($v) { $r64 = $v; } }) ? $r64 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t64))), T1);
                        });
                    }, $cOmWHb ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t65, $r65;
                            return $.$box(($t65 = executor2.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t65, { set $v($v) { $r65 = $v; } }) ? $r65 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t65))), T2);
                        });
                    }, $YUODnc ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t66, $r66;
                            return $.$box(($t66 = executor3.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t66, { set $v($v) { $r66 = $v; } }) ? $r66 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t66))), T3);
                        });
                    }, $QeaZQj ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t67, $r67;
                            return $.$box(($t67 = executor4.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t67, { set $v($v) { $r67 = $v; } }) ? $r67 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t67))), T4);
                        });
                    }, $vOYDkl ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t68, $r68;
                            return $.$box(($t68 = executor5.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t68, { set $v($v) { $r68 = $v; } }) ? $r68 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t68))), T5);
                        });
                    }, $dtzHjd ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t63, { set $v($v) { $r63 = $v; } }) ? $r63 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t63)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$$$$(T1, T2, T3, T4, T5))().$ctor$3($.$cast((($t69 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 0), ($.$$.N.AsyncResolver.IsCompleted($t69, { set $v($v) { $r69 = $v; } }) ? $r69 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t69)))), T1), $.$cast((($t70 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 1), ($.$$.N.AsyncResolver.IsCompleted($t70, { set $v($v) { $r70 = $v; } }) ? $r70 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t70)))), T2), $.$cast((($t71 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 2), ($.$$.N.AsyncResolver.IsCompleted($t71, { set $v($v) { $r71 = $v; } }) ? $r71 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t71)))), T3), $.$cast((($t72 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 3), ($.$$.N.AsyncResolver.IsCompleted($t72, { set $v($v) { $r72 = $v; } }) ? $r72 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t72)))), T4), $.$cast((($t73 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 4), ($.$$.N.AsyncResolver.IsCompleted($t73, { set $v($v) { $r73 = $v; } }) ? $r73 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t73)))), T5)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30067915731)
            
            //--TRIMMABLE-BOUNDARY-START(25772948435)
            static /*ValueTask<(T1, T2, T3, T4, T5, T6)> *//*async*/  BatchExecuteT$4(T1, T2, T3, T4, T5, T6, /*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*Func<IServerRemoteService, ValueTask<T1>>*/ executor1, /*Func<IServerRemoteService, ValueTask<T2>>*/ executor2, /*Func<IServerRemoteService, ValueTask<T3>>*/ executor3, /*Func<IServerRemoteService, ValueTask<T4>>*/ executor4, /*Func<IServerRemoteService, ValueTask<T5>>*/ executor5, /*Func<IServerRemoteService, ValueTask<T6>>*/ executor6)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$$(T1, T2, T3, T4, T5, T6)), $.$$.S.ValueTuple$$$$$$$(T1, T2, T3, T4, T5, T6), async ($asnycContext) => 
                {
                    let $t74, $r74;
                    let $t81, $r81;
                    let $t82, $r82;
                    let $t83, $r83;
                    let $t84, $r84;
                    let $t85, $r85;
                    let $t86, $r86;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772948435);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let results = ($t74 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.BatchExecute(server, context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))), [ new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t75, $r75;
                            return $.$box(($t75 = executor1.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t75, { set $v($v) { $r75 = $v; } }) ? $r75 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t75))), T1);
                        });
                    }, $zxncYh ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t76, $r76;
                            return $.$box(($t76 = executor2.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t76, { set $v($v) { $r76 = $v; } }) ? $r76 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t76))), T2);
                        });
                    }, $EZlwwc ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t77, $r77;
                            return $.$box(($t77 = executor3.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t77, { set $v($v) { $r77 = $v; } }) ? $r77 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t77))), T3);
                        });
                    }, $GGlUEd ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t78, $r78;
                            return $.$box(($t78 = executor4.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t78, { set $v($v) { $r78 = $v; } }) ? $r78 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t78))), T4);
                        });
                    }, $grvAZj ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t79, $r79;
                            return $.$box(($t79 = executor5.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t79, { set $v($v) { $r79 = $v; } }) ? $r79 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t79))), T5);
                        });
                    }, $cCzTUd ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t80, $r80;
                            return $.$box(($t80 = executor6.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t80, { set $v($v) { $r80 = $v; } }) ? $r80 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t80))), T6);
                        });
                    }, $sDIWPh ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t74, { set $v($v) { $r74 = $v; } }) ? $r74 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t74)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$$$$$(T1, T2, T3, T4, T5, T6))().$ctor$3($.$cast((($t81 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 0), ($.$$.N.AsyncResolver.IsCompleted($t81, { set $v($v) { $r81 = $v; } }) ? $r81 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t81)))), T1), $.$cast((($t82 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 1), ($.$$.N.AsyncResolver.IsCompleted($t82, { set $v($v) { $r82 = $v; } }) ? $r82 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t82)))), T2), $.$cast((($t83 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 2), ($.$$.N.AsyncResolver.IsCompleted($t83, { set $v($v) { $r83 = $v; } }) ? $r83 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t83)))), T3), $.$cast((($t84 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 3), ($.$$.N.AsyncResolver.IsCompleted($t84, { set $v($v) { $r84 = $v; } }) ? $r84 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t84)))), T4), $.$cast((($t85 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 4), ($.$$.N.AsyncResolver.IsCompleted($t85, { set $v($v) { $r85 = $v; } }) ? $r85 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t85)))), T5), $.$cast((($t86 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 5), ($.$$.N.AsyncResolver.IsCompleted($t86, { set $v($v) { $r86 = $v; } }) ? $r86 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t86)))), T6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25772948435)
            
            //--TRIMMABLE-BOUNDARY-START(21477981139)
            static /*ValueTask<(T1, T2, T3, T4, T5, T6, T7)> *//*async*/  BatchExecuteT$3(T1, T2, T3, T4, T5, T6, T7, /*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*Func<IServerRemoteService, ValueTask<T1>>*/ executor1, /*Func<IServerRemoteService, ValueTask<T2>>*/ executor2, /*Func<IServerRemoteService, ValueTask<T3>>*/ executor3, /*Func<IServerRemoteService, ValueTask<T4>>*/ executor4, /*Func<IServerRemoteService, ValueTask<T5>>*/ executor5, /*Func<IServerRemoteService, ValueTask<T6>>*/ executor6, /*Func<IServerRemoteService, ValueTask<T7>>*/ executor7)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$$$(T1, T2, T3, T4, T5, T6, T7)), $.$$.S.ValueTuple$$$$$$$$(T1, T2, T3, T4, T5, T6, T7), async ($asnycContext) => 
                {
                    let $t87, $r87;
                    let $t95, $r95;
                    let $t96, $r96;
                    let $t97, $r97;
                    let $t98, $r98;
                    let $t99, $r99;
                    let $t100, $r100;
                    let $t101, $r101;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477981139);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let results = ($t87 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.BatchExecute(server, context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))), [ new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t88, $r88;
                            return $.$box(($t88 = executor1.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t88, { set $v($v) { $r88 = $v; } }) ? $r88 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t88))), T1);
                        });
                    }, $CgJEHi ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t89, $r89;
                            return $.$box(($t89 = executor2.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t89, { set $v($v) { $r89 = $v; } }) ? $r89 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t89))), T2);
                        });
                    }, $aGspfd ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t90, $r90;
                            return $.$box(($t90 = executor3.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t90, { set $v($v) { $r90 = $v; } }) ? $r90 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t90))), T3);
                        });
                    }, $gQXSEb ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t91, $r91;
                            return $.$box(($t91 = executor4.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t91, { set $v($v) { $r91 = $v; } }) ? $r91 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t91))), T4);
                        });
                    }, $WdbCHa ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t92, $r92;
                            return $.$box(($t92 = executor5.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t92, { set $v($v) { $r92 = $v; } }) ? $r92 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t92))), T5);
                        });
                    }, $OfBnAd ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t93, $r93;
                            return $.$box(($t93 = executor6.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t93, { set $v($v) { $r93 = $v; } }) ? $r93 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t93))), T6);
                        });
                    }, $VvIcQh ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t94, $r94;
                            return $.$box(($t94 = executor7.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t94, { set $v($v) { $r94 = $v; } }) ? $r94 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t94))), T7);
                        });
                    }, $vedmOb ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t87, { set $v($v) { $r87 = $v; } }) ? $r87 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t87)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$$$$$$(T1, T2, T3, T4, T5, T6, T7))().$ctor$3($.$cast((($t95 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 0), ($.$$.N.AsyncResolver.IsCompleted($t95, { set $v($v) { $r95 = $v; } }) ? $r95 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t95)))), T1), $.$cast((($t96 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 1), ($.$$.N.AsyncResolver.IsCompleted($t96, { set $v($v) { $r96 = $v; } }) ? $r96 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t96)))), T2), $.$cast((($t97 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 2), ($.$$.N.AsyncResolver.IsCompleted($t97, { set $v($v) { $r97 = $v; } }) ? $r97 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t97)))), T3), $.$cast((($t98 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 3), ($.$$.N.AsyncResolver.IsCompleted($t98, { set $v($v) { $r98 = $v; } }) ? $r98 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t98)))), T4), $.$cast((($t99 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 4), ($.$$.N.AsyncResolver.IsCompleted($t99, { set $v($v) { $r99 = $v; } }) ? $r99 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t99)))), T5), $.$cast((($t100 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 5), ($.$$.N.AsyncResolver.IsCompleted($t100, { set $v($v) { $r100 = $v; } }) ? $r100 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t100)))), T6), $.$cast((($t101 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 6), ($.$$.N.AsyncResolver.IsCompleted($t101, { set $v($v) { $r101 = $v; } }) ? $r101 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t101)))), T7)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21477981139)
            
            //--TRIMMABLE-BOUNDARY-START(17183013843)
            static /*ValueTask<(T1, T2, T3, T4, T5, T6, T7, T8)> *//*async*/  BatchExecuteT$2(T1, T2, T3, T4, T5, T6, T7, T8, /*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*Func<IServerRemoteService, ValueTask<T1>>*/ executor1, /*Func<IServerRemoteService, ValueTask<T2>>*/ executor2, /*Func<IServerRemoteService, ValueTask<T3>>*/ executor3, /*Func<IServerRemoteService, ValueTask<T4>>*/ executor4, /*Func<IServerRemoteService, ValueTask<T5>>*/ executor5, /*Func<IServerRemoteService, ValueTask<T6>>*/ executor6, /*Func<IServerRemoteService, ValueTask<T7>>*/ executor7, /*Func<IServerRemoteService, ValueTask<T8>>*/ executor8)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$(T8))), $.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$(T8)), async ($asnycContext) => 
                {
                    let $t102, $r102;
                    let $t111, $r111;
                    let $t112, $r112;
                    let $t113, $r113;
                    let $t114, $r114;
                    let $t115, $r115;
                    let $t116, $r116;
                    let $t117, $r117;
                    let $t118, $r118;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183013843);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let results = ($t102 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.BatchExecute(server, context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))), [ new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t103, $r103;
                            return $.$box(($t103 = executor1.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t103, { set $v($v) { $r103 = $v; } }) ? $r103 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t103))), T1);
                        });
                    }, $fKLwhi ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t104, $r104;
                            return $.$box(($t104 = executor2.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t104, { set $v($v) { $r104 = $v; } }) ? $r104 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t104))), T2);
                        });
                    }, $DDPeLi ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t105, $r105;
                            return $.$box(($t105 = executor3.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t105, { set $v($v) { $r105 = $v; } }) ? $r105 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t105))), T3);
                        });
                    }, $Kxpwig ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t106, $r106;
                            return $.$box(($t106 = executor4.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t106, { set $v($v) { $r106 = $v; } }) ? $r106 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t106))), T4);
                        });
                    }, $JsdKch ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t107, $r107;
                            return $.$box(($t107 = executor5.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t107, { set $v($v) { $r107 = $v; } }) ? $r107 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t107))), T5);
                        });
                    }, $iHobSf ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t108, $r108;
                            return $.$box(($t108 = executor6.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t108, { set $v($v) { $r108 = $v; } }) ? $r108 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t108))), T6);
                        });
                    }, $WJEDri ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t109, $r109;
                            return $.$box(($t109 = executor7.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t109, { set $v($v) { $r109 = $v; } }) ? $r109 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t109))), T7);
                        });
                    }, $YFLSbh ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t110, $r110;
                            return $.$box(($t110 = executor8.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t110, { set $v($v) { $r110 = $v; } }) ? $r110 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t110))), T8);
                        });
                    }, $EvjJml ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t102, { set $v($v) { $r102 = $v; } }) ? $r102 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t102)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, T8))().$ctor$3($.$cast((($t111 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 0), ($.$$.N.AsyncResolver.IsCompleted($t111, { set $v($v) { $r111 = $v; } }) ? $r111 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t111)))), T1), $.$cast((($t112 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 1), ($.$$.N.AsyncResolver.IsCompleted($t112, { set $v($v) { $r112 = $v; } }) ? $r112 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t112)))), T2), $.$cast((($t113 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 2), ($.$$.N.AsyncResolver.IsCompleted($t113, { set $v($v) { $r113 = $v; } }) ? $r113 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t113)))), T3), $.$cast((($t114 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 3), ($.$$.N.AsyncResolver.IsCompleted($t114, { set $v($v) { $r114 = $v; } }) ? $r114 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t114)))), T4), $.$cast((($t115 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 4), ($.$$.N.AsyncResolver.IsCompleted($t115, { set $v($v) { $r115 = $v; } }) ? $r115 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t115)))), T5), $.$cast((($t116 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 5), ($.$$.N.AsyncResolver.IsCompleted($t116, { set $v($v) { $r116 = $v; } }) ? $r116 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t116)))), T6), $.$cast((($t117 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 6), ($.$$.N.AsyncResolver.IsCompleted($t117, { set $v($v) { $r117 = $v; } }) ? $r117 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t117)))), T7), $.$cast((($t118 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 7), ($.$$.N.AsyncResolver.IsCompleted($t118, { set $v($v) { $r118 = $v; } }) ? $r118 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t118)))), T8)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17183013843)
            
            //--TRIMMABLE-BOUNDARY-START(12888046547)
            static /*ValueTask<(T1, T2, T3, T4, T5, T6, T7, T8, T9)> *//*async*/  BatchExecuteT$1(T1, T2, T3, T4, T5, T6, T7, T8, T9, /*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*Func<IServerRemoteService, ValueTask<T1>>*/ executor1, /*Func<IServerRemoteService, ValueTask<T2>>*/ executor2, /*Func<IServerRemoteService, ValueTask<T3>>*/ executor3, /*Func<IServerRemoteService, ValueTask<T4>>*/ executor4, /*Func<IServerRemoteService, ValueTask<T5>>*/ executor5, /*Func<IServerRemoteService, ValueTask<T6>>*/ executor6, /*Func<IServerRemoteService, ValueTask<T7>>*/ executor7, /*Func<IServerRemoteService, ValueTask<T8>>*/ executor8, /*Func<IServerRemoteService, ValueTask<T9>>*/ executor9)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$$(T8, T9))), $.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$$(T8, T9)), async ($asnycContext) => 
                {
                    let $t119, $r119;
                    let $t129, $r129;
                    let $t130, $r130;
                    let $t131, $r131;
                    let $t132, $r132;
                    let $t133, $r133;
                    let $t134, $r134;
                    let $t135, $r135;
                    let $t136, $r136;
                    let $t137, $r137;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888046547);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let results = ($t119 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.BatchExecute(server, context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))), [ new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t120, $r120;
                            return $.$box(($t120 = executor1.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t120, { set $v($v) { $r120 = $v; } }) ? $r120 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t120))), T1);
                        });
                    }, $WsbPif ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t121, $r121;
                            return $.$box(($t121 = executor2.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t121, { set $v($v) { $r121 = $v; } }) ? $r121 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t121))), T2);
                        });
                    }, $LlcDRf ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t122, $r122;
                            return $.$box(($t122 = executor3.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t122, { set $v($v) { $r122 = $v; } }) ? $r122 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t122))), T3);
                        });
                    }, $rreFxf ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t123, $r123;
                            return $.$box(($t123 = executor4.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t123, { set $v($v) { $r123 = $v; } }) ? $r123 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t123))), T4);
                        });
                    }, $Uissri ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t124, $r124;
                            return $.$box(($t124 = executor5.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t124, { set $v($v) { $r124 = $v; } }) ? $r124 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t124))), T5);
                        });
                    }, $BBTUlg ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t125, $r125;
                            return $.$box(($t125 = executor6.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t125, { set $v($v) { $r125 = $v; } }) ? $r125 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t125))), T6);
                        });
                    }, $GghXmc ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t126, $r126;
                            return $.$box(($t126 = executor7.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t126, { set $v($v) { $r126 = $v; } }) ? $r126 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t126))), T7);
                        });
                    }, $KfiThj ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t127, $r127;
                            return $.$box(($t127 = executor8.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t127, { set $v($v) { $r127 = $v; } }) ? $r127 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t127))), T8);
                        });
                    }, $TvSmBe ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t128, $r128;
                            return $.$box(($t128 = executor9.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t128, { set $v($v) { $r128 = $v; } }) ? $r128 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t128))), T9);
                        });
                    }, $UlOJQe ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t119, { set $v($v) { $r119 = $v; } }) ? $r119 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t119)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$$(T8, T9)))().$ctor$3($.$cast((($t129 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 0), ($.$$.N.AsyncResolver.IsCompleted($t129, { set $v($v) { $r129 = $v; } }) ? $r129 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t129)))), T1), $.$cast((($t130 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 1), ($.$$.N.AsyncResolver.IsCompleted($t130, { set $v($v) { $r130 = $v; } }) ? $r130 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t130)))), T2), $.$cast((($t131 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 2), ($.$$.N.AsyncResolver.IsCompleted($t131, { set $v($v) { $r131 = $v; } }) ? $r131 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t131)))), T3), $.$cast((($t132 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 3), ($.$$.N.AsyncResolver.IsCompleted($t132, { set $v($v) { $r132 = $v; } }) ? $r132 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t132)))), T4), $.$cast((($t133 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 4), ($.$$.N.AsyncResolver.IsCompleted($t133, { set $v($v) { $r133 = $v; } }) ? $r133 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t133)))), T5), $.$cast((($t134 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 5), ($.$$.N.AsyncResolver.IsCompleted($t134, { set $v($v) { $r134 = $v; } }) ? $r134 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t134)))), T6), $.$cast((($t135 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 6), ($.$$.N.AsyncResolver.IsCompleted($t135, { set $v($v) { $r135 = $v; } }) ? $r135 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t135)))), T7), new ($.$$.S.ValueTuple$$$(T8, T9))().$ctor$3($.$cast((($t136 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 7), ($.$$.N.AsyncResolver.IsCompleted($t136, { set $v($v) { $r136 = $v; } }) ? $r136 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t136)))), T8), $.$cast((($t137 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 8), ($.$$.N.AsyncResolver.IsCompleted($t137, { set $v($v) { $r137 = $v; } }) ? $r137 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t137)))), T9))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12888046547)
            
            //--TRIMMABLE-BOUNDARY-START(8593079251)
            static /*ValueTask<(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10)> *//*async*/  BatchExecuteT(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, /*this IServerRemoteService*/ server, /*RemoteProxyExecutionContext?*/ context, /*Func<IServerRemoteService, ValueTask<T1>>*/ executor1, /*Func<IServerRemoteService, ValueTask<T2>>*/ executor2, /*Func<IServerRemoteService, ValueTask<T3>>*/ executor3, /*Func<IServerRemoteService, ValueTask<T4>>*/ executor4, /*Func<IServerRemoteService, ValueTask<T5>>*/ executor5, /*Func<IServerRemoteService, ValueTask<T6>>*/ executor6, /*Func<IServerRemoteService, ValueTask<T7>>*/ executor7, /*Func<IServerRemoteService, ValueTask<T8>>*/ executor8, /*Func<IServerRemoteService, ValueTask<T9>>*/ executor9, /*Func<IServerRemoteService, ValueTask<T10>>*/ executor10)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$$$(T8, T9, T10))), $.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$$$(T8, T9, T10)), async ($asnycContext) => 
                {
                    let $t138, $r138;
                    let $t149, $r149;
                    let $t150, $r150;
                    let $t151, $r151;
                    let $t152, $r152;
                    let $t153, $r153;
                    let $t154, $r154;
                    let $t155, $r155;
                    let $t156, $r156;
                    let $t157, $r157;
                    let $t158, $r158;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593079251);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let results = ($t138 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.BatchExecute(server, context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))), [ new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t139, $r139;
                            return $.$box(($t139 = executor1.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t139, { set $v($v) { $r139 = $v; } }) ? $r139 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t139))), T1);
                        });
                    }, $hqRTyh ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t140, $r140;
                            return $.$box(($t140 = executor2.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t140, { set $v($v) { $r140 = $v; } }) ? $r140 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t140))), T2);
                        });
                    }, $nJsmlg ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t141, $r141;
                            return $.$box(($t141 = executor3.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t141, { set $v($v) { $r141 = $v; } }) ? $r141 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t141))), T3);
                        });
                    }, $qOmMrd ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t142, $r142;
                            return $.$box(($t142 = executor4.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t142, { set $v($v) { $r142 = $v; } }) ? $r142 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t142))), T4);
                        });
                    }, $IaNlof ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t143, $r143;
                            return $.$box(($t143 = executor5.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t143, { set $v($v) { $r143 = $v; } }) ? $r143 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t143))), T5);
                        });
                    }, $atevil ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t144, $r144;
                            return $.$box(($t144 = executor6.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t144, { set $v($v) { $r144 = $v; } }) ? $r144 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t144))), T6);
                        });
                    }, $DfiOqc ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t145, $r145;
                            return $.$box(($t145 = executor7.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t145, { set $v($v) { $r145 = $v; } }) ? $r145 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t145))), T7);
                        });
                    }, $bAgbak ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t146, $r146;
                            return $.$box(($t146 = executor8.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t146, { set $v($v) { $r146 = $v; } }) ? $r146 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t146))), T8);
                        });
                    }, $MvnNhj ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t147, $r147;
                            return $.$box(($t147 = executor9.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t147, { set $v($v) { $r147 = $v; } }) ? $r147 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t147))), T9);
                        });
                    }, $XxqtYf ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}), new ($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object)))().$ctor(this, /*async*/  (/*server*/ server) =>
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                        {
                            let $t148, $r148;
                            return $.$box(($t148 = executor10.Invoke(server), ($.$$.N.AsyncResolver.IsCompleted($t148, { set $v($v) { $r148 = $v; } }) ? $r148 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t148))), T10);
                        });
                    }, $mhiXMd ??= {"r":$.$$.STT.Task$$($.$$.S.Object).$h,"p":[{"n":"server","p":1309651}],"n":"","d":3144659,"h":0,"f":17829890}) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t138, { set $v($v) { $r138 = $v; } }) ? $r138 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t138)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$$$(T8, T9, T10)))().$ctor$3($.$cast((($t149 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 0), ($.$$.N.AsyncResolver.IsCompleted($t149, { set $v($v) { $r149 = $v; } }) ? $r149 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t149)))), T1), $.$cast((($t150 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 1), ($.$$.N.AsyncResolver.IsCompleted($t150, { set $v($v) { $r150 = $v; } }) ? $r150 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t150)))), T2), $.$cast((($t151 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 2), ($.$$.N.AsyncResolver.IsCompleted($t151, { set $v($v) { $r151 = $v; } }) ? $r151 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t151)))), T3), $.$cast((($t152 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 3), ($.$$.N.AsyncResolver.IsCompleted($t152, { set $v($v) { $r152 = $v; } }) ? $r152 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t152)))), T4), $.$cast((($t153 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 4), ($.$$.N.AsyncResolver.IsCompleted($t153, { set $v($v) { $r153 = $v; } }) ? $r153 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t153)))), T5), $.$cast((($t154 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 5), ($.$$.N.AsyncResolver.IsCompleted($t154, { set $v($v) { $r154 = $v; } }) ? $r154 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t154)))), T6), $.$cast((($t155 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 6), ($.$$.N.AsyncResolver.IsCompleted($t155, { set $v($v) { $r155 = $v; } }) ? $r155 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t155)))), T7), new ($.$$.S.ValueTuple$$$$(T8, T9, T10))().$ctor$3($.$cast((($t156 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 7), ($.$$.N.AsyncResolver.IsCompleted($t156, { set $v($v) { $r156 = $v; } }) ? $r156 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t156)))), T8), $.$cast((($t157 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 8), ($.$$.N.AsyncResolver.IsCompleted($t157, { set $v($v) { $r157 = $v; } }) ? $r157 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t157)))), T9), $.$cast((($t158 = $.$sl.SL.Enumerable.ElementAt$1($.$$.STT.Task$$($.$$.S.Object), results, 9), ($.$$.N.AsyncResolver.IsCompleted($t158, { set $v($v) { $r158 = $v; } }) ? $r158 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t158)))), T10))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8593079251)
            
            //--TRIMMABLE-BOUNDARY-START(128852163539)
            static /*ValueTask<T> */ ReadSingle(T, /*this IServerRemoteService*/ server, /*DataFilter*/ filter, /*RemoteProxyExecutionContext?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852163539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$fPer.LCFCD.IReadSingleDataService$$(T), T, server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$fPer.LCFCD.IReadSingleDataService$$(T), $.$fPer.LCFCD.WireTransportModel$$(T)))().$ctor(this,  (/*server*/ server) =>
                {
                    return server[`LCFCD$IReadSingleDataService$${T.$getFullName('$')}$ReadSingle`](filter, null);
                }, $EsZIxh ??= {"r":(T) => $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$(T)).$h,"p":[{"n":"server","p":(T) => $.$fPer.LCFCD.IReadSingleDataService$$(T).$h}],"n":"","d":3144659,"h":0,"f":17825794}), filter, $.$with((context ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                {
                    $clone.CacheKey = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetCacheKey(T, filter, (context?.CacheKey ?? null));
                }));
            }
            //--TRIMMABLE-BOUNDARY-END(128852163539)
            
            //--TRIMMABLE-BOUNDARY-START(150327000019)
            static /*ValueTask<T?> *//*async*/  TryReadSingle(T, /*this IServerRemoteService*/ server, /*DataFilter*/ filter, /*RemoteProxyExecutionContext?*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T), T, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150327000019);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t159, $r159;
                        /*var*/ let t = ($t159 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$fPer.LCFCD.IReadSingleDataService$$(T), T, server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$fPer.LCFCD.IReadSingleDataService$$(T), $.$fPer.LCFCD.WireTransportModel$$(T)))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server[`LCFCD$IReadSingleDataService$${T.$getFullName('$')}$ReadSingle`](filter, null);
                        }, $VTrWJb ??= {"r":(T) => $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$(T)).$h,"p":[{"n":"server","p":(T) => $.$fPer.LCFCD.IReadSingleDataService$$(T).$h}],"n":"","d":3144659,"h":0,"f":17825794}), filter, $.$with((context ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                        {
                            $clone.CacheKey = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetCacheKey(T, filter, (context?.CacheKey ?? null));
                        })), ($.$$.N.AsyncResolver.IsCompleted($t159, { set $v($v) { $r159 = $v; } }) ? $r159 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t159)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, t);
                    }
                    catch(e)
                    {
                        if (e.Message !== "Not found")
                        {
                            throw e;
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$default(T));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(150327000019)
            
            //--TRIMMABLE-BOUNDARY-START(124557196243)
            static /*ValueTask<WireTransportManyModel<T>> */ ReadMany(T, /*this IServerRemoteService*/ server, /*DataFilter?*/ filter, /*RemoteProxyExecutionContext?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124557196243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$fPer.LCFCD.IReadManyDataService$$(T), T, server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$fPer.LCFCD.IReadManyDataService$$(T), $.$fPer.LCFCD.WireTransportManyModel$$(T)))().$ctor(this,  (/*server*/ server) =>
                {
                    return server[`LCFCD$IReadManyDataService$${T.$getFullName('$')}$ReadMany`](filter, null);
                }, $SsxIOb ??= {"r":(T) => $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(T)).$h,"p":[{"n":"server","p":(T) => $.$fPer.LCFCD.IReadManyDataService$$(T).$h}],"n":"","d":3144659,"h":0,"f":17825794}), filter, $.$with((context ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                {
                    $clone.CacheKey = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetCacheKey(T, filter, (context?.CacheKey ?? null));
                }));
            }
            //--TRIMMABLE-BOUNDARY-END(124557196243)
            
            //--TRIMMABLE-BOUNDARY-START(146032032723)
            static /*ValueTask<WireTransportManyModel<T>> *//*async*/  TryReadMany(T, /*this IServerRemoteService*/ server, /*DataFilter*/ filter, /*RemoteProxyExecutionContext?*/ context)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T)), $.$fPer.LCFCD.WireTransportManyModel$$(T), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146032032723);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t160, $r160;
                        /*var*/ let t = ($t160 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$fPer.LCFCD.IReadManyDataService$$(T), T, server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$fPer.LCFCD.IReadManyDataService$$(T), $.$fPer.LCFCD.WireTransportManyModel$$(T)))().$ctor(this,  (/*server*/ server) =>
                        {
                            return server[`LCFCD$IReadManyDataService$${T.$getFullName('$')}$ReadMany`](filter, null);
                        }, $HSMuXf ??= {"r":(T) => $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(T)).$h,"p":[{"n":"server","p":(T) => $.$fPer.LCFCD.IReadManyDataService$$(T).$h}],"n":"","d":3144659,"h":0,"f":17825794}), filter, $.$with((context ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                        {
                            $clone.CacheKey = $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetCacheKey(T, filter, (context?.CacheKey ?? null));
                        })), ($.$$.N.AsyncResolver.IsCompleted($t160, { set $v($v) { $r160 = $v; } }) ? $r160 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t160)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, t);
                    }
                    catch(e)
                    {
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$fPer.LCFCD.WireTransportManyModel$$(T))());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(146032032723)
            
            //--TRIMMABLE-BOUNDARY-START(60132686803)
            static /*ValueTask<WireTransportManyModel<T>> *//*async*/  Create(T, /*this IServerRemoteService*/ server, /*DataFilter*/ filter, /*params T[]*/ models)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T)), $.$fPer.LCFCD.WireTransportManyModel$$(T), async ($asnycContext) => 
                {
                    let $t164, $r164;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60132686803);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$fPer.LCFCD.IDataValidator.$type.IsAssignableFrom(T.$type))
                    {
                        let $i161 = 0;
                        let $arr161 = models;
                        while ($i161 < $arr161.length)
                        {
                            let $t162, $r162;
                            let model = $arr161[$i161++];
                            if (!($t162 = ($.$box(model, T)).LCFCD$IDataValidator$Validate($.$fPer.LCFCA$1.SchemaContext.op_Implicit$1(32/*SchemaType.Database*/)), ($.$$.N.AsyncResolver.IsCompleted($t162, { set $v($v) { $r162 = $v; } }) ? $r162 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t162))))
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12("Model is invalid");
                            }
                        }
                    }
                    if ($.$fPer.LCFCD.IDataModel.$type.IsAssignableFrom(T.$type))
                    {
                        let $i163 = 0;
                        let $arr163 = models;
                        while ($i163 < $arr163.length)
                        {
                            let model = $arr163[$i163++];
                            ($.$box(model, T)).LCFCD$IDataModel$On(server, new $.$fPer.LCFCD.DataEventArgs().$ctor$2(0/*DataEvent.Creating*/, null));
                        }
                    }
                    /*var*/ let ret = ($t164 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$fPer.LCFCD.ICreateDataService$$(T), T, server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$fPer.LCFCD.ICreateDataService$$(T), $.$fPer.LCFCD.WireTransportManyModel$$(T)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server[`LCFCD$ICreateDataService$${T.$getFullName('$')}$Create`](filter, models);
                    }, $DmLhDe ??= {"r":(T) => $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(T)).$h,"p":[{"n":"server","p":(T) => $.$fPer.LCFCD.ICreateDataService$$(T).$h}],"n":"","d":3144659,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t164, { set $v($v) { $r164 = $v; } }) ? $r164 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t164)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, ret);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(60132686803)
            
            //--TRIMMABLE-BOUNDARY-START(68722621395)
            static /*ValueTask<WireTransportManyModel<bool>> */ Delete(T, /*this IServerRemoteService*/ server, /*DataFilter*/ filter, /*params T[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722621395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$fPer.LCFCD.IDataModel.$type.IsAssignableFrom(T.$type))
                {
                    let $i165 = 0;
                    let $arr165 = models;
                    while ($i165 < $arr165.length)
                    {
                        let model = $arr165[$i165++];
                        ($.$box(model, T)).LCFCD$IDataModel$On(server, new $.$fPer.LCFCD.DataEventArgs().$ctor$2(2/*DataEvent.Deleting*/, null));
                    }
                }
                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$fPer.LCFCD.IDeleteDataService$$(T), $.$$.S.Boolean, server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$fPer.LCFCD.IDeleteDataService$$(T), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean)))().$ctor(this,  (/*server*/ server) =>
                {
                    return server.LCFCD$IDeleteDataService$$$Delete(filter, models);
                }, $aYfKke ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean)).$h,"p":[{"n":"server","p":(T) => $.$fPer.LCFCD.IDeleteDataService$$(T).$h}],"n":"","d":3144659,"h":0,"f":17825794}), null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(68722621395)
            
            //--TRIMMABLE-BOUNDARY-START(154621967315)
            static /*ValueTask<WireTransportManyModel<T>> *//*async*/  Update(T, /*this IServerRemoteService*/ server, /*DataFilter*/ filter, /*params T[]*/ models)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T)), $.$fPer.LCFCD.WireTransportManyModel$$(T), async ($asnycContext) => 
                {
                    let $t169, $r169;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154621967315);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$fPer.LCFCD.IDataValidator.$type.IsAssignableFrom(T.$type))
                    {
                        let $i166 = 0;
                        let $arr166 = models;
                        while ($i166 < $arr166.length)
                        {
                            let $t167, $r167;
                            let model = $arr166[$i166++];
                            if (!($t167 = ($.$box(model, T)).LCFCD$IDataValidator$Validate($.$fPer.LCFCA$1.SchemaContext.op_Implicit$1(32/*SchemaType.Database*/)), ($.$$.N.AsyncResolver.IsCompleted($t167, { set $v($v) { $r167 = $v; } }) ? $r167 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t167))))
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12("Model is invalid");
                            }
                        }
                    }
                    if ($.$fPer.LCFCD.IDataModel.$type.IsAssignableFrom(T.$type))
                    {
                        let $i168 = 0;
                        let $arr168 = models;
                        while ($i168 < $arr168.length)
                        {
                            let model = $arr168[$i168++];
                            ($.$box(model, T)).LCFCD$IDataModel$On(server, new $.$fPer.LCFCD.DataEventArgs().$ctor$2(1/*DataEvent.Updating*/, null));
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t169 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$fPer.LCFCD.IUpdateDataService$$(T), T, server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$fPer.LCFCD.IUpdateDataService$$(T), $.$fPer.LCFCD.WireTransportManyModel$$(T)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server[`LCFCD$IUpdateDataService$${T.$getFullName('$')}$Update`](filter, models);
                    }, $lKOTCk ??= {"r":(T) => $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(T)).$h,"p":[{"n":"server","p":(T) => $.$fPer.LCFCD.IUpdateDataService$$(T).$h}],"n":"","d":3144659,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t169, { set $v($v) { $r169 = $v; } }) ? $r169 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t169))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(154621967315)
            
            //--TRIMMABLE-BOUNDARY-START(64427654099)
            static /*ValueTask<WireTransportManyModel<T>> *//*async*/  CreateOrUpdate(T, /*this IServerRemoteService*/ server, /*DataFilter*/ filter, /*params T[]*/ models)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T)), $.$fPer.LCFCD.WireTransportManyModel$$(T), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64427654099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let toCreate = $.$sl.SL.Enumerable.ToList(T, $.$sl.SL.Enumerable.Where(T, models, new ($.$$.S.Func$$$(T, $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                    {
                        return ($.$box(m, T)).LCFCD$IIded$Identifier.Empty;
                    }, $KkXdba ??= {"r":262145,"p":[{"n":"m","p":(T) => T.$h}],"n":"","d":3144659,"h":0,"f":17825794})));
                    /*var*/ let toUpdate = $.$sl.SL.Enumerable.ToList(T, $.$sl.SL.Enumerable.Where(T, models, new ($.$$.S.Func$$$(T, $.$$.S.Boolean))().$ctor(this,  (/*m*/ m) =>
                    {
                        return !($.$box(m, T)).LCFCD$IIded$Identifier.Empty;
                    }, $DNoSzj ??= {"r":262145,"p":[{"n":"m","p":(T) => T.$h}],"n":"","d":3144659,"h":0,"f":17825794})));
                    /*List<T>*/ let results = new ($.$$.SCG.List$$(T))().$ctor$1();
                    if ($.$sl.SL.Enumerable.Any$1(T, toCreate))
                    {
                        let $t170, $r170;
                        /*var*/ let result = ($t170 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Create(T, server, filter, toCreate.ToArray()), ($.$$.N.AsyncResolver.IsCompleted($t170, { set $v($v) { $r170 = $v; } }) ? $r170 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t170)));
                        if (!result.Success)
                        {
                            throw new $.$$.S.Exception().$ctor$4(result.Message);
                        }
                        results.AddRange(result.Data);
                    }
                    if ($.$sl.SL.Enumerable.Any$1(T, toUpdate))
                    {
                        let $t171, $r171;
                        /*var*/ let result = ($t171 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Update(T, server, filter, toUpdate.ToArray()), ($.$$.N.AsyncResolver.IsCompleted($t171, { set $v($v) { $r171 = $v; } }) ? $r171 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t171)));
                        if (!result.Success)
                        {
                            throw new $.$$.S.Exception().$ctor$4(result.Message);
                        }
                        results.AddRange(result.Data);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                    {
                        //new $.$fPer.LCFCD.WireTransportManyModel$$(T)()
                        const $t172 = $.$fPer.LCFCD.WireTransportManyModel$$(T);
                        const $i172 = new $t172();
                        $i172.$ctor$2();
                        $i172.Success = true;
                        $i172.Data = results;
                        return $i172;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64427654099)
            
            static $h = 3144659;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(94492425171),
    {
      "r": 1310721,
      "p": [
        {
          "n": "_filter",
          "p": 9734486
        },
        {
          "n": "key",
          "p": 1310721,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetCacheKey",
      "d": 3144659,
      "h": 94492425171,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94492425171),
//--TRIMMABLE-BOUNDARY-START(51542752211),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "CacheKeyFor",
      "d": 3144659,
      "h": 51542752211,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(51542752211),
//--TRIMMABLE-BOUNDARY-START(55837719507),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "TService",
        "T"
      ],
      "n": "CacheKeyFor",
      "o": "@$1",
      "d": 3144659,
      "h": 55837719507,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(55837719507),
//--TRIMMABLE-BOUNDARY-START(137442098131),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "t",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "RunInterceptors",
      "d": 3144659,
      "h": 137442098131,
      "f": 16912418
    },
//--TRIMMABLE-BOUNDARY-END(137442098131),
//--TRIMMABLE-BOUNDARY-START(141737065427),
    {
      "r": (T, TState) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "state",
          "p": (T, TState) => TState.$h
        },
        {
          "n": "getPager",
          "p": (T, TState) => $.$$.S.Func$$$(TState, $.$$.STT.ValueTask$$(T)).$h
        }
      ],
      "g": [
        "T",
        "TState"
      ],
      "n": "ServerExcuteInternal",
      "d": 3144659,
      "h": 141737065427,
      "f": 16912418
    },
//--TRIMMABLE-BOUNDARY-END(141737065427),
//--TRIMMABLE-BOUNDARY-START(133147130835),
    {
      "r": (T) => $.$$.STT.Task$$(T).$h,
      "p": [
        {
          "n": "workItem",
          "p": (T) => $.$$.S.Func$$($.$$.STT.Task$$(T)).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "RunInBackground",
      "d": 3144659,
      "h": 133147130835,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(133147130835),
//--TRIMMABLE-BOUNDARY-START(98787392467),
    {
      "r": (TDataModel) => $.$fPer.LCFCD.Loader$$(TDataModel).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "loadFilter",
          "p": 9734486
        }
      ],
      "g": [
        "TDataModel"
      ],
      "n": "GetLoader",
      "d": 3144659,
      "h": 98787392467,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(98787392467),
//--TRIMMABLE-BOUNDARY-START(103082359763),
    {
      "r": (TDataModel) => $.$fPer.LCFCD.Pager$$(TDataModel).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486,
          "f": 65
        },
        {
          "n": "options",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "TDataModel"
      ],
      "n": "GetPager",
      "d": 3144659,
      "h": 103082359763,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(103082359763),
//--TRIMMABLE-BOUNDARY-START(107377327059),
    {
      "r": (TDataModel) => $.$fPer.LCFCD.Pager$$(TDataModel).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "getFilter",
          "p": $.$$.S.Func$$($.$$.STT.Task$$($.$fPer.LCFCD.DataFilter)).$h
        },
        {
          "n": "options",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "TDataModel"
      ],
      "n": "GetPager",
      "o": "@$1",
      "d": 3144659,
      "h": 107377327059,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(107377327059),
//--TRIMMABLE-BOUNDARY-START(111672294355),
    {
      "r": (TService, TDataModel) => $.$fPer.LCFCD.Pager$$(TDataModel).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "reader",
          "p": (TService, TDataModel) => $.$uvJL.LCFCR.ServicePagerMethod$$$(TService, TDataModel).$h
        },
        {
          "n": "filter",
          "p": 9734486,
          "f": 65
        },
        {
          "n": "options",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "TService",
        "TDataModel"
      ],
      "n": "GetPager",
      "o": "@$2",
      "d": 3144659,
      "h": 111672294355,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(111672294355),
//--TRIMMABLE-BOUNDARY-START(158916934611),
    {
      "r": 850899,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "WithFilter",
      "d": 3144659,
      "h": 158916934611,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(158916934611),
//--TRIMMABLE-BOUNDARY-START(115967261651),
    {
      "r": (TService) => $.$fPer.LCFCS$3.IServiceProxy$$(TService).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "options",
          "p": 1702867
        }
      ],
      "g": [
        "TService"
      ],
      "n": "GetRemoteService",
      "d": 3144659,
      "h": 115967261651,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(115967261651),
//--TRIMMABLE-BOUNDARY-START(73017588691),
    {
      "r": (TService, TData) => $.$$.STT.ValueTask$$(TData).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "reader",
          "p": (TService, TData) => $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.IWireTransportModel$$(TData)).$h
        },
        {
          "n": "filter",
          "p": 9734486,
          "f": 65
        },
        {
          "n": "options",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "TService",
        "TData"
      ],
      "n": "Execute",
      "d": 3144659,
      "h": 73017588691,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(73017588691),
//--TRIMMABLE-BOUNDARY-START(81607523283),
    {
      "r": (TService, TData) => $.$$.STT.ValueTask$$(TData).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "reader",
          "p": (TService, TData) => $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportModel$$(TData)).$h
        },
        {
          "n": "filter",
          "p": 9734486,
          "f": 65
        },
        {
          "n": "options",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "TService",
        "TData"
      ],
      "n": "Execute",
      "o": "@$2",
      "d": 3144659,
      "h": 81607523283,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(81607523283),
//--TRIMMABLE-BOUNDARY-START(77312555987),
    {
      "r": (TService, TData) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(TData)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "reader",
          "p": (TService, TData) => $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportManyModel$$(TData)).$h
        },
        {
          "n": "filter",
          "p": 9734486,
          "f": 65
        },
        {
          "n": "options",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "TService",
        "TData"
      ],
      "n": "Execute",
      "o": "@$1",
      "d": 3144659,
      "h": 77312555987,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(77312555987),
//--TRIMMABLE-BOUNDARY-START(90197457875),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "reader",
          "p": (TService) => $.$uvJL.LCFCR.ServiceModelMethod$$$(TService, $.$fPer.LCFCD.WireTransportModel).$h
        },
        {
          "n": "filter",
          "p": 9734486,
          "f": 65
        },
        {
          "n": "options",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "TService"
      ],
      "n": "Execute",
      "o": "@$4",
      "d": 3144659,
      "h": 90197457875,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(90197457875),
//--TRIMMABLE-BOUNDARY-START(85902490579),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "reader",
          "p": (TService) => $.$uvJL.LCFCR.ServiceMethod$$(TService).$h
        },
        {
          "n": "filter",
          "p": 9734486,
          "f": 65
        },
        {
          "n": "options",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "TService"
      ],
      "n": "Execute",
      "o": "@$3",
      "d": 3144659,
      "h": 85902490579,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(85902490579),
//--TRIMMABLE-BOUNDARY-START(120262228947),
    {
      "r": 65537,
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": "NOP",
      "d": 3144659,
      "h": 120262228947,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120262228947),
//--TRIMMABLE-BOUNDARY-START(4298111955),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.STT.Task$$($.$$.S.Object))).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executors",
          "p": $.$typeArray($.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.Task$$($.$$.S.Object))).$h,
          "f": 16
        }
      ],
      "n": "BatchExecute",
      "d": 3144659,
      "h": 4298111955,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(4298111955),
//--TRIMMABLE-BOUNDARY-START(47247784915),
    {
      "r": (T1) => $.$$.STT.ValueTask$$(T1).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executor1",
          "p": (T1) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T1)).$h
        }
      ],
      "g": [
        "T1"
      ],
      "n": "BatchExecuteT",
      "o": "@$9",
      "d": 3144659,
      "h": 47247784915,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(47247784915),
//--TRIMMABLE-BOUNDARY-START(42952817619),
    {
      "r": (T1, T2) => $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$(T1, T2)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executor1",
          "p": (T1, T2) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T1)).$h
        },
        {
          "n": "executor2",
          "p": (T1, T2) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T2)).$h
        }
      ],
      "g": [
        "T1",
        "T2"
      ],
      "n": "BatchExecuteT",
      "o": "@$8",
      "d": 3144659,
      "h": 42952817619,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(42952817619),
//--TRIMMABLE-BOUNDARY-START(38657850323),
    {
      "r": (T1, T2, T3) => $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$(T1, T2, T3)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executor1",
          "p": (T1, T2, T3) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T1)).$h
        },
        {
          "n": "executor2",
          "p": (T1, T2, T3) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T2)).$h
        },
        {
          "n": "executor3",
          "p": (T1, T2, T3) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T3)).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3"
      ],
      "n": "BatchExecuteT",
      "o": "@$7",
      "d": 3144659,
      "h": 38657850323,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(38657850323),
//--TRIMMABLE-BOUNDARY-START(34362883027),
    {
      "r": (T1, T2, T3, T4) => $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$(T1, T2, T3, T4)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executor1",
          "p": (T1, T2, T3, T4) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T1)).$h
        },
        {
          "n": "executor2",
          "p": (T1, T2, T3, T4) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T2)).$h
        },
        {
          "n": "executor3",
          "p": (T1, T2, T3, T4) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T3)).$h
        },
        {
          "n": "executor4",
          "p": (T1, T2, T3, T4) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T4)).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4"
      ],
      "n": "BatchExecuteT",
      "o": "@$6",
      "d": 3144659,
      "h": 34362883027,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(34362883027),
//--TRIMMABLE-BOUNDARY-START(30067915731),
    {
      "r": (T1, T2, T3, T4, T5) => $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$(T1, T2, T3, T4, T5)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executor1",
          "p": (T1, T2, T3, T4, T5) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T1)).$h
        },
        {
          "n": "executor2",
          "p": (T1, T2, T3, T4, T5) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T2)).$h
        },
        {
          "n": "executor3",
          "p": (T1, T2, T3, T4, T5) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T3)).$h
        },
        {
          "n": "executor4",
          "p": (T1, T2, T3, T4, T5) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T4)).$h
        },
        {
          "n": "executor5",
          "p": (T1, T2, T3, T4, T5) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T5)).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5"
      ],
      "n": "BatchExecuteT",
      "o": "@$5",
      "d": 3144659,
      "h": 30067915731,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(30067915731),
//--TRIMMABLE-BOUNDARY-START(25772948435),
    {
      "r": (T1, T2, T3, T4, T5, T6) => $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$$(T1, T2, T3, T4, T5, T6)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executor1",
          "p": (T1, T2, T3, T4, T5, T6) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T1)).$h
        },
        {
          "n": "executor2",
          "p": (T1, T2, T3, T4, T5, T6) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T2)).$h
        },
        {
          "n": "executor3",
          "p": (T1, T2, T3, T4, T5, T6) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T3)).$h
        },
        {
          "n": "executor4",
          "p": (T1, T2, T3, T4, T5, T6) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T4)).$h
        },
        {
          "n": "executor5",
          "p": (T1, T2, T3, T4, T5, T6) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T5)).$h
        },
        {
          "n": "executor6",
          "p": (T1, T2, T3, T4, T5, T6) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T6)).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5",
        "T6"
      ],
      "n": "BatchExecuteT",
      "o": "@$4",
      "d": 3144659,
      "h": 25772948435,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(25772948435),
//--TRIMMABLE-BOUNDARY-START(21477981139),
    {
      "r": (T1, T2, T3, T4, T5, T6, T7) => $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$$$(T1, T2, T3, T4, T5, T6, T7)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executor1",
          "p": (T1, T2, T3, T4, T5, T6, T7) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T1)).$h
        },
        {
          "n": "executor2",
          "p": (T1, T2, T3, T4, T5, T6, T7) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T2)).$h
        },
        {
          "n": "executor3",
          "p": (T1, T2, T3, T4, T5, T6, T7) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T3)).$h
        },
        {
          "n": "executor4",
          "p": (T1, T2, T3, T4, T5, T6, T7) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T4)).$h
        },
        {
          "n": "executor5",
          "p": (T1, T2, T3, T4, T5, T6, T7) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T5)).$h
        },
        {
          "n": "executor6",
          "p": (T1, T2, T3, T4, T5, T6, T7) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T6)).$h
        },
        {
          "n": "executor7",
          "p": (T1, T2, T3, T4, T5, T6, T7) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T7)).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5",
        "T6",
        "T7"
      ],
      "n": "BatchExecuteT",
      "o": "@$3",
      "d": 3144659,
      "h": 21477981139,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(21477981139),
//--TRIMMABLE-BOUNDARY-START(17183013843),
    {
      "r": (T1, T2, T3, T4, T5, T6, T7, T8) => $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$(T8))).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executor1",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T1)).$h
        },
        {
          "n": "executor2",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T2)).$h
        },
        {
          "n": "executor3",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T3)).$h
        },
        {
          "n": "executor4",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T4)).$h
        },
        {
          "n": "executor5",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T5)).$h
        },
        {
          "n": "executor6",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T6)).$h
        },
        {
          "n": "executor7",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T7)).$h
        },
        {
          "n": "executor8",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T8)).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5",
        "T6",
        "T7",
        "T8"
      ],
      "n": "BatchExecuteT",
      "o": "@$2",
      "d": 3144659,
      "h": 17183013843,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(17183013843),
//--TRIMMABLE-BOUNDARY-START(12888046547),
    {
      "r": (T1, T2, T3, T4, T5, T6, T7, T8, T9) => $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$$(T8, T9))).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executor1",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T1)).$h
        },
        {
          "n": "executor2",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T2)).$h
        },
        {
          "n": "executor3",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T3)).$h
        },
        {
          "n": "executor4",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T4)).$h
        },
        {
          "n": "executor5",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T5)).$h
        },
        {
          "n": "executor6",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T6)).$h
        },
        {
          "n": "executor7",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T7)).$h
        },
        {
          "n": "executor8",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T8)).$h
        },
        {
          "n": "executor9",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T9)).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5",
        "T6",
        "T7",
        "T8",
        "T9"
      ],
      "n": "BatchExecuteT",
      "o": "@$1",
      "d": 3144659,
      "h": 12888046547,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(12888046547),
//--TRIMMABLE-BOUNDARY-START(8593079251),
    {
      "r": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.STT.ValueTask$$($.$$.S.ValueTuple$$$$$$$$$(T1, T2, T3, T4, T5, T6, T7, $.$$.S.ValueTuple$$$$(T8, T9, T10))).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "context",
          "p": 1702867
        },
        {
          "n": "executor1",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T1)).$h
        },
        {
          "n": "executor2",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T2)).$h
        },
        {
          "n": "executor3",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T3)).$h
        },
        {
          "n": "executor4",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T4)).$h
        },
        {
          "n": "executor5",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T5)).$h
        },
        {
          "n": "executor6",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T6)).$h
        },
        {
          "n": "executor7",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T7)).$h
        },
        {
          "n": "executor8",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T8)).$h
        },
        {
          "n": "executor9",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T9)).$h
        },
        {
          "n": "executor10",
          "p": (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) => $.$$.S.Func$$$($.$uvJL.LCFCR.IServerRemoteService, $.$$.STT.ValueTask$$(T10)).$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5",
        "T6",
        "T7",
        "T8",
        "T9",
        "T10"
      ],
      "n": "BatchExecuteT",
      "d": 3144659,
      "h": 8593079251,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(8593079251),
//--TRIMMABLE-BOUNDARY-START(128852163539),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "context",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "ReadSingle",
      "d": 3144659,
      "h": 128852163539,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(128852163539),
//--TRIMMABLE-BOUNDARY-START(150327000019),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "context",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryReadSingle",
      "d": 3144659,
      "h": 150327000019,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(150327000019),
//--TRIMMABLE-BOUNDARY-START(124557196243),
    {
      "r": (T) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "context",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "ReadMany",
      "d": 3144659,
      "h": 124557196243,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(124557196243),
//--TRIMMABLE-BOUNDARY-START(146032032723),
    {
      "r": (T) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "context",
          "p": 1702867,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryReadMany",
      "d": 3144659,
      "h": 146032032723,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(146032032723),
//--TRIMMABLE-BOUNDARY-START(60132686803),
    {
      "r": (T) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "models",
          "p": (T) => $.$typeArray(T).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "Create",
      "d": 3144659,
      "h": 60132686803,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(60132686803),
//--TRIMMABLE-BOUNDARY-START(68722621395),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "models",
          "p": (T) => $.$typeArray(T).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "Delete",
      "d": 3144659,
      "h": 68722621395,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(68722621395),
//--TRIMMABLE-BOUNDARY-START(154621967315),
    {
      "r": (T) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "models",
          "p": (T) => $.$typeArray(T).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "Update",
      "d": 3144659,
      "h": 154621967315,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(154621967315),
//--TRIMMABLE-BOUNDARY-START(64427654099),
    {
      "r": (T) => $.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$(T)).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "models",
          "p": (T) => $.$typeArray(T).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateOrUpdate",
      "d": 3144659,
      "h": 64427654099,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(64427654099)
  ],
  "h": 3144659
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ServerRemoteServiceExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ServerRemoteServiceExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3144659)
        
        

        //--TRIMMABLE-BOUNDARY-START(2948051)
        $asm.$cls(`$uvJL.LCFCR.RemoteServiceExtension`, ($self) => class RemoteServiceExtension
        {
            //--TRIMMABLE-BOUNDARY-START(17182817235)
            static /*string */ GetRemoteServiceId(/*this Type*/ remoteServiceType, /*MethodInfo*/ method, /*out string*/ signature, /*bool*/ hashId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182817235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!remoteServiceType.IsInterface)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`${$.$strNN(remoteServiceType.FullName)} is not an interface`);
                }
                if (remoteServiceType !== method.DeclaringType)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`${$.$strNN(method.Name)} was not declared on ${$.$strNN(remoteServiceType.FullName)}`);
                }
                return $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(remoteServiceType, method.Name, $.$sl.SL.Enumerable.Select$1($.$$.SR.ParameterInfo, $.$uvJL.LCFCR.RemoteProxyMethodParameter, method.GetParameters(), new ($.$$.S.Func$$$($.$$.SR.ParameterInfo, $.$uvJL.LCFCR.RemoteProxyMethodParameter))().$ctor(this,  (/*p*/ p) =>
                {
                    return (() =>
                    {
                        //new $.$uvJL.LCFCR.RemoteProxyMethodParameter()
                        const $t1 = $.$uvJL.LCFCR.RemoteProxyMethodParameter;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = p.Name;
                        $i1.ParameterType = p.ParameterType;
                        $i1.Type = p.ParameterType.FullName;
                        return $i1;
                    })();
                }, $mtxjqh ??= {"r":2030547,"p":[{"n":"p","p":119078913}],"n":"","d":2948051,"h":0,"f":17825794})), signature, hashId);
            }
            //--TRIMMABLE-BOUNDARY-END(17182817235)
            
            //--TRIMMABLE-BOUNDARY-START(8592882643)
            static /*string */ GetFriendlyName(/*this Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592882643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsGenericType)
                {
                    /*string*/ let genericBaseName = type.Name;
                    /*int*/ let backtickIndex = $.$$.S.String.IndexOf$3.call(genericBaseName, /*`*/ 96);
                    if (backtickIndex > 0)
                    {
                        genericBaseName = $.$$.S.String.Substring.call(genericBaseName, 0, backtickIndex);
                    }
                    /*string*/ let fullBaseName = $.$$.S.String.IsNullOrEmpty(type.Namespace) ? genericBaseName : `${$.$strNN(type.Namespace)}.${$.$strNN(genericBaseName)}`;
                    /*var*/ let genericArguments = $.$sl.SL.Enumerable.Select$1($.$$.S.Type, $.$$.S.String, type.GetGenericArguments(), new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.String))().$ctor(this,  (/*t*/ t) =>
                    {
                        return $.$uvJL.LCFCR.RemoteServiceExtension.GetFriendlyName(t);
                    }, $WXUwCd ??= {"r":1310721,"p":[{"n":"t","p":188547073}],"n":"","d":2948051,"h":0,"f":17825794}));
                    return `${$.$strNN(fullBaseName)}<${$.$strNN($.$$.S.String.Join$5(", ", genericArguments))}>`;
                }
                return type.FullName ?? type.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8592882643)
            
            //--TRIMMABLE-BOUNDARY-START(21477784531)
            static /*string */ GetRemoteServiceId$1(/*this Type*/ remoteServiceType, /*string*/ methodName, /*IEnumerable<RemoteProxyMethodParameter>*/ parameters, /*out string*/ signature, /*bool*/ hashId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477784531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!remoteServiceType.IsInterface)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`${$.$strNN(remoteServiceType.FullName)} is not an interface`);
                }
                signature.$v = $.$strNN($.$strNN($.$strNN($.$strNN($.$strNN(remoteServiceType.ToString()) + ".") + $.$strNN(methodName)) + "(") + $.$strNN($.$$.S.String.Join$5(", ", $.$sl.SL.Enumerable.Select$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.String, parameters, new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.String))().$ctor(this,  (/**/ p) =>
                {
                    /*System.Type?*/ let __ca1__;
                    return ((__ca1__ = p.ParameterType) !== null ? ($.$uvJL.LCFCR.RemoteServiceExtension.GetFriendlyName(__ca1__) ?? $.$$.S.String.Trim$1.call(p.Type, /*?*/ 63)) : $.$$.S.String.Trim$1.call(p.Type, /*?*/ 63));
                }, $hHvkfe ??= {"r":1310721,"p":[{"n":"p","p":2030547}],"n":"","d":2948051,"h":0,"f":17825794}))))) + ")";
                if (hashId)
                {
                    /*SHA1*/ let sha = $.$sscr.SSC.SHA1.Create$2();
                    /*var*/ let hash = sha.ComputeHash$1($.$$.ST.Encoding.UTF8.GetBytes$8(signature.$v));
                    return $.$$.S.Convert.ToBase64String$3(hash);
                }
                else 
                {
                    return `${$.$strNN(remoteServiceType.FullName)}.${$.$strNN(methodName)}`;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477784531)
            
            //--TRIMMABLE-BOUNDARY-START(12887849939)
            static /*string */ GetRemoteMethodId(/*this Type*/ remoteServiceType, /*MethodInfo*/ method)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887849939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!remoteServiceType.IsInterface)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`${$.$strNN(remoteServiceType.FullName)} is not an interface`);
                }
                /*var*/ let sa = $.$$.SR.CustomAttributeExtensions.GetCustomAttribute$7($.$uvJL.LCFCR.RemoteServiceAttribute, remoteServiceType, true);
                if ((sa?.Id ?? null) !== null)
                {
                    return $.$strNN($.$strNN(sa.Id) + ".") + $.$strNN(method.Name);
                }
                /*SHA1*/ let sha = $.$sscr.SSC.SHA1.Create$2();
                /*var*/ let hash = sha.ComputeHash$1($.$$.ST.Encoding.UTF8.GetBytes$8($.$strNN($.$strNN(remoteServiceType.ToString()) + ".") + $.$strNN(method.Name)));
                return $.$$.S.Convert.ToBase64String$3(hash);
            }
            //--TRIMMABLE-BOUNDARY-END(12887849939)
            
            //--TRIMMABLE-BOUNDARY-START(4297915347)
            static /*ServiceFactory? */ GetClientServices(/*this IRemoteService*/ _this)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297915347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCP$1.PropertyExtension.GetAttachedProperty($.$fPer.LCFCS$3.ServiceFactory, _this, "ServiceFactory");
            }
            //--TRIMMABLE-BOUNDARY-END(4297915347)
            
            //--TRIMMABLE-BOUNDARY-START(25772751827)
            static /*void */ SetClientServices(/*this IRemoteService*/ _this, /*ServiceFactory?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772751827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCP$1.PropertyExtension.AttachProperty($.$fPer.LCFCS$3.ServiceFactory, _this, value, "ServiceFactory");
            }
            //--TRIMMABLE-BOUNDARY-END(25772751827)
            
            static $h = 2948051;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182817235),
    {
      "r": 1310721,
      "p": [
        {
          "n": "remoteServiceType",
          "p": 188547073
        },
        {
          "n": "method",
          "p": 117571585
        },
        {
          "n": "signature",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "hashId",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "GetRemoteServiceId",
      "d": 2948051,
      "h": 17182817235,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182817235),
//--TRIMMABLE-BOUNDARY-START(8592882643),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetFriendlyName",
      "d": 2948051,
      "h": 8592882643,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592882643),
//--TRIMMABLE-BOUNDARY-START(21477784531),
    {
      "r": 1310721,
      "p": [
        {
          "n": "remoteServiceType",
          "p": 188547073
        },
        {
          "n": "methodName",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter).$h
        },
        {
          "n": "signature",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "hashId",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "GetRemoteServiceId",
      "o": "@$1",
      "d": 2948051,
      "h": 21477784531,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477784531),
//--TRIMMABLE-BOUNDARY-START(12887849939),
    {
      "r": 1310721,
      "p": [
        {
          "n": "remoteServiceType",
          "p": 188547073
        },
        {
          "n": "method",
          "p": 117571585
        }
      ],
      "n": "GetRemoteMethodId",
      "d": 2948051,
      "h": 12887849939,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887849939),
//--TRIMMABLE-BOUNDARY-START(4297915347),
    {
      "r": 62949718,
      "p": [
        {
          "n": "_this",
          "p": 48007510
        }
      ],
      "n": "GetClientServices",
      "d": 2948051,
      "h": 4297915347,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297915347),
//--TRIMMABLE-BOUNDARY-START(25772751827),
    {
      "r": 65537,
      "p": [
        {
          "n": "_this",
          "p": 48007510
        },
        {
          "n": "value",
          "p": 62949718
        }
      ],
      "n": "SetClientServices",
      "d": 2948051,
      "h": 25772751827,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772751827)
  ],
  "h": 2948051
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteServiceExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteServiceExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2948051)
        
        

        //--TRIMMABLE-BOUNDARY-START(2816979)
        $asm.$cls(`$uvJL.LCFCR.RemoteSchemaReaderOption<>`, (T) => $asm.$gt(`$uvJL.LCFCR.RemoteSchemaReaderOption<>`, [T], ($self) => class RemoteSchemaReaderOption$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887718867)
            /*DataFilter?*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(12887718867)
            
            //--TRIMMABLE-BOUNDARY-START(8592751571)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592751571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592751571)
            
            //--TRIMMABLE-BOUNDARY-START(8592751571)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8592751571)
            
            static $H = 2816979;
            static $h = 2816979;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887718867),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21477653459,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 30067588051,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 83886081
      },
      "n": "Filter",
      "d": this.$h,
      "H": 12887718867,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887718867)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592751571),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8592751571,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592751571)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 2816979,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteSchemaReaderOption<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteSchemaReaderOption$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2816979)
        
        

        //--TRIMMABLE-BOUNDARY-START(1965011)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptorBuilder`, ($self) => class RemoteProxyMethodInfoTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591899603)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591899603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor()
                        const $t1 = $.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfo");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $KXbyZe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1965011,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$uvJL.LCFCR.RemoteProxyMethodInfo.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591899603)
            
            //--TRIMMABLE-BOUNDARY-START(4296932307)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296932307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296932307)
            
            //--TRIMMABLE-BOUNDARY-START(4296932307)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296932307)
            
            static $h = 1965011;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591899603),
    {
      "r": 65537,
      "n": "Register",
      "d": 1965011,
      "h": 8591899603,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591899603)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296932307),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1965011,
      "h": 4296932307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296932307)
  ],
  "h": 1965011
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfoTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyMethodInfoTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1965011)
        
        

        //--TRIMMABLE-BOUNDARY-START(1506259)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyCallMethodInvoker<>`, (TServiceInterface) => $asm.$gt(`$uvJL.LCFCR.RemoteProxyCallMethodInvoker<>`, [TServiceInterface], ($self) => class RemoteProxyCallMethodInvoker$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(1637331)
            static $_RemoteServiceParameter;
            static get RemoteServiceParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1637331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface);
                return $cls.$_RemoteServiceParameter ??= $asm.$nstr(`$uvJL.LCFCR.RemoteProxyCallMethodInvoker<${TServiceInterface?.$fullName}>.RemoteServiceParameter`, ($self) => class RemoteServiceParameter extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(38656342995)
                    /*PropertyInfo*/ Property = null;
                    //--TRIMMABLE-BOUNDARY-END(38656342995)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181506515)
                    /*RemoteServiceParameterAttribute?*/ Attribute = null;
                    //--TRIMMABLE-BOUNDARY-END(17181506515)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886539219)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886539219);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886539219)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886539219)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886539219)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Property = this.Property;
                        copy.Attribute = this.Attribute;
                        return copy;
                    }
                    static $H = 1637331;
                    static $h = 1637331;
                    static $z = 8;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656342995),
    {
      "p": 119603201,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34361375699,
        "h": Number(BigInt(1637331)|0x800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 55836212179,
        "h": Number(BigInt(1637331)|0xD00000000n),
        "f": 83886081
      },
      "n": "Property",
      "d": 1637331,
      "H": 38656342995,
      "h": Number(BigInt(1637331)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656342995),
//--TRIMMABLE-BOUNDARY-START(17181506515),
    {
      "p": 3013587,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25771441107,
        "h": Number(BigInt(1637331)|0x600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47246277587,
        "h": Number(BigInt(1637331)|0xB00000000n),
        "f": 83886081
      },
      "n": "Attribute",
      "d": 1637331,
      "H": 17181506515,
      "h": Number(BigInt(1637331)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181506515)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886539219),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1637331,
      "H": 12886539219,
      "h": Number(BigInt(1637331)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886539219)
  ],
  "d": 1506259,
  "H": 1637331,
  "h": 1637331
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyCallMethodInvoker<${TServiceInterface?.$fullName}>+RemoteServiceParameter`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyCallMethodInvoker$${TServiceInterface?.$getFullName(separator)}$${separator}RemoteServiceParameter`; }
                }, $cls, ($v) => $cls.$_RemoteServiceParameter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1637331)
            
            //--TRIMMABLE-BOUNDARY-START(1571795)
            static $_RemoteServiceInfo;
            static get RemoteServiceInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1571795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface);
                return $cls.$_RemoteServiceInfo ??= $asm.$nstr(`$uvJL.LCFCR.RemoteProxyCallMethodInvoker<${TServiceInterface?.$fullName}>.RemoteServiceInfo`, ($self) => class RemoteServiceInfo extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(111670721491)
                    /*Type*/ Type = null;
                    //--TRIMMABLE-BOUNDARY-END(111670721491)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131113939)
                    /*MethodInfo*/ Method = null;
                    //--TRIMMABLE-BOUNDARY-END(60131113939)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080786899)
                    /*string*/ Signature = null;
                    //--TRIMMABLE-BOUNDARY-END(103080786899)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426081235)
                    /*IEnumerable<RemoteServiceParameter>*/ Parameters = null;
                    //--TRIMMABLE-BOUNDARY-END(64426081235)
                    
                    //--TRIMMABLE-BOUNDARY-START(107375754195)
                    /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107375754195);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return `${$.$strNN(this.Signature)}`;
                    }
                    //--TRIMMABLE-BOUNDARY-END(107375754195)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476408275)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476408275);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476408275)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476408275)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476408275)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Type = this.Type;
                        copy.Method = this.Method;
                        copy.Signature = this.Signature;
                        copy.Parameters = this.Parameters;
                        return copy;
                    }
                    static $H = 1571795;
                    static $h = 1571795;
                    static $z = 16;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670721491),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55836146643,
        "h": Number(BigInt(1571795)|0xD00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 98785819603,
        "h": Number(BigInt(1571795)|0x1700000000n),
        "f": 83886081
      },
      "n": "Type",
      "d": 1571795,
      "H": 111670721491,
      "h": Number(BigInt(1571795)|0x1A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670721491),
//--TRIMMABLE-BOUNDARY-START(60131113939),
    {
      "p": 117571585,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30066342867,
        "h": Number(BigInt(1571795)|0x700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 73016015827,
        "h": Number(BigInt(1571795)|0x1100000000n),
        "f": 83886081
      },
      "n": "Method",
      "d": 1571795,
      "H": 60131113939,
      "h": Number(BigInt(1571795)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131113939),
//--TRIMMABLE-BOUNDARY-START(103080786899),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47246212051,
        "h": Number(BigInt(1571795)|0xB00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 90195885011,
        "h": Number(BigInt(1571795)|0x1500000000n),
        "f": 83886081
      },
      "n": "Signature",
      "d": 1571795,
      "H": 103080786899,
      "h": Number(BigInt(1571795)|0x1800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080786899),
//--TRIMMABLE-BOUNDARY-START(64426081235),
    {
      "p": $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceParameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38656277459,
        "h": Number(BigInt(1571795)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 81605950419,
        "h": Number(BigInt(1571795)|0x1300000000n),
        "f": 83886081
      },
      "n": "Parameters",
      "d": 1571795,
      "H": 64426081235,
      "h": Number(BigInt(1571795)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426081235)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107375754195),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1571795,
      "H": 107375754195,
      "h": Number(BigInt(1571795)|0x1900000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107375754195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476408275),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1571795,
      "H": 21476408275,
      "h": Number(BigInt(1571795)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476408275)
  ],
  "d": 1506259,
  "H": 1571795,
  "h": 1571795
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyCallMethodInvoker<${TServiceInterface?.$fullName}>+RemoteServiceInfo`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyCallMethodInvoker$${TServiceInterface?.$getFullName(separator)}$${separator}RemoteServiceInfo`; }
                }, $cls, ($v) => $cls.$_RemoteServiceInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1571795)
            
            //--TRIMMABLE-BOUNDARY-START(21476342739)
            /*MethodInfo*/ getResultMethod = null;
            //--TRIMMABLE-BOUNDARY-END(21476342739)
            
            //--TRIMMABLE-BOUNDARY-START(30066277331)
            /*MethodInfo*/ getValueResultMethod = null;
            //--TRIMMABLE-BOUNDARY-END(30066277331)
            
            //--TRIMMABLE-BOUNDARY-START(38656211923)
            /*ConcurrentDictionary<string, RemoteServiceInfo>*/ serviceTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(38656211923)
            
            //--TRIMMABLE-BOUNDARY-START(4296473555)
            $ctor$1(/*IServiceProvider*/ resolver)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296473555);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.getResultMethod = $.$firstOf($.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).$type.GetMethod$9("GetResult", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/), () => { throw new $.$$.S.NullReferenceException().$ctor$12("getResultMethod") });
                    this.getValueResultMethod = $.$firstOf($.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).$type.GetMethod$9("GetValueResult", 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/), () => { throw new $.$$.S.NullReferenceException().$ctor$12("getResultMethod") });
                    _ = $.$$.STT.Task.Run$1(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        let scope = null;
                        try
                        {
                            scope = $.$mxdi.MED.ServiceProviderServiceExtensions.CreateScope(resolver);
                            this.CreateRemoteServiceTypeMap(scope);
                        }
                        finally
                        {
                            scope?.S$IDisposable$Dispose();
                        }
                    }, $fvZycg ??= {"r":65537,"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296473555)
            
            //--TRIMMABLE-BOUNDARY-START(17181375443)
            /*T */ GetResult(T, /*Task<T>*/ task)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181375443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return task.Result;
            }
            //--TRIMMABLE-BOUNDARY-END(17181375443)
            
            //--TRIMMABLE-BOUNDARY-START(25771310035)
            /*T */ GetValueResult(T, /*ValueTask<T>*/ task)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771310035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return task.Result;
            }
            //--TRIMMABLE-BOUNDARY-END(25771310035)
            
            //--TRIMMABLE-BOUNDARY-START(12886408147)
            /*void */ CreateRemoteServiceTypeMap(/*IServiceScope*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886408147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let services = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$(TServiceInterface), scope.MED$IServiceScope$ServiceProvider);
                let $en1 = services.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let service = $en1.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let serviceType = $.$$.S.Object.GetType.call(service);
                        /*var*/ let interfaces = serviceType.GetInterfaces();
                        let $i2 = 0;
                        let $arr2 = interfaces;
                        while ($i2 < $arr2.length)
                        {
                            let _interface = $arr2[$i2++];
                            if (_interface !== TServiceInterface.$type)
                            {
                                let $en3 = $.$fPer.LCFCT.TypesExtensions.GetIMethods(_interface).SCG$IEnumerable$$$GetEnumerator();
                                while ($en3.SC$1$IEnumerator$MoveNext())
                                {
                                    let method = $en3.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let signature;
                                        /*var*/ let key = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId(method.DeclaringType, method, $.$ref(() => signature, ($v) => signature = $v, $.$$.S.String), true);
                                        this.serviceTypeMap.set_Item$1(key, (() =>
                                        {
                                            //new $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo()
                                            const $t5 = $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo;
                                            const $i5 = new $t5();
                                            $i5.$ctor$2();
                                            $i5.Type = serviceType;
                                            $i5.Method = method;
                                            $i5.Signature = signature;
                                            $i5.Parameters = $.$sl.SL.Enumerable.ToList($.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceParameter, $.$sl.SL.Enumerable.Where($.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceParameter, $.$sl.SL.Enumerable.Select$1($.$$.SR.PropertyInfo, $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceParameter, serviceType.GetProperties(), new ($.$$.S.Func$$$($.$$.SR.PropertyInfo, $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceParameter))().$ctor(this,  (/*i*/ i) =>
                                            {
                                                return (() =>
                                                {
                                                    //new $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceParameter()
                                                    const $t6 = $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceParameter;
                                                    const $i6 = new $t6();
                                                    $i6.$ctor$2();
                                                    $i6.Property = i;
                                                    $i6.Attribute = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributeFast$3($.$uvJL.LCFCR.RemoteServiceParameterAttribute, i, false, true);
                                                    return $i6;
                                                })();
                                            }, $CCUzZa ??= {"r":1637331,"p":[{"n":"i","p":119603201}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceParameter, $.$$.S.Boolean))().$ctor(this,  (/*i*/ i) =>
                                            {
                                                return i.Attribute !== null;
                                            }, $RQpFDc ??= {"r":262145,"p":[{"n":"i","p":1637331}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                                            return $i5;
                                        })());
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886408147)
            
            //--TRIMMABLE-BOUNDARY-START(34361244627)
            /*Task<object?> *//*async*/  Invoke(/*RemoteProxyMethodInfo*/ proxyMethodInfo, /*IScopedServiceFactory*/ scope, /*ClaimsPrincipal?*/ principal, /*IEnumerable<Stream>?*/ streams, /*OneOf<TServiceInterface, Action<TServiceInterface>>?*/ intializeService)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Object), $.$$.S.Object, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361244627);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*RemoteServiceInfo*/ let serviceInfo;
                    if (!this.serviceTypeMap.TryGetValue(proxyMethodInfo.Service, $.$ref(() => serviceInfo, ($v) => serviceInfo = $v, $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo)))
                    {
                        /*var*/ let split = $.$$.S.String.Split$1.call(proxyMethodInfo.Service, /*.*/ 46, 0);
                        if (split.length > 1)
                        {
                            /*var*/ let _serviceId = $.$$.S.String.Join$5(".", $.$sl.SL.Enumerable.SkipLast($.$$.S.String, split, 1));
                            /*var*/ let _method = $.$sl.SL.Enumerable.Last$1($.$$.S.String, split);
                            /*var*/ let type = $.$firstOf(scope.LCFCS$3$IScopedServiceFactory$GetType(_serviceId), () => { throw new $.$$.S.NullReferenceException().$ctor$12(`Cannot find service ${$.$strNN(_serviceId)}`) });
                            /*var*/ let mtd = type.GetMethod$12(_method);
                            if (type !== null && $.$$.SR.MethodInfo.op_Inequality$2(mtd, null))
                            {
                                serviceInfo = (() =>
                                {
                                    //new $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo()
                                    const $t8 = $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo;
                                    const $i8 = new $t8();
                                    $i8.$ctor$2();
                                    $i8.Type = type;
                                    $i8.Method = mtd;
                                    return $i8;
                                })();
                            }
                        }
                    }
                    if (serviceInfo.Type === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`Remote: Unable to find service with id \"${$.$strNN(proxyMethodInfo.Service)}\"`);
                    }
                    /*var*/ let authorize = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributeFast$5($.$uvJL.LCFCR.AuthorizeServiceAttribute, serviceInfo.Type, null, false, true);
                    if (authorize !== null)
                    {
                        if (principal === null)
                        {
                            throw new $.$snsc.SSA.AuthenticationException().$ctor$12("Not authenticated");
                        }
                        if (authorize.Roles !== null)
                        {
                            /*var*/ let roles = $.$$.S.String.Split$5.call(authorize.Roles, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*,*/ 44], [-1], null));
                            if (!$.$sl.SL.Enumerable.Any($.$$.S.String, roles, new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.Boolean))().$ctor(this,  (/*r*/ r) =>
                            {
                                return principal.IsInRole(r);
                            }, $tuQBWd ??= {"r":262145,"p":[{"n":"r","p":1310721}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})))
                            {
                                throw new $.$snsc.SSA.AuthenticationException().$ctor$12("Not authenticated");
                            }
                        }
                    }
                    /*TServiceInterface*/ let service = ((intializeService?.IsT0 ?? null) ?? false) ? $.$$.S.Nullable$$($.$fPer.LCFCO.OneOf$$$(TServiceInterface, $.$$.S.Action$$(TServiceInterface))).Value$get.call(intializeService).AsT0 : $.$cast(scope.LCFCS$3$IScopedServiceFactory$ResolveRequired(serviceInfo.Type, null, null), TServiceInterface);
                    intializeService?.Switch(new ($.$$.S.Action$$(TServiceInterface))().$ctor(this,  (/*s*/ s) =>
                    {
                    }, $hMEWgd ??= {"r":65537,"p":[{"n":"s","p":TServiceInterface?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}), new ($.$$.S.Action$$($.$$.S.Action$$(TServiceInterface)))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.Invoke(service);
                    }, $ybQelb ??= {"r":65537,"p":[{"n":"s","p":$.$$.S.Action$$(TServiceInterface).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter>?*/ let __ca1__;
                    if ($.$$.S.Int32.op_GreaterThan(((__ca1__ = proxyMethodInfo.ServiceParameters) !== null ? $.$fPer.LCFC.ArrayCompare.Count(__ca1__) : null), 0) && $.$fPer.LCFC.ArrayCompare.Count(serviceInfo.Parameters) > 0)
                    {
                        let $en9 = serviceInfo.Parameters.SCG$IEnumerable$$$GetEnumerator();
                        while ($en9.SC$1$IEnumerator$MoveNext())
                        {
                            let parameter = $en9.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let value = $.$sl.SL.Enumerable.SingleOrDefault$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, proxyMethodInfo.ServiceParameters, new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                                {
                                    return s.Name === ((parameter.Attribute?.Name ?? null) ?? parameter.Property.Name);
                                }, $DilFcd ??= {"r":262145,"p":[{"n":"s","p":2030547}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                                /*var*/ let cValue = $.$fPer.LCFCD.DataConverter.Convert($.$clone(value), parameter.Property.PropertyType);
                                parameter.Property.SetValue$2($.$box(service, TServiceInterface), cValue);
                            }
                        }
                    }
                    /*var*/ let methodParameterTypes = serviceInfo.Method.GetParameters();
                    /*object?[]*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [methodParameterTypes.length], null);
                    /*int*/ let output_i = 0;
                    /*int*/ let input_i = 0;
                    /*int*/ let stream_i = 0;
                    let $i10 = 0;
                    let $arr10 = methodParameterTypes;
                    while ($i10 < $arr10.length)
                    {
                        let parameterType = $arr10[$i10++];
                        if ($.$$.SI.Stream.$type.IsAssignableFrom(parameterType.ParameterType) && streams !== null)
                        {
                            $.$$.System.Array.$WriteT1.call(parameters, $.$sl.SL.Enumerable.ElementAt$1($.$$.SI.Stream, streams, stream_i), output_i);
                            stream_i++;
                        }
                        else 
                        {
                            /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter>?*/ let __ca2__;
                            if ($.$$.S.Int32.op_GreaterThan(((__ca2__ = proxyMethodInfo.Parameters) !== null ? $.$fPer.LCFC.ArrayCompare.Count(__ca2__) : null), input_i))
                            {
                                /*var*/ let rparam = $.$sl.SL.Enumerable.ElementAt$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, proxyMethodInfo.Parameters, input_i).Parameter;
                                input_i++;
                                /*object?*/ let parameter;
                                let element;
                                let node;
                                let tjel;
                                if ($.$is(rparam, $.$stj.STJ.JsonElement, { set $v($v){ element = $v; } }))
                                {
                                    parameter = $.$stj.STJ.JsonSerializer.Deserialize$19(element, parameterType.ParameterType, (() =>
                                    {
                                        //new $.$stj.STJ.JsonSerializerOptions()
                                        const $t11 = $.$stj.STJ.JsonSerializerOptions;
                                        const $i11 = new $t11();
                                        $i11.$ctor$1();
                                        $i11.PropertyNameCaseInsensitive = true;
                                        $i11.IgnoreReadOnlyFields = true;
                                        $i11.IgnoreReadOnlyProperties = true;
                                        $i11.ReferenceHandler = $.$stj.STJS$1.ReferenceHandler.Preserve;
                                        return $i11;
                                    })());
                                }
                                else if ($.$is(rparam, $.$stj.STJN.JsonNode, { set $v($v){ node = $v; } }))
                                {
                                    parameter = $.$stj.STJ.JsonSerializer.Deserialize$22(node, parameterType.ParameterType, (() =>
                                    {
                                        //new $.$stj.STJ.JsonSerializerOptions()
                                        const $t12 = $.$stj.STJ.JsonSerializerOptions;
                                        const $i12 = new $t12();
                                        $i12.$ctor$1();
                                        $i12.PropertyNameCaseInsensitive = true;
                                        $i12.IgnoreReadOnlyFields = true;
                                        $i12.IgnoreReadOnlyProperties = true;
                                        $i12.ReferenceHandler = $.$stj.STJS$1.ReferenceHandler.Preserve;
                                        return $i12;
                                    })());
                                }
                                else if ($.$is(rparam, $.$fPer.LCFCST.TypeDescriptorJsonSerializerJsonDocument, { set $v($v){ tjel = $v; } }))
                                {
                                    parameter = tjel.Deserialize(parameterType.ParameterType);
                                }
                                else 
                                {
                                    parameter = rparam;
                                }
                                let rs;
                                if ($.$is(parameter, $.$uvJL.LCFCR.IRemoteStream, { set $v($v){ rs = $v; } }) && streams !== null)
                                {
                                    rs.LCFCR$IRemoteStream$Stream = $.$sl.SL.Enumerable.ElementAt$1($.$$.SI.Stream, streams, stream_i);
                                    stream_i++;
                                }
                                $.$$.System.Array.$WriteT1.call(parameters, parameter, output_i);
                            }
                            else 
                            {
                                $.$$.System.Array.$WriteT1.call(parameters, parameterType.DefaultValue, output_i);
                            }
                        }
                        output_i++;
                    }
                    /*var*/ let result = serviceInfo.Method.Invoke($.$box(service, TServiceInterface), parameters);
                    let task;
                    if ($.$is(result, $.$$.STT.Task, { set $v($v){ task = $v; } }))
                    {
                        if (serviceInfo.Method.ReturnType.IsGenericType)
                        {
                            /*var*/ let gTypes = serviceInfo.Method.ReturnType.GetGenericArguments();
                            /*var*/ let parameterType = $.$$.System.Array.$ReadT1.call(gTypes, ((gTypes.length - 1) | 0));
                            /*var*/ let getResult = this.getResultMethod.MakeGenericMethod($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ parameterType ], null, null));
                            result = getResult.Invoke(this, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [task], [-1], null));
                            return $.$$.N.AsyncResolver.Result($asnycContext, result);
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.S.Void.$type);
                    }
                    let vtask;
                    if ($.$is(result, $.$$.STT.ValueTask, { set $v($v){ vtask = $v; } }))
                    {
                        let $t13, $r13;
                        ($t13 = vtask, ($.$$.N.AsyncResolver.IsCompleted($t13, { set $v($v) { $r13 = $v; } }) ? $r13 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t13)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.S.Void.$type);
                    }
                    if (serviceInfo.Method.ReturnType === $.$$.S.Void.$type)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.S.Void.$type);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, result);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34361244627)
            
            //--TRIMMABLE-BOUNDARY-START(8591440851)
            /*string */ BuildTable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591440851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let response = $.$$.S.String.Join$5("\r\n\r\n", $.$sl.SL.Enumerable.Select($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo), $.$$.S.String, this.serviceTypeMap, new ($.$$.S.Func$$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo), $.$$.S.Int32, $.$$.S.String))().$ctor(this,  (/*m*/ m, /*i*/ i) =>
                {
                    return `${$.$strNN(((i + 1) | 0))}. \"${$.$strNN(m.Key)}\" => ${$.$strNN(m.Value.Signature)}`;
                }, $CkYSlc ??= {"r":1310721,"p":[{"n":"m","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo).$h},{"n":"i","p":655361}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
                return response;
            }
            //--TRIMMABLE-BOUNDARY-END(8591440851)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38656211923)
                this.serviceTypeMap = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(38656211923)
                
            }
            static $H = 1506259;
            static $h = 1506259;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181375443),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "task",
          "p": (T) => $.$$.STT.Task$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetResult",
      "d": this.$h,
      "H": 17181375443,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(17181375443),
//--TRIMMABLE-BOUNDARY-START(25771310035),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "task",
          "p": (T) => $.$$.STT.ValueTask$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetValueResult",
      "d": this.$h,
      "H": 25771310035,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(25771310035),
//--TRIMMABLE-BOUNDARY-START(12886408147),
    {
      "r": 65537,
      "p": [
        {
          "n": "scope",
          "p": 1048666
        }
      ],
      "n": "CreateRemoteServiceTypeMap",
      "d": this.$h,
      "H": 12886408147,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886408147),
//--TRIMMABLE-BOUNDARY-START(34361244627),
    {
      "r": $.$$.STT.Task$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "proxyMethodInfo",
          "p": 1768403
        },
        {
          "n": "scope",
          "p": 61966678
        },
        {
          "n": "principal",
          "p": 393285
        },
        {
          "n": "streams",
          "p": $.$$.SCG.IEnumerable$$($.$$.SI.Stream).$h
        },
        {
          "n": "intializeService",
          "p": $.$typeNullable($.$fPer.LCFCO.OneOf$$$(TServiceInterface, $.$$.S.Action$$(TServiceInterface))).$h,
          "f": 65
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 34361244627,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34361244627),
//--TRIMMABLE-BOUNDARY-START(8591440851),
    {
      "r": 1310721,
      "n": "BuildTable",
      "d": this.$h,
      "H": 8591440851,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591440851)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476342739),
    {
      "t": 117571585,
      "n": "getResultMethod",
      "d": this.$h,
      "H": 21476342739,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476342739),
//--TRIMMABLE-BOUNDARY-START(30066277331),
    {
      "t": 117571585,
      "n": "getValueResultMethod",
      "d": this.$h,
      "H": 30066277331,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066277331),
//--TRIMMABLE-BOUNDARY-START(38656211923),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo).$h,
      "n": "serviceTypeMap",
      "d": this.$h,
      "H": 38656211923,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656211923)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296473555),
    {
      "p": [
        {
          "n": "resolver",
          "p": 327718
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4296473555,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296473555)
  ],
  "s": [
    {
      "h": TServiceInterface?.$h??1572864,
      "n": "TServiceInterface"
    }
  ],
  "r": 1,
  "H": 1506259,
  "h": this.$h
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceParameter, $.$uvJL.LCFCR.RemoteProxyCallMethodInvoker$$(TServiceInterface).RemoteServiceInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyCallMethodInvoker<${TServiceInterface?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyCallMethodInvoker$${TServiceInterface?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1506259)
        
        

        //--TRIMMABLE-BOUNDARY-START(3406803)
        $asm.$cls(`$uvJL.LCFCR.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593341395)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593341395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$uvJL.LCFCR.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$2(services, $.$uvJL.LCFCR.RemoteSchemaOptionReader$$().$type);
                $.$uvJL.LCFCR.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$uvJL.LCFCR.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593341395)
            
            //--TRIMMABLE-BOUNDARY-START(12888308691)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888308691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12888308691)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$uvJL.LCFCR.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298374099)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298374099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298374099)
            
            //--TRIMMABLE-BOUNDARY-START(4298374099)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298374099)
            
            static $h = 3406803;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593341395),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3406803,
      "h": 8593341395,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8593341395),
//--TRIMMABLE-BOUNDARY-START(12888308691),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 3406803,
      "h": 12888308691,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12888308691)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298374099),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3406803,
      "h": 4298374099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298374099)
  ],
  "h": 3406803
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3406803)
        
        

        //--TRIMMABLE-BOUNDARY-START(3079123)
        $asm.$cls(`$uvJL.LCFCR.ServerRemoteFunction<,>`, (TService, TData) => $asm.$gt(`$uvJL.LCFCR.ServerRemoteFunction<,>`, [TService, TData], ($self) => class ServerRemoteFunction$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30067850195)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(30067850195)
            
            //--TRIMMABLE-BOUNDARY-START(8593013715)
            $ctor$1(/*IServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593013715);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593013715)
            
            //--TRIMMABLE-BOUNDARY-START(17182948307)
            /*Task<TData> *//*async*/  Execute$1(/*Func<TService, Task<WireTransportModel<TData>>>*/ reader)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TData), TData, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182948307);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let service = null;
                    try
                    {
                        let $t1, $r1;
                        service = this.Server.LCFCR$IServerRemoteService$GetRemoteService(TService, null);
                        /*var*/ let result = ($t1 = reader.Invoke(service.LCFCS$3$IServiceProxy$$$Service), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        if (result.Success)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, result.Data);
                        }
                        throw new $.$$.S.Exception().$ctor$4(result.Message);
                    }
                    finally
                    {
                        service?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17182948307)
            
            //--TRIMMABLE-BOUNDARY-START(12887981011)
            /*Task<IEnumerable<TData>> *//*async*/  Execute(/*Func<TService, Task<WireTransportManyModel<TData>>>*/ reader)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TData)), $.$$.SCG.IEnumerable$$(TData), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887981011);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let service = null;
                    try
                    {
                        let $t2, $r2;
                        service = this.Server.LCFCR$IServerRemoteService$GetRemoteService(TService, null);
                        /*var*/ let result = ($t2 = reader.Invoke(service.LCFCS$3$IServiceProxy$$$Service), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        if (result.Success)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, result.Data);
                        }
                        throw new $.$$.S.Exception().$ctor$4(result.Message);
                    }
                    finally
                    {
                        service?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12887981011)
            
            //--TRIMMABLE-BOUNDARY-START(8591178707)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IServerRemoteFunction<TService, TData>.Execute(System.Func<TService, System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<TData>>>)
            [`LCFCR$IServerRemoteFunction$$$$Execute$${TService.$getFullName('$')}$${TData.$getFullName('$')}$1`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591178707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591178707)
            
            //--TRIMMABLE-BOUNDARY-START(4296211411)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IServerRemoteFunction<TService, TData>.Execute(System.Func<TService, System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<TData>>>)
            [`LCFCR$IServerRemoteFunction$${TService.$getFullName('$')}$${TData.$getFullName('$')}$Execute`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296211411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Execute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296211411)
            
            static $H = 3079123;
            static $h = 3079123;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067850195),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25772882899,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331650
      },
      "n": "Server",
      "d": this.$h,
      "H": 30067850195,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30067850195)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182948307),
    {
      "r": $.$$.STT.Task$$(TData).$h,
      "p": [
        {
          "n": "reader",
          "p": $.$$.S.Func$$$(TService, $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$(TData))).$h
        }
      ],
      "n": "Execute",
      "o": "@$1",
      "d": this.$h,
      "H": 17182948307,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(17182948307),
//--TRIMMABLE-BOUNDARY-START(12887981011),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$(TData)).$h,
      "p": [
        {
          "n": "reader",
          "p": $.$$.S.Func$$$(TService, $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(TData))).$h
        }
      ],
      "n": "Execute",
      "d": this.$h,
      "H": 12887981011,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12887981011)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593013715),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8593013715,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593013715)
  ],
  "s": [
    {
      "h": TService?.$h??1572864,
      "n": "TService",
      "f": 1,
      "c": [48007510
      ]
    },
    {
      "h": TData?.$h??1638400,
      "n": "TData"
    }
  ],
  "r": 2,
  "H": 3079123,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IServerRemoteFunction$$$(TService, TData) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ServerRemoteFunction<${TService?.$fullName},${TData?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ServerRemoteFunction$${TService?.$getFullName(separator)}$${TData?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3079123)
        
        

        //--TRIMMABLE-BOUNDARY-START(261075)
        $asm.$cls(`$uvJL.LCFCR.BatchItemClientServerRemoteService`, ($self) => class BatchItemClientServerRemoteService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590195667)
            /*IBatchClientServerRemoteService*/ _proxied = null;
            //--TRIMMABLE-BOUNDARY-END(8590195667)
            
            //--TRIMMABLE-BOUNDARY-START(4295228371)
            /*int*/ _index = 0;
            //--TRIMMABLE-BOUNDARY-END(4295228371)
            
            //--TRIMMABLE-BOUNDARY-START(12885162963)
            $ctor$1(/*IBatchClientServerRemoteService*/ proxied, /*int*/ index)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885162963);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._proxied = proxied;
                    this._index = index;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885162963)
            
            //--TRIMMABLE-BOUNDARY-START(17180130259)
            /*void */ AddServiceRequestHeader(/*string*/ key, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180130259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(17180130259)
            
            //--TRIMMABLE-BOUNDARY-START(21475097555)
            /*Task */ Commit(/*IRemoteServiceOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475097555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(21475097555)
            
            //--TRIMMABLE-BOUNDARY-START(30065032147)
            /*void */ NOP(/*int*/ batchIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065032147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._proxied.LCFCR$IBatchClientServerRemoteService$NOP(this._index);
            }
            //--TRIMMABLE-BOUNDARY-END(30065032147)
            
            //--TRIMMABLE-BOUNDARY-START(25770064851)
            /*IServiceProxy<TService> */ LCFCR$IServerRemoteService$GetRemoteService(TService, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770064851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let op = $.$with((options ?? $.$uvJL.LCFCR.RemoteProxyExecutionContext.Default), ($clone) =>
                {
                    $clone.InBatchIndex = this._index;
                });
                return this._proxied.LCFCR$IServerRemoteService$GetRemoteService(TService, op);
            }
            //--TRIMMABLE-BOUNDARY-END(25770064851)
            
            //--TRIMMABLE-BOUNDARY-START(8590588883)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IBatchClientServerRemoteService.NOP(int)
            LCFCR$IBatchClientServerRemoteService$NOP()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590588883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NOP(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590588883)
            
            //--TRIMMABLE-BOUNDARY-START(4295621587)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IBatchClientServerRemoteService.Commit(LivingThing.Core.Frameworks.Common.RPC.IRemoteServiceOptions?)
            LCFCR$IBatchClientServerRemoteService$Commit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295621587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Commit(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295621587)
            
            //--TRIMMABLE-BOUNDARY-START(4296276947)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IServerRemoteService.AddServiceRequestHeader(string, string?)
            LCFCR$IServerRemoteService$AddServiceRequestHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296276947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddServiceRequestHeader(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296276947)
            
            static $h = 261075;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180130259),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddServiceRequestHeader",
      "d": 261075,
      "h": 17180130259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180130259),
//--TRIMMABLE-BOUNDARY-START(21475097555),
    {
      "r": 178454529,
      "p": [
        {
          "n": "options",
          "p": 1113043
        }
      ],
      "n": "Commit",
      "d": 261075,
      "h": 21475097555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475097555),
//--TRIMMABLE-BOUNDARY-START(30065032147),
    {
      "r": 65537,
      "p": [
        {
          "n": "batchIndex",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "NOP",
      "d": 261075,
      "h": 30065032147,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065032147)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590195667),
    {
      "t": 654291,
      "n": "_proxied",
      "d": 261075,
      "h": 8590195667,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590195667),
//--TRIMMABLE-BOUNDARY-START(4295228371),
    {
      "t": 655361,
      "n": "_index",
      "d": 261075,
      "h": 4295228371,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295228371)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885162963),
    {
      "p": [
        {
          "n": "proxied",
          "p": 654291
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 261075,
      "h": 12885162963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885162963)
  ],
  "h": 261075
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IBatchClientServerRemoteService, $.$uvJL.LCFCR.IServerRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.BatchItemClientServerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}BatchItemClientServerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(261075)
        
        

        //--TRIMMABLE-BOUNDARY-START(588755)
        $asm.$cls(`$uvJL.LCFCR.FilteringServerRemoteService`, ($self) => class FilteringServerRemoteService extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655294419)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(38655294419)
            
            //--TRIMMABLE-BOUNDARY-START(8590523347)
            $ctor$1(/*IServerRemoteService*/ server, /*DataFilter*/ filter)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590523347);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                    this.Filter = filter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590523347)
            
            //--TRIMMABLE-BOUNDARY-START(17180457939)
            /*DataFilter*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(17180457939)
            
            //--TRIMMABLE-BOUNDARY-START(34360327123)
            /*Task<TResponse> */ Post(TResponse, /*string*/ url, /*object*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360327123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(34360327123)
            
            //--TRIMMABLE-BOUNDARY-START(12885490643)
            /*void */ AddServiceRequestHeader(/*string*/ key, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885490643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(12885490643)
            
            //--TRIMMABLE-BOUNDARY-START(30065359827)
            /*IServiceProxy<TService> */ LCFCR$IServerRemoteService$GetRemoteService(TService, /*RemoteProxyExecutionContext?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065359827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Server.LCFCR$IServerRemoteService$GetRemoteService(TService, options);
            }
            //--TRIMMABLE-BOUNDARY-END(30065359827)
            
            //--TRIMMABLE-BOUNDARY-START(12885752787)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IFilteringServerRemoteService.Filter.get
            get LCFCR$IFilteringServerRemoteService$Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295818195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Filter;
            }
            //--TRIMMABLE-BOUNDARY-END(12885752787)
            
            //--TRIMMABLE-BOUNDARY-START(4296276947)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IServerRemoteService.AddServiceRequestHeader(string, string?)
            LCFCR$IServerRemoteService$AddServiceRequestHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296276947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddServiceRequestHeader(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296276947)
            
            static $h = 588755;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180457939),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770392531,
        "f": 50331649
      },
      "n": "Filter",
      "d": 588755,
      "h": 17180457939,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180457939)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360327123),
    {
      "r": (TResponse) => $.$$.STT.Task$$(TResponse).$h,
      "p": [
        {
          "n": "url",
          "p": 1310721
        },
        {
          "n": "model",
          "p": 131073
        }
      ],
      "g": [
        "TResponse"
      ],
      "n": "Post",
      "d": 588755,
      "h": 34360327123,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(34360327123),
//--TRIMMABLE-BOUNDARY-START(12885490643),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddServiceRequestHeader",
      "d": 588755,
      "h": 12885490643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885490643)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655294419),
    {
      "t": 1309651,
      "n": "Server",
      "d": 588755,
      "h": 38655294419,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655294419)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590523347),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 588755,
      "h": 8590523347,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590523347)
  ],
  "h": 588755
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IFilteringServerRemoteService, $.$uvJL.LCFCR.IServerRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.FilteringServerRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}FilteringServerRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(588755)
        
        

        //--TRIMMABLE-BOUNDARY-START(1702867)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyExecutionContext`, ($self) => class RemoteProxyExecutionContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(111670852563)
            /*RemoteProxyExecutionContext*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(111670852563)
            
            //--TRIMMABLE-BOUNDARY-START(313534315475)
            /*bool?*/ RunInBackground = null;
            //--TRIMMABLE-BOUNDARY-END(313534315475)
            
            //--TRIMMABLE-BOUNDARY-START(317829282771)
            /*ICacheProvider?*/ ServerCache = null;
            //--TRIMMABLE-BOUNDARY-END(317829282771)
            
            //--TRIMMABLE-BOUNDARY-START(107375885267)
            /*IDataCacheStorageService?*/ DataCache = null;
            //--TRIMMABLE-BOUNDARY-END(107375885267)
            
            //--TRIMMABLE-BOUNDARY-START(98785950675)
            /*TimeSpan?*/ CachePeriod = null;
            //--TRIMMABLE-BOUNDARY-END(98785950675)
            
            //--TRIMMABLE-BOUNDARY-START(94490983379)
            /*string?*/ CacheKey = null;
            //--TRIMMABLE-BOUNDARY-END(94490983379)
            
            //--TRIMMABLE-BOUNDARY-START(468153138131)
            /*int?*/ TimeOut = null;
            //--TRIMMABLE-BOUNDARY-END(468153138131)
            
            //--TRIMMABLE-BOUNDARY-START(309239348179)
            /*int?*/ Retries = null;
            //--TRIMMABLE-BOUNDARY-END(309239348179)
            
            //--TRIMMABLE-BOUNDARY-START(85901048787)
            /*bool?*/ Authenticate = null;
            //--TRIMMABLE-BOUNDARY-END(85901048787)
            
            //--TRIMMABLE-BOUNDARY-START(103080917971)
            /*bool?*/ CloneResponse = null;
            //--TRIMMABLE-BOUNDARY-END(103080917971)
            
            //--TRIMMABLE-BOUNDARY-START(115965819859)
            /*bool?*/ Encrypt = null;
            //--TRIMMABLE-BOUNDARY-END(115965819859)
            
            //--TRIMMABLE-BOUNDARY-START(304944380883)
            /*IDictionary<string, string?>?*/ RequestHeader = null;
            //--TRIMMABLE-BOUNDARY-END(304944380883)
            
            //--TRIMMABLE-BOUNDARY-START(90196016083)
            /*bool?*/ Batching = null;
            //--TRIMMABLE-BOUNDARY-END(90196016083)
            
            //--TRIMMABLE-BOUNDARY-START(287764511699)
            /*int?*/ InBatchIndex = null;
            //--TRIMMABLE-BOUNDARY-END(287764511699)
            
            //--TRIMMABLE-BOUNDARY-START(283469544403)
            /*bool?*/ HashServiceName = null;
            //--TRIMMABLE-BOUNDARY-END(283469544403)
            
            //--TRIMMABLE-BOUNDARY-START(322124250067)
            /*Action<object>?*/ ServiceParameterSetter = null;
            //--TRIMMABLE-BOUNDARY-END(322124250067)
            
            //--TRIMMABLE-BOUNDARY-START(463858170835)
            /*string?*/ get_Item$1(/*string*/ key)
            {
                /*string?*/ let value = null;
                this.RequestHeader?.SCG$IDictionary$$$$TryGetValue(key, $.$ref(() => value, ($v) => value = $v, $.$$.S.String));
                return value;
            }
            /*void*/ set_Item$1(/*string*/ key, /*string?*/ value)
            {
                this.RequestHeader ??= new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$1();
                this.RequestHeader.SCG$IDictionary$$$$set_Item(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(463858170835)
            
            //--TRIMMABLE-BOUNDARY-START(30065884115)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteServiceOptions.Batching.get
            get LCFCR$IRemoteServiceOptions$Batching()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591047635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Batching;
            }
            //--TRIMMABLE-BOUNDARY-END(30065884115)
            
            //--TRIMMABLE-BOUNDARY-START(38655818707)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteServiceOptions.Encrypt.get
            get LCFCR$IRemoteServiceOptions$Encrypt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886014931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Encrypt;
            }
            //--TRIMMABLE-BOUNDARY-END(38655818707)
            
            //--TRIMMABLE-BOUNDARY-START(21475949523)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteServiceOptions.Authenticate.get
            get LCFCR$IRemoteServiceOptions$Authenticate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296080339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Authenticate;
            }
            //--TRIMMABLE-BOUNDARY-END(21475949523)
            
            //--TRIMMABLE-BOUNDARY-START(64425622483)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteServiceOptions.TimeOut.get
            get LCFCR$IRemoteServiceOptions$TimeOut()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310524371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TimeOut;
            }
            //--TRIMMABLE-BOUNDARY-END(64425622483)
            
            //--TRIMMABLE-BOUNDARY-START(55835687891)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteServiceOptions.Retries.get
            get LCFCR$IRemoteServiceOptions$Retries()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015557075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Retries;
            }
            //--TRIMMABLE-BOUNDARY-END(55835687891)
            
            //--TRIMMABLE-BOUNDARY-START(47245753299)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteServiceOptions.RequestHeader.get
            get LCFCR$IRemoteServiceOptions$RequestHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720589779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RequestHeader;
            }
            //--TRIMMABLE-BOUNDARY-END(47245753299)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<LivingThing.Core.Frameworks.Common.RPC.RemoteProxyExecutionContext>.Equals(LivingThing.Core.Frameworks.Common.RPC.RemoteProxyExecutionContext?)
            S$IEquatable$LivingThing$Core$Frameworks$Common$RPC$RemoteProxyExecutionContext$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(77311114195)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311114195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77311114195)
            
            //--TRIMMABLE-BOUNDARY-START(77311114195)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(77311114195)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.RunInBackground = this.RunInBackground;
                copy.ServerCache = this.ServerCache;
                copy.DataCache = this.DataCache;
                copy.CachePeriod = this.CachePeriod?.$clone() ?? null;
                copy.CacheKey = this.CacheKey;
                copy.TimeOut = this.TimeOut;
                copy.Retries = this.Retries;
                copy.Authenticate = this.Authenticate;
                copy.CloneResponse = this.CloneResponse;
                copy.Encrypt = this.Encrypt;
                copy.RequestHeader = this.RequestHeader;
                copy.Batching = this.Batching;
                copy.InBatchIndex = this.InBatchIndex;
                copy.HashServiceName = this.HashServiceName;
                copy.ServiceParameterSetter = this.ServiceParameterSetter;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(98785950675)
                this.CachePeriod = null;
                //--TRIMMABLE-BOUNDARY-END(98785950675)
                
            }
            //--TRIMMABLE-BOUNDARY-START(73016146899)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016146899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(111670852563)
                    this.Default = new $.$uvJL.LCFCR.RemoteProxyExecutionContext().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(111670852563)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016146899)
            
            //Begin generated record members
            /*Type*/ get EqualityContract() { return $.$typeOf($.$uvJL.LCFCR.RemoteProxyExecutionContext); }
            /*string*/ ToString()
            {
                let stringBuilder = new $.$$.ST.StringBuilder().$ctor$1();
                stringBuilder.Append$21("RemoteProxyExecutionContext");
                stringBuilder.Append$21("{");
                if (this.PrintMembers(stringBuilder))
                {
                    stringBuilder.Append$21(" ");
                }
                stringBuilder.Append$21("}");
                return stringBuilder.ToString();
            }
            /*bool*/ PrintMembers(/*StringBuilder*/ stringBuilder)
            {
                stringBuilder.Append$21("RunInBackground = ");
                stringBuilder.Append$21(this.RunInBackground.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ServerCache = ");
                stringBuilder.Append$21($.$dsp(this.ServerCache, $.$$.S.Object, ($t) => $t.ToString));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("DataCache = ");
                stringBuilder.Append$21($.$dsp(this.DataCache, $.$$.S.Object, ($t) => $t.ToString));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("CachePeriod = ");
                stringBuilder.Append$21(this.CachePeriod.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("CacheKey = ");
                stringBuilder.Append$21(this.CacheKey);
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("TimeOut = ");
                stringBuilder.Append$21(this.TimeOut.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Retries = ");
                stringBuilder.Append$21(this.Retries.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Authenticate = ");
                stringBuilder.Append$21(this.Authenticate.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("CloneResponse = ");
                stringBuilder.Append$21(this.CloneResponse.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Encrypt = ");
                stringBuilder.Append$21(this.Encrypt.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("RequestHeader = ");
                stringBuilder.Append$21($.$dsp(this.RequestHeader, $.$$.S.Object, ($t) => $t.ToString));
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("Batching = ");
                stringBuilder.Append$21(this.Batching.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("InBatchIndex = ");
                stringBuilder.Append$21(this.InBatchIndex.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("HashServiceName = ");
                stringBuilder.Append$21(this.HashServiceName.ToString());
                stringBuilder.Append$21(", ");
                stringBuilder.Append$21("ServiceParameterSetter = ");
                stringBuilder.Append$21($.$dsp(this.ServiceParameterSetter, $.$$.S.Object, ($t) => $t.ToString));
                return true;
            }
            /*bool*/ Equals$2(/*RemoteProxyExecutionContext*/ other)
            {
                return this === other || (other !== null && this.EqualityContract == other.EqualityContract && this.RunInBackground === other.RunInBackground && $.$$.SCG.EqualityComparer$$($.$fPer.LCFCS$5.ICacheProvider).Default.Equals$2(this.ServerCache, other.ServerCache) && $.$$.SCG.EqualityComparer$$($.$fPer.LCFCS$5.IDataCacheStorageService).Default.Equals$2(this.DataCache, other.DataCache) && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.TimeSpan)).Default.Equals$2(this.CachePeriod, other.CachePeriod) && $.$$.S.String.op_Equality(this.CacheKey, other.CacheKey) && this.TimeOut === other.TimeOut && this.Retries === other.Retries && this.Authenticate === other.Authenticate && this.CloneResponse === other.CloneResponse && this.Encrypt === other.Encrypt && $.$$.SCG.EqualityComparer$$($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String)).Default.Equals$2(this.RequestHeader, other.RequestHeader) && this.Batching === other.Batching && this.InBatchIndex === other.InBatchIndex && this.HashServiceName === other.HashServiceName && $.$$.SCG.EqualityComparer$$($.$$.S.Action$$($.$$.S.Object)).Default.Equals$2(this.ServiceParameterSetter, other.ServiceParameterSetter));
            }
            /*int*/ GetHashCode()
            {
                return $.$$.SCG.EqualityComparer$$($.$$.S.Type).Default.GetHashCode$1(this.EqualityContract) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Boolean)).Default.GetHashCode$1(this.RunInBackground) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$fPer.LCFCS$5.ICacheProvider).Default.GetHashCode$1(this.ServerCache) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$fPer.LCFCS$5.IDataCacheStorageService).Default.GetHashCode$1(this.DataCache) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.TimeSpan)).Default.GetHashCode$1(this.CachePeriod) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.String).Default.GetHashCode$1(this.CacheKey) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Int32)).Default.GetHashCode$1(this.TimeOut) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Int32)).Default.GetHashCode$1(this.Retries) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Boolean)).Default.GetHashCode$1(this.Authenticate) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Boolean)).Default.GetHashCode$1(this.CloneResponse) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Boolean)).Default.GetHashCode$1(this.Encrypt) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String)).Default.GetHashCode$1(this.RequestHeader) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Boolean)).Default.GetHashCode$1(this.Batching) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Int32)).Default.GetHashCode$1(this.InBatchIndex) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Nullable$$($.$$.S.Boolean)).Default.GetHashCode$1(this.HashServiceName) * -1521134295 && $.$$.SCG.EqualityComparer$$($.$$.S.Action$$($.$$.S.Object)).Default.GetHashCode$1(this.ServiceParameterSetter) * -1521134295;
            }
            static /*bool*/ op_Inequality(/*RemoteProxyExecutionContext*/ left, /*RemoteProxyExecutionContext*/ right)
            {
                return !(this.op_Equality(left, right));
            }
            static /*bool*/ op_Equality(/*RemoteProxyExecutionContext*/ left, /*RemoteProxyExecutionContext*/ right)
            {
                return left === right || (left !== null && left.Equals$2(right));
            }
            Deconstruct(/*out bool?*/ $RunInBackground, /*out LivingThing.Core.Frameworks.Common.Storage.ICacheProvider?*/ $ServerCache, /*out LivingThing.Core.Frameworks.Common.Storage.IDataCacheStorageService?*/ $DataCache, /*out System.TimeSpan?*/ $CachePeriod, /*out string?*/ $CacheKey, /*out int?*/ $TimeOut, /*out int?*/ $Retries, /*out bool?*/ $Authenticate, /*out bool?*/ $CloneResponse, /*out bool?*/ $Encrypt, /*out System.Collections.Generic.IDictionary<string, string?>?*/ $RequestHeader, /*out bool?*/ $Batching, /*out int?*/ $InBatchIndex, /*out bool?*/ $HashServiceName, /*out System.Action<object>?*/ $ServiceParameterSetter)
            {
                $RunInBackground.$v = this.RunInBackground;
                $ServerCache.$v = this.ServerCache;
                $DataCache.$v = this.DataCache;
                $CachePeriod.$v = this.CachePeriod;
                $CacheKey.$v = this.CacheKey;
                $TimeOut.$v = this.TimeOut;
                $Retries.$v = this.Retries;
                $Authenticate.$v = this.Authenticate;
                $CloneResponse.$v = this.CloneResponse;
                $Encrypt.$v = this.Encrypt;
                $RequestHeader.$v = this.RequestHeader;
                $Batching.$v = this.Batching;
                $InBatchIndex.$v = this.InBatchIndex;
                $HashServiceName.$v = this.HashServiceName;
                $ServiceParameterSetter.$v = this.ServiceParameterSetter;
            }
            //End generated record member3s
            static $h = 1702867;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120260787155),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197570198483,
        "f": 50331780
      },
      "n": "EqualityContract",
      "d": 1702867,
      "h": 120260787155,
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(120260787155),
//--TRIMMABLE-BOUNDARY-START(313534315475),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249109806035,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 433793399763,
        "f": 83886081
      },
      "n": "RunInBackground",
      "d": 1702867,
      "h": 313534315475,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313534315475),
//--TRIMMABLE-BOUNDARY-START(317829282771),
    {
      "p": 63801686,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257699740627,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 442383334355,
        "f": 83886081
      },
      "n": "ServerCache",
      "d": 1702867,
      "h": 317829282771,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(317829282771),
//--TRIMMABLE-BOUNDARY-START(107375885267),
    {
      "p": 63867222,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180390329299,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373663857619,
        "f": 83886081
      },
      "n": "DataCache",
      "d": 1702867,
      "h": 107375885267,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375885267),
//--TRIMMABLE-BOUNDARY-START(98785950675),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210460115,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356483988435,
        "f": 83886081
      },
      "n": "CachePeriod",
      "d": 1702867,
      "h": 98785950675,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785950675),
//--TRIMMABLE-BOUNDARY-START(94490983379),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620525523,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347894053843,
        "f": 83886081
      },
      "n": "CacheKey",
      "d": 1702867,
      "h": 94490983379,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490983379),
//--TRIMMABLE-BOUNDARY-START(468153138131),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274879609811,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 459563203539,
        "f": 83886081
      },
      "n": "TimeOut",
      "d": 1702867,
      "h": 468153138131,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(468153138131),
//--TRIMMABLE-BOUNDARY-START(309239348179),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240519871443,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 425203465171,
        "f": 83886081
      },
      "n": "Retries",
      "d": 1702867,
      "h": 309239348179,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309239348179),
//--TRIMMABLE-BOUNDARY-START(85901048787),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440656339,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330714184659,
        "f": 83886081
      },
      "n": "Authenticate",
      "d": 1702867,
      "h": 85901048787,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85901048787),
//--TRIMMABLE-BOUNDARY-START(103080917971),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171800394707,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365073923027,
        "f": 83886081
      },
      "n": "CloneResponse",
      "d": 1702867,
      "h": 103080917971,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080917971),
//--TRIMMABLE-BOUNDARY-START(115965819859),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188980263891,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 382253792211,
        "f": 83886081
      },
      "n": "Encrypt",
      "d": 1702867,
      "h": 115965819859,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965819859),
//--TRIMMABLE-BOUNDARY-START(304944380883),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231929936851,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 416613530579,
        "f": 83886081
      },
      "n": "RequestHeader",
      "d": 1702867,
      "h": 304944380883,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304944380883),
//--TRIMMABLE-BOUNDARY-START(90196016083),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030590931,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339304119251,
        "f": 83886081
      },
      "n": "Batching",
      "d": 1702867,
      "h": 90196016083,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196016083),
//--TRIMMABLE-BOUNDARY-START(287764511699),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214750067667,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 399433661395,
        "f": 83886081
      },
      "n": "InBatchIndex",
      "d": 1702867,
      "h": 287764511699,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287764511699),
//--TRIMMABLE-BOUNDARY-START(283469544403),
    {
      "p": $.$typeNullable($.$$.S.Boolean).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206160133075,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 390843726803,
        "f": 83886081
      },
      "n": "HashServiceName",
      "d": 1702867,
      "h": 283469544403,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283469544403),
//--TRIMMABLE-BOUNDARY-START(322124250067),
    {
      "p": $.$$.S.Action$$($.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266289675219,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 450973268947,
        "f": 83886081
      },
      "n": "ServiceParameterSetter",
      "d": 1702867,
      "h": 322124250067,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(322124250067),
//--TRIMMABLE-BOUNDARY-START(463858170835),
    {
      "p": 1310721,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 223340002259,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 408023595987,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 1702867,
      "h": 463858170835,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(463858170835)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(472448105427),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1702867,
      "h": 472448105427,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(472448105427),
//--TRIMMABLE-BOUNDARY-START(300649413587),
    {
      "r": 262145,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        }
      ],
      "n": "PrintMembers",
      "d": 1702867,
      "h": 300649413587,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(300649413587),
//--TRIMMABLE-BOUNDARY-START(279174577107),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1702867,
      "h": 279174577107,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(279174577107),
//--TRIMMABLE-BOUNDARY-START(124555754451),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1702867,
      "h": 124555754451,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555754451),
//--TRIMMABLE-BOUNDARY-START(128850721747),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1702867
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1702867,
      "h": 128850721747,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(128850721747),
//--TRIMMABLE-BOUNDARY-START(21476539347),
    {
      "r": 1702867,
      "n": "\u003CClone\u003E$",
      "o": "$$$",
      "d": 1702867,
      "h": 21476539347,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21476539347)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(111670852563),
    {
      "t": 1702867,
      "n": "Default",
      "d": 1702867,
      "h": 111670852563,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670852563)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(81606081491),
    {
      "p": [
        {
          "n": "original",
          "p": 1702867
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1702867,
      "h": 81606081491,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(81606081491),
//--TRIMMABLE-BOUNDARY-START(77311114195),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1702867,
      "h": 77311114195,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311114195)
  ],
  "h": 1702867
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IRemoteServiceOptions, $.$$.S.IEquatable$$($.$uvJL.LCFCR.RemoteProxyExecutionContext) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyExecutionContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyExecutionContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1702867)
        
        

        //--TRIMMABLE-BOUNDARY-START(457683)
        $asm.$cls(`$uvJL.LCFCR.Enumerator<>`, (TDataModel) => $asm.$gt(`$uvJL.LCFCR.Enumerator<>`, [TDataModel], ($self) => class Enumerator$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360196051)
            /*int*/ index = -1;
            //--TRIMMABLE-BOUNDARY-END(34360196051)
            
            //--TRIMMABLE-BOUNDARY-START(21475294163)
            /*EnumerableRemoteService<TDataModel>*/ enumerableService = null;
            //--TRIMMABLE-BOUNDARY-END(21475294163)
            
            //--TRIMMABLE-BOUNDARY-START(4295424979)
            $ctor$1(/*EnumerableRemoteService<TDataModel>*/ _enumerableService)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295424979);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.enumerableService = _enumerableService;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295424979)
            
            //--TRIMMABLE-BOUNDARY-START(8590392275)
            /*TDataModel */ get Current()
            {
                return $.$$.System.Array.$ReadT1.call(this.enumerableService.Data, this.index);
            }
            //--TRIMMABLE-BOUNDARY-END(8590392275)
            
            //--TRIMMABLE-BOUNDARY-START(12885359571)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885359571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885359571)
            
            //--TRIMMABLE-BOUNDARY-START(17180326867)
            /*ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180326867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.STT.ValueTask().$ctor$5($.$$.STT.Task.CompletedTask);
            }
            //--TRIMMABLE-BOUNDARY-END(17180326867)
            
            //--TRIMMABLE-BOUNDARY-START(38655163347)
            /*bool */ MoveNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655163347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.enumerableService.Load().GetAwaiter().GetResult();
                if (this.enumerableService.Data !== null)
                {
                    if (this.index < ((this.enumerableService.Data.length - 1) | 0))
                    {
                        this.index++;
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(38655163347)
            
            //--TRIMMABLE-BOUNDARY-START(42950130643)
            /*ValueTask<bool> *//*async*/  MoveNextAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950130643);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.enumerableService.Load(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (this.index < ((this.enumerableService.Data.length - 1) | 0))
                    {
                        this.index++;
                        return $.$$.N.AsyncResolver.Result($asnycContext, true);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, false);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(42950130643)
            
            //--TRIMMABLE-BOUNDARY-START(47245097939)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245097939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.index = -1;
            }
            //--TRIMMABLE-BOUNDARY-END(47245097939)
            
            //--TRIMMABLE-BOUNDARY-START(17239834625)
            //Generated interface implemetation for System.Collections.Generic.IAsyncEnumerator<TDataModel>.MoveNextAsync()
            SCG$IAsyncEnumerator$$$MoveNextAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239834625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MoveNextAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239834625)
            
            //--TRIMMABLE-BOUNDARY-START(12944867329)
            //Generated interface implemetation for System.Collections.Generic.IAsyncEnumerator<TDataModel>.Current.get
            get SCG$IAsyncEnumerator$$$Current()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354932737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Current;
            }
            //--TRIMMABLE-BOUNDARY-END(12944867329)
            
            //--TRIMMABLE-BOUNDARY-START(4385472513)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            S$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385472513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385472513)
            
            static $H = 457683;
            static $h = 457683;
            static $g = 1;
            static $f = 0b1010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590392275),
    {
      "p": TDataModel?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30065228755,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "Current",
      "d": this.$h,
      "H": 8590392275,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590392275)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885359571),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 12885359571,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885359571),
//--TRIMMABLE-BOUNDARY-START(17180326867),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": this.$h,
      "H": 17180326867,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180326867),
//--TRIMMABLE-BOUNDARY-START(38655163347),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": this.$h,
      "H": 38655163347,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655163347),
//--TRIMMABLE-BOUNDARY-START(42950130643),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "n": "MoveNextAsync",
      "d": this.$h,
      "H": 42950130643,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(42950130643),
//--TRIMMABLE-BOUNDARY-START(47245097939),
    {
      "r": 65537,
      "n": "Reset",
      "d": this.$h,
      "H": 47245097939,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245097939)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360196051),
    {
      "t": 655361,
      "n": "index",
      "d": this.$h,
      "H": 34360196051,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360196051),
//--TRIMMABLE-BOUNDARY-START(21475294163),
    {
      "t": $.$uvJL.LCFCR.EnumerableRemoteService$$(TDataModel).$h,
      "n": "enumerableService",
      "d": this.$h,
      "H": 21475294163,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475294163)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295424979),
    {
      "p": [
        {
          "n": "_enumerableService",
          "p": $.$uvJL.LCFCR.EnumerableRemoteService$$(TDataModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4295424979,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295424979)
  ],
  "s": [
    {
      "h": TDataModel?.$h??1572864,
      "n": "TDataModel"
    }
  ],
  "r": 1,
  "H": 457683,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IAsyncEnumerator$$(TDataModel), $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.Enumerator<${TDataModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}Enumerator$${TDataModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(457683)
        
        

        //--TRIMMABLE-BOUNDARY-START(392147)
        $asm.$cls(`$uvJL.LCFCR.EnumerableRemoteService<>`, (TDataModel) => $asm.$gt(`$uvJL.LCFCR.EnumerableRemoteService<>`, [TDataModel], ($self) => class EnumerableRemoteService$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115964509139)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(115964509139)
            
            //--TRIMMABLE-BOUNDARY-START(42950065107)
            /*TDataModel[]*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(42950065107)
            
            //--TRIMMABLE-BOUNDARY-START(25770195923)
            $ctor$1(/*IFilteringServerRemoteService*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770195923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                    this.Filter = server.LCFCR$IFilteringServerRemoteService$Filter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770195923)
            
            //--TRIMMABLE-BOUNDARY-START(30065163219)
            $ctor$2(/*IServerRemoteService*/ server, /*DataFilter*/ filter)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065163219);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Server = server;
                    this.Filter = filter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065163219)
            
            //--TRIMMABLE-BOUNDARY-START(34360130515)
            /*int*/ Count = 0;
            //--TRIMMABLE-BOUNDARY-END(34360130515)
            
            //--TRIMMABLE-BOUNDARY-START(38655097811)
            /*int*/ CurrentPage = 0;
            //--TRIMMABLE-BOUNDARY-END(38655097811)
            
            //--TRIMMABLE-BOUNDARY-START(111669541843)
            /*int*/ PageSize = 0;
            //--TRIMMABLE-BOUNDARY-END(111669541843)
            
            //--TRIMMABLE-BOUNDARY-START(47245032403)
            /*DataFilter*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(47245032403)
            
            //--TRIMMABLE-BOUNDARY-START(103079607251)
            /*int*/ loadedPage = 0;
            //--TRIMMABLE-BOUNDARY-END(103079607251)
            
            //--TRIMMABLE-BOUNDARY-START(107374574547)
            /*int*/ loadedSize = 0;
            //--TRIMMABLE-BOUNDARY-END(107374574547)
            
            //--TRIMMABLE-BOUNDARY-START(98784639955)
            /*Task *//*async*/  Load()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784639955);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.Data === null || this.loadedPage !== this.CurrentPage || this.loadedSize !== this.PageSize)
                    {
                        let service = null;
                        try
                        {
                            let $t1, $r1;
                            service = this.Server.LCFCR$IServerRemoteService$GetRemoteService($.$uvJL.LCFCR.ICRUDDataRemoteService$$(TDataModel), null);
                            /*var*/ let response = ($t1 = service.LCFCS$3$IServiceProxy$$$Service[`LCFCD$IReadManyDataService$${TDataModel.$getFullName('$')}$ReadMany`]($.$with(this.Filter, ($clone) =>
                            {
                                $clone.Page = this.CurrentPage;
                                $clone.Count = this.PageSize;
                            }), null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                            this.loadedPage = this.CurrentPage;
                            this.loadedSize = this.PageSize;
                            if (response.Success)
                            {
                                this.Count = response.TotalCount;
                                this.Data = $.$sl.SL.Enumerable.ToArray(TDataModel, response.Data);
                            }
                        }
                        finally
                        {
                            service?.S$IDisposable$Dispose();
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(98784639955)
            
            //--TRIMMABLE-BOUNDARY-START(94489672659)
            /*IAsyncEnumerator<TDataModel> */ GetAsyncEnumerator(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489672659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$uvJL.LCFCR.Enumerator$$(TDataModel))().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(94489672659)
            
            //--TRIMMABLE-BOUNDARY-START(17180916691)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteEnumerable<TDataModel>.Count.get
            get LCFCR$IRemoteEnumerable$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296014803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17180916691)
            
            //--TRIMMABLE-BOUNDARY-START(25770851283)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteEnumerable<TDataModel>.CurrentPage.get
            get LCFCR$IRemoteEnumerable$$$CurrentPage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590982099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentPage;
            }
            //--TRIMMABLE-BOUNDARY-END(25770851283)
            
            //--TRIMMABLE-BOUNDARY-START(47245687763)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteEnumerable<TDataModel>.CurrentPage.set
            set LCFCR$IRemoteEnumerable$$$CurrentPage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590982099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CurrentPage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47245687763)
            
            //--TRIMMABLE-BOUNDARY-START(34360785875)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteEnumerable<TDataModel>.PageSize.get
            get LCFCR$IRemoteEnumerable$$$PageSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655753171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PageSize;
            }
            //--TRIMMABLE-BOUNDARY-END(34360785875)
            
            //--TRIMMABLE-BOUNDARY-START(55835622355)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.RPC.IRemoteEnumerable<TDataModel>.PageSize.set
            set LCFCR$IRemoteEnumerable$$$PageSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655753171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.PageSize = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55835622355)
            
            //--TRIMMABLE-BOUNDARY-START(4354867201)
            //Generated interface implemetation for System.Collections.Generic.IAsyncEnumerable<TDataModel>.GetAsyncEnumerator(System.Threading.CancellationToken)
            [`SCG$IAsyncEnumerable$${TDataModel.$getFullName('$')}$GetAsyncEnumerator`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354867201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAsyncEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354867201)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38655097811)
                this.CurrentPage = 1;
                //--TRIMMABLE-BOUNDARY-END(38655097811)
                
                //--TRIMMABLE-BOUNDARY-START(111669541843)
                this.PageSize = 2147483647;
                //--TRIMMABLE-BOUNDARY-END(111669541843)
                
            }
            static $H = 392147;
            static $h = 392147;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950065107),
    {
      "p": $.$typeArray(TDataModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73014836179,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 141734312915,
        "h": Number(BigInt(this.$h)|0x2100000000n),
        "f": 83886082
      },
      "n": "Data",
      "d": this.$h,
      "H": 42950065107,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(42950065107),
//--TRIMMABLE-BOUNDARY-START(34360130515),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55834966995,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 124554443731,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 83886081
      },
      "n": "Count",
      "d": this.$h,
      "H": 34360130515,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360130515),
//--TRIMMABLE-BOUNDARY-START(38655097811),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64424901587,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 133144378323,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 83886081
      },
      "n": "CurrentPage",
      "d": this.$h,
      "H": 38655097811,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655097811),
//--TRIMMABLE-BOUNDARY-START(111669541843),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90194705363,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 150324247507,
        "h": Number(BigInt(this.$h)|0x2300000000n),
        "f": 83886081
      },
      "n": "PageSize",
      "d": this.$h,
      "H": 111669541843,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669541843),
//--TRIMMABLE-BOUNDARY-START(47245032403),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81604770771,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331656
      },
      "n": "Filter",
      "d": this.$h,
      "H": 47245032403,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(47245032403)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98784639955),
    {
      "r": 178454529,
      "n": "Load",
      "d": this.$h,
      "H": 98784639955,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(98784639955),
//--TRIMMABLE-BOUNDARY-START(94489672659),
    {
      "r": $.$$.SCG.IAsyncEnumerator$$(TDataModel).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "GetAsyncEnumerator",
      "d": this.$h,
      "H": 94489672659,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489672659)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(115964509139),
    {
      "t": 1309651,
      "n": "Server",
      "d": this.$h,
      "H": 115964509139,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115964509139),
//--TRIMMABLE-BOUNDARY-START(103079607251),
    {
      "t": 655361,
      "n": "loadedPage",
      "d": this.$h,
      "H": 103079607251,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(103079607251),
//--TRIMMABLE-BOUNDARY-START(107374574547),
    {
      "t": 655361,
      "n": "loadedSize",
      "d": this.$h,
      "H": 107374574547,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(107374574547)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770195923),
    {
      "p": [
        {
          "n": "server",
          "p": 850899
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 25770195923,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770195923),
//--TRIMMABLE-BOUNDARY-START(30065163219),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 30065163219,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065163219)
  ],
  "s": [
    {
      "h": TDataModel?.$h??1572864,
      "n": "TDataModel"
    }
  ],
  "r": 1,
  "H": 392147,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.IRemoteEnumerable$$(TDataModel), $.$$.SCG.IAsyncEnumerable$$(TDataModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.EnumerableRemoteService<${TDataModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}EnumerableRemoteService$${TDataModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(392147)
        
        

        //--TRIMMABLE-BOUNDARY-START(2751443)
        $asm.$cls(`$uvJL.LCFCR.RemoteSchemaOptionReader<>`, (T) => $asm.$gt(`$uvJL.LCFCR.RemoteSchemaOptionReader<>`, [T], ($self) => class RemoteSchemaOptionReader$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30067522515)
            /*IServerRemoteService*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(30067522515)
            
            //--TRIMMABLE-BOUNDARY-START(8592686035)
            /*IDataCacheStorageService*/ cache = null;
            //--TRIMMABLE-BOUNDARY-END(8592686035)
            
            //--TRIMMABLE-BOUNDARY-START(25772555219)
            /*IOptions<RemoteSchemaReaderOption<T>>*/ options = null;
            //--TRIMMABLE-BOUNDARY-END(25772555219)
            
            //--TRIMMABLE-BOUNDARY-START(12887653331)
            /*DataFilter */ GetFilter(/*object?*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schemaContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887653331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this.options[`MEO$IOptions$LivingThing$Core$Frameworks$Common$RPC$RemoteSchemaReaderOption$${T.$getFullName('$')}$$Value`]?.Filter ?? null) ?? $.$fPer.LCFCD.DataFilter.Default;
            }
            //--TRIMMABLE-BOUNDARY-END(12887653331)
            
            //--TRIMMABLE-BOUNDARY-START(4297718739)
            $ctor$1(/*IServerRemoteService*/ server, /*IDataCacheStorageService*/ cache, /*IOptions<RemoteSchemaReaderOption<T>>*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297718739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                    this.cache = cache;
                    this.options = options;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297718739)
            
            //--TRIMMABLE-BOUNDARY-START(17182620627)
            /*Pager<ISelectOption<IEnumerable<T>?>>? */ [`LCFCA$1$ISchemaOptionReader$System$Collections$Generic$IEnumerable$${T.$getFullName('$')}$$GetOptions`](/*object?*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schemaContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182620627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.ToList($.$fPer.LCFC.ISelectOption$$($.$$.SCG.IEnumerable$$(T)), $.$fPer.LCFCD.Paging.Select(T, $.$fPer.LCFC.ISelectOption$$($.$$.SCG.IEnumerable$$(T)), $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager(T, this.server, this.GetFilter(model, typeOrProperty, $.$clone(schemaContext)), (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyExecutionContext()
                    const $t1 = $.$uvJL.LCFCR.RemoteProxyExecutionContext;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.DataCache = this.cache;
                    $i1.CachePeriod = $.$$.S.TimeSpan.FromMinutes$2(5n);
                    return $i1;
                })()), new ($.$$.S.Func$$$(T, $.$fPer.LCFC.ISelectOption$$($.$$.SCG.IEnumerable$$(T))))().$ctor(this,  (/*c*/ c) =>
                {
                    return (() =>
                    {
                        //new $.$fPer.LCFC.SelectOption$$($.$$.SCG.IEnumerable$$(T))()
                        const $t2 = $.$fPer.LCFC.SelectOption$$($.$$.SCG.IEnumerable$$(T));
                        const $i2 = new $t2();
                        $i2.$ctor$3($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), [c], null, null));
                        $i2.Title = (($.$as(c, $.$fPer.LCFC.IDisplayable))?.LCFC$IDisplayable$Title ?? null);
                        return $i2;
                    })();
                }, $BuweHi ??= {"r":$.$fPer.LCFC.ISelectOption$$($.$$.SCG.IEnumerable$$(T)).$h,"p":[{"n":"c","p":T?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(17182620627)
            
            //--TRIMMABLE-BOUNDARY-START(21477587923)
            /*Pager<ISelectOption<T?>>? */ [`LCFCA$1$ISchemaOptionReader$${T.$getFullName('$')}$GetOptions`](/*object?*/ model, /*OneOf<Type, IPropertyDescriptor>*/ typeOrProperty, /*SchemaContext*/ schemaContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477587923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCD.Paging.ToList($.$fPer.LCFC.ISelectOption$$(T), $.$fPer.LCFCD.Paging.Select(T, $.$fPer.LCFC.ISelectOption$$(T), $.$uvJL.LCFCR.ServerRemoteServiceExtension.GetPager(T, this.server, this.GetFilter(model, typeOrProperty, $.$clone(schemaContext)), (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyExecutionContext()
                    const $t3 = $.$uvJL.LCFCR.RemoteProxyExecutionContext;
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.DataCache = this.cache;
                    $i3.CachePeriod = $.$$.S.TimeSpan.FromMinutes$2(5n);
                    return $i3;
                })()), new ($.$$.S.Func$$$(T, $.$fPer.LCFC.ISelectOption$$(T)))().$ctor(this,  (/*c*/ c) =>
                {
                    return new ($.$fPer.LCFC.SelectOption$$(T))().$ctor$3(c);
                }, $PusKja ??= {"r":$.$fPer.LCFC.ISelectOption$$(T).$h,"p":[{"n":"c","p":T?.$h??1572864}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(21477587923)
            
            static $H = 2751443;
            static $h = 2751443;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887653331),
    {
      "r": 9734486,
      "p": [
        {
          "n": "model",
          "p": 131073
        },
        {
          "n": "typeOrProperty",
          "p": $.$fPer.LCFCO.OneOf$$$($.$$.S.Type, $.$fPer.LCFCD$1.IPropertyDescriptor).$h
        },
        {
          "n": "schemaContext",
          "p": 2394454
        }
      ],
      "n": "GetFilter",
      "d": this.$h,
      "H": 12887653331,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(12887653331)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067522515),
    {
      "t": 1309651,
      "n": "server",
      "d": this.$h,
      "H": 30067522515,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30067522515),
//--TRIMMABLE-BOUNDARY-START(8592686035),
    {
      "t": 63867222,
      "n": "cache",
      "d": this.$h,
      "H": 8592686035,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592686035),
//--TRIMMABLE-BOUNDARY-START(25772555219),
    {
      "t": $.$meo.MEO.IOptions$$($.$uvJL.LCFCR.RemoteSchemaReaderOption$$(T)).$h,
      "n": "options",
      "d": this.$h,
      "H": 25772555219,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25772555219)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297718739),
    {
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "cache",
          "p": 63867222
        },
        {
          "n": "options",
          "p": $.$meo.MEO.IOptions$$($.$uvJL.LCFCR.RemoteSchemaReaderOption$$(T)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4297718739,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297718739)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 2751443,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCA$1.ISchemaOptionReader$$($.$$.SCG.IEnumerable$$(T)), $.$fPer.LCFCA$1.ISchemaOptionReader$$(T) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteSchemaOptionReader<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteSchemaOptionReader$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2751443)
        
        

        //--TRIMMABLE-BOUNDARY-START(195539)
        $asm.$cls(`$uvJL.LCFCR.AuthorizeServiceAttribute`, ($self) => class AuthorizeServiceAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(21475032019)
            /*string?*/ Roles = null;
            //--TRIMMABLE-BOUNDARY-END(21475032019)
            
            //--TRIMMABLE-BOUNDARY-START(8590130131)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590130131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590130131)
            
            //--TRIMMABLE-BOUNDARY-START(8590130131)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590130131)
            
            static $h = 195539;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475032019),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180064723,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30064966611,
        "f": 83886081
      },
      "n": "Roles",
      "d": 195539,
      "h": 21475032019,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475032019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590130131),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 195539,
      "h": 8590130131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590130131)
  ],
  "h": 195539,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 64,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.AuthorizeServiceAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}AuthorizeServiceAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(195539)
        
        

        //--TRIMMABLE-BOUNDARY-START(2882515)
        $asm.$cls(`$uvJL.LCFCR.RemoteServiceAttribute`, ($self) => class RemoteServiceAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12887784403)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887784403);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887784403)
            
            //--TRIMMABLE-BOUNDARY-START(17182751699)
            $ctor$3(/*string*/ id)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182751699);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Id = id;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182751699)
            
            //--TRIMMABLE-BOUNDARY-START(38657588179)
            /*string?*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(38657588179)
            
            //--TRIMMABLE-BOUNDARY-START(60132424659)
            /*string?*/ Url = null;
            //--TRIMMABLE-BOUNDARY-END(60132424659)
            
            //--TRIMMABLE-BOUNDARY-START(12887784403)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887784403)
            
            static $h = 2882515;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38657588179),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772686291,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247522771,
        "f": 83886081
      },
      "n": "Id",
      "d": 2882515,
      "h": 38657588179,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657588179),
//--TRIMMABLE-BOUNDARY-START(60132424659),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362620883,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837457363,
        "f": 83886081
      },
      "n": "Url",
      "d": 2882515,
      "h": 60132424659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132424659)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887784403),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2882515,
      "h": 12887784403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887784403),
//--TRIMMABLE-BOUNDARY-START(17182751699),
    {
      "p": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2882515,
      "h": 17182751699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182751699)
  ],
  "h": 2882515,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1088,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteServiceAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteServiceAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2882515)
        
        

        //--TRIMMABLE-BOUNDARY-START(3013587)
        $asm.$cls(`$uvJL.LCFCR.RemoteServiceParameterAttribute`, ($self) => class RemoteServiceParameterAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12887915475)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887915475);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887915475)
            
            //--TRIMMABLE-BOUNDARY-START(21477850067)
            $ctor$4(/*string*/ name)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477850067);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477850067)
            
            //--TRIMMABLE-BOUNDARY-START(17182882771)
            $ctor$3(/*string*/ name, /*string*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182882771);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182882771)
            
            //--TRIMMABLE-BOUNDARY-START(42952686547)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(42952686547)
            
            //--TRIMMABLE-BOUNDARY-START(64427523027)
            /*string?*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(64427523027)
            
            //--TRIMMABLE-BOUNDARY-START(12887915475)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887915475)
            
            static $h = 3013587;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952686547),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067784659,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51542621139,
        "f": 83886081
      },
      "n": "Name",
      "d": 3013587,
      "h": 42952686547,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952686547),
//--TRIMMABLE-BOUNDARY-START(64427523027),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657719251,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132555731,
        "f": 83886081
      },
      "n": "Value",
      "d": 3013587,
      "h": 64427523027,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427523027)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887915475),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3013587,
      "h": 12887915475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887915475),
//--TRIMMABLE-BOUNDARY-START(21477850067),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3013587,
      "h": 21477850067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477850067),
//--TRIMMABLE-BOUNDARY-START(17182882771),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3013587,
      "h": 17182882771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182882771)
  ],
  "h": 3013587,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 132,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteServiceParameterAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteServiceParameterAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3013587)
        
        

        //--TRIMMABLE-BOUNDARY-START(2030547)
        $asm.$str(`$uvJL.LCFCR.RemoteProxyMethodParameter`, ($self) => class RemoteProxyMethodParameter extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38656736211)
            static /*RemoteProxyMethodParameter */ From(/*MockMethodParameter*/ mock)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656736211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyMethodParameter()
                    const $t1 = $.$uvJL.LCFCR.RemoteProxyMethodParameter;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Name = mock.Name;
                    $i1.Parameter = mock.Parameter;
                    $i1.ParameterType = mock.ParameterType;
                    $i1.Type = mock.Type;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(38656736211)
            
            //--TRIMMABLE-BOUNDARY-START(34361768915)
            $ctor$4(/*Type?*/ type, /*object?*/ parameter)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361768915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = null;
                    this.ParameterType = type;
                    /*System.Type?*/ let __ca1__;
                    /*string?*/ let __ca2__;
                    this.Type = ((__ca1__ = type) !== null ? ((__ca2__ = __ca1__.FullName) !== null ? $.$fPer.LCFC.EncryptUtility.QuickHash256$2(__ca2__, null) : null) : null);
                    this.Parameter = parameter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361768915)
            
            //--TRIMMABLE-BOUNDARY-START(30066801619)
            $ctor$3(/*string?*/ name, /*Type?*/ type, /*object?*/ parameter)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066801619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.ParameterType = type;
                    /*System.Type?*/ let __ca3__;
                    /*string?*/ let __ca4__;
                    this.Type = ((__ca3__ = type) !== null ? ((__ca4__ = __ca3__.FullName) !== null ? $.$fPer.LCFC.EncryptUtility.QuickHash256$2(__ca4__, null) : null) : null);
                    this.Parameter = parameter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066801619)
            
            //--TRIMMABLE-BOUNDARY-START(77311441875)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(77311441875)
            
            //--TRIMMABLE-BOUNDARY-START(137440984019)
            /*string?*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(137440984019)
            
            //--TRIMMABLE-BOUNDARY-START(85901376467)
            /*Type?*/ ParameterType = null;
            //--TRIMMABLE-BOUNDARY-END(85901376467)
            
            //--TRIMMABLE-BOUNDARY-START(81606409171)
            /*object?*/ Parameter = null;
            //--TRIMMABLE-BOUNDARY-END(81606409171)
            
            //--TRIMMABLE-BOUNDARY-START(4296997843)
            /*object? */ set _Parameter(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491311059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parameter = value;
            }
            //--TRIMMABLE-BOUNDARY-END(4296997843)
            
            //--TRIMMABLE-BOUNDARY-START(133146016723)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146016723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Type)} ${$.$strNN(this.Name)} = ${$.$strNN($.$dspc(this.Parameter, $.$$.S.Object, ($t) => $t.ToString))}`;
            }
            //--TRIMMABLE-BOUNDARY-END(133146016723)
            
            //--TRIMMABLE-BOUNDARY-START(25771834323)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771834323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771834323)
            
            //--TRIMMABLE-BOUNDARY-START(25771834323)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(25771834323)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.Type = this.Type;
                copy.ParameterType = this.ParameterType;
                copy.Parameter = this.Parameter;
                return copy;
            }
            static $h = 2030547;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311441875),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246670803,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103081245651,
        "f": 83886081
      },
      "n": "Name",
      "d": 2030547,
      "h": 77311441875,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "n",
              "t": 1310721
            }
          ]
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "n",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311441875),
//--TRIMMABLE-BOUNDARY-START(137440984019),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016474579,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128851049427,
        "f": 83886081
      },
      "n": "Type",
      "d": 2030547,
      "h": 137440984019,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "t",
              "t": 1310721
            }
          ]
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "t",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137440984019),
//--TRIMMABLE-BOUNDARY-START(85901376467),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426539987,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120261114835,
        "f": 83886081
      },
      "n": "ParameterType",
      "d": 2030547,
      "h": 85901376467,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85901376467),
//--TRIMMABLE-BOUNDARY-START(81606409171),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836605395,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111671180243,
        "f": 83886081
      },
      "n": "Parameter",
      "d": 2030547,
      "h": 81606409171,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "p",
              "t": 1310721
            }
          ]
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "p",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81606409171),
//--TRIMMABLE-BOUNDARY-START(4296997843),
    {
      "p": 131073,
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491311059,
        "f": 83886081
      },
      "n": "_Parameter",
      "d": 2030547,
      "h": 4296997843,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "parameter",
              "t": 1310721
            }
          ]
        },
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "parameter",
              "t": 1310721
            }
          ]
        },
        {
          "t": 104464385,
          "c": 21579300865
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296997843)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656736211),
    {
      "r": 2030547,
      "p": [
        {
          "n": "mock",
          "p": 1044294
        }
      ],
      "n": "From",
      "d": 2030547,
      "h": 38656736211,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656736211),
//--TRIMMABLE-BOUNDARY-START(133146016723),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2030547,
      "h": 133146016723,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133146016723)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361768915),
    {
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "parameter",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2030547,
      "h": 34361768915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361768915),
//--TRIMMABLE-BOUNDARY-START(30066801619),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "parameter",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2030547,
      "h": 30066801619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066801619),
//--TRIMMABLE-BOUNDARY-START(25771834323),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2030547,
      "h": 25771834323,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771834323)
  ],
  "h": 2030547,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    },
    {
      "t": 44665174,
      "c": 4339632470
    },
    {
      "t": 13631572,
      "c": 12898533460,
      "a": [
        {
          "v": 2161619,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyMethodParameter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2030547)
        
        

        //--TRIMMABLE-BOUNDARY-START(1768403)
        $asm.$str(`$uvJL.LCFCR.RemoteProxyMethodInfo`, ($self) => class RemoteProxyMethodInfo extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(77311179731)
            /*string*/ Service = null;
            //--TRIMMABLE-BOUNDARY-END(77311179731)
            
            //--TRIMMABLE-BOUNDARY-START(73016212435)
            /*int*/ RequestId = 0;
            //--TRIMMABLE-BOUNDARY-END(73016212435)
            
            //--TRIMMABLE-BOUNDARY-START(8591702995)
            /*string */ set _Service(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786016211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Service = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8591702995)
            
            //--TRIMMABLE-BOUNDARY-START(81606147027)
            /*IEnumerable<RemoteProxyMethodParameter>?*/ ServiceParameters = null;
            //--TRIMMABLE-BOUNDARY-END(81606147027)
            
            //--TRIMMABLE-BOUNDARY-START(68721245139)
            /*IEnumerable<RemoteProxyMethodParameter>?*/ Parameters = null;
            //--TRIMMABLE-BOUNDARY-END(68721245139)
            
            //--TRIMMABLE-BOUNDARY-START(4296735699)
            /*IEnumerable<RemoteProxyMethodParameter>? */ set _Parameters(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196081619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Parameters = value;
            }
            //--TRIMMABLE-BOUNDARY-END(4296735699)
            
            //--TRIMMABLE-BOUNDARY-START(141735689171)
            /*bool */ ShouldSerializeServiceParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735689171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter>?*/ let __ca1__;
                return ((__ca1__ = this.ServiceParameters) !== null ? $.$sl.SL.Enumerable.Any$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, __ca1__) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(141735689171)
            
            //--TRIMMABLE-BOUNDARY-START(137440721875)
            /*bool */ ShouldSerializeMethodParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440721875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter>?*/ let __ca2__;
                return ((__ca2__ = this.Parameters) !== null ? $.$sl.SL.Enumerable.Any$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, __ca2__) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(137440721875)
            
            //--TRIMMABLE-BOUNDARY-START(146030656467)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030656467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Service)}(${$.$strNN($.$$.S.String.Join$5(", ", $.$sl.SL.Enumerable.Select$1($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.String, this.Parameters, new ($.$$.S.Func$$$($.$uvJL.LCFCR.RemoteProxyMethodParameter, $.$$.S.String))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.ToString();
                }, $urnzOa ??= {"r":1310721,"p":[{"n":"p","p":2030547}],"n":"","d":1768403,"h":0,"f":17825794}))))})`;
            }
            //--TRIMMABLE-BOUNDARY-END(146030656467)
            
            //--TRIMMABLE-BOUNDARY-START(30066539475)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066539475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066539475)
            
            //--TRIMMABLE-BOUNDARY-START(30066539475)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(30066539475)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Service = this.Service;
                copy.RequestId = this.RequestId;
                copy.ServiceParameters = this.ServiceParameters;
                copy.Parameters = this.Parameters;
                return copy;
            }
            static $h = 1768403;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311179731),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836343251,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555819987,
        "f": 83886081
      },
      "n": "Service",
      "d": 1768403,
      "h": 77311179731,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "s",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311179731),
//--TRIMMABLE-BOUNDARY-START(73016212435),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246408659,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965885395,
        "f": 83886081
      },
      "n": "RequestId",
      "d": 1768403,
      "h": 73016212435,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "i",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73016212435),
//--TRIMMABLE-BOUNDARY-START(8591702995),
    {
      "p": 1310721,
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786016211,
        "f": 83886081
      },
      "n": "_Service",
      "d": 1768403,
      "h": 8591702995,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "service",
              "t": 1310721
            }
          ]
        },
        {
          "t": 104464385,
          "c": 21579300865
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591702995),
//--TRIMMABLE-BOUNDARY-START(81606147027),
    {
      "p": $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426277843,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145754579,
        "f": 83886081
      },
      "n": "ServiceParameters",
      "d": 1768403,
      "h": 81606147027,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "sp",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81606147027),
//--TRIMMABLE-BOUNDARY-START(68721245139),
    {
      "p": $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656474067,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375950803,
        "f": 83886081
      },
      "n": "Parameters",
      "d": 1768403,
      "h": 68721245139,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "ps",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68721245139),
//--TRIMMABLE-BOUNDARY-START(4296735699),
    {
      "p": $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter).$h,
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196081619,
        "f": 83886081
      },
      "n": "_Parameters",
      "d": 1768403,
      "h": 4296735699,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "parameters",
              "t": 1310721
            }
          ]
        },
        {
          "t": 104464385,
          "c": 21579300865
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296735699)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(141735689171),
    {
      "r": 262145,
      "n": "ShouldSerializeServiceParameters",
      "d": 1768403,
      "h": 141735689171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735689171),
//--TRIMMABLE-BOUNDARY-START(137440721875),
    {
      "r": 262145,
      "n": "ShouldSerializeMethodParameters",
      "d": 1768403,
      "h": 137440721875,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137440721875),
//--TRIMMABLE-BOUNDARY-START(146030656467),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1768403,
      "h": 146030656467,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146030656467)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066539475),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1768403,
      "h": 30066539475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066539475)
  ],
  "h": 1768403,
  "a": [
    {
      "t": 37980502,
      "c": 12922882390,
      "a": [
        {
          "v": [],
          "t": $.$typeArray($.$$.S.Type).$h
        }
      ]
    },
    {
      "t": 44665174,
      "c": 4339632470
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyMethodInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1768403)
        
        

        //--TRIMMABLE-BOUNDARY-START(3275731)
        $asm.$cls(`$uvJL.LCFCR.ServiceModelMethod<,>`, (TService, TModel) => $asm.$gt(`$uvJL.LCFCR.ServiceModelMethod<,>`, [TService, TModel], ($self) => class ServiceModelMethod$$$ extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Task<TModel>*/ Invoke(/**/ service)
            {
                return this.$nativeFunction.call(this.$target, service);
            }
            static $H = 3275731;
            static $h = 3275731;
            static $g = 2;
            static $f = 0b11000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183144915),
    {
      "r": $.$$.STT.Task$$(TModel).$h,
      "p": [
        {
          "n": "service",
          "p": TService?.$h??1572864
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 17183144915,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17183144915),
//--TRIMMABLE-BOUNDARY-START(8593210323),
    {
      "r": 90570753,
      "p": [
        {
          "n": "service",
          "p": TService?.$h??1572864
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "H": 8593210323,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8593210323),
//--TRIMMABLE-BOUNDARY-START(12888177619),
    {
      "r": $.$$.STT.Task$$(TModel).$h,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "H": 12888177619,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12888177619)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298243027),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4298243027,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298243027)
  ],
  "s": [
    {
      "h": TService?.$h??1572864,
      "n": "TService"
    },
    {
      "h": TModel?.$h??1638400,
      "n": "TModel"
    }
  ],
  "r": 2,
  "H": 3275731,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ServiceModelMethod<${TService?.$fullName},${TModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ServiceModelMethod$${TService?.$getFullName(separator)}$${TModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3275731)
        
        

        //--TRIMMABLE-BOUNDARY-START(3210195)
        $asm.$cls(`$uvJL.LCFCR.ServiceMethod<>`, (TService) => $asm.$gt(`$uvJL.LCFCR.ServiceMethod<>`, [TService], ($self) => class ServiceMethod$$ extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Task*/ Invoke(/**/ service)
            {
                return this.$nativeFunction.call(this.$target, service);
            }
            static $H = 3210195;
            static $h = 3210195;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183079379),
    {
      "r": 178454529,
      "p": [
        {
          "n": "service",
          "p": TService?.$h??1572864
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 17183079379,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17183079379),
//--TRIMMABLE-BOUNDARY-START(8593144787),
    {
      "r": 90570753,
      "p": [
        {
          "n": "service",
          "p": TService?.$h??1572864
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "H": 8593144787,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8593144787),
//--TRIMMABLE-BOUNDARY-START(12888112083),
    {
      "r": 178454529,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "H": 12888112083,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12888112083)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298177491),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4298177491,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298177491)
  ],
  "s": [
    {
      "h": TService?.$h??1572864,
      "n": "TService"
    }
  ],
  "r": 1,
  "H": 3210195,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ServiceMethod<${TService?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ServiceMethod$${TService?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3210195)
        
        

        //--TRIMMABLE-BOUNDARY-START(3341267)
        $asm.$cls(`$uvJL.LCFCR.ServicePagerMethod<,>`, (TService, TModel) => $asm.$gt(`$uvJL.LCFCR.ServicePagerMethod<,>`, [TService, TModel], ($self) => class ServicePagerMethod$$$ extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*Task<WireTransportManyModel<TModel>>*/ Invoke(/**/ service, /**/ filter)
            {
                return this.$nativeFunction.call(this.$target, service, filter);
            }
            static $H = 3341267;
            static $h = 3341267;
            static $g = 2;
            static $f = 0b11000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183210451),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(TModel)).$h,
      "p": [
        {
          "n": "service",
          "p": TService?.$h??1572864
        },
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 17183210451,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17183210451),
//--TRIMMABLE-BOUNDARY-START(8593275859),
    {
      "r": 90570753,
      "p": [
        {
          "n": "service",
          "p": TService?.$h??1572864
        },
        {
          "n": "filter",
          "p": 9734486
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "H": 8593275859,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8593275859),
//--TRIMMABLE-BOUNDARY-START(12888243155),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$(TModel)).$h,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "H": 12888243155,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12888243155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298308563),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4298308563,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298308563)
  ],
  "s": [
    {
      "h": TService?.$h??1572864,
      "n": "TService"
    },
    {
      "h": TModel?.$h??1638400,
      "n": "TModel"
    }
  ],
  "r": 2,
  "H": 3341267,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.ServicePagerMethod<${TService?.$fullName},${TModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}ServicePagerMethod$${TService?.$getFullName(separator)}$${TModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3341267)
        
        

        //--TRIMMABLE-BOUNDARY-START(981971)
        $asm.$cls(`$uvJL.LCFCR.IReadOnlyDataService<>`, (TDataModel) => $asm.$gt(`$uvJL.LCFCR.IReadOnlyDataService<>`, [TDataModel], ($self) => class IReadOnlyDataService$$
        {
            static $H = 981971;
            static $h = 981971;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": TDataModel?.$h??1572864,
      "n": "TDataModel"
    }
  ],
  "r": 1,
  "H": 981971,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IReadDataService$$$$(TDataModel, $.$fPer.LCFCD.WireTransportModel$$(TDataModel), $.$fPer.LCFCD.WireTransportManyModel$$(TDataModel)), $.$fPer.LCFCD.IReadManyDataService$$$$(TDataModel, $.$fPer.LCFCD.WireTransportModel$$(TDataModel), $.$fPer.LCFCD.WireTransportManyModel$$(TDataModel)), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.IReadOnlyDataService<${TDataModel?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}IReadOnlyDataService$${TDataModel?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(981971)
        
        

        //--TRIMMABLE-BOUNDARY-START(2161619)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyMethodParameterJsonConverter`, ($self) => class RemoteProxyMethodParameterJsonConverter extends $.$stj.STJS$1.JsonConverter$$($.$uvJL.LCFCR.RemoteProxyMethodParameter)
        {
            //--TRIMMABLE-BOUNDARY-START(8592096211)
            /*RemoteProxyMethodParameter */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592096211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (reader.$v.TokenType === 1/*JsonTokenType.StartObject*/)
                {
                    /*string?*/ let name = null;
                    /*string?*/ let type = null;
                    /*object?*/ let value = null;
                    while(reader.$v.Read())
                    {
                        if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                        {
                            /*string?*/ let propertyName = reader.$v.GetString();
                            reader.$v.Read();
                            switch(propertyName)
                            {
                                case "n":
                                name = reader.$v.GetString();
                                break;
                                case "t":
                                type = reader.$v.GetString();
                                break;
                                case "p":
                                value = $.$stj.STJ.JsonSerializer.Deserialize$24($.$$.S.Object, reader, options);
                                break;
                                default:
                                break;
                            }
                        }
                        else 
                        {
                            break;
                        }
                    }
                    if (reader.$v.TokenType === 2/*JsonTokenType.EndObject*/)
                    {
                        return (() =>
                        {
                            //new $.$uvJL.LCFCR.RemoteProxyMethodParameter()
                            const $t3 = $.$uvJL.LCFCR.RemoteProxyMethodParameter;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            $i3.Name = name;
                            $i3.Type = type;
                            $i3.Parameter = value;
                            return $i3;
                        })();
                    }
                }
                throw new $.$stj.STJ.JsonException().$ctor$10("Invalid json");
            }
            //--TRIMMABLE-BOUNDARY-END(8592096211)
            
            //--TRIMMABLE-BOUNDARY-START(12887063507)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*RemoteProxyMethodParameter*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887063507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                if (value.Name !== null)
                {
                    writer.WriteString$19("n", value.Name);
                }
                writer.WriteString$19("t", value.Type);
                writer.WritePropertyName$11("p");
                /*var*/ let typeInfo = value.ParameterType !== null ? $.$fPer.LCFCS$1.JsonSerializeExtension.TryGetTypeInfo(value.ParameterType) : null;
                if (typeInfo !== null)
                {
                    $.$stj.STJ.JsonSerializer.Serialize$6(writer, value.Parameter, typeInfo);
                }
                else if (value.ParameterType !== null)
                {
                    $.$stj.STJ.JsonSerializer.Serialize$7(writer, value.Parameter, value.ParameterType, options);
                }
                else 
                {
                    $.$stj.STJ.JsonSerializer.Serialize$11($.$$.S.Object, writer, value.Parameter, options);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(12887063507)
            
            //--TRIMMABLE-BOUNDARY-START(4297128915)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297128915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297128915)
            
            //--TRIMMABLE-BOUNDARY-START(4297128915)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297128915)
            
            static $h = 2161619;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonConverter$$($.$uvJL.LCFCR.RemoteProxyMethodParameter); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592096211),
    {
      "r": 2030547,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 2161619,
      "h": 8592096211,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8592096211),
//--TRIMMABLE-BOUNDARY-START(12887063507),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 2030547
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 2161619,
      "h": 12887063507,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12887063507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297128915),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2161619,
      "h": 4297128915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297128915)
  ],
  "h": 2161619
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameterJsonConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyMethodParameterJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2161619)
        
        

        //--TRIMMABLE-BOUNDARY-START(2423763)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyServiceMethodException`, ($self) => class RemoteProxyServiceMethodException extends $.$$.S.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(12887325651)
            $ctor$5(/*RemoteProxyServiceMethodExceptionModel*/ model, /*string?*/ message, /*string?*/ stackTrace, /*RemoteProxyServiceMethodException?*/ inner)
            {
                super.$ctor$3(message, inner);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887325651);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Info = model;
                    this._stackTrace = stackTrace;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887325651)
            
            //--TRIMMABLE-BOUNDARY-START(17182292947)
            $ctor$6(/*string?*/ message, /*RemoteProxyServiceMethodException*/ inner)
            {
                super.$ctor$3(message, inner);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182292947);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Info = inner.Info;
                    this._stackTrace = inner.StackTrace;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182292947)
            
            //--TRIMMABLE-BOUNDARY-START(51542031315)
            /*RemoteProxyServiceMethodException */ get OriginalException()
            {
                return this.InnerException === null ? this : ($.$cast(this.InnerException, $.$uvJL.LCFCR.RemoteProxyServiceMethodException)).OriginalException;
            }
            //--TRIMMABLE-BOUNDARY-END(51542031315)
            
            //--TRIMMABLE-BOUNDARY-START(4297391059)
            /*string?*/ _stackTrace = null;
            //--TRIMMABLE-BOUNDARY-END(4297391059)
            
            //--TRIMMABLE-BOUNDARY-START(55836998611)
            /*string? */ get StackTrace()
            {
                return this._stackTrace ?? super.StackTrace;
            }
            //--TRIMMABLE-BOUNDARY-END(55836998611)
            
            //--TRIMMABLE-BOUNDARY-START(47247064019)
            /*RemoteProxyServiceMethodExceptionModel*/ Info = null;
            //--TRIMMABLE-BOUNDARY-END(47247064019)
            
            static $h = 2423763;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Exception; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542031315),
    {
      "p": 2423763,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362162131,
        "f": 50331649
      },
      "n": "OriginalException",
      "d": 2423763,
      "h": 51542031315,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542031315),
//--TRIMMABLE-BOUNDARY-START(55836998611),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952096723,
        "f": 50364417
      },
      "n": "StackTrace",
      "d": 2423763,
      "h": 55836998611,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55836998611),
//--TRIMMABLE-BOUNDARY-START(47247064019),
    {
      "p": 2489299,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772227539,
        "f": 50331649
      },
      "n": "Info",
      "d": 2423763,
      "h": 47247064019,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247064019)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297391059),
    {
      "t": 1310721,
      "n": "_stackTrace",
      "d": 2423763,
      "h": 4297391059,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297391059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887325651),
    {
      "p": [
        {
          "n": "model",
          "p": 2489299
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "stackTrace",
          "p": 1310721
        },
        {
          "n": "inner",
          "p": 2423763
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2423763,
      "h": 12887325651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887325651),
//--TRIMMABLE-BOUNDARY-START(17182292947),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "inner",
          "p": 2423763
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2423763,
      "h": 17182292947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182292947)
  ],
  "h": 2423763
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyServiceMethodException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2423763)
        
        

        //--TRIMMABLE-BOUNDARY-START(2620371)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor`, ($self) => class RemoteProxyServiceMethodExceptionModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297587667)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297587667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor.GenerateProperties($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, this, factory);
                    }, $HmHIEb ??= {"r":65537,"n":"","d":2620371,"h":0,"f":17825794}), 0, "RemoteProxyServiceMethodExceptionModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC\\RemoteProxyServiceMethodExceptionModel_LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModelTypeDescriptorBuilder.g.cs", "RemoteProxyServiceMethodExceptionModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297587667)
            
            //--TRIMMABLE-BOUNDARY-START(12887522259)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887522259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)).Type);
                        }, $LrgJfl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2620371,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Type = value.AsReference($.$$.S.String);
                        }, $NUVJcf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2620371,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Message"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel.$type, $.$discardRef(), "Message", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Message")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Message";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)).Message);
                        }, $TQLWXh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2620371,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Message = value.AsReference($.$$.S.String);
                        }, $eXhNYc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2620371,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("StackTrace"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel.$type, $.$discardRef(), "StackTrace", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("StackTrace")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "StackTrace";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)).StackTrace);
                        }, $MyuhXc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2620371,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.StackTrace = value.AsReference($.$$.S.String);
                        }, $DCpujj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2620371,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("InnerException"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel.$type, $.$discardRef(), "InnerException", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("InnerException")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "InnerException";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)).InnerException);
                        }, $VyttVd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2620371,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.InnerException = value.AsReference($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel);
                        }, $ulwMEh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2620371,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("InnerExceptions"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel.$type, $.$discardRef(), "InnerExceptions", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("InnerExceptions")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "InnerExceptions";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel), ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)).InnerExceptions);
                        }, $KVVANe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2620371,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.InnerExceptions = value.AsReference($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel));
                        }, $yIubHj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2620371,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887522259)
            
            //--TRIMMABLE-BOUNDARY-START(17182489555)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182489555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Type, ($v) => _Type = $v, $.$$.S.String)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _Message = _target.Message;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Message"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Message, ($v) => _Message = $v, $.$$.S.String)))
                    {
                        _target.Message = _Message;
                    }
                }
                {
                    /*var*/ let _StackTrace = _target.StackTrace;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("StackTrace"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _StackTrace, ($v) => _StackTrace = $v, $.$$.S.String)))
                    {
                        _target.StackTrace = _StackTrace;
                    }
                }
                {
                    /*var*/ let _InnerException = _target.InnerException;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("InnerException"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _InnerException, ($v) => _InnerException = $v, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)))
                    {
                        _target.InnerException = _InnerException;
                    }
                }
                {
                    /*var*/ let _InnerExceptions = _target.InnerExceptions;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("InnerExceptions"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel), $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel), $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, property, $.$ref(() => _InnerExceptions, ($v) => _InnerExceptions = $v, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel))))
                    {
                        _target.InnerExceptions = _InnerExceptions;
                        if (_InnerExceptions !== null)
                        {
                            let $en17 = _InnerExceptions.SCG$IEnumerable$$$GetEnumerator();
                            while ($en17.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en17.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel), $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, property, $.$ref(() => _InnerExceptions, ($v) => _InnerExceptions = $v, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182489555)
            
            //--TRIMMABLE-BOUNDARY-START(8592554963)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592554963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel)))
                {
                    /*var*/ let result = $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592554963)
            
            static $h = 2620371;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887522259),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2620371,
      "h": 12887522259,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887522259),
//--TRIMMABLE-BOUNDARY-START(17182489555),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2489299,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2620371,
      "h": 17182489555,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182489555),
//--TRIMMABLE-BOUNDARY-START(8592554963),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2489299,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2620371,
      "h": 8592554963,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592554963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297587667),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2620371,
      "h": 4297587667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297587667)
  ],
  "h": 2620371
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uvJL.LCFCR.RemoteProxyServiceMethodExceptionModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyServiceMethodExceptionModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyServiceMethodExceptionModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2620371)
        
        

        //--TRIMMABLE-BOUNDARY-START(2227155)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor`, ($self) => class RemoteProxyMethodParameterTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uvJL.LCFCR.RemoteProxyMethodParameter)
        {
            //--TRIMMABLE-BOUNDARY-START(4297194451)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297194451);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor.GenerateProperties($.$uvJL.LCFCR.RemoteProxyMethodParameter, this, factory);
                    }, $GKPHDc ??= {"r":65537,"n":"","d":2227155,"h":0,"f":17825794}), 0, "RemoteProxyMethodParameterTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC\\RemoteProxyMethodParameter_LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameterTypeDescriptorBuilder.g.cs", "RemoteProxyMethodParameterTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297194451)
            
            //--TRIMMABLE-BOUNDARY-START(12887129043)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887129043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodParameter.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Name";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyMethodParameter)).Name);
                        }, $BKXvSd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2227155,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$uvJL.LCFCR.RemoteProxyMethodParameter, target).$v.Name = value.AsReference($.$$.S.String);
                        }, $eMcCSk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2227155,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodParameter.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Type";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyMethodParameter)).Type);
                        }, $jMkBRa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2227155,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$uvJL.LCFCR.RemoteProxyMethodParameter, target).$v.Type = value.AsReference($.$$.S.String);
                        }, $dEiczk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2227155,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ParameterType"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodParameter.$type, $.$discardRef(), "ParameterType", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ParameterType")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Type, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "ParameterType";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Type, ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyMethodParameter)).ParameterType);
                        }, $yLUDLb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2227155,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Parameter"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodParameter.$type, $.$discardRef(), "Parameter", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Parameter")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Object, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Parameter";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.Object, ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyMethodParameter)).Parameter);
                        }, $iNiqPa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2227155,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$uvJL.LCFCR.RemoteProxyMethodParameter, target).$v.Parameter = value.AsReference($.$$.S.Object);
                        }, $PtFtNj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2227155,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("_Parameter"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodParameter.$type, $.$discardRef(), "_Parameter", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("_Parameter")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Object, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "_Parameter";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter";
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$uvJL.LCFCR.RemoteProxyMethodParameter, target).$v._Parameter = value.AsReference($.$$.S.Object);
                        }, $iPlBDc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2227155,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887129043)
            
            //--TRIMMABLE-BOUNDARY-START(17182096339)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182096339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                        _target.Name = _Name;
                    }
                }
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Type, ($v) => _Type = $v, $.$$.S.String)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _ParameterType = _target.ParameterType;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ParameterType"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Type));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ParameterType, ($v) => _ParameterType = $v, $.$$.S.Type)))
                    {
                    }
                }
                {
                    /*var*/ let _Parameter = _target.Parameter;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Parameter"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Object));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Object, property, $.$ref(() => _Parameter, ($v) => _Parameter = $v, $.$$.S.Object)))
                    {
                        _target.Parameter = _Parameter;
                    }
                }
                {
                    /*var*/ let __Parameter = null;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("_Parameter"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Object));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Object, property, $.$ref(() => __Parameter, ($v) => __Parameter = $v, $.$$.S.Object)))
                    {
                        _target._Parameter = __Parameter;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182096339)
            
            //--TRIMMABLE-BOUNDARY-START(8592161747)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameter*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592161747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uvJL.LCFCR.RemoteProxyMethodParameter, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$uvJL.LCFCR.RemoteProxyMethodParameter, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$uvJL.LCFCR.RemoteProxyMethodParameterTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$uvJL.LCFCR.RemoteProxyMethodParameter, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uvJL.LCFCR.RemoteProxyMethodParameter, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$uvJL.LCFCR.RemoteProxyMethodParameter, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592161747)
            
            static $h = 2227155;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uvJL.LCFCR.RemoteProxyMethodParameter); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887129043),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2227155,
      "h": 12887129043,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887129043),
//--TRIMMABLE-BOUNDARY-START(17182096339),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2030547,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2227155,
      "h": 17182096339,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182096339),
//--TRIMMABLE-BOUNDARY-START(8592161747),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2030547,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2227155,
      "h": 8592161747,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592161747)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297194451),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2227155,
      "h": 4297194451,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297194451)
  ],
  "h": 2227155
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodParameterTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyMethodParameterTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2227155)
        
        

        //--TRIMMABLE-BOUNDARY-START(1899475)
        $asm.$cls(`$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor`, ($self) => class RemoteProxyMethodInfoTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uvJL.LCFCR.RemoteProxyMethodInfo)
        {
            //--TRIMMABLE-BOUNDARY-START(4296866771)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296866771);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor.GenerateProperties($.$uvJL.LCFCR.RemoteProxyMethodInfo, this, factory);
                    }, $AQyeni ??= {"r":65537,"n":"","d":1899475,"h":0,"f":17825794}), 0, "RemoteProxyMethodInfoTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.RPC\\RemoteProxyMethodInfo_LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfoTypeDescriptorBuilder.g.cs", "RemoteProxyMethodInfoTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296866771)
            
            //--TRIMMABLE-BOUNDARY-START(12886801363)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886801363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodInfo.$type, $.$discardRef(), "Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Service";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfo";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyMethodInfo)).Service);
                        }, $PjMuQj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1899475,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$uvJL.LCFCR.RemoteProxyMethodInfo, target).$v.Service = value.AsReference($.$$.S.String);
                        }, $OaOkrf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1899475,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RequestId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodInfo.$type, $.$discardRef(), "RequestId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RequestId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "RequestId";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfo";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$uvJL.LCFCR.RemoteProxyMethodInfo)).RequestId);
                        }, $IhZVmb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1899475,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$uvJL.LCFCR.RemoteProxyMethodInfo, target).$v.RequestId = value.AsInt();
                        }, $WNgPBg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1899475,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("_Service"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodInfo.$type, $.$discardRef(), "_Service", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("_Service")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "_Service";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfo";
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$uvJL.LCFCR.RemoteProxyMethodInfo, target).$v._Service = value.AsReference($.$$.S.String);
                        }, $CNifoa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1899475,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ServiceParameters"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodInfo.$type, $.$discardRef(), "ServiceParameters", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ServiceParameters")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "ServiceParameters";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfo";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyMethodInfo)).ServiceParameters);
                        }, $arfkzb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1899475,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$uvJL.LCFCR.RemoteProxyMethodInfo, target).$v.ServiceParameters = value.AsReference($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter));
                        }, $CRyCej ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1899475,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Parameters"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodInfo.$type, $.$discardRef(), "Parameters", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Parameters")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Parameters";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfo";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), ($.$cast(target, $.$uvJL.LCFCR.RemoteProxyMethodInfo)).Parameters);
                        }, $tSRoaj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1899475,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$uvJL.LCFCR.RemoteProxyMethodInfo, target).$v.Parameters = value.AsReference($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter));
                        }, $yUUbWk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1899475,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("_Parameters"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$uvJL.LCFCR.RemoteProxyMethodInfo.$type, $.$discardRef(), "_Parameters", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("_Parameters")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "_Parameters";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfo";
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return $.$$.SRC.Unsafe.Unbox($.$uvJL.LCFCR.RemoteProxyMethodInfo, target).$v._Parameters = value.AsReference($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter));
                        }, $GAROsg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1899475,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886801363)
            
            //--TRIMMABLE-BOUNDARY-START(17181768659)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfo*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181768659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                {
                    /*var*/ let _Service = _target.Service;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Service, ($v) => _Service = $v, $.$$.S.String)))
                    {
                        _target.Service = _Service;
                    }
                }
                {
                    /*var*/ let _RequestId = _target.RequestId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RequestId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _RequestId, ($v) => _RequestId = $v, $.$$.S.Int32)))
                    {
                        _target.RequestId = _RequestId;
                    }
                }
                {
                    /*var*/ let __Service = null;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("_Service"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => __Service, ($v) => __Service = $v, $.$$.S.String)))
                    {
                        _target._Service = __Service;
                    }
                }
                {
                    /*var*/ let _ServiceParameters = _target.ServiceParameters;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ServiceParameters"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), $.$uvJL.LCFCR.RemoteProxyMethodParameter));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), $.$uvJL.LCFCR.RemoteProxyMethodParameter, property, $.$ref(() => _ServiceParameters, ($v) => _ServiceParameters = $v, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter))))
                    {
                        _target.ServiceParameters = _ServiceParameters;
                        if (_ServiceParameters !== null)
                        {
                            let $en17 = _ServiceParameters.SCG$IEnumerable$$$GetEnumerator();
                            while ($en17.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en17.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$uvJL.LCFCR.RemoteProxyMethodParameter, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), $.$uvJL.LCFCR.RemoteProxyMethodParameter, property, $.$ref(() => _ServiceParameters, ($v) => _ServiceParameters = $v, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter)));
                    }
                }
                {
                    /*var*/ let _Parameters = _target.Parameters;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Parameters"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), $.$uvJL.LCFCR.RemoteProxyMethodParameter));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), $.$uvJL.LCFCR.RemoteProxyMethodParameter, property, $.$ref(() => _Parameters, ($v) => _Parameters = $v, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter))))
                    {
                        _target.Parameters = _Parameters;
                        if (_Parameters !== null)
                        {
                            let $en22 = _Parameters.SCG$IEnumerable$$$GetEnumerator();
                            while ($en22.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en22.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$uvJL.LCFCR.RemoteProxyMethodParameter, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), $.$uvJL.LCFCR.RemoteProxyMethodParameter, property, $.$ref(() => _Parameters, ($v) => _Parameters = $v, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter)));
                    }
                }
                {
                    /*var*/ let __Parameters = null;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("_Parameters"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), $.$uvJL.LCFCR.RemoteProxyMethodParameter));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), $.$uvJL.LCFCR.RemoteProxyMethodParameter, property, $.$ref(() => __Parameters, ($v) => __Parameters = $v, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter))))
                    {
                        _target._Parameters = __Parameters;
                        if (__Parameters !== null)
                        {
                            let $en27 = __Parameters.SCG$IEnumerable$$$GetEnumerator();
                            while ($en27.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en27.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = $.$clone(item);
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$uvJL.LCFCR.RemoteProxyMethodParameter, () => _item, ($v) => _item = $v, null, true)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter), $.$uvJL.LCFCR.RemoteProxyMethodParameter, property, $.$ref(() => __Parameters, ($v) => __Parameters = $v, $.$$.SCG.IEnumerable$$($.$uvJL.LCFCR.RemoteProxyMethodParameter)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181768659)
            
            //--TRIMMABLE-BOUNDARY-START(8591834067)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfo*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591834067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = $.$clone(target).$v;
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$uvJL.LCFCR.RemoteProxyMethodInfo, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$uvJL.LCFCR.RemoteProxyMethodInfo, () => _target, ($v) => _target = $v, null, true)))
                {
                    /*var*/ let result = $.$uvJL.LCFCR.RemoteProxyMethodInfoTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$uvJL.LCFCR.RemoteProxyMethodInfo, () => _target, ($v) => _target = $v, null, true));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$uvJL.LCFCR.RemoteProxyMethodInfo, null, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$uvJL.LCFCR.RemoteProxyMethodInfo, () => _target, ($v) => _target = $v, null, true));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591834067)
            
            static $h = 1899475;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$uvJL.LCFCR.RemoteProxyMethodInfo); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886801363),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1899475,
      "h": 12886801363,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886801363),
//--TRIMMABLE-BOUNDARY-START(17181768659),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1768403,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1899475,
      "h": 17181768659,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181768659),
//--TRIMMABLE-BOUNDARY-START(8591834067),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1768403,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1899475,
      "h": 8591834067,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591834067)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296866771),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1899475,
      "h": 4296866771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296866771)
  ],
  "h": 1899475
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$uvJL.LCFCR.RemoteProxyMethodInfo), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.RemoteProxyMethodInfoTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}RemoteProxyMethodInfoTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1899475)
        
        

        //--TRIMMABLE-BOUNDARY-START(3537875)
        $asm.$cls(`$uvJL.LCFCR.UseGeneratedProxyRemoteServiceAttribute`, ($self) => class UseGeneratedProxyRemoteServiceAttribute extends $.$zHIt.LCFCM.MockAttribute$$($.$uvJL.LCFCR.RemoteProxyServiceBase)
        {
            //--TRIMMABLE-BOUNDARY-START(4298505171)
            $ctor$6()
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298505171);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298505171)
            
            //--TRIMMABLE-BOUNDARY-START(8593472467)
            $ctor$7(/*params Type[]*/ moreTypes)
            {
                super.$ctor$5(moreTypes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593472467);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593472467)
            
            //--TRIMMABLE-BOUNDARY-START(4298505171)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298505171)
            
            static $h = 3537875;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$zHIt.LCFCM.MockAttribute$$($.$uvJL.LCFCR.RemoteProxyServiceBase); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298505171),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3537875,
      "h": 4298505171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298505171),
//--TRIMMABLE-BOUNDARY-START(8593472467),
    {
      "p": [
        {
          "n": "moreTypes",
          "p": $.$typeArray($.$$.S.Type).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 3537875,
      "h": 8593472467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593472467)
  ],
  "h": 3537875,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1024,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.RPC.UseGeneratedProxyRemoteServiceAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}RPC${separator}UseGeneratedProxyRemoteServiceAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3537875)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking"));
})();
//--TRIMMABLE-BOUNDARY-END(64467)
