
//--TRIMMABLE-BOUNDARY-START(30204)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer) {
    "use strict";
    let _;
    let $EtHKYb;
    let $bxwPKk;
    let $ZfRVxe;
    let $uJPZff;
    let $eEPjyg;
    let $JToLAa;
    let $EklKYh;
    let $DuSlkj;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.ServiceProvider", 
    {
  "h": 30204,
  "f": "LivingThing.Core.Frameworks.Common.ServiceProvider",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.ServiceProvider",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.ServiceProvider",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(620028)
        $asm.$cls(`$lmWW.LCFCS.IServiceResolver`, ($self) => class IServiceResolver
        {
            static $h = 620028;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295587324),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvier",
          "p": 423420
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "all",
          "p": 262145
        },
        {
          "n": "currentScope",
          "p": 1900634,
          "f": 4
        }
      ],
      "n": "TryResolve",
      "o": "LCFCS$IServiceResolver$TryResolve",
      "d": 620028,
      "h": 4295587324,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295587324)
  ],
  "h": 620028
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.IServiceResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}IServiceResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(620028)
        
        

        //--TRIMMABLE-BOUNDARY-START(423420)
        $asm.$cls(`$lmWW.LCFCS.IExtensibleServiceProvider`, ($self) => class IExtensibleServiceProvider
        {
            static $h = 423420;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770227196),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475259900,
        "f": 50331905
      },
      "n": "Services",
      "o": "LCFCS$IExtensibleServiceProvider$Services",
      "d": 423420,
      "h": 25770227196,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770227196),
//--TRIMMABLE-BOUNDARY-START(4295390716),
    {
      "p": 393310,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885325308,
        "f": 50331905
      },
      "n": "Configuration",
      "o": "LCFCS$IExtensibleServiceProvider$Configuration",
      "d": 423420,
      "h": 4295390716,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295390716)
  ],
  "h": 423420
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.MED.IKeyedServiceProvider, $.$scm.S.IServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}IExtensibleServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(423420)
        
        

        //--TRIMMABLE-BOUNDARY-START(488956)
        $asm.$cls(`$lmWW.LCFCS.IExtensibleServiceProviderRoot`, ($self) => class IExtensibleServiceProviderRoot
        {
            static $h = 488956;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295456252),
    {
      "r": 65537,
      "p": [
        {
          "n": "resolver",
          "p": 620028
        }
      ],
      "n": "AddResolver",
      "o": "LCFCS$IExtensibleServiceProviderRoot$AddResolver",
      "d": 488956,
      "h": 4295456252,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295456252)
  ],
  "h": 488956
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$lmWW.LCFCS.IExtensibleServiceProvider, $.$mxdi.MED.IKeyedServiceProvider, $.$scm.S.IServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProviderRoot`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}IExtensibleServiceProviderRoot`; }
        });
        //--TRIMMABLE-BOUNDARY-END(488956)
        
        

        //--TRIMMABLE-BOUNDARY-START(554492)
        $asm.$cls(`$lmWW.LCFCS.IExtensibleServiceProviderScope`, ($self) => class IExtensibleServiceProviderScope
        {
            static $h = 554492;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885456380),
    {
      "p": 488956,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590489084,
        "f": 50331905
      },
      "n": "Root",
      "o": "LCFCS$IExtensibleServiceProviderScope$Root",
      "d": 554492,
      "h": 12885456380,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885456380)
  ],
  "h": 554492
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$lmWW.LCFCS.IExtensibleServiceProvider, $.$mxdi.MED.IKeyedServiceProvider, $.$scm.S.IServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProviderScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}IExtensibleServiceProviderScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(554492)
        
        

        //--TRIMMABLE-BOUNDARY-START(882172)
        $asm.$cls(`$lmWW.LCFCS.ServiceInstanceActivator`, ($self) => class ServiceInstanceActivator extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180751356)
            /*ServiceDescriptor*/ Descriptor = null;
            //--TRIMMABLE-BOUNDARY-END(17180751356)
            
            //--TRIMMABLE-BOUNDARY-START(8590816764)
            $ctor$1(/*ServiceDescriptor*/ descriptor)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590816764);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Descriptor = descriptor;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590816764)
            
            static $h = 882172;
            static $f = 0b110000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180751356),
    {
      "p": 1704026,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770685948,
        "f": 50331649
      },
      "n": "Descriptor",
      "d": 882172,
      "h": 17180751356,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180751356)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885784060),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvider",
          "p": 423420
        }
      ],
      "n": "Activate",
      "d": 882172,
      "h": 12885784060,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885784060)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590816764),
    {
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 882172,
      "h": 8590816764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590816764)
  ],
  "h": 882172
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.ServiceInstanceActivator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}ServiceInstanceActivator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(882172)
        
        

        //--TRIMMABLE-BOUNDARY-START(161276)
        $asm.$cls(`$lmWW.LCFCS.ExtensibleServiceProviderExtension`, ($self) => class ExtensibleServiceProviderExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295128572)
            static /*IEnumerable<ServiceDescriptor> */ GetServiceDescriptors(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295128572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let descriptors = $.$sl.SL.Enumerable.Where($.$mxdi.MED.ServiceDescriptor, services, new ($.$$.S.Func$$$($.$mxdi.MED.ServiceDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                {
                    /*object?*/ let __ca1__;
                    return s.ServiceType === serviceType && (s.ServiceKey === serviceKey || (((__ca1__ = s.ServiceKey) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.Equals$1, serviceKey) : false)));
                }, $EtHKYb ??= {"r":262145,"p":[{"n":"s","p":1704026}],"n":"","d":161276,"h":0,"f":17825794}));
                if (serviceType.IsGenericType)
                {
                    /*var*/ let openGenericType = serviceType.GetGenericTypeDefinition();
                    /*var*/ let _descriptors = $.$sl.SL.Enumerable.Where($.$mxdi.MED.ServiceDescriptor, services, new ($.$$.S.Func$$$($.$mxdi.MED.ServiceDescriptor, $.$$.S.Boolean))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.ServiceType === openGenericType;
                    }, $bxwPKk ??= {"r":262145,"p":[{"n":"s","p":1704026}],"n":"","d":161276,"h":0,"f":17825794}));
                    descriptors = $.$sl.SL.Enumerable.Concat($.$mxdi.MED.ServiceDescriptor, descriptors, _descriptors);
                }
                return descriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(4295128572)
            
            //--TRIMMABLE-BOUNDARY-START(8590095868)
            static /*void */ Match(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Action<ServiceDescriptor>*/ action)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590095868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let openGenericType = serviceType.IsGenericType ? serviceType.GetGenericTypeDefinition() : null;
                for(/*int*/ let i = 0; i < services.SCG$ICollection$$$Count; i++)
                {
                    /*var*/ let service = services.SCG$IList$$$get_Item(i);
                    if ((service.ServiceType === serviceType) || (openGenericType !== null && service.ServiceType === openGenericType))
                    {
                        /*object?*/ let __ca2__;
                        if (service.ServiceKey === serviceKey || (((__ca2__ = service.ServiceKey) !== null ? $.$dspc(__ca2__, $.$$.S.Object, ($t) => $t.Equals$1, serviceKey) : false)))
                        {
                            action.Invoke(service);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590095868)
            
            static $h = 161276;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295128572),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mxdi.MED.ServiceDescriptor).$h,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetServiceDescriptors",
      "d": 161276,
      "h": 4295128572,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295128572),
//--TRIMMABLE-BOUNDARY-START(8590095868),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "action",
          "p": $.$$.S.Action$$($.$mxdi.MED.ServiceDescriptor).$h
        }
      ],
      "n": "Match",
      "d": 161276,
      "h": 8590095868,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590095868)
  ],
  "h": 161276
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.ExtensibleServiceProviderExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}ExtensibleServiceProviderExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(161276)
        
        

        //--TRIMMABLE-BOUNDARY-START(357884)
        $asm.$cls(`$lmWW.LCFCSG.GeneratedServiceResolver`, ($self) => class GeneratedServiceResolver extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590292476)
            /*object? */ TryResolve(/*IExtensibleServiceProvider*/ serviceProvier, /*Type*/ serviceType, /*object?*/ serviceKey, /*bool*/ all, /*ref ServiceLifetime*/ currentScope)
            {
                /*var*/ let mdescriptors;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590292476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<object>?*/ let results = null;
                if ($.$fPer.LCFCSG.GeneratedServiceFactory.Descriptors.TryGetValue(serviceType, $.$ref(() => mdescriptors, ($v) => mdescriptors = $v, $.$$.SCG.List$$($.$fPer.LCFCSG.ServiceProviderDescriptor))))
                {
                    for(/*int*/ let i = 0; i < mdescriptors.Count; i++)
                    {
                        /*var*/ let service = mdescriptors.get_Item(i).Delegate.Invoke(serviceProvier, serviceKey);
                        if (!all)
                        {
                            return service;
                        }
                        results ??= new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                        results.Add(service);
                    }
                }
                return results;
            }
            //--TRIMMABLE-BOUNDARY-END(8590292476)
            
            //--TRIMMABLE-BOUNDARY-START(4295587324)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.ServiceProvider.IServiceResolver.TryResolve(LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProvider, System.Type, object?, bool, ref Microsoft.Extensions.DependencyInjection.ServiceLifetime)
            LCFCS$IServiceResolver$TryResolve()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295587324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryResolve(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295587324)
            
            //--TRIMMABLE-BOUNDARY-START(4295325180)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295325180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295325180)
            
            //--TRIMMABLE-BOUNDARY-START(4295325180)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295325180)
            
            static $h = 357884;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590292476),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvier",
          "p": 423420
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "all",
          "p": 262145
        },
        {
          "n": "currentScope",
          "p": 1900634,
          "f": 4
        }
      ],
      "n": "TryResolve",
      "d": 357884,
      "h": 8590292476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590292476)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295325180),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 357884,
      "h": 4295325180,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295325180)
  ],
  "h": 357884
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$lmWW.LCFCS.IServiceResolver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.Generator.GeneratedServiceResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}Generator${separator}GeneratedServiceResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(357884)
        
        

        //--TRIMMABLE-BOUNDARY-START(685564)
        $asm.$cls(`$lmWW.LCFCS.ServiceCollectionResolver`, ($self) => class ServiceCollectionResolver extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590620156)
            /*IServiceCollection*/ _services = null;
            //--TRIMMABLE-BOUNDARY-END(8590620156)
            
            //--TRIMMABLE-BOUNDARY-START(4295652860)
            /*Dictionary<(Type, object?), Dictionary<ServiceDescriptor, ServiceInstanceActivator>>*/ _activators = null;
            //--TRIMMABLE-BOUNDARY-END(4295652860)
            
            //--TRIMMABLE-BOUNDARY-START(12885587452)
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885587452);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._services = services;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885587452)
            
            //--TRIMMABLE-BOUNDARY-START(17180554748)
            /*Dictionary<ServiceDescriptor, ServiceInstanceActivator> */ GetActivators(/*Type*/ serviceType, /*object?*/ serviceKey, /*IExtensibleServiceProvider*/ serviceProvider)
            {
                /*var*/ let activatorsForSeviceDescriptors;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180554748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._activators.TryGetValue(new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object))().$ctor$3(serviceType, serviceKey), $.$ref(() => activatorsForSeviceDescriptors, ($v) => activatorsForSeviceDescriptors = $v, $.$$.SCG.Dictionary$$$($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ServiceInstanceActivator))))
                {
                    activatorsForSeviceDescriptors = new ($.$$.SCG.Dictionary$$$($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ServiceInstanceActivator))().$ctor$1();
                    this._activators.set_Item(new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object))().$ctor$3(serviceType, serviceKey), activatorsForSeviceDescriptors);
                    $.$lmWW.LCFCS.ExtensibleServiceProviderExtension.Match(this._services, serviceType, serviceKey, new ($.$$.S.Action$$($.$mxdi.MED.ServiceDescriptor))().$ctor(this,  (/**/ descriptor) =>
                    {
                        /*var*/ let activator;
                        if (!activatorsForSeviceDescriptors.TryGetValue(descriptor, $.$ref(() => activator, ($v) => activator = $v, $.$lmWW.LCFCS.ServiceInstanceActivator)))
                        {
                            /*ServiceInstanceActivator?*/ let instanceActivator = null;
                            if ((descriptor.IsKeyedService && descriptor.KeyedImplementationFactory !== null) || (!descriptor.IsKeyedService && descriptor.ImplementationFactory !== null))
                            {
                                instanceActivator = new $.$lmWW.LCFCS.ServiceFactoryInstanceActivator().$ctor$2(descriptor);
                            }
                            else if ((descriptor.IsKeyedService && descriptor.KeyedImplementationInstance !== null) || (!descriptor.IsKeyedService && descriptor.ImplementationInstance !== null))
                            {
                                instanceActivator = new $.$lmWW.LCFCS.ServiceInstanceInstanceActivator().$ctor$2(descriptor);
                            }
                            else if ((descriptor.IsKeyedService && descriptor.KeyedImplementationType !== null) || (!descriptor.IsKeyedService && descriptor.ImplementationType !== null))
                            {
                                instanceActivator = new $.$lmWW.LCFCS.ServiceConstructorActivator().$ctor$2(descriptor, serviceType, serviceKey, serviceProvider);
                            }
                            else 
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12("Unknown Error");
                            }
                            activatorsForSeviceDescriptors.set_Item(descriptor, instanceActivator);
                        }
                    }, $JToLAa ??= {"r":65537,"p":[{"n":"descriptor","p":1704026}],"n":"","d":685564,"h":0,"f":17825794}));
                }
                return activatorsForSeviceDescriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(17180554748)
            
            //--TRIMMABLE-BOUNDARY-START(21475522044)
            /*object? */ TryResolve(/*IExtensibleServiceProvider*/ serviceProvider, /*Type*/ serviceType, /*object?*/ serviceKey, /*bool*/ all, /*ref ServiceLifetime*/ currentScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475522044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        /*var*/ let mCurrentScope = currentScope.$v;
                        /*var*/ let activatorsForType = this.GetActivators(serviceType, serviceKey, serviceProvider);
                        if (!$.$sl.SL.Enumerable.Any$1($.$$.SCG.KeyValuePair$$$($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ServiceInstanceActivator), activatorsForType) && !all)
                        {
                            return null;
                        }
                        if (all)
                        {
                            return $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ServiceInstanceActivator), $.$$.S.Object, activatorsForType, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ServiceInstanceActivator), $.$$.S.Object))().$ctor(this,  (/*a*/ a) =>
                            {
                                return a.Value.Activate(serviceProvider);
                            }, $EklKYh ??= {"r":131073,"p":[{"n":"a","p":$.$$.SCG.KeyValuePair$$$($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ServiceInstanceActivator).$h}],"n":"","d":685564,"h":0,"f":17825794}));
                        }
                        else 
                        {
                            /*var*/ let activator = $.$sl.SL.Enumerable.First$1($.$$.SCG.KeyValuePair$$$($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ServiceInstanceActivator), activatorsForType);
                            currentScope.$v = activator.Value.Descriptor.Lifetime;
                            return activator.Value.Activate(serviceProvider);
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475522044)
            
            //--TRIMMABLE-BOUNDARY-START(4295587324)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.ServiceProvider.IServiceResolver.TryResolve(LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProvider, System.Type, object?, bool, ref Microsoft.Extensions.DependencyInjection.ServiceLifetime)
            LCFCS$IServiceResolver$TryResolve()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295587324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryResolve(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295587324)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295652860)
                this._activators = new ($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object), $.$$.SCG.Dictionary$$$($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ServiceInstanceActivator)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295652860)
                
            }
            static $h = 685564;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180554748),
    {
      "r": $.$$.SCG.Dictionary$$$($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ServiceInstanceActivator).$h,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "serviceProvider",
          "p": 423420
        }
      ],
      "n": "GetActivators",
      "d": 685564,
      "h": 17180554748,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180554748),
//--TRIMMABLE-BOUNDARY-START(21475522044),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvider",
          "p": 423420
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "all",
          "p": 262145
        },
        {
          "n": "currentScope",
          "p": 1900634,
          "f": 4
        }
      ],
      "n": "TryResolve",
      "d": 685564,
      "h": 21475522044,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475522044)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590620156),
    {
      "t": 786522,
      "n": "_services",
      "d": 685564,
      "h": 8590620156,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590620156),
//--TRIMMABLE-BOUNDARY-START(4295652860),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object), $.$$.SCG.Dictionary$$$($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ServiceInstanceActivator)).$h,
      "n": "_activators",
      "d": 685564,
      "h": 4295652860,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295652860)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885587452),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 685564,
      "h": 12885587452,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885587452)
  ],
  "h": 685564
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$lmWW.LCFCS.IServiceResolver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.ServiceCollectionResolver`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}ServiceCollectionResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(685564)
        
        

        //--TRIMMABLE-BOUNDARY-START(95740)
        $asm.$cls(`$lmWW.LCFCS.ExtensibleServiceProvider`, ($self) => class ExtensibleServiceProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(98784343548)
            /*ExtensibleServiceProvider?*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(98784343548)
            
            //--TRIMMABLE-BOUNDARY-START(8590030332)
            /*List<IServiceResolver>*/ _resolvers = null;
            //--TRIMMABLE-BOUNDARY-END(8590030332)
            
            //--TRIMMABLE-BOUNDARY-START(4295063036)
            /*Dictionary<(Type, object?), object>*/ _resolvedServices = null;
            //--TRIMMABLE-BOUNDARY-END(4295063036)
            
            //--TRIMMABLE-BOUNDARY-START(128849114620)
            /*IServiceCollection*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(128849114620)
            
            //--TRIMMABLE-BOUNDARY-START(38654801404)
            /*IConfiguration*/ Configuration = null;
            //--TRIMMABLE-BOUNDARY-END(38654801404)
            
            //--TRIMMABLE-BOUNDARY-START(141734016508)
            /*StartupOptions*/ StartupOptions;
            //--TRIMMABLE-BOUNDARY-END(141734016508)
            
            //--TRIMMABLE-BOUNDARY-START(30064866812)
            $ctor$1(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ startupOptions)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064866812);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$lmWW.LCFCS.ExtensibleServiceProvider.Instance = this;
                    this.Services = services;
                    this.Configuration = configuration;
                    this.StartupOptions = $.$clone(startupOptions);
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$scm.S.IServiceProvider, services, this);
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$mxdi.MED.IServiceScopeFactory, services, this);
                    $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$mxdi.MED.IServiceProviderIsService, services, this);
                    this._resolvers.Add(new $.$lmWW.LCFCS.ServiceCollectionResolver().$ctor$1(services));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064866812)
            
            //--TRIMMABLE-BOUNDARY-START(34359834108)
            /*void */ AddResolver(/*IServiceResolver*/ resolver)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359834108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._resolvers.Add(resolver);
            }
            //--TRIMMABLE-BOUNDARY-END(34359834108)
            
            //--TRIMMABLE-BOUNDARY-START(124554147324)
            /*object? */ ResolveSingle(/*Type*/ serviceType, /*object?*/ serviceKey, /*IExtensibleServiceProvider*/ provider, /*ServiceLifetime*/ currentScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554147324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < this._resolvers.Count; i++)
                {
                    /*var*/ let service = this._resolvers.get_Item(i).LCFCS$IServiceResolver$TryResolve(provider, serviceType, serviceKey, false, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mxdi.MED.ServiceLifetime, () => currentScope, ($v) => currentScope = $v, null, true));
                    if (service !== null)
                    {
                        return service;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(124554147324)
            
            //--TRIMMABLE-BOUNDARY-START(120259180028)
            /*IEnumerable<object> */ ResolveMany(/*Type*/ serviceType, /*object?*/ serviceKey, /*IExtensibleServiceProvider*/ provider, /*ref ServiceLifetime*/ currentScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259180028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<object>*/ let services = new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                for(/*int*/ let i = 0; i < this._resolvers.Count; i++)
                {
                    /*var*/ let service = this._resolvers.get_Item(i).LCFCS$IServiceResolver$TryResolve(provider, serviceType, serviceKey, true, currentScope);
                    if (service !== null)
                    {
                        services.AddRange($.$cast(service, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    }
                }
                /*var*/ let castToServiceType = $.$sl.SL.Enumerable.$type.GetMethod$12("Cast").MakeGenericMethod($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ serviceType ], null, null));
                /*var*/ let resolvedServices = castToServiceType.Invoke(null, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [services], [-1], null));
                return $.$cast(resolvedServices, $.$$.SCG.IEnumerable$$($.$$.S.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(120259180028)
            
            //--TRIMMABLE-BOUNDARY-START(115964212732)
            /*object? */ Resolve(/*Type*/ serviceType, /*object?*/ serviceKey, /*IExtensibleServiceProvider*/ provider, /*ref ServiceLifetime*/ currentScope)
            {
                /*var*/ let innerType;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964212732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (serviceType.IsGenericType && serviceType.GetGenericTypeDefinition() === $.$$.SCG.IEnumerable$$().$type && $.$fPer.LCFCT.TypesExtensions.IsEnumerable(serviceType, $.$ref(() => innerType, ($v) => innerType = $v, $.$$.S.Type), null))
                {
                    return this.ResolveMany(innerType, serviceKey, provider, currentScope);
                }
                return this.ResolveSingle(serviceType, serviceKey, provider, currentScope.$v);
            }
            //--TRIMMABLE-BOUNDARY-END(115964212732)
            
            //--TRIMMABLE-BOUNDARY-START(94489376252)
            /*object? */ GetServiceInternal(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489376252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        /*var*/ let service;
                        if (this._resolvedServices.TryGetValue(new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object))().$ctor$3(serviceType, serviceKey), $.$ref(() => service, ($v) => service = $v, $.$$.S.Object)))
                        {
                            return service;
                        }
                        /*var*/ let startScope = 0/*ServiceLifetime.Singleton*/;
                        service = this.Resolve(serviceType, serviceKey, this, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mxdi.MED.ServiceLifetime, () => startScope, ($v) => startScope = $v, null, true));
                        if (service !== null && startScope !== 2/*ServiceLifetime.Transient*/)
                        {
                            this._resolvedServices.Add(new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object))().$ctor$3(serviceType, serviceKey), service);
                        }
                        return service;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489376252)
            
            //--TRIMMABLE-BOUNDARY-START(90194408956)
            /*object? */ GetService(/*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194408956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetServiceInternal(serviceType, null);
            }
            //--TRIMMABLE-BOUNDARY-END(90194408956)
            
            //--TRIMMABLE-BOUNDARY-START(42949768700)
            /*IServiceScope */ CreateScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949768700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$lmWW.LCFCS.ExtensibleServiceProviderScope().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(42949768700)
            
            //--TRIMMABLE-BOUNDARY-START(103079310844)
            /*bool */ IsService(/*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079310844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Any$1($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ExtensibleServiceProviderExtension.GetServiceDescriptors(this.Services, serviceType, null));
            }
            //--TRIMMABLE-BOUNDARY-END(103079310844)
            
            //--TRIMMABLE-BOUNDARY-START(111669245436)
            /*void */ RegisterServicesInAssemblies(/*IEnumerable<Assembly>*/ assemblies)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669245436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en7 = assemblies.SCG$IEnumerable$$$GetEnumerator();
                while ($en7.SC$1$IEnumerator$MoveNext())
                {
                    let assembly = $en7.SCG$IEnumerator$$$Current;
                    {
                        $.$scsl.S.Console.WriteLine$17(`Registering from ${$.$strNN(assembly.GetName().Name)}`);
                        /*var*/ let types = $.$sl.SL.Enumerable.Where($.$$.S.Type, assembly.GetTypes(), new ($.$$.S.Func$$$($.$$.S.Type, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                        {
                            return $.$fPer.LCFCS$3.IServiceCollectionBuilder.$type.IsAssignableFrom(t);
                        }, $DuSlkj ??= {"r":262145,"p":[{"n":"t","p":188547073}],"n":"","d":95740,"h":0,"f":17825794}));
                        let $en8 = types.SCG$IEnumerable$$$GetEnumerator();
                        while ($en8.SC$1$IEnumerator$MoveNext())
                        {
                            let type = $en8.SCG$IEnumerator$$$Current;
                            {
                                $.$scsl.S.Console.WriteLine$17(`Registering ${$.$strNN(type.FullName)}`);
                                /*var*/ let configure = type.GetMethod$9("Configure", 16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                                configure.Invoke(null, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [this.Services, this.Configuration, this.StartupOptions], [-1], null));
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669245436)
            
            //--TRIMMABLE-BOUNDARY-START(81604474364)
            /*object? */ GetKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604474364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetServiceInternal(serviceType, serviceKey);
            }
            //--TRIMMABLE-BOUNDARY-END(81604474364)
            
            //--TRIMMABLE-BOUNDARY-START(85899441660)
            /*object */ GetRequiredKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899441660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$firstOf(this.GetServiceInternal(serviceType, serviceKey), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Cannot resolve ${$.$strNN(serviceType.FullName)}`) });
            }
            //--TRIMMABLE-BOUNDARY-END(85899441660)
            
            //--TRIMMABLE-BOUNDARY-START(146028983804)
            static /*void */ ValidateLifetime(/*ServiceLifetime*/ newServiceLifetime, /*ServiceLifetime*/ currentScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146028983804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (newServiceLifetime === 0/*ServiceLifetime.Singleton*/ && currentScope !== 0/*ServiceLifetime.Singleton*/)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Cannot resolve singleton service from a non-singleton scope");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146028983804)
            
            //--TRIMMABLE-BOUNDARY-START(107374278140)
            static /*bool */ IsValidateLifetime(/*ServiceLifetime*/ newServiceLifetime, /*ServiceLifetime*/ currentScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374278140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (newServiceLifetime === 0/*ServiceLifetime.Singleton*/ && currentScope !== 0/*ServiceLifetime.Singleton*/)
                {
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(107374278140)
            
            //--TRIMMABLE-BOUNDARY-START(4295456252)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProviderRoot.AddResolver(LivingThing.Core.Frameworks.Common.ServiceProvider.IServiceResolver)
            LCFCS$IExtensibleServiceProviderRoot$AddResolver()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295456252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddResolver(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295456252)
            
            //--TRIMMABLE-BOUNDARY-START(21475259900)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProvider.Services.get
            get LCFCS$IExtensibleServiceProvider$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770227196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(21475259900)
            
            //--TRIMMABLE-BOUNDARY-START(12885325308)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProvider.Configuration.get
            get LCFCS$IExtensibleServiceProvider$Configuration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295390716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configuration;
            }
            //--TRIMMABLE-BOUNDARY-END(12885325308)
            
            //--TRIMMABLE-BOUNDARY-START(4295688282)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetKeyedService(System.Type, object?)
            MED$IKeyedServiceProvider$GetKeyedService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetKeyedService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688282)
            
            //--TRIMMABLE-BOUNDARY-START(8590655578)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetRequiredKeyedService(System.Type, object?)
            MED$IKeyedServiceProvider$GetRequiredKeyedService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590655578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetRequiredKeyedService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590655578)
            
            //--TRIMMABLE-BOUNDARY-START(4295295014)
            //Generated interface implemetation for System.IServiceProvider.GetService(System.Type)
            S$IServiceProvider$GetService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295014)
            
            //--TRIMMABLE-BOUNDARY-START(4296081498)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.CreateScope()
            MED$IServiceScopeFactory$CreateScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296081498)
            
            //--TRIMMABLE-BOUNDARY-START(4295950426)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderIsService.IsService(System.Type)
            MED$IServiceProviderIsService$IsService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295950426)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590030332)
                this._resolvers = new ($.$$.SCG.List$$($.$lmWW.LCFCS.IServiceResolver))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590030332)
                
                //--TRIMMABLE-BOUNDARY-START(4295063036)
                this._resolvedServices = new ($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object), $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295063036)
                
                //--TRIMMABLE-BOUNDARY-START(141734016508)
                this.StartupOptions = $.$default($.$fPer.LCFCS$3.StartupOptions);
                //--TRIMMABLE-BOUNDARY-END(141734016508)
                
            }
            static $h = 95740;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(98784343548),
    {
      "p": 95740,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129637884,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439049212,
        "f": 83886114
      },
      "n": "Instance",
      "d": 95740,
      "h": 98784343548,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(98784343548),
//--TRIMMABLE-BOUNDARY-START(128849114620),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719572476,
        "f": 50331649
      },
      "n": "Services",
      "d": 95740,
      "h": 128849114620,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849114620),
//--TRIMMABLE-BOUNDARY-START(38654801404),
    {
      "p": 393310,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539703292,
        "f": 50331649
      },
      "n": "Configuration",
      "d": 95740,
      "h": 38654801404,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654801404),
//--TRIMMABLE-BOUNDARY-START(141734016508),
    {
      "p": 63211862,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309507068,
        "f": 50331649
      },
      "n": "StartupOptions",
      "d": 95740,
      "h": 141734016508,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734016508)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34359834108),
    {
      "r": 65537,
      "p": [
        {
          "n": "resolver",
          "p": 620028
        }
      ],
      "n": "AddResolver",
      "d": 95740,
      "h": 34359834108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359834108),
//--TRIMMABLE-BOUNDARY-START(124554147324),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "provider",
          "p": 423420
        },
        {
          "n": "currentScope",
          "p": 1900634
        }
      ],
      "n": "ResolveSingle",
      "d": 95740,
      "h": 124554147324,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124554147324),
//--TRIMMABLE-BOUNDARY-START(120259180028),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "provider",
          "p": 423420
        },
        {
          "n": "currentScope",
          "p": 1900634,
          "f": 4
        }
      ],
      "n": "ResolveMany",
      "d": 95740,
      "h": 120259180028,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120259180028),
//--TRIMMABLE-BOUNDARY-START(115964212732),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "provider",
          "p": 423420
        },
        {
          "n": "currentScope",
          "p": 1900634,
          "f": 4
        }
      ],
      "n": "Resolve",
      "d": 95740,
      "h": 115964212732,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115964212732),
//--TRIMMABLE-BOUNDARY-START(94489376252),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetServiceInternal",
      "d": 95740,
      "h": 94489376252,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94489376252),
//--TRIMMABLE-BOUNDARY-START(90194408956),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "GetService",
      "d": 95740,
      "h": 90194408956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194408956),
//--TRIMMABLE-BOUNDARY-START(42949768700),
    {
      "r": 1048666,
      "n": "CreateScope",
      "d": 95740,
      "h": 42949768700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949768700),
//--TRIMMABLE-BOUNDARY-START(103079310844),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "IsService",
      "d": 95740,
      "h": 103079310844,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079310844),
//--TRIMMABLE-BOUNDARY-START(111669245436),
    {
      "r": 65537,
      "p": [
        {
          "n": "assemblies",
          "p": $.$$.SCG.IEnumerable$$($.$$.SR.Assembly).$h
        }
      ],
      "n": "RegisterServicesInAssemblies",
      "d": 95740,
      "h": 111669245436,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669245436),
//--TRIMMABLE-BOUNDARY-START(81604474364),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedService",
      "d": 95740,
      "h": 81604474364,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604474364),
//--TRIMMABLE-BOUNDARY-START(85899441660),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetRequiredKeyedService",
      "d": 95740,
      "h": 85899441660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899441660),
//--TRIMMABLE-BOUNDARY-START(146028983804),
    {
      "r": 65537,
      "p": [
        {
          "n": "newServiceLifetime",
          "p": 1900634
        },
        {
          "n": "currentScope",
          "p": 1900634
        }
      ],
      "n": "ValidateLifetime",
      "d": 95740,
      "h": 146028983804,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(146028983804),
//--TRIMMABLE-BOUNDARY-START(107374278140),
    {
      "r": 262145,
      "p": [
        {
          "n": "newServiceLifetime",
          "p": 1900634
        },
        {
          "n": "currentScope",
          "p": 1900634
        }
      ],
      "n": "IsValidateLifetime",
      "d": 95740,
      "h": 107374278140,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(107374278140)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590030332),
    {
      "t": $.$$.SCG.List$$($.$lmWW.LCFCS.IServiceResolver).$h,
      "n": "_resolvers",
      "d": 95740,
      "h": 8590030332,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590030332),
//--TRIMMABLE-BOUNDARY-START(4295063036),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object), $.$$.S.Object).$h,
      "n": "_resolvedServices",
      "d": 95740,
      "h": 4295063036,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295063036)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30064866812),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "startupOptions",
          "p": 63211862
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 95740,
      "h": 30064866812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064866812)
  ],
  "h": 95740
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$lmWW.LCFCS.IExtensibleServiceProviderRoot, $.$lmWW.LCFCS.IExtensibleServiceProvider, $.$mxdi.MED.IKeyedServiceProvider, $.$scm.S.IServiceProvider, $.$mxdi.MED.IServiceScopeFactory, $.$mxdi.MED.IServiceProviderIsService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.ExtensibleServiceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}ExtensibleServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(95740)
        
        

        //--TRIMMABLE-BOUNDARY-START(292348)
        $asm.$cls(`$lmWW.LCFCS.ExtensibleServiceProviderScope`, ($self) => class ExtensibleServiceProviderScope extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81604670972)
            /*ExtensibleServiceProvider*/ root = null;
            //--TRIMMABLE-BOUNDARY-END(81604670972)
            
            //--TRIMMABLE-BOUNDARY-START(4295259644)
            /*Dictionary<(Type, object?), object>*/ _resolvedServices = null;
            //--TRIMMABLE-BOUNDARY-END(4295259644)
            
            //--TRIMMABLE-BOUNDARY-START(8590226940)
            $ctor$1(/*ExtensibleServiceProvider*/ root)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590226940);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.root = root;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590226940)
            
            //--TRIMMABLE-BOUNDARY-START(85899638268)
            /*IExtensibleServiceProviderRoot */ get Root()
            {
                return this.root;
            }
            //--TRIMMABLE-BOUNDARY-END(85899638268)
            
            //--TRIMMABLE-BOUNDARY-START(90194605564)
            /*IServiceProvider */ get ServiceProvider()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(90194605564)
            
            //--TRIMMABLE-BOUNDARY-START(94489572860)
            /*IServiceCollection */ get Services()
            {
                return this.root.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(94489572860)
            
            //--TRIMMABLE-BOUNDARY-START(17180161532)
            /*IConfiguration */ get Configuration()
            {
                return this.root.Configuration;
            }
            //--TRIMMABLE-BOUNDARY-END(17180161532)
            
            //--TRIMMABLE-BOUNDARY-START(12885194236)
            /*void */ AddResolver(/*IServiceResolver*/ resolver)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885194236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.root.AddResolver(resolver);
            }
            //--TRIMMABLE-BOUNDARY-END(12885194236)
            
            //--TRIMMABLE-BOUNDARY-START(21475128828)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475128828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en1 = this._resolvedServices.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let service = $en1.Current;
                    {
                        let dispose;
                        if ($.$is(service.Value, $.$$.S.IDisposable, { set $v($v){ dispose = $v; } }))
                        {
                            dispose.S$IDisposable$Dispose();
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475128828)
            
            //--TRIMMABLE-BOUNDARY-START(73014736380)
            /*object? */ GetServiceInternal(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014736380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (serviceType === $.$mxdi.MED.IServiceScope.$type)
                {
                    return new $.$lmWW.LCFCS.ExtensibleServiceProviderScope().$ctor$1(this.root);
                }
                if (serviceType === $.$scm.S.IServiceProvider.$type)
                {
                    return this;
                }
                if (serviceType === $.$mxdi.MED.IServiceProviderIsService.$type)
                {
                    return this;
                }
                //lock(this)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this)
                    {
                        /*var*/ let service;
                        if (this._resolvedServices.TryGetValue(new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object))().$ctor$3(serviceType, serviceKey), $.$ref(() => service, ($v) => service = $v, $.$$.S.Object)))
                        {
                            return service;
                        }
                        /*var*/ let startScope = 1/*ServiceLifetime.Scoped*/;
                        service = this.root.Resolve(serviceType, serviceKey, this, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mxdi.MED.ServiceLifetime, () => startScope, ($v) => startScope = $v, null, true));
                        if (service !== null && startScope !== 2/*ServiceLifetime.Transient*/)
                        {
                            this._resolvedServices.Add(new ($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object))().$ctor$3(serviceType, serviceKey), service);
                        }
                        else 
                        {
                        }
                        return service;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014736380)
            
            //--TRIMMABLE-BOUNDARY-START(68719769084)
            /*object? */ GetService(/*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719769084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetServiceInternal(serviceType, null);
            }
            //--TRIMMABLE-BOUNDARY-END(68719769084)
            
            //--TRIMMABLE-BOUNDARY-START(77309703676)
            /*bool */ IsService(/*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309703676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.root.IsService(serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(77309703676)
            
            //--TRIMMABLE-BOUNDARY-START(60129834492)
            /*object? */ GetKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129834492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetServiceInternal(serviceType, serviceKey);
            }
            //--TRIMMABLE-BOUNDARY-END(60129834492)
            
            //--TRIMMABLE-BOUNDARY-START(64424801788)
            /*object */ GetRequiredKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424801788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$firstOf(this.GetServiceInternal(serviceType, serviceKey), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Cannot resolve ${$.$strNN(serviceType.FullName)}`) });
            }
            //--TRIMMABLE-BOUNDARY-END(64424801788)
            
            //--TRIMMABLE-BOUNDARY-START(8590489084)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProviderScope.Root.get
            get LCFCS$IExtensibleServiceProviderScope$Root()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885456380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Root;
            }
            //--TRIMMABLE-BOUNDARY-END(8590489084)
            
            //--TRIMMABLE-BOUNDARY-START(21475259900)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProvider.Services.get
            get LCFCS$IExtensibleServiceProvider$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770227196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(21475259900)
            
            //--TRIMMABLE-BOUNDARY-START(12885325308)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.ServiceProvider.IExtensibleServiceProvider.Configuration.get
            get LCFCS$IExtensibleServiceProvider$Configuration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295390716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configuration;
            }
            //--TRIMMABLE-BOUNDARY-END(12885325308)
            
            //--TRIMMABLE-BOUNDARY-START(4295688282)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetKeyedService(System.Type, object?)
            MED$IKeyedServiceProvider$GetKeyedService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetKeyedService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688282)
            
            //--TRIMMABLE-BOUNDARY-START(8590655578)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetRequiredKeyedService(System.Type, object?)
            MED$IKeyedServiceProvider$GetRequiredKeyedService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590655578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetRequiredKeyedService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590655578)
            
            //--TRIMMABLE-BOUNDARY-START(4295295014)
            //Generated interface implemetation for System.IServiceProvider.GetService(System.Type)
            S$IServiceProvider$GetService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295014)
            
            //--TRIMMABLE-BOUNDARY-START(8590983258)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceScope.ServiceProvider.get
            get MED$IServiceScope$ServiceProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983258)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(4295950426)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderIsService.IsService(System.Type)
            MED$IServiceProviderIsService$IsService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295950426)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295259644)
                this._resolvedServices = new ($.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object), $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295259644)
                
            }
            static $h = 292348;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85899638268),
    {
      "p": 488956,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654998012,
        "f": 50331649
      },
      "n": "Root",
      "d": 292348,
      "h": 85899638268,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899638268),
//--TRIMMABLE-BOUNDARY-START(90194605564),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244932604,
        "f": 50331649
      },
      "n": "ServiceProvider",
      "d": 292348,
      "h": 90194605564,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194605564),
//--TRIMMABLE-BOUNDARY-START(94489572860),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834867196,
        "f": 50331649
      },
      "n": "Services",
      "d": 292348,
      "h": 94489572860,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489572860),
//--TRIMMABLE-BOUNDARY-START(17180161532),
    {
      "p": 393310,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065063420,
        "f": 50331649
      },
      "n": "Configuration",
      "d": 292348,
      "h": 17180161532,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180161532)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885194236),
    {
      "r": 65537,
      "p": [
        {
          "n": "resolver",
          "p": 620028
        }
      ],
      "n": "AddResolver",
      "d": 292348,
      "h": 12885194236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885194236),
//--TRIMMABLE-BOUNDARY-START(21475128828),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 292348,
      "h": 21475128828,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475128828),
//--TRIMMABLE-BOUNDARY-START(73014736380),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetServiceInternal",
      "d": 292348,
      "h": 73014736380,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014736380),
//--TRIMMABLE-BOUNDARY-START(68719769084),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "GetService",
      "d": 292348,
      "h": 68719769084,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719769084),
//--TRIMMABLE-BOUNDARY-START(77309703676),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "IsService",
      "d": 292348,
      "h": 77309703676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309703676),
//--TRIMMABLE-BOUNDARY-START(60129834492),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedService",
      "d": 292348,
      "h": 60129834492,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129834492),
//--TRIMMABLE-BOUNDARY-START(64424801788),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetRequiredKeyedService",
      "d": 292348,
      "h": 64424801788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424801788)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81604670972),
    {
      "t": 95740,
      "n": "root",
      "d": 292348,
      "h": 81604670972,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81604670972),
//--TRIMMABLE-BOUNDARY-START(4295259644),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$$.S.Type, $.$$.S.Object), $.$$.S.Object).$h,
      "n": "_resolvedServices",
      "d": 292348,
      "h": 4295259644,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295259644)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590226940),
    {
      "p": [
        {
          "n": "root",
          "p": 95740
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 292348,
      "h": 8590226940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590226940)
  ],
  "h": 292348
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$lmWW.LCFCS.IExtensibleServiceProviderScope, $.$lmWW.LCFCS.IExtensibleServiceProvider, $.$mxdi.MED.IKeyedServiceProvider, $.$scm.S.IServiceProvider, $.$mxdi.MED.IServiceScope, $.$$.S.IDisposable, $.$mxdi.MED.IServiceProviderIsService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.ExtensibleServiceProviderScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}ExtensibleServiceProviderScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(292348)
        
        

        //--TRIMMABLE-BOUNDARY-START(947708)
        $asm.$cls(`$lmWW.LCFCS.ServiceInstanceInstanceActivator`, ($self) => class ServiceInstanceInstanceActivator extends $.$lmWW.LCFCS.ServiceInstanceActivator
        {
            //--TRIMMABLE-BOUNDARY-START(4295915004)
            $ctor$2(/*ServiceDescriptor*/ descriptor)
            {
                super.$ctor$1(descriptor);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295915004);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295915004)
            
            //--TRIMMABLE-BOUNDARY-START(8590882300)
            /*object? */ Activate(/*IExtensibleServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590882300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Descriptor.IsKeyedService)
                {
                    return this.Descriptor.KeyedImplementationInstance;
                }
                else 
                {
                    return this.Descriptor.ImplementationInstance;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590882300)
            
            static $h = 947708;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lmWW.LCFCS.ServiceInstanceActivator; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590882300),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvider",
          "p": 423420
        }
      ],
      "n": "Activate",
      "d": 947708,
      "h": 8590882300,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590882300)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295915004),
    {
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 947708,
      "h": 4295915004,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295915004)
  ],
  "h": 947708
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.ServiceInstanceInstanceActivator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}ServiceInstanceInstanceActivator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(947708)
        
        

        //--TRIMMABLE-BOUNDARY-START(816636)
        $asm.$cls(`$lmWW.LCFCS.ServiceFactoryInstanceActivator`, ($self) => class ServiceFactoryInstanceActivator extends $.$lmWW.LCFCS.ServiceInstanceActivator
        {
            //--TRIMMABLE-BOUNDARY-START(4295783932)
            $ctor$2(/*ServiceDescriptor*/ descriptor)
            {
                super.$ctor$1(descriptor);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295783932);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295783932)
            
            //--TRIMMABLE-BOUNDARY-START(8590751228)
            /*object? */ Activate(/*IExtensibleServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590751228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Descriptor.IsKeyedService)
                {
                    return this.Descriptor.KeyedImplementationFactory.Invoke(serviceProvider, this.Descriptor.ServiceKey);
                }
                else 
                {
                    return this.Descriptor.ImplementationFactory.Invoke(serviceProvider);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590751228)
            
            static $h = 816636;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lmWW.LCFCS.ServiceInstanceActivator; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590751228),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvider",
          "p": 423420
        }
      ],
      "n": "Activate",
      "d": 816636,
      "h": 8590751228,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590751228)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295783932),
    {
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 816636,
      "h": 4295783932,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295783932)
  ],
  "h": 816636
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.ServiceFactoryInstanceActivator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}ServiceFactoryInstanceActivator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(816636)
        
        

        //--TRIMMABLE-BOUNDARY-START(751100)
        $asm.$cls(`$lmWW.LCFCS.ServiceConstructorActivator`, ($self) => class ServiceConstructorActivator extends $.$lmWW.LCFCS.ServiceInstanceActivator
        {
            //--TRIMMABLE-BOUNDARY-START(17180620284)
            /*Type*/ implementationType = null;
            //--TRIMMABLE-BOUNDARY-END(17180620284)
            
            //--TRIMMABLE-BOUNDARY-START(12885652988)
            /*ConstructorInfo*/ $constructor = null;
            //--TRIMMABLE-BOUNDARY-END(12885652988)
            
            //--TRIMMABLE-BOUNDARY-START(21475587580)
            /*object?*/ serviceKey = null;
            //--TRIMMABLE-BOUNDARY-END(21475587580)
            
            //--TRIMMABLE-BOUNDARY-START(4295718396)
            $ctor$2(/*ServiceDescriptor*/ descriptor, /*Type*/ serviceType, /*object?*/ serviceKey, /*IExtensibleServiceProvider*/ serviceProvider)
            {
                super.$ctor$1(descriptor);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295718396);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.implementationType = descriptor.IsKeyedService ? descriptor.KeyedImplementationType : descriptor.ImplementationType;
                    if (this.implementationType.IsGenericTypeDefinition && serviceType.IsGenericType)
                    {
                        /*var*/ let args = serviceType.GetGenericArguments();
                        this.implementationType = this.implementationType.MakeGenericType(args);
                    }
                    /*var*/ let constructors = this.implementationType.GetConstructors$1(4/*BindingFlags.Instance*/ | 16/*BindingFlags.Public*/);
                    if (constructors.length === 0)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`No public constructor is defined on ${$.$strNN(this.implementationType.Name)}`);
                    }
                    else if (constructors.length > 1)
                    {
                        this.$constructor = $.$firstOf($.$sl.SL.Enumerable.MaxBy$1($.$$.SR.ConstructorInfo, $.$$.S.Int32, constructors, new ($.$$.S.Func$$$($.$$.SR.ConstructorInfo, $.$$.S.Int32))().$ctor(this,  (/*c*/ c) =>
                        {
                            /*var*/ let parameters = c.GetParameters();
                            if ($.$sl.SL.Enumerable.All($.$$.SR.ParameterInfo, parameters, new ($.$$.S.Func$$$($.$$.SR.ParameterInfo, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                            {
                                return $.$sl.SL.Enumerable.Any$1($.$mxdi.MED.ServiceDescriptor, $.$lmWW.LCFCS.ExtensibleServiceProviderExtension.GetServiceDescriptors(serviceProvider.LCFCS$IExtensibleServiceProvider$Services, p.ParameterType, null));
                            }, $ZfRVxe ??= {"r":262145,"p":[{"n":"p","p":119078913}],"n":"","d":751100,"h":0,"f":17825794})))
                            {
                                /*var*/ let parametersCount = parameters.length;
                                return parametersCount;
                            }
                            return 0;
                        }, $uJPZff ??= {"r":655361,"p":[{"n":"c","p":109182977}],"n":"","d":751100,"h":0,"f":17825794})), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`No constructor on ${$.$strNN(serviceType.FullName)} can be used to instatiate it from the container`) });
                    }
                    else 
                    {
                        this.$constructor = $.$$.System.Array.$ReadT1.call(constructors, 0);
                    }
                    this.serviceKey = serviceKey;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295718396)
            
            //--TRIMMABLE-BOUNDARY-START(8590685692)
            /*object? */ Activate(/*IExtensibleServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590685692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let types = this.$constructor.GetParameters();
                /*var*/ let parameters = $.$sl.SL.Enumerable.ToArray($.$$.S.Object, $.$sl.SL.Enumerable.Select$1($.$$.SR.ParameterInfo, $.$$.S.Object, types, new ($.$$.S.Func$$$($.$$.SR.ParameterInfo, $.$$.S.Object))().$ctor(this,  (/*t*/ t) =>
                {
                    if (this.serviceKey !== null)
                    {
                        /*var*/ let service = serviceProvider.MED$IKeyedServiceProvider$GetKeyedService(t.ParameterType, this.serviceKey);
                        if (service !== null)
                        {
                            return service;
                        }
                    }
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService(serviceProvider, t.ParameterType);
                }, $eEPjyg ??= {"r":131073,"p":[{"n":"t","p":119078913}],"n":"","d":751100,"h":0,"f":17825794})));
                return this.$constructor.Invoke$2(parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(8590685692)
            
            static $h = 751100;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$lmWW.LCFCS.ServiceInstanceActivator; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590685692),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvider",
          "p": 423420
        }
      ],
      "n": "Activate",
      "d": 751100,
      "h": 8590685692,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590685692)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180620284),
    {
      "t": 188547073,
      "n": "implementationType",
      "d": 751100,
      "h": 17180620284,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180620284),
//--TRIMMABLE-BOUNDARY-START(12885652988),
    {
      "t": 109182977,
      "n": "constructor",
      "o": "$constructor",
      "d": 751100,
      "h": 12885652988,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885652988),
//--TRIMMABLE-BOUNDARY-START(21475587580),
    {
      "t": 131073,
      "n": "serviceKey",
      "d": 751100,
      "h": 21475587580,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475587580)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295718396),
    {
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "serviceProvider",
          "p": 423420
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 751100,
      "h": 4295718396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295718396)
  ],
  "h": 751100
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.ServiceConstructorActivator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}ServiceConstructorActivator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(751100)
        
        

        //--TRIMMABLE-BOUNDARY-START(226812)
        $asm.$cls(`$lmWW.LCFCS.ExtensibleServiceProviderFactory`, ($self) => class ExtensibleServiceProviderFactory extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295194108)
            /*IConfiguration*/ _configuration = null;
            //--TRIMMABLE-BOUNDARY-END(4295194108)
            
            //--TRIMMABLE-BOUNDARY-START(8590161404)
            /*StartupOptions*/ _options;
            //--TRIMMABLE-BOUNDARY-END(8590161404)
            
            //--TRIMMABLE-BOUNDARY-START(12885128700)
            $ctor$1(/*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885128700);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._configuration = configuration;
                    this._options = $.$clone(options);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885128700)
            
            //--TRIMMABLE-BOUNDARY-START(17180095996)
            /*IServiceCollection */ CreateBuilder(/*IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180095996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(17180095996)
            
            //--TRIMMABLE-BOUNDARY-START(21475063292)
            /*IServiceProvider */ CreateServiceProvider(/*IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475063292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let newServices = new $.$mxdi.MED.ServiceCollection().$ctor$1();
                let $en1 = services.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let service = $en1.SCG$IEnumerator$$$Current;
                    {
                        $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.Add(newServices, service);
                    }
                }
                return new $.$lmWW.LCFCS.ExtensibleServiceProvider().$ctor$1(newServices, this._configuration, $.$clone(this._options));
            }
            //--TRIMMABLE-BOUNDARY-END(21475063292)
            
            //--TRIMMABLE-BOUNDARY-START(4295819354)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<Microsoft.Extensions.DependencyInjection.IServiceCollection>.CreateBuilder(Microsoft.Extensions.DependencyInjection.IServiceCollection)
            MED$IServiceProviderFactory$Microsoft$Extensions$DependencyInjection$IServiceCollection$CreateBuilder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateBuilder(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295819354)
            
            //--TRIMMABLE-BOUNDARY-START(8590786650)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<Microsoft.Extensions.DependencyInjection.IServiceCollection>.CreateServiceProvider(Microsoft.Extensions.DependencyInjection.IServiceCollection)
            MED$IServiceProviderFactory$Microsoft$Extensions$DependencyInjection$IServiceCollection$CreateServiceProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateServiceProvider(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590786650)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590161404)
                this._options = $.$default($.$fPer.LCFCS$3.StartupOptions);
                //--TRIMMABLE-BOUNDARY-END(8590161404)
                
            }
            static $h = 226812;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180095996),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "CreateBuilder",
      "d": 226812,
      "h": 17180095996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180095996),
//--TRIMMABLE-BOUNDARY-START(21475063292),
    {
      "r": 327718,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "CreateServiceProvider",
      "d": 226812,
      "h": 21475063292,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475063292)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295194108),
    {
      "t": 393310,
      "n": "_configuration",
      "d": 226812,
      "h": 4295194108,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295194108),
//--TRIMMABLE-BOUNDARY-START(8590161404),
    {
      "t": 63211862,
      "n": "_options",
      "d": 226812,
      "h": 8590161404,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590161404)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885128700),
    {
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 226812,
      "h": 12885128700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885128700)
  ],
  "h": 226812
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.MED.IServiceProviderFactory$$($.$mxdi.MED.IServiceCollection) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.ServiceProvider.ExtensibleServiceProviderFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}ServiceProvider${separator}ExtensibleServiceProviderFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(226812)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(30204)
