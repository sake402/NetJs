
//--TRIMMABLE-BOUNDARY-START(46285)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt, $Iaui, $uvJL) {
    "use strict";
    let _;
    let $nOVISg;
    let $XSyMib;
    let $YRlDdl;
    let $tgCuYa;
    let $pnsXZh;
    let $Punvmk;
    let $LpOUIa;
    let $NygEva;
    let $ixUmAh;
    let $Lfeqek;
    let $PPBbqk;
    let $ATSdrh;
    let $OeASLe;
    let $WfVkGb;
    let $tWXtNb;
    let $SLEJDk;
    let $GZcauk;
    let $IJJxIb;
    let $mrxOab;
    let $uLLCAi;
    let $KkRZgb;
    let $SeOqCh;
    let $vFgZNd;
    let $cUSMKa;
    let $wUKfle;
    let $aFQIab;
    let $tppcOc;
    let $qqklpf;
    let $ZKzRCc;
    let $FMOovb;
    let $txYRhk;
    let $MTQPNk;
    let $IgIUqk;
    let $ZWwIAi;
    let $ibjrvb;
    let $Vdcdqd;
    let $YGKgKd;
    let $uRRJbl;
    let $tZknJh;
    let $xIZzOa;
    let $Rtnyig;
    let $BHVAhi;
    let $wNSleb;
    let $inDBQk;
    let $llNUli;
    let $Jyekej;
    let $xvtpSf;
    let $WgyVGi;
    let $mIEUmg;
    let $gpLJEc;
    let $zegkei;
    let $lkJCUd;
    let $phWTza;
    let $RJWIXb;
    let $djwzye;
    let $uEwrrj;
    let $yxCkSb;
    let $EcCNvi;
    let $iDqgqg;
    let $ybcxKb;
    let $JJkvgc;
    let $nfOlwc;
    let $DcpCGb;
    let $aEalhl;
    let $KkXyAc;
    let $BWjMol;
    let $MmWcMd;
    let $wCzsZk;
    let $UWoXuh;
    let $ZDFqbg;
    let $akuyOg;
    let $UAbIFi;
    let $xuJNSe;
    let $pBDGRh;
    let $gIdXJa;
    let $KNvmCe;
    let $lNLcSa;
    let $viOaFd;
    let $ZBFNei;
    let $EXWRde;
    let $zTNYDg;
    let $aCyqWg;
    let $Acyubc;
    let $qgMikk;
    let $trtkhf;
    let $VLZxUd;
    let $lpdmnh;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Wallet", 
    {
  "h": 46285,
  "f": "LivingThing.Core.Frameworks.Common.Wallet",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Wallet",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Wallet",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(767181)
        $asm.$cls(`$OJJQ.LCFCW.IWalletOnlinePaymentProvider`, ($self) => class IWalletOnlinePaymentProvider
        {
            static $h = 767181;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295734477),
    {
      "r": 1179649,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "token",
          "p": 3257549
        }
      ],
      "n": "GetBalance",
      "o": "LCFCW$IWalletOnlinePaymentProvider$GetBalance",
      "d": 767181,
      "h": 4295734477,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295734477)
  ],
  "h": 767181
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletOnlinePaymentProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletOnlinePaymentProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(767181)
        
        

        //--TRIMMABLE-BOUNDARY-START(505037)
        $asm.$cls(`$OJJQ.LCFCW.IWalletFundPaymentProvider`, ($self) => class IWalletFundPaymentProvider
        {
            static $h = 505037;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295472333),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Double).$h,
      "n": "FundAsync",
      "o": "LCFCW$IWalletFundPaymentProvider$FundAsync",
      "d": 505037,
      "h": 4295472333,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295472333)
  ],
  "h": 505037
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletFundPaymentProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletFundPaymentProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(505037)
        
        

        //--TRIMMABLE-BOUNDARY-START(898253)
        $asm.$cls(`$OJJQ.LCFCW.IWalletPaymentSendProgressReportIndicator`, ($self) => class IWalletPaymentSendProgressReportIndicator
        {
            static $h = 898253;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590832845),
    {
      "r": 65537,
      "p": [
        {
          "n": "progress",
          "p": 1114113
        }
      ],
      "n": "ReportProgress",
      "o": "LCFCW$IWalletPaymentSendProgressReportIndicator$ReportProgress",
      "d": 898253,
      "h": 8590832845,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590832845),
//--TRIMMABLE-BOUNDARY-START(4295865549),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ReportMessage",
      "o": "LCFCW$IWalletPaymentSendProgressReportIndicator$ReportMessage",
      "d": 898253,
      "h": 4295865549,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295865549)
  ],
  "h": 898253
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentSendProgressReportIndicator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletPaymentSendProgressReportIndicator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(898253)
        
        

        //--TRIMMABLE-BOUNDARY-START(963789)
        $asm.$cls(`$OJJQ.LCFCW.IWalletQRPaymentScannerProvider`, ($self) => class IWalletQRPaymentScannerProvider
        {
            static $h = 963789;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295931085),
    {
      "r": $.$$.STT.ValueTask$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "ScanPeer",
      "o": "LCFCW$IWalletQRPaymentScannerProvider$ScanPeer",
      "d": 963789,
      "h": 4295931085,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295931085)
  ],
  "h": 963789
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletQRPaymentScannerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletQRPaymentScannerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(963789)
        
        

        //--TRIMMABLE-BOUNDARY-START(832717)
        $asm.$cls(`$OJJQ.LCFCW.IWalletPaymentReceiveProgressReportIndicator`, ($self) => class IWalletPaymentReceiveProgressReportIndicator
        {
            static $h = 832717;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295800013),
    {
      "r": 181338113,
      "p": [
        {
          "n": "peer",
          "p": 570573
        }
      ],
      "n": "OnSenderPaired",
      "o": "LCFCW$IWalletPaymentReceiveProgressReportIndicator$OnSenderPaired",
      "d": 832717,
      "h": 4295800013,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295800013),
//--TRIMMABLE-BOUNDARY-START(17180701901),
    {
      "r": 65537,
      "p": [
        {
          "n": "progress",
          "p": 1114113
        }
      ],
      "n": "ReportProgress",
      "o": "LCFCW$IWalletPaymentReceiveProgressReportIndicator$ReportProgress",
      "d": 832717,
      "h": 17180701901,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180701901),
//--TRIMMABLE-BOUNDARY-START(12885734605),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ReportMessage",
      "o": "LCFCW$IWalletPaymentReceiveProgressReportIndicator$ReportMessage",
      "d": 832717,
      "h": 12885734605,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885734605),
//--TRIMMABLE-BOUNDARY-START(8590767309),
    {
      "r": 181338113,
      "p": [
        {
          "n": "from",
          "p": 570573
        },
        {
          "n": "tokens",
          "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken).$h
        }
      ],
      "n": "OnTokenReceived",
      "o": "LCFCW$IWalletPaymentReceiveProgressReportIndicator$OnTokenReceived",
      "d": 832717,
      "h": 8590767309,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590767309)
  ],
  "h": 832717
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletPaymentReceiveProgressReportIndicator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletPaymentReceiveProgressReportIndicator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(832717)
        
        

        //--TRIMMABLE-BOUNDARY-START(1225933)
        $asm.$cls(`$OJJQ.LCFCW.IWalletServices`, ($self) => class IWalletServices
        {
            static $h = 1225933;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245866189),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476062413,
        "f": 50331905
      },
      "n": "Issuers",
      "o": "LCFCW$IWalletServices$Issuers",
      "d": 1225933,
      "h": 47245866189,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47245866189),
//--TRIMMABLE-BOUNDARY-START(51540833485),
    {
      "p": 701645,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065997005,
        "f": 50331905
      },
      "n": "OfflinePayment",
      "o": "LCFCW$IWalletServices$OfflinePayment",
      "d": 1225933,
      "h": 51540833485,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51540833485),
//--TRIMMABLE-BOUNDARY-START(55835800781),
    {
      "p": 767181,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655931597,
        "f": 50331905
      },
      "n": "OnlinePayment",
      "o": "LCFCW$IWalletServices$OnlinePayment",
      "d": 1225933,
      "h": 55835800781,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(55835800781),
//--TRIMMABLE-BOUNDARY-START(4296193229),
    {
      "p": 505037,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886127821,
        "f": 50331905
      },
      "n": "FundPayment",
      "o": "LCFCW$IWalletServices$FundPayment",
      "d": 1225933,
      "h": 4296193229,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296193229)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950898893),
    {
      "r": $.$$.STT.ValueTask$$($.$OJJQ.LCFCW.IWalletHolder).$h,
      "p": [
        {
          "n": "networkAddress",
          "p": 1310721
        }
      ],
      "n": "GetHolder",
      "o": "LCFCW$IWalletServices$GetHolder",
      "d": 1225933,
      "h": 42950898893,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950898893)
  ],
  "h": 1225933
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletServices`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletServices`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1225933)
        
        

        //--TRIMMABLE-BOUNDARY-START(1160397)
        $asm.$cls(`$OJJQ.LCFCW.IWalletRewardService`, ($self) => class IWalletRewardService
        {
            static $h = 1160397;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296127693),
    {
      "r": $.$$.STT.Task$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$h,
      "p": [
        {
          "n": "accountId",
          "p": 89784321
        },
        {
          "n": "coinType",
          "p": 1310721
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "reference",
          "p": 1310721
        },
        {
          "n": "destination",
          "p": 2536653,
          "f": 65,
          "v": 2
        },
        {
          "n": "transactionDescription",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "RewardCoin",
      "o": "LCFCW$IWalletRewardService$RewardCoin",
      "d": 1160397,
      "h": 4296127693,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296127693)
  ],
  "h": 1160397
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletRewardService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletRewardService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1160397)
        
        

        //--TRIMMABLE-BOUNDARY-START(701645)
        $asm.$cls(`$OJJQ.LCFCW.IWalletOfflinePaymentProvider`, ($self) => class IWalletOfflinePaymentProvider
        {
            static $h = 701645;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590636237),
    {
      "r": $.$$.STT.Task$$($.$$.S.IDisposable).$h,
      "p": [
        {
          "n": "self",
          "p": 570573
        },
        {
          "n": "receiverHandler",
          "p": 832717
        }
      ],
      "n": "ReceiveOffline",
      "o": "LCFCW$IWalletOfflinePaymentProvider$ReceiveOffline",
      "d": 701645,
      "h": 8590636237,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590636237),
//--TRIMMABLE-BOUNDARY-START(4295668941),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "sender",
          "p": 570573
        },
        {
          "n": "recipient",
          "p": 570573
        },
        {
          "n": "denominations",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h
        },
        {
          "n": "pinCode",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        },
        {
          "n": "progressIndicator",
          "p": 898253
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "PayOffline",
      "o": "LCFCW$IWalletOfflinePaymentProvider$PayOffline",
      "d": 701645,
      "h": 4295668941,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295668941)
  ],
  "h": 701645
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletOfflinePaymentProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletOfflinePaymentProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(701645)
        
        

        //--TRIMMABLE-BOUNDARY-START(1357005)
        $asm.$cls(`$OJJQ.LCFCW.IWalletToken`, ($self) => class IWalletToken
        {
            static $h = 1357005;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886258893),
    {
      "p": 2864333,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951029965,
        "f": 50331905
      },
      "n": "CoinIdentifier",
      "o": "LCFCW$IWalletToken$CoinIdentifier",
      "d": 1357005,
      "h": 12886258893,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886258893),
//--TRIMMABLE-BOUNDARY-START(4296324301),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771160781,
        "f": 50331905
      },
      "n": "Amount",
      "o": "LCFCW$IWalletToken$Amount",
      "d": 1357005,
      "h": 4296324301,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296324301),
//--TRIMMABLE-BOUNDARY-START(17181226189),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540964557,
        "f": 50331905
      },
      "n": "FrozenAmount",
      "o": "LCFCW$IWalletToken$FrozenAmount",
      "d": 1357005,
      "h": 17181226189,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17181226189),
//--TRIMMABLE-BOUNDARY-START(8591291597),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361095373,
        "f": 50331905
      },
      "n": "Cashback",
      "o": "LCFCW$IWalletToken$Cashback",
      "d": 1357005,
      "h": 8591291597,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591291597)
  ],
  "h": 1357005
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1357005)
        
        

        //--TRIMMABLE-BOUNDARY-START(1291469)
        $asm.$cls(`$OJJQ.LCFCW.IWalletSystem`, ($self) => class IWalletSystem
        {
            //--TRIMMABLE-BOUNDARY-START(81605670093)
            /*double */ LCFCW$IWalletSystem$GetTotal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605670093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.IWalletToken, $.$sl.SL.Enumerable.SelectMany$2($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$OJJQ.LCFCW.IWalletToken, this.LCFCW$IWalletSystem$Tokens, new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken), $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken)))().$ctor(this,  (/*t*/ t) =>
                {
                    return t;
                }, $ixUmAh ??= {"r":$.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletToken).$h,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken).$h}],"n":"","d":1291469,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletToken, $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.LCFCW$IWalletToken$Amount;
                }, $Lfeqek ??= {"r":1179649,"p":[{"n":"t","p":1357005}],"n":"","d":1291469,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(81605670093)
            
            static $h = 1291469;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103080506573),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361029837,
        "f": 50331905
      },
      "n": "Name",
      "o": "LCFCW$IWalletSystem$Name",
      "d": 1291469,
      "h": 103080506573,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103080506573),
//--TRIMMABLE-BOUNDARY-START(120260375757),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720768205,
        "f": 50331905
      },
      "n": "Title",
      "o": "LCFCW$IWalletSystem$Title",
      "d": 1291469,
      "h": 120260375757,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(120260375757),
//--TRIMMABLE-BOUNDARY-START(94490571981),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181160653,
        "f": 50331905
      },
      "n": "Icon",
      "o": "LCFCW$IWalletSystem$Icon",
      "d": 1291469,
      "h": 94490571981,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94490571981),
//--TRIMMABLE-BOUNDARY-START(115965408461),
    {
      "p": 65309014,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130833613,
        "f": 50331905
      },
      "n": "Theme",
      "o": "LCFCW$IWalletSystem$Theme",
      "d": 1291469,
      "h": 115965408461,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(115965408461),
//--TRIMMABLE-BOUNDARY-START(90195604685),
    {
      "p": 570573,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591226061,
        "f": 50331905
      },
      "n": "Holder",
      "o": "LCFCW$IWalletSystem$Holder",
      "d": 1291469,
      "h": 90195604685,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90195604685),
//--TRIMMABLE-BOUNDARY-START(98785539277),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.IWalletIssuer).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771095245,
        "f": 50331905
      },
      "n": "Issuers",
      "o": "LCFCW$IWalletSystem$Issuers",
      "d": 1291469,
      "h": 98785539277,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98785539277),
//--TRIMMABLE-BOUNDARY-START(124555343053),
    {
      "p": $.$$.SCG.IEnumerable$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.IWalletToken)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310702797,
        "f": 50331905
      },
      "n": "Tokens",
      "o": "LCFCW$IWalletSystem$Tokens",
      "d": 1291469,
      "h": 124555343053,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(124555343053),
//--TRIMMABLE-BOUNDARY-START(107375473869),
    {
      "p": $.$fPer.LCFCD.Pager$$($.$OJJQ.LCFCW.IWalletTransaction).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950964429,
        "f": 50331905
      },
      "n": "RecentTransactions",
      "o": "LCFCW$IWalletSystem$RecentTransactions",
      "d": 1291469,
      "h": 107375473869,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(107375473869),
//--TRIMMABLE-BOUNDARY-START(111670441165),
    {
      "p": 1225933,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540899021,
        "f": 50331905
      },
      "n": "Services",
      "o": "LCFCW$IWalletSystem$Services",
      "d": 1291469,
      "h": 111670441165,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(111670441165)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900637389),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$OJJQ.LCFCW.IWalletTransaction)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetTransactions",
      "o": "LCFCW$IWalletSystem$GetTransactions",
      "d": 1291469,
      "h": 85900637389,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(85900637389),
//--TRIMMABLE-BOUNDARY-START(81605670093),
    {
      "r": 1179649,
      "n": "GetTotal",
      "o": "LCFCW$IWalletSystem$GetTotal",
      "d": 1291469,
      "h": 81605670093,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81605670093)
  ],
  "h": 1291469
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletSystem`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletSystem`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1291469)
        
        

        //--TRIMMABLE-BOUNDARY-START(1422541)
        $asm.$cls(`$OJJQ.LCFCW.IWalletTransaction`, ($self) => class IWalletTransaction
        {
            static $h = 1422541;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591357133),
    {
      "p": 2864333,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361160909,
        "f": 50331905
      },
      "n": "Coin",
      "o": "LCFCW$IWalletTransaction$Coin",
      "d": 1422541,
      "h": 8591357133,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591357133),
//--TRIMMABLE-BOUNDARY-START(85900768461),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720899277,
        "f": 50331905
      },
      "n": "Reference",
      "o": "LCFCW$IWalletTransaction$Reference",
      "d": 1422541,
      "h": 85900768461,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(85900768461),
//--TRIMMABLE-BOUNDARY-START(17181291725),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541030093,
        "f": 50331905
      },
      "n": "Description",
      "o": "LCFCW$IWalletTransaction$Description",
      "d": 1422541,
      "h": 17181291725,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17181291725),
//--TRIMMABLE-BOUNDARY-START(12886324429),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951095501,
        "f": 50331905
      },
      "n": "Date",
      "o": "LCFCW$IWalletTransaction$Date",
      "d": 1422541,
      "h": 12886324429,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886324429),
//--TRIMMABLE-BOUNDARY-START(4296389837),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771226317,
        "f": 50331905
      },
      "n": "Amount",
      "o": "LCFCW$IWalletTransaction$Amount",
      "d": 1422541,
      "h": 4296389837,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296389837),
//--TRIMMABLE-BOUNDARY-START(90195735757),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310833869,
        "f": 50331905
      },
      "n": "Sender",
      "o": "LCFCW$IWalletTransaction$Sender",
      "d": 1422541,
      "h": 90195735757,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90195735757),
//--TRIMMABLE-BOUNDARY-START(81605801165),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130964685,
        "f": 50331905
      },
      "n": "Receiver",
      "o": "LCFCW$IWalletTransaction$Receiver",
      "d": 1422541,
      "h": 81605801165,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(81605801165)
  ],
  "h": 1422541
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletTransaction`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1422541)
        
        

        //--TRIMMABLE-BOUNDARY-START(439501)
        $asm.$cls(`$OJJQ.LCFCW.IDenominatedWalletSystem`, ($self) => class IDenominatedWalletSystem
        {
            static $h = 439501;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295406797),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.ValueTuple$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$OJJQ.LCFCW.WalletTokenDescriptor), $.$$.S.Double).$h,
      "p": [
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "Denominate",
      "o": "LCFCW$IDenominatedWalletSystem$Denominate",
      "d": 439501,
      "h": 4295406797,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295406797)
  ],
  "h": 439501
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IDenominatedWalletSystem`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IDenominatedWalletSystem`; }
        });
        //--TRIMMABLE-BOUNDARY-END(439501)
        
        

        //--TRIMMABLE-BOUNDARY-START(570573)
        $asm.$cls(`$OJJQ.LCFCW.IWalletHolder`, ($self) => class IWalletHolder
        {
            static $h = 570573;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885472461),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590505165,
        "f": 50331905
      },
      "n": "NetworkAddress",
      "o": "LCFCW$IWalletHolder$NetworkAddress",
      "d": 570573,
      "h": 12885472461,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885472461)
  ],
  "h": 570573
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletHolder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(570573)
        
        

        //--TRIMMABLE-BOUNDARY-START(242893)
        $asm.$cls(`$OJJQ.LCFCW.DefaultWalletDefinition`, ($self) => class DefaultWalletDefinition extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475079373)
            /*string*/ static GeneralCoinTitle = null;
            //--TRIMMABLE-BOUNDARY-END(21475079373)
            
            //--TRIMMABLE-BOUNDARY-START(12885144781)
            /*string*/ static GeneralCoinIssuerName = null;
            //--TRIMMABLE-BOUNDARY-END(12885144781)
            
            //--TRIMMABLE-BOUNDARY-START(17180112077)
            /*string*/ static GeneralCoinName = null;
            //--TRIMMABLE-BOUNDARY-END(17180112077)
            
            //--TRIMMABLE-BOUNDARY-START(8590177485)
            /*string*/ static GeneralCoinCurrencyUnit = null;
            //--TRIMMABLE-BOUNDARY-END(8590177485)
            
            //--TRIMMABLE-BOUNDARY-START(25770046669)
            /*string*/ static GeneralCoinType = null;
            //--TRIMMABLE-BOUNDARY-END(25770046669)
            
            //--TRIMMABLE-BOUNDARY-START(30065013965)
            /*double*/ static ReferrerAwardCoins = 1;
            //--TRIMMABLE-BOUNDARY-END(30065013965)
            
            //--TRIMMABLE-BOUNDARY-START(4295210189)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295210189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295210189)
            
            //--TRIMMABLE-BOUNDARY-START(4295210189)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295210189)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21475079373)
                    this.GeneralCoinTitle = "NG Coin";
                    //--TRIMMABLE-BOUNDARY-END(21475079373)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885144781)
                    this.GeneralCoinIssuerName = "NG";
                    //--TRIMMABLE-BOUNDARY-END(12885144781)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180112077)
                    this.GeneralCoinName = "\u20A6";
                    //--TRIMMABLE-BOUNDARY-END(17180112077)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590177485)
                    this.GeneralCoinCurrencyUnit = "\u20A6";
                    //--TRIMMABLE-BOUNDARY-END(8590177485)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770046669)
                    this.GeneralCoinType = "NG/\u20A6";
                    //--TRIMMABLE-BOUNDARY-END(25770046669)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 242893;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475079373),
    {
      "t": 1310721,
      "n": "GeneralCoinTitle",
      "d": 242893,
      "h": 21475079373,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475079373),
//--TRIMMABLE-BOUNDARY-START(12885144781),
    {
      "t": 1310721,
      "n": "GeneralCoinIssuerName",
      "d": 242893,
      "h": 12885144781,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885144781),
//--TRIMMABLE-BOUNDARY-START(17180112077),
    {
      "t": 1310721,
      "n": "GeneralCoinName",
      "d": 242893,
      "h": 17180112077,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180112077),
//--TRIMMABLE-BOUNDARY-START(8590177485),
    {
      "t": 1310721,
      "n": "GeneralCoinCurrencyUnit",
      "d": 242893,
      "h": 8590177485,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590177485),
//--TRIMMABLE-BOUNDARY-START(25770046669),
    {
      "t": 1310721,
      "n": "GeneralCoinType",
      "d": 242893,
      "h": 25770046669,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770046669),
//--TRIMMABLE-BOUNDARY-START(30065013965),
    {
      "t": 1179649,
      "n": "ReferrerAwardCoins",
      "d": 242893,
      "h": 30065013965,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065013965)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295210189),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 242893,
      "h": 4295210189,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295210189)
  ],
  "h": 242893
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.DefaultWalletDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}DefaultWalletDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(242893)
        
        

        //--TRIMMABLE-BOUNDARY-START(2143437)
        $asm.$cls(`$OJJQ.LCFCW.UserWalletSavedCard`, ($self) => class UserWalletSavedCard extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297110733)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297110733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297110733)
            
            //--TRIMMABLE-BOUNDARY-START(4297110733)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297110733)
            
            static $h = 2143437;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297110733),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2143437,
      "h": 4297110733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297110733)
  ],
  "h": 2143437
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.UserWalletSavedCard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}UserWalletSavedCard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2143437)
        
        

        //--TRIMMABLE-BOUNDARY-START(2929869)
        $asm.$cls(`$OJJQ.LCFCW.WalletIssuerExtension`, ($self) => class WalletIssuerExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4297897165)
            static /*string */ GetCoinId(/*this IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ coin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297897165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (issuer.LCFC$INamed$Name === coin.Name)
                {
                    return issuer.LCFC$INamed$Name;
                }
                return `${$.$strNN(issuer.LCFC$INamed$Name)}/${$.$strNN(coin.Name)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(4297897165)
            
            //--TRIMMABLE-BOUNDARY-START(8592864461)
            static /*string */ GetCoinName(/*this IWalletIssuer*/ issuer, /*WalletTokenDescriptor*/ coin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592864461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (issuer.LCFC$INamed$Name === coin.Name)
                {
                    return issuer.LCFC$INamed$Name;
                }
                return `${$.$strNN(issuer.LCFC$INamed$Name)} ${$.$strNN(coin.Name)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(8592864461)
            
            static $h = 2929869;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297897165),
    {
      "r": 1310721,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "coin",
          "p": 3257549
        }
      ],
      "n": "GetCoinId",
      "d": 2929869,
      "h": 4297897165,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297897165),
//--TRIMMABLE-BOUNDARY-START(8592864461),
    {
      "r": 1310721,
      "p": [
        {
          "n": "issuer",
          "p": 636109
        },
        {
          "n": "coin",
          "p": 3257549
        }
      ],
      "n": "GetCoinName",
      "d": 2929869,
      "h": 8592864461,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592864461)
  ],
  "h": 2929869
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletIssuerExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletIssuerExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2929869)
        
        

        //--TRIMMABLE-BOUNDARY-START(3126477)
        $asm.$cls(`$OJJQ.LCFCW.WalletServiceExtension`, ($self) => class WalletServiceExtension
        {
            //--TRIMMABLE-BOUNDARY-START(8593061069)
            static /*double */ GetTransactionFee(/*this double*/ amount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593061069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*double*/ let payStackFee = 0;
                /*double*/ let payCowryFee = 0;
                if (amount < 5000)
                {
                    payStackFee = 10;
                    payCowryFee = 5;
                }
                else if (amount < 50000)
                {
                    payStackFee = 25;
                    payCowryFee = 5;
                }
                else 
                {
                    payStackFee = 50;
                    payCowryFee = 10;
                }
                return payStackFee + payCowryFee;
            }
            //--TRIMMABLE-BOUNDARY-END(8593061069)
            
            //--TRIMMABLE-BOUNDARY-START(4298093773)
            static /*IWalletIssuer? */ GetIssuer(/*this IWalletServices*/ services, /*string*/ coinName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298093773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.SingleOrDefault$1($.$OJJQ.LCFCW.IWalletIssuer, services.LCFCW$IWalletServices$Issuers, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.IWalletIssuer, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c.LCFC$INamed$Name === coinName;
                }, $nOVISg ??= {"r":262145,"p":[{"n":"c","p":636109}],"n":"","d":3126477,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4298093773)
            
            static $h = 3126477;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593061069),
    {
      "r": 1179649,
      "p": [
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "GetTransactionFee",
      "d": 3126477,
      "h": 8593061069,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593061069),
//--TRIMMABLE-BOUNDARY-START(4298093773),
    {
      "r": 636109,
      "p": [
        {
          "n": "services",
          "p": 1225933
        },
        {
          "n": "coinName",
          "p": 1310721
        }
      ],
      "n": "GetIssuer",
      "d": 3126477,
      "h": 4298093773,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298093773)
  ],
  "h": 3126477
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletServiceExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletServiceExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3126477)
        
        

        //--TRIMMABLE-BOUNDARY-START(2602189)
        $asm.$cls(`$OJJQ.LCFCW.WalletDestinationCustomAttributesProvider`, ($self) => class WalletDestinationCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297569485)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297569485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297569485)
            
            static $h = 2602189;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297569485),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2602189,
      "h": 4297569485,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297569485)
  ],
  "h": 2602189
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletDestinationCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletDestinationCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2602189)
        
        

        //--TRIMMABLE-BOUNDARY-START(2733261)
        $asm.$cls(`$OJJQ.LCFCW.WalletFeaturesCustomAttributesProvider`, ($self) => class WalletFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297700557)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297700557)
            
            //--TRIMMABLE-BOUNDARY-START(8592667853)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592667853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OJJQ.LCFCW.WalletFeaturesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OJJQ.LCFCW.WalletFeaturesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $XSyMib ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2733261,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $YRlDdl ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2733261,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592667853)
            
            static $h = 2733261;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592667853),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2733261,
      "h": 8592667853,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592667853)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297700557),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2733261,
      "h": 4297700557,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297700557)
  ],
  "h": 2733261
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2733261)
        
        

        //--TRIMMABLE-BOUNDARY-START(1750221)
        $asm.$cls(`$OJJQ.LCFCW.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296717517)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296717517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptorBuilder.Register();
                $.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296717517)
            
            static $h = 1750221;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296717517),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1750221,
      "h": 4296717517,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296717517)
  ],
  "h": 1750221
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1750221)
        
        

        //--TRIMMABLE-BOUNDARY-START(308429)
        $asm.$cls(`$OJJQ.LCFCW.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295275725)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295275725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OJJQ.LCFCW.UserWalletDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OJJQ.LCFCW.UserWalletDataModelCustomAttributesProvider, $.$OJJQ.LCFCW.UserWalletDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OJJQ.LCFCW.UserWalletTransactionModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelCustomAttributesProvider, $.$OJJQ.LCFCW.UserWalletTransactionModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OJJQ.LCFCW.WalletDestination.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OJJQ.LCFCW.WalletDestinationCustomAttributesProvider, $.$OJJQ.LCFCW.WalletDestinationCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OJJQ.LCFCW.WalletFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OJJQ.LCFCW.WalletFeaturesCustomAttributesProvider, $.$OJJQ.LCFCW.WalletFeaturesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OJJQ.LCFCW.WalletSegment.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OJJQ.LCFCW.WalletSegmentCustomAttributesProvider, $.$OJJQ.LCFCW.WalletSegmentCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$OJJQ.LCFCW.WalletTransactionType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$OJJQ.LCFCW.WalletTransactionTypeCustomAttributesProvider, $.$OJJQ.LCFCW.WalletTransactionTypeCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295275725)
            
            static $h = 308429;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295275725),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 308429,
      "h": 4295275725,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295275725)
  ],
  "h": 308429
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(308429)
        
        

        //--TRIMMABLE-BOUNDARY-START(3388621)
        $asm.$cls(`$OJJQ.LCFCW.WalletTransactionTypeCustomAttributesProvider`, ($self) => class WalletTransactionTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298355917)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298355917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298355917)
            
            static $h = 3388621;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298355917),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3388621,
      "h": 4298355917,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298355917)
  ],
  "h": 3388621
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletTransactionTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletTransactionTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3388621)
        
        

        //--TRIMMABLE-BOUNDARY-START(111821)
        $asm.$cls(`$OJJQ.LCFCW.CoinTokenExtension`, ($self) => class CoinTokenExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295079117)
            static /*double */ GetAmount(/*this IWalletToken*/ token, /*IWalletIssuer*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295079117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token.LCFCW$IWalletToken$Amount >= 0)
                {
                    return token.LCFCW$IWalletToken$Amount;
                }
                /*var*/ let descriptor = $.$sl.SL.Enumerable.SingleOrDefault$1($.$OJJQ.LCFCW.WalletTokenDescriptor, issuer.LCFCW$IWalletIssuer$CoinDescriptors, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.WalletTokenDescriptor, $.$$.S.Boolean))().$ctor(this,  (/**/ desc) =>
                {
                    return desc.Name === token.LCFCW$IWalletToken$CoinIdentifier.CoinName;
                }, $NygEva ??= {"r":262145,"p":[{"n":"desc","p":3257549}],"n":"","d":111821,"h":0,"f":17825794}));
                return descriptor.Amount;
            }
            //--TRIMMABLE-BOUNDARY-END(4295079117)
            
            static $h = 111821;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295079117),
    {
      "r": 1179649,
      "p": [
        {
          "n": "token",
          "p": 1357005
        },
        {
          "n": "issuer",
          "p": 636109
        }
      ],
      "n": "GetAmount",
      "d": 111821,
      "h": 4295079117,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295079117)
  ],
  "h": 111821
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.CoinTokenExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}CoinTokenExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(111821)
        
        

        //--TRIMMABLE-BOUNDARY-START(2274509)
        $asm.$cls(`$OJJQ.LCFCW.UserWalletTransactionModelCustomAttributesProvider`, ($self) => class UserWalletTransactionModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297241805)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297241805)
            
            //--TRIMMABLE-BOUNDARY-START(8592209101)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592209101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OJJQ.LCFCW.UserWalletTransactionModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Sender", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Receiver", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Coin", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OJJQ.LCFCW.UserWalletTransactionModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $WfVkGb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2274509,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $tWXtNb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2274509,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$Iaui.LCFCM.DataModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592209101)
            
            static $h = 2274509;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592209101),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2274509,
      "h": 8592209101,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592209101)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297241805),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2274509,
      "h": 4297241805,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297241805)
  ],
  "h": 2274509
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}UserWalletTransactionModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2274509)
        
        

        //--TRIMMABLE-BOUNDARY-START(1946829)
        $asm.$cls(`$OJJQ.LCFCW.UserWalletDataModelCustomAttributesProvider`, ($self) => class UserWalletDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296914125)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296914125)
            
            //--TRIMMABLE-BOUNDARY-START(8591881421)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591881421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OJJQ.LCFCW.UserWalletDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("CoinIdentifier", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OJJQ.LCFCW.UserWalletDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ATSdrh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1946829,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $OeASLe ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1946829,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$Iaui.LCFCM.DataModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591881421)
            
            static $h = 1946829;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591881421),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1946829,
      "h": 8591881421,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591881421)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296914125),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1946829,
      "h": 4296914125,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296914125)
  ],
  "h": 1946829
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}UserWalletDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1946829)
        
        

        //--TRIMMABLE-BOUNDARY-START(1619149)
        $asm.$cls(`$OJJQ.LCFCW.MockingFactoryExtension`, ($self) => class MockingFactoryExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296586445)
            static /*void */ AddGeneratedMockedServices(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296586445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$zHIt.LCFCM.MockFactory.Register($.$OJJQ.LCFCW.IWalletRemoteService, $.$OJJQ.LCFCW.IWalletRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletRemoteService_Mocking().$ctor$3(impl);
                }, $SLEJDk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$OJJQ.LCFCW.IWalletRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletRemoteService_Mocking().$ctor$3(impl);
                }, $GZcauk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$OJJQ.LCFCW.IWalletRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletRemoteService_Mocking().$ctor$3(impl);
                }, $IJJxIb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$OJJQ.LCFCW.IWalletRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletRemoteService_Mocking().$ctor$3(impl);
                }, $mrxOab ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$OJJQ.LCFCW.IWalletRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletRemoteService_Mocking().$ctor$3(impl);
                }, $uLLCAi ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$OJJQ.LCFCW.IWalletRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletRemoteService_Mocking().$ctor$3(impl);
                }, $KkRZgb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$OJJQ.LCFCW.IWalletRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletRemoteService_Mocking().$ctor$3(impl);
                }, $SeOqCh ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$OJJQ.LCFCW.IWalletRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletRemoteService_Mocking().$ctor$3(impl);
                }, $vFgZNd ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$OJJQ.LCFCW.IWalletTransactionRemoteService, $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking().$ctor$3(impl);
                }, $cUSMKa ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/**/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking().$ctor$3(impl);
                }, $wUKfle ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.ICreateDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking().$ctor$3(impl);
                }, $aFQIab ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking().$ctor$3(impl);
                }, $tppcOc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadManyDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking().$ctor$3(impl);
                }, $qqklpf ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IReadSingleDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking().$ctor$3(impl);
                }, $ZKzRCc ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IUpdateDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking().$ctor$3(impl);
                }, $FMOovb ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
                $.$zHIt.LCFCM.MockFactory.Register($.$fPer.LCFCD.IDeleteDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking, new $.$zHIt.LCFCM.MockServiceFactory().$ctor(this,  (/*impl*/ impl) =>
                {
                    return new $.$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking().$ctor$3(impl);
                }, $txYRhk ??= {"r":585542,"p":[{"n":"impl","p":192326}],"n":"","d":1619149,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4296586445)
            
            static $h = 1619149;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296586445),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedMockedServices",
      "d": 1619149,
      "h": 4296586445,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296586445)
  ],
  "h": 1619149
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.MockingFactoryExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}MockingFactoryExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1619149)
        
        

        //--TRIMMABLE-BOUNDARY-START(177357)
        $asm.$cls(`$OJJQ.LCFCW.CommunityCoinsRemoteServiceExtension`, ($self) => class CommunityCoinsRemoteServiceExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295144653)
            static /*ValueTask<bool> *//*async*/  IssueCoinIfNoneExists(/*this IServerRemoteService*/ server, /*string*/ walletName, /*double*/ amount, /*string?*/ transactionDescription)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295144653);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let coinIssued = ($t1 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$2($.$OJJQ.LCFCW.IWalletRemoteService, $.$$.S.Boolean, server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.Boolean)))().$ctor(this,  (/*server*/ server) =>
                    {
                        return server.LCFCW$IWalletRemoteService$IssueCoinIfNoneExists(walletName, amount, transactionDescription);
                    }, $PPBbqk ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.Boolean)).$h,"p":[{"n":"server","p":1029325}],"n":"","d":177357,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, coinIssued);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4295144653)
            
            static $h = 177357;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295144653),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "server",
          "p": 1309651
        },
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        }
      ],
      "n": "IssueCoinIfNoneExists",
      "d": 177357,
      "h": 4295144653,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(4295144653)
  ],
  "h": 177357
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.CommunityCoinsRemoteServiceExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}CommunityCoinsRemoteServiceExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(177357)
        
        

        //--TRIMMABLE-BOUNDARY-START(373965)
        $asm.$cls(`$OJJQ.LCFCW.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295341261)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295341261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295341261)
            
            static $h = 373965;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295341261),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 373965,
      "h": 4295341261,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295341261)
  ],
  "h": 373965
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(373965)
        
        

        //--TRIMMABLE-BOUNDARY-START(3060941)
        $asm.$cls(`$OJJQ.LCFCW.WalletSegmentCustomAttributesProvider`, ($self) => class WalletSegmentCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298028237)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298028237)
            
            //--TRIMMABLE-BOUNDARY-START(8592995533)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592995533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$OJJQ.LCFCW.WalletSegmentCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$OJJQ.LCFCW.WalletSegmentCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $MTQPNk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3060941,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $IgIUqk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3060941,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592995533)
            
            static $h = 3060941;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592995533),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3060941,
      "h": 8592995533,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592995533)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298028237),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3060941,
      "h": 4298028237,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298028237)
  ],
  "h": 3060941
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletSegmentCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletSegmentCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3060941)
        
        

        //--TRIMMABLE-BOUNDARY-START(2077901)
        $asm.$cls(`$OJJQ.LCFCW.UserWalletDataModelTypeDescriptorBuilder`, ($self) => class UserWalletDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592012493)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592012493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor()
                        const $t1 = $.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $xvtpSf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2077901,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OJJQ.LCFCW.UserWalletDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592012493)
            
            //--TRIMMABLE-BOUNDARY-START(4297045197)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297045197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297045197)
            
            //--TRIMMABLE-BOUNDARY-START(4297045197)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297045197)
            
            static $h = 2077901;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592012493),
    {
      "r": 65537,
      "n": "Register",
      "d": 2077901,
      "h": 8592012493,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592012493)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297045197),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2077901,
      "h": 4297045197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297045197)
  ],
  "h": 2077901
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}UserWalletDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2077901)
        
        

        //--TRIMMABLE-BOUNDARY-START(2405581)
        $asm.$cls(`$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptorBuilder`, ($self) => class UserWalletTransactionModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592340173)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592340173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor()
                        const $t1 = $.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $DcpCGb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2405581,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$OJJQ.LCFCW.UserWalletTransactionModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592340173)
            
            //--TRIMMABLE-BOUNDARY-START(4297372877)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297372877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297372877)
            
            //--TRIMMABLE-BOUNDARY-START(4297372877)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297372877)
            
            static $h = 2405581;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592340173),
    {
      "r": 65537,
      "n": "Register",
      "d": 2405581,
      "h": 8592340173,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592340173)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297372877),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2405581,
      "h": 4297372877,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297372877)
  ],
  "h": 2405581
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}UserWalletTransactionModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2405581)
        
        

        //--TRIMMABLE-BOUNDARY-START(1684685)
        $asm.$cls(`$OJJQ.LCFCW.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591619277)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591619277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$OJJQ.LCFCW.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$OJJQ.LCFCW.IWalletIssuer, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$OJJQ.LCWCS.DefaultWalletIssuer, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$OJJQ.LCFCW.IWalletIssuer))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$OJJQ.LCWCS.DefaultWalletIssuer, x);
                }, $tgCuYa ??= {"r":636109,"p":[{"n":"x","p":327718}],"n":"","d":1684685,"h":0,"f":17825794}));
                $.$OJJQ.LCFCW.MockingFactoryExtension.AddGeneratedMockedServices(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8591619277)
            
            //--TRIMMABLE-BOUNDARY-START(12886586573)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886586573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_DefaultWalletIssuer(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$OJJQ.LCWCS.DefaultWalletIssuer().$ctor$1();
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$OJJQ.LCWCS.DefaultWalletIssuer.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$OJJQ.LCFCW.ServiceRegistrar, Get_DefaultWalletIssuer, $pnsXZh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_DefaultWalletIssuer","d":1684685,"h":0,"f":16777250})));
                /*static object*/  function Get_IWalletIssuer(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$OJJQ.LCWCS.DefaultWalletIssuer, x);
                    }), $Punvmk ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1684685,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$OJJQ.LCFCW.IWalletIssuer.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$OJJQ.LCFCW.ServiceRegistrar, Get_IWalletIssuer, $LpOUIa ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IWalletIssuer","d":1684685,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(12886586573)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$OJJQ.LCFCW.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4296651981)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296651981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296651981)
            
            //--TRIMMABLE-BOUNDARY-START(4296651981)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296651981)
            
            static $h = 1684685;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591619277),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 1684685,
      "h": 8591619277,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591619277),
//--TRIMMABLE-BOUNDARY-START(12886586573),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 1684685,
      "h": 12886586573,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886586573)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296651981),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1684685,
      "h": 4296651981,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296651981)
  ],
  "h": 1684685
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1684685)
        
        

        //--TRIMMABLE-BOUNDARY-START(1815757)
        $asm.$cls(`$OJJQ.LCFCW.UserWallerHolder`, ($self) => class UserWallerHolder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296783053)
            /*UserModel*/ _user = null;
            //--TRIMMABLE-BOUNDARY-END(4296783053)
            
            //--TRIMMABLE-BOUNDARY-START(8591750349)
            /*string*/ _walletName = null;
            //--TRIMMABLE-BOUNDARY-END(8591750349)
            
            //--TRIMMABLE-BOUNDARY-START(17181684941)
            $ctor$1(/*UserModel*/ user, /*string*/ walletName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181684941);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._user = user;
                    this._walletName = walletName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181684941)
            
            //--TRIMMABLE-BOUNDARY-START(124555867341)
            /*WalletAddress */ get NetworkAddress()
            {
                return $.$OJJQ.LCFCW.WalletAddress.op_Implicit$1(this._user.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(124555867341)
            
            //--TRIMMABLE-BOUNDARY-START(111670965453)
            /*DataId */ get Identifier()
            {
                return this._user.Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(111670965453)
            
            //--TRIMMABLE-BOUNDARY-START(128850834637)
            /*string? */ get PhoneNumber()
            {
                return this._user.PhoneNumber;
            }
            //--TRIMMABLE-BOUNDARY-END(128850834637)
            
            //--TRIMMABLE-BOUNDARY-START(25771619533)
            /*string? */ get Email()
            {
                return this._user.Email;
            }
            //--TRIMMABLE-BOUNDARY-END(25771619533)
            
            //--TRIMMABLE-BOUNDARY-START(115965932749)
            /*GeoLocation?*/ Location = null;
            //--TRIMMABLE-BOUNDARY-END(115965932749)
            
            //--TRIMMABLE-BOUNDARY-START(133145801933)
            /*string? */ get Title()
            {
                return this._user.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(133145801933)
            
            //--TRIMMABLE-BOUNDARY-START(107375998157)
            /*IconDescriptor */ get Icon()
            {
                return $.$Iaui.LCFCM.ResourceModel.op_Implicit(this._user.Icon);
            }
            //--TRIMMABLE-BOUNDARY-END(107375998157)
            
            //--TRIMMABLE-BOUNDARY-START(21476652237)
            /*string? */ get Description()
            {
                return this._user.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(21476652237)
            
            //--TRIMMABLE-BOUNDARY-START(120260900045)
            /*string? */ get Name()
            {
                return this._user.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(120260900045)
            
            //--TRIMMABLE-BOUNDARY-START(8590505165)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletHolder.NetworkAddress.get
            get LCFCW$IWalletHolder$NetworkAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885472461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NetworkAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(8590505165)
            
            //--TRIMMABLE-BOUNDARY-START(21479917910)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Identifier.get
            get LCFCC$2$IContact$Identifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51544688982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Identifier;
            }
            //--TRIMMABLE-BOUNDARY-END(21479917910)
            
            //--TRIMMABLE-BOUNDARY-START(47249721686)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.PhoneNumber.get
            get LCFCC$2$IContact$PhoneNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64429590870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhoneNumber;
            }
            //--TRIMMABLE-BOUNDARY-END(47249721686)
            
            //--TRIMMABLE-BOUNDARY-START(12889983318)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Email.get
            get LCFCC$2$IContact$Email()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300048726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Email;
            }
            //--TRIMMABLE-BOUNDARY-END(12889983318)
            
            //--TRIMMABLE-BOUNDARY-START(38659787094)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Contacts.IContact.Location.get
            get LCFCC$2$IContact$Location()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60134623574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Location;
            }
            //--TRIMMABLE-BOUNDARY-END(38659787094)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            static $h = 1815757;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124555867341),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901161677,
        "f": 50331649
      },
      "n": "NetworkAddress",
      "d": 1815757,
      "h": 124555867341,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124555867341),
//--TRIMMABLE-BOUNDARY-START(111670965453),
    {
      "p": 10455382,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131357901,
        "f": 50331649
      },
      "n": "Identifier",
      "d": 1815757,
      "h": 111670965453,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111670965453),
//--TRIMMABLE-BOUNDARY-START(128850834637),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491096269,
        "f": 50331649
      },
      "n": "PhoneNumber",
      "d": 1815757,
      "h": 128850834637,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850834637),
//--TRIMMABLE-BOUNDARY-START(25771619533),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951488717,
        "f": 50331649
      },
      "n": "Email",
      "d": 1815757,
      "h": 25771619533,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771619533),
//--TRIMMABLE-BOUNDARY-START(115965932749),
    {
      "p": 13928790,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721292493,
        "f": 50331649
      },
      "n": "Location",
      "d": 1815757,
      "h": 115965932749,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965932749),
//--TRIMMABLE-BOUNDARY-START(133145801933),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081030861,
        "f": 50331649
      },
      "n": "Title",
      "d": 1815757,
      "h": 133145801933,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145801933),
//--TRIMMABLE-BOUNDARY-START(107375998157),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541423309,
        "f": 50331649
      },
      "n": "Icon",
      "d": 1815757,
      "h": 107375998157,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375998157),
//--TRIMMABLE-BOUNDARY-START(21476652237),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361554125,
        "f": 50331649
      },
      "n": "Description",
      "d": 1815757,
      "h": 21476652237,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476652237),
//--TRIMMABLE-BOUNDARY-START(120260900045),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311227085,
        "f": 50331649
      },
      "n": "Name",
      "d": 1815757,
      "h": 120260900045,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260900045)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296783053),
    {
      "t": 23799126,
      "n": "_user",
      "d": 1815757,
      "h": 4296783053,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296783053),
//--TRIMMABLE-BOUNDARY-START(8591750349),
    {
      "t": 1310721,
      "n": "_walletName",
      "d": 1815757,
      "h": 8591750349,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591750349)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181684941),
    {
      "p": [
        {
          "n": "user",
          "p": 23799126
        },
        {
          "n": "walletName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1815757,
      "h": 17181684941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181684941)
  ],
  "h": 1815757
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletHolder, $.$fPer.LCFCC$2.IContact, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.UserWallerHolder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}UserWallerHolder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1815757)
        
        

        //--TRIMMABLE-BOUNDARY-START(2798797)
        $asm.$str(`$OJJQ.LCFCW.WalletHash`, ($self) => class WalletHash extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(30067569869)
            /*string?*/ Hash = null;
            //--TRIMMABLE-BOUNDARY-END(30067569869)
            
            //--TRIMMABLE-BOUNDARY-START(51542406349)
            static /*string? */ op_Implicit(/*WalletHash*/ add)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51542406349);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return add.Hash;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51542406349)
            
            //--TRIMMABLE-BOUNDARY-START(55837373645)
            static /*WalletHash */ op_Implicit$1(/*string?*/ add)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55837373645);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$OJJQ.LCFCW.WalletHash()
                        const $t1 = $.$OJJQ.LCFCW.WalletHash;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Hash = add;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55837373645)
            
            //--TRIMMABLE-BOUNDARY-START(34362537165)
            static /*bool */ op_Equality(/*WalletHash*/ left, /*WalletHash*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362537165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return left.Hash === right.Hash;
            }
            //--TRIMMABLE-BOUNDARY-END(34362537165)
            
            //--TRIMMABLE-BOUNDARY-START(38657504461)
            static /*bool */ op_Inequality(/*WalletHash*/ left, /*WalletHash*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657504461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return left.Hash !== right.Hash;
            }
            //--TRIMMABLE-BOUNDARY-END(38657504461)
            
            //--TRIMMABLE-BOUNDARY-START(12887700685)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887700685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let hash;
                if ($.$is(obj, $.$OJJQ.LCFCW.WalletHash, { set $v($v){ hash = $v; } }))
                {
                    return hash.Hash === this.Hash;
                }
                return super.Equals$1(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(12887700685)
            
            //--TRIMMABLE-BOUNDARY-START(25772602573)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772602573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                return ((__ca1__ = this.Hash) !== null ? $.$$.S.String.GetHashCode.call(__ca1__) : super.GetHashCode());
            }
            //--TRIMMABLE-BOUNDARY-END(25772602573)
            
            //--TRIMMABLE-BOUNDARY-START(60132340941)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132340941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Hash ?? super.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(60132340941)
            
            //--TRIMMABLE-BOUNDARY-START(8592733389)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592733389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592733389)
            
            //--TRIMMABLE-BOUNDARY-START(8592733389)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592733389)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Hash = this.Hash;
                return copy;
            }
            static $h = 2798797;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067569869),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477635277,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247439053,
        "f": 83886081
      },
      "n": "Hash",
      "d": 2798797,
      "h": 30067569869,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "h",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30067569869)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887700685),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2798797,
      "h": 12887700685,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12887700685),
//--TRIMMABLE-BOUNDARY-START(25772602573),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2798797,
      "h": 25772602573,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772602573),
//--TRIMMABLE-BOUNDARY-START(60132340941),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2798797,
      "h": 60132340941,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60132340941)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592733389),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2798797,
      "h": 8592733389,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592733389)
  ],
  "h": 2798797
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletHash`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletHash`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2798797)
        
        

        //--TRIMMABLE-BOUNDARY-START(2864333)
        $asm.$str(`$OJJQ.LCFCW.WalletIdentifier`, ($self) => class WalletIdentifier extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(47247504589)
            /*string*/ IssuerName = null;
            //--TRIMMABLE-BOUNDARY-END(47247504589)
            
            //--TRIMMABLE-BOUNDARY-START(17182733517)
            /*string*/ CoinName = null;
            //--TRIMMABLE-BOUNDARY-END(17182733517)
            
            //--TRIMMABLE-BOUNDARY-START(73017308365)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017308365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.IssuerName)}/${$.$strNN(this.CoinName)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(73017308365)
            
            //--TRIMMABLE-BOUNDARY-START(42952537293)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952537293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.HashCode.Combine$6($.$$.S.String, $.$$.S.String, this.IssuerName, this.CoinName);
            }
            //--TRIMMABLE-BOUNDARY-END(42952537293)
            
            //--TRIMMABLE-BOUNDARY-START(21477700813)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477700813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let s;
                if ($.$is(obj, $.$$.S.String, { set $v($v){ s = $v; } }))
                {
                    return this.ToString() === s;
                }
                let wi;
                if ($.$is(obj, $.$OJJQ.LCFCW.WalletIdentifier, { set $v($v){ wi = $v; } }))
                {
                    return wi.IssuerName === this.IssuerName && wi.CoinName === this.CoinName;
                }
                return super.Equals$1(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(21477700813)
            
            //--TRIMMABLE-BOUNDARY-START(51542471885)
            static /*WalletIdentifier */ Parse(/*string?*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542471885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (id === null)
                {
                    return new $.$OJJQ.LCFCW.WalletIdentifier();
                }
                /*var*/ let ids = $.$$.S.String.Split$1.call(id, /*/*/ 47, 0);
                if (ids.length < 2)
                {
                    return (() =>
                    {
                        //new $.$OJJQ.LCFCW.WalletIdentifier()
                        const $t1 = $.$OJJQ.LCFCW.WalletIdentifier;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.IssuerName = $.$$.System.Array.$ReadT1.call(ids, 0);
                        $i1.CoinName = $.$$.System.Array.$ReadT1.call(ids, 0);
                        return $i1;
                    })();
                }
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletIdentifier()
                    const $t2 = $.$OJJQ.LCFCW.WalletIdentifier;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.IssuerName = $.$$.System.Array.$ReadT1.call(ids, 0);
                    $i2.CoinName = $.$$.System.Array.$ReadT1.call(ids, 1);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(51542471885)
            
            //--TRIMMABLE-BOUNDARY-START(12887766221)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887766221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887766221)
            
            //--TRIMMABLE-BOUNDARY-START(12887766221)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887766221)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.IssuerName = this.IssuerName;
                copy.CoinName = this.CoinName;
                return copy;
            }
            static $h = 2864333;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247504589),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657569997,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722341069,
        "f": 83886081
      },
      "n": "IssuerName",
      "d": 2864333,
      "h": 47247504589,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247504589),
//--TRIMMABLE-BOUNDARY-START(17182733517),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067635405,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132406477,
        "f": 83886081
      },
      "n": "CoinName",
      "d": 2864333,
      "h": 17182733517,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182733517)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73017308365),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2864333,
      "h": 73017308365,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73017308365),
//--TRIMMABLE-BOUNDARY-START(42952537293),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2864333,
      "h": 42952537293,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952537293),
//--TRIMMABLE-BOUNDARY-START(21477700813),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2864333,
      "h": 21477700813,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21477700813),
//--TRIMMABLE-BOUNDARY-START(51542471885),
    {
      "r": 2864333,
      "p": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": "Parse",
      "d": 2864333,
      "h": 51542471885,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51542471885)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887766221),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2864333,
      "h": 12887766221,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887766221)
  ],
  "h": 2864333
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletIdentifier`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletIdentifier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2864333)
        
        

        //--TRIMMABLE-BOUNDARY-START(3192013)
        $asm.$str(`$OJJQ.LCFCW.WalletToken`, ($self) => class WalletToken extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17183061197)
            /*double*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(17183061197)
            
            //--TRIMMABLE-BOUNDARY-START(21478028493)
            /*WalletTokenDescriptor*/ Descriptor;
            //--TRIMMABLE-BOUNDARY-END(21478028493)
            
            //--TRIMMABLE-BOUNDARY-START(68722668749)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722668749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN(this.Amount)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(68722668749)
            
            //--TRIMMABLE-BOUNDARY-START(64427701453)
            static /*WalletToken */ op_Implicit$1(/*double*/ amount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427701453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletToken()
                    const $t1 = $.$OJJQ.LCFCW.WalletToken;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Amount = amount;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(64427701453)
            
            //--TRIMMABLE-BOUNDARY-START(60132734157)
            static /*double */ op_Implicit(/*WalletToken*/ coins)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132734157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return coins.Amount;
            }
            //--TRIMMABLE-BOUNDARY-END(60132734157)
            
            //--TRIMMABLE-BOUNDARY-START(12888093901)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888093901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888093901)
            
            //--TRIMMABLE-BOUNDARY-START(12888093901)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12888093901)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Amount = this.Amount;
                copy.Descriptor = this.Descriptor.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21478028493)
                this.Descriptor = $.$default($.$OJJQ.LCFCW.WalletTokenDescriptor);
                //--TRIMMABLE-BOUNDARY-END(21478028493)
                
            }
            static $h = 3192013;
            static $z = 52;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183061197),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067963085,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247832269,
        "f": 83886081
      },
      "n": "Amount",
      "d": 3192013,
      "h": 17183061197,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183061197),
//--TRIMMABLE-BOUNDARY-START(21478028493),
    {
      "p": 3257549,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657897677,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837766861,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 3192013,
      "h": 21478028493,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21478028493)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68722668749),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 3192013,
      "h": 68722668749,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68722668749)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888093901),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3192013,
      "h": 12888093901,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888093901)
  ],
  "h": 3192013
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3192013)
        
        

        //--TRIMMABLE-BOUNDARY-START(2471117)
        $asm.$str(`$OJJQ.LCFCW.WalletAddress`, ($self) => class WalletAddress extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21477307597)
            /*string?*/ DisplayName = null;
            //--TRIMMABLE-BOUNDARY-END(21477307597)
            
            //--TRIMMABLE-BOUNDARY-START(17182340301)
            /*string?*/ Address = null;
            //--TRIMMABLE-BOUNDARY-END(17182340301)
            
            //--TRIMMABLE-BOUNDARY-START(85901817037)
            /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901817037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisplayName ?? this.Address ?? super.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(85901817037)
            
            //--TRIMMABLE-BOUNDARY-START(77311882445)
            static /*string? */ op_Implicit(/*WalletAddress*/ add)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311882445);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$strNN(add.Address) + $.$strNN((!$.$$.S.String.IsNullOrEmpty(add.DisplayName) ? "%" + $.$strNN(add.DisplayName) : ""));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311882445)
            
            //--TRIMMABLE-BOUNDARY-START(81606849741)
            static /*WalletAddress */ op_Implicit$1(/*string?*/ add)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606849741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (add === null)
                {
                    return new $.$OJJQ.LCFCW.WalletAddress();
                }
                /*var*/ let split = $.$$.S.String.Split$1.call(add, /*%*/ 37, 0);
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletAddress()
                    const $t1 = $.$OJJQ.LCFCW.WalletAddress;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Address = $.$$.System.Array.$ReadT1.call(split, 0);
                    $i1.DisplayName = split.length > 1 ? $.$$.System.Array.$ReadT1.call(split, 1) : null;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(81606849741)
            
            //--TRIMMABLE-BOUNDARY-START(51542078669)
            static /*bool */ op_Equality(/*WalletAddress*/ left, /*WalletAddress*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542078669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return left.Address === right.Address;
            }
            //--TRIMMABLE-BOUNDARY-END(51542078669)
            
            //--TRIMMABLE-BOUNDARY-START(55837045965)
            static /*bool */ op_Inequality(/*WalletAddress*/ left, /*WalletAddress*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837045965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return left.Address !== right.Address;
            }
            //--TRIMMABLE-BOUNDARY-END(55837045965)
            
            //--TRIMMABLE-BOUNDARY-START(47247111373)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247111373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                return ((__ca1__ = this.Address) !== null ? $.$$.S.String.GetHashCode.call(__ca1__) : super.GetHashCode());
            }
            //--TRIMMABLE-BOUNDARY-END(47247111373)
            
            //--TRIMMABLE-BOUNDARY-START(25772274893)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772274893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let add;
                if ($.$is(obj, $.$OJJQ.LCFCW.WalletAddress, { set $v($v){ add = $v; } }))
                {
                    return add.Address === this.Address;
                }
                return super.Equals$1(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(25772274893)
            
            //--TRIMMABLE-BOUNDARY-START(12887373005)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887373005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887373005)
            
            //--TRIMMABLE-BOUNDARY-START(12887373005)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887373005)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.DisplayName = this.DisplayName;
                copy.Address = this.Address;
                return copy;
            }
            static $h = 2471117;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477307597),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952144077,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016915149,
        "f": 83886081
      },
      "n": "DisplayName",
      "d": 2471117,
      "h": 21477307597,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "n",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21477307597),
//--TRIMMABLE-BOUNDARY-START(17182340301),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362209485,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426980557,
        "f": 83886081
      },
      "n": "Address",
      "d": 2471117,
      "h": 17182340301,
      "f": 2097153,
      "a": [
        {
          "t": 14811220,
          "c": 8604745812,
          "a": [
            {
              "v": "h",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17182340301)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901817037),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2471117,
      "h": 85901817037,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901817037),
//--TRIMMABLE-BOUNDARY-START(47247111373),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2471117,
      "h": 47247111373,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47247111373),
//--TRIMMABLE-BOUNDARY-START(25772274893),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2471117,
      "h": 25772274893,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772274893)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887373005),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2471117,
      "h": 12887373005,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887373005)
  ],
  "h": 2471117
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletAddress`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletAddress`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2471117)
        
        

        //--TRIMMABLE-BOUNDARY-START(3257549)
        $asm.$str(`$OJJQ.LCFCW.WalletTokenDescriptor`, ($self) => class WalletTokenDescriptor extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(81607636173)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(81607636173)
            
            //--TRIMMABLE-BOUNDARY-START(30068028621)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(30068028621)
            
            //--TRIMMABLE-BOUNDARY-START(77312668877)
            /*IconDescriptor*/ Icon;
            //--TRIMMABLE-BOUNDARY-END(77312668877)
            
            //--TRIMMABLE-BOUNDARY-START(25773061325)
            /*double*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(25773061325)
            
            //--TRIMMABLE-BOUNDARY-START(120262341837)
            /*string? */ get Title()
            {
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(120262341837)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(21478094029)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478094029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21478094029)
            
            //--TRIMMABLE-BOUNDARY-START(21478094029)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21478094029)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.Description = this.Description;
                copy.Icon = this.Icon.$clone();
                copy.Amount = this.Amount;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77312668877)
                this.Icon = $.$default($.$fPer.LCFC.IconDescriptor);
                //--TRIMMABLE-BOUNDARY-END(77312668877)
                
            }
            static $h = 3257549;
            static $z = 44;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81607636173),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427766989,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115967374541,
        "f": 83886081
      },
      "n": "Name",
      "d": 3257549,
      "h": 81607636173,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81607636173),
//--TRIMMABLE-BOUNDARY-START(30068028621),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247897805,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98787505357,
        "f": 83886081
      },
      "n": "Description",
      "d": 3257549,
      "h": 30068028621,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30068028621),
//--TRIMMABLE-BOUNDARY-START(77312668877),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837832397,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107377439949,
        "f": 83886081
      },
      "n": "Icon",
      "d": 3257549,
      "h": 77312668877,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312668877),
//--TRIMMABLE-BOUNDARY-START(25773061325),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657963213,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90197570765,
        "f": 83886081
      },
      "n": "Amount",
      "d": 3257549,
      "h": 25773061325,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25773061325),
//--TRIMMABLE-BOUNDARY-START(120262341837),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017701581,
        "f": 50331649
      },
      "n": "Title",
      "d": 3257549,
      "h": 120262341837,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120262341837)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21478094029),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3257549,
      "h": 21478094029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478094029)
  ],
  "h": 3257549
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletTokenDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletTokenDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3257549)
        
        

        //--TRIMMABLE-BOUNDARY-START(2536653)
        $asm.$str(`$OJJQ.LCFCW.WalletDestination`, ($self) => class WalletDestination extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Amount = 0;
            static Frozen = 1;
            static Cashback = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2536653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Amount": 0n,
                    "Frozen": 1n,
                    "Cashback": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297503949)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297503949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297503949)
            
            //--TRIMMABLE-BOUNDARY-START(4297503949)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297503949)
            
            static $h = 2536653;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592471245),
    {
      "t": 2536653,
      "n": "Amount",
      "d": 2536653,
      "h": 8592471245,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592471245),
//--TRIMMABLE-BOUNDARY-START(17182405837),
    {
      "t": 2536653,
      "n": "Frozen",
      "d": 2536653,
      "h": 17182405837,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182405837),
//--TRIMMABLE-BOUNDARY-START(12887438541),
    {
      "t": 2536653,
      "n": "Cashback",
      "d": 2536653,
      "h": 12887438541,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887438541)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297503949),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2536653,
      "h": 4297503949,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297503949)
  ],
  "h": 2536653
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletDestination`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletDestination`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2536653)
        
        

        //--TRIMMABLE-BOUNDARY-START(2995405)
        $asm.$str(`$OJJQ.LCFCW.WalletSegment`, ($self) => class WalletSegment extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Primary = 1;
            static Cashback = 2;
            static Frozen = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2995405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Primary": 1n,
                    "Cashback": 2n,
                    "Frozen": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297962701)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297962701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297962701)
            
            //--TRIMMABLE-BOUNDARY-START(4297962701)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297962701)
            
            static $h = 2995405;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182864589),
    {
      "t": 2995405,
      "n": "None",
      "d": 2995405,
      "h": 17182864589,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182864589),
//--TRIMMABLE-BOUNDARY-START(21477831885),
    {
      "t": 2995405,
      "n": "Primary",
      "d": 2995405,
      "h": 21477831885,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477831885),
//--TRIMMABLE-BOUNDARY-START(8592929997),
    {
      "t": 2995405,
      "n": "Cashback",
      "d": 2995405,
      "h": 8592929997,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592929997),
//--TRIMMABLE-BOUNDARY-START(12887897293),
    {
      "t": 2995405,
      "n": "Frozen",
      "d": 2995405,
      "h": 12887897293,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887897293)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297962701),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2995405,
      "h": 4297962701,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297962701)
  ],
  "h": 2995405,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletSegment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletSegment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2995405)
        
        

        //--TRIMMABLE-BOUNDARY-START(3323085)
        $asm.$str(`$OJJQ.LCFCW.WalletTransactionType`, ($self) => class WalletTransactionType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Offline = 0;
            static Online = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3323085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Offline": 0n,
                    "Online": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298290381)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298290381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298290381)
            
            //--TRIMMABLE-BOUNDARY-START(4298290381)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298290381)
            
            static $h = 3323085;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593257677),
    {
      "t": 3323085,
      "n": "Offline",
      "d": 3323085,
      "h": 8593257677,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593257677),
//--TRIMMABLE-BOUNDARY-START(12888224973),
    {
      "t": 3323085,
      "n": "Online",
      "d": 3323085,
      "h": 12888224973,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888224973)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298290381),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3323085,
      "h": 4298290381,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298290381)
  ],
  "h": 3323085
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletTransactionType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletTransactionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3323085)
        
        

        //--TRIMMABLE-BOUNDARY-START(2667725)
        $asm.$str(`$OJJQ.LCFCW.WalletFeatures`, ($self) => class WalletFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Purchasable = 1;
            static Transferable = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2667725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Purchasable": 1n,
                    "Transferable": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297635021)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297635021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297635021)
            
            //--TRIMMABLE-BOUNDARY-START(4297635021)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297635021)
            
            static $h = 2667725;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592602317),
    {
      "t": 2667725,
      "n": "None",
      "d": 2667725,
      "h": 8592602317,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592602317),
//--TRIMMABLE-BOUNDARY-START(12887569613),
    {
      "t": 2667725,
      "n": "Purchasable",
      "d": 2667725,
      "h": 12887569613,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887569613),
//--TRIMMABLE-BOUNDARY-START(17182536909),
    {
      "t": 2667725,
      "n": "Transferable",
      "d": 2667725,
      "h": 17182536909,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182536909)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297635021),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2667725,
      "h": 4297635021,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297635021)
  ],
  "h": 2667725,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.WalletFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}WalletFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2667725)
        
        

        //--TRIMMABLE-BOUNDARY-START(2208973)
        $asm.$cls(`$OJJQ.LCFCW.UserWalletTransactionModel`, ($self) => class UserWalletTransactionModel extends $.$Iaui.LCFCM.DataModel
        {
            //--TRIMMABLE-BOUNDARY-START(206160639181)
            /*string*/ Reference = null;
            //--TRIMMABLE-BOUNDARY-END(206160639181)
            
            //--TRIMMABLE-BOUNDARY-START(73016653005)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(73016653005)
            
            //--TRIMMABLE-BOUNDARY-START(68721685709)
            /*DateTime*/ Date;
            //--TRIMMABLE-BOUNDARY-END(68721685709)
            
            //--TRIMMABLE-BOUNDARY-START(51541816525)
            /*double*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(51541816525)
            
            //--TRIMMABLE-BOUNDARY-START(55836783821)
            /*double*/ BalanceAfter = 0;
            //--TRIMMABLE-BOUNDARY-END(55836783821)
            
            //--TRIMMABLE-BOUNDARY-START(77311620301)
            /*double*/ FrozenBalanceAfter = 0;
            //--TRIMMABLE-BOUNDARY-END(77311620301)
            
            //--TRIMMABLE-BOUNDARY-START(60131751117)
            /*double*/ CashbackBalanceAfter = 0;
            //--TRIMMABLE-BOUNDARY-END(60131751117)
            
            //--TRIMMABLE-BOUNDARY-START(214750573773)
            /*UserModel?*/ SenderAccount = null;
            //--TRIMMABLE-BOUNDARY-END(214750573773)
            
            //--TRIMMABLE-BOUNDARY-START(201865671885)
            /*UserModel?*/ ReceiverAccount = null;
            //--TRIMMABLE-BOUNDARY-END(201865671885)
            
            //--TRIMMABLE-BOUNDARY-START(193275737293)
            /*IEnumerable<PaymentModel>?*/ Payments = null;
            //--TRIMMABLE-BOUNDARY-END(193275737293)
            
            //--TRIMMABLE-BOUNDARY-START(210455606477)
            /*WalletAddress */ get Sender()
            {
                return $.$OJJQ.LCFCW.WalletAddress.op_Implicit$1((this.SenderAccount?.Name ?? null));
            }
            //--TRIMMABLE-BOUNDARY-END(210455606477)
            
            //--TRIMMABLE-BOUNDARY-START(197570704589)
            /*WalletAddress */ get Receiver()
            {
                return $.$OJJQ.LCFCW.WalletAddress.op_Implicit$1((this.ReceiverAccount?.Name ?? null));
            }
            //--TRIMMABLE-BOUNDARY-END(197570704589)
            
            //--TRIMMABLE-BOUNDARY-START(64426718413)
            /*WalletIdentifier */ get Coin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671358669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Reference === null)
                {
                    return new $.$OJJQ.LCFCW.WalletIdentifier();
                }
                /*var*/ let split = $.$$.S.String.Split$1.call(this.Reference, /*/*/ 47, 0);
                if (split.length >= 2)
                {
                    return (() =>
                    {
                        //new $.$OJJQ.LCFCW.WalletIdentifier()
                        const $t1 = $.$OJJQ.LCFCW.WalletIdentifier;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.IssuerName = $.$$.System.Array.$ReadT1.call(split, 0);
                        $i1.CoinName = $.$$.System.Array.$ReadT1.call(split, 1);
                        return $i1;
                    })();
                }
                return new $.$OJJQ.LCFCW.WalletIdentifier();
            }
            //--TRIMMABLE-BOUNDARY-END(64426718413)
            
            //--TRIMMABLE-BOUNDARY-START(34361160909)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Coin.get
            get LCFCW$IWalletTransaction$Coin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591357133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Coin;
            }
            //--TRIMMABLE-BOUNDARY-END(34361160909)
            
            //--TRIMMABLE-BOUNDARY-START(68720899277)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Reference.get
            get LCFCW$IWalletTransaction$Reference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900768461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reference;
            }
            //--TRIMMABLE-BOUNDARY-END(68720899277)
            
            //--TRIMMABLE-BOUNDARY-START(51541030093)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Description.get
            get LCFCW$IWalletTransaction$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181291725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(51541030093)
            
            //--TRIMMABLE-BOUNDARY-START(42951095501)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Date.get
            get LCFCW$IWalletTransaction$Date()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886324429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Date;
            }
            //--TRIMMABLE-BOUNDARY-END(42951095501)
            
            //--TRIMMABLE-BOUNDARY-START(25771226317)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Amount.get
            get LCFCW$IWalletTransaction$Amount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296389837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Amount;
            }
            //--TRIMMABLE-BOUNDARY-END(25771226317)
            
            //--TRIMMABLE-BOUNDARY-START(77310833869)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Sender.get
            get LCFCW$IWalletTransaction$Sender()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195735757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Sender;
            }
            //--TRIMMABLE-BOUNDARY-END(77310833869)
            
            //--TRIMMABLE-BOUNDARY-START(60130964685)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletTransaction.Receiver.get
            get LCFCW$IWalletTransaction$Receiver()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605801165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Receiver;
            }
            //--TRIMMABLE-BOUNDARY-END(60130964685)
            
            //--TRIMMABLE-BOUNDARY-START(47246849229)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246849229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246849229)
            
            //--TRIMMABLE-BOUNDARY-START(47246849229)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(47246849229)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(206160639181)
                this.Reference = null;
                //--TRIMMABLE-BOUNDARY-END(206160639181)
                
                //--TRIMMABLE-BOUNDARY-START(68721685709)
                this.Date = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(68721685709)
                
            }
            static $h = 2208973;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.DataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(206160639181),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171800900813,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292059985101,
        "f": 83886081
      },
      "n": "Reference",
      "d": 2208973,
      "h": 206160639181,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206160639181),
//--TRIMMABLE-BOUNDARY-START(73016653005),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851227853,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257700246733,
        "f": 83886081
      },
      "n": "Description",
      "d": 2208973,
      "h": 73016653005,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016653005),
//--TRIMMABLE-BOUNDARY-START(68721685709),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261293261,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249110312141,
        "f": 83886081
      },
      "n": "Date",
      "d": 2208973,
      "h": 68721685709,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721685709),
//--TRIMMABLE-BOUNDARY-START(51541816525),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901554893,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223340508365,
        "f": 83886081
      },
      "n": "Amount",
      "d": 2208973,
      "h": 51541816525,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541816525),
//--TRIMMABLE-BOUNDARY-START(55836783821),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491489485,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231930442957,
        "f": 83886081
      },
      "n": "BalanceAfter",
      "d": 2208973,
      "h": 55836783821,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836783821),
//--TRIMMABLE-BOUNDARY-START(77311620301),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137441162445,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266290181325,
        "f": 83886081
      },
      "n": "FrozenBalanceAfter",
      "d": 2208973,
      "h": 77311620301,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311620301),
//--TRIMMABLE-BOUNDARY-START(60131751117),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081424077,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240520377549,
        "f": 83886081
      },
      "n": "CashbackBalanceAfter",
      "d": 2208973,
      "h": 60131751117,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131751117),
//--TRIMMABLE-BOUNDARY-START(214750573773),
    {
      "p": 23799126,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188980769997,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300649919693,
        "f": 83886081
      },
      "n": "SenderAccount",
      "d": 2208973,
      "h": 214750573773,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214750573773),
//--TRIMMABLE-BOUNDARY-START(201865671885),
    {
      "p": 23799126,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210966221,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283470050509,
        "f": 83886081
      },
      "n": "ReceiverAccount",
      "d": 2208973,
      "h": 201865671885,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201865671885),
//--TRIMMABLE-BOUNDARY-START(193275737293),
    {
      "p": $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146031097037,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274880115917,
        "f": 83886081
      },
      "n": "Payments",
      "d": 2208973,
      "h": 193275737293,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193275737293),
//--TRIMMABLE-BOUNDARY-START(210455606477),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180390835405,
        "f": 50331649
      },
      "n": "Sender",
      "d": 2208973,
      "h": 210455606477,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210455606477),
//--TRIMMABLE-BOUNDARY-START(197570704589),
    {
      "p": 2471117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154621031629,
        "f": 50331649
      },
      "n": "Receiver",
      "d": 2208973,
      "h": 197570704589,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197570704589),
//--TRIMMABLE-BOUNDARY-START(64426718413),
    {
      "p": 2864333,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671358669,
        "f": 50331649
      },
      "n": "Coin",
      "d": 2208973,
      "h": 64426718413,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64426718413)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47246849229),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2208973,
      "h": 47246849229,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246849229)
  ],
  "h": 2208973
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$OJJQ.LCFCW.IWalletTransaction ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}UserWalletTransactionModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2208973)
        
        

        //--TRIMMABLE-BOUNDARY-START(1881293)
        $asm.$cls(`$OJJQ.LCFCW.UserWalletDataModel`, ($self) => class UserWalletDataModel extends $.$Iaui.LCFCM.DataModel
        {
            //--TRIMMABLE-BOUNDARY-START(197570376909)
            /*string*/ WalletName = null;
            //--TRIMMABLE-BOUNDARY-END(197570376909)
            
            //--TRIMMABLE-BOUNDARY-START(133145867469)
            /*bool*/ IsSetup = false;
            //--TRIMMABLE-BOUNDARY-END(133145867469)
            
            //--TRIMMABLE-BOUNDARY-START(34361619661)
            /*double*/ Amount = 0;
            //--TRIMMABLE-BOUNDARY-END(34361619661)
            
            //--TRIMMABLE-BOUNDARY-START(47246521549)
            /*double*/ FrozenAmount = 0;
            //--TRIMMABLE-BOUNDARY-END(47246521549)
            
            //--TRIMMABLE-BOUNDARY-START(38656586957)
            /*double*/ Cashback = 0;
            //--TRIMMABLE-BOUNDARY-END(38656586957)
            
            //--TRIMMABLE-BOUNDARY-START(42951554253)
            /*WalletIdentifier */ get CoinIdentifier()
            {
                return $.$OJJQ.LCFCW.WalletIdentifier.Parse(this.WalletName);
            }
            //--TRIMMABLE-BOUNDARY-END(42951554253)
            
            //--TRIMMABLE-BOUNDARY-START(193275409613)
            /*IEnumerable<UserWalletTransactionModel>?*/ Transactions = null;
            //--TRIMMABLE-BOUNDARY-END(193275409613)
            
            //--TRIMMABLE-BOUNDARY-START(120260965581)
            /*double */ GetCredited(/*DataId*/ currentUserId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260965581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>?*/ let __ca1__;
                return ((__ca1__ = this.Transactions) !== null ? $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.UserWalletTransactionModel, __ca1__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return (t.SenderAccount?.Identifier.Equals$2($.$clone(currentUserId)) ?? null) ?? false;
                }, $ZWwIAi ??= {"r":262145,"p":[{"n":"t","p":2208973}],"n":"","d":1881293,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.Amount;
                }, $ibjrvb ??= {"r":1179649,"p":[{"n":"t","p":2208973}],"n":"","d":1881293,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(120260965581)
            
            //--TRIMMABLE-BOUNDARY-START(124555932877)
            /*double */ GetDebited(/*DataId*/ currentUserId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555932877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>?*/ let __ca2__;
                return ((__ca2__ = this.Transactions) !== null ? $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.UserWalletTransactionModel, __ca2__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return (t.ReceiverAccount?.Identifier.Equals$2($.$clone(currentUserId)) ?? null) ?? false;
                }, $Vdcdqd ??= {"r":262145,"p":[{"n":"t","p":2208973}],"n":"","d":1881293,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.Double))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.Amount;
                }, $YGKgKd ??= {"r":1179649,"p":[{"n":"t","p":2208973}],"n":"","d":1881293,"h":0,"f":17825794})) : 0);
            }
            //--TRIMMABLE-BOUNDARY-END(124555932877)
            
            //--TRIMMABLE-BOUNDARY-START(128850900173)
            /*Dictionary<string, double>? */ GetPaymentCategories(/*DataId*/ currentUserId, /*int*/ groupIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850900173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>?*/ let __ca3__;
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>*/ let __ca4__;
                return _ = ((__ca3__ = this.Transactions) !== null ? ((__ca4__ = $.$sl.SL.Enumerable.Where($.$OJJQ.LCFCW.UserWalletTransactionModel, __ca3__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return (t.SenderAccount?.Identifier.Equals$2($.$clone(currentUserId)) ?? null) ?? false;
                }, $uRRJbl ??= {"r":262145,"p":[{"n":"t","p":2208973}],"n":"","d":1881293,"h":0,"f":17825794}))) !== null ? $.$sl.SL.Enumerable.ToDictionary$5($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.UserWalletTransactionModel), $.$$.S.String, $.$$.S.Double, $.$sl.SL.Enumerable.GroupBy$7($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.String, __ca4__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.String))().$ctor(this,  (/*t*/ t) =>
                {
                    /*var*/ let tt = $.$$.S.String.Split$1.call(t.Reference, /*/*/ 47, 0);
                    if (tt.length > groupIndex)
                    {
                        return $.$$.System.Array.$ReadT1.call(tt, groupIndex);
                    }
                    return "";
                }, $tZknJh ??= {"r":1310721,"p":[{"n":"t","p":2208973}],"n":"","d":1881293,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.UserWalletTransactionModel), $.$$.S.String))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.SL$IGrouping$$$$Key;
                }, $xIZzOa ??= {"r":1310721,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.UserWalletTransactionModel).$h}],"n":"","d":1881293,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.UserWalletTransactionModel), $.$$.S.Double))().$ctor(this,  (/**/ t) =>
                {
                    return $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.UserWalletTransactionModel, t, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.Double))().$ctor(this,  (/**/ tt) =>
                    {
                        return tt.Amount;
                    }, $Rtnyig ??= {"r":1179649,"p":[{"n":"tt","p":2208973}],"n":"","d":1881293,"h":0,"f":17825794}));
                }, $BHVAhi ??= {"r":1179649,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.String, $.$OJJQ.LCFCW.UserWalletTransactionModel).$h}],"n":"","d":1881293,"h":0,"f":17825794})) : null) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(128850900173)
            
            //--TRIMMABLE-BOUNDARY-START(137440834765)
            /*Dictionary<DateTime, double>? */ get MonthlyHistories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786129101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>?*/ let __ca5__;
                return _ = ((__ca5__ = this.Transactions) !== null ? $.$sl.SL.Enumerable.ToDictionary$5($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$OJJQ.LCFCW.UserWalletTransactionModel), $.$$.S.DateTime, $.$$.S.Double, $.$sl.SL.Enumerable.GroupBy$7($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.DateTime, __ca5__, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.DateTime))().$ctor(this,  (/*t*/ t) =>
                {
                    /*var*/ let dt = t.Date;
                    return new $.$$.S.DateTime().$ctor$17(dt.Year, dt.Month, 1);
                }, $wNSleb ??= {"r":65994753,"p":[{"n":"t","p":2208973}],"n":"","d":1881293,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$OJJQ.LCFCW.UserWalletTransactionModel), $.$$.S.DateTime))().$ctor(this,  (/**/ t) =>
                {
                    return t.SL$IGrouping$$$$Key;
                }, $inDBQk ??= {"r":65994753,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$OJJQ.LCFCW.UserWalletTransactionModel).$h}],"n":"","d":1881293,"h":0,"f":17825794}), new ($.$$.S.Func$$$($.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$OJJQ.LCFCW.UserWalletTransactionModel), $.$$.S.Double))().$ctor(this,  (/**/ t) =>
                {
                    return $.$sl.SL.Enumerable.Sum$16($.$OJJQ.LCFCW.UserWalletTransactionModel, t, new ($.$$.S.Func$$$($.$OJJQ.LCFCW.UserWalletTransactionModel, $.$$.S.Double))().$ctor(this,  (/**/ tt) =>
                    {
                        return tt.Amount;
                    }, $llNUli ??= {"r":1179649,"p":[{"n":"tt","p":2208973}],"n":"","d":1881293,"h":0,"f":17825794}));
                }, $Jyekej ??= {"r":1179649,"p":[{"n":"t","p":$.$sl.SL.IGrouping$$$($.$$.S.DateTime, $.$OJJQ.LCFCW.UserWalletTransactionModel).$h}],"n":"","d":1881293,"h":0,"f":17825794})) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(137440834765)
            
            //--TRIMMABLE-BOUNDARY-START(42951029965)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletToken.CoinIdentifier.get
            get LCFCW$IWalletToken$CoinIdentifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886258893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CoinIdentifier;
            }
            //--TRIMMABLE-BOUNDARY-END(42951029965)
            
            //--TRIMMABLE-BOUNDARY-START(25771160781)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletToken.Amount.get
            get LCFCW$IWalletToken$Amount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296324301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Amount;
            }
            //--TRIMMABLE-BOUNDARY-END(25771160781)
            
            //--TRIMMABLE-BOUNDARY-START(51540964557)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletToken.FrozenAmount.get
            get LCFCW$IWalletToken$FrozenAmount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181226189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FrozenAmount;
            }
            //--TRIMMABLE-BOUNDARY-END(51540964557)
            
            //--TRIMMABLE-BOUNDARY-START(34361095373)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletToken.Cashback.get
            get LCFCW$IWalletToken$Cashback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591291597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Cashback;
            }
            //--TRIMMABLE-BOUNDARY-END(34361095373)
            
            //--TRIMMABLE-BOUNDARY-START(30066652365)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066652365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066652365)
            
            //--TRIMMABLE-BOUNDARY-START(30066652365)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(30066652365)
            
            static $h = 1881293;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.DataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(197570376909),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965998285,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188980442317,
        "f": 83886081
      },
      "n": "WalletName",
      "d": 1881293,
      "h": 197570376909,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197570376909),
//--TRIMMABLE-BOUNDARY-START(133145867469),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196194509,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171800573133,
        "f": 83886081
      },
      "n": "IsSetup",
      "d": 1881293,
      "h": 133145867469,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145867469),
//--TRIMMABLE-BOUNDARY-START(34361619661),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836456141,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030769357,
        "f": 83886081
      },
      "n": "Amount",
      "d": 1881293,
      "h": 34361619661,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361619661),
//--TRIMMABLE-BOUNDARY-START(47246521549),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606259917,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210638541,
        "f": 83886081
      },
      "n": "FrozenAmount",
      "d": 1881293,
      "h": 47246521549,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246521549),
//--TRIMMABLE-BOUNDARY-START(38656586957),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426390733,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620703949,
        "f": 83886081
      },
      "n": "Cashback",
      "d": 1881293,
      "h": 38656586957,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656586957),
//--TRIMMABLE-BOUNDARY-START(42951554253),
    {
      "p": 2864333,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016325325,
        "f": 50331649
      },
      "n": "CoinIdentifier",
      "d": 1881293,
      "h": 42951554253,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42951554253),
//--TRIMMABLE-BOUNDARY-START(193275409613),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376063693,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390507725,
        "f": 83886081
      },
      "n": "Transactions",
      "d": 1881293,
      "h": 193275409613,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193275409613),
//--TRIMMABLE-BOUNDARY-START(137440834765),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.DateTime, $.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786129101,
        "f": 50331649
      },
      "n": "MonthlyHistories",
      "d": 1881293,
      "h": 137440834765,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137440834765)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(120260965581),
    {
      "r": 1179649,
      "p": [
        {
          "n": "currentUserId",
          "p": 10455382
        }
      ],
      "n": "GetCredited",
      "d": 1881293,
      "h": 120260965581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120260965581),
//--TRIMMABLE-BOUNDARY-START(124555932877),
    {
      "r": 1179649,
      "p": [
        {
          "n": "currentUserId",
          "p": 10455382
        }
      ],
      "n": "GetDebited",
      "d": 1881293,
      "h": 124555932877,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124555932877),
//--TRIMMABLE-BOUNDARY-START(128850900173),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Double).$h,
      "p": [
        {
          "n": "currentUserId",
          "p": 10455382
        },
        {
          "n": "groupIndex",
          "p": 655361,
          "f": 65,
          "v": 2
        }
      ],
      "n": "GetPaymentCategories",
      "d": 1881293,
      "h": 128850900173,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850900173)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066652365),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1881293,
      "h": 30066652365,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066652365)
  ],
  "h": 1881293
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$OJJQ.LCFCW.IWalletToken ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}UserWalletDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1881293)
        
        

        //--TRIMMABLE-BOUNDARY-START(1488077)
        $asm.$cls(`$OJJQ.LCFCW.IWalletTransactionRemoteService`, ($self) => class IWalletTransactionRemoteService
        {
            static $h = 1488077;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1488077,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.ICreateDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.IReadDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletTransactionRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletTransactionRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1488077)
        
        

        //--TRIMMABLE-BOUNDARY-START(1029325)
        $asm.$cls(`$OJJQ.LCFCW.IWalletRemoteService`, ($self) => class IWalletRemoteService
        {
            static $h = 1029325;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950702285),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$$.S.Boolean)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        }
      ],
      "n": "IssueCoinIfNoneExists",
      "o": "LCFCW$IWalletRemoteService$IssueCoinIfNoneExists",
      "d": 1029325,
      "h": 42950702285,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950702285),
//--TRIMMABLE-BOUNDARY-START(38655734989),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "reference",
          "p": 1310721
        }
      ],
      "n": "GetTransaction",
      "o": "LCFCW$IWalletRemoteService$GetTransaction",
      "d": 1029325,
      "h": 38655734989,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655734989),
//--TRIMMABLE-BOUNDARY-START(12885931213),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "targetAccount",
          "p": 10455382
        },
        {
          "n": "password",
          "p": 1310721
        }
      ],
      "n": "Create",
      "o": "LCFCW$IWalletRemoteService$Create",
      "d": 1029325,
      "h": 12885931213,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885931213),
//--TRIMMABLE-BOUNDARY-START(8590963917),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "targetAccount",
          "p": 10455382
        },
        {
          "n": "newPassword",
          "p": 1310721
        },
        {
          "n": "oldPassword",
          "p": 1310721
        }
      ],
      "n": "ChangePassword",
      "o": "LCFCW$IWalletRemoteService$ChangePassword",
      "d": 1029325,
      "h": 8590963917,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590963917),
//--TRIMMABLE-BOUNDARY-START(30065800397),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "targetAccount",
          "p": 10455382
        }
      ],
      "n": "GetBalance",
      "o": "LCFCW$IWalletRemoteService$GetBalance",
      "d": 1029325,
      "h": 30065800397,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065800397),
//--TRIMMABLE-BOUNDARY-START(34360767693),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "targetAccount",
          "p": 10455382
        }
      ],
      "n": "GetSummary",
      "o": "LCFCW$IWalletRemoteService$GetSummary",
      "d": 1029325,
      "h": 34360767693,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360767693),
//--TRIMMABLE-BOUNDARY-START(55835604173),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "targetAccount",
          "p": 10455382
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "transactionReference",
          "p": 1310721
        },
        {
          "n": "transactionTargetId",
          "p": 10455382
        },
        {
          "n": "transactionDescription",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "Reward",
      "o": "LCFCW$IWalletRemoteService$Reward",
      "d": 1029325,
      "h": 55835604173,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55835604173),
//--TRIMMABLE-BOUNDARY-START(25770833101),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "targetAccount",
          "p": 10455382
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "paymentReference",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        }
      ],
      "n": "FundAsync",
      "o": "LCFCW$IWalletRemoteService$FundAsync",
      "d": 1029325,
      "h": 25770833101,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770833101),
//--TRIMMABLE-BOUNDARY-START(17180898509),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "targetAccount",
          "p": 10455382
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "transactionReference",
          "p": 1310721
        },
        {
          "n": "transactionTargetId",
          "p": 10455382,
          "f": 65
        },
        {
          "n": "transactionDescription",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "password",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "allowNegativeBalance",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "segment",
          "p": 2995405,
          "f": 65,
          "v": 1
        },
        {
          "n": "giveCashbackProportion",
          "p": 1179649,
          "f": 65,
          "v": 0
        },
        {
          "n": "createPayment",
          "p": 12592470,
          "f": 65
        }
      ],
      "n": "DeductCoins",
      "o": "LCFCW$IWalletRemoteService$DeductCoins",
      "d": 1029325,
      "h": 17180898509,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180898509),
//--TRIMMABLE-BOUNDARY-START(60130571469),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "senderAccount",
          "p": 10455382
        },
        {
          "n": "receiverAccount",
          "p": 10455382
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "paymentReference",
          "p": 1310721
        },
        {
          "n": "transactionTargetId",
          "p": 10455382,
          "f": 65
        },
        {
          "n": "transactionDescription",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "password",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "allowNegativeBalance",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "senderSegment",
          "p": 2995405,
          "f": 65,
          "v": 1
        },
        {
          "n": "receiveSegment",
          "p": 2995405,
          "f": 65,
          "v": 1
        }
      ],
      "n": "TransferTo",
      "o": "LCFCW$IWalletRemoteService$TransferTo",
      "d": 1029325,
      "h": 60130571469,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(60130571469),
//--TRIMMABLE-BOUNDARY-START(47245669581),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "senderAccount",
          "p": 10455382
        },
        {
          "n": "receiverAccounts",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Double).$h
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "paymentReference",
          "p": 1310721
        },
        {
          "n": "transactionTargetId",
          "p": 10455382,
          "f": 65
        },
        {
          "n": "transactionDescription",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "password",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "allowNegativeBalance",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "freezeTransferedAmount",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "MultipleTransferTo",
      "o": "LCFCW$IWalletRemoteService$MultipleTransferTo",
      "d": 1029325,
      "h": 47245669581,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47245669581),
//--TRIMMABLE-BOUNDARY-START(21475865805),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "accountId",
          "p": 10455382
        },
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "FreezeAmount",
      "o": "LCFCW$IWalletRemoteService$FreezeAmount",
      "d": 1029325,
      "h": 21475865805,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475865805),
//--TRIMMABLE-BOUNDARY-START(64425538765),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "accountId",
          "p": 10455382
        },
        {
          "n": "amount",
          "p": 1179649
        }
      ],
      "n": "UnfreezeAmount",
      "o": "LCFCW$IWalletRemoteService$UnfreezeAmount",
      "d": 1029325,
      "h": 64425538765,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(64425538765),
//--TRIMMABLE-BOUNDARY-START(51540636877),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "targetAccount",
          "p": 10455382
        },
        {
          "n": "transaction",
          "p": 2208973
        }
      ],
      "n": "Reverse",
      "o": "LCFCW$IWalletRemoteService$Reverse",
      "d": 1029325,
      "h": 51540636877,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51540636877),
//--TRIMMABLE-BOUNDARY-START(4295996621),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult)).$h,
      "p": [
        {
          "n": "walletName",
          "p": 1310721
        },
        {
          "n": "amount",
          "p": 1179649
        },
        {
          "n": "bankAccount",
          "p": 5474646
        },
        {
          "n": "password",
          "p": 1310721
        },
        {
          "n": "transactionDescription",
          "p": 1310721
        }
      ],
      "n": "BankTransfer",
      "o": "LCFCW$IWalletRemoteService$BankTransfer",
      "d": 1029325,
      "h": 4295996621,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295996621)
  ],
  "h": 1029325,
  "a": [
    {
      "t": 3537875,
      "c": 4298505171
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.ICreateDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.IReadDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1029325)
        
        

        //--TRIMMABLE-BOUNDARY-START(636109)
        $asm.$cls(`$OJJQ.LCFCW.IWalletIssuer`, ($self) => class IWalletIssuer
        {
            static $h = 636109;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885537997),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360374477,
        "f": 50331905
      },
      "n": "CurrencyUnit",
      "o": "LCFCW$IWalletIssuer$CurrencyUnit",
      "d": 636109,
      "h": 12885537997,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885537997),
//--TRIMMABLE-BOUNDARY-START(8590570701),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.WalletTokenDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770439885,
        "f": 50331905
      },
      "n": "CoinDescriptors",
      "o": "LCFCW$IWalletIssuer$CoinDescriptors",
      "d": 636109,
      "h": 8590570701,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590570701),
//--TRIMMABLE-BOUNDARY-START(17180505293),
    {
      "p": 2667725,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950309069,
        "f": 50331905
      },
      "n": "Features",
      "o": "LCFCW$IWalletIssuer$Features",
      "d": 636109,
      "h": 17180505293,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180505293)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295603405),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceName",
          "p": 1310721
        }
      ],
      "n": "CanPayForService",
      "o": "LCFCW$IWalletIssuer$CanPayForService",
      "d": 636109,
      "h": 4295603405,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295603405)
  ],
  "h": 636109
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataConverter$$$($.$OJJQ.LCFCW.WalletToken, $.$fPer.LCFCDM.Money), $.$fPer.LCFCD.IDataConverter$$$($.$fPer.LCFCDM.Money, $.$OJJQ.LCFCW.WalletToken) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletIssuer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(636109)
        
        

        //--TRIMMABLE-BOUNDARY-START(1553613)
        $asm.$cls(`$OJJQ.LCFCW.IWalletTransactionRemoteService_Mocking`, ($self) => class IWalletTransactionRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296520909)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296520909);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296520909)
            
            //--TRIMMABLE-BOUNDARY-START(8591488205)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Frameworks$Common$Wallet$UserWalletTransactionModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591488205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i1.MethodName = "Create";
                    return $i1;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OJJQ.LCFCW.UserWalletTransactionModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591488205)
            
            //--TRIMMABLE-BOUNDARY-START(17181422797)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Frameworks$Common$Wallet$UserWalletTransactionModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181422797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i2.MethodName = "ReadMany";
                    return $i2;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OJJQ.LCFCW.UserWalletTransactionModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181422797)
            
            //--TRIMMABLE-BOUNDARY-START(21476390093)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Frameworks$Common$Wallet$UserWalletTransactionModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476390093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i3.MethodName = "ReadSingle";
                    return $i3;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OJJQ.LCFCW.UserWalletTransactionModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21476390093)
            
            //--TRIMMABLE-BOUNDARY-START(25771357389)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Frameworks$Common$Wallet$UserWalletTransactionModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771357389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i4.MethodName = "Update";
                    return $i4;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OJJQ.LCFCW.UserWalletTransactionModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25771357389)
            
            //--TRIMMABLE-BOUNDARY-START(12886455501)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886455501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i5.MethodName = "Delete";
                    return $i5;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OJJQ.LCFCW.UserWalletTransactionModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12886455501)
            
            static $h = 1553613;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296520909),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1553613,
      "h": 4296520909,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296520909)
  ],
  "h": 1553613
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$OJJQ.LCFCW.IWalletTransactionRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.ICreateDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.IReadDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletTransactionRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletTransactionRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1553613)
        
        

        //--TRIMMABLE-BOUNDARY-START(1094861)
        $asm.$cls(`$OJJQ.LCFCW.IWalletRemoteService_Mocking`, ($self) => class IWalletRemoteService_Mocking extends $.$uvJL.LCFCR.RemoteProxyServiceBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296062157)
            $ctor$3(/*IMockImplement*/ impl)
            {
                super.$ctor$2(impl);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296062157);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296062157)
            
            //--TRIMMABLE-BOUNDARY-START(68720571597)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<bool>> */ LCFCW$IWalletRemoteService$IssueCoinIfNoneExists(/*string*/ walletName, /*double*/ amount, /*string?*/ transactionDescription)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720571597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t1 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Mock = this;
                    $i1.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i1.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$$.S.Boolean).$type;
                    $i1.MethodName = "IssueCoinIfNoneExists";
                    return $i1;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionDescription) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(68720571597)
            
            //--TRIMMABLE-BOUNDARY-START(64425604301)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCFCW$IWalletRemoteService$GetTransaction(/*string*/ walletName, /*string*/ reference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425604301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t2 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Mock = this;
                    $i2.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i2.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i2.MethodName = "GetTransaction";
                    return $i2;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, reference) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(64425604301)
            
            //--TRIMMABLE-BOUNDARY-START(38655800525)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>> */ LCFCW$IWalletRemoteService$Create(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ targetAccount, /*string?*/ password)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655800525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t3 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Mock = this;
                    $i3.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i3.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i3.MethodName = "Create";
                    return $i3;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(targetAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, password) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(38655800525)
            
            //--TRIMMABLE-BOUNDARY-START(34360833229)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCFCW$IWalletRemoteService$ChangePassword(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ targetAccount, /*string*/ newPassword, /*string?*/ oldPassword)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360833229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t4 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Mock = this;
                    $i4.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i4.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i4.MethodName = "ChangePassword";
                    return $i4;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(targetAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, newPassword), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, oldPassword) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(34360833229)
            
            //--TRIMMABLE-BOUNDARY-START(55835669709)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>> */ LCFCW$IWalletRemoteService$GetBalance(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ targetAccount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835669709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t5 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Mock = this;
                    $i5.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i5.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i5.MethodName = "GetBalance";
                    return $i5;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(targetAccount)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(55835669709)
            
            //--TRIMMABLE-BOUNDARY-START(60130637005)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>> */ LCFCW$IWalletRemoteService$GetSummary(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ targetAccount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130637005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t6 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Mock = this;
                    $i6.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i6.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i6.MethodName = "GetSummary";
                    return $i6;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(targetAccount)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(60130637005)
            
            //--TRIMMABLE-BOUNDARY-START(81605473485)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCFCW$IWalletRemoteService$Reward(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ targetAccount, /*double*/ amount, /*string*/ transactionReference, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ transactionTargetId, /*string?*/ transactionDescription)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605473485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t7 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Mock = this;
                    $i7.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i7.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i7.MethodName = "Reward";
                    return $i7;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(targetAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionReference), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(transactionTargetId)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionDescription) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(81605473485)
            
            //--TRIMMABLE-BOUNDARY-START(51540702413)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCFCW$IWalletRemoteService$FundAsync(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ targetAccount, /*double*/ amount, /*string*/ paymentReference, /*string?*/ transactionDescription)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540702413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t8 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Mock = this;
                    $i8.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i8.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i8.MethodName = "FundAsync";
                    return $i8;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(targetAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, paymentReference), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionDescription) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(51540702413)
            
            //--TRIMMABLE-BOUNDARY-START(42950767821)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCFCW$IWalletRemoteService$DeductCoins(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ targetAccount, /*double*/ amount, /*string*/ transactionReference, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ transactionTargetId, /*string?*/ transactionDescription, /*string?*/ password, /*bool*/ allowNegativeBalance, /*LivingThing.Core.Frameworks.Common.Wallet.WalletSegment*/ segment, /*double*/ giveCashbackProportion, /*LivingThing.Core.Frameworks.Common.Models.PaymentModel?*/ createPayment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950767821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t9 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Mock = this;
                    $i9.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i9.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i9.MethodName = "DeductCoins";
                    return $i9;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(targetAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionReference), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(transactionTargetId)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionDescription), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, password), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(allowNegativeBalance, $.$$.S.Boolean)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OJJQ.LCFCW.WalletSegment.$type, $.$box(segment, $.$OJJQ.LCFCW.WalletSegment)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(giveCashbackProportion, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$Iaui.LCFCM.PaymentModel.$type, createPayment) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(42950767821)
            
            //--TRIMMABLE-BOUNDARY-START(85900440781)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCFCW$IWalletRemoteService$TransferTo(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ senderAccount, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ receiverAccount, /*double*/ amount, /*string*/ paymentReference, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ transactionTargetId, /*string?*/ transactionDescription, /*string?*/ password, /*bool*/ allowNegativeBalance, /*LivingThing.Core.Frameworks.Common.Wallet.WalletSegment*/ senderSegment, /*LivingThing.Core.Frameworks.Common.Wallet.WalletSegment*/ receiveSegment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900440781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t10 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Mock = this;
                    $i10.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i10.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i10.MethodName = "TransferTo";
                    return $i10;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(senderAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(receiverAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, paymentReference), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(transactionTargetId)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionDescription), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, password), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(allowNegativeBalance, $.$$.S.Boolean)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OJJQ.LCFCW.WalletSegment.$type, $.$box(senderSegment, $.$OJJQ.LCFCW.WalletSegment)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OJJQ.LCFCW.WalletSegment.$type, $.$box(receiveSegment, $.$OJJQ.LCFCW.WalletSegment)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(85900440781)
            
            //--TRIMMABLE-BOUNDARY-START(73015538893)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel>> */ LCFCW$IWalletRemoteService$MultipleTransferTo(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ senderAccount, /*System.Collections.Generic.Dictionary<string, double>*/ receiverAccounts, /*double*/ amount, /*string*/ paymentReference, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ transactionTargetId, /*string?*/ transactionDescription, /*string?*/ password, /*bool*/ allowNegativeBalance, /*bool*/ freezeTransferedAmount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015538893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t11 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i11 = new $t11();
                    $i11.$ctor$2();
                    $i11.Mock = this;
                    $i11.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i11.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel).$type;
                    $i11.MethodName = "MultipleTransferTo";
                    return $i11;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(senderAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Double).$type, receiverAccounts), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, paymentReference), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(transactionTargetId)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionDescription), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, password), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(allowNegativeBalance, $.$$.S.Boolean)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Boolean.$type, $.$box(freezeTransferedAmount, $.$$.S.Boolean)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(73015538893)
            
            //--TRIMMABLE-BOUNDARY-START(47245735117)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCFCW$IWalletRemoteService$FreezeAmount(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ accountId, /*double*/ amount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245735117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t12 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i12 = new $t12();
                    $i12.$ctor$2();
                    $i12.Mock = this;
                    $i12.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i12.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i12.MethodName = "FreezeAmount";
                    return $i12;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(accountId)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(47245735117)
            
            //--TRIMMABLE-BOUNDARY-START(90195408077)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCFCW$IWalletRemoteService$UnfreezeAmount(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ accountId, /*double*/ amount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195408077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t13 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i13 = new $t13();
                    $i13.$ctor$2();
                    $i13.Mock = this;
                    $i13.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i13.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i13.MethodName = "UnfreezeAmount";
                    return $i13;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(accountId)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(90195408077)
            
            //--TRIMMABLE-BOUNDARY-START(77310506189)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel> */ LCFCW$IWalletRemoteService$Reverse(/*string*/ walletName, /*LivingThing.Core.Frameworks.Common.Data.DataId*/ targetAccount, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel*/ transaction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310506189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t14 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i14 = new $t14();
                    $i14.$ctor$2();
                    $i14.Mock = this;
                    $i14.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i14.ReturnType = $.$fPer.LCFCD.WireTransportModel.$type;
                    $i14.MethodName = "Reverse";
                    return $i14;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel, $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataId.$type, $.$clone(targetAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OJJQ.LCFCW.UserWalletTransactionModel.$type, transaction) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(77310506189)
            
            //--TRIMMABLE-BOUNDARY-START(30065865933)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Data.BankTransferResult>> */ LCFCW$IWalletRemoteService$BankTransfer(/*string*/ walletName, /*double*/ amount, /*LivingThing.Core.Frameworks.Common.Data.BankAccount*/ bankAccount, /*string*/ password, /*string?*/ transactionDescription)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065865933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t15 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i15 = new $t15();
                    $i15.$ctor$2();
                    $i15.Mock = this;
                    $i15.DeclaringType = $.$OJJQ.LCFCW.IWalletRemoteService.$type;
                    $i15.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult).$type;
                    $i15.MethodName = "BankTransfer";
                    return $i15;
                })();
                return this.InvokeAsync($.$OJJQ.LCFCW.IWalletRemoteService, $.$fPer.LCFCD.WireTransportModel$$($.$fPer.LCFCD.BankTransferResult), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, walletName), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.Double.$type, $.$box(amount, $.$$.S.Double)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.BankAccount.$type, $.$clone(bankAccount)), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, password), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$$.S.String.$type, transactionDescription) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30065865933)
            
            //--TRIMMABLE-BOUNDARY-START(8591029453)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>> */ LCFCD$ICreateDataService$LivingThing$Core$Frameworks$Common$Wallet$UserWalletDataModel$Create(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591029453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t16 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i16 = new $t16();
                    $i16.$ctor$2();
                    $i16.Mock = this;
                    $i16.DeclaringType = $.$fPer.LCFCD.ICreateDataService$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i16.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i16.MethodName = "Create";
                    return $i16;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.ICreateDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OJJQ.LCFCW.UserWalletDataModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8591029453)
            
            //--TRIMMABLE-BOUNDARY-START(17180964045)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>> */ LCFCD$IReadManyDataService$LivingThing$Core$Frameworks$Common$Wallet$UserWalletDataModel$ReadMany(/*LivingThing.Core.Frameworks.Common.Data.DataFilter?*/ filter, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180964045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t17 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i17 = new $t17();
                    $i17.$ctor$2();
                    $i17.Mock = this;
                    $i17.DeclaringType = $.$fPer.LCFCD.IReadManyDataService$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i17.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i17.MethodName = "ReadMany";
                    return $i17;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadManyDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OJJQ.LCFCW.UserWalletDataModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17180964045)
            
            //--TRIMMABLE-BOUNDARY-START(21475931341)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>> */ LCFCD$IReadSingleDataService$LivingThing$Core$Frameworks$Common$Wallet$UserWalletDataModel$ReadSingle(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475931341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t18 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i18 = new $t18();
                    $i18.$ctor$2();
                    $i18.Mock = this;
                    $i18.DeclaringType = $.$fPer.LCFCD.IReadSingleDataService$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i18.ReturnType = $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i18.MethodName = "ReadSingle";
                    return $i18;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IReadSingleDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.WireTransportModel$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$OJJQ.LCFCW.UserWalletDataModel.$type, _) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(21475931341)
            
            //--TRIMMABLE-BOUNDARY-START(25770898637)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel>> */ LCFCD$IUpdateDataService$LivingThing$Core$Frameworks$Common$Wallet$UserWalletDataModel$Update(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770898637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t19 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i19 = new $t19();
                    $i19.$ctor$2();
                    $i19.Mock = this;
                    $i19.DeclaringType = $.$fPer.LCFCD.IUpdateDataService$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i19.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i19.MethodName = "Update";
                    return $i19;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IUpdateDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OJJQ.LCFCW.UserWalletDataModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(25770898637)
            
            //--TRIMMABLE-BOUNDARY-START(12885996749)
            /*System.Threading.Tasks.Task<LivingThing.Core.Frameworks.Common.Data.WireTransportManyModel<bool>> */ LCFCD$IDeleteDataService$$$Delete(/*LivingThing.Core.Frameworks.Common.Data.DataFilter*/ filter, /*LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel[]*/ models)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885996749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$zHIt.LCFCM.MockMethodContext()
                    const $t20 = $.$zHIt.LCFCM.MockMethodContext;
                    const $i20 = new $t20();
                    $i20.$ctor$2();
                    $i20.Mock = this;
                    $i20.DeclaringType = $.$fPer.LCFCD.IDeleteDataService$$($.$OJJQ.LCFCW.UserWalletDataModel).$type;
                    $i20.ReturnType = $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean).$type;
                    $i20.MethodName = "Delete";
                    return $i20;
                })();
                return this.InvokeAsync($.$fPer.LCFCD.IDeleteDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.WireTransportManyModel$$($.$$.S.Boolean), $.$clone(context), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$zHIt.LCFCM.MockMethodParameter), [ new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$fPer.LCFCD.DataFilter.$type, filter), new $.$zHIt.LCFCM.MockMethodParameter().$ctor$4($.$typeArray($.$OJJQ.LCFCW.UserWalletDataModel).$type, models) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(12885996749)
            
            static $h = 1094861;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$uvJL.LCFCR.RemoteProxyServiceBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296062157),
    {
      "p": [
        {
          "n": "impl",
          "p": 192326
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1094861,
      "h": 4296062157,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296062157)
  ],
  "h": 1094861
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$zHIt.LCFCM.IMocked, $.$OJJQ.LCFCW.IWalletRemoteService, $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.ICreateDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.IReadDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.IReadManyDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.IUpdateDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD.IDeleteDataService$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.IWalletRemoteService_Mocking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}IWalletRemoteService_Mocking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1094861)
        
        

        //--TRIMMABLE-BOUNDARY-START(2012365)
        $asm.$cls(`$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor`, ($self) => class UserWalletDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OJJQ.LCFCW.UserWalletDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296979661)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296979661);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor.GenerateProperties($.$OJJQ.LCFCW.UserWalletDataModel, this, factory);
                    }, $WgyVGi ??= {"r":65537,"n":"","d":2012365,"h":0,"f":17825794}), 0, "UserWalletDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Wallet\\UserWalletDataModel_LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModelTypeDescriptorBuilder.g.cs", "UserWalletDataModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296979661)
            
            //--TRIMMABLE-BOUNDARY-START(12886914253)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886914253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("WalletName"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletDataModel.$type, $.$discardRef(), "WalletName", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("WalletName")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "WalletName";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OJJQ.LCFCW.UserWalletDataModel)).WalletName);
                        }, $mIEUmg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2012365,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.WalletName = value.AsReference($.$$.S.String);
                        }, $gpLJEc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2012365,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsSetup"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletDataModel.$type, $.$discardRef(), "IsSetup", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsSetup")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "IsSetup";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$OJJQ.LCFCW.UserWalletDataModel)).IsSetup);
                        }, $zegkei ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2012365,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.IsSetup = value.AsBool();
                        }, $lkJCUd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2012365,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletDataModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Amount";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$OJJQ.LCFCW.UserWalletDataModel)).Amount);
                        }, $phWTza ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2012365,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Amount = value.AsDouble();
                        }, $RJWIXb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2012365,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FrozenAmount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletDataModel.$type, $.$discardRef(), "FrozenAmount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FrozenAmount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "FrozenAmount";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$OJJQ.LCFCW.UserWalletDataModel)).FrozenAmount);
                        }, $djwzye ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2012365,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target, /**/ value) =>
                        {
                            return target.FrozenAmount = value.AsDouble();
                        }, $uEwrrj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2012365,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Cashback"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletDataModel.$type, $.$discardRef(), "Cashback", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Cashback")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Cashback";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$OJJQ.LCFCW.UserWalletDataModel)).Cashback);
                        }, $yxCkSb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2012365,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Cashback = value.AsDouble();
                        }, $EcCNvi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2012365,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CoinIdentifier"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletDataModel.$type, $.$discardRef(), "CoinIdentifier", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CoinIdentifier")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletIdentifier, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "CoinIdentifier";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletIdentifier, ($.$cast(target, $.$OJJQ.LCFCW.UserWalletDataModel)).CoinIdentifier);
                        }, $iDqgqg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2012365,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Transactions"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletDataModel.$type, $.$discardRef(), "Transactions", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Transactions")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Transactions";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel), ($.$cast(target, $.$OJJQ.LCFCW.UserWalletDataModel)).Transactions);
                        }, $ybcxKb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2012365,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Transactions = value.AsReference($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel));
                        }, $JJkvgc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2012365,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MonthlyHistories"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletDataModel.$type, $.$discardRef(), "MonthlyHistories", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MonthlyHistories")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.DateTime, $.$$.S.Double), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "MonthlyHistories";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.DateTime, $.$$.S.Double), ($.$cast(target, $.$OJJQ.LCFCW.UserWalletDataModel)).MonthlyHistories);
                        }, $nfOlwc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2012365,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCM.DataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886914253)
            
            //--TRIMMABLE-BOUNDARY-START(17181881549)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181881549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.DataModel?*/ let targetBase = _target;
                $.$Iaui.LCFCM.DataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.DataModel));
                {
                    /*var*/ let _WalletName = _target.WalletName;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("WalletName"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _WalletName, ($v) => _WalletName = $v, $.$$.S.String)))
                    {
                        _target.WalletName = _WalletName;
                    }
                }
                {
                    /*var*/ let _IsSetup = _target.IsSetup;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsSetup"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsSetup, ($v) => _IsSetup = $v, null, true)))
                    {
                        _target.IsSetup = _IsSetup;
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Amount, ($v) => _Amount = $v, $.$$.S.Double)))
                    {
                        _target.Amount = _Amount;
                    }
                }
                {
                    /*var*/ let _FrozenAmount = _target.FrozenAmount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FrozenAmount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _FrozenAmount, ($v) => _FrozenAmount = $v, $.$$.S.Double)))
                    {
                        _target.FrozenAmount = _FrozenAmount;
                    }
                }
                {
                    /*var*/ let _Cashback = _target.Cashback;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Cashback"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Cashback, ($v) => _Cashback = $v, $.$$.S.Double)))
                    {
                        _target.Cashback = _Cashback;
                    }
                }
                {
                    /*var*/ let _CoinIdentifier = _target.CoinIdentifier;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CoinIdentifier"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletIdentifier));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletIdentifier, () => _CoinIdentifier, ($v) => _CoinIdentifier = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Transactions = _target.Transactions;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Transactions"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$OJJQ.LCFCW.UserWalletTransactionModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$OJJQ.LCFCW.UserWalletTransactionModel, property, $.$ref(() => _Transactions, ($v) => _Transactions = $v, $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel))))
                    {
                        _target.Transactions = _Transactions;
                        if (_Transactions !== null)
                        {
                            let $en27 = _Transactions.SCG$IEnumerable$$$GetEnumerator();
                            while ($en27.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en27.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$OJJQ.LCFCW.UserWalletTransactionModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$OJJQ.LCFCW.UserWalletTransactionModel, property, $.$ref(() => _Transactions, ($v) => _Transactions = $v, $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.UserWalletTransactionModel)));
                    }
                }
                {
                    /*var*/ let _MonthlyHistories = _target.MonthlyHistories;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MonthlyHistories"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.DateTime, $.$$.S.Double)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _MonthlyHistories, ($v) => _MonthlyHistories = $v, $.$$.SCG.Dictionary$$$($.$$.S.DateTime, $.$$.S.Double))))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181881549)
            
            //--TRIMMABLE-BOUNDARY-START(8591946957)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591946957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OJJQ.LCFCW.UserWalletDataModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OJJQ.LCFCW.UserWalletDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OJJQ.LCFCW.UserWalletDataModel)))
                {
                    /*var*/ let result = $.$OJJQ.LCFCW.UserWalletDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OJJQ.LCFCW.UserWalletDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OJJQ.LCFCW.UserWalletDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OJJQ.LCFCW.UserWalletDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591946957)
            
            static $h = 2012365;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OJJQ.LCFCW.UserWalletDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886914253),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2012365,
      "h": 12886914253,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886914253),
//--TRIMMABLE-BOUNDARY-START(17181881549),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1881293,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2012365,
      "h": 17181881549,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181881549),
//--TRIMMABLE-BOUNDARY-START(8591946957),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1881293,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2012365,
      "h": 8591946957,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591946957)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296979661),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2012365,
      "h": 4296979661,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296979661)
  ],
  "h": 2012365
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OJJQ.LCFCW.UserWalletDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.UserWalletDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}UserWalletDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2012365)
        
        

        //--TRIMMABLE-BOUNDARY-START(2340045)
        $asm.$cls(`$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor`, ($self) => class UserWalletTransactionModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OJJQ.LCFCW.UserWalletTransactionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297307341)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297307341);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor.GenerateProperties($.$OJJQ.LCFCW.UserWalletTransactionModel, this, factory);
                    }, $aEalhl ??= {"r":65537,"n":"","d":2340045,"h":0,"f":17825794}), 0, "UserWalletTransactionModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.Common.Wallet\\UserWalletTransactionModel_LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModelTypeDescriptorBuilder.g.cs", "UserWalletTransactionModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297307341)
            
            //--TRIMMABLE-BOUNDARY-START(12887241933)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887241933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Reference"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "Reference", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Reference")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Reference";
                        $i1.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).Reference);
                        }, $KkXyAc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Reference = value.AsReference($.$$.S.String);
                        }, $BWjMol ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Description";
                        $i3.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).Description);
                        }, $MmWcMd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Description = value.AsReference($.$$.S.String);
                        }, $wCzsZk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Date"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "Date", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Date")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Date";
                        $i5.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).Date);
                        }, $UWoXuh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Date = value.AsDateTime();
                        }, $ZDFqbg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Amount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "Amount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Amount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Amount";
                        $i7.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).Amount);
                        }, $akuyOg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Amount = value.AsDouble();
                        }, $UAbIFi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BalanceAfter"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "BalanceAfter", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BalanceAfter")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "BalanceAfter";
                        $i9.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).BalanceAfter);
                        }, $xuJNSe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BalanceAfter = value.AsDouble();
                        }, $pBDGRh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FrozenBalanceAfter"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "FrozenBalanceAfter", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FrozenBalanceAfter")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "FrozenBalanceAfter";
                        $i11.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).FrozenBalanceAfter);
                        }, $gIdXJa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FrozenBalanceAfter = value.AsDouble();
                        }, $KNvmCe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CashbackBalanceAfter"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "CashbackBalanceAfter", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CashbackBalanceAfter")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "CashbackBalanceAfter";
                        $i13.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).CashbackBalanceAfter);
                        }, $lNLcSa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CashbackBalanceAfter = value.AsDouble();
                        }, $viOaFd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SenderAccount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "SenderAccount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SenderAccount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$Iaui.LCFCM.UserModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "SenderAccount";
                        $i15.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$Iaui.LCFCM.UserModel, ($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).SenderAccount);
                        }, $ZBFNei ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SenderAccount = value.AsReference($.$Iaui.LCFCM.UserModel);
                        }, $EXWRde ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ReceiverAccount"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "ReceiverAccount", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ReceiverAccount")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$Iaui.LCFCM.UserModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "ReceiverAccount";
                        $i17.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$Iaui.LCFCM.UserModel, ($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).ReceiverAccount);
                        }, $zTNYDg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ReceiverAccount = value.AsReference($.$Iaui.LCFCM.UserModel);
                        }, $aCyqWg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Payments"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "Payments", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Payments")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Payments";
                        $i19.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel), ($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).Payments);
                        }, $Acyubc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Payments = value.AsReference($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel));
                        }, $qgMikk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Sender"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "Sender", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Sender")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletAddress, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t21 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i21 = new $t21();
                        $i21.$ctor$2();
                        $i21.Name = "Sender";
                        $i21.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i21.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletAddress, ($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).Sender);
                        }, $trtkhf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i21;
                    })()), schemas, null, factory);
                    let $en22 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en22.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en22.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Receiver"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "Receiver", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Receiver")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletAddress, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t23 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i23 = new $t23();
                        $i23.$ctor$2();
                        $i23.Name = "Receiver";
                        $i23.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i23.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletAddress, ($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).Receiver);
                        }, $VLZxUd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i23;
                    })()), schemas, null, factory);
                    let $en24 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en24.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en24.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Coin"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$OJJQ.LCFCW.UserWalletTransactionModel.$type, $.$discardRef(), "Coin", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Coin")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$OJJQ.LCFCW.WalletIdentifier, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t25 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i25 = new $t25();
                        $i25.$ctor$2();
                        $i25.Name = "Coin";
                        $i25.DelaredOn = "LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel";
                        $i25.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$15($.$OJJQ.LCFCW.WalletIdentifier, ($.$cast(target, $.$OJJQ.LCFCW.UserWalletTransactionModel)).Coin);
                        }, $lpdmnh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2340045,"h":0,"f":17825826});
                        return $i25;
                    })()), schemas, null, factory);
                    let $en26 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en26.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en26.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$Iaui.LCFCM.DataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887241933)
            
            //--TRIMMABLE-BOUNDARY-START(17182209229)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182209229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.Frameworks.Common.Models.DataModel?*/ let targetBase = _target;
                $.$Iaui.LCFCM.DataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$Iaui.LCFCM.DataModel));
                {
                    /*var*/ let _Reference = _target.Reference;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Reference"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Reference, ($v) => _Reference = $v, $.$$.S.String)))
                    {
                        _target.Reference = _Reference;
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                        _target.Description = _Description;
                    }
                }
                {
                    /*var*/ let _Date = _target.Date;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Date"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _Date, ($v) => _Date = $v, null, true)))
                    {
                        _target.Date = _Date;
                    }
                }
                {
                    /*var*/ let _Amount = _target.Amount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Amount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Amount, ($v) => _Amount = $v, $.$$.S.Double)))
                    {
                        _target.Amount = _Amount;
                    }
                }
                {
                    /*var*/ let _BalanceAfter = _target.BalanceAfter;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BalanceAfter"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _BalanceAfter, ($v) => _BalanceAfter = $v, $.$$.S.Double)))
                    {
                        _target.BalanceAfter = _BalanceAfter;
                    }
                }
                {
                    /*var*/ let _FrozenBalanceAfter = _target.FrozenBalanceAfter;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FrozenBalanceAfter"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _FrozenBalanceAfter, ($v) => _FrozenBalanceAfter = $v, $.$$.S.Double)))
                    {
                        _target.FrozenBalanceAfter = _FrozenBalanceAfter;
                    }
                }
                {
                    /*var*/ let _CashbackBalanceAfter = _target.CashbackBalanceAfter;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CashbackBalanceAfter"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _CashbackBalanceAfter, ($v) => _CashbackBalanceAfter = $v, $.$$.S.Double)))
                    {
                        _target.CashbackBalanceAfter = _CashbackBalanceAfter;
                    }
                }
                {
                    /*var*/ let _SenderAccount = _target.SenderAccount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SenderAccount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$Iaui.LCFCM.UserModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _SenderAccount, ($v) => _SenderAccount = $v, $.$Iaui.LCFCM.UserModel)))
                    {
                        _target.SenderAccount = _SenderAccount;
                    }
                }
                {
                    /*var*/ let _ReceiverAccount = _target.ReceiverAccount;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ReceiverAccount"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$Iaui.LCFCM.UserModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ReceiverAccount, ($v) => _ReceiverAccount = $v, $.$Iaui.LCFCM.UserModel)))
                    {
                        _target.ReceiverAccount = _ReceiverAccount;
                    }
                }
                {
                    /*var*/ let _Payments = _target.Payments;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Payments"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel), $.$Iaui.LCFCM.PaymentModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel), $.$Iaui.LCFCM.PaymentModel, property, $.$ref(() => _Payments, ($v) => _Payments = $v, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel))))
                    {
                        _target.Payments = _Payments;
                        if (_Payments !== null)
                        {
                            let $en41 = _Payments.SCG$IEnumerable$$$GetEnumerator();
                            while ($en41.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en41.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$Iaui.LCFCM.PaymentModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel), $.$Iaui.LCFCM.PaymentModel, property, $.$ref(() => _Payments, ($v) => _Payments = $v, $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.PaymentModel)));
                    }
                }
                {
                    /*var*/ let _Sender = _target.Sender;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Sender"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletAddress));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletAddress, () => _Sender, ($v) => _Sender = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Receiver = _target.Receiver;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Receiver"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletAddress));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletAddress, () => _Receiver, ($v) => _Receiver = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Coin = _target.Coin;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Coin"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$OJJQ.LCFCW.WalletIdentifier));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$OJJQ.LCFCW.WalletIdentifier, () => _Coin, ($v) => _Coin = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182209229)
            
            //--TRIMMABLE-BOUNDARY-START(8592274637)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592274637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$OJJQ.LCFCW.UserWalletTransactionModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$OJJQ.LCFCW.UserWalletTransactionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OJJQ.LCFCW.UserWalletTransactionModel)))
                {
                    /*var*/ let result = $.$OJJQ.LCFCW.UserWalletTransactionModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$OJJQ.LCFCW.UserWalletTransactionModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$OJJQ.LCFCW.UserWalletTransactionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$OJJQ.LCFCW.UserWalletTransactionModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592274637)
            
            static $h = 2340045;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$OJJQ.LCFCW.UserWalletTransactionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887241933),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2340045,
      "h": 12887241933,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887241933),
//--TRIMMABLE-BOUNDARY-START(17182209229),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2208973,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2340045,
      "h": 17182209229,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182209229),
//--TRIMMABLE-BOUNDARY-START(8592274637),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2208973,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2340045,
      "h": 8592274637,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592274637)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297307341),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2340045,
      "h": 4297307341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297307341)
  ],
  "h": 2340045
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$OJJQ.LCFCW.UserWalletTransactionModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Wallet.UserWalletTransactionModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Wallet${separator}UserWalletTransactionModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2340045)
        
        

        //--TRIMMABLE-BOUNDARY-START(3454157)
        $asm.$cls(`$OJJQ.LCWCS.DefaultWalletIssuer`, ($self) => class DefaultWalletIssuer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(107377636557)
            /*string */ get Name()
            {
                return "NG"/*DefaultWalletDefinition.GeneralCoinIssuerName*/;
            }
            //--TRIMMABLE-BOUNDARY-END(107377636557)
            
            //--TRIMMABLE-BOUNDARY-START(30068225229)
            /*string */ get CurrencyUnit()
            {
                return "\u20A6"/*DefaultWalletDefinition.GeneralCoinCurrencyUnit*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30068225229)
            
            //--TRIMMABLE-BOUNDARY-START(111672603853)
            /*string */ get Title()
            {
                return "NG Coin"/*DefaultWalletDefinition.GeneralCoinTitle*/;
            }
            //--TRIMMABLE-BOUNDARY-END(111672603853)
            
            //--TRIMMABLE-BOUNDARY-START(34363192525)
            /*string */ get Description()
            {
                return "This coin can be purchased and is awarded when you perform some activities here";
            }
            //--TRIMMABLE-BOUNDARY-END(34363192525)
            
            //--TRIMMABLE-BOUNDARY-START(103082669261)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-currency-ngn"/*MaterialDesignIconNames.CurrencyNgn*/);
            }
            //--TRIMMABLE-BOUNDARY-END(103082669261)
            
            //--TRIMMABLE-BOUNDARY-START(17183323341)
            /*IEnumerable<WalletTokenDescriptor>*/ CoinDescriptors = null;
            //--TRIMMABLE-BOUNDARY-END(17183323341)
            
            //--TRIMMABLE-BOUNDARY-START(38658159821)
            /*WalletFeatures */ get Features()
            {
                return 1/*WalletFeatures.Purchasable*/ | 2/*WalletFeatures.Transferable*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38658159821)
            
            //--TRIMMABLE-BOUNDARY-START(12888356045)
            /*bool */ CanPayForService(/*string?*/ serviceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888356045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(12888356045)
            
            //--TRIMMABLE-BOUNDARY-START(25773257933)
            /*Money */ Convert$1(/*WalletToken*/ input, /*object?*/ param)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773257933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$fPer.LCFCDM.Money().$ctor$3(input.Amount, 1/*MoneyUnitTypes.Naira*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25773257933)
            
            //--TRIMMABLE-BOUNDARY-START(21478290637)
            /*WalletToken */ Convert(/*Money*/ input, /*object?*/ param)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478290637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$OJJQ.LCFCW.WalletToken()
                    const $t1 = $.$OJJQ.LCFCW.WalletToken;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Amount = input.Naira.Value;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(21478290637)
            
            //--TRIMMABLE-BOUNDARY-START(34360374477)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CurrencyUnit.get
            get LCFCW$IWalletIssuer$CurrencyUnit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885537997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrencyUnit;
            }
            //--TRIMMABLE-BOUNDARY-END(34360374477)
            
            //--TRIMMABLE-BOUNDARY-START(25770439885)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CoinDescriptors.get
            get LCFCW$IWalletIssuer$CoinDescriptors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590570701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CoinDescriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(25770439885)
            
            //--TRIMMABLE-BOUNDARY-START(4295603405)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.CanPayForService(string?)
            LCFCW$IWalletIssuer$CanPayForService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295603405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanPayForService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295603405)
            
            //--TRIMMABLE-BOUNDARY-START(42950309069)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Wallet.IWalletIssuer.Features.get
            get LCFCW$IWalletIssuer$Features()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180505293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Features;
            }
            //--TRIMMABLE-BOUNDARY-END(42950309069)
            
            //--TRIMMABLE-BOUNDARY-START(17226762582)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Title.get
            get LCFC$IDisplayable$Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25816697174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Title;
            }
            //--TRIMMABLE-BOUNDARY-END(17226762582)
            
            //--TRIMMABLE-BOUNDARY-START(8636827990)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDisplayable.Icon.get
            get LCFC$IDisplayable$Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21521729878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Icon;
            }
            //--TRIMMABLE-BOUNDARY-END(8636827990)
            
            //--TRIMMABLE-BOUNDARY-START(12931729750)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IDescribable.Description.get
            get LCFC$IDescribable$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341795158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12931729750)
            
            //--TRIMMABLE-BOUNDARY-START(8637417814)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.INamed.Name.get
            get LCFC$INamed$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12932385110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8637417814)
            
            //--TRIMMABLE-BOUNDARY-START(4311845206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataConverter<LivingThing.Core.Frameworks.Common.Wallet.WalletToken, LivingThing.Core.Frameworks.Common.Data.Measurements.Money>.Convert(LivingThing.Core.Frameworks.Common.Wallet.WalletToken, object?)
            LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$Convert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311845206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Convert$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311845206)
            
            //--TRIMMABLE-BOUNDARY-START(4311845206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Data.IDataConverter<LivingThing.Core.Frameworks.Common.Data.Measurements.Money, LivingThing.Core.Frameworks.Common.Wallet.WalletToken>.Convert(LivingThing.Core.Frameworks.Common.Data.Measurements.Money, object?)
            LCFCD$IDataConverter$LivingThing$Core$Frameworks$Common$Data$Measurements$Money$LivingThing$Core$Frameworks$Common$Wallet$WalletToken$Convert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4311845206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Convert(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4311845206)
            
            //--TRIMMABLE-BOUNDARY-START(8593388749)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593388749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593388749)
            
            //--TRIMMABLE-BOUNDARY-START(8593388749)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8593388749)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17183323341)
                this.CoinDescriptors = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$OJJQ.LCFCW.WalletTokenDescriptor), [(() =>
                {
                    //new $.$OJJQ.LCFCW.WalletTokenDescriptor()
                    const $t2 = $.$OJJQ.LCFCW.WalletTokenDescriptor;
                    const $i2 = new $t2();
                    $i2.$ctor$2();
                    $i2.Name = "\u20A6"/*DefaultWalletDefinition.GeneralCoinName*/;
                    $i2.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit("_content/LivingThing.Core.Wallet.Client.Blazor/img/coin.png");
                    return $i2;
                })()], [-1], null);
                //--TRIMMABLE-BOUNDARY-END(17183323341)
                
            }
            static $h = 3454157;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107377636557),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197767373,
        "f": 50331649
      },
      "n": "Name",
      "d": 3454157,
      "h": 107377636557,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107377636557),
//--TRIMMABLE-BOUNDARY-START(30068225229),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55838029005,
        "f": 50331649
      },
      "n": "CurrencyUnit",
      "d": 3454157,
      "h": 30068225229,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30068225229),
//--TRIMMABLE-BOUNDARY-START(111672603853),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787701965,
        "f": 50331649
      },
      "n": "Title",
      "d": 3454157,
      "h": 111672603853,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111672603853),
//--TRIMMABLE-BOUNDARY-START(34363192525),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427963597,
        "f": 50331649
      },
      "n": "Description",
      "d": 3454157,
      "h": 34363192525,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34363192525),
//--TRIMMABLE-BOUNDARY-START(103082669261),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607832781,
        "f": 50331649
      },
      "n": "Icon",
      "d": 3454157,
      "h": 103082669261,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103082669261),
//--TRIMMABLE-BOUNDARY-START(17183323341),
    {
      "p": $.$$.SCG.IEnumerable$$($.$OJJQ.LCFCW.WalletTokenDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248094413,
        "f": 50331649
      },
      "n": "CoinDescriptors",
      "d": 3454157,
      "h": 17183323341,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183323341),
//--TRIMMABLE-BOUNDARY-START(38658159821),
    {
      "p": 2667725,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017898189,
        "f": 50331649
      },
      "n": "Features",
      "d": 3454157,
      "h": 38658159821,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38658159821)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888356045),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceName",
          "p": 1310721
        }
      ],
      "n": "CanPayForService",
      "d": 3454157,
      "h": 12888356045,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888356045),
//--TRIMMABLE-BOUNDARY-START(25773257933),
    {
      "r": 27822422,
      "p": [
        {
          "n": "input",
          "p": 3192013
        },
        {
          "n": "param",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "Convert",
      "o": "@$1",
      "d": 3454157,
      "h": 25773257933,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25773257933),
//--TRIMMABLE-BOUNDARY-START(21478290637),
    {
      "r": 3192013,
      "p": [
        {
          "n": "input",
          "p": 27822422
        },
        {
          "n": "param",
          "p": 131073,
          "f": 65
        }
      ],
      "n": "Convert",
      "d": 3454157,
      "h": 21478290637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478290637)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593388749),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3454157,
      "h": 8593388749,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593388749)
  ],
  "h": 3454157
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$OJJQ.LCFCW.IWalletIssuer, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed, $.$fPer.LCFCD.IDataConverter$$$($.$OJJQ.LCFCW.WalletToken, $.$fPer.LCFCDM.Money), $.$fPer.LCFCD.IDataConverter$$$($.$fPer.LCFCDM.Money, $.$OJJQ.LCFCW.WalletToken) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Wallet.Common.Services.DefaultWalletIssuer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Wallet${separator}Common${separator}Services${separator}DefaultWalletIssuer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3454157)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.RPC"));
})();
//--TRIMMABLE-BOUNDARY-END(46285)
