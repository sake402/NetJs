
//--TRIMMABLE-BOUNDARY-START(22915)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mep, $mecga, $mec, $mecb, $mefa, $mef, $mefp, $mecf, $mecj, $mxdi, $meo, $sih, $hqRR, $AWhY, $fPer) {
    "use strict";
    let _;
    let $qOWkTd;
    let $iEisje;
    let $BpzEGf;
    let $rnqrwi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.Common.Web", 
    {
  "h": 22915,
  "f": "LivingThing.Core.Frameworks.Common.Web",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Web",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.Common.Web",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(219523)
        $asm.$cls(`$ljzt.LCFCWM.HashTagMarkdownOptions`, ($self) => class HashTagMarkdownOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38654925187)
            /*string?*/ HashTagLinkFormat = null;
            //--TRIMMABLE-BOUNDARY-END(38654925187)
            
            //--TRIMMABLE-BOUNDARY-START(17180088707)
            /*string?*/ AtTagLinkFormat = null;
            //--TRIMMABLE-BOUNDARY-END(17180088707)
            
            //--TRIMMABLE-BOUNDARY-START(12885121411)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885121411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885121411)
            
            //--TRIMMABLE-BOUNDARY-START(12885121411)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885121411)
            
            static $h = 219523;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654925187),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359957891,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834794371,
        "f": 83886081
      },
      "n": "HashTagLinkFormat",
      "d": 219523,
      "h": 38654925187,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654925187),
//--TRIMMABLE-BOUNDARY-START(17180088707),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770023299,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244859779,
        "f": 83886081
      },
      "n": "AtTagLinkFormat",
      "d": 219523,
      "h": 17180088707,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180088707)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885121411),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 219523,
      "h": 12885121411,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885121411)
  ],
  "h": 219523
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Web.Markdown.HashTagMarkdownOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Web${separator}Markdown${separator}HashTagMarkdownOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(219523)
        
        

        //--TRIMMABLE-BOUNDARY-START(350595)
        $asm.$cls(`$ljzt.LCFCWM.MarkdownProcessor`, ($self) => class MarkdownProcessor
        {
            //--TRIMMABLE-BOUNDARY-START(12885252483)
            /*Converter*/ static converter = null;
            //--TRIMMABLE-BOUNDARY-END(12885252483)
            
            //--TRIMMABLE-BOUNDARY-START(25770154371)
            /*MarkdownPipeline*/ static pipeline = null;
            //--TRIMMABLE-BOUNDARY-END(25770154371)
            
            //--TRIMMABLE-BOUNDARY-START(4295317891)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295317891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let config = (() =>
                {
                    //new $.$hqRR.R.Config()
                    const $t1 = $.$hqRR.R.Config;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    return $i1;
                })();
                $.$ljzt.LCFCWM.MarkdownProcessor.converter = new $.$hqRR.R.Converter().$ctor$3(config, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SR.Assembly), [ $.$ljzt.LCFCWM.MarkdownProcessor.$type.Assembly ], null, null));
                $.$ljzt.LCFCWM.MarkdownProcessor.pipeline = $.$iqft.M.MarkdownExtensions.UseYamlFrontMatter($.$iqft.M.MarkdownExtensions.UseMediaLinks($.$iqft.M.MarkdownExtensions.Use($.$ljzt.LCFCWM.CustomLiteralInlineMarkdownExtension, $.$iqft.M.MarkdownExtensions.UseAdvancedExtensions(new $.$iqft.M.MarkdownPipelineBuilder().$ctor$1()), new $.$ljzt.LCFCWM.CustomLiteralInlineMarkdownExtension().$ctor$1(null)), (() =>
                {
                    //new $.$iqft.MEM$1.MediaOptions()
                    const $t2 = $.$iqft.MEM$1.MediaOptions;
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.Width = "";
                    $i2.Height = "";
                    return $i2;
                })())).Build();
            }
            //--TRIMMABLE-BOUNDARY-END(4295317891)
            
            //--TRIMMABLE-BOUNDARY-START(21475187075)
            /*HashTagMarkdownOptions?*/ static hashTagMarkdownOptions = null;
            //--TRIMMABLE-BOUNDARY-END(21475187075)
            
            //--TRIMMABLE-BOUNDARY-START(30065121667)
            static /*string? */ ToHtml(/*string?*/ markDown, /*IServiceProvider?*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065121667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (markDown === null)
                {
                    return null;
                }
                /*var*/ let context = new $.$iqft.M.MarkdownParserContext().$ctor$1();
                /*System.IServiceProvider?*/ let __ca1__;
                /*var*/ let hastTagOptions = ((__ca1__ = serviceProvider) !== null ? $.$mxdi.MED.ServiceProviderServiceExtensions.GetService($.$meo.MEO.IOptions$$($.$ljzt.LCFCWM.HashTagMarkdownOptions), __ca1__) : null);
                if (hastTagOptions !== null)
                {
                    context.Properties.set_Item($.$ljzt.LCFCWM.HashTagMarkdownOptions.$type, hastTagOptions);
                    $.$ljzt.LCFCWM.MarkdownProcessor.hashTagMarkdownOptions = hastTagOptions.MEO$IOptions$LivingThing$Core$Frameworks$Common$Web$Markdown$HashTagMarkdownOptions$Value;
                }
                return $.$iqft.M.Markdown.ToHtml$2(markDown ?? "", $.$ljzt.LCFCWM.MarkdownProcessor.pipeline, context);
            }
            //--TRIMMABLE-BOUNDARY-END(30065121667)
            
            //--TRIMMABLE-BOUNDARY-START(34360088963)
            static /*string? */ ToText(/*string?*/ markDown, /*string?*/ componentStartIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360088963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (markDown === null)
                {
                    return null;
                }
                if (componentStartIdentifier !== null)
                {
                    /*var*/ let texts = $.$sl.SL.Enumerable.Where($.$ljzt.LCFCWM.MarkdownComponent, $.$ljzt.LCFCWM.MarkdownProcessor.ComponentExtract(markDown, componentStartIdentifier), new ($.$$.S.Func$$$($.$ljzt.LCFCWM.MarkdownComponent, $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.ComponentName === null;
                    }, $iEisje ??= {"r":262145,"p":[{"n":"t","p":285059}],"n":"","d":350595,"h":0,"f":17825794}));
                    markDown = $.$$.S.String.Join$5("\r\n", $.$sl.SL.Enumerable.Select$1($.$ljzt.LCFCWM.MarkdownComponent, $.$$.S.String, texts, new ($.$$.S.Func$$$($.$ljzt.LCFCWM.MarkdownComponent, $.$$.S.String))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.Content;
                    }, $BpzEGf ??= {"r":1310721,"p":[{"n":"t","p":285059}],"n":"","d":350595,"h":0,"f":17825794})));
                }
                /*var*/ let html = $.$iqft.M.Markdown.ToHtml$2(markDown ?? "", $.$ljzt.LCFCWM.MarkdownProcessor.pipeline, null);
                /*var*/ let htmlDoc = new $.$DcMY.H.HtmlDocument().$ctor$1();
                htmlDoc.LoadHtml(html);
                /*string*/ let __ca2__;
                return _ = ((__ca2__ = htmlDoc.DocumentNode.InnerText) !== null ? $.$$.S.String.Trim.call(__ca2__) : null);
            }
            //--TRIMMABLE-BOUNDARY-END(34360088963)
            
            //--TRIMMABLE-BOUNDARY-START(17180219779)
            static /*string? */ FromHtml(/*string?*/ html, /*bool*/ respectMultipleBr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180219779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (html === null)
                {
                    return null;
                }
                html = $.$$.S.String.Replace$3.call(html, "<!--!-->", "") ?? "";
                /*string*/ let brPlaceHolder = "@@@@@@%%%%%";
                if (respectMultipleBr)
                {
                    html = $.$$.S.String.Replace$3.call(html, "<br>", brPlaceHolder);
                }
                /*var*/ let markdown = $.$ljzt.LCFCWM.MarkdownProcessor.converter.Convert(html);
                if (respectMultipleBr)
                {
                    markdown = $.$$.S.String.Replace$3.call(markdown, brPlaceHolder, "\r\n\r\n");
                }
                return $.$swh.SW.HttpUtility.HtmlDecode$1(markdown);
            }
            //--TRIMMABLE-BOUNDARY-END(17180219779)
            
            //--TRIMMABLE-BOUNDARY-START(8590285187)
            static /*IEnumerable<MarkdownComponent> */ ComponentExtract(/*string?*/ markDown, /*string*/ componentStartIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590285187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (markDown === null)
                {
                    return $.$sl.SL.Enumerable.Empty($.$ljzt.LCFCWM.MarkdownComponent);
                }
                markDown = $.$fPer.LCFCS$6.YamlFrontMatter.RemoveMetadatas(markDown);
                /*var*/ let components = new ($.$$.SCG.List$$($.$ljzt.LCFCWM.MarkdownComponent))().$ctor$1();
                /*var*/ let splitted = $.$fPer.LCFCS$6.StringExtension.SplitBy$5(markDown, $.$$.S.String.op_Implicit(componentStartIdentifier));
                /*int*/ let index = 0;
                let $en3 = splitted.GetEnumerator();
                while ($en3.MoveNext())
                {
                    let entry = $en3.Current;
                    {
                        if ($.$$.S.MemoryExtensions.Trim$4(entry.Token).Length > 0)
                        {
                            if (index !== 0 && !$.$$.S.Char.IsWhiteSpace$1(entry.Token._reference.GetAt(0)))
                            {
                                /*int*/ let start = 0;
                                /*int*/ let end = 0;
                                while(entry.Token._reference.GetAt(end) !== /*(*/ 40 && !$.$$.S.Char.IsWhiteSpace$1(entry.Token._reference.GetAt(end)) && end < entry.Token.Length)
                                {
                                    end++;
                                }
                                if (end > start)
                                {
                                    /*var*/ let componentName = entry.Token.Slice(start, ((end - start) | 0));
                                    /*var*/ let parameters = new ($.$$.SCG.Dictionary$$$($.$$.S.ReadOnlyMemory$$($.$$.S.Char), $.$$.S.ReadOnlyMemory$$($.$$.S.Char)))().$ctor$1();
                                    /*int*/ let parameterIndex = 0;
                                    /*ReadOnlySpan<char>*/ let content;
                                    if (entry.Token._reference.GetAt(end) === /*(*/ 40)
                                    {
                                        start = ((end + 1) | 0);
                                        end = start;
                                        /*int*/ let startParameter = start;
                                        while(entry.Token._reference.GetAt(end) !== /*)*/ 41 && end < entry.Token.Length)
                                        {
                                            if (entry.Token._reference.GetAt(end) === /*,*/ 44 || entry.Token._reference.GetAt(((end + 1) | 0)) === /*)*/ 41)
                                            {
                                                /*var*/ let kv = entry.Token.Slice(startParameter, ((((end + (entry.Token._reference.GetAt(end) === /*,*/ 44 ? 0 : 1)) | 0) - startParameter) | 0));
                                                /*int*/ let i = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, kv, /*=*/ 61);
                                                if (i !== -1)
                                                {
                                                    /*var*/ let key = kv.Slice(0, i);
                                                    /*var*/ let value = kv.Slice(((i + 1) | 0), ((((kv.Length - i) | 0) - 1) | 0));
                                                    /*var*/ let parameterValue = $.$$.S.MemoryExtensions.AsMemory$4($.$$.S.MemoryExtensions.Trim$4(value).ToString());
                                                    parameters.set_Item($.$$.S.MemoryExtensions.AsMemory$4($.$$.S.MemoryExtensions.Trim$4(key).ToString()), parameterValue);
                                                    parameters.set_Item($.$$.S.MemoryExtensions.AsMemory$4($.$$.S.Int32.ToString.call(parameterIndex)), parameterValue);
                                                }
                                                else 
                                                {
                                                    parameters.set_Item($.$$.S.MemoryExtensions.AsMemory$4($.$$.S.Int32.ToString.call(parameterIndex)), $.$$.S.MemoryExtensions.AsMemory$4($.$$.S.MemoryExtensions.Trim$4(kv).ToString()));
                                                }
                                                parameterIndex++;
                                                startParameter = ((end + 1) | 0);
                                            }
                                            end++;
                                        }
                                        start = ((end + 1) | 0);
                                        content = entry.Token.Slice(start, ((entry.Token.Length - start) | 0));
                                    }
                                    else 
                                    {
                                        content = entry.Token.Slice(end, ((entry.Token.Length - end) | 0));
                                    }
                                    components.Add((() =>
                                    {
                                        //new $.$ljzt.LCFCWM.MarkdownComponent()
                                        const $t4 = $.$ljzt.LCFCWM.MarkdownComponent;
                                        const $i4 = new $t4();
                                        $i4.$ctor$2();
                                        $i4.ComponentName = componentName.ToString();
                                        $i4.Parameters = parameters;
                                        $i4.Content = $.$$.S.MemoryExtensions.Trim$4(content).ToString();
                                        return $i4;
                                    })());
                                }
                            }
                            else 
                            {
                                components.Add((() =>
                                {
                                    //new $.$ljzt.LCFCWM.MarkdownComponent()
                                    const $t5 = $.$ljzt.LCFCWM.MarkdownComponent;
                                    const $i5 = new $t5();
                                    $i5.$ctor$2();
                                    $i5.Content = $.$$.S.MemoryExtensions.Trim$4(entry.Token).ToString();
                                    return $i5;
                                })());
                            }
                        }
                        index++;
                    }
                }
                return components;
            }
            //--TRIMMABLE-BOUNDARY-END(8590285187)
            
            static $h = 350595;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065121667),
    {
      "r": 1310721,
      "p": [
        {
          "n": "markDown",
          "p": 1310721
        },
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "ToHtml",
      "d": 350595,
      "h": 30065121667,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065121667),
//--TRIMMABLE-BOUNDARY-START(34360088963),
    {
      "r": 1310721,
      "p": [
        {
          "n": "markDown",
          "p": 1310721
        },
        {
          "n": "componentStartIdentifier",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "ToText",
      "d": 350595,
      "h": 34360088963,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360088963),
//--TRIMMABLE-BOUNDARY-START(17180219779),
    {
      "r": 1310721,
      "p": [
        {
          "n": "html",
          "p": 1310721
        },
        {
          "n": "respectMultipleBr",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "FromHtml",
      "d": 350595,
      "h": 17180219779,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180219779),
//--TRIMMABLE-BOUNDARY-START(8590285187),
    {
      "r": $.$$.SCG.IEnumerable$$($.$ljzt.LCFCWM.MarkdownComponent).$h,
      "p": [
        {
          "n": "markDown",
          "p": 1310721
        },
        {
          "n": "componentStartIdentifier",
          "p": 1310721
        }
      ],
      "n": "ComponentExtract",
      "d": 350595,
      "h": 8590285187,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590285187)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885252483),
    {
      "t": 2162085,
      "n": "converter",
      "d": 350595,
      "h": 12885252483,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885252483),
//--TRIMMABLE-BOUNDARY-START(25770154371),
    {
      "t": 11037862,
      "n": "pipeline",
      "d": 350595,
      "h": 25770154371,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770154371),
//--TRIMMABLE-BOUNDARY-START(21475187075),
    {
      "t": 219523,
      "n": "hashTagMarkdownOptions",
      "d": 350595,
      "h": 21475187075,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475187075)
  ],
  "h": 350595
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Web.Markdown.MarkdownProcessor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Web${separator}Markdown${separator}MarkdownProcessor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(350595)
        
        

        //--TRIMMABLE-BOUNDARY-START(481667)
        $asm.$cls(`$ljzt.LCFCW.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590416259)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590416259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ljzt.LCFCW.ServiceRegistrar.RegisterGenerated(services, configuration, $.$clone(options));
            }
            //--TRIMMABLE-BOUNDARY-END(8590416259)
            
            //--TRIMMABLE-BOUNDARY-START(12885383555)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885383555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885383555)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ljzt.LCFCW.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295448963)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295448963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295448963)
            
            //--TRIMMABLE-BOUNDARY-START(4295448963)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295448963)
            
            static $h = 481667;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590416259),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 481667,
      "h": 8590416259,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590416259),
//--TRIMMABLE-BOUNDARY-START(12885383555),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "RegisterGenerated",
      "d": 481667,
      "h": 12885383555,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885383555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295448963),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 481667,
      "h": 4295448963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295448963)
  ],
  "h": 481667
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Web.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Web${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(481667)
        
        

        //--TRIMMABLE-BOUNDARY-START(416131)
        $asm.$cls(`$ljzt.LCFCWM.YouTubeIframeReplacer`, ($self) => class YouTubeIframeReplacer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590350723)
            /*void */ Read(/*IElement*/ element, /*ReaderContext*/ ctx)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590350723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let src = element.AD$IElement$GetAttribute$1("src") ?? $.$$.S.String.Empty;
                if ($.$$.S.String.Contains$2.call(src, "://youtube.com", 3/*StringComparison.InvariantCultureIgnoreCase*/))
                {
                    /*var*/ let videoId = $.$sl.SL.Enumerable.LastOrDefault$3($.$$.S.String, $.$$.S.String.Split$5.call(src, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*/*/ 47, /*\\*/ 92], [-1], null))) ?? $.$$.S.String.Empty;
                    /*var*/ let markdown = `![youtube.com](https://://youtube.com/watch?v=${$.$strNN(videoId)})`;
                    ctx.Emit$1(new $.$hqRR.RD.MdText().$ctor$3(markdown));
                }
                else 
                {
                    ctx.ReadChildren(element);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590350723)
            
            //--TRIMMABLE-BOUNDARY-START(4301979045)
            //Generated interface implemetation for ReverseMarkdown.Readers.IMdReader.Read(AngleSharp.Dom.IElement, ReverseMarkdown.Readers.ReaderContext)
            RR$IMdReader$Read()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301979045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Read(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4301979045)
            
            //--TRIMMABLE-BOUNDARY-START(4295383427)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295383427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295383427)
            
            //--TRIMMABLE-BOUNDARY-START(4295383427)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295383427)
            
            static $h = 416131;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590350723),
    {
      "r": 65537,
      "p": [
        {
          "n": "element",
          "p": 15900455
        },
        {
          "n": "ctx",
          "p": 7601573
        }
      ],
      "n": "Read",
      "d": 416131,
      "h": 8590350723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590350723)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295383427),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 416131,
      "h": 4295383427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295383427)
  ],
  "h": 416131,
  "a": [
    {
      "t": 7339429,
      "c": 8597274021,
      "a": [
        {
          "v": [
            "iframe"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hqRR.RR.IMdReader ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Web.Markdown.YouTubeIframeReplacer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Web${separator}Markdown${separator}YouTubeIframeReplacer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(416131)
        
        

        //--TRIMMABLE-BOUNDARY-START(153987)
        $asm.$cls(`$ljzt.LCFCWM.CustomLiteralInlineMarkdownExtension`, ($self) => class CustomLiteralInlineMarkdownExtension extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590088579)
            /*HashTagMarkdownOptions?*/ options = null;
            //--TRIMMABLE-BOUNDARY-END(8590088579)
            
            //--TRIMMABLE-BOUNDARY-START(4295121283)
            $ctor$1(/*HashTagMarkdownOptions?*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295121283);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.options = options;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295121283)
            
            //--TRIMMABLE-BOUNDARY-START(17180023171)
            /*void */ Setup$1(/*MarkdownPipelineBuilder*/ pipeline)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180023171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17180023171)
            
            //--TRIMMABLE-BOUNDARY-START(12885055875)
            /*void */ Setup(/*MarkdownPipeline*/ pipeline, /*IMarkdownRenderer*/ renderer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885055875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let htmlRenderer = $.$as(renderer, $.$iqft.MR.HtmlRenderer);
                if (htmlRenderer !== null)
                {
                    /*var*/ let literalRenderer = htmlRenderer.ObjectRenderers.FindExact($.$iqft.MRHI.LiteralInlineRenderer);
                    if (literalRenderer !== null)
                    {
                        literalRenderer.TryWriters.Remove(new ($.$iqft.MR.MarkdownObjectRenderer$$$($.$iqft.MR.HtmlRenderer, $.$iqft.MSI.LiteralInline).TryWriteDelegate)().$ctor(this, this.TryConvert));
                        literalRenderer.TryWriters.Add(new ($.$iqft.MR.MarkdownObjectRenderer$$$($.$iqft.MR.HtmlRenderer, $.$iqft.MSI.LiteralInline).TryWriteDelegate)().$ctor(this, this.TryConvert));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885055875)
            
            //--TRIMMABLE-BOUNDARY-START(21474990467)
            /*List<LiteralInline>?*/ skipNext = null;
            //--TRIMMABLE-BOUNDARY-END(21474990467)
            
            //--TRIMMABLE-BOUNDARY-START(25769957763)
            /*bool */ TryConvert(/*HtmlRenderer*/ renderer, /*LiteralInline*/ literalInline)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769957763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.skipNext !== null && this.skipNext.Contains(literalInline))
                {
                    return true;
                }
                this.skipNext = null;
                let next;
                if ($.$is(literalInline.NextSibling, $.$iqft.MSI.LiteralInline, { set $v($v){ next = $v; } }) && next.Content.CurrentChar === /*_*/ 95)
                {
                    /*List<LiteralInline>*/ let toMerge = new ($.$$.SCG.List$$($.$iqft.MSI.LiteralInline))().$ctor$1();
                    toMerge.Add(literalInline);
                    toMerge.Add(next);
                    let mnext;
                    while($.$is(next.NextSibling, $.$iqft.MSI.LiteralInline, { set $v($v){ mnext = $v; } }) && mnext.Content.CurrentChar === /*_*/ 95)
                    {
                        toMerge.Add(mnext);
                        next = mnext;
                    }
                    literalInline = new $.$iqft.MSI.LiteralInline().$ctor$7($.$$.S.String.Join$5("", $.$sl.SL.Enumerable.Select$1($.$iqft.MSI.LiteralInline, $.$$.S.String, toMerge, new ($.$$.S.Func$$$($.$iqft.MSI.LiteralInline, $.$$.S.String))().$ctor(this,  (/*t*/ t) =>
                    {
                        return t.Content.ToString();
                    }, $rnqrwi ??= {"r":1310721,"p":[{"n":"t","p":22375590}],"n":"","d":153987,"h":0,"f":17825794}))));
                    this.skipNext = toMerge;
                }
                /*bool*/ let isHashTagStarted = false;
                /*bool*/ let isHttpStarted = false;
                /*int*/ let httpSequence = 0;
                /*bool*/ let isHttps = false;
                /*char[]*/ let bufferedChars = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), null, [200], null);
                /*int*/ let bufferedChars_i = 0;
                /*char*/ let lastChar = /*\u0000*/ 0;
                /*void*/  function FlushBuffered()
                {
                    if (bufferedChars_i > 0)
                    {
                        for(/*int*/ let i = 0; i < bufferedChars_i; i++)
                        {
                            renderer.Write$4($.$$.System.Array.$ReadT1.call(bufferedChars, i));
                        }
                        bufferedChars_i = 0;
                    }
                }
                while(!literalInline.Content.IsEmpty)
                {
                    /*bool*/ let isStartHashTag = !isHashTagStarted && (lastChar === /*\u0000*/ 0 || lastChar === /* */ 32) && (literalInline.Content.CurrentChar === /*#*/ 35 || literalInline.Content.CurrentChar === /*@*/ 64) && !$.$$.S.Char.IsWhiteSpace$1(literalInline.Content.PeekChar());
                    if (isStartHashTag)
                    {
                        isHashTagStarted = true;
                        /*var*/ let href = "#";
                        /*string*/ let $class = literalInline.Content.CurrentChar === /*#*/ 35 ? "hashtag" : "attag";
                        /*var*/ let _options = this.options ?? $.$ljzt.LCFCWM.MarkdownProcessor.hashTagMarkdownOptions;
                        if ((literalInline.Content.CurrentChar === /*#*/ 35 && (_options?.HashTagLinkFormat ?? null) !== null) || (literalInline.Content.CurrentChar === /*@*/ 64 && (_options?.AtTagLinkFormat ?? null) !== null))
                        {
                            /*string*/ let tag = "";
                            /*int*/ let i = 1;
                            /*char*/ let c;
                            while((c = literalInline.Content.PeekChar$1(i)) !== /* */ 32 && i < literalInline.Content.Length)
                            {
                                tag = $.$$.S.String.op_Addition(tag, $.$box(c, $.$$.S.Char));
                                i++;
                            }
                            href = $.$$.S.String.Format$9(literalInline.Content.CurrentChar === /*#*/ 35 ? _options.HashTagLinkFormat : _options.AtTagLinkFormat, tag);
                        }
                        renderer.Write$7(`<a class=\"${$.$strNN($class)}\" href=\"${$.$strNN(href)}\">${$.$strNN($.$$.S.Char.ToString.call(literalInline.Content.CurrentChar))}`);
                    }
                    else if (isHashTagStarted && $.$$.S.Char.IsWhiteSpace$1(literalInline.Content.CurrentChar))
                    {
                        renderer.Write$7(`</a> `);
                        isHashTagStarted = false;
                    }
                    else 
                    {
                        /*int*/ let initialBuffer_i = bufferedChars_i;
                        if (!isHttpStarted)
                        {
                            //switch (httpSequence)
                            {
                                $switchJumpStart1: 
                                //case 0:
                                if (httpSequence == 0)
                                {
                                    if ((lastChar === /* */ 32 || lastChar === /*\r*/ 13 || lastChar === /*\n*/ 10 || lastChar === /*\u0000*/ 0) && literalInline.Content.CurrentChar === /*h*/ 104)
                                    {
                                        httpSequence++;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else 
                                    {
                                        httpSequence = 0;
                                    }
                                }
                                //case 1:
                                else if (httpSequence == 1)
                                {
                                    if (literalInline.Content.CurrentChar === /*t*/ 116)
                                    {
                                        httpSequence++;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else 
                                    {
                                        httpSequence = 0;
                                    }
                                }
                                //case 2:
                                else if (httpSequence == 2)
                                {
                                    if (literalInline.Content.CurrentChar === /*t*/ 116)
                                    {
                                        httpSequence++;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else 
                                    {
                                        httpSequence = 0;
                                    }
                                }
                                //case 3:
                                else if (httpSequence == 3)
                                {
                                    if (literalInline.Content.CurrentChar === /*p*/ 112)
                                    {
                                        httpSequence++;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else 
                                    {
                                        httpSequence = 0;
                                    }
                                }
                                //case 4:
                                else if (httpSequence == 4)
                                {
                                    if (literalInline.Content.CurrentChar === /*s*/ 115)
                                    {
                                        httpSequence++;
                                        isHttps = true;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else if (literalInline.Content.CurrentChar === /*:*/ 58)
                                    {
                                        httpSequence++;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else 
                                    {
                                        httpSequence = 0;
                                    }
                                }
                                //case 5 when isHttps:
                                else if (httpSequence === 5 && isHttps)
                                {
                                    if (literalInline.Content.CurrentChar === /*:*/ 58)
                                    {
                                        httpSequence++;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else 
                                    {
                                        httpSequence = 0;
                                    }
                                }
                                //case 6 when isHttps:
                                else if (httpSequence === 6 && isHttps)
                                {
                                    if (literalInline.Content.CurrentChar === /*/*/ 47)
                                    {
                                        httpSequence++;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else 
                                    {
                                        httpSequence = 0;
                                    }
                                }
                                //case 7 when isHttps:
                                else if (httpSequence === 7 && isHttps)
                                {
                                    if (literalInline.Content.CurrentChar === /*/*/ 47)
                                    {
                                        httpSequence++;
                                        isHttpStarted = true;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else 
                                    {
                                        httpSequence = 0;
                                    }
                                }
                                //case 5 when !isHttps:
                                else if (httpSequence === 5 && !isHttps)
                                {
                                    if (literalInline.Content.CurrentChar === /*/*/ 47)
                                    {
                                        httpSequence++;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else 
                                    {
                                        httpSequence = 0;
                                    }
                                }
                                //case 6 when !isHttps:
                                else if (httpSequence === 6 && !isHttps)
                                {
                                    if (literalInline.Content.CurrentChar === /*/*/ 47)
                                    {
                                        httpSequence++;
                                        isHttpStarted = true;
                                        $.$$.System.Array.$WriteT1.call(bufferedChars, literalInline.Content.CurrentChar, bufferedChars_i++);
                                    }
                                    else 
                                    {
                                        httpSequence = 0;
                                    }
                                }
                                //default
                                else
                                {
                                    isHttpStarted = false;
                                    httpSequence = 0;
                                }
                            }
                        }
                        if (initialBuffer_i !== bufferedChars_i && isHttpStarted)
                        {
                            /*var*/ let line = literalInline.Content.ToString();
                            /*bool*/ let isIFrame = $.$$.S.String.StartsWith$3.call(line, "/youtube.com") || $.$$.S.String.StartsWith$3.call(line, "/www.youtube.com") || $.$$.S.String.StartsWith$3.call(line, "/youtu.be") || $.$$.S.String.StartsWith$3.call(line, "/www.youtu.be");
                            /*string?*/ let youtubeCode = null;
                            if (isIFrame)
                            {
                                /*var*/ let uri = new $.$spu.S.Uri().$ctor$5("https:/" + $.$strNN(line));
                                /*var*/ let queries = $.$swh.SW.HttpUtility.ParseQueryString$1(uri.Query);
                                if ($.$$.S.MemoryExtensions.Contains$2($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(queries.AllKeys), "v"))
                                {
                                    youtubeCode = queries.get_Item$2("v");
                                }
                                else if ($.$$.S.String.StartsWith$3.call(line, "/youtu.be/"))
                                {
                                    youtubeCode = uri.AbsolutePath;
                                }
                                if (youtubeCode !== null)
                                {
                                    renderer.Write$7(`<iframe class=\"wf bd-0 d-block\" src=\"https://youtube.com/embed/${$.$strNN(youtubeCode)}\"></iframe>`);
                                }
                            }
                            renderer.Write$7(`<a class=\"literallink\" target=\"_blank\" href=\"http`);
                            if (isHttps)
                            {
                                renderer.Write$7(`s`);
                            }
                            renderer.Write$7(`://`);
                            /*int*/ let link_i = 0;
                            /*char[]*/ let link = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), null, [200], null);
                            literalInline.Content.NextChar();
                            while(!literalInline.Content.IsEmpty)
                            {
                                $.$$.System.Array.$WriteT1.call(link, literalInline.Content.CurrentChar, link_i++);
                                renderer.Write$4(literalInline.Content.CurrentChar);
                                lastChar = literalInline.Content.CurrentChar;
                                literalInline.Content.NextChar();
                                if ($.$$.S.Char.IsWhiteSpace$1(literalInline.Content.CurrentChar))
                                {
                                    break;
                                }
                            }
                            renderer.Write$7(`\">`);
                            renderer.Write$7(`http`);
                            if (isHttps)
                            {
                                renderer.Write$7(`s`);
                            }
                            renderer.Write$7(`://`);
                            for(/*int*/ let i = 0; i < link_i; i++)
                            {
                                renderer.Write$4($.$$.System.Array.$ReadT1.call(link, i));
                            }
                            renderer.Write$7(`</a>`);
                            bufferedChars_i = 0;
                            initialBuffer_i = 0;
                        }
                        if (initialBuffer_i === bufferedChars_i)
                        {
                            FlushBuffered.call(this);
                            if (literalInline.Content.CurrentChar !== /*\u0000*/ 0)
                            {
                                renderer.Write$4(literalInline.Content.CurrentChar);
                            }
                        }
                    }
                    lastChar = literalInline.Content.CurrentChar;
                    literalInline.Content.NextChar();
                }
                FlushBuffered.call(this);
                if (isHashTagStarted)
                {
                    renderer.Write$7(`</a>`);
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(25769957763)
            
            //--TRIMMABLE-BOUNDARY-START(8600710310)
            //Generated interface implemetation for Markdig.IMarkdownExtension.Setup(Markdig.MarkdownPipelineBuilder)
            M$IMarkdownExtension$Setup$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8600710310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Setup$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8600710310)
            
            //--TRIMMABLE-BOUNDARY-START(4305743014)
            //Generated interface implemetation for Markdig.IMarkdownExtension.Setup(Markdig.MarkdownPipeline, Markdig.Renderers.IMarkdownRenderer)
            M$IMarkdownExtension$Setup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4305743014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Setup(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4305743014)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21474990467)
                this.skipNext = null;
                //--TRIMMABLE-BOUNDARY-END(21474990467)
                
            }
            static $h = 153987;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180023171),
    {
      "r": 65537,
      "p": [
        {
          "n": "pipeline",
          "p": 11234470
        }
      ],
      "n": "Setup",
      "o": "@$1",
      "d": 153987,
      "h": 17180023171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180023171),
//--TRIMMABLE-BOUNDARY-START(12885055875),
    {
      "r": 65537,
      "p": [
        {
          "n": "pipeline",
          "p": 11037862
        },
        {
          "n": "renderer",
          "p": 16280742
        }
      ],
      "n": "Setup",
      "d": 153987,
      "h": 12885055875,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885055875),
//--TRIMMABLE-BOUNDARY-START(25769957763),
    {
      "r": 262145,
      "p": [
        {
          "n": "renderer",
          "p": 16149670
        },
        {
          "n": "literalInline",
          "p": 22375590
        }
      ],
      "n": "TryConvert",
      "d": 153987,
      "h": 25769957763,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25769957763)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590088579),
    {
      "t": 219523,
      "n": "options",
      "d": 153987,
      "h": 8590088579,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590088579),
//--TRIMMABLE-BOUNDARY-START(21474990467),
    {
      "t": $.$$.SCG.List$$($.$iqft.MSI.LiteralInline).$h,
      "n": "skipNext",
      "d": 153987,
      "h": 21474990467,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21474990467)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295121283),
    {
      "p": [
        {
          "n": "options",
          "p": 219523,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 153987,
      "h": 4295121283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295121283)
  ],
  "h": 153987
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$iqft.M.IMarkdownExtension ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Web.Markdown.CustomLiteralInlineMarkdownExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Web${separator}Markdown${separator}CustomLiteralInlineMarkdownExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(153987)
        
        

        //--TRIMMABLE-BOUNDARY-START(88451)
        $asm.$cls(`$ljzt.LCFCWM.AudioVideoReplacer`, ($self) => class AudioVideoReplacer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295055747)
            /*string*/ static _remoteHost = null;
            //--TRIMMABLE-BOUNDARY-END(4295055747)
            
            //--TRIMMABLE-BOUNDARY-START(34359826819)
            static /*string */ get RemoteHost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769892227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ljzt.LCFCWM.AudioVideoReplacer._remoteHost;
            }
            static /*string */ set RemoteHost(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949761411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.String.IsNullOrEmpty(value) && !$.$$.S.String.StartsWith$2.call(value, "http", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    $.$ljzt.LCFCWM.AudioVideoReplacer._remoteHost = "https://" + $.$strNN(value);
                }
                else 
                {
                    $.$ljzt.LCFCWM.AudioVideoReplacer._remoteHost = value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359826819)
            
            //--TRIMMABLE-BOUNDARY-START(12884990339)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884990339);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884990339)
            
            //--TRIMMABLE-BOUNDARY-START(17179957635)
            $ctor$2(/*string*/ remoteHost)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17179957635);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$ljzt.LCFCWM.AudioVideoReplacer.RemoteHost = remoteHost;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17179957635)
            
            //--TRIMMABLE-BOUNDARY-START(30064859523)
            /*void */ Read(/*IElement*/ element, /*ReaderContext*/ ctx)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064859523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sourceElements = element.AD$IParentNode$QuerySelectorAll("source");
                /*var*/ let resolvedSources = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                let $en1 = sourceElements.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let source = $en1.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let src = source.AD$IElement$GetAttribute$1("src") ?? $.$$.S.String.Empty;
                        if (!$.$$.S.String.IsNullOrEmpty(src))
                        {
                            if (!$.$$.S.String.StartsWith$2.call(src, "http", 5/*StringComparison.OrdinalIgnoreCase*/) && !$.$$.S.String.IsNullOrEmpty($.$ljzt.LCFCWM.AudioVideoReplacer.RemoteHost))
                            {
                                src = $.$strNN($.$strNN($.$$.S.String.TrimEnd$3.call($.$ljzt.LCFCWM.AudioVideoReplacer.RemoteHost, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /*/*/ 47, /*\\*/ 92 ]))) + "/") + $.$strNN($.$$.S.String.TrimStart$3.call(src, $.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1([ /*/*/ 47, /*\\*/ 92 ])));
                            }
                            resolvedSources.Add(src);
                        }
                    }
                }
                if (resolvedSources.Count > 0)
                {
                    /*var*/ let markdownText = `![static](${$.$strNN($.$$.S.String.Join$5(" ", resolvedSources))})`;
                    ctx.Emit$1(new $.$hqRR.RD.MdText().$ctor$3(markdownText));
                }
                else 
                {
                    ctx.ReadChildren(element);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064859523)
            
            //--TRIMMABLE-BOUNDARY-START(4301979045)
            //Generated interface implemetation for ReverseMarkdown.Readers.IMdReader.Read(AngleSharp.Dom.IElement, ReverseMarkdown.Readers.ReaderContext)
            RR$IMdReader$Read()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301979045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Read(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4301979045)
            
            //--TRIMMABLE-BOUNDARY-START(12884990339)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12884990339)
            
            //--TRIMMABLE-BOUNDARY-START(8590023043)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590023043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295055747)
                    this._remoteHost = "dummy.url";
                    //--TRIMMABLE-BOUNDARY-END(4295055747)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590023043)
            
            static $h = 88451;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359826819),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769892227,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42949761411,
        "f": 83886113
      },
      "n": "RemoteHost",
      "d": 88451,
      "h": 34359826819,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34359826819)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064859523),
    {
      "r": 65537,
      "p": [
        {
          "n": "element",
          "p": 15900455
        },
        {
          "n": "ctx",
          "p": 7601573
        }
      ],
      "n": "Read",
      "d": 88451,
      "h": 30064859523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064859523)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295055747),
    {
      "t": 1310721,
      "n": "_remoteHost",
      "d": 88451,
      "h": 4295055747,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295055747)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884990339),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 88451,
      "h": 12884990339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884990339),
//--TRIMMABLE-BOUNDARY-START(17179957635),
    {
      "p": [
        {
          "n": "remoteHost",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 88451,
      "h": 17179957635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179957635)
  ],
  "h": 88451,
  "a": [
    {
      "t": 7339429,
      "c": 8597274021,
      "a": [
        {
          "v": [
            "audio",
            "video"
          ],
          "t": $.$typeArray($.$$.S.String).$h
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hqRR.RR.IMdReader ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Web.Markdown.AudioVideoReplacer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Web${separator}Markdown${separator}AudioVideoReplacer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(88451)
        
        

        //--TRIMMABLE-BOUNDARY-START(285059)
        $asm.$str(`$ljzt.LCFCWM.MarkdownComponent`, ($self) => class MarkdownComponent extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21475121539)
            /*string*/ ComponentName = null;
            //--TRIMMABLE-BOUNDARY-END(21475121539)
            
            //--TRIMMABLE-BOUNDARY-START(55834859907)
            /*Dictionary<ReadOnlyMemory<char>, ReadOnlyMemory<char>>*/ Parameters = null;
            //--TRIMMABLE-BOUNDARY-END(55834859907)
            
            //--TRIMMABLE-BOUNDARY-START(25770088835)
            /*string*/ Content = null;
            //--TRIMMABLE-BOUNDARY-END(25770088835)
            
            //--TRIMMABLE-BOUNDARY-START(85899630979)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899630979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ComponentName === null)
                {
                    return this.Content;
                }
                /*System.Collections.Generic.Dictionary<System.ReadOnlyMemory<char>, System.ReadOnlyMemory<char>>*/ let __ca1__;
                return `${$.$strNN(this.ComponentName)}:(${$.$strNN($.$$.S.String.Join$5(", ", ((__ca1__ = this.Parameters) !== null ? ($.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.ReadOnlyMemory$$($.$$.S.Char), $.$$.S.ReadOnlyMemory$$($.$$.S.Char)), $.$$.S.String, __ca1__, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.ReadOnlyMemory$$($.$$.S.Char), $.$$.S.ReadOnlyMemory$$($.$$.S.Char)), $.$$.S.String))().$ctor(this,  (/**/ p) =>
                {
                    return `${$.$strNN(p.Key.ToString())}=${$.$strNN(p.Value.ToString())}`;
                }, $qOWkTd ??= {"r":1310721,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.ReadOnlyMemory$$($.$$.S.Char), $.$$.S.ReadOnlyMemory$$($.$$.S.Char)).$h}],"n":"","d":285059,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.Empty($.$$.S.String)) : $.$sl.SL.Enumerable.Empty($.$$.S.String))))}) => ${$.$strNN(this.Content)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(85899630979)
            
            //--TRIMMABLE-BOUNDARY-START(17180154243)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180154243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180154243)
            
            //--TRIMMABLE-BOUNDARY-START(17180154243)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180154243)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ComponentName = this.ComponentName;
                copy.Parameters = this.Parameters;
                copy.Content = this.Content;
                return copy;
            }
            static $h = 285059;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475121539),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360023427,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424794499,
        "f": 83886081
      },
      "n": "ComponentName",
      "d": 285059,
      "h": 21475121539,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475121539),
//--TRIMMABLE-BOUNDARY-START(55834859907),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.ReadOnlyMemory$$($.$$.S.Char), $.$$.S.ReadOnlyMemory$$($.$$.S.Char)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539892611,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604663683,
        "f": 83886081
      },
      "n": "Parameters",
      "d": 285059,
      "h": 55834859907,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834859907),
//--TRIMMABLE-BOUNDARY-START(25770088835),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949958019,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014729091,
        "f": 83886081
      },
      "n": "Content",
      "d": 285059,
      "h": 25770088835,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770088835)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85899630979),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 285059,
      "h": 85899630979,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85899630979)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180154243),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 285059,
      "h": 17180154243,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180154243)
  ],
  "h": 285059
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.Common.Web.Markdown.MarkdownComponent`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}Common${separator}Web${separator}Markdown${separator}MarkdownComponent`; }
        });
        //--TRIMMABLE-BOUNDARY-END(285059)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(22915)
