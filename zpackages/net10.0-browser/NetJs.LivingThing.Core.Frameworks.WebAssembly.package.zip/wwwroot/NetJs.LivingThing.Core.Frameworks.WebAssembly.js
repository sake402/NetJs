
//--TRIMMABLE-BOUNDARY-START(34992)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $mexl, $mj, $mjw, $macwa, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $lmWW) {
    "use strict";
    let _;
    let $vJHhBj;
    let $VolJye;
    let $weAQUc;
    let $mWauRi;
    let $ZXqljf;
    let $QEUPVe;
    let $PfVRLj;
    let $DtAKIj;
    let $zvyFXd;
    let $eXYkUa;
    let $yHmMRg;
    let $uTFedf;
    let $QwWFni;
    let $TAkCad;
    let $ZEXYtb;
    let $KDIdzd;
    let $CzKjdl;
    let $UXfHMh;
    let $MDohKh;
    let $FWogfg;
    let $wDDgVh;
    let $eFVjJd;
    let $lHlZde;
    let $FJIEqf;
    let $JSNtCa;
    let $Cfkifk;
    let $TVGnGb;
    let $gAOfDf;
    let $jMwaHe;
    let $TYVOmg;
    let $PZIQKa;
    let $DrWnXd;
    let $Znqehf;
    let $CaJFGe;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Frameworks.WebAssembly", 
    {
  "h": 34992,
  "f": "LivingThing.Core.Frameworks.WebAssembly",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.WebAssembly",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Frameworks.WebAssembly",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(362672)
        $asm.$cls(`$TvJd.LCFWN.NativeInteropServiceBase<>`, (TInterface) => $asm.$gt(`$TvJd.LCFWN.NativeInteropServiceBase<>`, [TInterface], ($self) => class NativeInteropServiceBase$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55834937520)
            /*IJavaScriptRunner*/ javascript = null;
            //--TRIMMABLE-BOUNDARY-END(55834937520)
            
            //--TRIMMABLE-BOUNDARY-START(8590297264)
            $ctor$1(/*IJavaScriptRunner*/ javascript)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590297264);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.javascript = javascript;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590297264)
            
            //--TRIMMABLE-BOUNDARY-START(4295329968)
            /*int*/ static _requestId = 0;
            //--TRIMMABLE-BOUNDARY-END(4295329968)
            
            //--TRIMMABLE-BOUNDARY-START(51539970224)
            /*ValueTask<TResult> *//*async*/  CallNativePlatformInternal$1(TResult, /*RemoteProxyMethodInfo*/ parameter)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(TResult), TResult, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539970224);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.SI.Stream.$type === TResult.$type)
                    {
                        let $t1, $r1;
                        /*var*/ let bytes = ($t1 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.QueuePromise$1($.$typeArray($.$$.S.Byte), this.javascript, "callNative", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$clone(parameter), $.$box(true, $.$$.S.Boolean) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$cast($.$cast(new $.$$.SI.MemoryStream().$ctor$8(bytes), $.$$.S.Object), TResult));
                    }
                    /*var*/ let result = ($t2 = $.$hDPm.LCFCI.JavaScriptRunnerExtension.QueuePromise$1(TResult, this.javascript, "callNative", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$clone(parameter), $.$box(true, $.$$.S.Boolean) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, result);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51539970224)
            
            //--TRIMMABLE-BOUNDARY-START(47245002928)
            /*ValueTask */ CallNativePlatformInternal(/*RemoteProxyMethodInfo*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245002928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.javascript.LCFCI$IJavaScriptRunner$Queue$1("callNative", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$clone(parameter), $.$box(false, $.$$.S.Boolean) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(47245002928)
            
            //--TRIMMABLE-BOUNDARY-START(42950035632)
            /*ValueTask<TResult> */ CallNativePlatform$7(TResult, /*string?*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950035632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let requestId = $.$TvJd.LCFWN.NativeInteropServiceBase$$(TInterface)._requestId++;
                /*var*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uvJL.LCFCR.RemoteProxyMethodParameter), [], [-1], null);
                /*var*/ let methodInfo = (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                    const $t3 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                    const $i3 = new $t3();
                    $i3.$ctor$2();
                    $i3.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(TInterface.$type, methodName, parameters, $.$discardRef(), true);
                    $i3.Parameters = parameters;
                    $i3.RequestId = requestId;
                    return $i3;
                })();
                return this.CallNativePlatformInternal$1(TResult, $.$clone(methodInfo));
            }
            //--TRIMMABLE-BOUNDARY-END(42950035632)
            
            //--TRIMMABLE-BOUNDARY-START(34360101040)
            /*ValueTask<TResult> */ CallNativePlatform$5(T1, TResult, /*T1*/ parameter1, /*string?*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360101040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let requestId = $.$TvJd.LCFWN.NativeInteropServiceBase$$(TInterface)._requestId++;
                /*var*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uvJL.LCFCR.RemoteProxyMethodParameter), [new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T1.$type, $.$box(parameter1, T1))], null, null);
                /*var*/ let methodInfo = (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                    const $t4 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                    const $i4 = new $t4();
                    $i4.$ctor$2();
                    $i4.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(TInterface.$type, methodName, parameters, $.$discardRef(), true);
                    $i4.Parameters = parameters;
                    $i4.RequestId = requestId;
                    return $i4;
                })();
                return this.CallNativePlatformInternal$1(TResult, $.$clone(methodInfo));
            }
            //--TRIMMABLE-BOUNDARY-END(34360101040)
            
            //--TRIMMABLE-BOUNDARY-START(25770166448)
            /*ValueTask<TResult> */ CallNativePlatform$3(T1, T2, TResult, /*T1*/ parameter1, /*T2*/ parameter2, /*string?*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770166448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let requestId = $.$TvJd.LCFWN.NativeInteropServiceBase$$(TInterface)._requestId++;
                /*var*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uvJL.LCFCR.RemoteProxyMethodParameter), [new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T1.$type, $.$box(parameter1, T1)), new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T2.$type, $.$box(parameter2, T2))], null, null);
                /*var*/ let methodInfo = (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                    const $t5 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                    const $i5 = new $t5();
                    $i5.$ctor$2();
                    $i5.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(TInterface.$type, methodName, parameters, $.$discardRef(), true);
                    $i5.Parameters = parameters;
                    $i5.RequestId = requestId;
                    return $i5;
                })();
                return this.CallNativePlatformInternal$1(TResult, $.$clone(methodInfo));
            }
            //--TRIMMABLE-BOUNDARY-END(25770166448)
            
            //--TRIMMABLE-BOUNDARY-START(17180231856)
            /*ValueTask<TResult> */ CallNativePlatform$1(T1, T2, T3, TResult, /*T1*/ parameter1, /*T2*/ parameter2, /*T3*/ parameter3, /*string?*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180231856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let requestId = $.$TvJd.LCFWN.NativeInteropServiceBase$$(TInterface)._requestId++;
                /*var*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uvJL.LCFCR.RemoteProxyMethodParameter), [new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T1.$type, $.$box(parameter1, T1)), new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T2.$type, $.$box(parameter2, T2)), new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T3.$type, $.$box(parameter3, T3))], null, null);
                /*var*/ let methodInfo = (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                    const $t6 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                    const $i6 = new $t6();
                    $i6.$ctor$2();
                    $i6.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(TInterface.$type, methodName, parameters, $.$discardRef(), true);
                    $i6.Parameters = parameters;
                    $i6.RequestId = requestId;
                    return $i6;
                })();
                return this.CallNativePlatformInternal$1(TResult, $.$clone(methodInfo));
            }
            //--TRIMMABLE-BOUNDARY-END(17180231856)
            
            //--TRIMMABLE-BOUNDARY-START(12885264560)
            /*ValueTask */ CallNativePlatform(/*string?*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885264560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uvJL.LCFCR.RemoteProxyMethodParameter), [], [-1], null);
                /*var*/ let methodInfo = (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                    const $t7 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                    const $i7 = new $t7();
                    $i7.$ctor$2();
                    $i7.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(TInterface.$type, methodName, parameters, $.$discardRef(), true);
                    $i7.Parameters = parameters;
                    return $i7;
                })();
                return this.CallNativePlatformInternal($.$clone(methodInfo));
            }
            //--TRIMMABLE-BOUNDARY-END(12885264560)
            
            //--TRIMMABLE-BOUNDARY-START(38655068336)
            /*ValueTask */ CallNativePlatform$6(T1, /*T1*/ parameter1, /*string?*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655068336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uvJL.LCFCR.RemoteProxyMethodParameter), [new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T1.$type, $.$box(parameter1, T1))], null, null);
                /*var*/ let methodInfo = (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                    const $t8 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                    const $i8 = new $t8();
                    $i8.$ctor$2();
                    $i8.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(TInterface.$type, methodName, parameters, $.$discardRef(), true);
                    $i8.Parameters = parameters;
                    return $i8;
                })();
                return this.CallNativePlatformInternal($.$clone(methodInfo));
            }
            //--TRIMMABLE-BOUNDARY-END(38655068336)
            
            //--TRIMMABLE-BOUNDARY-START(30065133744)
            /*ValueTask */ CallNativePlatform$4(T1, T2, /*T1*/ parameter1, /*T2*/ parameter2, /*string?*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065133744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uvJL.LCFCR.RemoteProxyMethodParameter), [new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T1.$type, $.$box(parameter1, T1)), new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T2.$type, $.$box(parameter2, T2))], null, null);
                /*var*/ let methodInfo = (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                    const $t9 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                    const $i9 = new $t9();
                    $i9.$ctor$2();
                    $i9.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(TInterface.$type, methodName, parameters, $.$discardRef(), true);
                    $i9.Parameters = parameters;
                    return $i9;
                })();
                return this.CallNativePlatformInternal($.$clone(methodInfo));
            }
            //--TRIMMABLE-BOUNDARY-END(30065133744)
            
            //--TRIMMABLE-BOUNDARY-START(21475199152)
            /*ValueTask */ CallNativePlatform$2(T1, T2, T3, /*T1*/ parameter1, /*T2*/ parameter2, /*T3*/ parameter3, /*string?*/ methodName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475199152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$uvJL.LCFCR.RemoteProxyMethodParameter), [new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T1.$type, $.$box(parameter1, T1)), new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T2.$type, $.$box(parameter2, T2)), new $.$uvJL.LCFCR.RemoteProxyMethodParameter().$ctor$4(T3.$type, $.$box(parameter3, T3))], null, null);
                /*var*/ let methodInfo = (() =>
                {
                    //new $.$uvJL.LCFCR.RemoteProxyMethodInfo()
                    const $t10 = $.$uvJL.LCFCR.RemoteProxyMethodInfo;
                    const $i10 = new $t10();
                    $i10.$ctor$2();
                    $i10.Service = $.$uvJL.LCFCR.RemoteServiceExtension.GetRemoteServiceId$1(TInterface.$type, methodName, parameters, $.$discardRef(), true);
                    $i10.Parameters = parameters;
                    return $i10;
                })();
                return this.CallNativePlatformInternal($.$clone(methodInfo));
            }
            //--TRIMMABLE-BOUNDARY-END(21475199152)
            
            static $H = 362672;
            static $h = 362672;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539970224),
    {
      "r": (TResult) => $.$$.STT.ValueTask$$(TResult).$h,
      "p": [
        {
          "n": "parameter",
          "p": 1768403
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "CallNativePlatformInternal",
      "o": "@$1",
      "d": this.$h,
      "H": 51539970224,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(51539970224),
//--TRIMMABLE-BOUNDARY-START(47245002928),
    {
      "r": 181338113,
      "p": [
        {
          "n": "parameter",
          "p": 1768403
        }
      ],
      "n": "CallNativePlatformInternal",
      "d": this.$h,
      "H": 47245002928,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245002928),
//--TRIMMABLE-BOUNDARY-START(42950035632),
    {
      "r": (TResult) => $.$$.STT.ValueTask$$(TResult).$h,
      "p": [
        {
          "n": "methodName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "CallNativePlatform",
      "o": "@$7",
      "d": this.$h,
      "H": 42950035632,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(42950035632),
//--TRIMMABLE-BOUNDARY-START(34360101040),
    {
      "r": (T1, TResult) => $.$$.STT.ValueTask$$(TResult).$h,
      "p": [
        {
          "n": "parameter1",
          "p": (T1, TResult) => T1.$h
        },
        {
          "n": "methodName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "g": [
        "T1",
        "TResult"
      ],
      "n": "CallNativePlatform",
      "o": "@$5",
      "d": this.$h,
      "H": 34360101040,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(34360101040),
//--TRIMMABLE-BOUNDARY-START(25770166448),
    {
      "r": (T1, T2, TResult) => $.$$.STT.ValueTask$$(TResult).$h,
      "p": [
        {
          "n": "parameter1",
          "p": (T1, T2, TResult) => T1.$h
        },
        {
          "n": "parameter2",
          "p": (T1, T2, TResult) => T2.$h
        },
        {
          "n": "methodName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "g": [
        "T1",
        "T2",
        "TResult"
      ],
      "n": "CallNativePlatform",
      "o": "@$3",
      "d": this.$h,
      "H": 25770166448,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(25770166448),
//--TRIMMABLE-BOUNDARY-START(17180231856),
    {
      "r": (T1, T2, T3, TResult) => $.$$.STT.ValueTask$$(TResult).$h,
      "p": [
        {
          "n": "parameter1",
          "p": (T1, T2, T3, TResult) => T1.$h
        },
        {
          "n": "parameter2",
          "p": (T1, T2, T3, TResult) => T2.$h
        },
        {
          "n": "parameter3",
          "p": (T1, T2, T3, TResult) => T3.$h
        },
        {
          "n": "methodName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "TResult"
      ],
      "n": "CallNativePlatform",
      "o": "@$1",
      "d": this.$h,
      "H": 17180231856,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(17180231856),
//--TRIMMABLE-BOUNDARY-START(12885264560),
    {
      "r": 181338113,
      "p": [
        {
          "n": "methodName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "n": "CallNativePlatform",
      "d": this.$h,
      "H": 12885264560,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12885264560),
//--TRIMMABLE-BOUNDARY-START(38655068336),
    {
      "r": 181338113,
      "p": [
        {
          "n": "parameter1",
          "p": (T1) => T1.$h
        },
        {
          "n": "methodName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "g": [
        "T1"
      ],
      "n": "CallNativePlatform",
      "o": "@$6",
      "d": this.$h,
      "H": 38655068336,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(38655068336),
//--TRIMMABLE-BOUNDARY-START(30065133744),
    {
      "r": 181338113,
      "p": [
        {
          "n": "parameter1",
          "p": (T1, T2) => T1.$h
        },
        {
          "n": "parameter2",
          "p": (T1, T2) => T2.$h
        },
        {
          "n": "methodName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "g": [
        "T1",
        "T2"
      ],
      "n": "CallNativePlatform",
      "o": "@$4",
      "d": this.$h,
      "H": 30065133744,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(30065133744),
//--TRIMMABLE-BOUNDARY-START(21475199152),
    {
      "r": 181338113,
      "p": [
        {
          "n": "parameter1",
          "p": (T1, T2, T3) => T1.$h
        },
        {
          "n": "parameter2",
          "p": (T1, T2, T3) => T2.$h
        },
        {
          "n": "parameter3",
          "p": (T1, T2, T3) => T3.$h
        },
        {
          "n": "methodName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 126156801,
              "c": 4421124097
            }
          ]
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3"
      ],
      "n": "CallNativePlatform",
      "o": "@$2",
      "d": this.$h,
      "H": 21475199152,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16908292
    },
//--TRIMMABLE-BOUNDARY-END(21475199152)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55834937520),
    {
      "t": 64509610,
      "n": "javascript",
      "d": this.$h,
      "H": 55834937520,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55834937520),
//--TRIMMABLE-BOUNDARY-START(4295329968),
    {
      "t": 655361,
      "n": "_requestId",
      "d": this.$h,
      "H": 4295329968,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295329968)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590297264),
    {
      "p": [
        {
          "n": "javascript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590297264,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590297264)
  ],
  "s": [
    {
      "h": TInterface?.$h??1572864,
      "n": "TInterface"
    }
  ],
  "r": 1,
  "H": 362672,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.NativeInteropServices.NativeInteropServiceBase<${TInterface?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}NativeInteropServices${separator}NativeInteropServiceBase$${TInterface?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(362672)
        
        

        //--TRIMMABLE-BOUNDARY-START(821424)
        $asm.$cls(`$TvJd.LCFWS.WasmJavascriptImport`, ($self) => class WasmJavascriptImport
        {
            //--TRIMMABLE-BOUNDARY-START(25770625200)
            static /*string */ LocalStorageGet(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770625200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageGet_304094707 === null)
                {
                    $.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageGet_304094707 = $.$srij.SRIJ.JSFunctionBinding.BindJSFunction("globalThis.localStorage.getItem", null, $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerType), [$.$srij.SRIJ.JSMarshalerType.String, $.$srij.SRIJ.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __key_native;
                    /*string*/ let __retVal;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __retVal_native;
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => __key_native, ($v) => __key_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    __key_native.ToJS$37(key);
                    {
                        __retVal_native = __InvokeJSFunction.call(this, $.$clone(____arg_exception_native), $.$clone(____arg_return_native), $.$clone(__key_native));
                    }
                    __retVal_native.ToManaged$37($.$ref(() => __retVal, ($v) => __retVal = $v, $.$$.S.String));
                    return __retVal;
                }
                /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __key_native)
                {
                    /*global::System.Span<global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument>*/ let __arguments_buffer = $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).op_Implicit$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __key_native], null, null));
                    $.$srij.SRIJ.JSFunctionBinding.InvokeJS($.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageGet_304094707, __arguments_buffer);
                    return __arguments_buffer._reference.GetAt(1);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770625200)
            
            //--TRIMMABLE-BOUNDARY-START(8590756016)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_LocalStorageGet_304094707 = null;
            //--TRIMMABLE-BOUNDARY-END(8590756016)
            
            //--TRIMMABLE-BOUNDARY-START(34360559792)
            static /*void */ LocalStorageSet(/*string*/ key, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360559792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageSet_677461511 === null)
                {
                    $.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageSet_677461511 = $.$srij.SRIJ.JSFunctionBinding.BindJSFunction("globalThis.localStorage.setItem", null, $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerType), [$.$srij.SRIJ.JSMarshalerType.Discard, $.$srij.SRIJ.JSMarshalerType.String, $.$srij.SRIJ.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __key_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __value_native;
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => __value_native, ($v) => __value_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => __key_native, ($v) => __key_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    __value_native.ToJS$37(value);
                    __key_native.ToJS$37(key);
                    {
                        __InvokeJSFunction.call(this, $.$clone(____arg_exception_native), $.$clone(____arg_return_native), $.$clone(__key_native), $.$clone(__value_native));
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __key_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __value_native)
                {
                    $.$srij.SRIJ.JSFunctionBinding.InvokeJS($.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageSet_677461511, $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).op_Implicit$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __key_native, __value_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360559792)
            
            //--TRIMMABLE-BOUNDARY-START(17180690608)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_LocalStorageSet_677461511 = null;
            //--TRIMMABLE-BOUNDARY-END(17180690608)
            
            //--TRIMMABLE-BOUNDARY-START(30065592496)
            static /*void */ LocalStorageRemove(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065592496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageRemove_92020726 === null)
                {
                    $.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageRemove_92020726 = $.$srij.SRIJ.JSFunctionBinding.BindJSFunction("globalThis.localStorage.removeItem", null, $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerType), [$.$srij.SRIJ.JSMarshalerType.Discard, $.$srij.SRIJ.JSMarshalerType.String], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let __key_native;
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => __key_native, ($v) => __key_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    __key_native.ToJS$37(key);
                    {
                        __InvokeJSFunction.call(this, $.$clone(____arg_exception_native), $.$clone(____arg_return_native), $.$clone(__key_native));
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ __key_native)
                {
                    $.$srij.SRIJ.JSFunctionBinding.InvokeJS($.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageRemove_92020726, $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).op_Implicit$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native, __key_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065592496)
            
            //--TRIMMABLE-BOUNDARY-START(12885723312)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_LocalStorageRemove_92020726 = null;
            //--TRIMMABLE-BOUNDARY-END(12885723312)
            
            //--TRIMMABLE-BOUNDARY-START(21475657904)
            static /*void */ LocalStorageClear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475657904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageClear_19325221 === null)
                {
                    $.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageClear_19325221 = $.$srij.SRIJ.JSFunctionBinding.BindJSFunction("globalThis.localStorage.clear", null, $.$$.S.ReadOnlySpan$$($.$srij.SRIJ.JSMarshalerType).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerType), [$.$srij.SRIJ.JSMarshalerType.Discard], null, null)));
                }
                {
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_exception_native;
                    /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ let ____arg_return_native;
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_return_native, ($v) => ____arg_return_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_return_native.Initialize();
                    $.$$.SRC.Unsafe.SkipInit($.$srij.SRIJ.JSMarshalerArgument, $.$ref(() => ____arg_exception_native, ($v) => ____arg_exception_native = $v, $.$srij.SRIJ.JSMarshalerArgument));
                    ____arg_exception_native.Initialize();
                    {
                        __InvokeJSFunction.call(this, $.$clone(____arg_exception_native), $.$clone(____arg_return_native));
                    }
                }
                /*void*/  function __InvokeJSFunction(/*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_exception_native, /*global::System.Runtime.InteropServices.JavaScript.JSMarshalerArgument*/ ____arg_return_native)
                {
                    $.$srij.SRIJ.JSFunctionBinding.InvokeJS($.$TvJd.LCFWS.WasmJavascriptImport.__signature_LocalStorageClear_19325221, $.$$.S.Span$$($.$srij.SRIJ.JSMarshalerArgument).op_Implicit$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$srij.SRIJ.JSMarshalerArgument), [____arg_exception_native, ____arg_return_native], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475657904)
            
            //--TRIMMABLE-BOUNDARY-START(4295788720)
            /*global::System.Runtime.InteropServices.JavaScript.JSFunctionBinding*/ static __signature_LocalStorageClear_19325221 = null;
            //--TRIMMABLE-BOUNDARY-END(4295788720)
            
            static $h = 821424;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770625200),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "LocalStorageGet",
      "d": 821424,
      "h": 25770625200,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "globalThis.localStorage.getItem",
              "t": 1310721
            }
          ]
        },
        {
          "t": 71237633,
          "c": 4366204929
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770625200),
//--TRIMMABLE-BOUNDARY-START(34360559792),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "LocalStorageSet",
      "d": 821424,
      "h": 34360559792,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "globalThis.localStorage.setItem",
              "t": 1310721
            }
          ]
        },
        {
          "t": 71237633,
          "c": 4366204929
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360559792),
//--TRIMMABLE-BOUNDARY-START(30065592496),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "LocalStorageRemove",
      "d": 821424,
      "h": 30065592496,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "globalThis.localStorage.removeItem",
              "t": 1310721
            }
          ]
        },
        {
          "t": 71237633,
          "c": 4366204929
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065592496),
//--TRIMMABLE-BOUNDARY-START(21475657904),
    {
      "r": 65537,
      "n": "LocalStorageClear",
      "d": 821424,
      "h": 21475657904,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "globalThis.localStorage.clear",
              "t": 1310721
            }
          ]
        },
        {
          "t": 71237633,
          "c": 4366204929
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475657904)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590756016),
    {
      "t": 524299,
      "n": "__signature_LocalStorageGet_304094707",
      "d": 821424,
      "h": 8590756016,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590756016),
//--TRIMMABLE-BOUNDARY-START(17180690608),
    {
      "t": 524299,
      "n": "__signature_LocalStorageSet_677461511",
      "d": 821424,
      "h": 17180690608,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180690608),
//--TRIMMABLE-BOUNDARY-START(12885723312),
    {
      "t": 524299,
      "n": "__signature_LocalStorageRemove_92020726",
      "d": 821424,
      "h": 12885723312,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885723312),
//--TRIMMABLE-BOUNDARY-START(4295788720),
    {
      "t": 524299,
      "n": "__signature_LocalStorageClear_19325221",
      "d": 821424,
      "h": 4295788720,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295788720)
  ],
  "h": 821424
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.Services.WasmJavascriptImport`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}Services${separator}WasmJavascriptImport`; }
        });
        //--TRIMMABLE-BOUNDARY-END(821424)
        
        

        //--TRIMMABLE-BOUNDARY-START(755888)
        $asm.$cls(`$TvJd.LCFWS.WasmJavascriptCallDispatcher`, ($self) => class WasmJavascriptCallDispatcher
        {
            //--TRIMMABLE-BOUNDARY-START(4295723184)
            static /*Task<object> */ Dispatch(/*RemoteProxyMethodInfo*/ info)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295723184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4295723184)
            
            //--TRIMMABLE-BOUNDARY-START(8590690480)
            static /*Task<object> */ DispatchAsync(/*RemoteProxyMethodInfo*/ info)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590690480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(8590690480)
            
            static $h = 755888;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295723184),
    {
      "r": $.$$.STT.Task$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "info",
          "p": 1768403
        }
      ],
      "n": "Dispatch",
      "d": 755888,
      "h": 4295723184,
      "f": 16777249,
      "a": [
        {
          "t": 2818162,
          "c": 12887720050,
          "a": [
            {
              "v": "LivingThing.Core.Frameworks.WebAssembly.Services.WasmJavascriptCallDispatcher.Dispatch",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295723184),
//--TRIMMABLE-BOUNDARY-START(8590690480),
    {
      "r": $.$$.STT.Task$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "info",
          "p": 1768403
        }
      ],
      "n": "DispatchAsync",
      "d": 755888,
      "h": 8590690480,
      "f": 16777249,
      "a": [
        {
          "t": 2818162,
          "c": 12887720050,
          "a": [
            {
              "v": "LivingThing.Core.Frameworks.WebAssembly.Services.WasmJavascriptCallDispatcher.DispatchAsync",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590690480)
  ],
  "h": 755888
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.Services.WasmJavascriptCallDispatcher`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}Services${separator}WasmJavascriptCallDispatcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(755888)
        
        

        //--TRIMMABLE-BOUNDARY-START(1214640)
        $asm.$cls(`$TvJd.LCFW.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4296181936)
            static /*void */ AddBlazorWebAssemblyLibraries(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296181936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$TvJd.LCFW.Startup.RegisterGenerated(services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFC.IApplicationContextProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$TvJd.LCFWS.WasmApplicationContextProvider, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFC.IApplicationContextProvider))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmApplicationContextProvider, x);
                }, $DtAKIj ??= {"r":46041430,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$vWqU.LCFCC.IUIRenderingProvider, $.$TvJd.LCFWS.WasmViewRenderingStateProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$fPer.LCFC.IBootupTask, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$fPer.LCFC.IProfileTrace, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$TvJd.LCFWS.WasmProfileTrace, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFC.IProfileTrace))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmProfileTrace, x);
                }, $zvyFXd ??= {"r":47941974,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFC.IBootupTask))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmProfileTrace, x);
                }, $eXYkUa ??= {"r":46106966,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCS$3.IRemoteModuleLoader, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$TvJd.LCFWS.WasmAssemblyLazyLoader, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCS$3.IRemoteModuleLoader))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmAssemblyLazyLoader, x);
                }, $yHmMRg ??= {"r":61901142,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCI.IJavaScriptRunner, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$hDPm.LCFCS.JavaScriptRunner, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$TvJd.LCFWS.WasmJavaScriptRunner, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCS.JavaScriptRunner))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmJavaScriptRunner, x);
                }, $uTFedf ??= {"r":70145706,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$hDPm.LCFCI.IJavaScriptRunner))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmJavaScriptRunner, x);
                }, $QwWFni ??= {"r":64509610,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFCS$5.IPersistentStorageService, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$TvJd.LCFWS.WasmJavascriptLocalStorageService, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFCS$5.IPersistentStorageService))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmJavascriptLocalStorageService, x);
                }, $TAkCad ??= {"r":63932758,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4296181936)
            
            //--TRIMMABLE-BOUNDARY-START(8591149232)
            static /*void */ RegisterGenerated(/*IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591149232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static object*/  function Get_WasmApplicationContextProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$TvJd.LCFWS.WasmApplicationContextProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$mac.MAC.NavigationManager, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFCC$1.IConfigurationParser, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFCC$1.IConfigurationParser, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$hDPm.LCFCI.IJavaScriptRunner, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IJavaScriptRunner, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration), provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration), provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$snh.SNH.HttpClient, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$snh.SNH.HttpClient, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$TvJd.LCFWS.WasmApplicationContextProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_WasmApplicationContextProvider, $ZEXYtb ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_WasmApplicationContextProvider","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_IApplicationContextProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/**/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmApplicationContextProvider, x);
                    }), $KDIdzd ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fPer.LCFC.IApplicationContextProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_IApplicationContextProvider, $CzKjdl ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IApplicationContextProvider","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_WasmViewRenderingStateProvider(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$TvJd.LCFWS.WasmViewRenderingStateProvider().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$mac.MAC.PersistentComponentState, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.PersistentComponentState, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$vWqU.LCFCC.IUIRenderingProvider.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_WasmViewRenderingStateProvider, $UXfHMh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_WasmViewRenderingStateProvider","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_WasmProfileTrace(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$TvJd.LCFWS.WasmProfileTrace().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$mj.MJ.IJSRuntime, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mj.MJ.IJSRuntime, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$TvJd.LCFWS.WasmProfileTrace.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(0/*ServiceLifetime.Singleton*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_WasmProfileTrace, $MDohKh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_WasmProfileTrace","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_IProfileTrace(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmProfileTrace, x);
                    }), $FWogfg ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fPer.LCFC.IProfileTrace.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(0/*ServiceLifetime.Singleton*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_IProfileTrace, $wDDgVh ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IProfileTrace","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_IBootupTask(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmProfileTrace, x);
                    }), $eFVjJd ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fPer.LCFC.IBootupTask.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(0/*ServiceLifetime.Singleton*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_IBootupTask, $lHlZde ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IBootupTask","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_WasmAssemblyLazyLoader(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$TvJd.LCFWS.WasmAssemblyLazyLoader().$ctor$1(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$macwa.MACWS.LazyAssemblyLoader, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$macwa.MACWS.LazyAssemblyLoader, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFC.IApplicationContextProvider, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFC.IApplicationContextProvider, provider), serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$fPer.LCFCC$1.IConfigurationParser, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$fPer.LCFCC$1.IConfigurationParser, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$TvJd.LCFWS.WasmAssemblyLazyLoader.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_WasmAssemblyLazyLoader, $FJIEqf ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_WasmAssemblyLazyLoader","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_IRemoteModuleLoader(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmAssemblyLazyLoader, x);
                    }), $JSNtCa ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fPer.LCFCS$3.IRemoteModuleLoader.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_IRemoteModuleLoader, $Cfkifk ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IRemoteModuleLoader","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_WasmJavaScriptRunner(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$TvJd.LCFWS.WasmJavaScriptRunner().$ctor$2(serviceKey !== null ? $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$mj.MJ.IJSRuntime, provider, serviceKey) : $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mj.MJ.IJSRuntime, provider));
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$TvJd.LCFWS.WasmJavaScriptRunner.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_WasmJavaScriptRunner, $TVGnGb ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_WasmJavaScriptRunner","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_JavaScriptRunner(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmJavaScriptRunner, x);
                    }), $gAOfDf ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$hDPm.LCFCS.JavaScriptRunner.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_JavaScriptRunner, $jMwaHe ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_JavaScriptRunner","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_IJavaScriptRunner(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmJavaScriptRunner, x);
                    }), $TYVOmg ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$hDPm.LCFCI.IJavaScriptRunner.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_IJavaScriptRunner, $PZIQKa ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IJavaScriptRunner","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_WasmJavascriptLocalStorageService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return new $.$TvJd.LCFWS.WasmJavascriptLocalStorageService().$ctor$2();
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$TvJd.LCFWS.WasmJavascriptLocalStorageService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_WasmJavascriptLocalStorageService, $DrWnXd ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_WasmJavascriptLocalStorageService","d":1214640,"h":0,"f":16777250})));
                /*static object*/  function Get_IPersistentStorageService(/*IServiceProvider*/ provider, /*object?*/ serviceKey)
                {
                    return (new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this, ( (/*x*/ x) =>
                    {
                        return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$TvJd.LCFWS.WasmJavascriptLocalStorageService, x);
                    }), $Znqehf ??= {"r":131073,"p":[{"n":"x","p":327718}],"n":"","d":1214640,"h":0,"f":17825794})).Invoke(provider);
                }
                $.$fPer.LCFCSG.GeneratedServiceFactory.Register($.$fPer.LCFCS$5.IPersistentStorageService.$type, new $.$fPer.LCFCSG.ServiceProviderDescriptor().$ctor$3(1/*ServiceLifetime.Scoped*/, new ($.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object))().$ctor($.$TvJd.LCFW.Startup, Get_IPersistentStorageService, $CaJFGe ??= {"r":131073,"p":[{"n":"provider","p":327718},{"n":"serviceKey","p":131073}],"n":"Get_IPersistentStorageService","d":1214640,"h":0,"f":16777250})));
            }
            //--TRIMMABLE-BOUNDARY-END(8591149232)
            
            static $h = 1214640;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296181936),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddBlazorWebAssemblyLibraries",
      "d": 1214640,
      "h": 4296181936,
      "f": 16777249,
      "a": [
        {
          "t": 60918102,
          "c": 4355885398
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296181936),
//--TRIMMABLE-BOUNDARY-START(8591149232),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "RegisterGenerated",
      "d": 1214640,
      "h": 8591149232,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591149232)
  ],
  "h": 1214640
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1214640)
        
        

        //--TRIMMABLE-BOUNDARY-START(559280)
        $asm.$cls(`$TvJd.LCFWN.Startup`, ($self) => class Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295526576)
            static /*void */ AddNativeInterop(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295526576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$vWqU.LCFCC.ICameraProvider, $.$TvJd.LCFWN.NativeInteropCameraProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCS.IPlatformPermissionManager, $.$TvJd.LCFWN.NativeInteropPermissionProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCP.IPlatformShareManager, $.$TvJd.LCFWN.NativeInteropShareProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFC.IBrowserWindow, $.$TvJd.LCFWN.NativeInteropBrowser, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCS$3.ILocationProvider, $.$TvJd.LCFWN.NativeInteropLocationProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCS$3.ILocationGeocoder, $.$TvJd.LCFWN.NativeIntropLocationGeocoder, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295526576)
            
            static $h = 559280;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295526576),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddNativeInterop",
      "d": 559280,
      "h": 4295526576,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295526576)
  ],
  "h": 559280
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.NativeInteropServices.Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}NativeInteropServices${separator}Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(559280)
        
        

        //--TRIMMABLE-BOUNDARY-START(690352)
        $asm.$cls(`$TvJd.LCFWS.WasmAssemblyLazyLoader`, ($self) => class WasmAssemblyLazyLoader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180559536)
            /*Dictionary<string, string[]>*/ static assemblyToLoadOnPath = null;
            //--TRIMMABLE-BOUNDARY-END(17180559536)
            
            //--TRIMMABLE-BOUNDARY-START(34360428720)
            static /*void */ Register(/*string*/ path, /*string[]*/ assemblies)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360428720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$TvJd.LCFWS.WasmAssemblyLazyLoader.assemblyToLoadOnPath.Add(path, assemblies);
            }
            //--TRIMMABLE-BOUNDARY-END(34360428720)
            
            //--TRIMMABLE-BOUNDARY-START(12885592240)
            /*LazyAssemblyLoader*/ AssemblyLoader = null;
            //--TRIMMABLE-BOUNDARY-END(12885592240)
            
            //--TRIMMABLE-BOUNDARY-START(25770494128)
            /*IApplicationContextProvider*/ context = null;
            //--TRIMMABLE-BOUNDARY-END(25770494128)
            
            //--TRIMMABLE-BOUNDARY-START(21475526832)
            /*IConfigurationParser*/ configuration = null;
            //--TRIMMABLE-BOUNDARY-END(21475526832)
            
            //--TRIMMABLE-BOUNDARY-START(8590624944)
            $ctor$1(/*LazyAssemblyLoader*/ assemblyLoader, /*IApplicationContextProvider*/ context, /*IConfigurationParser*/ configuration)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590624944);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AssemblyLoader = assemblyLoader;
                    this.context = context;
                    this.configuration = configuration;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590624944)
            
            //--TRIMMABLE-BOUNDARY-START(30065461424)
            /*ValueTask<IEnumerable<Assembly>> *//*async*/  LoadModulesAndRegisterServices(/*IEnumerable<string>*/ assemblyNames)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)), $.$$.SCG.IEnumerable$$($.$$.SR.Assembly), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065461424);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$scsl.S.Console.WriteLine$17(`Wasm loading assemblies ${$.$strNN($.$$.S.String.Join$5(";", assemblyNames))}`);
                    /*string*/ let extension = ".wasm";
                    /*var*/ let assemblies = ($t1 = this.AssemblyLoader.LoadAssembliesAsync($.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.S.String, $.$sl.SL.Enumerable.Distinct$1($.$$.S.String, assemblyNames), new ($.$$.S.Func$$$($.$$.S.String, $.$$.S.String))().$ctor(this,  (/*a*/ a) =>
                    {
                        return !$.$$.S.String.EndsWith$3.call(a, extension) ? $.$strNN(a) + $.$strNN(extension) : a;
                    }, $ZXqljf ??= {"r":1310721,"p":[{"n":"a","p":1310721}],"n":"","d":690352,"h":0,"f":17825794}))), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    $.$scsl.S.Console.WriteLine$17(`Loaded ${$.$strNN($.$sl.SL.Enumerable.Count$1($.$$.SR.Assembly, assemblies))} assemblies!`);
                    if ($.$lmWW.LCFCS.ExtensibleServiceProvider.Instance !== null)
                    {
                        $.$lmWW.LCFCS.ExtensibleServiceProvider.Instance.RegisterServicesInAssemblies(assemblies);
                    }
                    let configurationProvider;
                    if ($.$is(this.configuration, $.$fPer.LCFCC$1.ConfigurationProvider, { set $v($v){ configurationProvider = $v; } }))
                    {
                        let $en2 = assemblies.SCG$IEnumerable$$$GetEnumerator();
                        while ($en2.SC$1$IEnumerator$MoveNext())
                        {
                            let assembly = $en2.SCG$IEnumerator$$$Current;
                            {
                                configurationProvider.AddEmbeddedConfigurationFromAssembly(assembly);
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.SR.Assembly, assemblyNames, new ($.$$.S.Func$$$($.$$.S.String, $.$$.SR.Assembly))().$ctor(this,  (/*assemblyName*/ assemblyName) =>
                    {
                        if ($.$$.S.String.EndsWith$3.call(assemblyName, ".wasm"))
                        {
                            assemblyName = $.$$.S.String.Substring.call(assemblyName, 0, ((assemblyName.length - 5) | 0));
                        }
                        return $.$sl.SL.Enumerable.FirstOrDefault$1($.$$.SR.Assembly, $.$$.SRL.AssemblyLoadContext.Default.Assemblies, new ($.$$.S.Func$$$($.$$.SR.Assembly, $.$$.S.Boolean))().$ctor(this,  (/*Assembly*/ a) =>
                        {
                            return a.GetName().Name === assemblyName;
                        }, $QEUPVe ??= {"r":262145,"p":[{"n":"a","p":107020289}],"n":"","d":690352,"h":0,"f":17825794}));
                    }, $PfVRLj ??= {"r":107020289,"p":[{"n":"assemblyName","p":1310721}],"n":"","d":690352,"h":0,"f":17825794})));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065461424)
            
            //--TRIMMABLE-BOUNDARY-START(4356868438)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IRemoteModuleLoader.LoadModulesAndRegisterServices(System.Collections.Generic.IEnumerable<string>)
            LCFCS$3$IRemoteModuleLoader$LoadModulesAndRegisterServices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356868438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LoadModulesAndRegisterServices(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356868438)
            
            //--TRIMMABLE-BOUNDARY-START(4295657648)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295657648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17180559536)
                    this.assemblyToLoadOnPath = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.String)))().$ctor$6(new $.$TvJd.LCFWS.WasmPathRegexComparer().$ctor$1());
                    //--TRIMMABLE-BOUNDARY-END(17180559536)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295657648)
            
            static $h = 690352;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360428720),
    {
      "r": 65537,
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "assemblies",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": "Register",
      "d": 690352,
      "h": 34360428720,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360428720),
//--TRIMMABLE-BOUNDARY-START(30065461424),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)).$h,
      "p": [
        {
          "n": "assemblyNames",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "LoadModulesAndRegisterServices",
      "d": 690352,
      "h": 30065461424,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(30065461424)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180559536),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.String)).$h,
      "n": "assemblyToLoadOnPath",
      "d": 690352,
      "h": 17180559536,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180559536),
//--TRIMMABLE-BOUNDARY-START(12885592240),
    {
      "t": 3473528,
      "n": "AssemblyLoader",
      "d": 690352,
      "h": 12885592240,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885592240),
//--TRIMMABLE-BOUNDARY-START(25770494128),
    {
      "t": 46041430,
      "n": "context",
      "d": 690352,
      "h": 25770494128,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770494128),
//--TRIMMABLE-BOUNDARY-START(21475526832),
    {
      "t": 4950358,
      "n": "configuration",
      "d": 690352,
      "h": 21475526832,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475526832)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590624944),
    {
      "p": [
        {
          "n": "assemblyLoader",
          "p": 3473528
        },
        {
          "n": "context",
          "p": 46041430
        },
        {
          "n": "configuration",
          "p": 4950358
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 690352,
      "h": 8590624944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590624944)
  ],
  "h": 690352
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IRemoteModuleLoader ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.Services.WasmAssemblyLazyLoader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}Services${separator}WasmAssemblyLazyLoader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(690352)
        
        

        //--TRIMMABLE-BOUNDARY-START(624816)
        $asm.$cls(`$TvJd.LCFWS.WasmApplicationContextProvider`, ($self) => class WasmApplicationContextProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885526704)
            $ctor$1(/*NavigationManager*/ navManager, /*IConfigurationParser*/ configuration, /*IJavaScriptRunner*/ javaScript, /*IOptions<ApplicationRuntimeConfiguration>*/ runtime, /*HttpClient*/ http)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885526704);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.NavManager = navManager;
                    this.Configuration = configuration;
                    this.JavaScript = javaScript;
                    this.Runtime = runtime.MEO$IOptions$LivingThing$Core$Frameworks$Common$Application$ApplicationRuntimeConfiguration$Value ?? (() =>
                    {
                        //new $.$fPer.LCFCA.ApplicationRuntimeConfiguration()
                        const $t1 = $.$fPer.LCFCA.ApplicationRuntimeConfiguration;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.StartupOptions = (() =>
                        {
                            //new $.$fPer.LCFCS$3.StartupOptions()
                            const $t2 = $.$fPer.LCFCS$3.StartupOptions;
                            const $i2 = new $t2();
                            $i2.$ctor$2();
                            $i2.Runtime = 3/*RuntimeType.Wasm*/;
                            return $i2;
                        })();
                        return $i1;
                    })();
                    /*System.Collections.Generic.Dictionary<string, string>?*/ let __ca1__;
                    this.IsMobile = ((__ca1__ = this.Runtime.Variables) !== null ? $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.S.String, __ca1__, "mobile") : null) === "true";
                    /*var*/ let sp = $.$fPer.LCFCS$6.StringExtension.SplitBy$1($.$fPer.LCFC.StringyExtension.AsStringy$1(navManager.Uri), /*?*/ 63);
                    if (sp.Length > 1)
                    {
                        /*var*/ let query = sp.get_Item$1(1);
                        let $en3 = $.$fPer.LCFCS$6.StringExtension.SplitBy$1(query, /*&*/ 38).GetEnumerator();
                        while ($en3.MoveNext())
                        {
                            let kv = $en3.Current;
                            {
                                if (kv.Token.StartsWith($.$fPer.LCFC.Stringy.op_Implicit$3("host"), 4))
                                {
                                    /*var*/ let kkvv = $.$fPer.LCFCS$6.StringExtension.SplitBy$1(kv.Token, /*=*/ 61);
                                    if (kkvv.Length > 0)
                                    {
                                        this.host = $.$fPer.LCFC.Stringy.op_Implicit$1(kkvv.get_Item$1(1));
                                        if (this.host === ".")
                                        {
                                            /*var*/ let uri = new $.$spu.S.Uri().$ctor$5(this.NavManager.Uri);
                                            this.host = uri.Host;
                                            if (uri.Port !== 80)
                                            {
                                                this.host += ":" + uri.Port;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885526704)
            
            //--TRIMMABLE-BOUNDARY-START(85899970736)
            /*NavigationManager*/ NavManager = null;
            //--TRIMMABLE-BOUNDARY-END(85899970736)
            
            //--TRIMMABLE-BOUNDARY-START(17180494000)
            /*IConfigurationParser*/ Configuration = null;
            //--TRIMMABLE-BOUNDARY-END(17180494000)
            
            //--TRIMMABLE-BOUNDARY-START(77310036144)
            /*IJavaScriptRunner*/ JavaScript = null;
            //--TRIMMABLE-BOUNDARY-END(77310036144)
            
            //--TRIMMABLE-BOUNDARY-START(64425134256)
            /*string?*/ host = null;
            //--TRIMMABLE-BOUNDARY-END(64425134256)
            
            //--TRIMMABLE-BOUNDARY-START(90194938032)
            /*string */ get RemoteHost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540232368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let rHost = this.host ?? this.Configuration.LCFCC$1$IConfigurationParser$RemoteHost;
                if (rHost === null)
                {
                    /*var*/ let localUri = this.LocalUri;
                    rHost = ($.$spu.S.Uri.op_Inequality(localUri, null) ? $.$strNN(localUri.Authority) + $.$strNN((localUri.Port !== 80 ? ":" + localUri.Port : "")) : null) ?? "sake.org.ng";
                }
                if (rHost === ".")
                {
                    /*var*/ let uri = new $.$spu.S.Uri().$ctor$5(this.NavManager.Uri);
                    rHost = uri.Host;
                    if (uri.Port !== 80)
                    {
                        rHost += ":" + uri.Port;
                    }
                    this.host = rHost;
                }
                return rHost;
            }
            /*string */ set RemoteHost(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079839920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.host = value;
            }
            //--TRIMMABLE-BOUNDARY-END(90194938032)
            
            //--TRIMMABLE-BOUNDARY-START(68720101552)
            /*bool */ get IsClient()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(68720101552)
            
            //--TRIMMABLE-BOUNDARY-START(73015068848)
            /*bool*/ IsMobile = false;
            //--TRIMMABLE-BOUNDARY-END(73015068848)
            
            //--TRIMMABLE-BOUNDARY-START(81605003440)
            /*Uri */ get LocalUri()
            {
                return new $.$spu.S.Uri().$ctor$5(this.NavManager.Uri);
            }
            //--TRIMMABLE-BOUNDARY-END(81605003440)
            
            //--TRIMMABLE-BOUNDARY-START(94489905328)
            /*ApplicationRuntimeConfiguration*/ Runtime = null;
            //--TRIMMABLE-BOUNDARY-END(94489905328)
            
            //--TRIMMABLE-BOUNDARY-START(42995714390)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IApplicationContextProvider.Runtime.get
            get LCFC$IApplicationContextProvider$Runtime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64470550870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Runtime;
            }
            //--TRIMMABLE-BOUNDARY-END(42995714390)
            
            //--TRIMMABLE-BOUNDARY-START(17225910614)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IApplicationContextProvider.IsMobile.get
            get LCFC$IApplicationContextProvider$IsMobile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51585648982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsMobile;
            }
            //--TRIMMABLE-BOUNDARY-END(17225910614)
            
            //--TRIMMABLE-BOUNDARY-START(8635976022)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IApplicationContextProvider.IsClient.get
            get LCFC$IApplicationContextProvider$IsClient()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47290681686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsClient;
            }
            //--TRIMMABLE-BOUNDARY-END(8635976022)
            
            //--TRIMMABLE-BOUNDARY-START(34405779798)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IApplicationContextProvider.RemoteHost.get
            get LCFC$IApplicationContextProvider$RemoteHost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60175583574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoteHost;
            }
            //--TRIMMABLE-BOUNDARY-END(34405779798)
            
            //--TRIMMABLE-BOUNDARY-START(25815845206)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IApplicationContextProvider.LocalUri.get
            get LCFC$IApplicationContextProvider$LocalUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55880616278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LocalUri;
            }
            //--TRIMMABLE-BOUNDARY-END(25815845206)
            
            static $h = 624816;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194938032),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540232368,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079839920,
        "f": 83886081
      },
      "n": "RemoteHost",
      "d": 624816,
      "h": 90194938032,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194938032),
//--TRIMMABLE-BOUNDARY-START(68720101552),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770428592,
        "f": 50331649
      },
      "n": "IsClient",
      "d": 624816,
      "h": 68720101552,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720101552),
//--TRIMMABLE-BOUNDARY-START(73015068848),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360363184,
        "f": 50331649
      },
      "n": "IsMobile",
      "d": 624816,
      "h": 73015068848,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015068848),
//--TRIMMABLE-BOUNDARY-START(81605003440),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950297776,
        "f": 50331649
      },
      "n": "LocalUri",
      "d": 624816,
      "h": 81605003440,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605003440),
//--TRIMMABLE-BOUNDARY-START(94489905328),
    {
      "p": 1083734,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130166960,
        "f": 50331649
      },
      "n": "Runtime",
      "d": 624816,
      "h": 94489905328,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489905328)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85899970736),
    {
      "t": 4980851,
      "n": "NavManager",
      "d": 624816,
      "h": 85899970736,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85899970736),
//--TRIMMABLE-BOUNDARY-START(17180494000),
    {
      "t": 4950358,
      "n": "Configuration",
      "d": 624816,
      "h": 17180494000,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180494000),
//--TRIMMABLE-BOUNDARY-START(77310036144),
    {
      "t": 64509610,
      "n": "JavaScript",
      "d": 624816,
      "h": 77310036144,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77310036144),
//--TRIMMABLE-BOUNDARY-START(64425134256),
    {
      "t": 1310721,
      "n": "host",
      "d": 624816,
      "h": 64425134256,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425134256)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885526704),
    {
      "p": [
        {
          "n": "navManager",
          "p": 4980851
        },
        {
          "n": "configuration",
          "p": 4950358
        },
        {
          "n": "javaScript",
          "p": 64509610
        },
        {
          "n": "runtime",
          "p": $.$meo.MEO.IOptions$$($.$fPer.LCFCA.ApplicationRuntimeConfiguration).$h
        },
        {
          "n": "http",
          "p": 6488117
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 624816,
      "h": 12885526704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885526704)
  ],
  "h": 624816
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IApplicationContextProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.Services.WasmApplicationContextProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}Services${separator}WasmApplicationContextProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(624816)
        
        

        //--TRIMMABLE-BOUNDARY-START(1149104)
        $asm.$cls(`$TvJd.LCFWS.WasmViewRenderingStateProvider`, ($self) => class WasmViewRenderingStateProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770952880)
            /*bool */ get IsPreRendering()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(25770952880)
            
            //--TRIMMABLE-BOUNDARY-START(42950822064)
            /*PersistentComponentState*/ State = null;
            //--TRIMMABLE-BOUNDARY-END(42950822064)
            
            //--TRIMMABLE-BOUNDARY-START(47245789360)
            /*PersistingComponentStateSubscription*/ subscription;
            //--TRIMMABLE-BOUNDARY-END(47245789360)
            
            //--TRIMMABLE-BOUNDARY-START(30065920176)
            /*List<Action>*/ persistDelegates = null;
            //--TRIMMABLE-BOUNDARY-END(30065920176)
            
            //--TRIMMABLE-BOUNDARY-START(4296116400)
            $ctor$1(/*PersistentComponentState*/ state)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296116400);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.State = state;
                    this.subscription = state.RegisterOnPersisting$1(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, this.PersistStates));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296116400)
            
            //--TRIMMABLE-BOUNDARY-START(34360887472)
            /*Task */ PersistStates()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360887472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.persistDelegates.ForEach(new ($.$$.S.Action$$($.$$.S.Action))().$ctor(this,  (/**/ d) =>
                {
                    return d.Invoke();
                }, $vJHhBj ??= {"r":65537,"p":[{"n":"d","p":43122689}],"n":"","d":1149104,"h":0,"f":17825794}));
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(34360887472)
            
            //--TRIMMABLE-BOUNDARY-START(38655854768)
            /*void */ SetPreRenderingData(T, /*string*/ key, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655854768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.persistDelegates.Add(new $.$$.S.Action().$ctor(this,  () =>
                {
                    return this.State.PersistAsJson$1(T, key, value);
                }, $VolJye ??= {"r":65537,"n":"","d":1149104,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(38655854768)
            
            //--TRIMMABLE-BOUNDARY-START(51540756656)
            /*bool */ TryGetPreRenderingData(T, /*string*/ key, /*out T?*/ value)
            {
                /*string?*/ let _value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540756656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.State.TryTakeFromJson$1($.$$.S.String, key, $.$ref(() => _value, ($v) => _value = $v, $.$$.S.String)))
                {
                    value.$v = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize$3(T, _value, false, "TryGetPreRenderingData", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.WebAssembly\\WasmViewRenderingStateProvider.cs", "TryGetPreRenderingData", 45);
                    return true;
                }
                value.$v = $.$default(T);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(51540756656)
            
            //--TRIMMABLE-BOUNDARY-START(8591083696)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591083696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.subscription.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(8591083696)
            
            //--TRIMMABLE-BOUNDARY-START(21475985584)
            /*ValueTask<T?> *//*async*/  GetOrCreate(T, /*string*/ key, /*Func<ValueTask<T?>>*/ create)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$(T), T, async ($asnycContext) => 
                {
                    /*var*/ let dt;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475985584);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.TryGetPreRenderingData(T, key, $.$ref(() => dt, ($v) => dt = $v, T)))
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, dt);
                    }
                    dt = ($t3 = create.Invoke(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    this.SetPreRenderingData(T, key, dt);
                    return $.$$.N.AsyncResolver.Result($asnycContext, dt);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475985584)
            
            //--TRIMMABLE-BOUNDARY-START(8595398056)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.IUIRenderingProvider.IsPreRendering.get
            get LCFCC$IUIRenderingProvider$IsPreRendering()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890365352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsPreRendering;
            }
            //--TRIMMABLE-BOUNDARY-END(8595398056)
            
            //--TRIMMABLE-BOUNDARY-START(4358768982)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Storage.ICacheProvider.GetOrCreate<T>(string, System.Func<System.Threading.Tasks.ValueTask<T?>>)
            LCFCS$5$ICacheProvider$GetOrCreate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358768982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOrCreate(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358768982)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47245789360)
                this.subscription = $.$default($.$mac.MAC.PersistingComponentStateSubscription);
                //--TRIMMABLE-BOUNDARY-END(47245789360)
                
                //--TRIMMABLE-BOUNDARY-START(30065920176)
                this.persistDelegates = new ($.$$.SCG.List$$($.$$.S.Action))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(30065920176)
                
            }
            static $h = 1149104;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770952880),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181018288,
        "f": 50331649
      },
      "n": "IsPreRendering",
      "d": 1149104,
      "h": 25770952880,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770952880)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360887472),
    {
      "r": 178454529,
      "n": "PersistStates",
      "d": 1149104,
      "h": 34360887472,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360887472),
//--TRIMMABLE-BOUNDARY-START(38655854768),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "SetPreRenderingData",
      "d": 1149104,
      "h": 38655854768,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(38655854768),
//--TRIMMABLE-BOUNDARY-START(51540756656),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetPreRenderingData",
      "d": 1149104,
      "h": 51540756656,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(51540756656),
//--TRIMMABLE-BOUNDARY-START(8591083696),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1149104,
      "h": 8591083696,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591083696),
//--TRIMMABLE-BOUNDARY-START(21475985584),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "create",
          "p": (T) => $.$$.S.Func$$($.$$.STT.ValueTask$$(T)).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetOrCreate",
      "d": 1149104,
      "h": 21475985584,
      "f": 16912385
    },
//--TRIMMABLE-BOUNDARY-END(21475985584)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950822064),
    {
      "t": 6160499,
      "n": "State",
      "d": 1149104,
      "h": 42950822064,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950822064),
//--TRIMMABLE-BOUNDARY-START(47245789360),
    {
      "t": 6422643,
      "n": "subscription",
      "d": 1149104,
      "h": 47245789360,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245789360),
//--TRIMMABLE-BOUNDARY-START(30065920176),
    {
      "t": $.$$.SCG.List$$($.$$.S.Action).$h,
      "n": "persistDelegates",
      "d": 1149104,
      "h": 30065920176,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065920176)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296116400),
    {
      "p": [
        {
          "n": "state",
          "p": 6160499
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1149104,
      "h": 4296116400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296116400)
  ],
  "h": 1149104
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.IUIRenderingProvider, $.$fPer.LCFCS$5.ICacheProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.Services.WasmViewRenderingStateProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}Services${separator}WasmViewRenderingStateProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1149104)
        
        

        //--TRIMMABLE-BOUNDARY-START(1083568)
        $asm.$cls(`$TvJd.LCFWS.WasmProfileTrace`, ($self) => class WasmProfileTrace extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885985456)
            /*IJSInProcessRuntime*/ js = null;
            //--TRIMMABLE-BOUNDARY-END(12885985456)
            
            //--TRIMMABLE-BOUNDARY-START(4296050864)
            $ctor$1(/*IJSRuntime*/ js)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296050864);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.js = $.$cast(js, $.$mj.MJ.IJSInProcessRuntime);
                    $.$scsl.S.Console.WriteLine$17("Using Wasm Trace");
                    $.$fPer.LCFC.ProfileTraceExtension.UseTrace(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296050864)
            
            //--TRIMMABLE-BOUNDARY-START(8591018160)
            /*ValueTask */ BootExecute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591018160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(8591018160)
            
            //--TRIMMABLE-BOUNDARY-START(17180952752)
            /*void */ Start(/*string*/ traceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180952752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17180952752)
            
            //--TRIMMABLE-BOUNDARY-START(21475920048)
            /*void */ Stop(/*string*/ traceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475920048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475920048)
            
            //--TRIMMABLE-BOUNDARY-START(4342909270)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IProfileTrace.Start(string)
            LCFC$IProfileTrace$Start()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4342909270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Start(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4342909270)
            
            //--TRIMMABLE-BOUNDARY-START(8637876566)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IProfileTrace.Stop(string)
            LCFC$IProfileTrace$Stop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8637876566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Stop(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8637876566)
            
            //--TRIMMABLE-BOUNDARY-START(4341074262)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IBootupTask.BootExecute()
            LCFC$IBootupTask$BootExecute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341074262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BootExecute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4341074262)
            
            static $h = 1083568;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591018160),
    {
      "r": 181338113,
      "n": "BootExecute",
      "d": 1083568,
      "h": 8591018160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591018160),
//--TRIMMABLE-BOUNDARY-START(17180952752),
    {
      "r": 65537,
      "p": [
        {
          "n": "traceName",
          "p": 1310721
        }
      ],
      "n": "Start",
      "d": 1083568,
      "h": 17180952752,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180952752),
//--TRIMMABLE-BOUNDARY-START(21475920048),
    {
      "r": 65537,
      "p": [
        {
          "n": "traceName",
          "p": 1310721
        }
      ],
      "n": "Stop",
      "d": 1083568,
      "h": 21475920048,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475920048)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885985456),
    {
      "t": 393330,
      "n": "js",
      "d": 1083568,
      "h": 12885985456,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885985456)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296050864),
    {
      "p": [
        {
          "n": "js",
          "p": 524402
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1083568,
      "h": 4296050864,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296050864)
  ],
  "h": 1083568
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IProfileTrace, $.$fPer.LCFC.IBootupTask ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.Services.WasmProfileTrace`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}Services${separator}WasmProfileTrace`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1083568)
        
        

        //--TRIMMABLE-BOUNDARY-START(166064)
        $asm.$cls(`$TvJd.LCFWN.NativeInteropCameraProvider`, ($self) => class NativeInteropCameraProvider extends $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$vWqU.LCFCC.ICameraProvider)
        {
            //--TRIMMABLE-BOUNDARY-START(4295133360)
            $ctor$2(/*IJavaScriptRunner*/ javascript)
            {
                super.$ctor$1(javascript);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295133360);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295133360)
            
            //--TRIMMABLE-BOUNDARY-START(8590100656)
            /*Task<Stream> *//*async*/  GetImageFromCamera()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SI.Stream), $.$$.SI.Stream, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590100656);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = this.CallNativePlatform$7($.$$.SI.Stream, "GetImageFromCamera"), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590100656)
            
            //--TRIMMABLE-BOUNDARY-START(4297416104)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Client.ICameraProvider.GetImageFromCamera()
            LCFCC$ICameraProvider$GetImageFromCamera()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297416104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetImageFromCamera(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4297416104)
            
            static $h = 166064;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$vWqU.LCFCC.ICameraProvider); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590100656),
    {
      "r": $.$$.STT.Task$$($.$$.SI.Stream).$h,
      "n": "GetImageFromCamera",
      "d": 166064,
      "h": 8590100656,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(8590100656)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295133360),
    {
      "p": [
        {
          "n": "javascript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 166064,
      "h": 4295133360,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295133360)
  ],
  "h": 166064
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ICameraProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.NativeInteropServices.NativeInteropCameraProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}NativeInteropServices${separator}NativeInteropCameraProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(166064)
        
        

        //--TRIMMABLE-BOUNDARY-START(297136)
        $asm.$cls(`$TvJd.LCFWN.NativeInteropPermissionProvider`, ($self) => class NativeInteropPermissionProvider extends $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$fPer.LCFCS.IPlatformPermissionManager)
        {
            //--TRIMMABLE-BOUNDARY-START(4295264432)
            $ctor$2(/*IJavaScriptRunner*/ javascript)
            {
                super.$ctor$1(javascript);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295264432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295264432)
            
            //--TRIMMABLE-BOUNDARY-START(8590231728)
            /*Task<bool> *//*async*/  RequestPermission(/*params PlatformPermissionTypes[]*/ permissions)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590231728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = this.CallNativePlatform$5($.$typeArray($.$fPer.LCFCS.PlatformPermissionTypes), $.$$.S.Boolean, permissions, "RequestPermission"), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590231728)
            
            //--TRIMMABLE-BOUNDARY-START(4352739670)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Security.IPlatformPermissionManager.RequestPermission(params LivingThing.Core.Frameworks.Common.Security.PlatformPermissionTypes[])
            LCFCS$IPlatformPermissionManager$RequestPermission()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4352739670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RequestPermission(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4352739670)
            
            static $h = 297136;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$fPer.LCFCS.IPlatformPermissionManager); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590231728),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "permissions",
          "p": $.$typeArray($.$fPer.LCFCS.PlatformPermissionTypes).$h,
          "f": 16
        }
      ],
      "n": "RequestPermission",
      "d": 297136,
      "h": 8590231728,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(8590231728)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295264432),
    {
      "p": [
        {
          "n": "javascript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 297136,
      "h": 4295264432,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295264432)
  ],
  "h": 297136
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS.IPlatformPermissionManager ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.NativeInteropServices.NativeInteropPermissionProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}NativeInteropServices${separator}NativeInteropPermissionProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(297136)
        
        

        //--TRIMMABLE-BOUNDARY-START(231600)
        $asm.$cls(`$TvJd.LCFWN.NativeInteropLocationProvider`, ($self) => class NativeInteropLocationProvider extends $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$fPer.LCFCS$3.ILocationProvider)
        {
            //--TRIMMABLE-BOUNDARY-START(4295198896)
            $ctor$2(/*IJavaScriptRunner*/ javascript)
            {
                super.$ctor$1(javascript);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295198896);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295198896)
            
            //--TRIMMABLE-BOUNDARY-START(8590166192)
            /*ValueTask<GeoLocation> */ GetCurrentUserLocationAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590166192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CallNativePlatform$7($.$fPer.LCFCDG.GeoLocation, "GetCurrentUserLocationAsync");
            }
            //--TRIMMABLE-BOUNDARY-END(8590166192)
            
            //--TRIMMABLE-BOUNDARY-START(4356409686)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.ILocationProvider.GetCurrentUserLocationAsync()
            LCFCS$3$ILocationProvider$GetCurrentUserLocationAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356409686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCurrentUserLocationAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356409686)
            
            static $h = 231600;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$fPer.LCFCS$3.ILocationProvider); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590166192),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCDG.GeoLocation).$h,
      "n": "GetCurrentUserLocationAsync",
      "d": 231600,
      "h": 8590166192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590166192)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295198896),
    {
      "p": [
        {
          "n": "javascript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 231600,
      "h": 4295198896,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295198896)
  ],
  "h": 231600
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.ILocationProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.NativeInteropServices.NativeInteropLocationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}NativeInteropServices${separator}NativeInteropLocationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(231600)
        
        

        //--TRIMMABLE-BOUNDARY-START(428208)
        $asm.$cls(`$TvJd.LCFWN.NativeInteropShareProvider`, ($self) => class NativeInteropShareProvider extends $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$fPer.LCFCP.IPlatformShareManager)
        {
            //--TRIMMABLE-BOUNDARY-START(4295395504)
            $ctor$2(/*IJavaScriptRunner*/ javascript)
            {
                super.$ctor$1(javascript);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295395504);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295395504)
            
            //--TRIMMABLE-BOUNDARY-START(8590362800)
            /*ValueTask */ ShareAsync(/*string?*/ title, /*string?*/ text, /*Uri?*/ uri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590362800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CallNativePlatform$2($.$$.S.String, $.$$.S.String, $.$spu.S.Uri, title, text, uri, "ShareAsync");
            }
            //--TRIMMABLE-BOUNDARY-END(8590362800)
            
            //--TRIMMABLE-BOUNDARY-START(30118414678)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Platforms.IPlatformShareManager.ShareAsync(string?, string?, System.Uri?)
            LCFCP$IPlatformShareManager$ShareAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30118414678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ShareAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30118414678)
            
            static $h = 428208;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$fPer.LCFCP.IPlatformShareManager); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590362800),
    {
      "r": 181338113,
      "p": [
        {
          "n": "title",
          "p": 1310721
        },
        {
          "n": "text",
          "p": 1310721
        },
        {
          "n": "uri",
          "p": 1703938
        }
      ],
      "n": "ShareAsync",
      "d": 428208,
      "h": 8590362800,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590362800)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295395504),
    {
      "p": [
        {
          "n": "javascript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 428208,
      "h": 4295395504,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295395504)
  ],
  "h": 428208
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCP.IPlatformShareManager ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.NativeInteropServices.NativeInteropShareProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}NativeInteropServices${separator}NativeInteropShareProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(428208)
        
        

        //--TRIMMABLE-BOUNDARY-START(100528)
        $asm.$cls(`$TvJd.LCFWN.NativeInteropBrowser`, ($self) => class NativeInteropBrowser extends $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$fPer.LCFC.IBrowserWindow)
        {
            //--TRIMMABLE-BOUNDARY-START(4295067824)
            $ctor$2(/*IJavaScriptRunner*/ javascript)
            {
                super.$ctor$1(javascript);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295067824);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295067824)
            
            //--TRIMMABLE-BOUNDARY-START(8590035120)
            /*ValueTask */ Open(/*Uri*/ url, /*CancellationToken?*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590035120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CallNativePlatform$4($.$spu.S.Uri, $.$typeNullable($.$$.ST$1.CancellationToken), url, $.$clone(token), "Open");
            }
            //--TRIMMABLE-BOUNDARY-END(8590035120)
            
            //--TRIMMABLE-BOUNDARY-START(4341139798)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IBrowserWindow.Open(System.Uri, System.Threading.CancellationToken?)
            LCFC$IBrowserWindow$Open()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341139798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Open(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4341139798)
            
            static $h = 100528;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$fPer.LCFC.IBrowserWindow); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590035120),
    {
      "r": 181338113,
      "p": [
        {
          "n": "url",
          "p": 1703938
        },
        {
          "n": "token",
          "p": $.$typeNullable($.$$.ST$1.CancellationToken).$h,
          "f": 65
        }
      ],
      "n": "Open",
      "d": 100528,
      "h": 8590035120,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590035120)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295067824),
    {
      "p": [
        {
          "n": "javascript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 100528,
      "h": 4295067824,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295067824)
  ],
  "h": 100528
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IBrowserWindow ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.NativeInteropServices.NativeInteropBrowser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}NativeInteropServices${separator}NativeInteropBrowser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(100528)
        
        

        //--TRIMMABLE-BOUNDARY-START(493744)
        $asm.$cls(`$TvJd.LCFWN.NativeIntropLocationGeocoder`, ($self) => class NativeIntropLocationGeocoder extends $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$fPer.LCFCS$3.ILocationGeocoder)
        {
            //--TRIMMABLE-BOUNDARY-START(4295461040)
            $ctor$2(/*IJavaScriptRunner*/ javascript)
            {
                super.$ctor$1(javascript);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295461040);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295461040)
            
            //--TRIMMABLE-BOUNDARY-START(8590428336)
            /*Task<IEnumerable<GeoLocation>> *//*async*/  Geocode(/*string*/ address)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation)), $.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590428336);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = this.CallNativePlatform$5($.$$.S.String, $.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation), address, "Geocode"), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8590428336)
            
            //--TRIMMABLE-BOUNDARY-START(12885395632)
            /*Task<string?> *//*async*/  ReverseGeocode(/*GeoLocation*/ location)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.String), $.$$.S.String, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885395632);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t2 = this.CallNativePlatform$5($.$fPer.LCFCDG.GeoLocation, $.$$.S.String, location, "ReverseGeocode"), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885395632)
            
            //--TRIMMABLE-BOUNDARY-START(8651311446)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.ILocationGeocoder.ReverseGeocode(LivingThing.Core.Frameworks.Common.Data.Geographic.GeoLocation)
            LCFCS$3$ILocationGeocoder$ReverseGeocode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8651311446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReverseGeocode(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8651311446)
            
            //--TRIMMABLE-BOUNDARY-START(4356344150)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.ILocationGeocoder.Geocode(string)
            LCFCS$3$ILocationGeocoder$Geocode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356344150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Geocode(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356344150)
            
            static $h = 493744;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$TvJd.LCFWN.NativeInteropServiceBase$$($.$fPer.LCFCS$3.ILocationGeocoder); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590428336),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$fPer.LCFCDG.GeoLocation)).$h,
      "p": [
        {
          "n": "address",
          "p": 1310721
        }
      ],
      "n": "Geocode",
      "d": 493744,
      "h": 8590428336,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(8590428336),
//--TRIMMABLE-BOUNDARY-START(12885395632),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "p": [
        {
          "n": "location",
          "p": 13928790
        }
      ],
      "n": "ReverseGeocode",
      "d": 493744,
      "h": 12885395632,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12885395632)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295461040),
    {
      "p": [
        {
          "n": "javascript",
          "p": 64509610
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 493744,
      "h": 4295461040,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295461040)
  ],
  "h": 493744
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.ILocationGeocoder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.NativeInteropServices.NativeIntropLocationGeocoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}NativeInteropServices${separator}NativeIntropLocationGeocoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(493744)
        
        

        //--TRIMMABLE-BOUNDARY-START(886960)
        $asm.$cls(`$TvJd.LCFWS.WasmJavascriptLocalStorageService`, ($self) => class WasmJavascriptLocalStorageService extends $.$hDPm.LCFCS.JavascriptLocalStorageService
        {
            //--TRIMMABLE-BOUNDARY-START(4295854256)
            $ctor$2()
            {
                super.$ctor$1(null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295854256);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295854256)
            
            //--TRIMMABLE-BOUNDARY-START(12885788848)
            /*ValueTask<T> */ GetItem(T, /*string*/ key)
            {
                /*var*/ let item;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885788848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.storageCache ??= new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$fPer.LCFCS$1.Serialized))().$ctor$1();
                if (this.storageCache.TryGetValue(key, $.$ref(() => item, ($v) => item = $v, $.$fPer.LCFCS$1.Serialized)))
                {
                    if ($.$fPer.LCFCS$1.Serialized.op_Implicit$1(item) !== null)
                    {
                        try
                        {
                            /*var*/ let value = $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize(T, item, false, "GetItem", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.WebAssembly\\WasmJavascriptLocalStorageService.cs", "GetItem", 26);
                            return $.$$.STT.ValueTask.FromResult(T, value);
                        }
                        catch(e)
                        {
                            $.$$.SD.Debug.WriteLine$4(e.Message);
                            $.$$.SD.Debug.WriteLine$4(e.StackTrace);
                        }
                    }
                }
                else 
                {
                    item = $.$fPer.LCFCS$1.Serialized.op_Implicit$4(globalThis.localStorage.getItem(key));
                    this.storageCache.set_Item$1(key, $.$clone(item));
                    /*var*/ let result = $.$$.STT.ValueTask.FromResult(T, $.$fPer.LCFCS$1.JsonSerializeExtension.DeSerialize(T, item, false, "GetItem", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.WebAssembly\\WasmJavascriptLocalStorageService.cs", "GetItem", 40));
                    return result;
                }
                return $.$$.STT.ValueTask.FromResult(T, $.$default(T));
            }
            //--TRIMMABLE-BOUNDARY-END(12885788848)
            
            //--TRIMMABLE-BOUNDARY-START(21475723440)
            /*ValueTask */ SetItem(T, /*string*/ key, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475723440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.storageCache ??= new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$fPer.LCFCS$1.Serialized))().$ctor$1();
                /*var*/ let str = $.$fPer.LCFCS$1.JsonSerializeExtension.Serialize(T, value, true, false, true, false, false, false, false, "SetItem", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.WebAssembly\\WasmJavascriptLocalStorageService.cs", "SetItem", 49);
                this.storageCache.set_Item$1(key, $.$clone(str));
                globalThis.localStorage.setItem(key, str.Json);
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(21475723440)
            
            //--TRIMMABLE-BOUNDARY-START(17180756144)
            /*ValueTask */ RemoveItem(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180756144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.storageCache !== null)
                {
                    $.$$.SCG.CollectionExtensions.Remove($.$$.S.String, $.$fPer.LCFCS$1.Serialized, this.storageCache, key, $.$discardRef());
                }
                globalThis.localStorage.removeItem(key);
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(17180756144)
            
            //--TRIMMABLE-BOUNDARY-START(8590821552)
            /*ValueTask */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590821552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.storageCache?.Clear();
                globalThis.localStorage.clear();
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(8590821552)
            
            //--TRIMMABLE-BOUNDARY-START(4295854256)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295854256)
            
            static $h = 886960;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCS.JavascriptLocalStorageService; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885788848),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetItem",
      "d": 886960,
      "h": 12885788848,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(12885788848),
//--TRIMMABLE-BOUNDARY-START(21475723440),
    {
      "r": 181338113,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "SetItem",
      "d": 886960,
      "h": 21475723440,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(21475723440),
//--TRIMMABLE-BOUNDARY-START(17180756144),
    {
      "r": 181338113,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "RemoveItem",
      "d": 886960,
      "h": 17180756144,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180756144),
//--TRIMMABLE-BOUNDARY-START(8590821552),
    {
      "r": 181338113,
      "n": "Clear",
      "d": 886960,
      "h": 8590821552,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590821552)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295854256),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 886960,
      "h": 4295854256,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295854256)
  ],
  "h": 886960
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$5.IPersistentStorageService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.Services.WasmJavascriptLocalStorageService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}Services${separator}WasmJavascriptLocalStorageService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(886960)
        
        

        //--TRIMMABLE-BOUNDARY-START(952496)
        $asm.$cls(`$TvJd.LCFWS.WasmJavaScriptRunner`, ($self) => class WasmJavaScriptRunner extends $.$hDPm.LCFCS.JavaScriptRunner
        {
            //--TRIMMABLE-BOUNDARY-START(4295919792)
            $ctor$2(/*IJSRuntime*/ js)
            {
                super.$ctor$1(js, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295919792);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295919792)
            
            //--TRIMMABLE-BOUNDARY-START(8590887088)
            /*ValueTask */ Queue(/*Func<IJSRuntime, ValueTask>*/ action, /*bool*/ throwIfNotReady)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590887088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return action.Invoke(this.JavaScript);
            }
            //--TRIMMABLE-BOUNDARY-END(8590887088)
            
            //--TRIMMABLE-BOUNDARY-START(17180821680)
            /*ValueTask<T> */ Queue$2(T, /*Func<IJSRuntime, ValueTask<T>>*/ action, /*bool*/ throwIfNotReady)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180821680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return action.Invoke(this.JavaScript);
            }
            //--TRIMMABLE-BOUNDARY-END(17180821680)
            
            //--TRIMMABLE-BOUNDARY-START(12885854384)
            /*ValueTask */ Queue$1(/*string*/ method, /*params object?[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885854384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFC.Performance.MeasureValueAsync(new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this,  () =>
                {
                    if (method === "window.lt.localStorage.setItem" || method === "localStorage.setItem")
                    {
                        globalThis.localStorage.setItem($.$cast($.$$.System.Array.$ReadT1.call(parameters, 0), $.$$.S.String), $.$cast($.$$.System.Array.$ReadT1.call(parameters, 1), $.$$.S.String));
                        return $.$$.STT.ValueTask.CompletedTask;
                    }
                    else if (method === "window.lt.localStorage.removeItem" || method === "localStorage.removeItem")
                    {
                        globalThis.localStorage.removeItem($.$cast($.$$.System.Array.$ReadT1.call(parameters, 0), $.$$.S.String));
                        return $.$$.STT.ValueTask.CompletedTask;
                    }
                    $.$mj.MJ.JSInProcessRuntimeExtensions.InvokeVoid(($.$cast(this.JavaScript, $.$mj.MJ.IJSInProcessRuntime)), $.$$.S.String.StartsWith$3.call(method, "window.") ? method : ("window.lt." + $.$strNN(method)), parameters);
                    return $.$$.STT.ValueTask.CompletedTask;
                }, $weAQUc ??= {"r":181338113,"n":"","d":952496,"h":0,"f":17825794}), 0, method, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.WebAssembly\\WasmJavaScriptRunner.cs", "Queue", 32);
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12885854384)
            
            //--TRIMMABLE-BOUNDARY-START(21475788976)
            /*ValueTask<T> */ Queue$3(T, /*string*/ method, /*params object?[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475788976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFC.Performance.Measure$1($.$$.STT.ValueTask$$(T), new ($.$$.S.Func$$($.$$.STT.ValueTask$$(T)))().$ctor(this,  () =>
                {
                    if (method === "window.lt.localStorage.getItem" || method === "localStorage.getItem")
                    {
                        return $.$$.STT.ValueTask.FromResult(T, $.$cast(globalThis.localStorage.getItem($.$cast($.$$.System.Array.$ReadT1.call(parameters, 0), $.$$.S.String)), T));
                    }
                    /*var*/ let result = ($.$cast(this.JavaScript, $.$mj.MJ.IJSInProcessRuntime)).MJ$IJSInProcessRuntime$Invoke(T, $.$$.S.String.StartsWith$3.call(method, "window.") ? method : ("window.lt." + $.$strNN(method)), parameters);
                    return $.$$.STT.ValueTask.FromResult(T, result);
                }, $mWauRi ??= {"r":(T) => $.$$.STT.ValueTask$$(T).$h,"n":"","d":952496,"h":0,"f":17825794}), 0, "JSQueue: " + $.$strNN(method), "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Frameworks.WebAssembly\\WasmJavaScriptRunner.cs", "Queue", 56);
            }
            //--TRIMMABLE-BOUNDARY-END(21475788976)
            
            static $h = 952496;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCS.JavaScriptRunner; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590887088),
    {
      "r": 181338113,
      "p": [
        {
          "n": "action",
          "p": $.$$.S.Func$$$($.$mj.MJ.IJSRuntime, $.$$.STT.ValueTask).$h
        },
        {
          "n": "throwIfNotReady",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "Queue",
      "d": 952496,
      "h": 8590887088,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590887088),
//--TRIMMABLE-BOUNDARY-START(17180821680),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "action",
          "p": (T) => $.$$.S.Func$$$($.$mj.MJ.IJSRuntime, $.$$.STT.ValueTask$$(T)).$h
        },
        {
          "n": "throwIfNotReady",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "g": [
        "T"
      ],
      "n": "Queue",
      "o": "@$2",
      "d": 952496,
      "h": 17180821680,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(17180821680),
//--TRIMMABLE-BOUNDARY-START(12885854384),
    {
      "r": 181338113,
      "p": [
        {
          "n": "method",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "Queue",
      "o": "@$1",
      "d": 952496,
      "h": 12885854384,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885854384),
//--TRIMMABLE-BOUNDARY-START(21475788976),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "method",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "Queue",
      "o": "@$3",
      "d": 952496,
      "h": 21475788976,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(21475788976)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295919792),
    {
      "p": [
        {
          "n": "js",
          "p": 524402
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 952496,
      "h": 4295919792,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295919792)
  ],
  "h": 952496
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCI.IJavaScriptRunner, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.Services.WasmJavaScriptRunner`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}Services${separator}WasmJavaScriptRunner`; }
        });
        //--TRIMMABLE-BOUNDARY-END(952496)
        
        

        //--TRIMMABLE-BOUNDARY-START(1018032)
        $asm.$cls(`$TvJd.LCFWS.WasmPathRegexComparer`, ($self) => class WasmPathRegexComparer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590952624)
            /*bool */ Equals$2(/*string?*/ x, /*string?*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590952624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$str.STR.Regex.Match$4(x, y).Success;
            }
            //--TRIMMABLE-BOUNDARY-END(8590952624)
            
            //--TRIMMABLE-BOUNDARY-START(12885919920)
            /*int */ GetHashCode$1(/*string*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885919920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.GetHashCode.call(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(12885919920)
            
            //--TRIMMABLE-BOUNDARY-START(4355457025)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<string>.Equals(string?, string?)
            SCG$IEqualityComparer$System$String$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355457025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355457025)
            
            //--TRIMMABLE-BOUNDARY-START(8650424321)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<string>.GetHashCode(string)
            SCG$IEqualityComparer$System$String$GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8650424321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHashCode$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8650424321)
            
            //--TRIMMABLE-BOUNDARY-START(4295985328)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295985328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295985328)
            
            //--TRIMMABLE-BOUNDARY-START(4295985328)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295985328)
            
            static $h = 1018032;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590952624),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": 1310721
        },
        {
          "n": "y",
          "p": 1310721
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1018032,
      "h": 8590952624,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590952624),
//--TRIMMABLE-BOUNDARY-START(12885919920),
    {
      "r": 655361,
      "p": [
        {
          "n": "obj",
          "p": 1310721
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 1018032,
      "h": 12885919920,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885919920)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295985328),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1018032,
      "h": 4295985328,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295985328)
  ],
  "h": 1018032
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IEqualityComparer$$($.$$.S.String) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Frameworks.WebAssembly.Services.WasmPathRegexComparer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Frameworks${separator}WebAssembly${separator}Services${separator}WasmPathRegexComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1018032)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.JSInterop.WebAssembly", "NetJs.Microsoft.AspNetCore.Components.WebAssembly", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.ServiceProvider"));
})();
//--TRIMMABLE-BOUNDARY-END(34992)
