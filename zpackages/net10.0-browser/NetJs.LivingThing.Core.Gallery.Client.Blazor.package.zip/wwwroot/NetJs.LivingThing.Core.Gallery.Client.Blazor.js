
//--TRIMMABLE-BOUNDARY-START(57083)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $lJUR, $qgEF) {
    "use strict";
    let _;
    let $FOuGuc;
    let $PoQcaa;
    let $klrPol;
    let $Amyewg;
    let $kOjPoc;
    let $MZHXrd;
    let $XgISEg;
    let $pbjPBb;
    let $UUnNkd;
    let $gDzmTf;
    let $YOUUOi;
    let $oFbQIb;
    let $Zcawnj;
    let $gXgCli;
    let $mZOfya;
    let $bPsiYf;
    let $HqgUEe;
    let $Lfsyed;
    let $lJkbll;
    let $pwZEof;
    let $ZLUGrd;
    let $YLEtai;
    let $hRigYb;
    let $tFookh;
    let $DYUtka;
    let $WzzTNk;
    let $BMjZDc;
    let $pQRIgg;
    let $ADbmkh;
    let $HpgJPe;
    let $RGISGh;
    let $pYLglg;
    let $OQQnve;
    let $wWOnHi;
    let $EEKGoa;
    let $ORLbrk;
    let $oBdSRe;
    let $wTuooe;
    let $uzdWEc;
    let $SxeEFj;
    let $kmNvha;
    let $SsZYOk;
    let $xHJwMb;
    let $EzBKYe;
    let $Ajrymd;
    let $dIQAWc;
    let $HoUith;
    let $yQapHi;
    let $bzHYlc;
    let $cJIrle;
    let $rTMJbb;
    let $vfLHJf;
    let $YcmSqk;
    let $PIjske;
    let $tYesBd;
    let $SNGGHf;
    let $BZCcJg;
    let $njAvol;
    let $tLshrd;
    let $mtFVGh;
    let $QjljXa;
    let $usqvZj;
    let $zCOuli;
    let $SEEYpe;
    let $RuqNfl;
    let $rZurGg;
    let $TOFKVj;
    let $kufiti;
    let $DtYGBb;
    let $eoySQh;
    let $aAcjPg;
    let $CxxCac;
    let $ItAgkf;
    let $aALrqk;
    let $vDGTVk;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Gallery.Client.Blazor", 
    {
  "h": 57083,
  "f": "LivingThing.Core.Gallery.Client.Blazor",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Gallery.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Gallery.Client.Blazor",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(581371)
        $asm.$cls(`$SAWq.LCGC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590515963)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590515963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$SAWq.LCGCP.GalleryCategory, "LivingThing.Core.Gallery.Client", "Pages\\GalleryCategory", "Gallery Category", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Gallery/{CategoryName}" ], null, null), null);
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$SAWq.LCGCP.GalleryHome, "LivingThing.Core.Gallery.Client", "Pages\\GalleryHome", "Gallery Home", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/Gallery" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8590515963)
            
            //--TRIMMABLE-BOUNDARY-START(4295548667)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295548667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295548667)
            
            //--TRIMMABLE-BOUNDARY-START(4295548667)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295548667)
            
            static $h = 581371;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590515963),
    {
      "r": 65537,
      "n": "Build",
      "d": 581371,
      "h": 8590515963,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590515963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295548667),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 581371,
      "h": 4295548667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295548667)
  ],
  "h": 581371
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(581371)
        
        

        //--TRIMMABLE-BOUNDARY-START(450299)
        $asm.$cls(`$SAWq.LCGC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295417595)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295417595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$SAWq.LCGC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295417595)
            
            static $h = 450299;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295417595),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 450299,
      "h": 4295417595,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295417595)
  ],
  "h": 450299
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(450299)
        
        

        //--TRIMMABLE-BOUNDARY-START(188155)
        $asm.$cls(`$SAWq._LCGCSG$1.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295155451)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg1, /*int*/ __seq2, /*global::System.Int32*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295155451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq2, "PadContent", $.$box(__arg2, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq3, "ChildContent", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295155451)
            
            static $h = 188155;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295155451),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 14505642
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 655361
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 188155,
      "h": 4295155451,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295155451)
  ],
  "h": 188155
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Gallery.Client.Shared.GalleryCategory.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryCategory${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(188155)
        
        

        //--TRIMMABLE-BOUNDARY-START(253691)
        $asm.$cls(`$SAWq._LCGCSG$2.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295220987)
            static /*void */ CreateEditable_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*TValue*/ __arg1, /*int*/ __seq2, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg2, /*int*/ __seq3, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295220987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Tag", __arg0);
                __builder.AddComponentParameter(__seq1, "Value", $.$box(__arg1, TValue));
                __builder.AddComponentParameter(__seq2, "ValueChanged", __arg2);
                __builder.AddComponentParameter(__seq3, "ValueExpression", __arg3);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295220987)
            
            //--TRIMMABLE-BOUNDARY-START(8590188283)
            static /*void */ CreateEditable_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590188283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Tag", __arg0);
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590188283)
            
            static $h = 253691;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295220987),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_0",
      "d": 253691,
      "h": 4295220987,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295220987),
//--TRIMMABLE-BOUNDARY-START(8590188283),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_1",
      "d": 253691,
      "h": 8590188283,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590188283)
  ],
  "h": 253691
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Gallery.Client.Shared.GalleryCategoryCard.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryCategoryCard${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(253691)
        
        

        //--TRIMMABLE-BOUNDARY-START(122619)
        $asm.$cls(`$SAWq._LCGCSG.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295089915)
            static /*void */ CreateEditable_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Boolean?*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*TValue*/ __arg2, /*int*/ __seq3, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg3, /*int*/ __seq4, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295089915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Enable", $.$box(__arg0, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq1, "PlaceHolder", __arg1);
                __builder.AddComponentParameter(__seq2, "Value", $.$box(__arg2, TValue));
                __builder.AddComponentParameter(__seq3, "ValueChanged", __arg3);
                __builder.AddComponentParameter(__seq4, "ValueExpression", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295089915)
            
            static $h = 122619;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295089915),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": $.$typeNullable($.$$.S.Boolean).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_0",
      "d": 122619,
      "h": 4295089915,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295089915)
  ],
  "h": 122619
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Gallery.Client.Shared.GalleryCategoriesCarousel.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryCategoriesCarousel${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(122619)
        
        

        //--TRIMMABLE-BOUNDARY-START(319227)
        $asm.$cls(`$SAWq._LCGCSG$3.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295286523)
            static /*void */ CreateEditable_0(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*global::System.Boolean?*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295286523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Tag", __arg0);
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "Enable", $.$box(__arg2, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295286523)
            
            //--TRIMMABLE-BOUNDARY-START(8590253819)
            static /*void */ CreateEditable_1(TValue, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*global::System.String*/ __arg1, /*int*/ __seq2, /*global::System.Boolean?*/ __arg2, /*int*/ __seq3, /*TValue*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.EventCallback<TValue>*/ __arg4, /*int*/ __seq5, /*global::System.Linq.Expressions.Expression<global::System.Func<TValue>>*/ __arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590253819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCE.Editable$$(TValue), seq);
                __builder.AddComponentParameter(__seq0, "Tag", __arg0);
                __builder.AddComponentParameter(__seq1, "Class", __arg1);
                __builder.AddComponentParameter(__seq2, "Enable", $.$box(__arg2, $.$$.S.Boolean));
                __builder.AddComponentParameter(__seq3, "Value", $.$box(__arg3, TValue));
                __builder.AddComponentParameter(__seq4, "ValueChanged", __arg4);
                __builder.AddComponentParameter(__seq5, "ValueExpression", __arg5);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590253819)
            
            static $h = 319227;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295286523),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": $.$typeNullable($.$$.S.Boolean).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_0",
      "d": 319227,
      "h": 4295286523,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295286523),
//--TRIMMABLE-BOUNDARY-START(8590253819),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 1310721
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": $.$typeNullable($.$$.S.Boolean).$h
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (TValue) => $.$mac.MAC.EventCallback$$(TValue).$h
        },
        {
          "n": "__seq5",
          "p": 655361
        },
        {
          "n": "__arg5",
          "p": (TValue) => $.$sle.SLE.Expression$$($.$$.S.Func$$(TValue)).$h
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "CreateEditable_1",
      "d": 319227,
      "h": 8590253819,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590253819)
  ],
  "h": 319227
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.Gallery.Client.Shared.GalleryCollage.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryCollage${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(319227)
        
        

        //--TRIMMABLE-BOUNDARY-START(515835)
        $asm.$cls(`$SAWq.LCGC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180385019)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCP.GalleryCategory.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCP.GalleryCategory().$ctor$3();
                    }, $Lfsyed ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCP.GalleryHome.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCP.GalleryHome().$ctor$3();
                    }, $lJkbll ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCS.GalleryBrowser.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCS.GalleryBrowser().$ctor$3();
                    }, $pwZEof ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCS.GalleryCategories.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCS.GalleryCategories().$ctor$3();
                    }, $ZLUGrd ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCS.GalleryCategoriesCarousel.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCS.GalleryCategoriesCarousel().$ctor$4();
                    }, $YLEtai ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCS.GalleryCategory.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCS.GalleryCategory().$ctor$3();
                    }, $hRigYb ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCS.GalleryCategoryCard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCS.GalleryCategoryCard().$ctor$3();
                    }, $tFookh ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCS.GalleryCollage.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCS.GalleryCollage().$ctor$3();
                    }, $DYUtka ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCS.GalleryImageCard.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCS.GalleryImageCard().$ctor$3();
                    }, $WzzTNk ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCS.GalleryLayout.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCS.GalleryLayout().$ctor$3();
                    }, $BMjZDc ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$SAWq.LCGCS.GalleryToolBar.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$SAWq.LCGCS.GalleryToolBar().$ctor$3();
                    }, $pQRIgg ??= {"r":2752627,"n":"","d":515835,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180385019)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4295483131)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295483131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295483131)
            
            //--TRIMMABLE-BOUNDARY-START(4295483131)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295483131)
            
            static $h = 515835;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180385019),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885417723,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 515835,
      "h": 17180385019,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180385019)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295483131),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 515835,
      "h": 4295483131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295483131)
  ],
  "h": 515835
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(515835)
        
        

        //--TRIMMABLE-BOUNDARY-START(1367803)
        $asm.$cls(`$SAWq.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296335099)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296335099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296335099)
            
            //--TRIMMABLE-BOUNDARY-START(4296335099)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296335099)
            
            static $h = 1367803;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296335099),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1367803,
      "h": 4296335099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296335099)
  ],
  "h": 1367803
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1367803)
        
        

        //--TRIMMABLE-BOUNDARY-START(1433339)
        $asm.$cls(`$SAWq.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296400635)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296400635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296400635)
            
            //--TRIMMABLE-BOUNDARY-START(4296400635)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296400635)
            
            static $h = 1433339;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296400635),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1433339,
      "h": 4296400635,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296400635)
  ],
  "h": 1433339,
  "a": [
    {
      "t": 1367803,
      "c": 4296335099
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1433339)
        
        

        //--TRIMMABLE-BOUNDARY-START(384763)
        $asm.$cls(`$SAWq.LCGC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590319355)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590319355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590319355)
            
            //--TRIMMABLE-BOUNDARY-START(4295352059)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295352059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295352059)
            
            //--TRIMMABLE-BOUNDARY-START(4295352059)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295352059)
            
            static $h = 384763;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590319355),
    {
      "r": 65537,
      "n": "Execute",
      "d": 384763,
      "h": 8590319355,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590319355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295352059),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 384763,
      "h": 4295352059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295352059)
  ],
  "h": 384763
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(384763)
        
        

        //--TRIMMABLE-BOUNDARY-START(843515)
        $asm.$cls(`$SAWq.LCGCS.GalleryCategories`, ($self) => class GalleryCategories extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(77310254843)
            /*bool*/ UseSlider = false;
            //--TRIMMABLE-BOUNDARY-END(77310254843)
            
            //--TRIMMABLE-BOUNDARY-START(21475679995)
            /*GalleryDescriptor*/ Descriptor;
            //--TRIMMABLE-BOUNDARY-END(21475679995)
            
            //--TRIMMABLE-BOUNDARY-START(51540451067)
            /*string */ get OptimizedComponentName()
            {
                return "gallerycategories";
            }
            //--TRIMMABLE-BOUNDARY-END(51540451067)
            
            //--TRIMMABLE-BOUNDARY-START(73015287547)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015287547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "UseSlider":
                    this.UseSlider = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                    case "Descriptor":
                    this.Descriptor = $.$cast(parameter.Value, $.$qgEF.LCGCM.GalleryDescriptor);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(73015287547)
            
            //--TRIMMABLE-BOUNDARY-START(17180712699)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180712699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$qgEF.LCGCM.GalleryItemModel), 0);
                __builder.AddComponentParameter(1, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 33554432n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(2, "PadContent", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2), $.$$.S.Int32));
                __builder.AddAttribute$3(3, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$macw.MACR$2.NavLink, 4);
                        __builder2.AddComponentParameter(5, "href", `/Gallery/${$.$strNN(context.Model.Name)}`);
                        __builder2.AddComponentParameter(6, "class", "clickable");
                        __builder2.AddAttribute$3(7, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$SAWq.LCGCS.GalleryCategoryCard, 8);
                            __builder3.AddComponentParameter(9, "Category", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel)).op_Implicit$1(context)));
                            __builder3.AddComponentParameter(10, "Class", "wx-2 hx-2");
                            __builder3.CloseComponent();
                        }), $gXgCli ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":843515,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $mZOfya ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":843515,"h":0,"f":17825794});
                }), $bPsiYf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel)).$h}],"n":"","d":843515,"h":0,"f":17825794}));
                __builder.AddAttribute$3(11, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 12);
                    __builder2.AddComponentParameter(13, "Message", "No categories yet");
                    __builder2.CloseComponent();
                }), $HqgUEe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":843515,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17180712699)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885745403)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885745403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885745403)
            
            //--TRIMMABLE-BOUNDARY-START(12885745403)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885745403)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475679995)
                this.Descriptor = $.$default($.$qgEF.LCGCM.GalleryDescriptor);
                //--TRIMMABLE-BOUNDARY-END(21475679995)
                
            }
            static $h = 843515;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310254843),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245483771,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720320251,
        "f": 83886081
      },
      "n": "UseSlider",
      "d": 843515,
      "h": 77310254843,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310254843),
//--TRIMMABLE-BOUNDARY-START(21475679995),
    {
      "p": 99910,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065614587,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130385659,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 843515,
      "h": 21475679995,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475679995),
//--TRIMMABLE-BOUNDARY-START(51540451067),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655549179,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 843515,
      "h": 51540451067,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540451067)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015287547),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 843515,
      "h": 73015287547,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015287547),
//--TRIMMABLE-BOUNDARY-START(17180712699),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 843515,
      "h": 17180712699,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180712699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885745403),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 843515,
      "h": 12885745403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885745403)
  ],
  "h": 843515
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Shared.GalleryCategories`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryCategories`; }
        });
        //--TRIMMABLE-BOUNDARY-END(843515)
        
        

        //--TRIMMABLE-BOUNDARY-START(1171195)
        $asm.$cls(`$SAWq.LCGCS.GalleryImageCard`, ($self) => class GalleryImageCard extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(34360909563)
            /*GalleryItemModel*/ Media = null;
            //--TRIMMABLE-BOUNDARY-END(34360909563)
            
            //--TRIMMABLE-BOUNDARY-START(38655876859)
            /*string */ get OptimizedComponentName()
            {
                return "galleryimagecard";
            }
            //--TRIMMABLE-BOUNDARY-END(38655876859)
            
            //--TRIMMABLE-BOUNDARY-START(51540778747)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540778747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Media":
                    this.Media = $.$cast(parameter.Value, $.$qgEF.LCGCM.GalleryItemModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(51540778747)
            
            //--TRIMMABLE-BOUNDARY-START(12886073083)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886073083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$4.Position, 0);
                __builder.AddComponentParameter(1, "Relative", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                __builder.AddComponentParameter(2, "Class", "hf flex mihx-1 display clickable");
                __builder.AddComponentParameter(3, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.AllAttributes()));
                __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCP$4.At, 5);
                    __builder2.AddComponentParameter(6, "X", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCP$4.PositionX, 2/*PositionX.LeftToLeft*/), $.$hDPm.LCFCCP$4.PositionX));
                    __builder2.AddComponentParameter(7, "Y", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCP$4.PositionY, 4/*PositionY.BottomToBottom*/), $.$hDPm.LCFCCP$4.PositionY));
                    __builder2.AddComponentParameter(8, "Class", "bg-tb-transparent-dark cl-white wp-100 pd stack fade-in-hover");
                    __builder2.AddAttribute$3(9, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenElement(10, "b");
                        __builder3.AddContent$4(11, this.Media.Name);
                        __builder3.CloseElement();
                        __builder3.AddMarkupContent(12, "\r\n        ");
                        __builder3.OpenElement(13, "em");
                        __builder3.AddAttribute$5(14, "class", "d-block fsz-small op-7");
                        __builder3.AddContent$4(15, this.Media.Description);
                        __builder3.CloseElement();
                    }), $PoQcaa ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1171195,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(16, "\r\n    ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 17);
                    __builder2.AddComponentParameter(18, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Media.Path));
                    __builder2.AddComponentParameter(19, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ & ~2/*MediaFeatures.HeightResponsive*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                    __builder2.AddComponentParameter(20, "Class", "mg-a");
                    __builder2.CloseComponent();
                }), $klrPol ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1171195,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12886073083)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591105787)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591105787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591105787)
            
            //--TRIMMABLE-BOUNDARY-START(8591105787)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591105787)
            
            static $h = 1171195;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360909563),
    {
      "p": 165446,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476007675,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245811451,
        "f": 83886081
      },
      "n": "Media",
      "d": 1171195,
      "h": 34360909563,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360909563),
//--TRIMMABLE-BOUNDARY-START(38655876859),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065942267,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1171195,
      "h": 38655876859,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655876859)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540778747),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1171195,
      "h": 51540778747,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540778747),
//--TRIMMABLE-BOUNDARY-START(12886073083),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1171195,
      "h": 12886073083,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886073083)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591105787),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1171195,
      "h": 8591105787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591105787)
  ],
  "h": 1171195
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Shared.GalleryImageCard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryImageCard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1171195)
        
        

        //--TRIMMABLE-BOUNDARY-START(974587)
        $asm.$cls(`$SAWq.LCGCS.GalleryCategory`, ($self) => class GalleryCategory extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21475811067)
            /*GalleryDescriptor*/ Descriptor;
            //--TRIMMABLE-BOUNDARY-END(21475811067)
            
            //--TRIMMABLE-BOUNDARY-START(77310385915)
            /*bool*/ UseSlider = false;
            //--TRIMMABLE-BOUNDARY-END(77310385915)
            
            //--TRIMMABLE-BOUNDARY-START(51540582139)
            /*string */ get OptimizedComponentName()
            {
                return "gallerycategory";
            }
            //--TRIMMABLE-BOUNDARY-END(51540582139)
            
            //--TRIMMABLE-BOUNDARY-START(73015418619)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015418619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Descriptor":
                    this.Descriptor = $.$cast(parameter.Value, $.$qgEF.LCGCM.GalleryDescriptor);
                    return true;
                    case "UseSlider":
                    this.UseSlider = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(73015418619)
            
            //--TRIMMABLE-BOUNDARY-START(17180843771)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180843771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.AddMarkupContent(0, "<div class=\"pd\"><h2 class=\"mg-0\">Category Name</h2></div>\r\n");
                $.$SAWq._LCGCSG$1.TypeInference.CreateDataList_0($.$$.S.Int32, __builder, 1, 2, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), [1, 2, 3, 4, 5, 6, 7, 8, 9], null, null), 3, 35184372092928n | 33554432n, 4, 2, 5, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Int32, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.Int32))))().$ctor(this,  (/**/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 6);
                        __builder2.AddComponentParameter(7, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ | 2/*CardFeatures.Corner*/), $.$hDPm.LCFCCC$1.CardFeatures));
                        __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(9, "div");
                            __builder3.AddAttribute$5(10, "class", "row");
                            __builder3.OpenElement(11, "div");
                            __builder3.AddAttribute$5(12, "class", "col-a");
                            __builder3.OpenElement(13, "div");
                            __builder3.AddAttribute$5(14, "class", "wx-02 hx-02 round clip");
                            __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 15);
                            __builder3.AddComponentParameter(16, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, (($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Int32, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.Int32)).op_Implicit$1(context) & 1) === 0) ? "https://images.pexels.com/photos/490466/pexels-photo-490466.jpeg" : "https://images.pexels.com/photos/33109/fall-autumn-red-season.jpg"));
                            __builder3.AddComponentParameter(17, "Class", "mg-a");
                            __builder3.CloseComponent();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(18, "\r\n            ");
                            __builder3.OpenElement(19, "div");
                            __builder3.AddAttribute$5(20, "class", "col-10 flex");
                            __builder3.OpenElement(21, "b");
                            __builder3.AddAttribute$5(22, "class", "mgl mgy-a nowrap");
                            __builder3.AddContent$4(23, "Category ");
                            __builder3.AddContent$3(24, context);
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }), $Amyewg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":974587,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $kOjPoc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":974587,"h":0,"f":17825794});
                }, $MZHXrd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$$.S.Int32, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$$.S.Int32)).$h}],"n":"","d":974587,"h":0,"f":17825794}));
                __builder.AddMarkupContent(25, "\r\n");
                __builder.OpenComponent$1($.$SAWq.LCGCS.GalleryCollage, 26);
                __builder.AddComponentParameter(27, "Descriptor", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$qgEF.LCGCM.GalleryDescriptor, $.$clone(this.Descriptor)));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17180843771)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885876475)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885876475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885876475)
            
            //--TRIMMABLE-BOUNDARY-START(12885876475)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12885876475)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475811067)
                this.Descriptor = $.$default($.$qgEF.LCGCM.GalleryDescriptor);
                //--TRIMMABLE-BOUNDARY-END(21475811067)
                
            }
            static $h = 974587;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475811067),
    {
      "p": 99910,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065745659,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130516731,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 974587,
      "h": 21475811067,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475811067),
//--TRIMMABLE-BOUNDARY-START(77310385915),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245614843,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720451323,
        "f": 83886081
      },
      "n": "UseSlider",
      "d": 974587,
      "h": 77310385915,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310385915),
//--TRIMMABLE-BOUNDARY-START(51540582139),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655680251,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 974587,
      "h": 51540582139,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540582139)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015418619),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 974587,
      "h": 73015418619,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015418619),
//--TRIMMABLE-BOUNDARY-START(17180843771),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 974587,
      "h": 17180843771,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180843771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885876475),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 974587,
      "h": 12885876475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885876475)
  ],
  "h": 974587
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Shared.GalleryCategory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryCategory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(974587)
        
        

        //--TRIMMABLE-BOUNDARY-START(712443)
        $asm.$cls(`$SAWq.LCGCP.GalleryHome`, ($self) => class GalleryHome extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21475548923)
            /*string */ get OptimizedComponentName()
            {
                return "galleryhome";
            }
            //--TRIMMABLE-BOUNDARY-END(21475548923)
            
            //--TRIMMABLE-BOUNDARY-START(8590647035)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590647035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$SAWq.LCGCS.GalleryLayout, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddMarkupContent(2, "<div class=\"pd\"><h2 class=\"mgb-0\">Welcome to SIT Gallery</h2>\r\n        <p>At SIT, most of our solutions are built by us. Here we try to share our moments of such development with you.</p>\r\n        <p>Enjoy!!!</p></div>\r\n    ");
                    __builder2.OpenComponent$1($.$SAWq.LCGCS.GalleryCategoriesCarousel, 3);
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(4, "\r\n    ");
                    __builder2.AddMarkupContent(5, "<div class=\"pd\"><h2>Categories</h2></div>\r\n    ");
                    __builder2.OpenComponent$1($.$SAWq.LCGCS.GalleryCategories, 6);
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(7, "\r\n    ");
                    __builder2.AddMarkupContent(8, "<div class=\"pd\"><h2>Favorites</h2></div>\r\n    ");
                    __builder2.OpenComponent$1($.$SAWq.LCGCS.GalleryCollage, 9);
                    __builder2.CloseComponent();
                }), $FOuGuc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":712443,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8590647035)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4295679739)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295679739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295679739)
            
            //--TRIMMABLE-BOUNDARY-START(4295679739)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295679739)
            
            static $h = 712443;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475548923),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180581627,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 712443,
      "h": 21475548923,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475548923)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590647035),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 712443,
      "h": 8590647035,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590647035)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295679739),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 712443,
      "h": 4295679739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295679739)
  ],
  "h": 712443,
  "a": [
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Gallery",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Pages.GalleryHome`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Pages${separator}GalleryHome`; }
        });
        //--TRIMMABLE-BOUNDARY-END(712443)
        
        

        //--TRIMMABLE-BOUNDARY-START(1040123)
        $asm.$cls(`$SAWq.LCGCS.GalleryCategoryCard`, ($self) => class GalleryCategoryCard extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(17180909307)
            /*GalleryItemModel*/ Category = null;
            //--TRIMMABLE-BOUNDARY-END(17180909307)
            
            //--TRIMMABLE-BOUNDARY-START(38655745787)
            /*string */ get OptimizedComponentName()
            {
                return "gallerycategorycard";
            }
            //--TRIMMABLE-BOUNDARY-END(38655745787)
            
            //--TRIMMABLE-BOUNDARY-START(51540647675)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540647675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Category":
                    this.Category = $.$cast(parameter.Value, $.$qgEF.LCGCM.GalleryItemModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(51540647675)
            
            //--TRIMMABLE-BOUNDARY-START(12885942011)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885942011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 0);
                __builder.AddComponentParameter(1, "Class", "mihx-2 miwx-2");
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ & ~16/*CardFeatures.Pad*/), $.$hDPm.LCFCCC$1.CardFeatures));
                __builder.AddComponentParameter(3, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.AllAttributes()));
                __builder.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCP$4.Position, 5);
                    __builder2.AddComponentParameter(6, "Relative", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                    __builder2.AddComponentParameter(7, "Class", "hf flex");
                    __builder2.AddAttribute$3(8, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCP$4.At, 9);
                        __builder3.AddComponentParameter(10, "X", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCP$4.PositionX, 2/*PositionX.LeftToLeft*/), $.$hDPm.LCFCCP$4.PositionX));
                        __builder3.AddComponentParameter(11, "Y", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCP$4.PositionY, 4/*PositionY.BottomToBottom*/), $.$hDPm.LCFCCP$4.PositionY));
                        __builder3.AddComponentParameter(12, "Class", "bg-dark-05 wp-100 pd");
                        __builder3.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                        {
                            $.$SAWq._LCGCSG$2.TypeInference.CreateEditable_0($.$$.S.String, __builder4, 14, 15, "b", 16, this.Category.Name, 17, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/**/ __value) =>
                            {
                                return this.Category.Name = __value;
                            }, $OQQnve ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1040123,"h":0,"f":17825794}), this.Category.Name)), 18, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Category"), "Name"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $wWOnHi ??= {"r":38797349,"n":"","d":1040123,"h":0,"f":17825794})).Invoke()));
                            __builder4.AddMarkupContent(19, "\r\n            ");
                            __builder4.OpenElement(20, "small");
                            __builder4.AddAttribute$5(21, "class", "f-right text-italic d-block");
                            __builder4.AddContent$3(22, $.$box(this.Category.Contents, $.$$.S.Int32));
                            __builder4.AddContent$4(23, " pictures");
                            __builder4.CloseElement();
                            __builder4.AddMarkupContent(24, "\r\n            ");
                            $.$SAWq._LCGCSG$2.TypeInference.CreateEditable_1($.$$.S.String, __builder4, 25, 26, "small", 27, "d-block mgt", 28, this.Category.Description, 29, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/**/ __value) =>
                            {
                                return this.Category.Description = __value;
                            }, $EEKGoa ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1040123,"h":0,"f":17825794}), this.Category.Description)), 30, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                            {
                                return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "Category"), "Description"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                            }, $ORLbrk ??= {"r":38797349,"n":"","d":1040123,"h":0,"f":17825794})).Invoke()));
                        }), $oBdSRe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1040123,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                        __builder3.AddMarkupContent(31, "\r\n        ");
                        __builder3.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 32);
                        __builder3.AddComponentParameter(33, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Category.ImagePath));
                        __builder3.AddComponentParameter(34, "Class", "mg-a");
                        __builder3.CloseComponent();
                    }), $wTuooe ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1040123,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $uzdWEc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1040123,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12885942011)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8590974715)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590974715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590974715)
            
            //--TRIMMABLE-BOUNDARY-START(8590974715)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590974715)
            
            static $h = 1040123;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180909307),
    {
      "p": 165446,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770843899,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245680379,
        "f": 83886081
      },
      "n": "Category",
      "d": 1040123,
      "h": 17180909307,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180909307),
//--TRIMMABLE-BOUNDARY-START(38655745787),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360778491,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1040123,
      "h": 38655745787,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655745787)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540647675),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1040123,
      "h": 51540647675,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540647675),
//--TRIMMABLE-BOUNDARY-START(12885942011),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1040123,
      "h": 12885942011,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885942011)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590974715),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1040123,
      "h": 8590974715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590974715)
  ],
  "h": 1040123
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Shared.GalleryCategoryCard`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryCategoryCard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1040123)
        
        

        //--TRIMMABLE-BOUNDARY-START(1236731)
        $asm.$cls(`$SAWq.LCGCS.GalleryLayout`, ($self) => class GalleryLayout extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(30066007803)
            /*IAssetsCollection*/ Assets$1 = null;
            //--TRIMMABLE-BOUNDARY-END(30066007803)
            
            //--TRIMMABLE-BOUNDARY-START(111670386427)
            /*IUIClientPromptService*/ Prompt = null;
            //--TRIMMABLE-BOUNDARY-END(111670386427)
            
            //--TRIMMABLE-BOUNDARY-START(38655942395)
            /*RenderFragment*/ ChildContent = null;
            //--TRIMMABLE-BOUNDARY-END(38655942395)
            
            //--TRIMMABLE-BOUNDARY-START(98785484539)
            /*RenderFragment*/ Left = null;
            //--TRIMMABLE-BOUNDARY-END(98785484539)
            
            //--TRIMMABLE-BOUNDARY-START(115965353723)
            /*RenderFragment*/ Right = null;
            //--TRIMMABLE-BOUNDARY-END(115965353723)
            
            //--TRIMMABLE-BOUNDARY-START(103080451835)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080451835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Assets$1.LCFCH$IAssetsCollection$Add($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "https://fonts.googleapis.com/css2?family=Raleway:ital,wght@1,200&display=swap" ], null, null));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(103080451835)
            
            //--TRIMMABLE-BOUNDARY-START(163209993979)
            /*bool*/ showSideBar = true;
            //--TRIMMABLE-BOUNDARY-END(163209993979)
            
            //--TRIMMABLE-BOUNDARY-START(167504961275)
            /*void */ ToggleSideBar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504961275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.showSideBar = !this.showSideBar;
            }
            //--TRIMMABLE-BOUNDARY-END(167504961275)
            
            //--TRIMMABLE-BOUNDARY-START(107375419131)
            /*string */ get OptimizedComponentName()
            {
                return "gallerylayout";
            }
            //--TRIMMABLE-BOUNDARY-END(107375419131)
            
            //--TRIMMABLE-BOUNDARY-START(171799928571)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799928571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ChildContent":
                    this.ChildContent = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "Left":
                    this.Left = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                    case "Right":
                    this.Right = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(171799928571)
            
            //--TRIMMABLE-BOUNDARY-START(94490517243)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490517243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Assets$1 = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCH.IAssetsCollection, serviceProvider);
                this.Prompt = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.IUIClientPromptService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(94490517243)
            
            //--TRIMMABLE-BOUNDARY-START(34360975099)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360975099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCS$3.ServerConnection, 0);
                __builder.CloseComponent();
                __builder.AddMarkupContent(1, "\r\n\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCL.ThreeColumnLayout, 2);
                __builder.AddComponentParameter(3, "content-class", "clip");
                __builder.AddComponentParameter(4, "FullPage", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                __builder.AddComponentParameter(5, "_LeftFlags", "showSideBar?LayoutSideBarFlags.Show:LayoutSideBarFlags.None");
                __builder.AddComponentParameter(6, "left-class", "bg-card");
                __builder.AddAttribute$3(7, "Header", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                    __builder2.OpenElement(8, "GalleryMenu");
                    __builder2.AddAttribute$5(9, "IconClicked", "ToggleSideBar");
                    __builder2.AddAttribute$5(10, "Class", "bg-card z-4 pos-stick");
                    __builder2.AddAttribute$5(11, "Style", "top:0");
                    __builder2.CloseElement();
                }), $oFbQIb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1236731,"h":0,"f":17825794}));
                __builder.AddAttribute$3(12, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.AddContent$1(13, this.ChildContent);
                }), $Zcawnj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1236731,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(14, "\r\n\r\n");
                __builder.OpenComponent$1($.$hDPm.LCFCCU.StaticComponents, 15);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(34360975099)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(25771040507)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771040507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771040507)
            
            //--TRIMMABLE-BOUNDARY-START(25771040507)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25771040507)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30066007803)
                this.Assets$1 = null;
                //--TRIMMABLE-BOUNDARY-END(30066007803)
                
                //--TRIMMABLE-BOUNDARY-START(111670386427)
                this.Prompt = null;
                //--TRIMMABLE-BOUNDARY-END(111670386427)
                
            }
            static $h = 1236731;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066007803),
    {
      "p": 61691562,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245876987,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555288315,
        "f": 83886081
      },
      "n": "Assets",
      "o": "@$1",
      "d": 1236731,
      "h": 30066007803,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066007803),
//--TRIMMABLE-BOUNDARY-START(111670386427),
    {
      "p": 65427114,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605615355,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325092091,
        "f": 83886081
      },
      "n": "Prompt",
      "d": 1236731,
      "h": 111670386427,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670386427),
//--TRIMMABLE-BOUNDARY-START(38655942395),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835811579,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145222907,
        "f": 83886081
      },
      "n": "ChildContent",
      "d": 1236731,
      "h": 38655942395,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655942395),
//--TRIMMABLE-BOUNDARY-START(98785484539),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425746171,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735157499,
        "f": 83886081
      },
      "n": "Left",
      "d": 1236731,
      "h": 98785484539,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785484539),
//--TRIMMABLE-BOUNDARY-START(115965353723),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195549947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915026683,
        "f": 83886081
      },
      "n": "Right",
      "d": 1236731,
      "h": 115965353723,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965353723),
//--TRIMMABLE-BOUNDARY-START(107375419131),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015680763,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1236731,
      "h": 107375419131,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107375419131)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103080451835),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 1236731,
      "h": 103080451835,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(103080451835),
//--TRIMMABLE-BOUNDARY-START(167504961275),
    {
      "r": 65537,
      "n": "ToggleSideBar",
      "d": 1236731,
      "h": 167504961275,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167504961275),
//--TRIMMABLE-BOUNDARY-START(171799928571),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1236731,
      "h": 171799928571,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171799928571),
//--TRIMMABLE-BOUNDARY-START(94490517243),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1236731,
      "h": 94490517243,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490517243),
//--TRIMMABLE-BOUNDARY-START(34360975099),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1236731,
      "h": 34360975099,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360975099)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(163209993979),
    {
      "t": 262145,
      "n": "showSideBar",
      "d": 1236731,
      "h": 163209993979,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(163209993979)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771040507),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1236731,
      "h": 25771040507,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771040507)
  ],
  "h": 1236731
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Shared.GalleryLayout`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryLayout`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1236731)
        
        

        //--TRIMMABLE-BOUNDARY-START(1302267)
        $asm.$cls(`$SAWq.LCGCS.GalleryToolBar`, ($self) => class GalleryToolBar extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(34361040635)
            /*EventCallback*/ IconClicked;
            //--TRIMMABLE-BOUNDARY-END(34361040635)
            
            //--TRIMMABLE-BOUNDARY-START(60130844411)
            /*bool*/ useSlider = false;
            //--TRIMMABLE-BOUNDARY-END(60130844411)
            
            //--TRIMMABLE-BOUNDARY-START(51540909819)
            /*void */ ToggleSlider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540909819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.useSlider = !this.useSlider;
                this.StateChanged(false, true, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.Gallery.Client.Blazor\\GalleryToolBar.razor.cs", "ToggleSlider", 19);
            }
            //--TRIMMABLE-BOUNDARY-END(51540909819)
            
            //--TRIMMABLE-BOUNDARY-START(38656007931)
            /*string */ get OptimizedComponentName()
            {
                return "gallerytoolbar";
            }
            //--TRIMMABLE-BOUNDARY-END(38656007931)
            
            //--TRIMMABLE-BOUNDARY-START(55835877115)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835877115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "IconClicked":
                    this.IconClicked = $.$cast(parameter.Value, $.$mac.MAC.EventCallback);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(55835877115)
            
            //--TRIMMABLE-BOUNDARY-START(12886204155)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886204155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCA$2.ApplicationToolBar, 0);
                __builder.AddComponentParameter(1, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `shadow pos-rel ${$.$strNN(this.Class)}`));
                __builder.AddComponentParameter(2, "SetAttributes", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFC.Stringy, $.$$.S.Object)), this.AllAttributes()));
                __builder.AddAttribute$3(3, "Icon", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 4);
                        __builder2.AddComponentParameter(5, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Transparent));
                        __builder2.AddComponentParameter(6, "Class", "mdi mdi-cart fsz-25 !shadow pd-0");
                        __builder2.AddComponentParameter(7, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$5($.$macw.MACW.MouseEventArgs, this, this.IconClicked)));
                        __builder2.CloseComponent();
                    }, $XgISEg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1302267,"h":0,"f":17825794});
                }), $pbjPBb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1302267,"h":0,"f":17825794}));
                __builder.AddAttribute$3(8, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object)))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.AddMarkupContent(9, "<h2 class=\"mg-0\"><a href=\"/Gallery\">SIT Gallery</a></h2>");
                    }, $UUnNkd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1302267,"h":0,"f":17825794});
                }), $gDzmTf ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$$.S.Object).$h}],"n":"","d":1302267,"h":0,"f":17825794}));
                __builder.AddAttribute$3(10, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder2) =>
                {
                }), $YOUUOi ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1302267,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12886204155)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8591236859)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591236859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591236859)
            
            //--TRIMMABLE-BOUNDARY-START(8591236859)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591236859)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34361040635)
                this.IconClicked = $.$default($.$mac.MAC.EventCallback);
                //--TRIMMABLE-BOUNDARY-END(34361040635)
                
            }
            static $h = 1302267;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361040635),
    {
      "p": 2097267,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476138747,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245942523,
        "f": 83886081
      },
      "n": "IconClicked",
      "d": 1302267,
      "h": 34361040635,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361040635),
//--TRIMMABLE-BOUNDARY-START(38656007931),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066073339,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1302267,
      "h": 38656007931,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38656007931)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540909819),
    {
      "r": 65537,
      "n": "ToggleSlider",
      "d": 1302267,
      "h": 51540909819,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540909819),
//--TRIMMABLE-BOUNDARY-START(55835877115),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1302267,
      "h": 55835877115,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835877115),
//--TRIMMABLE-BOUNDARY-START(12886204155),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1302267,
      "h": 12886204155,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886204155)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60130844411),
    {
      "t": 262145,
      "n": "useSlider",
      "d": 1302267,
      "h": 60130844411,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130844411)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591236859),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1302267,
      "h": 8591236859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591236859)
  ],
  "h": 1302267
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Shared.GalleryToolBar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryToolBar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1302267)
        
        

        //--TRIMMABLE-BOUNDARY-START(1105659)
        $asm.$cls(`$SAWq.LCGCS.GalleryCollage`, ($self) => class GalleryCollage extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(94490386171)
            /*string */ get OptimizedComponentName()
            {
                return "gallerycollage";
            }
            //--TRIMMABLE-BOUNDARY-END(94490386171)
            
            //--TRIMMABLE-BOUNDARY-START(150324961019)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324961019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Filter":
                    this.Filter = $.$cast(parameter.Value, $.$fPer.LCFCD.DataFilter);
                    return true;
                    case "Descriptor":
                    this.Descriptor = $.$cast(parameter.Value, $.$qgEF.LCGCM.GalleryDescriptor);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(150324961019)
            
            //--TRIMMABLE-BOUNDARY-START(85900451579)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900451579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.CommentProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$hDPm.LCFCI.ICommentProvider, serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(85900451579)
            
            //--TRIMMABLE-BOUNDARY-START(38655811323)
            /*DataFilter*/ Filter = null;
            //--TRIMMABLE-BOUNDARY-END(38655811323)
            
            //--TRIMMABLE-BOUNDARY-START(34360844027)
            /*GalleryDescriptor*/ Descriptor;
            //--TRIMMABLE-BOUNDARY-END(34360844027)
            
            //--TRIMMABLE-BOUNDARY-START(30065876731)
            /*ICommentProvider*/ CommentProvider = null;
            //--TRIMMABLE-BOUNDARY-END(30065876731)
            
            //--TRIMMABLE-BOUNDARY-START(103080320763)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(103080320763)
            
            //--TRIMMABLE-BOUNDARY-START(146029993723)
            /*bool*/ showDialog = false;
            //--TRIMMABLE-BOUNDARY-END(146029993723)
            
            //--TRIMMABLE-BOUNDARY-START(98785353467)
            /*GalleryItemModel?*/ selected = null;
            //--TRIMMABLE-BOUNDARY-END(98785353467)
            
            //--TRIMMABLE-BOUNDARY-START(90195418875)
            /*RemoteDataList<GalleryItemModel>?*/ list = null;
            //--TRIMMABLE-BOUNDARY-END(90195418875)
            
            //--TRIMMABLE-BOUNDARY-START(141735026427)
            /*void */ Show(/*GalleryItemModel*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735026427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.selected = selection;
                this.showDialog = true;
            }
            //--TRIMMABLE-BOUNDARY-END(141735026427)
            
            //--TRIMMABLE-BOUNDARY-START(158914895611)
            /*Task *//*async*/  UpdateTitle(/*GalleryItemModel*/ image, /*string*/ title)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914895611);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    image.Name = title;
                    ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$qgEF.LCGCS.IGalleryRemoteService, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$qgEF.LCGCS.IGalleryRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCGCS$IGalleryRemoteService$SetTitle($.$clone(this.Descriptor), image.Path, title);
                    }, $cJIrle ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"s","p":296518}],"n":"","d":1105659,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158914895611)
            
            //--TRIMMABLE-BOUNDARY-START(154619928315)
            /*Task *//*async*/  UpdateDescription(/*GalleryItemModel*/ image, /*string*/ description)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619928315);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    image.Description = description;
                    ($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$qgEF.LCGCS.IGalleryRemoteService, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$qgEF.LCGCS.IGalleryRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*s*/ s) =>
                    {
                        return s.LCGCS$IGalleryRemoteService$SetDescription($.$clone(this.Descriptor), image.Path, description);
                    }, $rTMJbb ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"s","p":296518}],"n":"","d":1105659,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(154619928315)
            
            //--TRIMMABLE-BOUNDARY-START(25770909435)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770909435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCA$3.AuthenticationTicket, 0);
                __builder.AddAttribute$3(1, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket)))().$ctor(this, ( (/*ticket*/ ticket) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$qgEF.LCGCM.GalleryItemModel), 2);
                        __builder2.AddComponentParameter(3, "_ref", "list");
                        __builder2.AddComponentParameter(4, "PadContent", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2), $.$$.S.Int32));
                        __builder2.AddComponentParameter(5, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n | 65536n | 134217728n), $.$hDPm.LCFCCD$1.DataListFeatures));
                        __builder2.AddComponentParameter(6, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, this.Filter));
                        __builder2.AddAttribute$3(7, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel))))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$SAWq.LCGCS.GalleryImageCard, 8);
                                __builder3.AddComponentParameter(9, "Class", "hx-2");
                                __builder3.AddComponentParameter(10, "Media", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel)).op_Implicit$1(context)));
                                __builder3.AddComponentParameter(11, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                                {
                                    return this.Show($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel)).op_Implicit$1(context));
                                }, $vfLHJf ??= {"r":65537,"n":"","d":1105659,"h":0,"f":17825794})));
                                __builder3.CloseComponent();
                            }, $YcmSqk ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1105659,"h":0,"f":17825794});
                        }), $PIjske ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel)).$h}],"n":"","d":1105659,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(12, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/**/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 13);
                            __builder3.AddComponentParameter(14, "Message", "No media here");
                            __builder3.CloseComponent();
                        }), $tYesBd ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1105659,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(15, "\r\n\r\n        ");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCD$4.Dialog, 16);
                        __builder2.AddComponentParameter(17, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$4.DialogFeatures, 0/*DialogFeatures.Default*/ | 8/*DialogFeatures.Closeable*/ | 4/*DialogFeatures.CloseOnClickOut*/), $.$hDPm.LCFCCD$4.DialogFeatures));
                        __builder2.AddComponentParameter(18, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.showDialog ? "bg-dark-09" : ""));
                        __builder2.AddComponentParameter(19, "Show", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, this.showDialog), $.$$.S.Boolean));
                        __builder2.AddComponentParameter(20, "ShowChanged", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.S.Boolean), $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.Boolean, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.Boolean, this, new ($.$$.S.Action$$($.$$.S.Boolean))().$ctor(this,  (/*__value*/ __value) =>
                        {
                            return this.showDialog = __value;
                        }, $SNGGHf ??= {"r":65537,"p":[{"n":"__value","p":262145}],"n":"","d":1105659,"h":0,"f":17825794}), this.showDialog))));
                        __builder2.AddAttribute$3(21, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$qgEF.LCGCM.GalleryItemModel), 22);
                            __builder3.AddComponentParameter(23, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 67108864n), $.$hDPm.LCFCCD$1.DataListFeatures));
                            __builder3.AddComponentParameter(24, "Class", "mgr");
                            __builder3.AddAttribute$3(25, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel))))().$ctor(this, ( (/*context*/ context) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenElement(26, "div");
                                    __builder4.AddAttribute$5(27, "class", "row wv-10 hv-10");
                                    __builder4.OpenElement(28, "div");
                                    __builder4.AddAttribute$5(29, "class", "col-10 stack");
                                    __builder4.OpenElement(30, "div");
                                    __builder4.AddAttribute$5(31, "class", "fill");
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 32);
                                    __builder4.AddComponentParameter(33, "AltIconClass", "mawp-10 mahp-10 mg-a");
                                    __builder4.AddComponentParameter(34, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.Path));
                                    __builder4.AddComponentParameter(35, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCM$3.MediaFeatures, 387/*MediaFeatures.Default*/ & ~3/*MediaFeatures.Responsive*/), $.$hDPm.LCFCCM$3.MediaFeatures));
                                    __builder4.AddComponentParameter(36, "Class", "mg-a");
                                    __builder4.CloseComponent();
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(37, "\r\n                        ");
                                    __builder4.OpenElement(38, "div");
                                    __builder4.AddAttribute$5(39, "class", "stack pd");
                                    /*var*/ let titleBinder = new ($.$hDPm.LCFCU.DelegateValueBinder$$($.$$.S.String))().$ctor$8(context.Model.Name, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*v*/ v) =>
                                    {
                                        return this.UpdateTitle($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel)).op_Implicit$1(context), v);
                                    }, $BZCcJg ??= {"r":178454529,"p":[{"n":"v","p":1310721}],"n":"","d":1105659,"h":0,"f":17825794}));
                                    /*var*/ let infoBinder = new ($.$hDPm.LCFCU.DelegateValueBinder$$($.$$.S.String))().$ctor$8(context.Model.Description, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task))().$ctor(this,  (/*v*/ v) =>
                                    {
                                        return this.UpdateDescription($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel)).op_Implicit$1(context), v);
                                    }, $njAvol ??= {"r":178454529,"p":[{"n":"v","p":1310721}],"n":"","d":1105659,"h":0,"f":17825794}));
                                    $.$SAWq._LCGCSG$3.TypeInference.CreateEditable_0($.$$.S.String, __builder4, 40, 41, "h2", 42, "mg-0", 43, ticket.Model.HasRoles$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "SuperAdmin", "Admin", "Editor" ], null, null)), 44, titleBinder.Value, 45, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        return titleBinder.Value = __value;
                                    }, $tLshrd ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1105659,"h":0,"f":17825794}), titleBinder.Value)), 46, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                    {
                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(titleBinder), "Value"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                    }, $mtFVGh ??= {"r":38797349,"n":"","d":1105659,"h":0,"f":17825794})).Invoke()));
                                    __builder4.AddMarkupContent(47, "\r\n                            ");
                                    $.$SAWq._LCGCSG$3.TypeInference.CreateEditable_1($.$$.S.String, __builder4, 48, 49, "small", 50, "mgt", 51, ticket.Model.HasRoles$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [ "SuperAdmin", "Admin", "Editor" ], null, null)), 52, infoBinder.Value, 53, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                                    {
                                        return infoBinder.Value = __value;
                                    }, $QjljXa ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":1105659,"h":0,"f":17825794}), infoBinder.Value)), 54, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                                    {
                                        return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.Property$5($.$sle.SLE.Expression.Constant$1(infoBinder), "Value"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                                    }, $usqvZj ??= {"r":38797349,"n":"","d":1105659,"h":0,"f":17825794})).Invoke()));
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                    __builder4.AddMarkupContent(55, "\r\n                    ");
                                    __builder4.OpenElement(56, "div");
                                    __builder4.AddAttribute$5(57, "class", "col-a miwx-3 pd scroll");
                                    __builder4.AddMarkupContent(58, "<h2 class=\"mgt-0\">Reactions</h2>\r\n                        ");
                                    __builder4.AddContent$1(59, this.CommentProvider.LCFCI$ICommentProvider$GetComments((() =>
                                    {
                                        //new $.$hDPm.LCFCI.CommentConfiguration()
                                        const $t4 = $.$hDPm.LCFCI.CommentConfiguration;
                                        const $i4 = new $t4();
                                        $i4.$ctor$1();
                                        $i4.Identifier = $.$fPer.LCFCD.DataId.op_Implicit$1(context.Model.Path);
                                        $i4.Anonymous = true;
                                        return $i4;
                                    })()));
                                    __builder4.CloseElement();
                                    __builder4.CloseElement();
                                }, $zCOuli ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":1105659,"h":0,"f":17825794});
                            }), $SEEYpe ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel)).$h}],"n":"","d":1105659,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $RuqNfl ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":1105659,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $rZurGg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":1105659,"h":0,"f":17825794});
                }), $TOFKVj ??= {"r":6881395,"p":[{"n":"ticket","p":$.$hDPm.LCFCI.ContainerContext$$($.$GfYa.LCFCA.DecodedAuthenticationTicket).$h}],"n":"","d":1105659,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25770909435)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(21475942139)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475942139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475942139)
            
            //--TRIMMABLE-BOUNDARY-START(21475942139)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(21475942139)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34360844027)
                this.Descriptor = $.$default($.$qgEF.LCGCM.GalleryDescriptor);
                //--TRIMMABLE-BOUNDARY-END(34360844027)
                
                //--TRIMMABLE-BOUNDARY-START(30065876731)
                this.CommentProvider = null;
                //--TRIMMABLE-BOUNDARY-END(30065876731)
                
                //--TRIMMABLE-BOUNDARY-START(103080320763)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(103080320763)
                
            }
            static $h = 1105659;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94490386171),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015549691,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 1105659,
      "h": 94490386171,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(94490386171),
//--TRIMMABLE-BOUNDARY-START(38655811323),
    {
      "p": 9734486,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425615099,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850124539,
        "f": 83886081
      },
      "n": "Filter",
      "d": 1105659,
      "h": 38655811323,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655811323),
//--TRIMMABLE-BOUNDARY-START(34360844027),
    {
      "p": 99910,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835680507,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260189947,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 1105659,
      "h": 34360844027,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360844027),
//--TRIMMABLE-BOUNDARY-START(30065876731),
    {
      "p": 63723178,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245745915,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670255355,
        "f": 83886081
      },
      "n": "CommentProvider",
      "d": 1105659,
      "h": 30065876731,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065876731),
//--TRIMMABLE-BOUNDARY-START(103080320763),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605484283,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440059131,
        "f": 83886081
      },
      "n": "Server",
      "d": 1105659,
      "h": 103080320763,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103080320763)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150324961019),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 1105659,
      "h": 150324961019,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324961019),
//--TRIMMABLE-BOUNDARY-START(85900451579),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 1105659,
      "h": 85900451579,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900451579),
//--TRIMMABLE-BOUNDARY-START(141735026427),
    {
      "r": 65537,
      "p": [
        {
          "n": "selection",
          "p": 165446
        }
      ],
      "n": "Show",
      "d": 1105659,
      "h": 141735026427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735026427),
//--TRIMMABLE-BOUNDARY-START(158914895611),
    {
      "r": 178454529,
      "p": [
        {
          "n": "image",
          "p": 165446
        },
        {
          "n": "title",
          "p": 1310721
        }
      ],
      "n": "UpdateTitle",
      "d": 1105659,
      "h": 158914895611,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(158914895611),
//--TRIMMABLE-BOUNDARY-START(154619928315),
    {
      "r": 178454529,
      "p": [
        {
          "n": "image",
          "p": 165446
        },
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": "UpdateDescription",
      "d": 1105659,
      "h": 154619928315,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(154619928315),
//--TRIMMABLE-BOUNDARY-START(25770909435),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 1105659,
      "h": 25770909435,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770909435)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(146029993723),
    {
      "t": 262145,
      "n": "showDialog",
      "d": 1105659,
      "h": 146029993723,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(146029993723),
//--TRIMMABLE-BOUNDARY-START(98785353467),
    {
      "t": 165446,
      "n": "selected",
      "d": 1105659,
      "h": 98785353467,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(98785353467),
//--TRIMMABLE-BOUNDARY-START(90195418875),
    {
      "t": $.$hDPm.LCFCCD$1.RemoteDataList$$($.$qgEF.LCGCM.GalleryItemModel).$h,
      "n": "list",
      "d": 1105659,
      "h": 90195418875,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90195418875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475942139),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1105659,
      "h": 21475942139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475942139)
  ],
  "h": 1105659
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Shared.GalleryCollage`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryCollage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1105659)
        
        

        //--TRIMMABLE-BOUNDARY-START(646907)
        $asm.$cls(`$SAWq.LCGCP.GalleryCategory`, ($self) => class GalleryCategory extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(77310058235)
            /*string */ get OptimizedComponentName()
            {
                return "gallerycategory";
            }
            //--TRIMMABLE-BOUNDARY-END(77310058235)
            
            //--TRIMMABLE-BOUNDARY-START(111669796603)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669796603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "CategoryName":
                    this.CategoryName = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(111669796603)
            
            //--TRIMMABLE-BOUNDARY-START(68720123643)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720123643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
                this.Nav = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MAC.NavigationManager, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(68720123643)
            
            //--TRIMMABLE-BOUNDARY-START(25770450683)
            /*string*/ CategoryName = null;
            //--TRIMMABLE-BOUNDARY-END(25770450683)
            
            //--TRIMMABLE-BOUNDARY-START(81605025531)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(81605025531)
            
            //--TRIMMABLE-BOUNDARY-START(73015090939)
            /*NavigationManager*/ Nav = null;
            //--TRIMMABLE-BOUNDARY-END(73015090939)
            
            //--TRIMMABLE-BOUNDARY-START(30065417979)
            /*Task *//*async*/  FileSelected(/*IEnumerable<PickedFileInfo>*/ fileInfos)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065417979);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let file = null;
                    try
                    {
                        let $t2, $r2;
                        let $t3, $r3;
                        file = ($t2 = $.$sl.SL.Enumerable.First$1($.$vWqU.LCFCC.PickedFileInfo, fileInfos).ReadAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        /*var*/ let _stream = file.LCFCC$IFileStreamProvider$Stream;
                        /*byte[]*/ let b = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [$.$sl.SL.Enumerable.First$1($.$vWqU.LCFCC.PickedFileInfo, fileInfos).Size], null);
                        ($t3 = _stream.ReadAsync$1(b, 0, b.length), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        /*var*/ let stream = new $.$$.SI.MemoryStream().$ctor$8(b);
                        this.Nav.NavigateTo$2(this.Nav.Uri, true);
                    }
                    finally
                    {
                        file?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065417979)
            
            //--TRIMMABLE-BOUNDARY-START(21475483387)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475483387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$SAWq.LCGCS.GalleryLayout, 0);
                __builder.AddAttribute$3(1, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(2, "div");
                    __builder2.AddAttribute$5(3, "class", "pd");
                    __builder2.OpenElement(4, "h2");
                    __builder2.AddAttribute$5(5, "class", "mg-0");
                    __builder2.AddContent$4(6, this.CategoryName);
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(7, "\r\n    ");
                    __builder2.OpenComponent$1($.$SAWq.LCGCS.GalleryCategoriesCarousel, 8);
                    __builder2.AddAttribute$3(9, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCF.FileUpload, 10);
                        __builder3.AddComponentParameter(11, "OnFileSelected", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo)), $.$mac.MAC.EventCallback.Factory.Create$10($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo), this, new ($.$$.S.Func$$$($.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo), $.$$.STT.Task))().$ctor(this, this.FileSelected))));
                        __builder3.AddAttribute$3(12, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                        {
                            __builder4.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 13);
                            __builder4.AddComponentParameter(14, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, $.$fPer.LCFC.Theme.Primary));
                            __builder4.AddAttribute$3(15, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder5*/ __builder5) =>
                            {
                                __builder5.AddContent$4(16, "Add Image");
                            }), $ADbmkh ??= {"r":65537,"p":[{"n":"__builder5","p":7536755}],"n":"","d":646907,"h":0,"f":17825794}));
                            __builder4.CloseComponent();
                        }), $HpgJPe ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":646907,"h":0,"f":17825794}));
                        __builder3.CloseComponent();
                    }), $RGISGh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":646907,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(17, "\r\n    ");
                    __builder2.OpenComponent$1($.$SAWq.LCGCS.GalleryCollage, 18);
                    __builder2.AddComponentParameter(19, "DataFilter", this.CategoryName);
                    __builder2.SetKey(this.CategoryName);
                    __builder2.CloseComponent();
                }), $pYLglg ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":646907,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(21475483387)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(17180516091)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180516091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180516091)
            
            //--TRIMMABLE-BOUNDARY-START(17180516091)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17180516091)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81605025531)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(81605025531)
                
                //--TRIMMABLE-BOUNDARY-START(73015090939)
                this.Nav = null;
                //--TRIMMABLE-BOUNDARY-END(73015090939)
                
            }
            static $h = 646907;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310058235),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835221755,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 646907,
      "h": 77310058235,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310058235),
//--TRIMMABLE-BOUNDARY-START(25770450683),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655352571,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194960123,
        "f": 83886081
      },
      "n": "CategoryName",
      "d": 646907,
      "h": 25770450683,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770450683),
//--TRIMMABLE-BOUNDARY-START(81605025531),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425156347,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374829307,
        "f": 83886081
      },
      "n": "Server",
      "d": 646907,
      "h": 81605025531,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605025531),
//--TRIMMABLE-BOUNDARY-START(73015090939),
    {
      "p": 4980851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245287163,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784894715,
        "f": 83886081
      },
      "n": "Nav",
      "d": 646907,
      "h": 73015090939,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015090939)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111669796603),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 646907,
      "h": 111669796603,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669796603),
//--TRIMMABLE-BOUNDARY-START(68720123643),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 646907,
      "h": 68720123643,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720123643),
//--TRIMMABLE-BOUNDARY-START(30065417979),
    {
      "r": 178454529,
      "p": [
        {
          "n": "fileInfos",
          "p": $.$$.SCG.IEnumerable$$($.$vWqU.LCFCC.PickedFileInfo).$h
        }
      ],
      "n": "FileSelected",
      "d": 646907,
      "h": 30065417979,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(30065417979),
//--TRIMMABLE-BOUNDARY-START(21475483387),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 646907,
      "h": 21475483387,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21475483387)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180516091),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 646907,
      "h": 17180516091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180516091)
  ],
  "h": 646907,
  "a": [
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/Gallery/{CategoryName}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Pages.GalleryCategory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Pages${separator}GalleryCategory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(646907)
        
        

        //--TRIMMABLE-BOUNDARY-START(777979)
        $asm.$cls(`$SAWq.LCGCS.GalleryBrowser`, ($self) => class GalleryBrowser extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(42950450939)
            /*GalleryDescriptor*/ Descriptor;
            //--TRIMMABLE-BOUNDARY-END(42950450939)
            
            //--TRIMMABLE-BOUNDARY-START(128849796859)
            /*bool*/ ReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(128849796859)
            
            //--TRIMMABLE-BOUNDARY-START(115964894971)
            /*RenderFragment<GalleryItemModel>?*/ OpenItemView = null;
            //--TRIMMABLE-BOUNDARY-END(115964894971)
            
            //--TRIMMABLE-BOUNDARY-START(111669927675)
            /*RenderFragment<GalleryItemModel>?*/ ItemView = null;
            //--TRIMMABLE-BOUNDARY-END(111669927675)
            
            //--TRIMMABLE-BOUNDARY-START(124554829563)
            /*Stack<GalleryItemModel>*/ paths = null;
            //--TRIMMABLE-BOUNDARY-END(124554829563)
            
            //--TRIMMABLE-BOUNDARY-START(38655483643)
            /*GalleryItemModel? */ get Current()
            {
                /*var*/ let top;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425287419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.paths.TryPeek($.$ref(() => top, ($v) => top = $v, $.$qgEF.LCGCM.GalleryItemModel));
                return top;
            }
            //--TRIMMABLE-BOUNDARY-END(38655483643)
            
            //--TRIMMABLE-BOUNDARY-START(4295745275)
            /*string */ get _Path()
            {
                return $.$$.S.String.Join$5("/", $.$sl.SL.Enumerable.Select$1($.$qgEF.LCGCM.GalleryItemModel, $.$$.S.String, $.$sl.SL.Enumerable.Reverse($.$qgEF.LCGCM.GalleryItemModel, this.paths), new ($.$$.S.Func$$$($.$qgEF.LCGCM.GalleryItemModel, $.$$.S.String))().$ctor(this,  (/*p*/ p) =>
                {
                    return p.Name;
                }, $kufiti ??= {"r":1310721,"p":[{"n":"p","p":165446}],"n":"","d":777979,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(4295745275)
            
            //--TRIMMABLE-BOUNDARY-START(47245418235)
            /*Task *//*async*/  Exclude(/*GalleryItemModel*/ item)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245418235);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$4($.$qgEF.LCGCS.IGalleryRemoteService, this.UnitOfWork.LCFCI$IClientUnitOfWork$Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$qgEF.LCGCS.IGalleryRemoteService, $.$fPer.LCFCD.WireTransportModel))().$ctor(this,  (/*g*/ g) =>
                    {
                        return g.LCGCS$IGalleryRemoteService$Exclude($.$clone(this.Descriptor), item.Path, !item.IsExcluded);
                    }, $DtYGBb ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,"p":[{"n":"g","p":296518}],"n":"","d":777979,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    item.IsExcluded = !item.IsExcluded;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47245418235)
            
            //--TRIMMABLE-BOUNDARY-START(30065549051)
            /*void */ Back()
            {
                /*var*/ let top;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065549051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.paths.TryPop($.$ref(() => top, ($v) => top = $v, $.$qgEF.LCGCM.GalleryItemModel));
            }
            //--TRIMMABLE-BOUNDARY-END(30065549051)
            
            //--TRIMMABLE-BOUNDARY-START(133144764155)
            /*void */ Select(/*GalleryItemModel*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144764155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.paths.Push(item);
            }
            //--TRIMMABLE-BOUNDARY-END(133144764155)
            
            //--TRIMMABLE-BOUNDARY-START(171799469819)
            /*void */ SetTo(/*GalleryItemModel?*/ item)
            {
                /*var*/ let top;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799469819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while(this.paths.TryPeek($.$ref(() => top, ($v) => top = $v, $.$qgEF.LCGCM.GalleryItemModel)))
                {
                    if (top === item)
                    {
                        break;
                    }
                    this.paths.TryPop($.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799469819)
            
            //--TRIMMABLE-BOUNDARY-START(120259862267)
            /*string */ get OptimizedComponentName()
            {
                return "gallerybrowser";
            }
            //--TRIMMABLE-BOUNDARY-END(120259862267)
            
            //--TRIMMABLE-BOUNDARY-START(176094437115)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094437115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch5 = parameter.Name;
                switch($switch5)
                {
                    case "Descriptor":
                    this.Descriptor = $.$cast(parameter.Value, $.$qgEF.LCGCM.GalleryDescriptor);
                    return true;
                    case "ReadOnly":
                    this.ReadOnly = $.$cast(parameter.Value, $.$$.S.Boolean);
                    return true;
                    case "OpenItemView":
                    this.OpenItemView = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment$$($.$qgEF.LCGCM.GalleryItemModel));
                    return true;
                    case "ItemView":
                    this.ItemView = $.$cast(parameter.Value, $.$mac.MAC.RenderFragment$$($.$qgEF.LCGCM.GalleryItemModel));
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(176094437115)
            
            //--TRIMMABLE-BOUNDARY-START(34360516347)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360516347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "flex bdb pdb");
                __builder.OpenElement(2, "button");
                __builder.AddAttribute$5(3, "class", "mgy-a mdi mdi-chevron-double-left bg-transparent fsz-20");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 4, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.Back)));
                __builder.CloseElement();
                __builder.AddMarkupContent(5, "\r\n    ");
                __builder.OpenElement(6, "b");
                __builder.AddAttribute$5(7, "class", "mgy-a mgr clickable");
                __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 8, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                {
                    return this.SetTo(null);
                }, $eoySQh ??= {"r":65537,"n":"","d":777979,"h":0,"f":17825794})));
                __builder.AddContent$4(9, "Root");
                __builder.CloseElement();
                let $en6 = $.$sl.SL.Enumerable.Reverse($.$qgEF.LCGCM.GalleryItemModel, this.paths).SCG$IEnumerable$$$GetEnumerator();
                while ($en6.SC$1$IEnumerator$MoveNext())
                {
                    let level = $en6.SCG$IEnumerator$$$Current;
                    {
                        __builder.AddMarkupContent(10, "<span class=\"mgy-a\">></span>\r\n        ");
                        __builder.OpenElement(11, "b");
                        __builder.AddAttribute$5(12, "class", "mgy-a mgx clickable");
                        __builder.AddAttribute$7($.$macw.MACW.MouseEventArgs, 13, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return this.SetTo(level);
                        }, $aAcjPg ??= {"r":65537,"n":"","d":777979,"h":0,"f":17825794})));
                        __builder.AddContent$4(14, level.Name);
                        __builder.AddMarkupContent(15, "\r\n            ");
                        __builder.OpenElement(16, "small");
                        __builder.AddMarkupContent(17, "\r\n                (");
                        __builder.AddContent$3(18, $.$box(level.Contents, $.$$.S.Int32));
                        __builder.AddMarkupContent(19, ")\r\n            ");
                        __builder.CloseElement();
                        __builder.CloseElement();
                    }
                }
                __builder.CloseElement();
                if (this.Current !== null && !this.Current.IsDirectory)
                {
                    if (this.OpenItemView !== null)
                    {
                        __builder.AddContent$1(20, this.OpenItemView.Invoke(this.Current));
                    }
                    else 
                    {
                        __builder.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 21);
                        __builder.AddComponentParameter(22, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.Current.Path));
                        __builder.CloseComponent();
                    }
                }
                else 
                {
                    __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$qgEF.LCGCM.GalleryItemModel), 23);
                    __builder.AddComponentParameter(24, "DataFilter", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCD.DataFilter, new $.$fPer.LCFCD.DataFilter().$ctor$22(this._Path, null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null).WithAttribute$2($.$qgEF.LCGCM.GalleryDescriptor, $.$clone(this.Descriptor), 0)));
                    __builder.AddComponentParameter(25, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder.AddComponentParameter(26, "GridWidth", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 150), $.$$.S.Int32));
                    __builder.AddComponentParameter(27, "GridGap", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 20), $.$$.S.Int32));
                    __builder.AddComponentParameter(28, "Class", "mgt");
                    __builder.AddAttribute$3(29, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel))))().$ctor(this, ( (/*context*/ context) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                        {
                            __builder2.OpenElement(30, "div");
                            __builder2.AddAttribute$5(31, "class", $.$strNN($.$strNN($.$strNN("bg-" + $.$strNN((context.Data.IsExcluded ? "gray" : "card"))) + " shadow") + " bd") + " stack");
                            __builder2.OpenElement(32, "div");
                            __builder2.AddAttribute$5(33, "class", "hx-08 flex clickable");
                            __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 34, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this,  () =>
                            {
                                return this.Select(context.Data);
                            }, $CxxCac ??= {"r":65537,"n":"","d":777979,"h":0,"f":17825794})));
                            if (context.Data.IsDirectory && context.Data.ImagePath === null)
                            {
                                __builder2.AddMarkupContent(35, "<i class=\"mdi mdi-folder fsz-80 mgx-a cl-warning\"></i>");
                            }
                            else 
                            {
                                __builder2.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 36);
                                __builder2.AddComponentParameter(37, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 80), $.$$.S.Int32));
                                __builder2.AddComponentParameter(38, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Data.ImagePath ?? context.Data.Path));
                                __builder2.CloseComponent();
                            }
                            __builder2.CloseElement();
                            __builder2.AddMarkupContent(39, "\r\n            ");
                            __builder2.OpenElement(40, "div");
                            __builder2.AddAttribute$5(41, "class", "pd bdt flex");
                            __builder2.OpenElement(42, "h3");
                            __builder2.AddAttribute$5(43, "class", "mg-0 fill nowrap");
                            __builder2.AddContent$4(44, context.Data.Name);
                            if (context.Data.IsDirectory)
                            {
                                __builder2.OpenElement(45, "small");
                                __builder2.AddContent$4(46, "(");
                                __builder2.AddContent$3(47, $.$box(context.Data.Contents, $.$$.S.Int32));
                                __builder2.AddContent$4(48, ")");
                                __builder2.CloseElement();
                            }
                            __builder2.CloseElement();
                            if (!this.ReadOnly)
                            {
                                __builder2.OpenElement(49, "popup");
                                __builder2.AddAttribute$5(50, "class", "pos-rel");
                                __builder2.AddMarkupContent(51, "<button class=\"bg-transparent mdi mdi-dots-vertical\"></button>\r\n                        ");
                                __builder2.OpenElement(52, "pop");
                                __builder2.AddAttribute$5(53, "class", "miwx-15 at bottomtobottom righttoright bg-tertiary shadow");
                                __builder2.OpenElement(54, "ul");
                                __builder2.AddAttribute$5(55, "class", "reset menu vh selectable");
                                __builder2.OpenElement(56, "li");
                                __builder2.AddAttribute$5(57, "class", "menuitem pd clickable");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 58, "onclick", $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                                {
                                    return this.Exclude(context.Data);
                                }, $ItAgkf ??= {"r":178454529,"n":"","d":777979,"h":0,"f":17825794})));
                                __builder2.AddMarkupContent(59, "<i class=\"mdi mdi-eye-remove\"></i>\r\n                                    ");
                                __builder2.OpenElement(60, "span");
                                __builder2.AddContent$4(61, !context.Data.IsExcluded ? "Exclude" : "Include");
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                            __builder2.CloseElement();
                            __builder2.CloseElement();
                        }, $aALrqk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":777979,"h":0,"f":17825794});
                    }), $vDGTVk ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel)).$h}],"n":"","d":777979,"h":0,"f":17825794}));
                    __builder.SetKey(this.Current ?? $.$cast(this, $.$$.S.Object));
                    __builder.CloseComponent();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360516347)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(25770581755)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770581755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770581755)
            
            //--TRIMMABLE-BOUNDARY-START(25770581755)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(25770581755)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(42950450939)
                this.Descriptor = $.$default($.$qgEF.LCGCM.GalleryDescriptor);
                //--TRIMMABLE-BOUNDARY-END(42950450939)
                
                //--TRIMMABLE-BOUNDARY-START(124554829563)
                this.paths = new ($.$sc.SCG.Stack$$($.$qgEF.LCGCM.GalleryItemModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(124554829563)
                
            }
            static $h = 777979;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950450939),
    {
      "p": 99910,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015222011,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734698747,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 777979,
      "h": 42950450939,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950450939),
//--TRIMMABLE-BOUNDARY-START(128849796859),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374960379,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504502523,
        "f": 83886081
      },
      "n": "ReadOnly",
      "d": 777979,
      "h": 128849796859,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849796859),
//--TRIMMABLE-BOUNDARY-START(115964894971),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$qgEF.LCGCM.GalleryItemModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195091195,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914567931,
        "f": 83886081
      },
      "n": "OpenItemView",
      "d": 777979,
      "h": 115964894971,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964894971),
//--TRIMMABLE-BOUNDARY-START(111669927675),
    {
      "p": $.$mac.MAC.RenderFragment$$($.$qgEF.LCGCM.GalleryItemModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605156603,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324633339,
        "f": 83886081
      },
      "n": "ItemView",
      "d": 777979,
      "h": 111669927675,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669927675),
//--TRIMMABLE-BOUNDARY-START(38655483643),
    {
      "p": 165446,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425287419,
        "f": 50331650
      },
      "n": "Current",
      "d": 777979,
      "h": 38655483643,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38655483643),
//--TRIMMABLE-BOUNDARY-START(4295745275),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835352827,
        "f": 50331650
      },
      "n": "_Path",
      "d": 777979,
      "h": 4295745275,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(4295745275),
//--TRIMMABLE-BOUNDARY-START(120259862267),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785025787,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 777979,
      "h": 120259862267,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120259862267)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245418235),
    {
      "r": 178454529,
      "p": [
        {
          "n": "item",
          "p": 165446
        }
      ],
      "n": "Exclude",
      "d": 777979,
      "h": 47245418235,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(47245418235),
//--TRIMMABLE-BOUNDARY-START(30065549051),
    {
      "r": 65537,
      "n": "Back",
      "d": 777979,
      "h": 30065549051,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065549051),
//--TRIMMABLE-BOUNDARY-START(133144764155),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": 165446
        }
      ],
      "n": "Select",
      "d": 777979,
      "h": 133144764155,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144764155),
//--TRIMMABLE-BOUNDARY-START(171799469819),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": 165446
        }
      ],
      "n": "SetTo",
      "d": 777979,
      "h": 171799469819,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171799469819),
//--TRIMMABLE-BOUNDARY-START(176094437115),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 777979,
      "h": 176094437115,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094437115),
//--TRIMMABLE-BOUNDARY-START(34360516347),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 777979,
      "h": 34360516347,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360516347)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124554829563),
    {
      "t": $.$sc.SCG.Stack$$($.$qgEF.LCGCM.GalleryItemModel).$h,
      "n": "paths",
      "d": 777979,
      "h": 124554829563,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124554829563)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770581755),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 777979,
      "h": 25770581755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770581755)
  ],
  "h": 777979
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Shared.GalleryBrowser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryBrowser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(777979)
        
        

        //--TRIMMABLE-BOUNDARY-START(909051)
        $asm.$cls(`$SAWq.LCGCS.GalleryCategoriesCarousel`, ($self) => class GalleryCategoriesCarousel extends $.$hDPm.LCFCC$1.BaseContainer
        {
            //--TRIMMABLE-BOUNDARY-START(73015353083)
            /*string */ get OptimizedComponentName()
            {
                return "gallerycategoriescarousel";
            }
            //--TRIMMABLE-BOUNDARY-END(73015353083)
            
            //--TRIMMABLE-BOUNDARY-START(107375091451)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375091451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "Descriptor":
                    this.Descriptor = $.$cast(parameter.Value, $.$qgEF.LCGCM.GalleryDescriptor);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(107375091451)
            
            //--TRIMMABLE-BOUNDARY-START(60130451195)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130451195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Server = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$uvJL.LCFCR.IServerRemoteService, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(60130451195)
            
            //--TRIMMABLE-BOUNDARY-START(77310320379)
            /*IServerRemoteService*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(77310320379)
            
            //--TRIMMABLE-BOUNDARY-START(21475745531)
            /*GalleryDescriptor*/ Descriptor;
            //--TRIMMABLE-BOUNDARY-END(21475745531)
            
            //--TRIMMABLE-BOUNDARY-START(64425418491)
            /*RemoteDataList<GalleryItemModel>?*/ list = null;
            //--TRIMMABLE-BOUNDARY-END(64425418491)
            
            //--TRIMMABLE-BOUNDARY-START(68720385787)
            /*string */ get NewCategory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655614715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            /*string */ set NewCategory(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490189563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t2, $r2;
                        /*var*/ let m = ($t2 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.Execute$1($.$qgEF.LCGCS.IGalleryRemoteService, $.$qgEF.LCGCM.GalleryItemModel, this.Server, new ($.$uvJL.LCFCR.ServiceModelMethod$$$($.$qgEF.LCGCS.IGalleryRemoteService, $.$fPer.LCFCD.WireTransportManyModel$$($.$qgEF.LCGCM.GalleryItemModel)))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.LCFCD$ICreateDataService$LivingThing$Core$Gallery$Common$Models$GalleryItemModel$Create(new $.$fPer.LCFCD.DataFilter().$ctor$1(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$qgEF.LCGCM.GalleryItemModel), [ (() =>
                            {
                                //new $.$qgEF.LCGCM.GalleryItemModel()
                                const $t3 = $.$qgEF.LCGCM.GalleryItemModel;
                                const $i3 = new $t3();
                                $i3.$ctor$3();
                                $i3.Name = value;
                                return $i3;
                            })() ], null, null));
                        }, $SxeEFj ??= {"r":$.$$.STT.Task$$($.$fPer.LCFCD.WireTransportManyModel$$($.$qgEF.LCGCM.GalleryItemModel)).$h,"p":[{"n":"s","p":296518}],"n":"","d":909051,"h":0,"f":17825794}), null, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        _ = this.list.Add$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$qgEF.LCGCM.GalleryItemModel), [ $.$sl.SL.Enumerable.First$1($.$qgEF.LCGCM.GalleryItemModel, m.AsEnumerable()) ], null, null));
                    });
                }, $kmNvha ??= {"r":178454529,"n":"","d":909051,"h":0,"f":17829890}));
            }
            //--TRIMMABLE-BOUNDARY-END(68720385787)
            
            //--TRIMMABLE-BOUNDARY-START(17180778235)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180778235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenElement(0, "div");
                __builder.AddAttribute$5(1, "class", "flex");
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.RemoteDataList$$($.$qgEF.LCGCM.GalleryItemModel), 2);
                __builder.AddComponentParameter(3, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 33554432n), $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(4, "PadContent", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 2), $.$$.S.Int32));
                __builder.AddComponentParameter(5, "Class", "fill");
                __builder.AddAttribute$3(6, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel))))().$ctor(this, ( (/*context*/ context) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        __builder2.OpenComponent$1($.$macw.MACR$2.NavLink, 7);
                        __builder2.AddComponentParameter(8, "href", `/Gallery/${$.$strNN(context.Model.Name)}`);
                        __builder2.AddComponentParameter(9, "class", "clickable");
                        __builder2.AddAttribute$3(10, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 11);
                            __builder3.AddComponentParameter(12, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCC$1.CardFeatures, 21/*CardFeatures.Default*/ | 2/*CardFeatures.Corner*/), $.$hDPm.LCFCCC$1.CardFeatures));
                            __builder3.AddAttribute$3(13, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                            {
                                __builder4.OpenElement(14, "div");
                                __builder4.AddAttribute$5(15, "class", "row");
                                __builder4.OpenElement(16, "div");
                                __builder4.AddAttribute$5(17, "class", "col-a");
                                __builder4.OpenElement(18, "div");
                                __builder4.AddAttribute$5(19, "class", "wx-02 hx-02 round clip");
                                __builder4.OpenComponent$1($.$hDPm.LCFCCM$3.Media, 20);
                                __builder4.AddComponentParameter(21, "Url", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, context.Model.ImagePath));
                                __builder4.AddComponentParameter(22, "Class", "mg-a");
                                __builder4.CloseComponent();
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                                __builder4.AddMarkupContent(23, "\r\n                        ");
                                __builder4.OpenElement(24, "div");
                                __builder4.AddAttribute$5(25, "class", "col-10 flex");
                                __builder4.OpenElement(26, "b");
                                __builder4.AddAttribute$5(27, "class", "mgl mgy-a nowrap");
                                __builder4.AddContent$4(28, context.Model.Name);
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                                __builder4.CloseElement();
                            }), $SsZYOk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":909051,"h":0,"f":17825794}));
                            __builder3.CloseComponent();
                        }), $xHJwMb ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":909051,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }, $EzBKYe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":909051,"h":0,"f":17825794});
                }), $Ajrymd ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$qgEF.LCGCM.GalleryItemModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$qgEF.LCGCM.GalleryItemModel)).$h}],"n":"","d":909051,"h":0,"f":17825794}));
                __builder.AddAttribute$3(29, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                }), $dIQAWc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":909051,"h":0,"f":17825794}));
                __builder.AddComponentReferenceCapture(30, new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*__value*/ __value) =>
                {
                    this.list = $.$cast(__value, $.$hDPm.LCFCCD$1.RemoteDataList$$($.$qgEF.LCGCM.GalleryItemModel));
                }, $HoUith ??= {"r":65537,"p":[{"n":"__value","p":131073}],"n":"","d":909051,"h":0,"f":17825794}));
                __builder.CloseComponent();
                __builder.AddMarkupContent(31, "\r\n    ");
                __builder.OpenElement(32, "div");
                $.$SAWq._LCGCSG.TypeInference.CreateEditable_0($.$$.S.String, __builder, 33, 34, true, 35, "New Category Name", 36, this.NewCategory, 37, $.$mac.MAC.EventCallback.Factory.Create$6($.$$.S.String, this, $.$mac.MACC.RuntimeHelpers.CreateInferredEventCallback$1($.$$.S.String, this, new ($.$$.S.Action$$($.$$.S.String))().$ctor(this,  (/*__value*/ __value) =>
                {
                    return this.NewCategory = __value;
                }, $yQapHi ??= {"r":65537,"p":[{"n":"__value","p":1310721}],"n":"","d":909051,"h":0,"f":17825794}), this.NewCategory)), 38, ((new ($.$$.S.Func$$($.$sle.SLE.LambdaExpression))().$ctor(this,  () =>
                {
                    return $.$sle.SLE.Expression.Lambda$9($.$sle.SLE.Expression.PropertyOrField($.$sle.SLE.Expression.Constant$1(this), "NewCategory"), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [  ], null, null));
                }, $bzHYlc ??= {"r":38797349,"n":"","d":909051,"h":0,"f":17825794})).Invoke()));
                __builder.AddMarkupContent(39, "\r\n        ");
                __builder.AddContent$1(40, this.ChildContent);
                __builder.CloseElement();
                __builder.CloseElement();
            }
            //--TRIMMABLE-BOUNDARY-END(17180778235)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12885810939)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885810939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885810939)
            
            //--TRIMMABLE-BOUNDARY-START(12885810939)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12885810939)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77310320379)
                this.Server = null;
                //--TRIMMABLE-BOUNDARY-END(77310320379)
                
                //--TRIMMABLE-BOUNDARY-START(21475745531)
                this.Descriptor = $.$default($.$qgEF.LCGCM.GalleryDescriptor);
                //--TRIMMABLE-BOUNDARY-END(21475745531)
                
            }
            static $h = 909051;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseContainer; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015353083),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245549307,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 909051,
      "h": 73015353083,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73015353083),
//--TRIMMABLE-BOUNDARY-START(77310320379),
    {
      "p": 1309651,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835483899,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080124155,
        "f": 83886081
      },
      "n": "Server",
      "d": 909051,
      "h": 77310320379,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310320379),
//--TRIMMABLE-BOUNDARY-START(21475745531),
    {
      "p": 99910,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065680123,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900254971,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 909051,
      "h": 21475745531,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475745531),
//--TRIMMABLE-BOUNDARY-START(68720385787),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655614715,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490189563,
        "f": 83886082
      },
      "n": "NewCategory",
      "d": 909051,
      "h": 68720385787,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(68720385787)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107375091451),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 909051,
      "h": 107375091451,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107375091451),
//--TRIMMABLE-BOUNDARY-START(60130451195),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 909051,
      "h": 60130451195,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130451195),
//--TRIMMABLE-BOUNDARY-START(17180778235),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 909051,
      "h": 17180778235,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17180778235)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425418491),
    {
      "t": $.$hDPm.LCFCCD$1.RemoteDataList$$($.$qgEF.LCGCM.GalleryItemModel).$h,
      "n": "list",
      "d": 909051,
      "h": 64425418491,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425418491)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885810939),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 909051,
      "h": 12885810939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885810939)
  ],
  "h": 909051
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCC$1.IContainer, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Client.Shared.GalleryCategoriesCarousel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Client${separator}Shared${separator}GalleryCategoriesCarousel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(909051)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Gallery.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(57083)
