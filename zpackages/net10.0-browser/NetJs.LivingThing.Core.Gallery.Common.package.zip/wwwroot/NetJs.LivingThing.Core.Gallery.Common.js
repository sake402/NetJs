
//--TRIMMABLE-BOUNDARY-START(34374)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mep, $mecga, $mec, $sdp, $srw, $srsf, $sxxd, $sct, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $mxdi, $sca, $meo, $mc, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $zHIt, $Iaui, $uvJL) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.Gallery.Common", 
    {
  "h": 34374,
  "f": "LivingThing.Core.Gallery.Common",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.Gallery.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.Gallery.Common",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(99910)
        $asm.$str(`$qgEF.LCGCM.GalleryDescriptor`, ($self) => class GalleryDescriptor extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21474936390)
            /*string*/ RootFolder = null;
            //--TRIMMABLE-BOUNDARY-END(21474936390)
            
            //--TRIMMABLE-BOUNDARY-START(8590034502)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590034502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590034502)
            
            //--TRIMMABLE-BOUNDARY-START(8590034502)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590034502)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.RootFolder = this.RootFolder;
                return copy;
            }
            static $h = 99910;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474936390),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17179969094,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30064870982,
        "f": 83886081
      },
      "n": "RootFolder",
      "d": 99910,
      "h": 21474936390,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474936390)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590034502),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 99910,
      "h": 8590034502,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590034502)
  ],
  "h": 99910
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IJsonSerializableDataConvert ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Common.Models.GalleryDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Common${separator}Models${separator}GalleryDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(99910)
        
        

        //--TRIMMABLE-BOUNDARY-START(362054)
        $asm.$cls(`$qgEF.LCGCS$1.GallerySettings`, ($self) => class GallerySettings extends $.$Iaui.LCFCMS.ComponentSettings
        {
            //--TRIMMABLE-BOUNDARY-START(12885263942)
            /*string*/ FolderPath = null;
            //--TRIMMABLE-BOUNDARY-END(12885263942)
            
            //--TRIMMABLE-BOUNDARY-START(8590296646)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590296646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590296646)
            
            //--TRIMMABLE-BOUNDARY-START(8590296646)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8590296646)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885263942)
                this.FolderPath = "~\\Gallery";
                //--TRIMMABLE-BOUNDARY-END(12885263942)
                
            }
            static $h = 362054;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS.ComponentSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885263942),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475198534,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065133126,
        "f": 83886081
      },
      "n": "FolderPath",
      "d": 362054,
      "h": 12885263942,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885263942)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590296646),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 362054,
      "h": 8590296646,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590296646)
  ],
  "h": 362054
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$fPer.LCFCD.ISettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Common.Settings.GallerySettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Common${separator}Settings${separator}GallerySettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(362054)
        
        

        //--TRIMMABLE-BOUNDARY-START(427590)
        $asm.$cls(`$qgEF.LCGCS$2.GalleryStates`, ($self) => class GalleryStates extends $.$Iaui.LCFCMS$1.ComponentStates
        {
            //--TRIMMABLE-BOUNDARY-START(4295394886)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295394886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295394886)
            
            //--TRIMMABLE-BOUNDARY-START(4295394886)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295394886)
            
            static $h = 427590;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCMS$1.ComponentStates; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295394886),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 427590,
      "h": 4295394886,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295394886)
  ],
  "h": 427590
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentStates, $.$fPer.LCFCD.IStates ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Common.States.GalleryStates`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Common${separator}States${separator}GalleryStates`; }
        });
        //--TRIMMABLE-BOUNDARY-END(427590)
        
        

        //--TRIMMABLE-BOUNDARY-START(165446)
        $asm.$cls(`$qgEF.LCGCM.GalleryItemModel`, ($self) => class GalleryItemModel extends $.$Iaui.LCFCM.EntryModel
        {
            //--TRIMMABLE-BOUNDARY-START(111669315142)
            /*bool*/ IsDirectory = false;
            //--TRIMMABLE-BOUNDARY-END(111669315142)
            
            //--TRIMMABLE-BOUNDARY-START(115964282438)
            /*bool*/ IsExcluded = false;
            //--TRIMMABLE-BOUNDARY-END(115964282438)
            
            //--TRIMMABLE-BOUNDARY-START(120259249734)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(120259249734)
            
            //--TRIMMABLE-BOUNDARY-START(42949838406)
            /*string?*/ Description = null;
            //--TRIMMABLE-BOUNDARY-END(42949838406)
            
            //--TRIMMABLE-BOUNDARY-START(124554217030)
            /*string*/ Path = null;
            //--TRIMMABLE-BOUNDARY-END(124554217030)
            
            //--TRIMMABLE-BOUNDARY-START(107374347846)
            /*string?*/ ImagePath = null;
            //--TRIMMABLE-BOUNDARY-END(107374347846)
            
            //--TRIMMABLE-BOUNDARY-START(38654871110)
            /*int*/ Contents = 0;
            //--TRIMMABLE-BOUNDARY-END(38654871110)
            
            //--TRIMMABLE-BOUNDARY-START(34359903814)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359903814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359903814)
            
            //--TRIMMABLE-BOUNDARY-START(34359903814)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34359903814)
            
            static $h = 165446;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.EntryModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111669315142),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309576774,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158913955398,
        "f": 83886081
      },
      "n": "IsDirectory",
      "d": 165446,
      "h": 111669315142,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669315142),
//--TRIMMABLE-BOUNDARY-START(115964282438),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899511366,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167503889990,
        "f": 83886081
      },
      "n": "IsExcluded",
      "d": 165446,
      "h": 115964282438,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964282438),
//--TRIMMABLE-BOUNDARY-START(120259249734),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489445958,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176093824582,
        "f": 83886081
      },
      "n": "Name",
      "d": 165446,
      "h": 120259249734,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259249734),
//--TRIMMABLE-BOUNDARY-START(42949838406),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129707590,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734086214,
        "f": 83886081
      },
      "n": "Description",
      "d": 165446,
      "h": 42949838406,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949838406),
//--TRIMMABLE-BOUNDARY-START(124554217030),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079380550,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184683759174,
        "f": 83886081
      },
      "n": "Path",
      "d": 165446,
      "h": 124554217030,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554217030),
//--TRIMMABLE-BOUNDARY-START(107374347846),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719642182,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324020806,
        "f": 83886081
      },
      "n": "ImagePath",
      "d": 165446,
      "h": 107374347846,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374347846),
//--TRIMMABLE-BOUNDARY-START(38654871110),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539772998,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144151622,
        "f": 83886081
      },
      "n": "Contents",
      "d": 165446,
      "h": 38654871110,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654871110)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34359903814),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 165446,
      "h": 34359903814,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359903814)
  ],
  "h": 165446
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Common.Models.GalleryItemModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Common${separator}Models${separator}GalleryItemModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(165446)
        
        

        //--TRIMMABLE-BOUNDARY-START(296518)
        $asm.$cls(`$qgEF.LCGCS.IGalleryRemoteService`, ($self) => class IGalleryRemoteService
        {
            static $h = 296518;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295263814),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "gallery",
          "p": 99910
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "exclude",
          "p": 262145
        }
      ],
      "n": "Exclude",
      "o": "LCGCS$IGalleryRemoteService$Exclude",
      "d": 296518,
      "h": 4295263814,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295263814),
//--TRIMMABLE-BOUNDARY-START(12885198406),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "gallery",
          "p": 99910
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "title",
          "p": 1310721
        }
      ],
      "n": "SetTitle",
      "o": "LCGCS$IGalleryRemoteService$SetTitle",
      "d": 296518,
      "h": 12885198406,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885198406),
//--TRIMMABLE-BOUNDARY-START(8590231110),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "gallery",
          "p": 99910
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": "SetDescription",
      "o": "LCGCS$IGalleryRemoteService$SetDescription",
      "d": 296518,
      "h": 8590231110,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590231110),
//--TRIMMABLE-BOUNDARY-START(17180165702),
    {
      "r": $.$$.STT.Task$$($.$fPer.LCFCD.WireTransportModel).$h,
      "p": [
        {
          "n": "gallery",
          "p": 99910
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": "Upload",
      "o": "LCGCS$IGalleryRemoteService$Upload",
      "d": 296518,
      "h": 17180165702,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180165702)
  ],
  "h": 296518
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$qgEF.LCGCM.GalleryItemModel), $.$fPer.LCFCD.ICreateDataService$$($.$qgEF.LCGCM.GalleryItemModel), $.$fPer.LCFCD.IReadDataService$$($.$qgEF.LCGCM.GalleryItemModel), $.$fPer.LCFCD.IReadManyDataService$$($.$qgEF.LCGCM.GalleryItemModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$qgEF.LCGCM.GalleryItemModel), $.$fPer.LCFCD.IUpdateDataService$$($.$qgEF.LCGCM.GalleryItemModel), $.$fPer.LCFCD.IDeleteDataService$$($.$qgEF.LCGCM.GalleryItemModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Common.Services.IGalleryRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Common${separator}Services${separator}IGalleryRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(296518)
        
        

        //--TRIMMABLE-BOUNDARY-START(230982)
        $asm.$cls(`$qgEF.LCGCM.GalleryModel`, ($self) => class GalleryModel extends $.$Iaui.LCFCM.ComponentModel$$$($.$qgEF.LCGCS$1.GallerySettings, $.$qgEF.LCGCS$2.GalleryStates)
        {
            //--TRIMMABLE-BOUNDARY-START(4295198278)
            //default constructor overload
            $ctor$7()
            {
                super.$ctor$6();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295198278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295198278)
            
            //--TRIMMABLE-BOUNDARY-START(4295198278)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4295198278)
            
            static $h = 230982;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$Iaui.LCFCM.ComponentModel$$$($.$qgEF.LCGCS$1.GallerySettings, $.$qgEF.LCGCS$2.GalleryStates); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295198278),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 230982,
      "h": 4295198278,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295198278)
  ],
  "h": 230982
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.Gallery.Common.Models.GalleryModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}Gallery${separator}Common${separator}Models${separator}GalleryModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(230982)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.RPC"));
})();
//--TRIMMABLE-BOUNDARY-END(34374)
