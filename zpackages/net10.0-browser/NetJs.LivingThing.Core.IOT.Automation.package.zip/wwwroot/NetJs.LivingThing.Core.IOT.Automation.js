
//--TRIMMABLE-BOUNDARY-START(18806)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $HnZw, $mep, $meca, $mxdi, $mexla, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $meo, $mecm, $mecga, $mec, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $eFOo, $fXpo, $zHIt, $uvJL, $KuVO, $lOHy, $kVHt, $UrvY, $vWqU, $JRhp, $DJRY, $tUcV, $nYKj, $AvdQ, $bMcF, $XBGm) {
    "use strict";
    let _;
    let $sylASd;
    let $qIRcWg;
    let $Kqtuyi;
    let $pVsfqj;
    let $PWXytf;
    let $vJwSvi;
    let $vCLOie;
    let $EwHyIh;
    let $okZvAj;
    let $RaFhth;
    let $oLaBOe;
    let $CLxVQd;
    let $IxboMi;
    let $IBnYmh;
    let $uHTZQh;
    let $xSRtOc;
    let $iafucl;
    let $hToEJc;
    let $MJVAfl;
    let $EARsmc;
    let $qAkrBj;
    let $ajLajd;
    let $AzkIFj;
    let $yhmDdk;
    let $UxFtLi;
    let $KRxZHh;
    let $RViXCa;
    let $xvcvFf;
    let $yxNSod;
    let $XzZiIj;
    let $pwGJkk;
    let $QrwyLb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Automation", 
    {
  "h": 18806,
  "f": "LivingThing.Core.IOT.Automation",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Automation",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Automation",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(149878)
        $asm.$cls(`$xIHr.LCIAAD.IOTDeviceControlActionSettings`, ($self) => class IOTDeviceControlActionSettings extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38654855542)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(38654855542)
            
            //--TRIMMABLE-BOUNDARY-START(17180019062)
            /*Dictionary<string, object>*/ CommandParameter = null;
            //--TRIMMABLE-BOUNDARY-END(17180019062)
            
            //--TRIMMABLE-BOUNDARY-START(12885051766)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885051766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885051766)
            
            //--TRIMMABLE-BOUNDARY-START(12885051766)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885051766)
            
            static $h = 149878;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654855542),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359888246,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834724726,
        "f": 83886081
      },
      "n": "Id",
      "d": 149878,
      "h": 38654855542,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654855542),
//--TRIMMABLE-BOUNDARY-START(17180019062),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769953654,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244790134,
        "f": 83886081
      },
      "n": "CommandParameter",
      "d": 149878,
      "h": 17180019062,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180019062)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885051766),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 149878,
      "h": 12885051766,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885051766)
  ],
  "h": 149878
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlActionSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Actions${separator}DeviceControl${separator}IOTDeviceControlActionSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(149878)
        
        

        //--TRIMMABLE-BOUNDARY-START(805238)
        $asm.$cls(`$xIHr.LCIATD.ConditionModelCustomAttributesProvider`, ($self) => class ConditionModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295772534)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295772534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295772534)
            
            static $h = 805238;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295772534),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 805238,
      "h": 4295772534,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295772534)
  ],
  "h": 805238
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}ConditionModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(805238)
        
        

        //--TRIMMABLE-BOUNDARY-START(1263990)
        $asm.$cls(`$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsCustomAttributesProvider`, ($self) => class IOTDeviceStatusTriggerSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296231286)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296231286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296231286)
            
            static $h = 1263990;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296231286),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1263990,
      "h": 4296231286,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296231286)
  ],
  "h": 1263990
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTriggerSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}IOTDeviceStatusTriggerSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1263990)
        
        

        //--TRIMMABLE-BOUNDARY-START(1067382)
        $asm.$cls(`$xIHr.LCIATD.ConditionTypeCustomAttributesProvider`, ($self) => class ConditionTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296034678)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296034678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296034678)
            
            static $h = 1067382;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296034678),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1067382,
      "h": 4296034678,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296034678)
  ],
  "h": 1067382
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}ConditionTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1067382)
        
        

        //--TRIMMABLE-BOUNDARY-START(215414)
        $asm.$cls(`$xIHr.LCIAAD.IOTDeviceControlActionSettingsCustomAttributesProvider`, ($self) => class IOTDeviceControlActionSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295182710)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295182710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295182710)
            
            static $h = 215414;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295182710),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 215414,
      "h": 4295182710,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295182710)
  ],
  "h": 215414
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlActionSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Actions${separator}DeviceControl${separator}IOTDeviceControlActionSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(215414)
        
        

        //--TRIMMABLE-BOUNDARY-START(412022)
        $asm.$cls(`$xIHr.LCIA.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295379318)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295379318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xIHr.LCIAAD.IOTDeviceControlActionSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xIHr.LCIAAD.IOTDeviceControlActionSettingsCustomAttributesProvider, $.$xIHr.LCIAAD.IOTDeviceControlActionSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xIHr.LCIATD.ConditionType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xIHr.LCIATD.ConditionTypeCustomAttributesProvider, $.$xIHr.LCIATD.ConditionTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xIHr.LCIATD.ConditionModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xIHr.LCIATD.ConditionModelCustomAttributesProvider, $.$xIHr.LCIATD.ConditionModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsCustomAttributesProvider, $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295379318)
            
            static $h = 412022;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295379318),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 412022,
      "h": 4295379318,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295379318)
  ],
  "h": 412022
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(412022)
        
        

        //--TRIMMABLE-BOUNDARY-START(477558)
        $asm.$cls(`$xIHr.LCIA.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295444854)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295444854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295444854)
            
            static $h = 477558;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295444854),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 477558,
      "h": 4295444854,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295444854)
  ],
  "h": 477558
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(477558)
        
        

        //--TRIMMABLE-BOUNDARY-START(1460598)
        $asm.$cls(`$xIHr.LCIA.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296427894)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296427894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptorBuilder.Register();
                $.$xIHr.LCIATD.ConditionModelTypeDescriptorBuilder.Register();
                $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4296427894)
            
            static $h = 1460598;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296427894),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 1460598,
      "h": 4296427894,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296427894)
  ],
  "h": 1460598
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1460598)
        
        

        //--TRIMMABLE-BOUNDARY-START(739702)
        $asm.$cls(`$xIHr.LCIATD.ConditionModel`, ($self) => class ConditionModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770543478)
            /*string*/ Field = null;
            //--TRIMMABLE-BOUNDARY-END(25770543478)
            
            //--TRIMMABLE-BOUNDARY-START(21475576182)
            /*ConditionType*/ Condition = 0;
            //--TRIMMABLE-BOUNDARY-END(21475576182)
            
            //--TRIMMABLE-BOUNDARY-START(81605118326)
            /*double*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(81605118326)
            
            //--TRIMMABLE-BOUNDARY-START(17180608886)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180608886);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180608886)
            
            //--TRIMMABLE-BOUNDARY-START(17180608886)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180608886)
            
            static $h = 739702;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770543478),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950412662,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720216438,
        "f": 83886081
      },
      "n": "Field",
      "d": 739702,
      "h": 25770543478,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770543478),
//--TRIMMABLE-BOUNDARY-START(21475576182),
    {
      "p": 1001846,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360478070,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130281846,
        "f": 83886081
      },
      "n": "Condition",
      "d": 739702,
      "h": 21475576182,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475576182),
//--TRIMMABLE-BOUNDARY-START(81605118326),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540347254,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310151030,
        "f": 83886081
      },
      "n": "Value",
      "d": 739702,
      "h": 81605118326,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605118326)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180608886),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 739702,
      "h": 17180608886,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180608886)
  ],
  "h": 739702
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}ConditionModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(739702)
        
        

        //--TRIMMABLE-BOUNDARY-START(1198454)
        $asm.$cls(`$xIHr.LCIATD.IOTDeviceStatusTriggerSettings`, ($self) => class IOTDeviceStatusTriggerSettings extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655904118)
            /*string*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(38655904118)
            
            //--TRIMMABLE-BOUNDARY-START(17181067638)
            /*List<ConditionModel>*/ Conditions = null;
            //--TRIMMABLE-BOUNDARY-END(17181067638)
            
            //--TRIMMABLE-BOUNDARY-START(12886100342)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886100342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886100342)
            
            //--TRIMMABLE-BOUNDARY-START(12886100342)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886100342)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17181067638)
                this.Conditions = new ($.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17181067638)
                
            }
            static $h = 1198454;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655904118),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360936822,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835773302,
        "f": 83886081
      },
      "n": "Id",
      "d": 1198454,
      "h": 38655904118,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655904118),
//--TRIMMABLE-BOUNDARY-START(17181067638),
    {
      "p": $.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771002230,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245838710,
        "f": 83886081
      },
      "n": "Conditions",
      "d": 1198454,
      "h": 17181067638,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181067638)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886100342),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1198454,
      "h": 12886100342,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886100342)
  ],
  "h": 1198454
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTriggerSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}IOTDeviceStatusTriggerSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1198454)
        
        

        //--TRIMMABLE-BOUNDARY-START(346486)
        $asm.$cls(`$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptorBuilder`, ($self) => class IOTDeviceControlActionSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590281078)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590281078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptor()
                        const $t1 = $.$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlActionSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $IxboMi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":346486,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xIHr.LCIAAD.IOTDeviceControlActionSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590281078)
            
            //--TRIMMABLE-BOUNDARY-START(4295313782)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295313782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295313782)
            
            //--TRIMMABLE-BOUNDARY-START(4295313782)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295313782)
            
            static $h = 346486;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590281078),
    {
      "r": 65537,
      "n": "Register",
      "d": 346486,
      "h": 8590281078,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590281078)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295313782),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 346486,
      "h": 4295313782,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295313782)
  ],
  "h": 346486
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlActionSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Actions${separator}DeviceControl${separator}IOTDeviceControlActionSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(346486)
        
        

        //--TRIMMABLE-BOUNDARY-START(1395062)
        $asm.$cls(`$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptorBuilder`, ($self) => class IOTDeviceStatusTriggerSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591329654)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591329654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptor()
                        const $t1 = $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTriggerSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $MJVAfl ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1395062,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591329654)
            
            //--TRIMMABLE-BOUNDARY-START(4296362358)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296362358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296362358)
            
            //--TRIMMABLE-BOUNDARY-START(4296362358)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296362358)
            
            static $h = 1395062;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591329654),
    {
      "r": 65537,
      "n": "Register",
      "d": 1395062,
      "h": 8591329654,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591329654)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296362358),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1395062,
      "h": 4296362358,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296362358)
  ],
  "h": 1395062
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTriggerSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}IOTDeviceStatusTriggerSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1395062)
        
        

        //--TRIMMABLE-BOUNDARY-START(936310)
        $asm.$cls(`$xIHr.LCIATD.ConditionModelTypeDescriptorBuilder`, ($self) => class ConditionModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590870902)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590870902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$xIHr.LCIATD.ConditionModelTypeDescriptor()
                        const $t1 = $.$xIHr.LCIATD.ConditionModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $UxFtLi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":936310,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$xIHr.LCIATD.ConditionModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590870902)
            
            //--TRIMMABLE-BOUNDARY-START(4295903606)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295903606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295903606)
            
            //--TRIMMABLE-BOUNDARY-START(4295903606)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295903606)
            
            static $h = 936310;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590870902),
    {
      "r": 65537,
      "n": "Register",
      "d": 936310,
      "h": 8590870902,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590870902)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295903606),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 936310,
      "h": 4295903606,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295903606)
  ],
  "h": 936310
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}ConditionModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(936310)
        
        

        //--TRIMMABLE-BOUNDARY-START(84342)
        $asm.$cls(`$xIHr.LCIAAD.IOTDeviceControlAction`, ($self) => class IOTDeviceControlAction extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38654790006)
            /*IIOTDeviceProvider*/ Provider = null;
            //--TRIMMABLE-BOUNDARY-END(38654790006)
            
            //--TRIMMABLE-BOUNDARY-START(34359822710)
            /*string */ get Name()
            {
                return "Control a Device";
            }
            //--TRIMMABLE-BOUNDARY-END(34359822710)
            
            //--TRIMMABLE-BOUNDARY-START(8590018934)
            /*string */ get Description()
            {
                return "Control a Smart Device";
            }
            //--TRIMMABLE-BOUNDARY-END(8590018934)
            
            //--TRIMMABLE-BOUNDARY-START(4295051638)
            $ctor$1(/*IIOTDeviceProvider*/ provider)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295051638);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Provider = provider;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295051638)
            
            //--TRIMMABLE-BOUNDARY-START(30064855414)
            /*Task *//*async*/  Handle(/*AutomationActionContext*/ notification, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064855414);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let settings = notification.Context.GetParameter($.$xIHr.LCIAAD.IOTDeviceControlActionSettings, this, notification);
                    /*var*/ let devices = ($t1 = this.Provider.LCICI$IIOTDeviceProvider$GetAsync(settings.Id), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    let $en2 = devices.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let device = $en2.SCG$IEnumerator$$$Current;
                        {
                            let $t3, $r3;
                            ($t3 = device.LCICI$IIOTAutomate$UpdateStatusFrom($.$$.N.InterfaceVarianceStubHandler.Create($.$sl.SL.Enumerable.ToArray($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$$.S.Object), $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$$.S.Object), settings.CommandParameter, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$$.S.Object)))().$ctor(this,  (/*c*/ c) =>
                            {
                                return $.$fPer.LCFCD.DataDescriptorFactory.FromData($.$$.S.Object, c.Value, null, null, c.Key, null, false);
                            }, $sylASd ??= {"r":$.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$$.S.Object).$h,"p":[{"n":"c","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h}],"n":"","d":84342,"h":0,"f":17825794}))), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor$$($.$$.S.Object)), $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor))), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30064855414)
            
            //--TRIMMABLE-BOUNDARY-START(21475940282)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationAction.Name.get
            get LCFCA$IAutomationAction$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065874874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(21475940282)
            
            //--TRIMMABLE-BOUNDARY-START(12886005690)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationAction.Description.get
            get LCFCA$IAutomationAction$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296071098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12886005690)
            
            //--TRIMMABLE-BOUNDARY-START(25770907578)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationAction.Handle(LivingThing.Core.Frameworks.Common.Automation.AutomationActionContext, System.Threading.CancellationToken)
            LCFCA$IAutomationAction$Handle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770907578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770907578)
            
            static $h = 84342;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359822710),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769888118,
        "f": 50331649
      },
      "n": "Name",
      "d": 84342,
      "h": 34359822710,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359822710),
//--TRIMMABLE-BOUNDARY-START(8590018934),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17179953526,
        "f": 50331649
      },
      "n": "Description",
      "d": 84342,
      "h": 8590018934,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590018934)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064855414),
    {
      "r": 178454529,
      "p": [
        {
          "n": "notification",
          "p": 710586
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "d": 84342,
      "h": 30064855414,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(30064855414)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38654790006),
    {
      "t": 28153233,
      "n": "Provider",
      "d": 84342,
      "h": 38654790006,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654790006)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295051638),
    {
      "p": [
        {
          "n": "provider",
          "p": 28153233
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 84342,
      "h": 4295051638,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295051638)
  ],
  "h": 84342
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$eFOo.LCFCA.IAutomationAction ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlAction`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Actions${separator}DeviceControl${separator}IOTDeviceControlAction`; }
        });
        //--TRIMMABLE-BOUNDARY-END(84342)
        
        

        //--TRIMMABLE-BOUNDARY-START(1132918)
        $asm.$cls(`$xIHr.LCIATD.IOTDeviceStatusTrigger`, ($self) => class IOTDeviceStatusTrigger extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655838582)
            /*IIOTDeviceProvider*/ Provider = null;
            //--TRIMMABLE-BOUNDARY-END(38655838582)
            
            //--TRIMMABLE-BOUNDARY-START(4296100214)
            $ctor$1(/*IIOTDeviceProvider*/ provider)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296100214);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Provider = provider;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296100214)
            
            //--TRIMMABLE-BOUNDARY-START(34360871286)
            /*string */ get Name()
            {
                return "Device Status";
            }
            //--TRIMMABLE-BOUNDARY-END(34360871286)
            
            //--TRIMMABLE-BOUNDARY-START(8591067510)
            /*string */ get Description()
            {
                return "When a device has a particular status";
            }
            //--TRIMMABLE-BOUNDARY-END(8591067510)
            
            //--TRIMMABLE-BOUNDARY-START(30065903990)
            /*Task<AutomationActionContext> *//*async*/  Handle(/*AutomationTriggerContext*/ request, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$eFOo.LCFCA.AutomationActionContext), $.$eFOo.LCFCA.AutomationActionContext, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065903990);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let settings = request.Context.GetParameter$1($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings, this, request);
                    /*var*/ let devices = ($t1 = this.Provider.LCICI$IIOTDeviceProvider$GetAsync(settings.Id), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*bool*/ let triggered = false;
                    let $en2 = devices.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let device = $en2.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let statuses = device.LCICI$IIOTDevice$ReceivedStatus.LCICI$IIOTDeviceStatusModel$GetDataPoints(16777215/*SchemaType.All*/);
                            if (statuses !== null)
                            {
                                triggered = $.$sl.SL.Enumerable.All($.$xIHr.LCIATD.ConditionModel, settings.Conditions, new ($.$$.S.Func$$$($.$xIHr.LCIATD.ConditionModel, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                                {
                                    /*var*/ let sequence = $.$sl.SL.Enumerable.FirstOrDefault$1($.$XBGm.LCICI.IIOTDeviceDataPointModel, statuses, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDeviceDataPointModel, $.$$.S.Boolean))().$ctor(this,  (/*cc*/ cc) =>
                                    {
                                        return cc.LCFCD$1$IObservableDataDescriptor$Name === c.Field;
                                    }, $pVsfqj ??= {"r":262145,"p":[{"n":"cc","p":26514833}],"n":"","d":1132918,"h":0,"f":17825794}));
                                    if (sequence !== null)
                                    {
                                        /*var*/ let value = sequence.LCFCD$IValueProvider$Value;
                                        /*var*/ let presetValue = c.Value;
                                        let $switch3 = c.Condition;
                                        switch($switch3)
                                        {
                                            case 1/*ConditionType.Equals*/:
                                            return $.$dspc(value, $.$$.S.Object, ($t) => $t.Equals$1, $.$box(presetValue, $.$$.S.Double));
                                            case 2/*ConditionType.GreaterThan*/:
                                            {
                                                try
                                                {
                                                    /*double*/ let val = $.$$.S.Convert.ToDouble$10(value);
                                                    return val > presetValue;
                                                }
                                                catch($e)
                                                {
                                                    return false;
                                                }
                                            }
                                            case 3/*ConditionType.LessThan*/:
                                            {
                                                try
                                                {
                                                    /*double*/ let val = $.$$.S.Convert.ToDouble$10(value);
                                                    return val < presetValue;
                                                }
                                                catch($e)
                                                {
                                                    return false;
                                                }
                                            }
                                        }
                                    }
                                    return false;
                                }, $PWXytf ??= {"r":262145,"p":[{"n":"c","p":739702}],"n":"","d":1132918,"h":0,"f":17825794}));
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, request.Context.GetAction(this, request, triggered));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065903990)
            
            //--TRIMMABLE-BOUNDARY-START(21476071354)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Name.get
            get LCFCA$IAutomationTrigger$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066005946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(21476071354)
            
            //--TRIMMABLE-BOUNDARY-START(12886136762)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Description.get
            get LCFCA$IAutomationTrigger$Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296202170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Description;
            }
            //--TRIMMABLE-BOUNDARY-END(12886136762)
            
            //--TRIMMABLE-BOUNDARY-START(25771038650)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Automation.IAutomationTrigger.Handle(LivingThing.Core.Frameworks.Common.Automation.AutomationTriggerContext, System.Threading.CancellationToken)
            LCFCA$IAutomationTrigger$Handle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771038650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25771038650)
            
            static $h = 1132918;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360871286),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770936694,
        "f": 50331649
      },
      "n": "Name",
      "d": 1132918,
      "h": 34360871286,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360871286),
//--TRIMMABLE-BOUNDARY-START(8591067510),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181002102,
        "f": 50331649
      },
      "n": "Description",
      "d": 1132918,
      "h": 8591067510,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591067510)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065903990),
    {
      "r": $.$$.STT.Task$$($.$eFOo.LCFCA.AutomationActionContext).$h,
      "p": [
        {
          "n": "request",
          "p": 907194
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Handle",
      "d": 1132918,
      "h": 30065903990,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(30065903990)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655838582),
    {
      "t": 28153233,
      "n": "Provider",
      "d": 1132918,
      "h": 38655838582,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655838582)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296100214),
    {
      "p": [
        {
          "n": "provider",
          "p": 28153233
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1132918,
      "h": 4296100214,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296100214)
  ],
  "h": 1132918
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$eFOo.LCFCA.IAutomationTrigger ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTrigger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}IOTDeviceStatusTrigger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1132918)
        
        

        //--TRIMMABLE-BOUNDARY-START(674166)
        $asm.$cls(`$xIHr.LCIA.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590608758)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590608758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$eFOo.LCFCA.AutomationContext, $.$xIHr.LCIA.IOTAutomationContext, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$eFOo.LCFCA.AutomationController, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$eFOo.LCFCA.IAutomationController, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$xIHr.LCIA.IOTAutomationController, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$eFOo.LCFCA.IAutomationController))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$xIHr.LCIA.IOTAutomationController, x);
                }, $qIRcWg ??= {"r":1169338,"p":[{"n":"x","p":327718}],"n":"","d":674166,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$eFOo.LCFCA.AutomationController))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$xIHr.LCIA.IOTAutomationController, x);
                }, $Kqtuyi ??= {"r":841658,"p":[{"n":"x","p":327718}],"n":"","d":674166,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$eFOo.LCFCA.IAutomationAction, $.$xIHr.LCIAAD.IOTDeviceControlAction, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$eFOo.LCFCA.IAutomationTrigger, $.$xIHr.LCIATD.IOTDeviceStatusTrigger, services);
                $.$xIHr.LCIA.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$xIHr.LCIA.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590608758)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$xIHr.LCIA.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295641462)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295641462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295641462)
            
            //--TRIMMABLE-BOUNDARY-START(4295641462)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295641462)
            
            static $h = 674166;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590608758),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 674166,
      "h": 8590608758,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590608758)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295641462),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 674166,
      "h": 4295641462,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295641462)
  ],
  "h": 674166
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(674166)
        
        

        //--TRIMMABLE-BOUNDARY-START(543094)
        $asm.$cls(`$xIHr.LCIA.IOTAutomationContext`, ($self) => class IOTAutomationContext extends $.$eFOo.LCFCA.AutomationContext
        {
            //--TRIMMABLE-BOUNDARY-START(25770346870)
            /*ServiceFactory*/ Factory = null;
            //--TRIMMABLE-BOUNDARY-END(25770346870)
            
            //--TRIMMABLE-BOUNDARY-START(73014987126)
            /*ISceneStore*/ SceneStore = null;
            //--TRIMMABLE-BOUNDARY-END(73014987126)
            
            //--TRIMMABLE-BOUNDARY-START(8590477686)
            $ctor$2(/*AutomationController*/ automator, /*ISceneStore*/ sceneStore, /*ServiceFactory*/ factory)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590477686);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Automator = automator;
                    this.SceneStore = sceneStore;
                    this.Factory = factory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590477686)
            
            //--TRIMMABLE-BOUNDARY-START(21475379574)
            /*AutomationController*/ Automator = null;
            //--TRIMMABLE-BOUNDARY-END(21475379574)
            
            //--TRIMMABLE-BOUNDARY-START(77309954422)
            /*List<(IAutomationTrigger Handler,  IOTSceneTriggerModel Trigger)>*/ triggerDatas = null;
            //--TRIMMABLE-BOUNDARY-END(77309954422)
            
            //--TRIMMABLE-BOUNDARY-START(12885444982)
            /*List<(IAutomationAction Handler, IOTSceneActionModel Action)>*/ actionDatas = null;
            //--TRIMMABLE-BOUNDARY-END(12885444982)
            
            //--TRIMMABLE-BOUNDARY-START(68720019830)
            /*Task *//*async*/  Load(/*IOTSceneModel*/ scene)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720019830);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let triggersModel = ($t1 = this.SceneStore.LCICD$ISceneStore$GetTriggers(scene), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    /*var*/ let triggerHandlers = $.$fPer.LCFCS$3.ServiceFactoryExtensions.GetInstances($.$eFOo.LCFCA.IAutomationTrigger, this.Factory);
                    let $en2 = triggersModel.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let triggerModel = $en2.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let handler = $.$sl.SL.Enumerable.SingleOrDefault$1($.$eFOo.LCFCA.IAutomationTrigger, triggerHandlers, new ($.$$.S.Func$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.Boolean))().$ctor(this,  (/**/ h) =>
                            {
                                return $.$$.S.Object.GetType.call(h).FullName === triggerModel.TriggerType;
                            }, $vCLOie ??= {"r":262145,"p":[{"n":"h","p":1234874}],"n":"","d":543094,"h":0,"f":17825794}));
                            if (handler !== null)
                            {
                                this.triggerDatas.Add(new ($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$XBGm.LCICM.IOTSceneTriggerModel))().$ctor$3(handler, triggerModel));
                            }
                        }
                    }
                    /*var*/ let actionsModel = ($t3 = this.SceneStore.LCICD$ISceneStore$GetActions(scene), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    /*var*/ let actionHandlers = $.$fPer.LCFCS$3.ServiceFactoryExtensions.GetInstances($.$eFOo.LCFCA.IAutomationAction, this.Factory);
                    let $en4 = actionsModel.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let actionModel = $en4.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let handler = $.$sl.SL.Enumerable.SingleOrDefault$1($.$eFOo.LCFCA.IAutomationAction, actionHandlers, new ($.$$.S.Func$$$($.$eFOo.LCFCA.IAutomationAction, $.$$.S.Boolean))().$ctor(this,  (/**/ h) =>
                            {
                                return $.$$.S.Object.GetType.call(h).FullName === actionModel.ActionType;
                            }, $EwHyIh ??= {"r":262145,"p":[{"n":"h","p":1103802}],"n":"","d":543094,"h":0,"f":17825794}));
                            if (handler !== null)
                            {
                                this.actionDatas.Add(new ($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$XBGm.LCICM.IOTSceneActionModel))().$ctor$3(handler, actionModel));
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720019830)
            
            //--TRIMMABLE-BOUNDARY-START(81604921718)
            /*IEnumerable<(IAutomationTrigger, string)> */ get Triggers()
            {
                return $.$sl.SL.Enumerable.Select$1($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$XBGm.LCICM.IOTSceneTriggerModel), $.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.String), this.triggerDatas, new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$XBGm.LCICM.IOTSceneTriggerModel), $.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.String)))().$ctor(this,  (/*t*/ t) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.String))().$ctor$3(t.Item1, t.Item2.Identifier.ToString());
                }, $okZvAj ??= {"r":$.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.String).$h,"p":[{"n":"t","p":$.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$XBGm.LCICM.IOTSceneTriggerModel).$h}],"n":"","d":543094,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(81604921718)
            
            //--TRIMMABLE-BOUNDARY-START(17180412278)
            /*IEnumerable<(IAutomationAction, string)> */ get Actions()
            {
                return $.$sl.SL.Enumerable.Select$1($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$XBGm.LCICM.IOTSceneActionModel), $.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$$.S.String), this.actionDatas, new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$XBGm.LCICM.IOTSceneActionModel), $.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$$.S.String)))().$ctor(this,  (/*t*/ t) =>
                {
                    return new ($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$$.S.String))().$ctor$3(t.Item1, t.Item2.Identifier.ToString());
                }, $RaFhth ??= {"r":$.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$$.S.String).$h,"p":[{"n":"t","p":$.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$XBGm.LCICM.IOTSceneActionModel).$h}],"n":"","d":543094,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(17180412278)
            
            //--TRIMMABLE-BOUNDARY-START(64425052534)
            /*T */ GetParameter$1(T, /*IAutomationTrigger*/ trigger, /*AutomationTriggerContext*/ triggerContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425052534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tData = $.$sl.SL.Enumerable.Single($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$XBGm.LCICM.IOTSceneTriggerModel), this.triggerDatas, new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$XBGm.LCICM.IOTSceneTriggerModel), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.Item1 === trigger && $.$$.S.String.Equals$5.call(t.Item2.Identifier.ToString(), triggerContext.TriggerId);
                }, $oLaBOe ??= {"r":262145,"p":[{"n":"t","p":$.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$XBGm.LCICM.IOTSceneTriggerModel).$h}],"n":"","d":543094,"h":0,"f":17825794}));
                return tData.Item2.GetDataAs(T);
            }
            //--TRIMMABLE-BOUNDARY-END(64425052534)
            
            //--TRIMMABLE-BOUNDARY-START(60130085238)
            /*T */ GetParameter(T, /*IAutomationAction*/ action, /*AutomationActionContext*/ actionContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130085238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tData = $.$sl.SL.Enumerable.Single($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$XBGm.LCICM.IOTSceneActionModel), this.actionDatas, new ($.$$.S.Func$$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$XBGm.LCICM.IOTSceneActionModel), $.$$.S.Boolean))().$ctor(this,  (/*t*/ t) =>
                {
                    return t.Item1 === action && $.$$.S.String.Equals$5.call(t.Item2.Identifier.ToString(), actionContext.ActionId);
                }, $CLxVQd ??= {"r":262145,"p":[{"n":"t","p":$.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$XBGm.LCICM.IOTSceneActionModel).$h}],"n":"","d":543094,"h":0,"f":17825794}));
                return tData.Item2.GetDataAs(T);
            }
            //--TRIMMABLE-BOUNDARY-END(60130085238)
            
            //--TRIMMABLE-BOUNDARY-START(55835117942)
            /*AutomationActionContext */ GetAction(/*IAutomationTrigger*/ trigger, /*AutomationTriggerContext*/ triggerContext, /*bool*/ fired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835117942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$eFOo.LCFCA.AutomationActionContext()
                    const $t5 = $.$eFOo.LCFCA.AutomationActionContext;
                    const $i5 = new $t5();
                    $i5.$ctor$1(this);
                    $i5.Fired = fired;
                    return $i5;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(55835117942)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77309954422)
                this.triggerDatas = new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$XBGm.LCICM.IOTSceneTriggerModel)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(77309954422)
                
                //--TRIMMABLE-BOUNDARY-START(12885444982)
                this.actionDatas = new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$XBGm.LCICM.IOTSceneActionModel)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12885444982)
                
            }
            static $h = 543094;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$eFOo.LCFCA.AutomationContext; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475379574),
    {
      "p": 841658,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950216054,
        "f": 50364417
      },
      "n": "Automator",
      "d": 543094,
      "h": 21475379574,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475379574),
//--TRIMMABLE-BOUNDARY-START(81604921718),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540150646,
        "f": 50364417
      },
      "n": "Triggers",
      "d": 543094,
      "h": 81604921718,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81604921718),
//--TRIMMABLE-BOUNDARY-START(17180412278),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360281462,
        "f": 50364417
      },
      "n": "Actions",
      "d": 543094,
      "h": 17180412278,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180412278)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720019830),
    {
      "r": 178454529,
      "p": [
        {
          "n": "scene",
          "p": 40605073
        }
      ],
      "n": "Load",
      "d": 543094,
      "h": 68720019830,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(68720019830),
//--TRIMMABLE-BOUNDARY-START(64425052534),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "trigger",
          "p": 1234874
        },
        {
          "n": "triggerContext",
          "p": 907194
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetParameter",
      "o": "@$1",
      "d": 543094,
      "h": 64425052534,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(64425052534),
//--TRIMMABLE-BOUNDARY-START(60130085238),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "action",
          "p": 1103802
        },
        {
          "n": "actionContext",
          "p": 710586
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetParameter",
      "d": 543094,
      "h": 60130085238,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(60130085238),
//--TRIMMABLE-BOUNDARY-START(55835117942),
    {
      "r": 710586,
      "p": [
        {
          "n": "trigger",
          "p": 1234874
        },
        {
          "n": "triggerContext",
          "p": 907194
        },
        {
          "n": "fired",
          "p": 262145
        }
      ],
      "n": "GetAction",
      "d": 543094,
      "h": 55835117942,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835117942)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770346870),
    {
      "t": 62949718,
      "n": "Factory",
      "d": 543094,
      "h": 25770346870,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770346870),
//--TRIMMABLE-BOUNDARY-START(73014987126),
    {
      "t": 1414545,
      "n": "SceneStore",
      "d": 543094,
      "h": 73014987126,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73014987126),
//--TRIMMABLE-BOUNDARY-START(77309954422),
    {
      "t": $.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationTrigger, $.$XBGm.LCICM.IOTSceneTriggerModel)).$h,
      "n": "triggerDatas",
      "d": 543094,
      "h": 77309954422,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77309954422),
//--TRIMMABLE-BOUNDARY-START(12885444982),
    {
      "t": $.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$eFOo.LCFCA.IAutomationAction, $.$XBGm.LCICM.IOTSceneActionModel)).$h,
      "n": "actionDatas",
      "d": 543094,
      "h": 12885444982,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885444982)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590477686),
    {
      "p": [
        {
          "n": "automator",
          "p": 841658
        },
        {
          "n": "sceneStore",
          "p": 1414545
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 543094,
      "h": 8590477686,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590477686)
  ],
  "h": 543094
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.IOTAutomationContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}IOTAutomationContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(543094)
        
        

        //--TRIMMABLE-BOUNDARY-START(1001846)
        $asm.$str(`$xIHr.LCIATD.ConditionType`, ($self) => class ConditionType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Equals = 1;
            static GreaterThan = 2;
            static LessThan = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1001846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Equals": 1n,
                    "GreaterThan": 2n,
                    "LessThan": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295969142)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295969142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295969142)
            
            //--TRIMMABLE-BOUNDARY-START(4295969142)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295969142)
            
            static $h = 1001846;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475838326),
    {
      "t": 1001846,
      "n": "None",
      "d": 1001846,
      "h": 21475838326,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475838326),
//--TRIMMABLE-BOUNDARY-START(8590936438),
    {
      "t": 1001846,
      "n": "Equals",
      "o": "@$2",
      "d": 1001846,
      "h": 8590936438,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590936438),
//--TRIMMABLE-BOUNDARY-START(12885903734),
    {
      "t": 1001846,
      "n": "GreaterThan",
      "d": 1001846,
      "h": 12885903734,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885903734),
//--TRIMMABLE-BOUNDARY-START(17180871030),
    {
      "t": 1001846,
      "n": "LessThan",
      "d": 1001846,
      "h": 17180871030,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180871030)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295969142),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1001846,
      "h": 4295969142,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295969142)
  ],
  "h": 1001846
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}ConditionType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1001846)
        
        

        //--TRIMMABLE-BOUNDARY-START(608630)
        $asm.$cls(`$xIHr.LCIA.IOTAutomationController`, ($self) => class IOTAutomationController extends $.$eFOo.LCFCA.AutomationController
        {
            //--TRIMMABLE-BOUNDARY-START(12885510518)
            /*ServiceFactory*/ Factory = null;
            //--TRIMMABLE-BOUNDARY-END(12885510518)
            
            //--TRIMMABLE-BOUNDARY-START(30065379702)
            /*ISceneStore*/ SceneStore = null;
            //--TRIMMABLE-BOUNDARY-END(30065379702)
            
            //--TRIMMABLE-BOUNDARY-START(4295575926)
            $ctor$2(/*ServiceFactory*/ factory, /*ISceneStore*/ sceneStore)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295575926);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Factory = factory;
                    this.SceneStore = sceneStore;
                    this.Run$2();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295575926)
            
            //--TRIMMABLE-BOUNDARY-START(21475445110)
            /*Task */ RunNow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475445110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.runNowCompletes !== null)
                {
                    return $.$$.STT.Task.CompletedTask;
                }
                this.delayToken.Cancel();
                this.delayToken = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                this.runNowCompletes = new ($.$$.STT.TaskCompletionSource$$($.$$.S.Object))().$ctor$1();
                return this.runNowCompletes.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(21475445110)
            
            //--TRIMMABLE-BOUNDARY-START(25770412406)
            /*TaskCompletionSource<object>*/ runNowCompletes = null;
            //--TRIMMABLE-BOUNDARY-END(25770412406)
            
            //--TRIMMABLE-BOUNDARY-START(8590543222)
            /*CancellationTokenSource*/ delayToken = null;
            //--TRIMMABLE-BOUNDARY-END(8590543222)
            
            //--TRIMMABLE-BOUNDARY-START(17180477814)
            /*void */ Run$2()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180477814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, /*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        while(true)
                        {
                            try
                            {
                                let $t1, $r1;
                                /*var*/ let scenes = ($t1 = this.SceneStore.LCICD$ISmartDataStore$LivingThing$Core$IOT$Common$Models$IOTSceneModel$GetAllAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                                let $en2 = scenes.SCG$IEnumerable$$$GetEnumerator();
                                while ($en2.SC$1$IEnumerator$MoveNext())
                                {
                                    let scene = $en2.SCG$IEnumerator$$$Current;
                                    {
                                        /*var*/ let context = new $.$xIHr.LCIA.IOTAutomationContext().$ctor$2(this, this.SceneStore, this.Factory);
                                        try
                                        {
                                            let $t3, $r3;
                                            let $t4, $r4;
                                            ($t3 = context.Load(scene), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                            ($t4 = this.Run(context, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$eFOo.LCFCA.AutomationTriggerContext), [ new $.$eFOo.LCFCA.AutomationTriggerContext().$ctor$1(context) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                        }
                                        catch($e)
                                        {
                                        }
                                    }
                                }
                            }
                            catch($e)
                            {
                            }
                            finally
                            {
                                {
                                    if (this.runNowCompletes !== null)
                                    {
                                        this.runNowCompletes.SetResult(null);
                                        this.runNowCompletes = null;
                                    }
                                }
                            }
                            try
                            {
                                let $t5, $r5;
                                ($t5 = $.$$.STT.Task.Delay(15000, this.delayToken.Token), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                            }
                            catch($e)
                            {
                            }
                        }
                    });
                }, $vJwSvi ??= {"r":178454529,"n":"","d":608630,"h":0,"f":17829890}));
            }
            //--TRIMMABLE-BOUNDARY-END(17180477814)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590543222)
                this.delayToken = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590543222)
                
            }
            static $h = 608630;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$eFOo.LCFCA.AutomationController; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475445110),
    {
      "r": 178454529,
      "n": "RunNow",
      "d": 608630,
      "h": 21475445110,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475445110),
//--TRIMMABLE-BOUNDARY-START(17180477814),
    {
      "r": 65537,
      "n": "Run",
      "o": "@$2",
      "d": 608630,
      "h": 17180477814,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180477814)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885510518),
    {
      "t": 62949718,
      "n": "Factory",
      "d": 608630,
      "h": 12885510518,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885510518),
//--TRIMMABLE-BOUNDARY-START(30065379702),
    {
      "t": 1414545,
      "n": "SceneStore",
      "d": 608630,
      "h": 30065379702,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065379702),
//--TRIMMABLE-BOUNDARY-START(25770412406),
    {
      "t": $.$$.STT.TaskCompletionSource$$($.$$.S.Object).$h,
      "n": "runNowCompletes",
      "d": 608630,
      "h": 25770412406,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770412406),
//--TRIMMABLE-BOUNDARY-START(8590543222),
    {
      "t": 170983425,
      "n": "delayToken",
      "d": 608630,
      "h": 8590543222,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590543222)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295575926),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "sceneStore",
          "p": 1414545
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 608630,
      "h": 4295575926,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295575926)
  ],
  "h": 608630
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$eFOo.LCFCA.IAutomationController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.IOTAutomationController`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}IOTAutomationController`; }
        });
        //--TRIMMABLE-BOUNDARY-END(608630)
        
        

        //--TRIMMABLE-BOUNDARY-START(1329526)
        $asm.$cls(`$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptor`, ($self) => class IOTDeviceStatusTriggerSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4296296822)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296296822);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptor.GenerateProperties($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings, this, factory);
                    }, $EARsmc ??= {"r":65537,"n":"","d":1329526,"h":0,"f":17825794}), 0, "IOTDeviceStatusTriggerSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Automation\\Triggers_DeviceStatus_IOTDeviceStatusTriggerSettings_LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTriggerSettingsTypeDescriptorBuilder.g.cs", "IOTDeviceStatusTriggerSettingsTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296296822)
            
            //--TRIMMABLE-BOUNDARY-START(12886231414)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886231414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTriggerSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings)).Id);
                        }, $qAkrBj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1329526,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $ajLajd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1329526,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Conditions"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings.$type, $.$discardRef(), "Conditions", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Conditions")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Conditions";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTriggerSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel), ($.$cast(target, $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings)).Conditions);
                        }, $AzkIFj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1329526,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Conditions = value.AsReference($.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel));
                        }, $yhmDdk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1329526,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886231414)
            
            //--TRIMMABLE-BOUNDARY-START(17181198710)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTriggerSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181198710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _Conditions = _target.Conditions;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Conditions"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel), $.$xIHr.LCIATD.ConditionModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel), $.$xIHr.LCIATD.ConditionModel, property, $.$ref(() => _Conditions, ($v) => _Conditions = $v, $.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel))))
                    {
                        _target.Conditions = _Conditions;
                        if (_Conditions !== null)
                        {
                            let $en7 = _Conditions.GetEnumerator();
                            while ($en7.MoveNext())
                            {
                                let item = $en7.Current;
                                {
                                    /*var*/ let _item = item;
                                    if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$xIHr.LCIATD.ConditionModel)))
                                    {
                                    }
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel), $.$xIHr.LCIATD.ConditionModel, property, $.$ref(() => _Conditions, ($v) => _Conditions = $v, $.$$.SCG.List$$($.$xIHr.LCIATD.ConditionModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181198710)
            
            //--TRIMMABLE-BOUNDARY-START(8591264118)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTriggerSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591264118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings)))
                {
                    /*var*/ let result = $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591264118)
            
            static $h = 1329526;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886231414),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1329526,
      "h": 12886231414,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886231414),
//--TRIMMABLE-BOUNDARY-START(17181198710),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1198454,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1329526,
      "h": 17181198710,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181198710),
//--TRIMMABLE-BOUNDARY-START(8591264118),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1198454,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1329526,
      "h": 8591264118,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591264118)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296296822),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1329526,
      "h": 4296296822,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296296822)
  ],
  "h": 1329526
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xIHr.LCIATD.IOTDeviceStatusTriggerSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.IOTDeviceStatusTriggerSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}IOTDeviceStatusTriggerSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1329526)
        
        

        //--TRIMMABLE-BOUNDARY-START(870774)
        $asm.$cls(`$xIHr.LCIATD.ConditionModelTypeDescriptor`, ($self) => class ConditionModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xIHr.LCIATD.ConditionModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295838070)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295838070);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xIHr.LCIATD.ConditionModelTypeDescriptor.GenerateProperties($.$xIHr.LCIATD.ConditionModel, this, factory);
                    }, $KRxZHh ??= {"r":65537,"n":"","d":870774,"h":0,"f":17825794}), 0, "ConditionModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Automation\\Triggers_DeviceStatus_IOTDeviceStatusTriggerSettings_LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModelTypeDescriptorBuilder.g.cs", "ConditionModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295838070)
            
            //--TRIMMABLE-BOUNDARY-START(12885772662)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885772662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Field"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xIHr.LCIATD.ConditionModel.$type, $.$discardRef(), "Field", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Field")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Field";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIATD.ConditionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$xIHr.LCIATD.ConditionModel)).Field);
                        }, $RViXCa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":870774,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIATD.ConditionModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Field = value.AsReference($.$$.S.String);
                        }, $xvcvFf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":870774,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Condition"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xIHr.LCIATD.ConditionModel.$type, $.$discardRef(), "Condition", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Condition")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$xIHr.LCIATD.ConditionType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Condition";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIATD.ConditionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$xIHr.LCIATD.ConditionType, ($.$cast(target, $.$xIHr.LCIATD.ConditionModel)).Condition);
                        }, $yxNSod ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":870774,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIATD.ConditionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Condition = value.AsEnumValue($.$xIHr.LCIATD.ConditionType);
                        }, $XzZiIj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":870774,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Value"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xIHr.LCIATD.ConditionModel.$type, $.$discardRef(), "Value", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Value")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Value";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIATD.ConditionModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$xIHr.LCIATD.ConditionModel)).Value);
                        }, $pwGJkk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":870774,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIATD.ConditionModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Value = value.AsDouble();
                        }, $QrwyLb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":870774,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885772662)
            
            //--TRIMMABLE-BOUNDARY-START(17180739958)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180739958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Field = _target.Field;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Field"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Field, ($v) => _Field = $v, $.$$.S.String)))
                    {
                        _target.Field = _Field;
                    }
                }
                {
                    /*var*/ let _Condition = _target.Condition;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Condition"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$xIHr.LCIATD.ConditionType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$xIHr.LCIATD.ConditionType, () => _Condition, ($v) => _Condition = $v, null, true)))
                    {
                        _target.Condition = _Condition;
                    }
                }
                {
                    /*var*/ let _Value = _target.Value;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Value"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Value, ($v) => _Value = $v, $.$$.S.Double)))
                    {
                        _target.Value = _Value;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180739958)
            
            //--TRIMMABLE-BOUNDARY-START(8590805366)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590805366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xIHr.LCIATD.ConditionModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xIHr.LCIATD.ConditionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xIHr.LCIATD.ConditionModel)))
                {
                    /*var*/ let result = $.$xIHr.LCIATD.ConditionModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xIHr.LCIATD.ConditionModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xIHr.LCIATD.ConditionModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$xIHr.LCIATD.ConditionModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590805366)
            
            static $h = 870774;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xIHr.LCIATD.ConditionModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885772662),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 870774,
      "h": 12885772662,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885772662),
//--TRIMMABLE-BOUNDARY-START(17180739958),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 739702,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 870774,
      "h": 17180739958,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180739958),
//--TRIMMABLE-BOUNDARY-START(8590805366),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 739702,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 870774,
      "h": 8590805366,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590805366)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295838070),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 870774,
      "h": 4295838070,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295838070)
  ],
  "h": 870774
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xIHr.LCIATD.ConditionModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Triggers.DeviceStatus.ConditionModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Triggers${separator}DeviceStatus${separator}ConditionModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(870774)
        
        

        //--TRIMMABLE-BOUNDARY-START(280950)
        $asm.$cls(`$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptor`, ($self) => class IOTDeviceControlActionSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xIHr.LCIAAD.IOTDeviceControlActionSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4295248246)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295248246);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptor.GenerateProperties($.$xIHr.LCIAAD.IOTDeviceControlActionSettings, this, factory);
                    }, $IBnYmh ??= {"r":65537,"n":"","d":280950,"h":0,"f":17825794}), 0, "IOTDeviceControlActionSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Automation\\Actions_DeviceControl_IOTDeviceControlActionSettings_LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlActionSettingsTypeDescriptorBuilder.g.cs", "IOTDeviceControlActionSettingsTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295248246)
            
            //--TRIMMABLE-BOUNDARY-START(12885182838)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885182838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xIHr.LCIAAD.IOTDeviceControlActionSettings.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlActionSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$xIHr.LCIAAD.IOTDeviceControlActionSettings)).Id);
                        }, $uHTZQh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":280950,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $xSRtOc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":280950,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CommandParameter"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$xIHr.LCIAAD.IOTDeviceControlActionSettings.$type, $.$discardRef(), "CommandParameter", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CommandParameter")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CommandParameter";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlActionSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object), ($.$cast(target, $.$xIHr.LCIAAD.IOTDeviceControlActionSettings)).CommandParameter);
                        }, $iafucl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":280950,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CommandParameter = value.AsReference($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object));
                        }, $hToEJc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":280950,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885182838)
            
            //--TRIMMABLE-BOUNDARY-START(17180150134)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlActionSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180150134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _CommandParameter = _target.CommandParameter;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CommandParameter"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _CommandParameter, ($v) => _CommandParameter = $v, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))))
                    {
                        _target.CommandParameter = _CommandParameter;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180150134)
            
            //--TRIMMABLE-BOUNDARY-START(8590215542)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlActionSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590215542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$xIHr.LCIAAD.IOTDeviceControlActionSettings().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$xIHr.LCIAAD.IOTDeviceControlActionSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$xIHr.LCIAAD.IOTDeviceControlActionSettings)))
                {
                    /*var*/ let result = $.$xIHr.LCIAAD.IOTDeviceControlActionSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$xIHr.LCIAAD.IOTDeviceControlActionSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$xIHr.LCIAAD.IOTDeviceControlActionSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$xIHr.LCIAAD.IOTDeviceControlActionSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590215542)
            
            static $h = 280950;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$xIHr.LCIAAD.IOTDeviceControlActionSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885182838),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 280950,
      "h": 12885182838,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885182838),
//--TRIMMABLE-BOUNDARY-START(17180150134),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 149878,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 280950,
      "h": 17180150134,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180150134),
//--TRIMMABLE-BOUNDARY-START(8590215542),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 149878,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 280950,
      "h": 8590215542,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590215542)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295248246),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 280950,
      "h": 4295248246,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295248246)
  ],
  "h": 280950
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$xIHr.LCIAAD.IOTDeviceControlActionSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Automation.Actions.DeviceControl.IOTDeviceControlActionSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Automation${separator}Actions${separator}DeviceControl${separator}IOTDeviceControlActionSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(280950)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.DynamicExpresso.Core", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.IOT.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(18806)
