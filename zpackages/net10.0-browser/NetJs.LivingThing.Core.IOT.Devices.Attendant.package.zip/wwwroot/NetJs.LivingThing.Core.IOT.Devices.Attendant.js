
//--TRIMMABLE-BOUNDARY-START(62844)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $CGlcQh;
    let $YiFgpa;
    let $boIigl;
    let $fCQKsf;
    let $gSUUOb;
    let $JjsbUk;
    let $mfLwbb;
    let $eprRXe;
    let $bNDmSf;
    let $ZTxKsh;
    let $nWPgck;
    let $pzdcck;
    let $Swtzif;
    let $guZnmb;
    let $ekQoKj;
    let $MxLWci;
    let $nYUlmc;
    let $TnoeAd;
    let $uCAqdl;
    let $dZpqRc;
    let $EbNHrg;
    let $GKGNBd;
    let $VXQeQb;
    let $IQbuUi;
    let $EGlXgk;
    let $PTvHbc;
    let $qIiilb;
    let $yZCuEi;
    let $wTQKvf;
    let $cxaHUd;
    let $DnNlzc;
    let $ObzwMa;
    let $IcwRId;
    let $ghjiRe;
    let $UmhsSc;
    let $OBtcha;
    let $pEVHff;
    let $NtOpXj;
    let $MUmYtk;
    let $ubUaJb;
    let $stLTRf;
    let $thjyvd;
    let $HEVdRi;
    let $wLrZae;
    let $igdQkh;
    let $yXCaJc;
    let $PBLLCd;
    let $lWLWvd;
    let $PpQeBd;
    let $IJLWwb;
    let $bVEyei;
    let $SpcWZh;
    let $RhThVj;
    let $akuKlh;
    let $ptWYze;
    let $EZPVmd;
    let $NamMrg;
    let $FMrHIe;
    let $dAoIve;
    let $lIZMdf;
    let $uZZbmg;
    let $mtPbWg;
    let $JDPFHg;
    let $iFREEf;
    let $qcLebf;
    let $Uvdtsk;
    let $bdbMHd;
    let $PYHmyg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.Attendant", 
    {
  "h": 62844,
  "f": "LivingThing.Core.IOT.Devices.Attendant",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Attendant",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Attendant",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5BdHRlbmRhbnQuU21hcnRBdHRlbmRhbnREZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIlNtYXJ0IEhvbWUiIF0sDQogICAgICAiQWxpYXNlcyI6ICJBdHRlbmRhbnQiLA0KICAgICAgIk5hbWUiOiAiU21hcnQgQXR0ZW5kYW50IiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJCaW9tZXRyaWMgYW5kIElkLUNhcmQgY2xvdWQgY29ubmVjdGVkIGNsb2NrLWluIHN5c3RlbSBmb3IgbWFuYWdpbmcgZXZlbnQgYW5kIGF0dGVuZGFuY2VzLiIsDQogICAgICAiQmFubmVySW1hZ2UiOiAifi9pbWcvYmFubmVyNC5qcGciLA0KICAgICAgIkltYWdlcyI6IFsgIn4vaW1nL3NlcnZlci9iYW5uZXIxLmpwZyIsICJ\u002BL2ltZy9zZXJ2ZXIvYmFubmVyMi5qcGciLCAifi9pbWcvc2VydmVyL2Jhbm5lcjMuanBnIiwgIn4vaW1nL3NlcnZlci9iYW5uZXI0LmpwZyIgXSwNCiAgICAgICJJY29uIjogeyAiTmFtZSI6ICJtZGkgbWRpLWVsZWN0cmljLXN3aXRjaCIgfSwNCiAgICAgICJUaGVtZUNvbG9yIjogIiNkNzdiYmEiLA0KICAgICAgIkZsYWdzIjogIkZlYXR1cmVkLFB1Ymxpc2hlZCIsDQogICAgICAiU2VjdXJpdGllcyI6ICJDaGFsbGVuZ2VIYW5kU2hha2VBdXRoZW50aWNhdGlvblByb3RvY29sLEFkdmFuY2VkRW5jcnlwdGlvblN0YW5kYXJkLEVsbGlwdGljQ3VydmVGaXJtd2FyZVVwZGF0ZVNpZ25pbmciLA0KICAgICAgIkZlYXR1cmVzIjogWw0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIlJlbW90ZSBNb25pdG9yaW5nIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiQ2hlY2sgYW5kIHNlZSB3aG8gaGFzIGNoZWtlZCBpbiBmb3IgdGhlIGRheSByZW1vdGVseSBmcm9tIGlTbWFydCBtb2JpbGUgYXBwLiIsDQogICAgICAgICAgIkljb24iOiB7ICJJY29uIjogIm1kaSBtZGktcmVtb3RlLXR2IiB9DQogICAgICAgIH0NCiAgICAgIF0sDQogICAgICAiQmVuZWZpdHMiOiBbDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiUmVhbC10aW1lIEFjY2VzcyIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIlN0YXkgY29uZWN0ZWQgdG8geW91ciBidXNpbmVzcyBmcm9tIGFueXdoZXJlIHlvdSBtaWdodCBiZSIsDQogICAgICAgICAgIkljb24iOiB7ICJJY29uIjogIm1kaSBtZGktY2hhcnQiIH0NCiAgICAgICAgfQ0KICAgICAgXSwNCiAgICAgICJTcGVjaWZpY2F0aW9ucyI6IFsNCiAgICAgICAgew0KICAgICAgICAgICJUaXRsZSI6ICJTdXBwbHkgVm9sdGFnZSIsDQogICAgICAgICAgIlZhbHVlIjogIjVWIg0KICAgICAgICB9DQogICAgICBdDQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1963388)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceScopeModelCustomAttributesProvider`, ($self) => class SmartAttendantDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296930684)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296930684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296930684)
            
            static $h = 1963388;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296930684),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1963388,
      "h": 4296930684,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296930684)
  ],
  "h": 1963388
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1963388)
        
        

        //--TRIMMABLE-BOUNDARY-START(1701244)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SmartAttendantDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296668540)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296668540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$$($.$MCAB.LCIDAMS.SmartAttendantStatusModel, $.$MCAB.LCIDAM.SmartAttendantLogModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296668540)
            
            static $h = 1701244;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296668540),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1701244,
      "h": 4296668540,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296668540)
  ],
  "h": 1701244
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1701244)
        
        

        //--TRIMMABLE-BOUNDARY-START(914812)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelCustomAttributesProvider`, ($self) => class SmartAttendantEmptyFingerPrintTemplateControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295882108)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295882108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295882108)
            
            static $h = 914812;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295882108),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 914812,
      "h": 4295882108,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295882108)
  ],
  "h": 914812
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantEmptyFingerPrintTemplateControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantEmptyFingerPrintTemplateControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(914812)
        
        

        //--TRIMMABLE-BOUNDARY-START(4126076)
        $asm.$cls(`$MCAB.LCIDAS$1.SmartAttendantDeviceSettingsCustomAttributesProvider`, ($self) => class SmartAttendantDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299093372)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299093372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299093372)
            
            static $h = 4126076;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299093372),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4126076,
      "h": 4299093372,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299093372)
  ],
  "h": 4126076
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Settings${separator}SmartAttendantDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4126076)
        
        

        //--TRIMMABLE-BOUNDARY-START(1176956)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantCommandsModelCustomAttributesProvider`, ($self) => class SmartAttendantCommandsModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296144252)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296144252)
            
            //--TRIMMABLE-BOUNDARY-START(8591111548)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591111548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$MCAB.LCIDAM.SmartAttendantCommandsModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("On", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (13432);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$MCAB.LCIDAM.SmartAttendantCommandsModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $CGlcQh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1176956,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $YiFgpa ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1176956,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591111548)
            
            static $h = 1176956;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591111548),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1176956,
      "h": 8591111548,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591111548)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296144252),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1176956,
      "h": 4296144252,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296144252)
  ],
  "h": 1176956
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantCommandsModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantCommandsModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1176956)
        
        

        //--TRIMMABLE-BOUNDARY-START(2749820)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantServiceModelCustomAttributesProvider`, ($self) => class SmartAttendantServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297717116)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297717116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297717116)
            
            static $h = 2749820;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297717116),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2749820,
      "h": 4297717116,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297717116)
  ],
  "h": 2749820
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2749820)
        
        

        //--TRIMMABLE-BOUNDARY-START(2094460)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SmartAttendantDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592029052)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592029052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $boIigl ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2094460,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592029052)
            
            //--TRIMMABLE-BOUNDARY-START(4297061756)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297061756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297061756)
            
            //--TRIMMABLE-BOUNDARY-START(4297061756)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297061756)
            
            static $h = 2094460;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592029052),
    {
      "r": 65537,
      "n": "Register",
      "d": 2094460,
      "h": 8592029052,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592029052)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297061756),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2094460,
      "h": 4297061756,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297061756)
  ],
  "h": 2094460
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2094460)
        
        

        //--TRIMMABLE-BOUNDARY-START(128380)
        $asm.$cls(`$MCAB.LCIDA._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295095676)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295095676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$MCAB.LCIDA.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295095676)
            
            static $h = 128380;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295095676),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 128380,
      "h": 4295095676,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295095676)
  ],
  "h": 128380
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(128380)
        
        

        //--TRIMMABLE-BOUNDARY-START(1832316)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SmartAttendantDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591766908)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591766908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $gSUUOb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1832316,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591766908)
            
            //--TRIMMABLE-BOUNDARY-START(4296799612)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296799612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296799612)
            
            //--TRIMMABLE-BOUNDARY-START(4296799612)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296799612)
            
            static $h = 1832316;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591766908),
    {
      "r": 65537,
      "n": "Register",
      "d": 1832316,
      "h": 8591766908,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591766908)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296799612),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1832316,
      "h": 4296799612,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296799612)
  ],
  "h": 1832316
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1832316)
        
        

        //--TRIMMABLE-BOUNDARY-START(2225532)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelCustomAttributesProvider`, ($self) => class SmartAttendantDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297192828)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297192828)
            
            //--TRIMMABLE-BOUNDARY-START(8592160124)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592160124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Ack", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $mfLwbb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2225532,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $eprRXe ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2225532,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592160124)
            
            static $h = 2225532;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592160124),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2225532,
      "h": 8592160124,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592160124)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297192828),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2225532,
      "h": 4297192828,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297192828)
  ],
  "h": 2225532
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2225532)
        
        

        //--TRIMMABLE-BOUNDARY-START(1308028)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantCommandsModelTypeDescriptorBuilder`, ($self) => class SmartAttendantCommandsModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591242620)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591242620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAM.SmartAttendantCommandsModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAM.SmartAttendantCommandsModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantCommandsModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $bNDmSf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1308028,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAM.SmartAttendantCommandsModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591242620)
            
            //--TRIMMABLE-BOUNDARY-START(4296275324)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296275324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296275324)
            
            //--TRIMMABLE-BOUNDARY-START(4296275324)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296275324)
            
            static $h = 1308028;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591242620),
    {
      "r": 65537,
      "n": "Register",
      "d": 1308028,
      "h": 8591242620,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591242620)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296275324),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1308028,
      "h": 4296275324,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296275324)
  ],
  "h": 1308028
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantCommandsModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantCommandsModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1308028)
        
        

        //--TRIMMABLE-BOUNDARY-START(3011964)
        $asm.$cls(`$MCAB.LCIDAMS.SmartAttendantStatusModelCustomAttributesProvider`, ($self) => class SmartAttendantStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297979260)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297979260)
            
            //--TRIMMABLE-BOUNDARY-START(8592946556)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592946556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$MCAB.LCIDAMS.SmartAttendantStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("EnrolId", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (256);
                            $i3.ConvertType = ($.$$.S.Int16.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BatteryVoltage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (257);
                            $i4.ConvertType = ($.$$.S.Int16.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$MCAB.LCIDAMS.SmartAttendantStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $Swtzif ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3011964,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $guZnmb ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3011964,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592946556)
            
            static $h = 3011964;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592946556),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3011964,
      "h": 8592946556,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592946556)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297979260),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3011964,
      "h": 4297979260,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297979260)
  ],
  "h": 3011964
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Statuses${separator}SmartAttendantStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3011964)
        
        

        //--TRIMMABLE-BOUNDARY-START(259452)
        $asm.$cls(`$MCAB.LCIDA.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295226748)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295226748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelCustomAttributesProvider, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAM.SmartAttendantCommandsModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAM.SmartAttendantCommandsModelCustomAttributesProvider, $.$MCAB.LCIDAM.SmartAttendantCommandsModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelCustomAttributesProvider, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAM.SmartAttendantDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAM.SmartAttendantDeviceModelCustomAttributesProvider, $.$MCAB.LCIDAM.SmartAttendantDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModelCustomAttributesProvider, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAM.SmartAttendantDeviceScopeModelCustomAttributesProvider, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelCustomAttributesProvider, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelCustomAttributesProvider, $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAM.SmartAttendantLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAM.SmartAttendantLogModelCustomAttributesProvider, $.$MCAB.LCIDAM.SmartAttendantLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAM.SmartAttendantServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAM.SmartAttendantServiceModelCustomAttributesProvider, $.$MCAB.LCIDAM.SmartAttendantServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAMS.SmartAttendantStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAMS.SmartAttendantStatusModelCustomAttributesProvider, $.$MCAB.LCIDAMS.SmartAttendantStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsCustomAttributesProvider, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MCAB.LCIDAS$1.SmartAttendantDeviceSettingsCustomAttributesProvider, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295226748)
            
            static $h = 259452;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295226748),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 259452,
      "h": 4295226748,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295226748)
  ],
  "h": 259452
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(259452)
        
        

        //--TRIMMABLE-BOUNDARY-START(1045884)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptorBuilder`, ($self) => class SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590980476)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590980476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantEmptyFingerPrintTemplateControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ekQoKj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1045884,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590980476)
            
            //--TRIMMABLE-BOUNDARY-START(4296013180)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296013180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296013180)
            
            //--TRIMMABLE-BOUNDARY-START(4296013180)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296013180)
            
            static $h = 1045884;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590980476),
    {
      "r": 65537,
      "n": "Register",
      "d": 1045884,
      "h": 8590980476,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590980476)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296013180),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1045884,
      "h": 4296013180,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296013180)
  ],
  "h": 1045884
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1045884)
        
        

        //--TRIMMABLE-BOUNDARY-START(1570172)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceModelTypeDescriptorBuilder`, ($self) => class SmartAttendantDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591504764)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591504764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAM.SmartAttendantDeviceModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAM.SmartAttendantDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $TnoeAd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1570172,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAM.SmartAttendantDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591504764)
            
            //--TRIMMABLE-BOUNDARY-START(4296537468)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296537468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296537468)
            
            //--TRIMMABLE-BOUNDARY-START(4296537468)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296537468)
            
            static $h = 1570172;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591504764),
    {
      "r": 65537,
      "n": "Register",
      "d": 1570172,
      "h": 8591504764,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591504764)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296537468),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1570172,
      "h": 4296537468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296537468)
  ],
  "h": 1570172
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1570172)
        
        

        //--TRIMMABLE-BOUNDARY-START(521596)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptorBuilder`, ($self) => class SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590456188)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590456188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantAddFingerPrintTemplateControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $dZpqRc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":521596,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590456188)
            
            //--TRIMMABLE-BOUNDARY-START(4295488892)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295488892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295488892)
            
            //--TRIMMABLE-BOUNDARY-START(4295488892)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295488892)
            
            static $h = 521596;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590456188),
    {
      "r": 65537,
      "n": "Register",
      "d": 521596,
      "h": 8590456188,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590456188)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295488892),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 521596,
      "h": 4295488892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295488892)
  ],
  "h": 521596
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(521596)
        
        

        //--TRIMMABLE-BOUNDARY-START(652668)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelCustomAttributesProvider`, ($self) => class SmartAttendantDeleteFingerPrintTemplateControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295619964)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295619964)
            
            //--TRIMMABLE-BOUNDARY-START(8590587260)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590587260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Id", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $wTQKvf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":652668,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $cxaHUd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":652668,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590587260)
            
            static $h = 652668;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590587260),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 652668,
      "h": 8590587260,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590587260)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295619964),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 652668,
      "h": 4295619964,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295619964)
  ],
  "h": 652668
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantDeleteFingerPrintTemplateControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantDeleteFingerPrintTemplateControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(652668)
        
        

        //--TRIMMABLE-BOUNDARY-START(3863932)
        $asm.$cls(`$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SmartAttendantDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298831228)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298831228)
            
            //--TRIMMABLE-BOUNDARY-START(8593798524)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593798524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("ScannerWebUrl", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "swu";
                            $i3.Order = (20);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("ScannerWebService", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Key = "sws";
                            $i4.Order = (21);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("scannerWebServiceTarget", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Key = "swt";
                            $i5.Order = (22);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $DnNlzc ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3863932,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ObzwMa ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3863932,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593798524)
            
            static $h = 3863932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593798524),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3863932,
      "h": 8593798524,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593798524)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298831228),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3863932,
      "h": 4298831228,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298831228)
  ],
  "h": 3863932
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Settings${separator}SmartAttendantDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3863932)
        
        

        //--TRIMMABLE-BOUNDARY-START(1439100)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceModelCustomAttributesProvider`, ($self) => class SmartAttendantDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296406396)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296406396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296406396)
            
            static $h = 1439100;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296406396),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1439100,
      "h": 4296406396,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296406396)
  ],
  "h": 1439100
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1439100)
        
        

        //--TRIMMABLE-BOUNDARY-START(4650364)
        $asm.$cls(`$MCAB.LCIDA.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299617660)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299617660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAM.SmartAttendantCommandsModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAM.SmartAttendantDeviceModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAM.SmartAttendantLogModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAM.SmartAttendantServiceModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299617660)
            
            static $h = 4650364;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299617660),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4650364,
      "h": 4299617660,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299617660)
  ],
  "h": 4650364
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4650364)
        
        

        //--TRIMMABLE-BOUNDARY-START(783740)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptorBuilder`, ($self) => class SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590718332)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590718332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantDeleteFingerPrintTemplateControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ghjiRe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":783740,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590718332)
            
            //--TRIMMABLE-BOUNDARY-START(4295751036)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295751036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295751036)
            
            //--TRIMMABLE-BOUNDARY-START(4295751036)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295751036)
            
            static $h = 783740;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590718332),
    {
      "r": 65537,
      "n": "Register",
      "d": 783740,
      "h": 8590718332,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590718332)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295751036),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 783740,
      "h": 4295751036,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295751036)
  ],
  "h": 783740
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(783740)
        
        

        //--TRIMMABLE-BOUNDARY-START(2487676)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantLogModelCustomAttributesProvider`, ($self) => class SmartAttendantLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297454972)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297454972)
            
            //--TRIMMABLE-BOUNDARY-START(8592422268)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592422268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$MCAB.LCIDAM.SmartAttendantLogModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Id", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (12);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$MCAB.LCIDAM.SmartAttendantLogModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $NtOpXj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2487676,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $MUmYtk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2487676,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceLogModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592422268)
            
            static $h = 2487676;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592422268),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2487676,
      "h": 8592422268,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592422268)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297454972),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2487676,
      "h": 4297454972,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297454972)
  ],
  "h": 2487676
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2487676)
        
        

        //--TRIMMABLE-BOUNDARY-START(390524)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelCustomAttributesProvider`, ($self) => class SmartAttendantAddFingerPrintTemplateControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295357820)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295357820)
            
            //--TRIMMABLE-BOUNDARY-START(8590325116)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590325116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Id", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ubUaJb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":390524,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $stLTRf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":390524,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590325116)
            
            static $h = 390524;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590325116),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 390524,
      "h": 8590325116,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590325116)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295357820),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 390524,
      "h": 4295357820,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295357820)
  ],
  "h": 390524
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantAddFingerPrintTemplateControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantAddFingerPrintTemplateControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(390524)
        
        

        //--TRIMMABLE-BOUNDARY-START(2356604)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SmartAttendantDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592291196)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592291196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $thjyvd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2356604,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592291196)
            
            //--TRIMMABLE-BOUNDARY-START(4297323900)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297323900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297323900)
            
            //--TRIMMABLE-BOUNDARY-START(4297323900)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297323900)
            
            static $h = 2356604;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592291196),
    {
      "r": 65537,
      "n": "Register",
      "d": 2356604,
      "h": 8592291196,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592291196)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297323900),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2356604,
      "h": 4297323900,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297323900)
  ],
  "h": 2356604
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2356604)
        
        

        //--TRIMMABLE-BOUNDARY-START(3143036)
        $asm.$cls(`$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptorBuilder`, ($self) => class SmartAttendantStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593077628)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593077628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $yXCaJc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3143036,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAMS.SmartAttendantStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593077628)
            
            //--TRIMMABLE-BOUNDARY-START(4298110332)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298110332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298110332)
            
            //--TRIMMABLE-BOUNDARY-START(4298110332)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298110332)
            
            static $h = 3143036;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593077628),
    {
      "r": 65537,
      "n": "Register",
      "d": 3143036,
      "h": 8593077628,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593077628)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298110332),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3143036,
      "h": 4298110332,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298110332)
  ],
  "h": 3143036
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Statuses${separator}SmartAttendantStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3143036)
        
        

        //--TRIMMABLE-BOUNDARY-START(2880892)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantServiceModelTypeDescriptorBuilder`, ($self) => class SmartAttendantServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592815484)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592815484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAM.SmartAttendantServiceModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAM.SmartAttendantServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SpcWZh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2880892,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAM.SmartAttendantServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592815484)
            
            //--TRIMMABLE-BOUNDARY-START(4297848188)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297848188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297848188)
            
            //--TRIMMABLE-BOUNDARY-START(4297848188)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297848188)
            
            static $h = 2880892;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592815484),
    {
      "r": 65537,
      "n": "Register",
      "d": 2880892,
      "h": 8592815484,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592815484)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297848188),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2880892,
      "h": 4297848188,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297848188)
  ],
  "h": 2880892
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2880892)
        
        

        //--TRIMMABLE-BOUNDARY-START(4257148)
        $asm.$cls(`$MCAB.LCIDAS$1.SmartAttendantDeviceSettingsTypeDescriptorBuilder`, ($self) => class SmartAttendantDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594191740)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594191740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettingsTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $akuKlh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4257148,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594191740)
            
            //--TRIMMABLE-BOUNDARY-START(4299224444)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299224444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299224444)
            
            //--TRIMMABLE-BOUNDARY-START(4299224444)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299224444)
            
            static $h = 4257148;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594191740),
    {
      "r": 65537,
      "n": "Register",
      "d": 4257148,
      "h": 8594191740,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594191740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299224444),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4257148,
      "h": 4299224444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299224444)
  ],
  "h": 4257148
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Settings${separator}SmartAttendantDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4257148)
        
        

        //--TRIMMABLE-BOUNDARY-START(3995004)
        $asm.$cls(`$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SmartAttendantDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593929596)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593929596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $EZPVmd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3995004,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593929596)
            
            //--TRIMMABLE-BOUNDARY-START(4298962300)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298962300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298962300)
            
            //--TRIMMABLE-BOUNDARY-START(4298962300)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298962300)
            
            static $h = 3995004;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593929596),
    {
      "r": 65537,
      "n": "Register",
      "d": 3995004,
      "h": 8593929596,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593929596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298962300),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3995004,
      "h": 4298962300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298962300)
  ],
  "h": 3995004
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Settings${separator}SmartAttendantDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3995004)
        
        

        //--TRIMMABLE-BOUNDARY-START(2618748)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantLogModelTypeDescriptorBuilder`, ($self) => class SmartAttendantLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592553340)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592553340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MCAB.LCIDAM.SmartAttendantLogModelTypeDescriptor()
                        const $t1 = $.$MCAB.LCIDAM.SmartAttendantLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iFREEf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2618748,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MCAB.LCIDAM.SmartAttendantLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592553340)
            
            //--TRIMMABLE-BOUNDARY-START(4297586044)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297586044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297586044)
            
            //--TRIMMABLE-BOUNDARY-START(4297586044)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297586044)
            
            static $h = 2618748;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592553340),
    {
      "r": 65537,
      "n": "Register",
      "d": 2618748,
      "h": 8592553340,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592553340)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297586044),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2618748,
      "h": 4297586044,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297586044)
  ],
  "h": 2618748
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2618748)
        
        

        //--TRIMMABLE-BOUNDARY-START(193916)
        $asm.$cls(`$MCAB.LCIDA.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180063100)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$sl.SL.Enumerable.Empty($.$$.S.String);
            }
            //--TRIMMABLE-BOUNDARY-END(17180063100)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295161212)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295161212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295161212)
            
            //--TRIMMABLE-BOUNDARY-START(4295161212)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295161212)
            
            static $h = 193916;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180063100),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885095804,
        "f": 50331649
      },
      "n": "Paths",
      "d": 193916,
      "h": 17180063100,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180063100)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295161212),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 193916,
      "h": 4295161212,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295161212)
  ],
  "h": 193916
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(193916)
        
        

        //--TRIMMABLE-BOUNDARY-START(3536252)
        $asm.$cls(`$MCAB.LCIDA.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593470844)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593470844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$MCAB.LCIDA.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$MCAB.LCIDA.SmartAttendantDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$MCAB.LCIDA.SmartAttendantDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$MCAB.LCIDA.SmartAttendantDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MCAB.LCIDA.SmartAttendantDeviceFamily, x);
                }, $IQbuUi ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":3536252,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MCAB.LCIDA.SmartAttendantDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$MCAB.LCIDA.SmartAttendantDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $EGlXgk ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":3536252,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$MCAB.LCIDA.SmartAttendantDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MCAB.LCIDA.SmartAttendantDeviceFamily, x);
                }, $PTvHbc ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$MCAB.LCIDA.SmartAttendantDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":3536252,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MCAB.LCIDA.SmartAttendantDeviceFamily, x);
                }, $qIiilb ??= {"r":$.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType).$h,"p":[{"n":"x","p":327718}],"n":"","d":3536252,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MCAB.LCIDA.SmartAttendantDeviceFamily, x);
                }, $yZCuEi ??= {"r":$.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType).$h,"p":[{"n":"x","p":327718}],"n":"","d":3536252,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$MCAB.LCIDA.SmartAttendantDevice), $.$MCAB.LCIDAP.SmartAttendantDeviceCommands$$($.$MCAB.LCIDA.SmartAttendantDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$MCAB.LCIDA.SmartAttendantDevice), $.$MCAB.LCIDAV$1.SmartAttendantViewRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$MCAB.LCIDAV.SmartAttendantClientAppViewModel, services);
                $.$MCAB.LCIDA.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$MCAB.LCIDA.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8593470844)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$MCAB.LCIDA.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4298503548)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298503548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298503548)
            
            //--TRIMMABLE-BOUNDARY-START(4298503548)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298503548)
            
            static $h = 3536252;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593470844),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 3536252,
      "h": 8593470844,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593470844)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298503548),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3536252,
      "h": 4298503548,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298503548)
  ],
  "h": 3536252
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3536252)
        
        

        //--TRIMMABLE-BOUNDARY-START(3208572)
        $asm.$cls(`$MCAB.LCIDA.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183077756)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MCAB.LCIDAV$1.SmartAttendantDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MCAB.LCIDAV$1.SmartAttendantDeviceDetails().$ctor$4();
                    }, $IcwRId ??= {"r":2752627,"n":"","d":3208572,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17183077756)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4298175868)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298175868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298175868)
            
            //--TRIMMABLE-BOUNDARY-START(4298175868)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298175868)
            
            static $h = 3208572;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183077756),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888110460,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 3208572,
      "h": 17183077756,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183077756)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298175868),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3208572,
      "h": 4298175868,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298175868)
  ],
  "h": 3208572
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3208572)
        
        

        //--TRIMMABLE-BOUNDARY-START(5240188)
        $asm.$cls(`$MCAB.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4300207484)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300207484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300207484)
            
            //--TRIMMABLE-BOUNDARY-START(4300207484)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300207484)
            
            static $h = 5240188;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300207484),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5240188,
      "h": 4300207484,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300207484)
  ],
  "h": 5240188
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5240188)
        
        

        //--TRIMMABLE-BOUNDARY-START(5305724)
        $asm.$cls(`$MCAB.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4300273020)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300273020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300273020)
            
            //--TRIMMABLE-BOUNDARY-START(4300273020)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4300273020)
            
            static $h = 5305724;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300273020),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5305724,
      "h": 4300273020,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300273020)
  ],
  "h": 5305724,
  "a": [
    {
      "t": 5240188,
      "c": 4300207484
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5305724)
        
        

        //--TRIMMABLE-BOUNDARY-START(849276)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel`, ($self) => class SmartAttendantEmptyFingerPrintTemplateControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295816572)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295816572);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295816572)
            
            //--TRIMMABLE-BOUNDARY-START(8590783868)
            /*int */ get Command()
            {
                return ((128 + 3) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(8590783868)
            
            //--TRIMMABLE-BOUNDARY-START(4295816572)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295816572)
            
            static $h = 849276;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590783868),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180718460,
        "f": 50364417
      },
      "n": "Command",
      "d": 849276,
      "h": 8590783868,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590783868)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295816572),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 849276,
      "h": 4295816572,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295816572)
  ],
  "h": 849276
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantEmptyFingerPrintTemplateControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantEmptyFingerPrintTemplateControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(849276)
        
        

        //--TRIMMABLE-BOUNDARY-START(324988)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel`, ($self) => class SmartAttendantAddFingerPrintTemplateControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590259580)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590259580);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590259580)
            
            //--TRIMMABLE-BOUNDARY-START(12885226876)
            $ctor$3(/*int*/ id)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885226876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Id = $.$cast(id, $.$$.S.Byte);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885226876)
            
            //--TRIMMABLE-BOUNDARY-START(17180194172)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17180194172)
            
            //--TRIMMABLE-BOUNDARY-START(38655030652)
            /*byte*/ Id = 0;
            //--TRIMMABLE-BOUNDARY-END(38655030652)
            
            //--TRIMMABLE-BOUNDARY-START(8590259580)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590259580)
            
            static $h = 324988;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180194172),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770128764,
        "f": 50364417
      },
      "n": "Command",
      "d": 324988,
      "h": 17180194172,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180194172),
//--TRIMMABLE-BOUNDARY-START(38655030652),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360063356,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244965244,
        "f": 83886082
      },
      "n": "Id",
      "d": 324988,
      "h": 38655030652,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655030652)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590259580),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 324988,
      "h": 8590259580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590259580),
//--TRIMMABLE-BOUNDARY-START(12885226876),
    {
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 324988,
      "h": 12885226876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885226876)
  ],
  "h": 324988
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantAddFingerPrintTemplateControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantAddFingerPrintTemplateControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(324988)
        
        

        //--TRIMMABLE-BOUNDARY-START(587132)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel`, ($self) => class SmartAttendantDeleteFingerPrintTemplateControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590521724)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590521724);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590521724)
            
            //--TRIMMABLE-BOUNDARY-START(12885489020)
            $ctor$3(/*int*/ id)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885489020);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Id = $.$cast(id, $.$$.S.Byte);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885489020)
            
            //--TRIMMABLE-BOUNDARY-START(17180456316)
            /*int */ get Command()
            {
                return ((128 + 2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17180456316)
            
            //--TRIMMABLE-BOUNDARY-START(38655292796)
            /*byte*/ Id = 0;
            //--TRIMMABLE-BOUNDARY-END(38655292796)
            
            //--TRIMMABLE-BOUNDARY-START(8590521724)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590521724)
            
            static $h = 587132;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180456316),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770390908,
        "f": 50364417
      },
      "n": "Command",
      "d": 587132,
      "h": 17180456316,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180456316),
//--TRIMMABLE-BOUNDARY-START(38655292796),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360325500,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245227388,
        "f": 83886082
      },
      "n": "Id",
      "d": 587132,
      "h": 38655292796,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655292796)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590521724),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 587132,
      "h": 8590521724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590521724),
//--TRIMMABLE-BOUNDARY-START(12885489020),
    {
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 587132,
      "h": 12885489020,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885489020)
  ],
  "h": 587132
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantDeleteFingerPrintTemplateControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantDeleteFingerPrintTemplateControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(587132)
        
        

        //--TRIMMABLE-BOUNDARY-START(2946428)
        $asm.$cls(`$MCAB.LCIDAMS.SmartAttendantStatusModel`, ($self) => class SmartAttendantStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(21477782908)
            /*int*/ EnrolId = 0;
            //--TRIMMABLE-BOUNDARY-END(21477782908)
            
            //--TRIMMABLE-BOUNDARY-START(17182815612)
            /*float*/ BatteryVoltage = 0;
            //--TRIMMABLE-BOUNDARY-END(17182815612)
            
            //--TRIMMABLE-BOUNDARY-START(12887848316)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887848316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887848316)
            
            //--TRIMMABLE-BOUNDARY-START(12887848316)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887848316)
            
            static $h = 2946428;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477782908),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657652092,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837521276,
        "f": 83886081
      },
      "n": "EnrolId",
      "d": 2946428,
      "h": 21477782908,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 256,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21477782908),
//--TRIMMABLE-BOUNDARY-START(17182815612),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067717500,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247586684,
        "f": 83886081
      },
      "n": "BatteryVoltage",
      "d": 2946428,
      "h": 17182815612,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 257,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 524289,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17182815612)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887848316),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2946428,
      "h": 12887848316,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887848316)
  ],
  "h": 2946428
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Statuses${separator}SmartAttendantStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2946428)
        
        

        //--TRIMMABLE-BOUNDARY-START(2422140)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantLogModel`, ($self) => class SmartAttendantLogModel extends $.$XBGm.LCICDi.iSmartDeviceLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(30067193212)
            /*string?*/ Id = null;
            //--TRIMMABLE-BOUNDARY-END(30067193212)
            
            //--TRIMMABLE-BOUNDARY-START(34362160508)
            /*bool */ get IsValid()
            {
                return this.Id !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(34362160508)
            
            //--TRIMMABLE-BOUNDARY-START(8592356732)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592356732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592356732)
            
            //--TRIMMABLE-BOUNDARY-START(8592356732)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592356732)
            
            static $h = 2422140;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067193212),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182291324,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42952095100,
        "f": 83886081
      },
      "n": "Id",
      "d": 2422140,
      "h": 30067193212,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 12,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30067193212),
//--TRIMMABLE-BOUNDARY-START(34362160508),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772225916,
        "f": 50364417
      },
      "n": "IsValid",
      "d": 2422140,
      "h": 34362160508,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362160508)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592356732),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2422140,
      "h": 8592356732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592356732)
  ],
  "h": 2422140
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2422140)
        
        

        //--TRIMMABLE-BOUNDARY-START(2159996)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel`, ($self) => class SmartAttendantDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(12887061884)
            /*iSmartDeviceAcknowledgeLogModel?*/ Ack = null;
            //--TRIMMABLE-BOUNDARY-END(12887061884)
            
            //--TRIMMABLE-BOUNDARY-START(8592094588)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592094588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592094588)
            
            //--TRIMMABLE-BOUNDARY-START(8592094588)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8592094588)
            
            static $h = 2159996;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887061884),
    {
      "p": 15635857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476996476,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066931068,
        "f": 83886081
      },
      "n": "Ack",
      "d": 2159996,
      "h": 12887061884,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887061884)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592094588),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2159996,
      "h": 8592094588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592094588)
  ],
  "h": 2159996
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2159996)
        
        

        //--TRIMMABLE-BOUNDARY-START(980348)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor`, ($self) => class SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295947644)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295947644);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel, this, factory);
                    }, $MxLWci ??= {"r":65537,"n":"","d":980348,"h":0,"f":17825794}), 0, "SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantEmptyFingerPrintTemplateControlModel_LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptorBuilder.g.cs", "SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295947644)
            
            //--TRIMMABLE-BOUNDARY-START(12885882236)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885882236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Command";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantEmptyFingerPrintTemplateControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel)).Command);
                        }, $nYUlmc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":980348,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885882236)
            
            //--TRIMMABLE-BOUNDARY-START(17180849532)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantEmptyFingerPrintTemplateControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180849532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180849532)
            
            //--TRIMMABLE-BOUNDARY-START(8590914940)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantEmptyFingerPrintTemplateControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590914940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590914940)
            
            static $h = 980348;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885882236),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 980348,
      "h": 12885882236,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885882236),
//--TRIMMABLE-BOUNDARY-START(17180849532),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 849276,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 980348,
      "h": 17180849532,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180849532),
//--TRIMMABLE-BOUNDARY-START(8590914940),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 849276,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 980348,
      "h": 8590914940,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590914940)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295947644),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 980348,
      "h": 4295947644,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295947644)
  ],
  "h": 980348
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantEmptyFingerPrintTemplateControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(980348)
        
        

        //--TRIMMABLE-BOUNDARY-START(456060)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor`, ($self) => class SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295423356)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295423356);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel, this, factory);
                    }, $EbNHrg ??= {"r":65537,"n":"","d":456060,"h":0,"f":17825794}), 0, "SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantAddFingerPrintTemplateControlModel_LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptorBuilder.g.cs", "SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295423356)
            
            //--TRIMMABLE-BOUNDARY-START(12885357948)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885357948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Byte, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantAddFingerPrintTemplateControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$1(($.$cast(target, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel)).Id);
                        }, $GKGNBd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":456060,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Command";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantAddFingerPrintTemplateControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel)).Command);
                        }, $VXQeQb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":456060,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885357948)
            
            //--TRIMMABLE-BOUNDARY-START(17180325244)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantAddFingerPrintTemplateControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180325244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Byte));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Byte, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.Byte)))
                    {
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180325244)
            
            //--TRIMMABLE-BOUNDARY-START(8590390652)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantAddFingerPrintTemplateControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590390652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590390652)
            
            static $h = 456060;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885357948),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 456060,
      "h": 12885357948,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885357948),
//--TRIMMABLE-BOUNDARY-START(17180325244),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 324988,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 456060,
      "h": 17180325244,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180325244),
//--TRIMMABLE-BOUNDARY-START(8590390652),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 324988,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 456060,
      "h": 8590390652,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590390652)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295423356),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 456060,
      "h": 4295423356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295423356)
  ],
  "h": 456060
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantAddFingerPrintTemplateControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(456060)
        
        

        //--TRIMMABLE-BOUNDARY-START(718204)
        $asm.$cls(`$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor`, ($self) => class SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295685500)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295685500);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel, this, factory);
                    }, $UmhsSc ??= {"r":65537,"n":"","d":718204,"h":0,"f":17825794}), 0, "SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantDeleteFingerPrintTemplateControlModel_LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptorBuilder.g.cs", "SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295685500)
            
            //--TRIMMABLE-BOUNDARY-START(12885620092)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885620092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Byte, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantDeleteFingerPrintTemplateControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$1(($.$cast(target, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel)).Id);
                        }, $OBtcha ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":718204,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Command";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantDeleteFingerPrintTemplateControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel)).Command);
                        }, $pEVHff ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":718204,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885620092)
            
            //--TRIMMABLE-BOUNDARY-START(17180587388)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantDeleteFingerPrintTemplateControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180587388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Byte));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Byte, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.Byte)))
                    {
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180587388)
            
            //--TRIMMABLE-BOUNDARY-START(8590652796)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantDeleteFingerPrintTemplateControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590652796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590652796)
            
            static $h = 718204;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885620092),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 718204,
      "h": 12885620092,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885620092),
//--TRIMMABLE-BOUNDARY-START(17180587388),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 587132,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 718204,
      "h": 17180587388,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180587388),
//--TRIMMABLE-BOUNDARY-START(8590652796),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 587132,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 718204,
      "h": 8590652796,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590652796)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295685500),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 718204,
      "h": 4295685500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295685500)
  ],
  "h": 718204
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Controls.SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Controls${separator}SmartAttendantDeleteFingerPrintTemplateControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(718204)
        
        

        //--TRIMMABLE-BOUNDARY-START(3077500)
        $asm.$cls(`$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptor`, ($self) => class SmartAttendantStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAMS.SmartAttendantStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298044796)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298044796);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAMS.SmartAttendantStatusModel, this, factory);
                    }, $PBLLCd ??= {"r":65537,"n":"","d":3077500,"h":0,"f":17825794}), 0, "SmartAttendantStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantStatusModel_LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModelTypeDescriptorBuilder.g.cs", "SmartAttendantStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298044796)
            
            //--TRIMMABLE-BOUNDARY-START(12887979388)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887979388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("EnrolId"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAMS.SmartAttendantStatusModel.$type, $.$discardRef(), "EnrolId", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("EnrolId")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "EnrolId";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$MCAB.LCIDAMS.SmartAttendantStatusModel)).EnrolId);
                        }, $lWLWvd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3077500,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.EnrolId = value.AsInt();
                        }, $PpQeBd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3077500,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BatteryVoltage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAMS.SmartAttendantStatusModel.$type, $.$discardRef(), "BatteryVoltage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BatteryVoltage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "BatteryVoltage";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$MCAB.LCIDAMS.SmartAttendantStatusModel)).BatteryVoltage);
                        }, $IJLWwb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3077500,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BatteryVoltage = value.AsFloat();
                        }, $bVEyei ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3077500,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887979388)
            
            //--TRIMMABLE-BOUNDARY-START(17182946684)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182946684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _EnrolId = _target.EnrolId;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("EnrolId"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _EnrolId, ($v) => _EnrolId = $v, $.$$.S.Int32)))
                    {
                        _target.EnrolId = _EnrolId;
                    }
                }
                {
                    /*var*/ let _BatteryVoltage = _target.BatteryVoltage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BatteryVoltage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _BatteryVoltage, ($v) => _BatteryVoltage = $v, $.$$.S.Single)))
                    {
                        _target.BatteryVoltage = _BatteryVoltage;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182946684)
            
            //--TRIMMABLE-BOUNDARY-START(8593012092)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593012092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAMS.SmartAttendantStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAMS.SmartAttendantStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMS.SmartAttendantStatusModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAMS.SmartAttendantStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMS.SmartAttendantStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAMS.SmartAttendantStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAMS.SmartAttendantStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593012092)
            
            static $h = 3077500;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAMS.SmartAttendantStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887979388),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3077500,
      "h": 12887979388,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887979388),
//--TRIMMABLE-BOUNDARY-START(17182946684),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2946428,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3077500,
      "h": 17182946684,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182946684),
//--TRIMMABLE-BOUNDARY-START(8593012092),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2946428,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3077500,
      "h": 8593012092,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593012092)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298044796),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3077500,
      "h": 4298044796,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298044796)
  ],
  "h": 3077500
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAMS.SmartAttendantStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}Statuses${separator}SmartAttendantStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3077500)
        
        

        //--TRIMMABLE-BOUNDARY-START(2553212)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantLogModelTypeDescriptor`, ($self) => class SmartAttendantLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297520508)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297520508);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAM.SmartAttendantLogModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAM.SmartAttendantLogModel, this, factory);
                    }, $qcLebf ??= {"r":65537,"n":"","d":2553212,"h":0,"f":17825794}), 0, "SmartAttendantLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantLogModel_LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModelTypeDescriptorBuilder.g.cs", "SmartAttendantLogModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297520508)
            
            //--TRIMMABLE-BOUNDARY-START(12887455100)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887455100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Id"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAM.SmartAttendantLogModel.$type, $.$discardRef(), "Id", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Id")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Id";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAM.SmartAttendantLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$MCAB.LCIDAM.SmartAttendantLogModel)).Id);
                        }, $Uvdtsk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2553212,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAM.SmartAttendantLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Id = value.AsReference($.$$.S.String);
                        }, $bdbMHd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2553212,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsValid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAM.SmartAttendantLogModel.$type, $.$discardRef(), "IsValid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsValid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "IsValid";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAM.SmartAttendantLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$MCAB.LCIDAM.SmartAttendantLogModel)).IsValid);
                        }, $PYHmyg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2553212,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887455100)
            
            //--TRIMMABLE-BOUNDARY-START(17182422396)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182422396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceLogModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceLogModel));
                {
                    /*var*/ let _Id = _target.Id;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Id"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Id, ($v) => _Id = $v, $.$$.S.String)))
                    {
                        _target.Id = _Id;
                    }
                }
                {
                    /*var*/ let _IsValid = _target.IsValid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsValid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsValid, ($v) => _IsValid = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182422396)
            
            //--TRIMMABLE-BOUNDARY-START(8592487804)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592487804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAM.SmartAttendantLogModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAM.SmartAttendantLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantLogModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAM.SmartAttendantLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAM.SmartAttendantLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592487804)
            
            static $h = 2553212;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887455100),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2553212,
      "h": 12887455100,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887455100),
//--TRIMMABLE-BOUNDARY-START(17182422396),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2422140,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2553212,
      "h": 17182422396,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182422396),
//--TRIMMABLE-BOUNDARY-START(8592487804),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2422140,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2553212,
      "h": 8592487804,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592487804)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297520508),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2553212,
      "h": 4297520508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297520508)
  ],
  "h": 2553212
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2553212)
        
        

        //--TRIMMABLE-BOUNDARY-START(3405180)
        $asm.$cls(`$MCAB.LCIDAP.SmartAttendantDeviceCommands<>`, (TDevice) => $asm.$gt(`$MCAB.LCIDAP.SmartAttendantDeviceCommands<>`, [TDevice], ($self) => class SmartAttendantDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12888307068)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12888307068)
            
            //--TRIMMABLE-BOUNDARY-START(17183274364)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183274364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$MCAB.LCIDAP.SmartAttendantDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17183274364)
            
            //--TRIMMABLE-BOUNDARY-START(8593339772)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593339772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593339772)
            
            //--TRIMMABLE-BOUNDARY-START(8593339772)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8593339772)
            
            //--TRIMMABLE-BOUNDARY-START(4298372476)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298372476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12888307068)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$MCAB.LCIDAP.SmartAttendantAddFingerPrintCommand().$ctor$6(), new $.$MCAB.LCIDAP.SmartAttendantDeleteFingerPrintCommand().$ctor$6(), new $.$MCAB.LCIDAP.SmartAttendantEmptyFingerPrintCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12888307068)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298372476)
            
            static $H = 3405180;
            static $h = 3405180;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183274364),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17183274364,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17183274364)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888307068),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12888307068,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12888307068)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593339772),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8593339772,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593339772)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 3405180,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Protocol.SmartAttendantDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Protocol${separator}SmartAttendantDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3405180)
        
        

        //--TRIMMABLE-BOUNDARY-START(3470716)
        $asm.$cls(`$MCAB.LCIDAP.SmartAttendantEmptyFingerPrintCommand`, ($self) => class SmartAttendantEmptyFingerPrintCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298438012)
            $ctor$6()
            {
                super.$ctor$5("Empty", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298438012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298438012)
            
            //--TRIMMABLE-BOUNDARY-START(17183339900)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-flask-empty"/*MaterialDesignIconNames.FlaskEmpty*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17183339900)
            
            //--TRIMMABLE-BOUNDARY-START(4298438012)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298438012)
            
            static $h = 3470716;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183339900),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888372604,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3470716,
      "h": 17183339900,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183339900)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298438012),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3470716,
      "h": 4298438012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298438012)
  ],
  "h": 3470716
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Protocol.SmartAttendantEmptyFingerPrintCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Protocol${separator}SmartAttendantEmptyFingerPrintCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3470716)
        
        

        //--TRIMMABLE-BOUNDARY-START(3274108)
        $asm.$cls(`$MCAB.LCIDAP.SmartAttendantAddFingerPrintCommand`, ($self) => class SmartAttendantAddFingerPrintCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298241404)
            $ctor$6()
            {
                super.$ctor$5("Add", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298241404);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298241404)
            
            //--TRIMMABLE-BOUNDARY-START(17183143292)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-plus"/*MaterialDesignIconNames.Plus*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17183143292)
            
            //--TRIMMABLE-BOUNDARY-START(4298241404)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298241404)
            
            static $h = 3274108;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183143292),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888175996,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3274108,
      "h": 17183143292,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183143292)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298241404),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3274108,
      "h": 4298241404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298241404)
  ],
  "h": 3274108
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Protocol.SmartAttendantAddFingerPrintCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Protocol${separator}SmartAttendantAddFingerPrintCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3274108)
        
        

        //--TRIMMABLE-BOUNDARY-START(3339644)
        $asm.$cls(`$MCAB.LCIDAP.SmartAttendantDeleteFingerPrintCommand`, ($self) => class SmartAttendantDeleteFingerPrintCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298306940)
            $ctor$6()
            {
                super.$ctor$5("Delete", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298306940);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298306940)
            
            //--TRIMMABLE-BOUNDARY-START(17183208828)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-delete"/*MaterialDesignIconNames.Delete*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17183208828)
            
            //--TRIMMABLE-BOUNDARY-START(4298306940)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298306940)
            
            static $h = 3339644;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183208828),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888241532,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3339644,
      "h": 17183208828,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183208828)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298306940),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3339644,
      "h": 4298306940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298306940)
  ],
  "h": 3339644
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Protocol.SmartAttendantDeleteFingerPrintCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Protocol${separator}SmartAttendantDeleteFingerPrintCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3339644)
        
        

        //--TRIMMABLE-BOUNDARY-START(2291068)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelTypeDescriptor`, ($self) => class SmartAttendantDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297258364)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297258364);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, this, factory);
                    }, $HEVdRi ??= {"r":65537,"n":"","d":2291068,"h":0,"f":17825794}), 0, "SmartAttendantDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantDeviceSendDataModel_LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SmartAttendantDeviceSendDataModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297258364)
            
            //--TRIMMABLE-BOUNDARY-START(12887192956)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887192956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Ack"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel.$type, $.$discardRef(), "Ack", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Ack")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Ack";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModel, ($.$cast(target, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel)).Ack);
                        }, $wLrZae ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2291068,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Ack = value.AsReference($.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModel);
                        }, $igdQkh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2291068,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887192956)
            
            //--TRIMMABLE-BOUNDARY-START(17182160252)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182160252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceSendDataModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceSendDataModel));
                {
                    /*var*/ let _Ack = _target.Ack;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Ack"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Ack, ($v) => _Ack = $v, $.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModel)))
                    {
                        _target.Ack = _Ack;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182160252)
            
            //--TRIMMABLE-BOUNDARY-START(8592225660)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592225660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592225660)
            
            static $h = 2291068;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887192956),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2291068,
      "h": 12887192956,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887192956),
//--TRIMMABLE-BOUNDARY-START(17182160252),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2159996,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2291068,
      "h": 17182160252,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182160252),
//--TRIMMABLE-BOUNDARY-START(8592225660),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2159996,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2291068,
      "h": 8592225660,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592225660)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297258364),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2291068,
      "h": 4297258364,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297258364)
  ],
  "h": 2291068
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2291068)
        
        

        //--TRIMMABLE-BOUNDARY-START(1111420)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantCommandsModel`, ($self) => class SmartAttendantCommandsModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(8591046012)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591046012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591046012)
            
            //--TRIMMABLE-BOUNDARY-START(12886013308)
            $ctor$5(/*SmartAttendantAddFingerPrintTemplateControlModel*/ on)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886013308);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.On = on;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886013308)
            
            //--TRIMMABLE-BOUNDARY-START(25770915196)
            /*SmartAttendantAddFingerPrintTemplateControlModel?*/ On = null;
            //--TRIMMABLE-BOUNDARY-END(25770915196)
            
            //--TRIMMABLE-BOUNDARY-START(8591046012)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8591046012)
            
            static $h = 1111420;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770915196),
    {
      "p": 324988,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475947900,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360849788,
        "f": 83886081
      },
      "n": "On",
      "d": 1111420,
      "h": 25770915196,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770915196)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591046012),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1111420,
      "h": 8591046012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591046012),
//--TRIMMABLE-BOUNDARY-START(12886013308),
    {
      "p": [
        {
          "n": "on",
          "p": 324988
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1111420,
      "h": 12886013308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886013308)
  ],
  "h": 1111420
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantCommandsModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantCommandsModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1111420)
        
        

        //--TRIMMABLE-BOUNDARY-START(1242492)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantCommandsModelTypeDescriptor`, ($self) => class SmartAttendantCommandsModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantCommandsModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296209788)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296209788);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAM.SmartAttendantCommandsModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAM.SmartAttendantCommandsModel, this, factory);
                    }, $ZTxKsh ??= {"r":65537,"n":"","d":1242492,"h":0,"f":17825794}), 0, "SmartAttendantCommandsModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantCommandsModel_LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantCommandsModelTypeDescriptorBuilder.g.cs", "SmartAttendantCommandsModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296209788)
            
            //--TRIMMABLE-BOUNDARY-START(12886144380)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886144380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("On"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAM.SmartAttendantCommandsModel.$type, $.$discardRef(), "On", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("On")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "On";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantCommandsModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAM.SmartAttendantCommandsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel, ($.$cast(target, $.$MCAB.LCIDAM.SmartAttendantCommandsModel)).On);
                        }, $nWPgck ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1242492,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAM.SmartAttendantCommandsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.On = value.AsReference($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel);
                        }, $pzdcck ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1242492,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886144380)
            
            //--TRIMMABLE-BOUNDARY-START(17181111676)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantCommandsModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181111676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                {
                    /*var*/ let _On = _target.On;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("On"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _On, ($v) => _On = $v, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel)))
                    {
                        _target.On = _On;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181111676)
            
            //--TRIMMABLE-BOUNDARY-START(8591177084)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantCommandsModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591177084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAM.SmartAttendantCommandsModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAM.SmartAttendantCommandsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantCommandsModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAM.SmartAttendantCommandsModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantCommandsModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAM.SmartAttendantCommandsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantCommandsModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591177084)
            
            static $h = 1242492;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantCommandsModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886144380),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1242492,
      "h": 12886144380,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886144380),
//--TRIMMABLE-BOUNDARY-START(17181111676),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1111420,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1242492,
      "h": 17181111676,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181111676),
//--TRIMMABLE-BOUNDARY-START(8591177084),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1111420,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1242492,
      "h": 8591177084,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591177084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296209788),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1242492,
      "h": 4296209788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296209788)
  ],
  "h": 1242492
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantCommandsModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantCommandsModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantCommandsModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1242492)
        
        

        //--TRIMMABLE-BOUNDARY-START(1635708)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel`, ($self) => class SmartAttendantDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$MCAB.LCIDAMS.SmartAttendantStatusModel, $.$MCAB.LCIDAM.SmartAttendantLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8591570300)
            /*IOTDeviceSendDataModel? */ Ack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591570300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Log !== null ? (() =>
                {
                    //new $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel()
                    const $t1 = $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel;
                    const $i1 = new $t1();
                    $i1.$ctor$3();
                    $i1.Ack = new $.$XBGm.LCICDi.iSmartDeviceAcknowledgeLogModel().$ctor$3(this.Log.SynchIndex);
                    return $i1;
                })() : super.Ack();
            }
            //--TRIMMABLE-BOUNDARY-END(8591570300)
            
            //--TRIMMABLE-BOUNDARY-START(4296603004)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296603004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296603004)
            
            //--TRIMMABLE-BOUNDARY-START(4296603004)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296603004)
            
            static $h = 1635708;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$MCAB.LCIDAMS.SmartAttendantStatusModel, $.$MCAB.LCIDAM.SmartAttendantLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591570300),
    {
      "r": 39425425,
      "n": "Ack",
      "d": 1635708,
      "h": 8591570300,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591570300)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296603004),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1635708,
      "h": 4296603004,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296603004)
  ],
  "h": 1635708
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1635708)
        
        

        //--TRIMMABLE-BOUNDARY-START(1766780)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModelTypeDescriptor`, ($self) => class SmartAttendantDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296734076)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296734076);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, this, factory);
                    }, $JjsbUk ??= {"r":65537,"n":"","d":1766780,"h":0,"f":17825794}), 0, "SmartAttendantDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SmartAttendantDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296734076)
            
            //--TRIMMABLE-BOUNDARY-START(12886668668)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886668668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$MCAB.LCIDAMS.SmartAttendantStatusModel, $.$MCAB.LCIDAM.SmartAttendantLogModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886668668)
            
            //--TRIMMABLE-BOUNDARY-START(17181635964)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181635964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.Attendant.Models.Statuses.SmartAttendantStatusModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantLogModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$MCAB.LCIDAMS.SmartAttendantStatusModel, $.$MCAB.LCIDAM.SmartAttendantLogModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$MCAB.LCIDAMS.SmartAttendantStatusModel, $.$MCAB.LCIDAM.SmartAttendantLogModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181635964)
            
            //--TRIMMABLE-BOUNDARY-START(8591701372)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591701372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591701372)
            
            static $h = 1766780;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886668668),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1766780,
      "h": 12886668668,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886668668),
//--TRIMMABLE-BOUNDARY-START(17181635964),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1635708,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1766780,
      "h": 17181635964,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181635964),
//--TRIMMABLE-BOUNDARY-START(8591701372),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1635708,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1766780,
      "h": 8591701372,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591701372)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296734076),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1766780,
      "h": 4296734076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296734076)
  ],
  "h": 1766780
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1766780)
        
        

        //--TRIMMABLE-BOUNDARY-START(4322684)
        $asm.$cls(`$MCAB.LCIDA.SmartAttendantDataConverter`, ($self) => class SmartAttendantDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299289980)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299289980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299289980)
            
            //--TRIMMABLE-BOUNDARY-START(4299289980)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299289980)
            
            static $h = 4322684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299289980),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4322684,
      "h": 4299289980,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299289980)
  ],
  "h": 4322684
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.SmartAttendantDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}SmartAttendantDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4322684)
        
        

        $asm.$typeProxy("$MCAB.LCIDAM.SmartAttendantServiceModel", "$MCAB.LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModel");
        $asm.$typeProxy("$MCAB.LCIDAM.SmartAttendantDeviceModel", "$MCAB.LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModel");
        $asm.$typeProxy("$MCAB.LCIDAS$1.SmartAttendantDeviceSettings", "$MCAB.LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettings");
        $asm.$typeProxy("$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings", "$MCAB.LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings");
        $asm.$typeProxy("$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler", "$MCAB.LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceStatusHandler");
        $asm.$typeProxy("$MCAB.LCIDAS.ISmartAttendantDeviceHubClient", "$MCAB.LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceHubClient");
        $asm.$typeProxy("$MCAB.LCIDAS.ISmartAttendantRemoteService", "$MCAB.LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantRemoteService");
        //--TRIMMABLE-BOUNDARY-START(1897852)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceScopeModel`, ($self) => class SmartAttendantDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296865148)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296865148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296865148)
            
            //--TRIMMABLE-BOUNDARY-START(4296865148)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296865148)
            
            static $h = 1897852;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296865148),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1897852,
      "h": 4296865148,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296865148)
  ],
  "h": 1897852
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1897852)
        
        

        //--TRIMMABLE-BOUNDARY-START(2684284)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantServiceModel`, ($self) => class SmartAttendantServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297651580)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297651580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297651580)
            
            //--TRIMMABLE-BOUNDARY-START(4297651580)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297651580)
            
            static $h = 2684284;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297651580),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2684284,
      "h": 4297651580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297651580)
  ],
  "h": 2684284
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2684284)
        
        

        //--TRIMMABLE-BOUNDARY-START(1373564)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceModel`, ($self) => class SmartAttendantDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296340860)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296340860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296340860)
            
            //--TRIMMABLE-BOUNDARY-START(4296340860)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296340860)
            
            static $h = 1373564;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296340860),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1373564,
      "h": 4296340860,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296340860)
  ],
  "h": 1373564
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1373564)
        
        

        //--TRIMMABLE-BOUNDARY-START(3798396)
        $asm.$cls(`$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings`, ($self) => class SmartAttendantDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(55838373244)
            /*IOTDeviceInternalConfiguration<string>?*/ ScannerWebUrl = null;
            //--TRIMMABLE-BOUNDARY-END(55838373244)
            
            //--TRIMMABLE-BOUNDARY-START(47248438652)
            /*IOTDeviceInternalConfiguration<string>?*/ ScannerWebService = null;
            //--TRIMMABLE-BOUNDARY-END(47248438652)
            
            //--TRIMMABLE-BOUNDARY-START(51543405948)
            /*IOTDeviceInternalConfiguration<string>?*/ scannerWebServiceTarget = null;
            //--TRIMMABLE-BOUNDARY-END(51543405948)
            
            //--TRIMMABLE-BOUNDARY-START(17183667580)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183667580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183667580)
            
            //--TRIMMABLE-BOUNDARY-START(17183667580)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(17183667580)
            
            static $h = 3798396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55838373244),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953471356,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81608177020,
        "f": 83886081
      },
      "n": "ScannerWebUrl",
      "d": 3798396,
      "h": 55838373244,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "swu",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55838373244),
//--TRIMMABLE-BOUNDARY-START(47248438652),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773602172,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64428307836,
        "f": 83886081
      },
      "n": "ScannerWebService",
      "d": 3798396,
      "h": 47248438652,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "sws",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 21,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47248438652),
//--TRIMMABLE-BOUNDARY-START(51543405948),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363536764,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73018242428,
        "f": 83886081
      },
      "n": "scannerWebServiceTarget",
      "d": 3798396,
      "h": 51543405948,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "swt",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 22,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51543405948)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183667580),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3798396,
      "h": 17183667580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183667580)
  ],
  "h": 3798396
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Settings${separator}SmartAttendantDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3798396)
        
        

        //--TRIMMABLE-BOUNDARY-START(3732860)
        $asm.$cls(`$MCAB.LCIDAS.ISmartAttendantRemoteService`, ($self) => class ISmartAttendantRemoteService
        {
            static $h = 3732860;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3732860
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Services${separator}ISmartAttendantRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3732860)
        
        

        //--TRIMMABLE-BOUNDARY-START(4060540)
        $asm.$cls(`$MCAB.LCIDAS$1.SmartAttendantDeviceSettings`, ($self) => class SmartAttendantDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $self, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4299027836)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299027836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299027836)
            
            //--TRIMMABLE-BOUNDARY-START(4299027836)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4299027836)
            
            static $h = 4060540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299027836),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4060540,
      "h": 4299027836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299027836)
  ],
  "h": 4060540
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Settings${separator}SmartAttendantDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4060540)
        
        

        //--TRIMMABLE-BOUNDARY-START(3667324)
        $asm.$cls(`$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler`, ($self) => class ISmartAttendantDeviceStatusHandler
        {
            static $h = 3667324;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3667324
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Services${separator}ISmartAttendantDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3667324)
        
        

        //--TRIMMABLE-BOUNDARY-START(3601788)
        $asm.$cls(`$MCAB.LCIDAS.ISmartAttendantDeviceHubClient`, ($self) => class ISmartAttendantDeviceHubClient
        {
            static $h = 3601788;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3601788
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Services${separator}ISmartAttendantDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3601788)
        
        

        //--TRIMMABLE-BOUNDARY-START(4584828)
        $asm.$cls(`$MCAB.LCIDA.SmartAttendantDeviceModelDefinition`, ($self) => class SmartAttendantDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4299552124)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299552124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299552124)
            
            //--TRIMMABLE-BOUNDARY-START(4299552124)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299552124)
            
            static $h = 4584828;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299552124),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4584828,
      "h": 4299552124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299552124)
  ],
  "h": 4584828
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.SmartAttendantDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}SmartAttendantDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4584828)
        
        

        //--TRIMMABLE-BOUNDARY-START(2028924)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceScopeModelTypeDescriptor`, ($self) => class SmartAttendantDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296996220)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296996220);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, this, factory);
                    }, $fCQKsf ??= {"r":65537,"n":"","d":2028924,"h":0,"f":17825794}), 0, "SmartAttendantDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantDeviceScopeModel_LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModelTypeDescriptorBuilder.g.cs", "SmartAttendantDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296996220)
            
            //--TRIMMABLE-BOUNDARY-START(12886930812)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886930812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886930812)
            
            //--TRIMMABLE-BOUNDARY-START(17181898108)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181898108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModel, LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettings, LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModel, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceStatusHandler, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceHubClient, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181898108)
            
            //--TRIMMABLE-BOUNDARY-START(8591963516)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591963516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591963516)
            
            static $h = 2028924;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886930812),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2028924,
      "h": 12886930812,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886930812),
//--TRIMMABLE-BOUNDARY-START(17181898108),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1897852,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2028924,
      "h": 17181898108,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181898108),
//--TRIMMABLE-BOUNDARY-START(8591963516),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1897852,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2028924,
      "h": 8591963516,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591963516)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296996220),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2028924,
      "h": 4296996220,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296996220)
  ],
  "h": 2028924
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2028924)
        
        

        //--TRIMMABLE-BOUNDARY-START(1504636)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantDeviceModelTypeDescriptor`, ($self) => class SmartAttendantDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296471932)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296471932);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAM.SmartAttendantDeviceModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAM.SmartAttendantDeviceModel, this, factory);
                    }, $uCAqdl ??= {"r":65537,"n":"","d":1504636,"h":0,"f":17825794}), 0, "SmartAttendantDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantDeviceModel_LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModelTypeDescriptorBuilder.g.cs", "SmartAttendantDeviceModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296471932)
            
            //--TRIMMABLE-BOUNDARY-START(12886406524)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886406524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886406524)
            
            //--TRIMMABLE-BOUNDARY-START(17181373820)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181373820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModel, LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettings, LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModel, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceStatusHandler, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceHubClient, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181373820)
            
            //--TRIMMABLE-BOUNDARY-START(8591439228)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591439228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAM.SmartAttendantDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAM.SmartAttendantDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591439228)
            
            static $h = 1504636;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886406524),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1504636,
      "h": 12886406524,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886406524),
//--TRIMMABLE-BOUNDARY-START(17181373820),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1373564,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1504636,
      "h": 17181373820,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181373820),
//--TRIMMABLE-BOUNDARY-START(8591439228),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1373564,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1504636,
      "h": 8591439228,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591439228)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296471932),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1504636,
      "h": 4296471932,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296471932)
  ],
  "h": 1504636
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1504636)
        
        

        //--TRIMMABLE-BOUNDARY-START(2815356)
        $asm.$cls(`$MCAB.LCIDAM.SmartAttendantServiceModelTypeDescriptor`, ($self) => class SmartAttendantServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297782652)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297782652);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAM.SmartAttendantServiceModelTypeDescriptor.GenerateProperties($.$MCAB.LCIDAM.SmartAttendantServiceModel, this, factory);
                    }, $RhThVj ??= {"r":65537,"n":"","d":2815356,"h":0,"f":17825794}), 0, "SmartAttendantServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Models_SmartAttendantServiceModel_LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModelTypeDescriptorBuilder.g.cs", "SmartAttendantServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297782652)
            
            //--TRIMMABLE-BOUNDARY-START(12887717244)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887717244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887717244)
            
            //--TRIMMABLE-BOUNDARY-START(17182684540)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182684540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModel, LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettings, LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModel, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceStatusHandler, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceHubClient, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182684540)
            
            //--TRIMMABLE-BOUNDARY-START(8592749948)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592749948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAM.SmartAttendantServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAM.SmartAttendantServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantServiceModel)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAM.SmartAttendantServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAM.SmartAttendantServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAM.SmartAttendantServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592749948)
            
            static $h = 2815356;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887717244),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2815356,
      "h": 12887717244,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887717244),
//--TRIMMABLE-BOUNDARY-START(17182684540),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2684284,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2815356,
      "h": 17182684540,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182684540),
//--TRIMMABLE-BOUNDARY-START(8592749948),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2684284,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2815356,
      "h": 8592749948,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592749948)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297782652),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2815356,
      "h": 4297782652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297782652)
  ],
  "h": 2815356
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Models${separator}SmartAttendantServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2815356)
        
        

        //--TRIMMABLE-BOUNDARY-START(4191612)
        $asm.$cls(`$MCAB.LCIDAS$1.SmartAttendantDeviceSettingsTypeDescriptor`, ($self) => class SmartAttendantDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299158908)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299158908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettingsTypeDescriptor.GenerateProperties($.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, this, factory);
                    }, $ptWYze ??= {"r":65537,"n":"","d":4191612,"h":0,"f":17825794}), 0, "SmartAttendantDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Settings_SmartAttendantDeviceSettings_LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettingsTypeDescriptorBuilder.g.cs", "SmartAttendantDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299158908)
            
            //--TRIMMABLE-BOUNDARY-START(12889093500)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889093500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889093500)
            
            //--TRIMMABLE-BOUNDARY-START(17184060796)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184060796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModel, LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettings, LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModel, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceStatusHandler, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceHubClient, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184060796)
            
            //--TRIMMABLE-BOUNDARY-START(8594126204)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594126204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594126204)
            
            static $h = 4191612;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889093500),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4191612,
      "h": 12889093500,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889093500),
//--TRIMMABLE-BOUNDARY-START(17184060796),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4060540,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4191612,
      "h": 17184060796,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184060796),
//--TRIMMABLE-BOUNDARY-START(8594126204),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4060540,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4191612,
      "h": 8594126204,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594126204)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299158908),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4191612,
      "h": 4299158908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299158908)
  ],
  "h": 4191612
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Settings${separator}SmartAttendantDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4191612)
        
        

        //--TRIMMABLE-BOUNDARY-START(3929468)
        $asm.$cls(`$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor`, ($self) => class SmartAttendantDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298896764)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298896764);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, this, factory);
                    }, $NamMrg ??= {"r":65537,"n":"","d":3929468,"h":0,"f":17825794}), 0, "SmartAttendantDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Attendant\\Settings_SmartAttendantDeviceHardwareSettings_LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SmartAttendantDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298896764)
            
            //--TRIMMABLE-BOUNDARY-START(12888831356)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888831356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ScannerWebUrl"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings.$type, $.$discardRef(), "ScannerWebUrl", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ScannerWebUrl")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "ScannerWebUrl";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), ($.$cast(target, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings)).ScannerWebUrl);
                        }, $FMrHIe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3929468,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ScannerWebUrl = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String));
                        }, $dAoIve ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3929468,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("ScannerWebService"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings.$type, $.$discardRef(), "ScannerWebService", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("ScannerWebService")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "ScannerWebService";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), ($.$cast(target, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings)).ScannerWebService);
                        }, $lIZMdf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3929468,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.ScannerWebService = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String));
                        }, $uZZbmg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3929468,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("scannerWebServiceTarget"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings.$type, $.$discardRef(), "scannerWebServiceTarget", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("scannerWebServiceTarget")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "scannerWebServiceTarget";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), ($.$cast(target, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings)).scannerWebServiceTarget);
                        }, $mtPbWg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3929468,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.scannerWebServiceTarget = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String));
                        }, $JDPFHg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3929468,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888831356)
            
            //--TRIMMABLE-BOUNDARY-START(17183798652)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183798652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceModel, LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceSettings, LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Attendant.Models.SmartAttendantDeviceSendDataModel, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceStatusHandler, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantDeviceHubClient, LivingThing.Core.IOT.Devices.Attendant.Services.ISmartAttendantRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _ScannerWebUrl = _target.ScannerWebUrl;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ScannerWebUrl"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ScannerWebUrl, ($v) => _ScannerWebUrl = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String))))
                    {
                        _target.ScannerWebUrl = _ScannerWebUrl;
                    }
                }
                {
                    /*var*/ let _ScannerWebService = _target.ScannerWebService;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("ScannerWebService"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _ScannerWebService, ($v) => _ScannerWebService = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String))))
                    {
                        _target.ScannerWebService = _ScannerWebService;
                    }
                }
                {
                    /*var*/ let _scannerWebServiceTarget = _target.scannerWebServiceTarget;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("scannerWebServiceTarget"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _scannerWebServiceTarget, ($v) => _scannerWebServiceTarget = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String))))
                    {
                        _target.scannerWebServiceTarget = _scannerWebServiceTarget;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183798652)
            
            //--TRIMMABLE-BOUNDARY-START(8593864060)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593864060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593864060)
            
            static $h = 3929468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888831356),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3929468,
      "h": 12888831356,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888831356),
//--TRIMMABLE-BOUNDARY-START(17183798652),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3798396,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3929468,
      "h": 17183798652,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183798652),
//--TRIMMABLE-BOUNDARY-START(8593864060),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3798396,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3929468,
      "h": 8593864060,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593864060)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298896764),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3929468,
      "h": 4298896764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298896764)
  ],
  "h": 3929468
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Settings.SmartAttendantDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Settings${separator}SmartAttendantDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3929468)
        
        

        //--TRIMMABLE-BOUNDARY-START(4388220)
        $asm.$cls(`$MCAB.LCIDA.SmartAttendantDevice`, ($self) => class SmartAttendantDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$MCAB.LCIDAMS.SmartAttendantStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4299355516)
            $ctor$2(/*IIOTDeviceFamily<SmartAttendantDevice>*/ family, /*IIOTDeviceScope*/ scope, /*SmartAttendantDeviceModel*/ model)
            {
                super.$ctor$3(family, scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299355516);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299355516)
            
            //--TRIMMABLE-BOUNDARY-START(8594322812)
            /*Task */ AddFinger(/*int*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594322812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$MCAB.LCIDAP.SmartAttendantAddFingerPrintCommand, $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel, this, new $.$MCAB.LCIDAP.SmartAttendantAddFingerPrintCommand().$ctor$6(), new $.$MCAB.LCIDAMC.SmartAttendantAddFingerPrintTemplateControlModel().$ctor$3(id));
            }
            //--TRIMMABLE-BOUNDARY-END(8594322812)
            
            //--TRIMMABLE-BOUNDARY-START(12889290108)
            /*Task */ DeleteFinger(/*int*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889290108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$MCAB.LCIDAP.SmartAttendantDeleteFingerPrintCommand, $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel, this, new $.$MCAB.LCIDAP.SmartAttendantDeleteFingerPrintCommand().$ctor$6(), new $.$MCAB.LCIDAMC.SmartAttendantDeleteFingerPrintTemplateControlModel().$ctor$3(id));
            }
            //--TRIMMABLE-BOUNDARY-END(12889290108)
            
            //--TRIMMABLE-BOUNDARY-START(17184257404)
            /*Task */ EmptyDatabase()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184257404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$MCAB.LCIDAP.SmartAttendantEmptyFingerPrintCommand, $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel, this, new $.$MCAB.LCIDAP.SmartAttendantEmptyFingerPrintCommand().$ctor$6(), new $.$MCAB.LCIDAMC.SmartAttendantEmptyFingerPrintTemplateControlModel().$ctor$2());
            }
            //--TRIMMABLE-BOUNDARY-END(17184257404)
            
            static $h = 4388220;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$MCAB.LCIDAMS.SmartAttendantStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594322812),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "AddFinger",
      "d": 4388220,
      "h": 8594322812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594322812),
//--TRIMMABLE-BOUNDARY-START(12889290108),
    {
      "r": 178454529,
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "DeleteFinger",
      "d": 4388220,
      "h": 12889290108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889290108),
//--TRIMMABLE-BOUNDARY-START(17184257404),
    {
      "r": 178454529,
      "n": "EmptyDatabase",
      "d": 4388220,
      "h": 17184257404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17184257404)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299355516),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$MCAB.LCIDA.SmartAttendantDevice).$h
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 1373564
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4388220,
      "h": 4299355516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299355516)
  ],
  "h": 4388220
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.SmartAttendantDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}SmartAttendantDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4388220)
        
        

        //--TRIMMABLE-BOUNDARY-START(4453756)
        $asm.$cls(`$MCAB.LCIDA.SmartAttendantDeviceDefinition`, ($self) => class SmartAttendantDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$MCAB.LCIDAMS.SmartAttendantStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299421052)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299421052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299421052)
            
            //--TRIMMABLE-BOUNDARY-START(4299421052)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299421052)
            
            static $h = 4453756;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$MCAB.LCIDAMS.SmartAttendantStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299421052),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4453756,
      "h": 4299421052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299421052)
  ],
  "h": 4453756
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.SmartAttendantDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}SmartAttendantDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4453756)
        
        

        //--TRIMMABLE-BOUNDARY-START(4519292)
        $asm.$cls(`$MCAB.LCIDA.SmartAttendantDeviceFamily`, ($self) => class SmartAttendantDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4299486588)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SmartAttendantDeviceReceivedDataModel, SmartAttendantDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SmartAttendantDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299486588);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299486588)
            
            //--TRIMMABLE-BOUNDARY-START(8594453884)
            /*Type */ get DeviceLogType()
            {
                return $.$MCAB.LCIDAM.SmartAttendantLogModel.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8594453884)
            
            //--TRIMMABLE-BOUNDARY-START(12889421180)
            /*IIOTDeviceFamilyFeatures */ get Features()
            {
                return super.Features | 1/*IIOTDeviceFamilyFeatures.NoDatabase*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12889421180)
            
            static $h = 4519292;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8594453884),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479355772,
        "f": 50364417
      },
      "n": "DeviceLogType",
      "d": 4519292,
      "h": 8594453884,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8594453884),
//--TRIMMABLE-BOUNDARY-START(12889421180),
    {
      "p": 26842513,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069290364,
        "f": 50364417
      },
      "n": "Features",
      "d": 4519292,
      "h": 12889421180,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12889421180)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299486588),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4519292,
      "h": 4299486588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299486588)
  ],
  "h": 4519292
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$MCAB.LCIDA.SmartAttendantDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.SmartAttendantDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}SmartAttendantDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4519292)
        
        

        //--TRIMMABLE-BOUNDARY-START(5174652)
        $asm.$cls(`$MCAB.LCIDAV$1.SmartAttendantViewRenderer`, ($self) => class SmartAttendantViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$$$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel))
        {
            //--TRIMMABLE-BOUNDARY-START(4300141948)
            $ctor$2(/*IOTRootViewModel*/ root)
            {
                super.$ctor$1(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300141948);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300141948)
            
            //--TRIMMABLE-BOUNDARY-START(8595109244)
            /*RenderFragment? */ GetView(/*IClientUnitOfWork*/ ui, /*SmartAttendantDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>?*/ clicked, /*Func<Task>?*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595109244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$MCAB.LCIDAV$1.SmartAttendantDeviceDetails, $.$MCAB.LCIDAV$1.SmartAttendantDetailsViewModel, new $.$MCAB.LCIDAV$1.SmartAttendantDetailsViewModel().$ctor$8(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8595109244)
            
            static $h = 5174652;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$$$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595109244),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 4388220
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 5174652,
      "h": 8595109244,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8595109244)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300141948),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5174652,
      "h": 4300141948,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300141948)
  ],
  "h": 5174652
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$MCAB.LCIDA.SmartAttendantDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Views.SmartAttendantViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Views${separator}SmartAttendantViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5174652)
        
        

        //--TRIMMABLE-BOUNDARY-START(5043580)
        $asm.$cls(`$MCAB.LCIDAV$1.SmartAttendantDetailsViewModel`, ($self) => class SmartAttendantDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$$$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel))
        {
            //--TRIMMABLE-BOUNDARY-START(4300010876)
            $ctor$8(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*SmartAttendantDevice*/ device)
            {
                super.$ctor$7(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300010876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300010876)
            
            static $h = 5043580;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$$$$$$($.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300010876),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 4388220
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 5043580,
      "h": 4300010876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300010876)
  ],
  "h": 5043580
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Views.SmartAttendantDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Views${separator}SmartAttendantDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5043580)
        
        

        //--TRIMMABLE-BOUNDARY-START(5109116)
        $asm.$cls(`$MCAB.LCIDAV$1.SmartAttendantDeviceDetails`, ($self) => class SmartAttendantDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$MCAB.LCIDAV$1.SmartAttendantDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51544716668)
            /*SmartAttendantDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51544716668)
            
            //--TRIMMABLE-BOUNDARY-START(34364847484)
            /*string */ get OptimizedComponentName()
            {
                return "smartattendantdevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(34364847484)
            
            //--TRIMMABLE-BOUNDARY-START(47249749372)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47249749372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$MCAB.LCIDAV$1.SmartAttendantDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47249749372)
            
            //--TRIMMABLE-BOUNDARY-START(12890011004)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890011004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$MCAB.LCIDA.SmartAttendantDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$MCAB.LCIDA.SmartAttendantDevice), this.ViewModel));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICD$1.DeviceDetailsFeatures, 479/*DeviceDetailsFeatures.Default*/ & ~256/*DeviceDetailsFeatures.IO*/), $.$ntej.LCICD$1.DeviceDetailsFeatures));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12890011004)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8595043708)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595043708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8595043708)
            
            //--TRIMMABLE-BOUNDARY-START(8595043708)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8595043708)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51544716668)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(51544716668)
                
            }
            static $h = 5109116;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$MCAB.LCIDAV$1.SmartAttendantDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51544716668),
    {
      "p": 5043580,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069880188,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42954782076,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 5109116,
      "h": 51544716668,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51544716668),
//--TRIMMABLE-BOUNDARY-START(34364847484),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479945596,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 5109116,
      "h": 34364847484,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34364847484)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47249749372),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 5109116,
      "h": 47249749372,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47249749372),
//--TRIMMABLE-BOUNDARY-START(12890011004),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 5109116,
      "h": 12890011004,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12890011004)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595043708),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 5109116,
      "h": 8595043708,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595043708)
  ],
  "h": 5109116
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.Views.SmartAttendantDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}Views${separator}SmartAttendantDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5109116)
        
        

        $asm.$typeProxy("$MCAB.LCIDAV.SmartAttendantClientAppViewModel", "$MCAB.LivingThing.Core.IOT.Devices.Attendant.ViewModels.SmartAttendantClientAppViewModel");
        $asm.$typeProxy("$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel", "$MCAB.LivingThing.Core.IOT.Devices.Attendant.ViewModels.SmartAttendantClientAppServiceViewModel");
        $asm.$typeProxy("$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel", "$MCAB.LivingThing.Core.IOT.Devices.Attendant.ViewModels.SmartAttendantClientAppDeviceViewModel");
        //--TRIMMABLE-BOUNDARY-START(4781436)
        $asm.$cls(`$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel`, ($self) => class SmartAttendantClientAppDeviceScopeViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAV.SmartAttendantClientAppViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel, $self, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel, $.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299748732)
            $ctor$3(/*SmartAttendantClientAppServiceViewModel*/ service, /*SmartAttendantDeviceScopeModel*/ model, /*IEnumerable<SmartAttendantClientAppDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299748732);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299748732)
            
            static $h = 4781436;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAV.SmartAttendantClientAppViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel, $.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299748732),
    {
      "p": [
        {
          "n": "service",
          "p": 4912508
        },
        {
          "n": "model",
          "p": 1897852
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4781436,
      "h": 4299748732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299748732)
  ],
  "h": 4781436
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.ViewModels.SmartAttendantClientAppDeviceScopeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}ViewModels${separator}SmartAttendantClientAppDeviceScopeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4781436)
        
        

        //--TRIMMABLE-BOUNDARY-START(4912508)
        $asm.$cls(`$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel`, ($self) => class SmartAttendantClientAppServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAV.SmartAttendantClientAppViewModel, $self, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel, $.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299879804)
            $ctor$3(/*SmartAttendantClientAppViewModel*/ app, /*SmartAttendantServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299879804);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299879804)
            
            //--TRIMMABLE-BOUNDARY-START(12889814396)
            /*SmartAttendantClientAppDeviceViewModel */ GetDeviceViewModel(/*SmartAttendantDeviceModel*/ model, /*IEnumerable<SmartAttendantClientAppDeviceScopeViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889814396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12889814396)
            
            //--TRIMMABLE-BOUNDARY-START(8594847100)
            /*SmartAttendantClientAppDeviceScopeViewModel */ GetDeviceScopeViewModel(/*SmartAttendantDeviceScopeModel*/ model, /*IEnumerable<SmartAttendantClientAppDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594847100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8594847100)
            
            static $h = 4912508;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAV.SmartAttendantClientAppViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel, $.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889814396),
    {
      "r": 4846972,
      "p": [
        {
          "n": "model",
          "p": 1373564
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 4912508,
      "h": 12889814396,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12889814396),
//--TRIMMABLE-BOUNDARY-START(8594847100),
    {
      "r": 4781436,
      "p": [
        {
          "n": "model",
          "p": 1897852
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 4912508,
      "h": 8594847100,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8594847100)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299879804),
    {
      "p": [
        {
          "n": "app",
          "p": 4978044
        },
        {
          "n": "model",
          "p": 2684284
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4912508,
      "h": 4299879804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299879804)
  ],
  "h": 4912508
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.ViewModels.SmartAttendantClientAppServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}ViewModels${separator}SmartAttendantClientAppServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4912508)
        
        

        //--TRIMMABLE-BOUNDARY-START(4846972)
        $asm.$cls(`$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel`, ($self) => class SmartAttendantClientAppDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAV.SmartAttendantClientAppViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel, $self, $.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299814268)
            $ctor$7(/*SmartAttendantClientAppServiceViewModel*/ service, /*SmartAttendantDeviceModel*/ model, /*IEnumerable<SmartAttendantClientAppDeviceScopeViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299814268);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299814268)
            
            static $h = 4846972;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAV.SmartAttendantClientAppViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel, $.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299814268),
    {
      "p": [
        {
          "n": "service",
          "p": 4912508
        },
        {
          "n": "model",
          "p": 1373564
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 4846972,
      "h": 4299814268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299814268)
  ],
  "h": 4846972
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.ViewModels.SmartAttendantClientAppDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}ViewModels${separator}SmartAttendantClientAppDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4846972)
        
        

        //--TRIMMABLE-BOUNDARY-START(4978044)
        $asm.$cls(`$MCAB.LCIDAV.SmartAttendantClientAppViewModel`, ($self) => class SmartAttendantClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel, $.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299945340)
            $ctor$5(/*IOTRootViewModel*/ root, /*SmartAttendantDeviceFamily*/ family, /*IHubConnector<IIOTDeviceHubClientBase<SmartAttendantDeviceReceivedDataModel, IOTDeviceStatusModel>>*/ hubConnector)
            {
                super.$ctor$5(root, family, $.$$.N.InterfaceVarianceStubHandler.Create(hubConnector, $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)), $.$kVHt.LCFCH.IHubConnector$$($.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299945340);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299945340)
            
            //--TRIMMABLE-BOUNDARY-START(8594912636)
            /*bool */ get Authorize()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594912636)
            
            //--TRIMMABLE-BOUNDARY-START(21479814524)
            /*SmartAttendantClientAppServiceViewModel */ GetServiceViewModel(/*SmartAttendantServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479814524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(21479814524)
            
            static $h = 4978044;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAV.SmartAttendantClientAppViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel, $.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8594912636),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17184847228,
        "f": 50364417
      },
      "n": "Authorize",
      "d": 4978044,
      "h": 8594912636,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8594912636)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21479814524),
    {
      "r": 4912508,
      "p": [
        {
          "n": "model",
          "p": 2684284
        }
      ],
      "n": "GetServiceViewModel",
      "d": 4978044,
      "h": 21479814524,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21479814524)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299945340),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 4519292
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4978044,
      "h": 4299945340,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299945340)
  ],
  "h": 4978044
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$MCAB.LCIDAM.SmartAttendantServiceModel), $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.ViewModels.SmartAttendantClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}ViewModels${separator}SmartAttendantClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4978044)
        
        

        //--TRIMMABLE-BOUNDARY-START(4715900)
        $asm.$cls(`$MCAB.LCIDAV.SmartAttendantClientAppDefinition`, ($self) => class SmartAttendantClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAV.SmartAttendantClientAppViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel, $.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4299683196)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299683196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299683196)
            
            //--TRIMMABLE-BOUNDARY-START(4299683196)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299683196)
            
            static $h = 4715900;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MCAB.LCIDAV.SmartAttendantClientAppViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppServiceViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceScopeViewModel, $.$MCAB.LCIDAV.SmartAttendantClientAppDeviceViewModel, $.$MCAB.LCIDA.SmartAttendantDevice, $.$MCAB.LCIDAM.SmartAttendantServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MCAB.LCIDAM.SmartAttendantDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MCAB.LCIDAM.SmartAttendantDeviceModel, $.$MCAB.LCIDAS$1.SmartAttendantDeviceSettings, $.$MCAB.LCIDAS$1.SmartAttendantDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MCAB.LCIDAM.SmartAttendantDeviceReceivedDataModel, $.$MCAB.LCIDAM.SmartAttendantDeviceSendDataModel, $.$MCAB.LCIDAS.ISmartAttendantDeviceStatusHandler, $.$MCAB.LCIDAS.ISmartAttendantDeviceHubClient, $.$MCAB.LCIDAS.ISmartAttendantRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299683196),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4715900,
      "h": 4299683196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299683196)
  ],
  "h": 4715900
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Attendant.ViewModels.SmartAttendantClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Attendant${separator}ViewModels${separator}SmartAttendantClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4715900)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(62844)
