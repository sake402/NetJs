
//--TRIMMABLE-BOUNDARY-START(59658)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej, $NzWm, $cCKL, $HTiB) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.AutoTracks", 
    {
  "h": 59658,
  "f": "LivingThing.Core.IOT.Devices.AutoTracks",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.AutoTracks",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.AutoTracks",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5BdXRvVHJhY2tzLkF1dG9UcmFja3NTbWFydERldmljZSI6IHsNCiAgICAgICJOYW1lIjogIkF1dG9UcmFja3MiLA0KICAgICAgIlNlcnZpY2VMaW5rIjogIkF1dG9UcmFja3MvQXBwIiwNCiAgICAgICJTaG9ydERlc2NyaXB0aW9uIjogIlRyYWNrIGFuZCBmbGVldCBtYW5hZ2UgeW91ciBhc3NldHMgKHBldHMsIGNhcnMsIGJ1c2VzLCB0cnVja3MpIHJlYWx0aW1lLiIsDQogICAgICAiRGVzY3JpcHRpb24iOiAiQSB0cmFja2luZyBhbmQgZmxlZXQgbWFuYWdlbWVudCBzb2x1dGlvbi5cclxuPGVtPkFjY291bnRhYmlsaXR5IGFuZCBQZWFjZTwvZW0\u002BIG9mIG1pbmQgb3ZlciB5b3VyIGFzc2V0cy4iLA0KICAgICAgIlNlY3VyaXRpZXMiOiAiQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyIsDQogICAgICAiRmxhZ3MiOiAiRmVhdHVyZWQsUHVibGlzaGVkIiwNCiAgICAgICJJY29uIjogeyAiTmFtZSI6ICJtZGkgbWRpLW1hcC1tYXJrZXIiIH0sDQogICAgICAiVGhlbWVDb2xvciI6ICIjNjM5YmZmIiwNCiAgICAgICJCYW5uZXJJbWFnZSI6ICJ\u002BL2ltZy9iYW5uZXIuanBnIiwNCiAgICAgICJTdGF0dXNlcyI6IFtdLA0KICAgICAgIkNsaWNrQ29tbWFuZCI6IHsgIk5hbWUiOiAiT24vT2ZmIiB9LA0KICAgICAgIlN0YXR1c05hbWVzIjogIlN0YXR1cy5Mb2NhdGlvbixEZXZpY2UuTW9kZWwuU3RhdHVzLkxvY2F0aW9uLERldmljZS5Nb2RlbC5TdGF0dXMuU3BlZWQiLA0KICAgICAgIkFjY2Vzc29yaWVzIjogWw0KICAgICAgICB7DQogICAgICAgICAgIkNhdGVnb3JpZXMiOiBbICJBdXRvVHJhY2tzIiwgIlRyYWNrZXJzIiBdLA0KICAgICAgICAgICJOYW1lIjogIlNtYXJ0IFRyYWNrZXIiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJHU00vR1BTL0dQUlMgYXNzZXQgdHJhY2tlciIsDQogICAgICAgICAgIkNvc3QiOiB7DQogICAgICAgICAgICAiVmFsdWUiOiA1MDAwMCwNCiAgICAgICAgICAgICJVbml0IjogIk5haXJhIg0KICAgICAgICAgIH0sDQogICAgICAgICAgIkltYWdlcyI6IFsgIn4vaW1nL2RldmljZS5qcGciIF0sDQogICAgICAgICAgIkZsYWdzIjogIkZlYXR1cmVkLFB1Ymxpc2hlZCIsDQogICAgICAgICAgIkZlYXR1cmVzIjogWw0KICAgICAgICAgICAgew0KICAgICAgICAgICAgICAiVGl0bGUiOiAiU3BlZWQgTGltaXRpbmciLA0KICAgICAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiTGltaXQgaG93IGZhc3QgeW91ciB2ZWhpY2xlIGNhbiBiZSBkcml2ZW4iLA0KICAgICAgICAgICAgICAiSWNvbiI6IHsgIkljb24iOiAiU3BlZWRvbWV0ZXIiIH0NCiAgICAgICAgICAgIH0sDQogICAgICAgICAgICB7DQogICAgICAgICAgICAgICJUaXRsZSI6ICJTTVMgVHJhY2tpbmciLA0KICAgICAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiR2V0IHlvdXIgYXNzZXQgbG9jYXRpb24gYnkgc2ltcGx5IHNlbmRpbmcgU01TICh3aGVyZSkgdG8gaXQiLA0KICAgICAgICAgICAgICAiSWNvbiI6IHsgIkljb24iOiAiTWVzc2FnZSIgfQ0KICAgICAgICAgICAgfSwNCiAgICAgICAgICAgIHsNCiAgICAgICAgICAgICAgIlRpdGxlIjogIldlYiBUcmFja2luZyIsDQogICAgICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJUcmFjayBhc3NldCByZWFsLXRpbWUgZnJvbSBpbnNpZGUgbW9iaWxlIGFwcGxpY2F0aW9uLiIsDQogICAgICAgICAgICAgICJJY29uIjogeyAiSWNvbiI6ICJQaG9uZSIgfQ0KICAgICAgICAgICAgfSwNCiAgICAgICAgICAgIHsNCiAgICAgICAgICAgICAgIlRpdGxlIjogIldoYXRzYXBwL1RlbGVncmFtIFRyYWNraW5nIiwNCiAgICAgICAgICAgICAgIkRlc2NyaXB0aW9uIjogIlRyYWNrIGFzc2V0IHJlYWwtdGltZSBmcm9tIGluc2lkZSB5b3VyIGNoYXR0aW5nIGFwcGxpY2F0aW9uLiIsDQogICAgICAgICAgICAgICJJY29uIjogeyAiSWNvbiI6ICJQaG9uZSIgfQ0KICAgICAgICAgICAgfQ0KICAgICAgICAgIF0sDQogICAgICAgICAgIlNwZWNpZmljYXRpb25zIjogWw0KICAgICAgICAgICAgew0KICAgICAgICAgICAgICAiVGl0bGUiOiAiU3VwcGx5IFZvbHRhZ2UiLA0KICAgICAgICAgICAgICAiVmFsdWUiOiAiMTJWLTM2ViBEQyINCiAgICAgICAgICAgIH0sDQogICAgICAgICAgICB7DQogICAgICAgICAgICAgICJUaXRsZSI6ICJDb25uZWN0aXZpdHkiLA0KICAgICAgICAgICAgICAiVmFsdWUiOiAiMkcvM0ciDQogICAgICAgICAgICB9DQogICAgICAgICAgXQ0KICAgICAgICB9DQogICAgICBdLA0KICAgICAgIlNlcnZpY2VUaWVycyI6IFsNCiAgICAgICAgew0KICAgICAgICAgICJOYW1lIjogIk1vYmlsZUxpdGUiLA0KICAgICAgICAgICJTZXJ2aWNlVHlwZSI6ICJNb2JpbGVMaXRlIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiV2l0aCBObyBUcmFja2luZyBIaXN0b3J5IiwNCiAgICAgICAgICAiQW1vdW50IjogeyAiVmFsdWUiOiAzMDAgfSwNCiAgICAgICAgICAiQW1vdW50UXVhbGlmaWNhdGlvbiI6ICIvbW8iLA0KICAgICAgICAgICJTZXJ2aWNlRmVhdHVyZXMiOiAiUmVhbFRpbWVUcmFja2luZyxNb2JpbGVBcHAsR2VvRmVuY2luZyINCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJOYW1lIjogIk1vYmlsZUV4dHJhIiwNCiAgICAgICAgICAiU2VydmljZVR5cGUiOiAiTW9iaWxlRXh0cmEiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICIzIGRheXMgb2YgVHJhY2tpbmcgSGlzdG9yeSIsDQogICAgICAgICAgIkFtb3VudCI6IHsgIlZhbHVlIjogNDAwIH0sDQogICAgICAgICAgIkFtb3VudFF1YWxpZmljYXRpb24iOiAiL21vIiwNCiAgICAgICAgICAiU2VydmljZUZlYXR1cmVzIjogIlJlYWxUaW1lVHJhY2tpbmcsTW9iaWxlQXBwLEdlb0ZlbmNpbmcsU3BlZWRMaW1pdGluZyxIaXN0b3J5LFJlcG9ydGluZyINCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJOYW1lIjogIk1vYmlsZVBsdXMiLA0KICAgICAgICAgICJTZXJ2aWNlVHlwZSI6ICJNb2JpbGVQbHVzIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiMSBtb250aCBvZiBUcmFja2luZyBIaXN0b3J5IiwNCiAgICAgICAgICAiQW1vdW50IjogeyAiVmFsdWUiOiA2MDAgfSwNCiAgICAgICAgICAiQW1vdW50UXVhbGlmaWNhdGlvbiI6ICIvbW8iLA0KICAgICAgICAgICJTZXJ2aWNlRmVhdHVyZXMiOiAiQWxsIg0KICAgICAgICB9DQogICAgICAgIC8vew0KICAgICAgICAvLyAgIlR5cGUiOiAiQXNzZXRMaXRlIiwNCiAgICAgICAgLy8gICJEZXNjcmlwdGlvbiI6ICJUcmFja2luZyBieSBhIGhhcmR3YXJlIHRyYWNrZXIiLA0KICAgICAgICAvLyAgIkFtb3VudCI6IDEwMDAsDQogICAgICAgIC8vICAiQW1vdW50UXVhbGlmaWNhdGlvbiI6ICIvbW8iLA0KICAgICAgICAvLyAgIk1heERldmljZSI6IDEsDQogICAgICAgIC8vICAiU2VydmljZUZlYXR1cmVzIjogIlJlYWxUaW1lVHJhY2tpbmcsSGlzdG9yeSINCiAgICAgICAgLy99LA0KICAgICAgICAvL3sNCiAgICAgICAgLy8gICJUeXBlIjogIkFzc2V0RXh0cmEiLA0KICAgICAgICAvLyAgIkRlc2NyaXB0aW9uIjogIlRyYWNraW5nIGJ5IGEgaGFyZHdhcmUgdHJhY2tlciIsDQogICAgICAgIC8vICAiQW1vdW50IjogMzUwMCwNCiAgICAgICAgLy8gICJBbW91bnRRdWFsaWZpY2F0aW9uIjogIi9tbyIsDQogICAgICAgIC8vICAiTWF4RGV2aWNlIjogNSwNCiAgICAgICAgLy8gICJTZXJ2aWNlRmVhdHVyZXMiOiAiUmVhbFRpbWVUcmFja2luZyxIaXN0b3J5Ig0KICAgICAgICAvL30sDQogICAgICAgIC8vew0KICAgICAgICAvLyAgIk5hbWUiOiAiQXNzZXRQbHVzIiwNCiAgICAgICAgLy8gICJTZXJ2aWNlVHlwZSI6ICJNb2JpbGVMaXRlIiwNCiAgICAgICAgLy8gICJEZXNjcmlwdGlvbiI6ICIxIG1vbnRoIG9mIHRyYWNraW5nIGhpc3RvcnkiLA0KICAgICAgICAvLyAgIkFtb3VudCI6IDQ1MCwNCiAgICAgICAgLy8gICJBbW91bnRRdWFsaWZpY2F0aW9uIjogIi9tby9hc3NldCIsDQogICAgICAgIC8vICAiTWF4RGV2aWNlIjogMCwNCiAgICAgICAgLy8gICJTZXJ2aWNlRmVhdHVyZXMiOiAiQWxsIg0KICAgICAgICAvL30NCiAgICAgIF0sDQogICAgICAiQWN0aW9ucyI6IFsNCiAgICAgICAgew0KICAgICAgICAgICJUZXh0IjogIlNJR04gVVAiLA0KICAgICAgICAgICJJY29uIjogIkFjY291bnQiLA0KICAgICAgICAgICJMaW5rIjogIi9BdXRvVHJhY2tzL1N0YXJ0Ig0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRleHQiOiAiVklTSVQgUE9SVEFMIiwNCiAgICAgICAgICAiSWNvbiI6ICJNYXBNYXJrZXIiLA0KICAgICAgICAgICJMaW5rIjogIi9BdXRvVHJhY2tzL0FwcCINCiAgICAgICAgfQ0KICAgICAgXQ0KICAgIH0NCiAgfQ0KfQ=="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(125194)
        $asm.$cls(`$Gtji.LCIDA.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590059786)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590059786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590059786)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$Gtji.LCIDA.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295092490)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295092490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295092490)
            
            //--TRIMMABLE-BOUNDARY-START(4295092490)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295092490)
            
            static $h = 125194;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590059786),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 125194,
      "h": 8590059786,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590059786)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295092490),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 125194,
      "h": 4295092490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295092490)
  ],
  "h": 125194
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.AutoTracks.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}AutoTracks${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(125194)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor", "NetJs.LivingThing.Core.IOT.Devices.Gateway", "NetJs.LivingThing.Core.IOT.TankTalks.Common", "NetJs.LivingThing.Core.IOT.AutoTracks.Common"));
})();
//--TRIMMABLE-BOUNDARY-END(59658)
