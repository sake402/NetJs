
//--TRIMMABLE-BOUNDARY-START(39253)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $SRpAxf;
    let $GZXWRh;
    let $qdTRQb;
    let $jpnCMg;
    let $bFwQil;
    let $EwelPe;
    let $YkFDfa;
    let $ceaFvg;
    let $jfewWf;
    let $eyeXZd;
    let $Mlciwk;
    let $hdEklc;
    let $yDyjjg;
    let $YwjOlg;
    let $xSuEnd;
    let $dMCGFe;
    let $xAMIPf;
    let $XivjPk;
    let $HFVbWa;
    let $ChqnNb;
    let $WdcnVi;
    let $hvNYVa;
    let $TdkLti;
    let $ccGPra;
    let $MDtmah;
    let $zvLrDb;
    let $agrruf;
    let $IPTLxc;
    let $AMTDCg;
    let $ESXGTg;
    let $HkNsli;
    let $QDcrLj;
    let $MmUqGg;
    let $hxvPTa;
    let $dZHyUa;
    let $IZwoWk;
    let $gusQca;
    let $wEsPvj;
    let $RslKDe;
    let $NijAde;
    let $POKkVf;
    let $KtSpck;
    let $ECcTQe;
    let $kNClic;
    let $pWaAmh;
    let $gQjHwi;
    let $FTPLJd;
    let $wbxlTa;
    let $GcoQAe;
    let $LFARca;
    let $yGlvie;
    let $cMsuea;
    let $CawxQg;
    let $uUOMuh;
    let $rZkbce;
    let $QcAJpi;
    let $gttlBd;
    let $jRJeej;
    let $OHeJVf;
    let $DuYCzi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.Beacon", 
    {
  "h": 39253,
  "f": "LivingThing.Core.IOT.Devices.Beacon",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Beacon",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Beacon",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5CZWFjb24uU21hcnRCZWFjb25EZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIlNtYXJ0IEhvbWUiIF0sDQogICAgICAiTmFtZSI6ICJTbWFydEJlYWNvbiIsDQogICAgICAiRGVzY3JpcHRpb24iOiAiQmx1ZXRvb3RoIGJlYWNvbiB0byBsb2NhdGUgb2JqZWN0cyBpbiBwcm94aW1pdHkiLA0KICAgICAgIlVuaXRDb3N0Ijogew0KICAgICAgICAiVmFsdWUiOiA0MDAwLA0KICAgICAgICAiVW5pdCI6ICJOYWlyYSINCiAgICAgIH0sDQogICAgICAiSW1hZ2VzIjogWw0KICAgICAgICAifi9CZWFjb24vaW1nL0JlYWNvbi0xLmpwZyIsDQogICAgICAgICJ\u002BL0JlYWNvbi9pbWcvQmVhY29uLTIuanBnIiwNCiAgICAgICAgIn4vQmVhY29uL2ltZy9CZWFjb24tMy5qcGciLA0KICAgICAgICAifi9CZWFjb24vaW1nL0JlYWNvbi00LnBuZyIsDQogICAgICAgICJ\u002BL0JlYWNvbi9pbWcvQmVhY29uLTUucG5nIg0KICAgICAgXSwNCiAgICAgICJJY29uIjogeyAiTmFtZSI6ICJtZGkgbWRpLWRpYW1vbmQtc3RvbmUiIH0sDQogICAgICAiVGhlbWVDb2xvciI6ICIjZDc3YmJhIiwNCiAgICAgICJmRmxhZ3MiOiAiUHVibGlzaGVkIiwNCiAgICAgICJTZWN1cml0aWVzIjogIkNoYWxsZW5nZUhhbmRTaGFrZUF1dGhlbnRpY2F0aW9uUHJvdG9jb2wsQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyIsDQogICAgICAiU3RhdHVzTmFtZXMiOiAiU3RhdHVzLlN0YXR1cyxEZXZpY2UuU3RhdHVzLkZyYW1lLkJlYWNvbi5Sc3NpIg0KICAgIH0NCiAgfQ0KfQ=="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1349973)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceScopeModelCustomAttributesProvider`, ($self) => class SmartBeaconDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296317269)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296317269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296317269)
            
            static $h = 1349973;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296317269),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1349973,
      "h": 4296317269,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296317269)
  ],
  "h": 1349973
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1349973)
        
        

        //--TRIMMABLE-BOUNDARY-START(3053909)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconBroadcastPeerMessagesCustomAttributesProvider`, ($self) => class SmartBeaconBroadcastPeerMessagesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298021205)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298021205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298021205)
            
            static $h = 3053909;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298021205),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3053909,
      "h": 4298021205,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298021205)
  ],
  "h": 3053909
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconBroadcastPeerMessagesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconBroadcastPeerMessagesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3053909)
        
        

        //--TRIMMABLE-BOUNDARY-START(1874261)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconServiceModelCustomAttributesProvider`, ($self) => class SmartBeaconServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296841557)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296841557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296841557)
            
            static $h = 1874261;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296841557),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1874261,
      "h": 4296841557,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296841557)
  ],
  "h": 1874261
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1874261)
        
        

        //--TRIMMABLE-BOUNDARY-START(825685)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceModelCustomAttributesProvider`, ($self) => class SmartBeaconDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295792981)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295792981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295792981)
            
            static $h = 825685;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295792981),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 825685,
      "h": 4295792981,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295792981)
  ],
  "h": 825685
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(825685)
        
        

        //--TRIMMABLE-BOUNDARY-START(366933)
        $asm.$cls(`$jjuN.LCIDB.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295334229)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295334229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelCustomAttributesProvider, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBM.SmartBeaconDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBM.SmartBeaconDeviceModelCustomAttributesProvider, $.$jjuN.LCIDBM.SmartBeaconDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelCustomAttributesProvider, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBM.SmartBeaconDeviceScopeModelCustomAttributesProvider, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelCustomAttributesProvider, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBM.SmartBeaconServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBM.SmartBeaconServiceModelCustomAttributesProvider, $.$jjuN.LCIDBM.SmartBeaconServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBMS.SmartBeaconStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBMS.SmartBeaconStatusModelCustomAttributesProvider, $.$jjuN.LCIDBMS.SmartBeaconStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBS$1.SmartBeaconBroadcastPeerMessages.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBS$1.SmartBeaconBroadcastPeerMessagesCustomAttributesProvider, $.$jjuN.LCIDBS$1.SmartBeaconBroadcastPeerMessagesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBS$1.SmartBeaconActions.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBS$1.SmartBeaconActionsCustomAttributesProvider, $.$jjuN.LCIDBS$1.SmartBeaconActionsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettingsCustomAttributesProvider, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBS$1.SmartBeaconClickCommand.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBS$1.SmartBeaconClickCommandCustomAttributesProvider, $.$jjuN.LCIDBS$1.SmartBeaconClickCommandCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsCustomAttributesProvider, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295334229)
            
            static $h = 366933;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295334229),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 366933,
      "h": 4295334229,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295334229)
  ],
  "h": 366933
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(366933)
        
        

        //--TRIMMABLE-BOUNDARY-START(3184981)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconClickCommandCustomAttributesProvider`, ($self) => class SmartBeaconClickCommandCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298152277)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298152277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298152277)
            
            static $h = 3184981;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298152277),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3184981,
      "h": 4298152277,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298152277)
  ],
  "h": 3184981
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconClickCommandCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconClickCommandCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3184981)
        
        

        //--TRIMMABLE-BOUNDARY-START(235861)
        $asm.$cls(`$jjuN.LCIDB._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295203157)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295203157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$jjuN.LCIDB.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295203157)
            
            static $h = 235861;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295203157),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 235861,
      "h": 4295203157,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295203157)
  ],
  "h": 235861
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(235861)
        
        

        //--TRIMMABLE-BOUNDARY-START(3316053)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SmartBeaconDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298283349)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298283349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider$$($.$jjuN.LCIDBS$1.SmartBeaconActions).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298283349)
            
            static $h = 3316053;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298283349),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3316053,
      "h": 4298283349,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298283349)
  ],
  "h": 3316053
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3316053)
        
        

        //--TRIMMABLE-BOUNDARY-START(4102485)
        $asm.$cls(`$jjuN.LCIDB.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299069781)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299069781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelTypeDescriptorBuilder.Register();
                $.$jjuN.LCIDBM.SmartBeaconDeviceModelTypeDescriptorBuilder.Register();
                $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$jjuN.LCIDBM.SmartBeaconServiceModelTypeDescriptorBuilder.Register();
                $.$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptorBuilder.Register();
                $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299069781)
            
            static $h = 4102485;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299069781),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4102485,
      "h": 4299069781,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299069781)
  ],
  "h": 4102485
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4102485)
        
        

        //--TRIMMABLE-BOUNDARY-START(1743189)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SmartBeaconDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591677781)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591677781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eyeXZd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1743189,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591677781)
            
            //--TRIMMABLE-BOUNDARY-START(4296710485)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296710485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296710485)
            
            //--TRIMMABLE-BOUNDARY-START(4296710485)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296710485)
            
            static $h = 1743189;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591677781),
    {
      "r": 65537,
      "n": "Register",
      "d": 1743189,
      "h": 8591677781,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591677781)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296710485),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1743189,
      "h": 4296710485,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296710485)
  ],
  "h": 1743189
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1743189)
        
        

        //--TRIMMABLE-BOUNDARY-START(2005333)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconServiceModelTypeDescriptorBuilder`, ($self) => class SmartBeaconServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591939925)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591939925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$jjuN.LCIDBM.SmartBeaconServiceModelTypeDescriptor()
                        const $t1 = $.$jjuN.LCIDBM.SmartBeaconServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $jpnCMg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2005333,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$jjuN.LCIDBM.SmartBeaconServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591939925)
            
            //--TRIMMABLE-BOUNDARY-START(4296972629)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296972629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296972629)
            
            //--TRIMMABLE-BOUNDARY-START(4296972629)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296972629)
            
            static $h = 2005333;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591939925),
    {
      "r": 65537,
      "n": "Register",
      "d": 2005333,
      "h": 8591939925,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591939925)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296972629),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2005333,
      "h": 4296972629,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296972629)
  ],
  "h": 2005333
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2005333)
        
        

        //--TRIMMABLE-BOUNDARY-START(956757)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceModelTypeDescriptorBuilder`, ($self) => class SmartBeaconDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590891349)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590891349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$jjuN.LCIDBM.SmartBeaconDeviceModelTypeDescriptor()
                        const $t1 = $.$jjuN.LCIDBM.SmartBeaconDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $EwelPe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":956757,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$jjuN.LCIDBM.SmartBeaconDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590891349)
            
            //--TRIMMABLE-BOUNDARY-START(4295924053)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295924053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295924053)
            
            //--TRIMMABLE-BOUNDARY-START(4295924053)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295924053)
            
            static $h = 956757;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590891349),
    {
      "r": 65537,
      "n": "Register",
      "d": 956757,
      "h": 8590891349,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590891349)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295924053),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 956757,
      "h": 4295924053,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295924053)
  ],
  "h": 956757
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(956757)
        
        

        //--TRIMMABLE-BOUNDARY-START(3578197)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsCustomAttributesProvider`, ($self) => class SmartBeaconDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298545493)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298545493)
            
            //--TRIMMABLE-BOUNDARY-START(8593512789)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593512789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("OnClick", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (257);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("RSSI", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (258);
                            $i4.Description = "RSSI at 1m distance";
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Theme", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (259);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ceaFvg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3578197,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $jfewWf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3578197,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593512789)
            
            static $h = 3578197;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593512789),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3578197,
      "h": 8593512789,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593512789)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298545493),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3578197,
      "h": 4298545493,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298545493)
  ],
  "h": 3578197
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3578197)
        
        

        //--TRIMMABLE-BOUNDARY-START(432469)
        $asm.$cls(`$jjuN.LCIDB.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295399765)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295399765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295399765)
            
            static $h = 432469;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295399765),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 432469,
      "h": 4295399765,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295399765)
  ],
  "h": 432469
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(432469)
        
        

        //--TRIMMABLE-BOUNDARY-START(563541)
        $asm.$cls(`$jjuN.LCIDBMC.SmartBeaconAlarmControlModelCustomAttributesProvider`, ($self) => class SmartBeaconAlarmControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295530837)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295530837)
            
            //--TRIMMABLE-BOUNDARY-START(8590498133)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590498133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Count", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $dMCGFe ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":563541,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $xAMIPf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":563541,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590498133)
            
            static $h = 563541;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590498133),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 563541,
      "h": 8590498133,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590498133)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295530837),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 563541,
      "h": 4295530837,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295530837)
  ],
  "h": 563541
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.Controls.SmartBeaconAlarmControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}Controls${separator}SmartBeaconAlarmControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(563541)
        
        

        //--TRIMMABLE-BOUNDARY-START(3447125)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SmartBeaconDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593381717)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593381717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XivjPk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3447125,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593381717)
            
            //--TRIMMABLE-BOUNDARY-START(4298414421)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298414421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298414421)
            
            //--TRIMMABLE-BOUNDARY-START(4298414421)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298414421)
            
            static $h = 3447125;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593381717),
    {
      "r": 65537,
      "n": "Register",
      "d": 3447125,
      "h": 8593381717,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593381717)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298414421),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3447125,
      "h": 4298414421,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298414421)
  ],
  "h": 3447125
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3447125)
        
        

        //--TRIMMABLE-BOUNDARY-START(1218901)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SmartBeaconDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591153493)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591153493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $MmUqGg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1218901,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591153493)
            
            //--TRIMMABLE-BOUNDARY-START(4296186197)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296186197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296186197)
            
            //--TRIMMABLE-BOUNDARY-START(4296186197)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296186197)
            
            static $h = 1218901;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591153493),
    {
      "r": 65537,
      "n": "Register",
      "d": 1218901,
      "h": 8591153493,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591153493)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296186197),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1218901,
      "h": 4296186197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296186197)
  ],
  "h": 1218901
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1218901)
        
        

        //--TRIMMABLE-BOUNDARY-START(694613)
        $asm.$cls(`$jjuN.LCIDBMC.SmartBeaconAlarmControlModelTypeDescriptorBuilder`, ($self) => class SmartBeaconAlarmControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590629205)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590629205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelTypeDescriptor()
                        const $t1 = $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Beacon.Models.Controls.SmartBeaconAlarmControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ccGPra ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":694613,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590629205)
            
            //--TRIMMABLE-BOUNDARY-START(4295661909)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295661909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295661909)
            
            //--TRIMMABLE-BOUNDARY-START(4295661909)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295661909)
            
            static $h = 694613;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590629205),
    {
      "r": 65537,
      "n": "Register",
      "d": 694613,
      "h": 8590629205,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590629205)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295661909),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 694613,
      "h": 4295661909,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295661909)
  ],
  "h": 694613
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.Controls.SmartBeaconAlarmControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}Controls${separator}SmartBeaconAlarmControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(694613)
        
        

        //--TRIMMABLE-BOUNDARY-START(1612117)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelCustomAttributesProvider`, ($self) => class SmartBeaconDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296579413)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296579413)
            
            //--TRIMMABLE-BOUNDARY-START(8591546709)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591546709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("On", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (13432);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ChqnNb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1612117,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $WdcnVi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1612117,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591546709)
            
            static $h = 1612117;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591546709),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1612117,
      "h": 8591546709,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591546709)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296579413),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1612117,
      "h": 4296579413,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296579413)
  ],
  "h": 1612117
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1612117)
        
        

        //--TRIMMABLE-BOUNDARY-START(2267477)
        $asm.$cls(`$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptorBuilder`, ($self) => class SmartBeaconStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592202069)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592202069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptor()
                        const $t1 = $.$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $FTPLJd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2267477,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$jjuN.LCIDBMS.SmartBeaconStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592202069)
            
            //--TRIMMABLE-BOUNDARY-START(4297234773)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297234773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297234773)
            
            //--TRIMMABLE-BOUNDARY-START(4297234773)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297234773)
            
            static $h = 2267477;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592202069),
    {
      "r": 65537,
      "n": "Register",
      "d": 2267477,
      "h": 8592202069,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592202069)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297234773),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2267477,
      "h": 4297234773,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297234773)
  ],
  "h": 2267477
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}Statuses${separator}SmartBeaconStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2267477)
        
        

        //--TRIMMABLE-BOUNDARY-START(2136405)
        $asm.$cls(`$jjuN.LCIDBMS.SmartBeaconStatusModelCustomAttributesProvider`, ($self) => class SmartBeaconStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297103701)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297103701)
            
            //--TRIMMABLE-BOUNDARY-START(8592070997)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592070997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$jjuN.LCIDBMS.SmartBeaconStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Status", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Format=Bool(ON, OFF)"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("CountDown", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Format=TimeSpan>Remove(^0s$)", "Icon=Timer"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$jjuN.LCIDBMS.SmartBeaconStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $hvNYVa ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2136405,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $TdkLti ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2136405,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592070997)
            
            static $h = 2136405;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592070997),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2136405,
      "h": 8592070997,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592070997)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297103701),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2136405,
      "h": 4297103701,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297103701)
  ],
  "h": 2136405
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}Statuses${separator}SmartBeaconStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2136405)
        
        

        //--TRIMMABLE-BOUNDARY-START(1481045)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SmartBeaconDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591415637)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591415637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HkNsli ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1481045,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591415637)
            
            //--TRIMMABLE-BOUNDARY-START(4296448341)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296448341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296448341)
            
            //--TRIMMABLE-BOUNDARY-START(4296448341)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296448341)
            
            static $h = 1481045;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591415637),
    {
      "r": 65537,
      "n": "Register",
      "d": 1481045,
      "h": 8591415637,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591415637)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296448341),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1481045,
      "h": 4296448341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296448341)
  ],
  "h": 1481045
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1481045)
        
        

        //--TRIMMABLE-BOUNDARY-START(3709269)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptorBuilder`, ($self) => class SmartBeaconDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593643861)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593643861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor()
                        const $t1 = $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CawxQg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3709269,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593643861)
            
            //--TRIMMABLE-BOUNDARY-START(4298676565)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298676565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298676565)
            
            //--TRIMMABLE-BOUNDARY-START(4298676565)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298676565)
            
            static $h = 3709269;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593643861),
    {
      "r": 65537,
      "n": "Register",
      "d": 3709269,
      "h": 8593643861,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593643861)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298676565),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3709269,
      "h": 4298676565,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298676565)
  ],
  "h": 3709269
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3709269)
        
        

        //--TRIMMABLE-BOUNDARY-START(1087829)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SmartBeaconDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296055125)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296055125)
            
            //--TRIMMABLE-BOUNDARY-START(8591022421)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591022421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Frame", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Exclude = $.$cast((16777215), $.$fPer.LCFCA$1.SchemaType);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $pWaAmh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1087829,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $gQjHwi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1087829,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$jjuN.LCIDBMS.SmartBeaconStatusModel).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591022421)
            
            static $h = 1087829;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591022421),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1087829,
      "h": 8591022421,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591022421)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296055125),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1087829,
      "h": 4296055125,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296055125)
  ],
  "h": 1087829
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1087829)
        
        

        //--TRIMMABLE-BOUNDARY-START(2922837)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconActionsCustomAttributesProvider`, ($self) => class SmartBeaconActionsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297890133)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297890133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297890133)
            
            static $h = 2922837;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297890133),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2922837,
      "h": 4297890133,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297890133)
  ],
  "h": 2922837
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconActionsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconActionsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2922837)
        
        

        //--TRIMMABLE-BOUNDARY-START(104789)
        $asm.$cls(`$jjuN._LCIDBVB.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295072085)
            static /*void */ CreateDataList_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.Collections.Generic.IEnumerable<T>*/ __arg0, /*int*/ __seq1, /*global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListFeatures*/ __arg1, /*int*/ __seq2, /*global::System.Object*/ __arg2, /*int*/ __seq3, /*global::System.Int32*/ __arg3, /*int*/ __seq4, /*global::Microsoft.AspNetCore.Components.RenderFragment<global::LivingThing.Core.Frameworks.Client.Components.DataList.DataListItemContext<T, global::LivingThing.Core.Frameworks.Client.Components.DataList.DefaultDataListItem<T>>>*/ __arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295072085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Data", __arg0);
                __builder.AddComponentParameter(__seq1, "Features", $.$box(__arg1, $.$hDPm.LCFCCD$1.DataListFeatures));
                __builder.AddComponentParameter(__seq2, "Visualization", __arg2);
                __builder.AddComponentParameter(__seq3, "PadContent", $.$box(__arg3, $.$$.S.Int32));
                __builder.AddComponentParameter(__seq4, "ChildContent", __arg4);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295072085)
            
            static $h = 104789;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295072085),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": (T) => $.$$.SCG.IEnumerable$$(T).$h
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": 14505642
        },
        {
          "n": "__seq2",
          "p": 655361
        },
        {
          "n": "__arg2",
          "p": 131073
        },
        {
          "n": "__seq3",
          "p": 655361
        },
        {
          "n": "__arg3",
          "p": 655361
        },
        {
          "n": "__seq4",
          "p": 655361
        },
        {
          "n": "__arg4",
          "p": (T) => $.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$(T, $.$hDPm.LCFCCD$1.DefaultDataListItem$$(T))).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateDataList_0",
      "d": 104789,
      "h": 4295072085,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295072085)
  ],
  "h": 104789
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.Devices.Beacon.Views.BeaconMap.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Views${separator}BeaconMap${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(104789)
        
        

        //--TRIMMABLE-BOUNDARY-START(301397)
        $asm.$cls(`$jjuN.LCIDB.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180170581)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180170581)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295268693)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295268693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295268693)
            
            //--TRIMMABLE-BOUNDARY-START(4295268693)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295268693)
            
            static $h = 301397;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180170581),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885203285,
        "f": 50331649
      },
      "n": "Paths",
      "d": 301397,
      "h": 17180170581,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180170581)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295268693),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 301397,
      "h": 4295268693,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295268693)
  ],
  "h": 301397
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(301397)
        
        

        //--TRIMMABLE-BOUNDARY-START(2333013)
        $asm.$cls(`$jjuN.LCIDB.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182202197)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jjuN.LCIDBV.BeaconMap.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jjuN.LCIDBV.BeaconMap().$ctor$5();
                    }, $YwjOlg ??= {"r":2752627,"n":"","d":2333013,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$jjuN.LCIDBV.SmartBeaconDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$jjuN.LCIDBV.SmartBeaconDeviceDetails().$ctor$4();
                    }, $xSuEnd ??= {"r":2752627,"n":"","d":2333013,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17182202197)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4297300309)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297300309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297300309)
            
            //--TRIMMABLE-BOUNDARY-START(4297300309)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297300309)
            
            static $h = 2333013;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182202197),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887234901,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 2333013,
      "h": 17182202197,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182202197)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297300309),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2333013,
      "h": 4297300309,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297300309)
  ],
  "h": 2333013
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2333013)
        
        

        //--TRIMMABLE-BOUNDARY-START(2595157)
        $asm.$cls(`$jjuN.LCIDB.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592529749)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592529749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$jjuN.LCIDB.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$jjuN.LCIDB.SmartBeaconDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$jjuN.LCIDB.SmartBeaconDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$jjuN.LCIDB.SmartBeaconDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$jjuN.LCIDB.SmartBeaconDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jjuN.LCIDB.SmartBeaconDeviceFamily, x);
                }, $IPTLxc ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2595157,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jjuN.LCIDB.SmartBeaconDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$jjuN.LCIDB.SmartBeaconDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $AMTDCg ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2595157,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$jjuN.LCIDB.SmartBeaconDevice)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$jjuN.LCIDB.SmartBeaconDeviceFamily, x);
                }, $ESXGTg ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$jjuN.LCIDB.SmartBeaconDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2595157,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel), $.$jjuN.LCIDBP.BeaconMessageDecoder, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$jjuN.LCIDB.SmartBeaconDevice), $.$jjuN.LCIDBPC.SmartBeaconDeviceCommands$$($.$jjuN.LCIDB.SmartBeaconDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$jjuN.LCIDB.SmartBeaconDevice), $.$jjuN.LCIDBV.SmartBeaconViewRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592529749)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$jjuN.LCIDB.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297562453)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297562453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297562453)
            
            //--TRIMMABLE-BOUNDARY-START(4297562453)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297562453)
            
            static $h = 2595157;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592529749),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2595157,
      "h": 8592529749,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592529749)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297562453),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2595157,
      "h": 4297562453,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297562453)
  ],
  "h": 2595157
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2595157)
        
        

        //--TRIMMABLE-BOUNDARY-START(4495701)
        $asm.$cls(`$jjuN.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299462997)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299462997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299462997)
            
            //--TRIMMABLE-BOUNDARY-START(4299462997)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299462997)
            
            static $h = 4495701;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299462997),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4495701,
      "h": 4299462997,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299462997)
  ],
  "h": 4495701,
  "a": [
    {
      "t": 4430165,
      "c": 4299397461
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4495701)
        
        

        //--TRIMMABLE-BOUNDARY-START(4430165)
        $asm.$cls(`$jjuN.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299397461)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299397461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299397461)
            
            //--TRIMMABLE-BOUNDARY-START(4299397461)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299397461)
            
            static $h = 4430165;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299397461),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4430165,
      "h": 4299397461,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299397461)
  ],
  "h": 4430165
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4430165)
        
        

        //--TRIMMABLE-BOUNDARY-START(2070869)
        $asm.$cls(`$jjuN.LCIDBMS.SmartBeaconStatusModel`, ($self) => class SmartBeaconStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(55836645717)
            /*bool*/ Status = false;
            //--TRIMMABLE-BOUNDARY-END(55836645717)
            
            //--TRIMMABLE-BOUNDARY-START(17181940053)
            /*int*/ CountDown = 0;
            //--TRIMMABLE-BOUNDARY-END(17181940053)
            
            //--TRIMMABLE-BOUNDARY-START(12886972757)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886972757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886972757)
            
            //--TRIMMABLE-BOUNDARY-START(12886972757)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886972757)
            
            static $h = 2070869;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836645717),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361809237,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541678421,
        "f": 83886081
      },
      "n": "Status",
      "d": 2070869,
      "h": 55836645717,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "Format=Bool(ON, OFF)"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836645717),
//--TRIMMABLE-BOUNDARY-START(17181940053),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771874645,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951743829,
        "f": 83886081
      },
      "n": "CountDown",
      "d": 2070869,
      "h": 17181940053,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "Format=TimeSpan\u003ERemove(^0s$)",
                "Icon=Timer"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17181940053)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886972757),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2070869,
      "h": 12886972757,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886972757)
  ],
  "h": 2070869
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}Statuses${separator}SmartBeaconStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2070869)
        
        

        //--TRIMMABLE-BOUNDARY-START(498005)
        $asm.$cls(`$jjuN.LCIDBMC.SmartBeaconAlarmControlModel`, ($self) => class SmartBeaconAlarmControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590432597)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590432597);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590432597)
            
            //--TRIMMABLE-BOUNDARY-START(12885399893)
            $ctor$3(/*int*/ count)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885399893);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Count = count;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885399893)
            
            //--TRIMMABLE-BOUNDARY-START(17180367189)
            /*int */ get Command()
            {
                return ((128 + 4) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17180367189)
            
            //--TRIMMABLE-BOUNDARY-START(21475334485)
            /*int*/ Count = 0;
            //--TRIMMABLE-BOUNDARY-END(21475334485)
            
            //--TRIMMABLE-BOUNDARY-START(8590432597)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590432597)
            
            static $h = 498005;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180367189),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065269077,
        "f": 50364417
      },
      "n": "Command",
      "d": 498005,
      "h": 17180367189,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180367189),
//--TRIMMABLE-BOUNDARY-START(21475334485),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655203669,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245138261,
        "f": 83886082
      },
      "n": "Count",
      "d": 498005,
      "h": 21475334485,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475334485)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590432597),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 498005,
      "h": 8590432597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590432597),
//--TRIMMABLE-BOUNDARY-START(12885399893),
    {
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 498005,
      "h": 12885399893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885399893)
  ],
  "h": 498005
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.Controls.SmartBeaconAlarmControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}Controls${separator}SmartBeaconAlarmControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(498005)
        
        

        //--TRIMMABLE-BOUNDARY-START(2988373)
        $asm.$str(`$jjuN.LCIDBS$1.SmartBeaconBroadcastPeerMessages`, ($self) => class SmartBeaconBroadcastPeerMessages extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static State = 1;
            static ToggleCountDown = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2988373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "State": 1n,
                    "ToggleCountDown": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297955669)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297955669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297955669)
            
            //--TRIMMABLE-BOUNDARY-START(4297955669)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297955669)
            
            static $h = 2988373;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592922965),
    {
      "t": 2988373,
      "n": "None",
      "d": 2988373,
      "h": 8592922965,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592922965),
//--TRIMMABLE-BOUNDARY-START(12887890261),
    {
      "t": 2988373,
      "n": "State",
      "d": 2988373,
      "h": 12887890261,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887890261),
//--TRIMMABLE-BOUNDARY-START(17182857557),
    {
      "t": 2988373,
      "n": "ToggleCountDown",
      "d": 2988373,
      "h": 17182857557,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182857557)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297955669),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2988373,
      "h": 4297955669,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297955669)
  ],
  "h": 2988373
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconBroadcastPeerMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconBroadcastPeerMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2988373)
        
        

        //--TRIMMABLE-BOUNDARY-START(2857301)
        $asm.$str(`$jjuN.LCIDBS$1.SmartBeaconActions`, ($self) => class SmartBeaconActions extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Off = 0;
            static On = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2857301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Off": 0n,
                    "On": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297824597)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297824597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297824597)
            
            //--TRIMMABLE-BOUNDARY-START(4297824597)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297824597)
            
            static $h = 2857301;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592791893),
    {
      "t": 2857301,
      "n": "Off",
      "d": 2857301,
      "h": 8592791893,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592791893),
//--TRIMMABLE-BOUNDARY-START(12887759189),
    {
      "t": 2857301,
      "n": "On",
      "d": 2857301,
      "h": 12887759189,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887759189)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297824597),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2857301,
      "h": 4297824597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297824597)
  ],
  "h": 2857301
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconActions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconActions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2857301)
        
        

        //--TRIMMABLE-BOUNDARY-START(3119445)
        $asm.$str(`$jjuN.LCIDBS$1.SmartBeaconClickCommand`, ($self) => class SmartBeaconClickCommand extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Alarm = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3119445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Alarm": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298086741)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298086741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298086741)
            
            //--TRIMMABLE-BOUNDARY-START(4298086741)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298086741)
            
            static $h = 3119445;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888021333),
    {
      "t": 3119445,
      "n": "None",
      "d": 3119445,
      "h": 12888021333,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888021333),
//--TRIMMABLE-BOUNDARY-START(8593054037),
    {
      "t": 3119445,
      "n": "Alarm",
      "d": 3119445,
      "h": 8593054037,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593054037)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298086741),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3119445,
      "h": 4298086741,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298086741)
  ],
  "h": 3119445
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconClickCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconClickCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3119445)
        
        

        //--TRIMMABLE-BOUNDARY-START(170325)
        $asm.$cls(`$jjuN.LCIDB._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590104917)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590104917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590104917)
            
            //--TRIMMABLE-BOUNDARY-START(4295137621)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295137621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295137621)
            
            //--TRIMMABLE-BOUNDARY-START(4295137621)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295137621)
            
            static $h = 170325;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590104917),
    {
      "r": 65537,
      "n": "Execute",
      "d": 170325,
      "h": 8590104917,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590104917)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295137621),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 170325,
      "h": 4295137621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295137621)
  ],
  "h": 170325
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(170325)
        
        

        //--TRIMMABLE-BOUNDARY-START(629077)
        $asm.$cls(`$jjuN.LCIDBMC.SmartBeaconAlarmControlModelTypeDescriptor`, ($self) => class SmartBeaconAlarmControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295596373)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295596373);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelTypeDescriptor.GenerateProperties($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel, this, factory);
                    }, $MDtmah ??= {"r":65537,"n":"","d":629077,"h":0,"f":17825794}), 0, "SmartBeaconAlarmControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Beacon\\Models_Controls_SmartBeaconAlarmControlModel_LivingThing.Core.IOT.Devices.Beacon.Models.Controls.SmartBeaconAlarmControlModelTypeDescriptorBuilder.g.cs", "SmartBeaconAlarmControlModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295596373)
            
            //--TRIMMABLE-BOUNDARY-START(12885530965)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885530965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Count"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel.$type, $.$discardRef(), "Count", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Count")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Count";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Beacon.Models.Controls.SmartBeaconAlarmControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel)).Count);
                        }, $zvLrDb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":629077,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Command";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Beacon.Models.Controls.SmartBeaconAlarmControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel)).Command);
                        }, $agrruf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":629077,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885530965)
            
            //--TRIMMABLE-BOUNDARY-START(17180498261)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.Controls.SmartBeaconAlarmControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180498261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Count = _target.Count;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Count"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Count, ($v) => _Count = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180498261)
            
            //--TRIMMABLE-BOUNDARY-START(8590563669)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.Controls.SmartBeaconAlarmControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590563669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel)))
                {
                    /*var*/ let result = $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590563669)
            
            static $h = 629077;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885530965),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 629077,
      "h": 12885530965,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885530965),
//--TRIMMABLE-BOUNDARY-START(17180498261),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 498005,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 629077,
      "h": 17180498261,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180498261),
//--TRIMMABLE-BOUNDARY-START(8590563669),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 498005,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 629077,
      "h": 8590563669,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590563669)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295596373),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 629077,
      "h": 4295596373,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295596373)
  ],
  "h": 629077
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.Controls.SmartBeaconAlarmControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}Controls${separator}SmartBeaconAlarmControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(629077)
        
        

        //--TRIMMABLE-BOUNDARY-START(2201941)
        $asm.$cls(`$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptor`, ($self) => class SmartBeaconStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBMS.SmartBeaconStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297169237)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297169237);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptor.GenerateProperties($.$jjuN.LCIDBMS.SmartBeaconStatusModel, this, factory);
                    }, $wbxlTa ??= {"r":65537,"n":"","d":2201941,"h":0,"f":17825794}), 0, "SmartBeaconStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Beacon\\Models_Statuses_SmartBeaconStatusModel_LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModelTypeDescriptorBuilder.g.cs", "SmartBeaconStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297169237)
            
            //--TRIMMABLE-BOUNDARY-START(12887103829)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887103829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Status"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$jjuN.LCIDBMS.SmartBeaconStatusModel.$type, $.$discardRef(), "Status", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Status")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Status";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$jjuN.LCIDBMS.SmartBeaconStatusModel)).Status);
                        }, $GcoQAe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2201941,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Status = value.AsBool();
                        }, $LFARca ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2201941,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CountDown"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$jjuN.LCIDBMS.SmartBeaconStatusModel.$type, $.$discardRef(), "CountDown", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CountDown")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CountDown";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$jjuN.LCIDBMS.SmartBeaconStatusModel)).CountDown);
                        }, $yGlvie ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2201941,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CountDown = value.AsInt();
                        }, $cMsuea ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2201941,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887103829)
            
            //--TRIMMABLE-BOUNDARY-START(17182071125)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182071125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Status = _target.Status;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Status"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Status, ($v) => _Status = $v, null, true)))
                    {
                        _target.Status = _Status;
                    }
                }
                {
                    /*var*/ let _CountDown = _target.CountDown;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CountDown"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _CountDown, ($v) => _CountDown = $v, $.$$.S.Int32)))
                    {
                        _target.CountDown = _CountDown;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182071125)
            
            //--TRIMMABLE-BOUNDARY-START(8592136533)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592136533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$jjuN.LCIDBMS.SmartBeaconStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$jjuN.LCIDBMS.SmartBeaconStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBMS.SmartBeaconStatusModel)))
                {
                    /*var*/ let result = $.$jjuN.LCIDBMS.SmartBeaconStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBMS.SmartBeaconStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$jjuN.LCIDBMS.SmartBeaconStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBMS.SmartBeaconStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592136533)
            
            static $h = 2201941;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBMS.SmartBeaconStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887103829),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2201941,
      "h": 12887103829,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887103829),
//--TRIMMABLE-BOUNDARY-START(17182071125),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2070869,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2201941,
      "h": 17182071125,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182071125),
//--TRIMMABLE-BOUNDARY-START(8592136533),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2070869,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2201941,
      "h": 8592136533,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592136533)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297169237),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2201941,
      "h": 4297169237,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297169237)
  ],
  "h": 2201941
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$jjuN.LCIDBMS.SmartBeaconStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}Statuses${separator}SmartBeaconStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2201941)
        
        

        //--TRIMMABLE-BOUNDARY-START(2464085)
        $asm.$cls(`$jjuN.LCIDBPC.SmartBeaconDeviceCommands<>`, (TDevice) => $asm.$gt(`$jjuN.LCIDBPC.SmartBeaconDeviceCommands<>`, [TDevice], ($self) => class SmartBeaconDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12887365973)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12887365973)
            
            //--TRIMMABLE-BOUNDARY-START(17182333269)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182333269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$jjuN.LCIDBPC.SmartBeaconDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17182333269)
            
            //--TRIMMABLE-BOUNDARY-START(8592398677)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592398677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592398677)
            
            //--TRIMMABLE-BOUNDARY-START(8592398677)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8592398677)
            
            //--TRIMMABLE-BOUNDARY-START(4297431381)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297431381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12887365973)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$jjuN.LCIDBPCV.SmartBeaconAlarmCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12887365973)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297431381)
            
            static $H = 2464085;
            static $h = 2464085;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182333269),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17182333269,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182333269)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887365973),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12887365973,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12887365973)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592398677),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8592398677,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592398677)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 2464085,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Protocol.Commands.SmartBeaconDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Protocol${separator}Commands${separator}SmartBeaconDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2464085)
        
        

        //--TRIMMABLE-BOUNDARY-START(2529621)
        $asm.$cls(`$jjuN.LCIDBPCV.SmartBeaconAlarmCommand`, ($self) => class SmartBeaconAlarmCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297496917)
            $ctor$6()
            {
                super.$ctor$5("CountDown", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297496917);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297496917)
            
            //--TRIMMABLE-BOUNDARY-START(17182398805)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-counter"/*MaterialDesignIconNames.Counter*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17182398805)
            
            //--TRIMMABLE-BOUNDARY-START(4297496917)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4297496917)
            
            static $h = 2529621;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182398805),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887431509,
        "f": 50364417
      },
      "n": "Icon",
      "d": 2529621,
      "h": 17182398805,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17182398805)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297496917),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2529621,
      "h": 4297496917,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297496917)
  ],
  "h": 2529621
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Protocol.Commands.Variants.SmartBeaconAlarmCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Protocol${separator}Commands${separator}Variants${separator}SmartBeaconAlarmCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2529621)
        
        

        //--TRIMMABLE-BOUNDARY-START(1546581)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel`, ($self) => class SmartBeaconDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(8591481173)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591481173);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591481173)
            
            //--TRIMMABLE-BOUNDARY-START(12886448469)
            $ctor$5(/*SmartBeaconAlarmControlModel*/ on)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886448469);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.On = on;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886448469)
            
            //--TRIMMABLE-BOUNDARY-START(25771350357)
            /*SmartBeaconAlarmControlModel?*/ On = null;
            //--TRIMMABLE-BOUNDARY-END(25771350357)
            
            //--TRIMMABLE-BOUNDARY-START(8591481173)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8591481173)
            
            static $h = 1546581;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771350357),
    {
      "p": 498005,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476383061,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34361284949,
        "f": 83886081
      },
      "n": "On",
      "d": 1546581,
      "h": 25771350357,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771350357)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591481173),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1546581,
      "h": 8591481173,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591481173),
//--TRIMMABLE-BOUNDARY-START(12886448469),
    {
      "p": [
        {
          "n": "on",
          "p": 498005
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1546581,
      "h": 12886448469,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886448469)
  ],
  "h": 1546581
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1546581)
        
        

        //--TRIMMABLE-BOUNDARY-START(1022293)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel`, ($self) => class SmartBeaconDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$jjuN.LCIDBMS.SmartBeaconStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(12885924181)
            /*BeaconFrameBase*/ Frame = null;
            //--TRIMMABLE-BOUNDARY-END(12885924181)
            
            //--TRIMMABLE-BOUNDARY-START(34360760661)
            /*bool */ get IsValid()
            {
                return this.Frame !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(34360760661)
            
            //--TRIMMABLE-BOUNDARY-START(8590956885)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590956885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590956885)
            
            //--TRIMMABLE-BOUNDARY-START(8590956885)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590956885)
            
            static $h = 1022293;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$jjuN.LCIDBMS.SmartBeaconStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885924181),
    {
      "p": 628113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475858773,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950695253,
        "f": 83886081
      },
      "n": "Frame",
      "d": 1022293,
      "h": 12885924181,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Exclude",
              "v": 16777215,
              "t": 2722134
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885924181),
//--TRIMMABLE-BOUNDARY-START(34360760661),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065793365,
        "f": 50364417
      },
      "n": "IsValid",
      "d": 1022293,
      "h": 34360760661,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360760661)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590956885),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1022293,
      "h": 8590956885,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590956885)
  ],
  "h": 1022293
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1022293)
        
        

        //--TRIMMABLE-BOUNDARY-START(1677653)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelTypeDescriptor`, ($self) => class SmartBeaconDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296644949)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296644949);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelTypeDescriptor.GenerateProperties($.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, this, factory);
                    }, $Mlciwk ??= {"r":65537,"n":"","d":1677653,"h":0,"f":17825794}), 0, "SmartBeaconDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Beacon\\Models_SmartBeaconDeviceSendDataModel_LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SmartBeaconDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296644949)
            
            //--TRIMMABLE-BOUNDARY-START(12886579541)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886579541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("On"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel.$type, $.$discardRef(), "On", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("On")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "On";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel, ($.$cast(target, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel)).On);
                        }, $hdEklc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1677653,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.On = value.AsReference($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel);
                        }, $yDyjjg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1677653,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886579541)
            
            //--TRIMMABLE-BOUNDARY-START(17181546837)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181546837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                {
                    /*var*/ let _On = _target.On;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("On"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _On, ($v) => _On = $v, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel)))
                    {
                        _target.On = _On;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181546837)
            
            //--TRIMMABLE-BOUNDARY-START(8591612245)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591612245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591612245)
            
            static $h = 1677653;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886579541),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1677653,
      "h": 12886579541,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886579541),
//--TRIMMABLE-BOUNDARY-START(17181546837),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1546581,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1677653,
      "h": 17181546837,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181546837),
//--TRIMMABLE-BOUNDARY-START(8591612245),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1546581,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1677653,
      "h": 8591612245,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591612245)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296644949),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1677653,
      "h": 4296644949,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296644949)
  ],
  "h": 1677653
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1677653)
        
        

        //--TRIMMABLE-BOUNDARY-START(1153365)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelTypeDescriptor`, ($self) => class SmartBeaconDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296120661)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296120661);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, this, factory);
                    }, $hxvPTa ??= {"r":65537,"n":"","d":1153365,"h":0,"f":17825794}), 0, "SmartBeaconDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Beacon\\Models_SmartBeaconDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SmartBeaconDeviceReceivedDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296120661)
            
            //--TRIMMABLE-BOUNDARY-START(12886055253)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886055253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Frame"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel.$type, $.$discardRef(), "Frame", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Frame")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICB.BeaconFrameBase, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Frame";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICB.BeaconFrameBase, ($.$cast(target, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel)).Frame);
                        }, $dZHyUa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153365,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Frame = value.AsReference($.$XBGm.LCICB.BeaconFrameBase);
                        }, $IZwoWk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1153365,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsValid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel.$type, $.$discardRef(), "IsValid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsValid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "IsValid";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel)).IsValid);
                        }, $gusQca ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1153365,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$jjuN.LCIDBMS.SmartBeaconStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886055253)
            
            //--TRIMMABLE-BOUNDARY-START(17181022549)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181022549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.Beacon.Models.Statuses.SmartBeaconStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$jjuN.LCIDBMS.SmartBeaconStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$jjuN.LCIDBMS.SmartBeaconStatusModel)));
                {
                    /*var*/ let _Frame = _target.Frame;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Frame"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICB.BeaconFrameBase));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Frame, ($v) => _Frame = $v, $.$XBGm.LCICB.BeaconFrameBase)))
                    {
                        _target.Frame = _Frame;
                    }
                }
                {
                    /*var*/ let _IsValid = _target.IsValid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsValid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsValid, ($v) => _IsValid = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181022549)
            
            //--TRIMMABLE-BOUNDARY-START(8591087957)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591087957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591087957)
            
            static $h = 1153365;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886055253),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1153365,
      "h": 12886055253,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886055253),
//--TRIMMABLE-BOUNDARY-START(17181022549),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1022293,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1153365,
      "h": 17181022549,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181022549),
//--TRIMMABLE-BOUNDARY-START(8591087957),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1022293,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1153365,
      "h": 8591087957,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591087957)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296120661),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1153365,
      "h": 4296120661,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296120661)
  ],
  "h": 1153365
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1153365)
        
        

        //--TRIMMABLE-BOUNDARY-START(3774805)
        $asm.$cls(`$jjuN.LCIDB.SmartBeaconDataConverter`, ($self) => class SmartBeaconDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298742101)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298742101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298742101)
            
            //--TRIMMABLE-BOUNDARY-START(4298742101)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298742101)
            
            static $h = 3774805;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298742101),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3774805,
      "h": 4298742101,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298742101)
  ],
  "h": 3774805
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.SmartBeaconDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}SmartBeaconDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3774805)
        
        

        $asm.$typeProxy("$jjuN.LCIDBM.SmartBeaconServiceModel", "$jjuN.LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModel");
        $asm.$typeProxy("$jjuN.LCIDBM.SmartBeaconDeviceModel", "$jjuN.LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModel");
        $asm.$typeProxy("$jjuN.LCIDBS$1.SmartBeaconDeviceSettings", "$jjuN.LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings");
        $asm.$typeProxy("$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings", "$jjuN.LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettings");
        $asm.$typeProxy("$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler", "$jjuN.LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceStatusHandler");
        $asm.$typeProxy("$jjuN.LCIDBS.ISmartBeaconDeviceHubClient", "$jjuN.LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceHubClient");
        $asm.$typeProxy("$jjuN.LCIDBS.ISmartBeaconRemoteService", "$jjuN.LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconRemoteService");
        //--TRIMMABLE-BOUNDARY-START(1284437)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceScopeModel`, ($self) => class SmartBeaconDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296251733)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296251733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296251733)
            
            //--TRIMMABLE-BOUNDARY-START(4296251733)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296251733)
            
            static $h = 1284437;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296251733),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1284437,
      "h": 4296251733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296251733)
  ],
  "h": 1284437
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1284437)
        
        

        //--TRIMMABLE-BOUNDARY-START(2791765)
        $asm.$cls(`$jjuN.LCIDBS.ISmartBeaconRemoteService`, ($self) => class ISmartBeaconRemoteService
        {
            static $h = 2791765;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2791765
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$jjuN.LCIDBM.SmartBeaconServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$jjuN.LCIDBM.SmartBeaconServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$jjuN.LCIDBM.SmartBeaconServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$jjuN.LCIDBM.SmartBeaconServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$jjuN.LCIDBM.SmartBeaconServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$jjuN.LCIDBM.SmartBeaconServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$jjuN.LCIDBM.SmartBeaconServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$jjuN.LCIDBM.SmartBeaconServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Services${separator}ISmartBeaconRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2791765)
        
        

        //--TRIMMABLE-BOUNDARY-START(760149)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceModel`, ($self) => class SmartBeaconDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295727445)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295727445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295727445)
            
            //--TRIMMABLE-BOUNDARY-START(4295727445)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295727445)
            
            static $h = 760149;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295727445),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 760149,
      "h": 4295727445,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295727445)
  ],
  "h": 760149
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(760149)
        
        

        //--TRIMMABLE-BOUNDARY-START(2726229)
        $asm.$cls(`$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler`, ($self) => class ISmartBeaconDeviceStatusHandler
        {
            static $h = 2726229;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2726229
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Services${separator}ISmartBeaconDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2726229)
        
        

        //--TRIMMABLE-BOUNDARY-START(3250517)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings`, ($self) => class SmartBeaconDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceHardwareSettings$$($.$jjuN.LCIDBS$1.SmartBeaconActions)
        {
            //--TRIMMABLE-BOUNDARY-START(4298217813)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298217813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298217813)
            
            //--TRIMMABLE-BOUNDARY-START(4298217813)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298217813)
            
            static $h = 3250517;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceHardwareSettings$$($.$jjuN.LCIDBS$1.SmartBeaconActions); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298217813),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3250517,
      "h": 4298217813,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298217813)
  ],
  "h": 3250517
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3250517)
        
        

        //--TRIMMABLE-BOUNDARY-START(1808725)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconServiceModel`, ($self) => class SmartBeaconServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296776021)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296776021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296776021)
            
            //--TRIMMABLE-BOUNDARY-START(4296776021)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296776021)
            
            static $h = 1808725;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296776021),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1808725,
      "h": 4296776021,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296776021)
  ],
  "h": 1808725
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1808725)
        
        

        //--TRIMMABLE-BOUNDARY-START(2660693)
        $asm.$cls(`$jjuN.LCIDBS.ISmartBeaconDeviceHubClient`, ($self) => class ISmartBeaconDeviceHubClient
        {
            static $h = 2660693;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2660693
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Services${separator}ISmartBeaconDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2660693)
        
        

        //--TRIMMABLE-BOUNDARY-START(3512661)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconDeviceSettings`, ($self) => class SmartBeaconDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $self, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(47248152917)
            /*SmartBeaconClickCommand*/ OnClick = 0;
            //--TRIMMABLE-BOUNDARY-END(47248152917)
            
            //--TRIMMABLE-BOUNDARY-START(51543120213)
            /*double*/ RSSI = 0;
            //--TRIMMABLE-BOUNDARY-END(51543120213)
            
            //--TRIMMABLE-BOUNDARY-START(81607891285)
            /*WebColor*/ Theme = 0;
            //--TRIMMABLE-BOUNDARY-END(81607891285)
            
            //--TRIMMABLE-BOUNDARY-START(17183381845)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183381845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183381845)
            
            //--TRIMMABLE-BOUNDARY-START(17183381845)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17183381845)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51543120213)
                this.RSSI = -70;
                //--TRIMMABLE-BOUNDARY-END(51543120213)
                
            }
            static $h = 3512661;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47248152917),
    {
      "p": 3119445,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773316437,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60133054805,
        "f": 83886081
      },
      "n": "OnClick",
      "d": 3512661,
      "h": 47248152917,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 257,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47248152917),
//--TRIMMABLE-BOUNDARY-START(51543120213),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363251029,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68722989397,
        "f": 83886081
      },
      "n": "RSSI",
      "d": 3512661,
      "h": 51543120213,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 258,
              "t": 655361
            },
            {
              "n": "Description",
              "v": "RSSI at 1m distance",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51543120213),
//--TRIMMABLE-BOUNDARY-START(81607891285),
    {
      "p": 66423126,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953185621,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77312923989,
        "f": 83886081
      },
      "n": "Theme",
      "d": 3512661,
      "h": 81607891285,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 259,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81607891285)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183381845),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3512661,
      "h": 17183381845,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183381845)
  ],
  "h": 3512661
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3512661)
        
        

        //--TRIMMABLE-BOUNDARY-START(4036949)
        $asm.$cls(`$jjuN.LCIDB.SmartBeaconDeviceModelDefinition`, ($self) => class SmartBeaconDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4299004245)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299004245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299004245)
            
            //--TRIMMABLE-BOUNDARY-START(4299004245)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299004245)
            
            static $h = 4036949;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299004245),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4036949,
      "h": 4299004245,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299004245)
  ],
  "h": 4036949
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.SmartBeaconDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}SmartBeaconDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4036949)
        
        

        //--TRIMMABLE-BOUNDARY-START(1939797)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconServiceModelTypeDescriptor`, ($self) => class SmartBeaconServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296907093)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296907093);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$jjuN.LCIDBM.SmartBeaconServiceModelTypeDescriptor.GenerateProperties($.$jjuN.LCIDBM.SmartBeaconServiceModel, this, factory);
                    }, $bFwQil ??= {"r":65537,"n":"","d":1939797,"h":0,"f":17825794}), 0, "SmartBeaconServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Beacon\\Models_SmartBeaconServiceModel_LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModelTypeDescriptorBuilder.g.cs", "SmartBeaconServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296907093)
            
            //--TRIMMABLE-BOUNDARY-START(12886841685)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886841685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886841685)
            
            //--TRIMMABLE-BOUNDARY-START(17181808981)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181808981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModel, LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings, LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModel, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceStatusHandler, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceHubClient, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181808981)
            
            //--TRIMMABLE-BOUNDARY-START(8591874389)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591874389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$jjuN.LCIDBM.SmartBeaconServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$jjuN.LCIDBM.SmartBeaconServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconServiceModel)))
                {
                    /*var*/ let result = $.$jjuN.LCIDBM.SmartBeaconServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$jjuN.LCIDBM.SmartBeaconServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591874389)
            
            static $h = 1939797;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886841685),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1939797,
      "h": 12886841685,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886841685),
//--TRIMMABLE-BOUNDARY-START(17181808981),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1808725,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1939797,
      "h": 17181808981,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181808981),
//--TRIMMABLE-BOUNDARY-START(8591874389),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1808725,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1939797,
      "h": 8591874389,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591874389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296907093),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1939797,
      "h": 4296907093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296907093)
  ],
  "h": 1939797
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1939797)
        
        

        //--TRIMMABLE-BOUNDARY-START(891221)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceModelTypeDescriptor`, ($self) => class SmartBeaconDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295858517)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295858517);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$jjuN.LCIDBM.SmartBeaconDeviceModelTypeDescriptor.GenerateProperties($.$jjuN.LCIDBM.SmartBeaconDeviceModel, this, factory);
                    }, $YkFDfa ??= {"r":65537,"n":"","d":891221,"h":0,"f":17825794}), 0, "SmartBeaconDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Beacon\\Models_SmartBeaconDeviceModel_LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModelTypeDescriptorBuilder.g.cs", "SmartBeaconDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295858517)
            
            //--TRIMMABLE-BOUNDARY-START(12885793109)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885793109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885793109)
            
            //--TRIMMABLE-BOUNDARY-START(17180760405)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180760405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModel, LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings, LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModel, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceStatusHandler, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceHubClient, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180760405)
            
            //--TRIMMABLE-BOUNDARY-START(8590825813)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590825813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$jjuN.LCIDBM.SmartBeaconDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceModel)))
                {
                    /*var*/ let result = $.$jjuN.LCIDBM.SmartBeaconDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590825813)
            
            static $h = 891221;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885793109),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 891221,
      "h": 12885793109,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885793109),
//--TRIMMABLE-BOUNDARY-START(17180760405),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 760149,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 891221,
      "h": 17180760405,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180760405),
//--TRIMMABLE-BOUNDARY-START(8590825813),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 760149,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 891221,
      "h": 8590825813,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590825813)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295858517),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 891221,
      "h": 4295858517,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295858517)
  ],
  "h": 891221
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(891221)
        
        

        //--TRIMMABLE-BOUNDARY-START(3381589)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettingsTypeDescriptor`, ($self) => class SmartBeaconDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298348885)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298348885);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, this, factory);
                    }, $HFVbWa ??= {"r":65537,"n":"","d":3381589,"h":0,"f":17825794}), 0, "SmartBeaconDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Beacon\\Settings_SmartBeaconDeviceHardwareSettings_LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SmartBeaconDeviceHardwareSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298348885)
            
            //--TRIMMABLE-BOUNDARY-START(12888283477)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888283477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$jjuN.LCIDBS$1.SmartBeaconActions).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888283477)
            
            //--TRIMMABLE-BOUNDARY-START(17183250773)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183250773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModel, LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings, LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModel, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceStatusHandler, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceHubClient, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconRemoteService>.iSmartDeviceHardwareSettings<LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconActions>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$jjuN.LCIDBS$1.SmartBeaconActions).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceHardwareSettings$$($.$jjuN.LCIDBS$1.SmartBeaconActions)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183250773)
            
            //--TRIMMABLE-BOUNDARY-START(8593316181)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593316181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593316181)
            
            static $h = 3381589;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888283477),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3381589,
      "h": 12888283477,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888283477),
//--TRIMMABLE-BOUNDARY-START(17183250773),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3250517,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3381589,
      "h": 17183250773,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183250773),
//--TRIMMABLE-BOUNDARY-START(8593316181),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3250517,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3381589,
      "h": 8593316181,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593316181)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298348885),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3381589,
      "h": 4298348885,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298348885)
  ],
  "h": 3381589
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3381589)
        
        

        //--TRIMMABLE-BOUNDARY-START(1415509)
        $asm.$cls(`$jjuN.LCIDBM.SmartBeaconDeviceScopeModelTypeDescriptor`, ($self) => class SmartBeaconDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296382805)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296382805);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModelTypeDescriptor.GenerateProperties($.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, this, factory);
                    }, $QDcrLj ??= {"r":65537,"n":"","d":1415509,"h":0,"f":17825794}), 0, "SmartBeaconDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Beacon\\Models_SmartBeaconDeviceScopeModel_LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModelTypeDescriptorBuilder.g.cs", "SmartBeaconDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296382805)
            
            //--TRIMMABLE-BOUNDARY-START(12886317397)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886317397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886317397)
            
            //--TRIMMABLE-BOUNDARY-START(17181284693)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181284693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModel, LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings, LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModel, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceStatusHandler, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceHubClient, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181284693)
            
            //--TRIMMABLE-BOUNDARY-START(8591350101)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591350101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel)))
                {
                    /*var*/ let result = $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591350101)
            
            static $h = 1415509;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886317397),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1415509,
      "h": 12886317397,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886317397),
//--TRIMMABLE-BOUNDARY-START(17181284693),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1284437,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1415509,
      "h": 17181284693,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181284693),
//--TRIMMABLE-BOUNDARY-START(8591350101),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1284437,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1415509,
      "h": 8591350101,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591350101)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296382805),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1415509,
      "h": 4296382805,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296382805)
  ],
  "h": 1415509
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Models${separator}SmartBeaconDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1415509)
        
        

        //--TRIMMABLE-BOUNDARY-START(3643733)
        $asm.$cls(`$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor`, ($self) => class SmartBeaconDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298611029)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298611029);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor.GenerateProperties($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, this, factory);
                    }, $uUOMuh ??= {"r":65537,"n":"","d":3643733,"h":0,"f":17825794}), 0, "SmartBeaconDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Beacon\\Settings_SmartBeaconDeviceSettings_LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettingsTypeDescriptorBuilder.g.cs", "SmartBeaconDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298611029)
            
            //--TRIMMABLE-BOUNDARY-START(12888545621)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888545621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OnClick"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings.$type, $.$discardRef(), "OnClick", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OnClick")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$jjuN.LCIDBS$1.SmartBeaconClickCommand, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "OnClick";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$jjuN.LCIDBS$1.SmartBeaconClickCommand, ($.$cast(target, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings)).OnClick);
                        }, $rZkbce ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3643733,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.OnClick = value.AsEnumValue($.$jjuN.LCIDBS$1.SmartBeaconClickCommand);
                        }, $QcAJpi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3643733,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("RSSI"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings.$type, $.$discardRef(), "RSSI", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("RSSI")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "RSSI";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings)).RSSI);
                        }, $gttlBd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3643733,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.RSSI = value.AsDouble();
                        }, $jRJeej ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3643733,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Theme"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings.$type, $.$discardRef(), "Theme", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Theme")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$fPer.LCFC.WebColor, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Theme";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$fPer.LCFC.WebColor, ($.$cast(target, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings)).Theme);
                        }, $OHeJVf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3643733,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Theme = value.AsEnumValue($.$fPer.LCFC.WebColor);
                        }, $DuYCzi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3643733,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888545621)
            
            //--TRIMMABLE-BOUNDARY-START(17183512917)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183512917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceModel, LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings, LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.Beacon.Models.SmartBeaconDeviceSendDataModel, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceStatusHandler, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconDeviceHubClient, LivingThing.Core.IOT.Devices.Beacon.Services.ISmartBeaconRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _OnClick = _target.OnClick;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OnClick"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$jjuN.LCIDBS$1.SmartBeaconClickCommand));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$jjuN.LCIDBS$1.SmartBeaconClickCommand, () => _OnClick, ($v) => _OnClick = $v, null, true)))
                    {
                        _target.OnClick = _OnClick;
                    }
                }
                {
                    /*var*/ let _RSSI = _target.RSSI;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("RSSI"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _RSSI, ($v) => _RSSI = $v, $.$$.S.Double)))
                    {
                        _target.RSSI = _RSSI;
                    }
                }
                {
                    /*var*/ let _Theme = _target.Theme;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Theme"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$fPer.LCFC.WebColor));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$fPer.LCFC.WebColor, () => _Theme, ($v) => _Theme = $v, null, true)))
                    {
                        _target.Theme = _Theme;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183512917)
            
            //--TRIMMABLE-BOUNDARY-START(8593578325)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593578325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings)))
                {
                    /*var*/ let result = $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593578325)
            
            static $h = 3643733;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888545621),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3643733,
      "h": 12888545621,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888545621),
//--TRIMMABLE-BOUNDARY-START(17183512917),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3512661,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3643733,
      "h": 17183512917,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183512917),
//--TRIMMABLE-BOUNDARY-START(8593578325),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3512661,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3643733,
      "h": 8593578325,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593578325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298611029),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3643733,
      "h": 4298611029,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298611029)
  ],
  "h": 3643733
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Settings.SmartBeaconDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Settings${separator}SmartBeaconDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3643733)
        
        

        //--TRIMMABLE-BOUNDARY-START(3840341)
        $asm.$cls(`$jjuN.LCIDB.SmartBeaconDevice`, ($self) => class SmartBeaconDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$jjuN.LCIDBMS.SmartBeaconStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4298807637)
            $ctor$2(/*IIOTDeviceFamily<SmartBeaconDevice>*/ family, /*IIOTDeviceScope*/ scope, /*SmartBeaconDeviceModel*/ model)
            {
                super.$ctor$3(family, scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298807637);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298807637)
            
            //--TRIMMABLE-BOUNDARY-START(38658546005)
            /*IconDescriptor */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478676821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let icon = super.Icon;
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = this.Model$1.DeviceType !== 0/*IOTDeviceType.Others*/ ? $.$XBGm.LCIC.UtilityExtension.MaterialIcon(this.Model$1.DeviceType, this.IsAvailable) : icon.Icon;
                    $i1.Theme = $.$with(icon.Theme, ($clone) =>
                    {
                        $clone.ForegroundColor = this.IsAvailable ? "FFFF00" : "FFFFFF";
                    });
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(38658546005)
            
            //--TRIMMABLE-BOUNDARY-START(34363578709)
            /*Length */ GetDistance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363578709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$fPer.LCFCDM.Length().$ctor$3(Math.pow(10, (this.Settings$1.RSSI - this.Received.Frame.Beacon.LCFCBBI$IBeacon$Rssi) / (((10 * 2) | 0))), 1/*LengthUnitTypes.m*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34363578709)
            
            //--TRIMMABLE-BOUNDARY-START(42953513301)
            /*string */ get StatusText()
            {
                return this.GetDistance().ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(42953513301)
            
            //--TRIMMABLE-BOUNDARY-START(8593774933)
            /*Task */ Alarm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593774933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$jjuN.LCIDBPCV.SmartBeaconAlarmCommand, $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel, this, new $.$jjuN.LCIDBPCV.SmartBeaconAlarmCommand().$ctor$6(), new $.$jjuN.LCIDBMC.SmartBeaconAlarmControlModel().$ctor$2());
            }
            //--TRIMMABLE-BOUNDARY-END(8593774933)
            
            //--TRIMMABLE-BOUNDARY-START(12888742229)
            /*Task */ Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888742229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let on = (this.Received?.Status?.Status ?? null) ?? false;
                let $switch2 = this.Settings$1.OnClick;
                switch($switch2)
                {
                    case 1/*SmartBeaconClickCommand.Alarm*/:
                    return this.Alarm();
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12888742229)
            
            static $h = 3840341;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$jjuN.LCIDBMS.SmartBeaconStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38658546005),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478676821,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3840341,
      "h": 38658546005,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38658546005),
//--TRIMMABLE-BOUNDARY-START(42953513301),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068611413,
        "f": 50364417
      },
      "n": "StatusText",
      "d": 3840341,
      "h": 42953513301,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42953513301)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34363578709),
    {
      "r": 27298134,
      "n": "GetDistance",
      "d": 3840341,
      "h": 34363578709,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34363578709),
//--TRIMMABLE-BOUNDARY-START(8593774933),
    {
      "r": 178454529,
      "n": "Alarm",
      "d": 3840341,
      "h": 8593774933,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593774933),
//--TRIMMABLE-BOUNDARY-START(12888742229),
    {
      "r": 178454529,
      "n": "Clicked",
      "d": 3840341,
      "h": 12888742229,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12888742229)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298807637),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$jjuN.LCIDB.SmartBeaconDevice).$h
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 760149
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3840341,
      "h": 4298807637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298807637)
  ],
  "h": 3840341
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.SmartBeaconDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}SmartBeaconDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3840341)
        
        

        //--TRIMMABLE-BOUNDARY-START(3905877)
        $asm.$cls(`$jjuN.LCIDB.SmartBeaconDeviceDefinition`, ($self) => class SmartBeaconDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$jjuN.LCIDBMS.SmartBeaconStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298873173)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298873173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298873173)
            
            //--TRIMMABLE-BOUNDARY-START(4298873173)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298873173)
            
            static $h = 3905877;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$jjuN.LCIDBMS.SmartBeaconStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298873173),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3905877,
      "h": 4298873173,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298873173)
  ],
  "h": 3905877
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.SmartBeaconDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}SmartBeaconDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3905877)
        
        

        //--TRIMMABLE-BOUNDARY-START(3971413)
        $asm.$cls(`$jjuN.LCIDB.SmartBeaconDeviceFamily`, ($self) => class SmartBeaconDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4298938709)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SmartBeaconDeviceReceivedDataModel, SmartBeaconDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SmartBeaconDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298938709);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298938709)
            
            //--TRIMMABLE-BOUNDARY-START(8593906005)
            /*Type */ get DeviceBroadcastSendMessageEnumType()
            {
                return $.$jjuN.LCIDBS$1.SmartBeaconBroadcastPeerMessages.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8593906005)
            
            static $h = 3971413;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBM.SmartBeaconServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$jjuN.LCIDBM.SmartBeaconDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$jjuN.LCIDBM.SmartBeaconDeviceModel, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel, $.$jjuN.LCIDBS.ISmartBeaconDeviceStatusHandler, $.$jjuN.LCIDBS.ISmartBeaconDeviceHubClient, $.$jjuN.LCIDBS.ISmartBeaconRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593906005),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183840597,
        "f": 50364417
      },
      "n": "DeviceBroadcastSendMessageEnumType",
      "d": 3971413,
      "h": 8593906005,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593906005)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298938709),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3971413,
      "h": 4298938709,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298938709)
  ],
  "h": 3971413
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$jjuN.LCIDB.SmartBeaconDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.SmartBeaconDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}SmartBeaconDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3971413)
        
        

        //--TRIMMABLE-BOUNDARY-START(4168021)
        $asm.$cls(`$jjuN.LCIDBV.BeaconMap`, ($self) => class BeaconMap extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$$.SCG.IEnumerable$$($.$jjuN.LCIDB.SmartBeaconDevice))
        {
            //--TRIMMABLE-BOUNDARY-START(51543775573)
            /*string */ get OptimizedComponentName()
            {
                return "beaconmap";
            }
            //--TRIMMABLE-BOUNDARY-END(51543775573)
            
            //--TRIMMABLE-BOUNDARY-START(47248808277)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248808277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.Bluetooth = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$lOHy.LCFCBBI.IBeaconAdvertiser, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(47248808277)
            
            //--TRIMMABLE-BOUNDARY-START(21479004501)
            /*IBeaconAdvertiser*/ Bluetooth = null;
            //--TRIMMABLE-BOUNDARY-END(21479004501)
            
            //--TRIMMABLE-BOUNDARY-START(17184037205)
            /*double */ BatteryVoltage(/*SmartBeaconDevice*/ beacon)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184037205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let dat = $.$sl.SL.Enumerable.First$1($.$lOHy.LCFCBBM.BLEManufacturerData, beacon.Received.Frame.Beacon.LCFCBBI$IBeacon$LastPacket.Advertisement.ManufacturerData).Data;
                return $.$sl.SL.Enumerable.Last$1($.$$.S.Byte, dat) / 10;
            }
            //--TRIMMABLE-BOUNDARY-END(17184037205)
            
            //--TRIMMABLE-BOUNDARY-START(12889069909)
            /*void */ Alert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889069909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CancellationTokenSource*/ let src = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                src.CancelAfter(5000);
                this.Bluetooth.LCFCBBI$IBeaconAdvertiser$StartAdvertisement((() =>
                {
                    //new $.$lOHy.LCFCBBM.BLEAdvertisementPacket()
                    const $t1 = $.$lOHy.LCFCBBM.BLEAdvertisementPacket;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Advertisement = (() =>
                    {
                        //new $.$lOHy.LCFCBBM.BeaconAdvertisement()
                        const $t2 = $.$lOHy.LCFCBBM.BeaconAdvertisement;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ManufacturerData = (() =>
                        {
                            //new $.$$.SCG.List$$($.$lOHy.LCFCBBM.BLEManufacturerData)()
                            const $t3 = $.$$.SCG.List$$($.$lOHy.LCFCBBM.BLEManufacturerData);
                            const $i3 = new $t3();
                            $i3.$ctor$1();
                            $i3.Add((() =>
                            {
                                //new $.$lOHy.LCFCBBM.BLEManufacturerData()
                                const $t4 = $.$lOHy.LCFCBBM.BLEManufacturerData;
                                const $i4 = new $t4();
                                $i4.$ctor$2();
                                $i4.CompanyId = 65534;
                                $i4.Data = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [37, 244, 163, 222, 168, 251], [-1], null);
                                return $i4;
                            })());
                            return $i3;
                        })();
                        return $i2;
                    })();
                    return $i1;
                })(), src.Token);
            }
            //--TRIMMABLE-BOUNDARY-END(12889069909)
            
            //--TRIMMABLE-BOUNDARY-START(25773971797)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773971797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCT$4.Themable, 0);
                __builder.AddAttribute$3(1, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors)))().$ctor(this, ( (/*theme*/ theme) =>
                {
                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                    {
                        /*var*/ let builder = $.$hDPm.LCFCCSF.SVGBuilder.Create(100, 100, 0, true, 0, 0);
                        for(/*int*/ let i = 1; i < 10; i++)
                        {
                            builder.LCFCCSF$ISVGBuilder$MoveTo(0.5, 1).LCFCCSF$ISVGCircleBuilder$Circle($.$hDPm.LCFCC$1.Dimension.op_Implicit(1 * ((((i + 1) | 0)) / 10))).LCFCCSF$ISVGBuilder$StrokeColor(`#${$.$strNN($.$$.S.String.Trim$1.call(theme.Model.TertiaryForegroundColor, /*#*/ 35))}${$.$strNN(((10 - i) | 0))}0`).LCFCCSF$ISVGBuilder$StrokeWidth(1).LCFCCSF$ISVGBuilder$FillColor("#00000010");
                        }
                        __builder2.OpenElement(2, "div");
                        __builder2.AddAttribute$5(3, "class", "pos-rel mgt");
                        __builder2.AddContent$1(4, builder.LCFCCSF$ISVGBuilder$Build());
                        __builder2.AddMarkupContent(5, "\r\n        ");
                        __builder2.AddMarkupContent(6, "<div class=\"pos-abs b-0 l-0 r-0 flex\"><div class=\"mg-a text-center\"><i class=\"mdi mdi-account fsz-50\"></i>\r\n                <b class=\"d-block\">Me</b></div></div>");
                        /*int*/ let ii = 0;
                        let $en5 = $.$sl.SL.Enumerable.Where($.$jjuN.LCIDB.SmartBeaconDevice, this.ViewModel, new ($.$$.S.Func$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$$.S.Boolean))().$ctor(this,  (/*b*/ b) =>
                        {
                            return b.IsAvailable;
                        }, $wEsPvj ??= {"r":262145,"p":[{"n":"b","p":3840341}],"n":"","d":4168021,"h":0,"f":17825794})).SCG$IEnumerable$$$GetEnumerator();
                        while ($en5.SC$1$IEnumerator$MoveNext())
                        {
                            let beacon = $en5.SCG$IEnumerator$$$Current;
                            {
                                /*var*/ let distance = beacon.GetDistance();
                                /*var*/ let bottom = distance.M * 100 / 10;
                                if (bottom > 100)
                                {
                                    bottom = 100;
                                }
                                __builder2.OpenElement(7, "div");
                                __builder2.AddAttribute$5(8, "class", "pos-abs text-center");
                                __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 9, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.Alert)));
                                __builder2.AddAttribute$5(10, "style", `bottom:${$.$strNN(bottom)}%;left:${$.$strNN(((30 + (((((((ii & 1) === 1 ? 1 : -1) * ii) | 0) * 9) | 0))) | 0))}%;transition:bottom ease-in 0.5s`);
                                __builder2.OpenElement(11, "h3");
                                __builder2.AddAttribute$5(12, "class", "mg-0");
                                __builder2.AddContent$4(13, (() =>
                                {
                                    var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(3, 3);
                                    $handler.AppendFormatted($.$box(beacon.Name, $.$$.S.String), null, null);
                                    $handler.AppendLiteral(" (");
                                    $handler.AppendFormatted($.$box(this.BatteryVoltage(beacon), $.$$.S.Double), null, null);
                                    $handler.AppendLiteral("V, ");
                                    $handler.AppendFormatted($.$box(beacon.Received.Frame.Beacon.LCFCBBI$IBeacon$Rssi, $.$$.S.Double), null, "f");
                                    $handler.AppendLiteral("db)");
                                    return $handler.ToStringAndClear                            ();
                                })());
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(14, "\r\n                ");
                                __builder2.OpenElement(15, "div");
                                __builder2.AddAttribute$5(16, "class", "mg-a hx-05 wx-05 bd flex round shadow");
                                __builder2.AddAttribute$5(17, "style", "background-color:" + $.$strNN(($.$$.S.Enum.ToStringT($.$fPer.LCFC.WebColor, $.$$.S.UInt32, beacon.Settings$1.Theme))));
                                __builder2.AddMarkupContent(18, "<i class=\"mdi mdi-diamond-stone fsz-30 mg-a flex mgc-a\"></i>");
                                __builder2.CloseElement();
                                __builder2.AddMarkupContent(19, "\r\n                ");
                                __builder2.OpenElement(20, "h4");
                                __builder2.AddAttribute$5(21, "class", "mg-0");
                                __builder2.AddContent$4(22, "~");
                                __builder2.AddContent$3(23, $.$clone(distance));
                                __builder2.AddContent$4(24, " away");
                                __builder2.CloseElement();
                                __builder2.CloseElement();
                            }
                        }
                        __builder2.CloseElement();
                        if ($.$sl.SL.Enumerable.Any($.$jjuN.LCIDB.SmartBeaconDevice, this.ViewModel, new ($.$$.S.Func$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$$.S.Boolean))().$ctor(this,  (/*v*/ v) =>
                        {
                            return !v.IsAvailable;
                        }, $RslKDe ??= {"r":262145,"p":[{"n":"v","p":3840341}],"n":"","d":4168021,"h":0,"f":17825794})))
                        {
                            __builder2.OpenElement(25, "div");
                            __builder2.AddAttribute$5(26, "class", "pd");
                            __builder2.AddMarkupContent(27, "<h2>Out of range</h2>\r\n            ");
                            $.$jjuN._LCIDBVB.TypeInference.CreateDataList_0($.$jjuN.LCIDB.SmartBeaconDevice, __builder2, 28, 29, $.$sl.SL.Enumerable.Where($.$jjuN.LCIDB.SmartBeaconDevice, this.ViewModel, new ($.$$.S.Func$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$$.S.Boolean))().$ctor(this,  (/*v*/ v) =>
                            {
                                return !v.IsAvailable;
                            }, $NijAde ??= {"r":262145,"p":[{"n":"v","p":3840341}],"n":"","d":4168021,"h":0,"f":17825794})), 30, 35184372092928n | 33554432n, 31, "ListVisualization.CarouselHorizontalView", 32, 2, 33, new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$jjuN.LCIDB.SmartBeaconDevice))))().$ctor(this,  (/*beacon*/ beacon) =>
                            {
                                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                                {
                                    __builder3.OpenElement(34, "div");
                                    __builder3.AddAttribute$5(35, "class", "text-center");
                                    __builder3.AddAttribute$7($.$macw.MACW.MouseEventArgs, 36, "onclick", $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.Alert)));
                                    __builder3.OpenElement(37, "h3");
                                    __builder3.AddAttribute$5(38, "class", "mgt-0 mgb-1");
                                    __builder3.AddContent$4(39, beacon.Model.Name);
                                    __builder3.CloseElement();
                                    __builder3.AddMarkupContent(40, "\r\n                    ");
                                    __builder3.OpenElement(41, "div");
                                    __builder3.AddAttribute$5(42, "class", "hx-07 wx-07 bd flex round shadow");
                                    __builder3.AddAttribute$5(43, "style", "background-color:" + $.$strNN(($.$$.S.Enum.ToStringT($.$fPer.LCFC.WebColor, $.$$.S.UInt32, beacon.Model.Settings$1.Theme))));
                                    __builder3.AddMarkupContent(44, "<i class=\"mdi mdi-diamond-stone fsz-40 mg-a flex mgc-a\"></i>");
                                    __builder3.CloseElement();
                                    __builder3.CloseElement();
                                }, $POKkVf ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":4168021,"h":0,"f":17825794});
                            }, $KtSpck ??= {"r":6881395,"p":[{"n":"beacon","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$jjuN.LCIDB.SmartBeaconDevice)).$h}],"n":"","d":4168021,"h":0,"f":17825794}));
                            __builder2.CloseElement();
                        }
                    }, $ECcTQe ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":4168021,"h":0,"f":17825794});
                }), $kNClic ??= {"r":6881395,"p":[{"n":"theme","p":$.$hDPm.LCFCI.ContainerContext$$($.$vWqU.LCFCC.ThemeColors).$h}],"n":"","d":4168021,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(25773971797)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8594102613)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594102613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594102613)
            
            //--TRIMMABLE-BOUNDARY-START(8594102613)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8594102613)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21479004501)
                this.Bluetooth = null;
                //--TRIMMABLE-BOUNDARY-END(21479004501)
                
            }
            static $h = 4168021;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$$.SCG.IEnumerable$$($.$jjuN.LCIDB.SmartBeaconDevice)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51543775573),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953840981,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 4168021,
      "h": 51543775573,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51543775573),
//--TRIMMABLE-BOUNDARY-START(21479004501),
    {
      "p": 187873,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363906389,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60133710165,
        "f": 83886081
      },
      "n": "Bluetooth",
      "d": 4168021,
      "h": 21479004501,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21479004501)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47248808277),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 4168021,
      "h": 47248808277,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47248808277),
//--TRIMMABLE-BOUNDARY-START(17184037205),
    {
      "r": 1179649,
      "p": [
        {
          "n": "beacon",
          "p": 3840341
        }
      ],
      "n": "BatteryVoltage",
      "d": 4168021,
      "h": 17184037205,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17184037205),
//--TRIMMABLE-BOUNDARY-START(12889069909),
    {
      "r": 65537,
      "n": "Alert",
      "d": 4168021,
      "h": 12889069909,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12889069909),
//--TRIMMABLE-BOUNDARY-START(25773971797),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4168021,
      "h": 25773971797,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25773971797)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594102613),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4168021,
      "h": 8594102613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594102613)
  ],
  "h": 4168021
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Views.BeaconMap`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Views${separator}BeaconMap`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4168021)
        
        

        //--TRIMMABLE-BOUNDARY-START(2398549)
        $asm.$cls(`$jjuN.LCIDBP.BeaconMessageDecoder`, ($self) => class BeaconMessageDecoder extends $.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8592333141)
            /*SmartBeaconDeviceReceivedDataModel */ Decode(/*IConnectionMessage*/ message, /*IIOTDevice*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592333141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let frame = $.$cast(message, $.$XBGm.LCICB.BeaconFrameBase);
                return (() =>
                {
                    //new $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel()
                    const $t1 = $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel;
                    const $i1 = new $t1();
                    $i1.$ctor$4();
                    $i1.Frame = frame;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(8592333141)
            
            //--TRIMMABLE-BOUNDARY-START(4297365845)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297365845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297365845)
            
            //--TRIMMABLE-BOUNDARY-START(4297365845)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297365845)
            
            static $h = 2398549;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592333141),
    {
      "r": 1022293,
      "p": [
        {
          "n": "message",
          "p": 1961646
        },
        {
          "n": "device",
          "p": 25925009,
          "f": 65
        }
      ],
      "n": "Decode",
      "d": 2398549,
      "h": 8592333141,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8592333141)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297365845),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2398549,
      "h": 4297365845,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297365845)
  ],
  "h": 2398549
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolDecoder$$($.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceProtocolDecoder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Protocol.BeaconMessageDecoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Protocol${separator}BeaconMessageDecoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2398549)
        
        

        //--TRIMMABLE-BOUNDARY-START(4364629)
        $asm.$cls(`$jjuN.LCIDBV.SmartBeaconViewRenderer`, ($self) => class SmartBeaconViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299331925)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299331925);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299331925)
            
            //--TRIMMABLE-BOUNDARY-START(8594299221)
            /*RenderFragment? */ GetView(/*IClientUnitOfWork*/ ui, /*SmartBeaconDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>?*/ clicked, /*Func<Task>?*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594299221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$jjuN.LCIDBV.SmartBeaconDeviceDetails, $.$jjuN.LCIDBV.SmartBeaconDetailsViewModel, new $.$jjuN.LCIDBV.SmartBeaconDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8594299221)
            
            static $h = 4364629;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594299221),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 3840341
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 4364629,
      "h": 8594299221,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8594299221)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299331925),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4364629,
      "h": 4299331925,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299331925)
  ],
  "h": 4364629
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$jjuN.LCIDB.SmartBeaconDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Views.SmartBeaconViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Views${separator}SmartBeaconViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4364629)
        
        

        //--TRIMMABLE-BOUNDARY-START(4233557)
        $asm.$cls(`$jjuN.LCIDBV.SmartBeaconDetailsViewModel`, ($self) => class SmartBeaconDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299200853)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*SmartBeaconDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299200853);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299200853)
            
            static $h = 4233557;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$jjuN.LCIDB.SmartBeaconDevice, $.$jjuN.LCIDBS$1.SmartBeaconDeviceSettings, $.$jjuN.LCIDBS$1.SmartBeaconDeviceHardwareSettings, $.$jjuN.LCIDBM.SmartBeaconDeviceReceivedDataModel, $.$jjuN.LCIDBM.SmartBeaconDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299200853),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 3840341
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 4233557,
      "h": 4299200853,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299200853)
  ],
  "h": 4233557
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Views.SmartBeaconDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Views${separator}SmartBeaconDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4233557)
        
        

        //--TRIMMABLE-BOUNDARY-START(4299093)
        $asm.$cls(`$jjuN.LCIDBV.SmartBeaconDeviceDetails`, ($self) => class SmartBeaconDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$jjuN.LCIDBV.SmartBeaconDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51543906645)
            /*SmartBeaconDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51543906645)
            
            //--TRIMMABLE-BOUNDARY-START(34364037461)
            /*string */ get OptimizedComponentName()
            {
                return "smartbeacondevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(34364037461)
            
            //--TRIMMABLE-BOUNDARY-START(47248939349)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248939349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$jjuN.LCIDBV.SmartBeaconDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47248939349)
            
            //--TRIMMABLE-BOUNDARY-START(12889200981)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889200981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$jjuN.LCIDB.SmartBeaconDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$jjuN.LCIDB.SmartBeaconDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$jjuN.LCIDBV.BeaconMap, 3);
                    __builder2.AddComponentParameter(4, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$jjuN.LCIDB.SmartBeaconDevice), this.ViewModel.Device$1.OwnerScope.LCICI$IIOTDeviceScope$Devices.Where(new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$$.S.Boolean))().$ctor(this,  (/**/ d) =>
                    {
                        return $.$is(d, $.$jjuN.LCIDB.SmartBeaconDevice);
                    }, $SRpAxf ??= {"r":262145,"p":[{"n":"d","p":25925009}],"n":"","d":4299093,"h":0,"f":17825794})).Select$1($.$jjuN.LCIDB.SmartBeaconDevice, new ($.$$.S.Func$$$($.$XBGm.LCICI.IIOTDevice, $.$jjuN.LCIDB.SmartBeaconDevice))().$ctor(this,  (/*d*/ d) =>
                    {
                        return $.$cast(d, $.$jjuN.LCIDB.SmartBeaconDevice);
                    }, $GZXWRh ??= {"r":3840341,"p":[{"n":"d","p":25925009}],"n":"","d":4299093,"h":0,"f":17825794}))));
                    __builder2.CloseComponent();
                }), $qdTRQb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":4299093,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12889200981)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8594233685)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594233685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594233685)
            
            //--TRIMMABLE-BOUNDARY-START(8594233685)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8594233685)
            
            static $h = 4299093;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$jjuN.LCIDBV.SmartBeaconDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51543906645),
    {
      "p": 4233557,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069070165,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42953972053,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 4299093,
      "h": 51543906645,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51543906645),
//--TRIMMABLE-BOUNDARY-START(34364037461),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479135573,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 4299093,
      "h": 34364037461,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34364037461)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47248939349),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 4299093,
      "h": 47248939349,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47248939349),
//--TRIMMABLE-BOUNDARY-START(12889200981),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4299093,
      "h": 12889200981,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12889200981)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594233685),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4299093,
      "h": 8594233685,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594233685)
  ],
  "h": 4299093
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Beacon.Views.SmartBeaconDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Beacon${separator}Views${separator}SmartBeaconDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4299093)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(39253)
