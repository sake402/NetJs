
//--TRIMMABLE-BOUNDARY-START(26531)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $HjvUIf;
    let $TreOyg;
    let $bMhNSe;
    let $TvOCzc;
    let $AqDyqg;
    let $BcaWpj;
    let $bhEowk;
    let $nXAMMb;
    let $CyxBla;
    let $fXcEKh;
    let $cJFomc;
    let $qJVlcj;
    let $zvUUFc;
    let $Ntleee;
    let $ylrGVd;
    let $fvIwZb;
    let $Pckacb;
    let $VwtOZd;
    let $TUcAPk;
    let $btmTZg;
    let $yxIpYd;
    let $OHMTCg;
    let $XLRqKa;
    let $WJIoGb;
    let $yedGwk;
    let $YJlvia;
    let $knONGi;
    let $jKhEhl;
    let $bhZBPi;
    let $nfizSa;
    let $VuErPa;
    let $wYeaWe;
    let $SQgYdl;
    let $VYIVqb;
    let $uEiOGc;
    let $hMxLtc;
    let $bxAjGd;
    let $LMsCVi;
    let $ZeAfik;
    let $CSHcWd;
    let $KsRBui;
    let $kSNtXg;
    let $FArDWc;
    let $GPIZmi;
    let $oJhECb;
    let $mZAkwk;
    let $DRVAQj;
    let $SimJhl;
    let $bYaBXg;
    let $AuzfYh;
    let $uhwkId;
    let $lJTtPb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.CowVitals", 
    {
  "h": 26531,
  "f": "LivingThing.Core.IOT.Devices.CowVitals",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.CowVitals",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.CowVitals",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5Db3dWaXRhbHMuU21hcnRDb3dWaXRhbHNEZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIkNvd1ZpdGFscyIgXSwNCiAgICAgICJOYW1lIjogIlNtYXJ0IENvd1ZpdGFscyIsDQogICAgICAiQWxpYXNlcyI6ICJDb3dWaXRhbHMiLA0KICAgICAgIkRlc2NyaXB0aW9uIjogIkNvdyBUcmFja2luZyBhbmQgVml0YWxzIE1vbml0b3JpbmciLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vaW1nL2Nvdy5qcGciLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktZWxlY3RyaWMtc3dpdGNoIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q3N2JiYSIsDQogICAgICAiU2VjdXJpdGllcyI6ICJDaGFsbGVuZ2VIYW5kU2hha2VBdXRoZW50aWNhdGlvblByb3RvY29sLEFkdmFuY2VkRW5jcnlwdGlvblN0YW5kYXJkLEVsbGlwdGljQ3VydmVGaXJtd2FyZVVwZGF0ZVNpZ25pbmciDQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2385827)
        $asm.$cls(`$ezfM.LCIDC.NavigationMenuBuilder`, ($self) => class NavigationMenuBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592320419)
            static /*void */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592320419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$hDPm.LCFCL.NavigationMenu.Register$1($.$ezfM.LCIDCV.CowVitals, "LivingThing.Core.IOT.Devices.CowVitals", "Views\\CowVitals", "Cow Vitals", $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "/CowVitals" ], null, null), null);
            }
            //--TRIMMABLE-BOUNDARY-END(8592320419)
            
            //--TRIMMABLE-BOUNDARY-START(4297353123)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297353123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297353123)
            
            //--TRIMMABLE-BOUNDARY-START(4297353123)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297353123)
            
            static $h = 2385827;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592320419),
    {
      "r": 65537,
      "n": "Build",
      "d": 2385827,
      "h": 8592320419,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592320419)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297353123),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2385827,
      "h": 4297353123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297353123)
  ],
  "h": 2385827
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.NavigationMenuBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}NavigationMenuBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2385827)
        
        

        //--TRIMMABLE-BOUNDARY-START(1599395)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsDeviceModelCustomAttributesProvider`, ($self) => class SmartCowVitalsDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296566691)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296566691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296566691)
            
            static $h = 1599395;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296566691),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1599395,
      "h": 4296566691,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296566691)
  ],
  "h": 1599395
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1599395)
        
        

        //--TRIMMABLE-BOUNDARY-START(223139)
        $asm.$cls(`$ezfM.LCIDC._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295190435)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295190435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$ezfM.LCIDC.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295190435)
            
            static $h = 223139;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295190435),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 223139,
      "h": 4295190435,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295190435)
  ],
  "h": 223139
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(223139)
        
        

        //--TRIMMABLE-BOUNDARY-START(2123683)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsServiceModelCustomAttributesProvider`, ($self) => class SmartCowVitalsServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297090979)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297090979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297090979)
            
            static $h = 2123683;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297090979),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2123683,
      "h": 4297090979,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297090979)
  ],
  "h": 2123683
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2123683)
        
        

        //--TRIMMABLE-BOUNDARY-START(1009571)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModelCustomAttributesProvider`, ($self) => class SmartCowVitalsDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295976867)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295976867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceSendDataModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295976867)
            
            static $h = 1009571;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295976867),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1009571,
      "h": 4295976867,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295976867)
  ],
  "h": 1009571
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1009571)
        
        

        //--TRIMMABLE-BOUNDARY-START(3565475)
        $asm.$cls(`$ezfM.LCIDC.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298532771)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298532771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$ezfM.LCIDCC.SmartCowVitalsCommandsModelTypeDescriptorBuilder.Register();
                $.$ezfM.LCIDCM.SmartCowVitalsDeviceModelTypeDescriptorBuilder.Register();
                $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$ezfM.LCIDCM.SmartCowVitalsServiceModelTypeDescriptorBuilder.Register();
                $.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptorBuilder.Register();
                $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298532771)
            
            static $h = 3565475;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298532771),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3565475,
      "h": 4298532771,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298532771)
  ],
  "h": 3565475
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3565475)
        
        

        //--TRIMMABLE-BOUNDARY-START(878499)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SmartCowVitalsDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590813091)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590813091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $TreOyg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":878499,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590813091)
            
            //--TRIMMABLE-BOUNDARY-START(4295845795)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295845795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295845795)
            
            //--TRIMMABLE-BOUNDARY-START(4295845795)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295845795)
            
            static $h = 878499;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590813091),
    {
      "r": 65537,
      "n": "Register",
      "d": 878499,
      "h": 8590813091,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590813091)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295845795),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 878499,
      "h": 4295845795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295845795)
  ],
  "h": 878499
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(878499)
        
        

        //--TRIMMABLE-BOUNDARY-START(2910115)
        $asm.$cls(`$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SmartCowVitalsDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592844707)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592844707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $BcaWpj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2910115,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592844707)
            
            //--TRIMMABLE-BOUNDARY-START(4297877411)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297877411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297877411)
            
            //--TRIMMABLE-BOUNDARY-START(4297877411)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297877411)
            
            static $h = 2910115;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592844707),
    {
      "r": 65537,
      "n": "Register",
      "d": 2910115,
      "h": 8592844707,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592844707)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297877411),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2910115,
      "h": 4297877411,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297877411)
  ],
  "h": 2910115
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Settings${separator}SmartCowVitalsDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2910115)
        
        

        //--TRIMMABLE-BOUNDARY-START(3041187)
        $asm.$cls(`$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettingsCustomAttributesProvider`, ($self) => class SmartCowVitalsDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298008483)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298008483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298008483)
            
            static $h = 3041187;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298008483),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3041187,
      "h": 4298008483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298008483)
  ],
  "h": 3041187
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Settings${separator}SmartCowVitalsDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3041187)
        
        

        //--TRIMMABLE-BOUNDARY-START(1468323)
        $asm.$cls(`$ezfM.LCIDC.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4296435619)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296435619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ezfM.LCIDCC.SmartCowVitalsCommandsModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ezfM.LCIDCC.SmartCowVitalsCommandsModelCustomAttributesProvider, $.$ezfM.LCIDCC.SmartCowVitalsCommandsModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ezfM.LCIDCM.SmartCowVitalsDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ezfM.LCIDCM.SmartCowVitalsDeviceModelCustomAttributesProvider, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModelCustomAttributesProvider, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModelCustomAttributesProvider, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModelCustomAttributesProvider, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ezfM.LCIDCM.SmartCowVitalsServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ezfM.LCIDCM.SmartCowVitalsServiceModelCustomAttributesProvider, $.$ezfM.LCIDCM.SmartCowVitalsServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelCustomAttributesProvider, $.$ezfM.LCIDCD.SmartCowVitalsStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettingsCustomAttributesProvider, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettingsCustomAttributesProvider, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4296435619)
            
            static $h = 1468323;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296435619),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 1468323,
      "h": 4296435619,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296435619)
  ],
  "h": 1468323
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1468323)
        
        

        //--TRIMMABLE-BOUNDARY-START(354211)
        $asm.$cls(`$ezfM.LCIDCC.SmartCowVitalsCommandsModelCustomAttributesProvider`, ($self) => class SmartCowVitalsCommandsModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295321507)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295321507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295321507)
            
            static $h = 354211;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295321507),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 354211,
      "h": 4295321507,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295321507)
  ],
  "h": 354211
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Commands.SmartCowVitalsCommandsModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Commands${separator}SmartCowVitalsCommandsModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(354211)
        
        

        //--TRIMMABLE-BOUNDARY-START(1140643)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SmartCowVitalsDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591075235)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591075235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $TvOCzc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1140643,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591075235)
            
            //--TRIMMABLE-BOUNDARY-START(4296107939)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296107939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296107939)
            
            //--TRIMMABLE-BOUNDARY-START(4296107939)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296107939)
            
            static $h = 1140643;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591075235),
    {
      "r": 65537,
      "n": "Register",
      "d": 1140643,
      "h": 8591075235,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591075235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296107939),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1140643,
      "h": 4296107939,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296107939)
  ],
  "h": 1140643
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1140643)
        
        

        //--TRIMMABLE-BOUNDARY-START(747427)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SmartCowVitalsDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295714723)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295714723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$ezfM.LCIDCD.SmartCowVitalsStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295714723)
            
            static $h = 747427;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295714723),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 747427,
      "h": 4295714723,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295714723)
  ],
  "h": 747427
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(747427)
        
        

        //--TRIMMABLE-BOUNDARY-START(1271715)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsStatusModelCustomAttributesProvider`, ($self) => class SmartCowVitalsStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296239011)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296239011)
            
            //--TRIMMABLE-BOUNDARY-START(8591206307)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591206307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$ezfM.LCIDCD.SmartCowVitalsStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(10, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("AmbientTemperature", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BodyTemperature", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("X", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Y", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (4);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Z", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (5);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("BreathInterval", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (6);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Latitude", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Order = (7);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Longitude", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Order = (8);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Course", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Order = (9);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Speed", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t12 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$4();
                            $i12.Order = (10);
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$ezfM.LCIDCD.SmartCowVitalsStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $Pckacb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1271715,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $VwtOZd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1271715,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591206307)
            
            static $h = 1271715;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591206307),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1271715,
      "h": 8591206307,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591206307)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296239011),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1271715,
      "h": 4296239011,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296239011)
  ],
  "h": 1271715
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1271715)
        
        

        //--TRIMMABLE-BOUNDARY-START(485283)
        $asm.$cls(`$ezfM.LCIDCC.SmartCowVitalsCommandsModelTypeDescriptorBuilder`, ($self) => class SmartCowVitalsCommandsModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590419875)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590419875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ezfM.LCIDCC.SmartCowVitalsCommandsModelTypeDescriptor()
                        const $t1 = $.$ezfM.LCIDCC.SmartCowVitalsCommandsModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.CowVitals.Commands.SmartCowVitalsCommandsModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $nXAMMb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":485283,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ezfM.LCIDCC.SmartCowVitalsCommandsModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590419875)
            
            //--TRIMMABLE-BOUNDARY-START(4295452579)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295452579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295452579)
            
            //--TRIMMABLE-BOUNDARY-START(4295452579)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295452579)
            
            static $h = 485283;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590419875),
    {
      "r": 65537,
      "n": "Register",
      "d": 485283,
      "h": 8590419875,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590419875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295452579),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 485283,
      "h": 4295452579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295452579)
  ],
  "h": 485283
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Commands.SmartCowVitalsCommandsModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Commands${separator}SmartCowVitalsCommandsModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(485283)
        
        

        //--TRIMMABLE-BOUNDARY-START(2254755)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsServiceModelTypeDescriptorBuilder`, ($self) => class SmartCowVitalsServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592189347)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592189347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ezfM.LCIDCM.SmartCowVitalsServiceModelTypeDescriptor()
                        const $t1 = $.$ezfM.LCIDCM.SmartCowVitalsServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $fXcEKh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2254755,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ezfM.LCIDCM.SmartCowVitalsServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592189347)
            
            //--TRIMMABLE-BOUNDARY-START(4297222051)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297222051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297222051)
            
            //--TRIMMABLE-BOUNDARY-START(4297222051)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297222051)
            
            static $h = 2254755;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592189347),
    {
      "r": 65537,
      "n": "Register",
      "d": 2254755,
      "h": 8592189347,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592189347)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297222051),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2254755,
      "h": 4297222051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297222051)
  ],
  "h": 2254755
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2254755)
        
        

        //--TRIMMABLE-BOUNDARY-START(1861539)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModelCustomAttributesProvider`, ($self) => class SmartCowVitalsDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296828835)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296828835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296828835)
            
            static $h = 1861539;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296828835),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1861539,
      "h": 4296828835,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296828835)
  ],
  "h": 1861539
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1861539)
        
        

        //--TRIMMABLE-BOUNDARY-START(1992611)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SmartCowVitalsDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591927203)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591927203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $TUcAPk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1992611,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591927203)
            
            //--TRIMMABLE-BOUNDARY-START(4296959907)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296959907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296959907)
            
            //--TRIMMABLE-BOUNDARY-START(4296959907)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296959907)
            
            static $h = 1992611;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591927203),
    {
      "r": 65537,
      "n": "Register",
      "d": 1992611,
      "h": 8591927203,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591927203)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296959907),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1992611,
      "h": 4296959907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296959907)
  ],
  "h": 1992611
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1992611)
        
        

        //--TRIMMABLE-BOUNDARY-START(1402787)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptorBuilder`, ($self) => class SmartCowVitalsStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591337379)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591337379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor()
                        const $t1 = $.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $yedGwk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1402787,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591337379)
            
            //--TRIMMABLE-BOUNDARY-START(4296370083)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296370083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296370083)
            
            //--TRIMMABLE-BOUNDARY-START(4296370083)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296370083)
            
            static $h = 1402787;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591337379),
    {
      "r": 65537,
      "n": "Register",
      "d": 1402787,
      "h": 8591337379,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591337379)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296370083),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1402787,
      "h": 4296370083,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296370083)
  ],
  "h": 1402787
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1402787)
        
        

        //--TRIMMABLE-BOUNDARY-START(1730467)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsDeviceModelTypeDescriptorBuilder`, ($self) => class SmartCowVitalsDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591665059)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591665059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ezfM.LCIDCM.SmartCowVitalsDeviceModelTypeDescriptor()
                        const $t1 = $.$ezfM.LCIDCM.SmartCowVitalsDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $yxIpYd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1730467,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ezfM.LCIDCM.SmartCowVitalsDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591665059)
            
            //--TRIMMABLE-BOUNDARY-START(4296697763)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296697763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296697763)
            
            //--TRIMMABLE-BOUNDARY-START(4296697763)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296697763)
            
            static $h = 1730467;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591665059),
    {
      "r": 65537,
      "n": "Register",
      "d": 1730467,
      "h": 8591665059,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591665059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296697763),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1730467,
      "h": 4296697763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296697763)
  ],
  "h": 1730467
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1730467)
        
        

        //--TRIMMABLE-BOUNDARY-START(2779043)
        $asm.$cls(`$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SmartCowVitalsDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297746339)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297746339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297746339)
            
            static $h = 2779043;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297746339),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2779043,
      "h": 4297746339,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297746339)
  ],
  "h": 2779043
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Settings${separator}SmartCowVitalsDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2779043)
        
        

        //--TRIMMABLE-BOUNDARY-START(3172259)
        $asm.$cls(`$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettingsTypeDescriptorBuilder`, ($self) => class SmartCowVitalsDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593106851)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593106851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettingsTypeDescriptor()
                        const $t1 = $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $XLRqKa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3172259,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593106851)
            
            //--TRIMMABLE-BOUNDARY-START(4298139555)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298139555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298139555)
            
            //--TRIMMABLE-BOUNDARY-START(4298139555)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298139555)
            
            static $h = 3172259;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593106851),
    {
      "r": 65537,
      "n": "Register",
      "d": 3172259,
      "h": 8593106851,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593106851)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298139555),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3172259,
      "h": 4298139555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298139555)
  ],
  "h": 3172259
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Settings${separator}SmartCowVitalsDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3172259)
        
        

        //--TRIMMABLE-BOUNDARY-START(92067)
        $asm.$cls(`$ezfM._LCIDCVC.TypeInference`, ($self) => class TypeInference
        {
            //--TRIMMABLE-BOUNDARY-START(4295059363)
            static /*void */ CreatePropertySheet_0(T, /*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder, /*int*/ seq, /*int*/ __seq0, /*global::System.String*/ __arg0, /*int*/ __seq1, /*T*/ __arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295059363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCP$7.PropertySheet$$(T), seq);
                __builder.AddComponentParameter(__seq0, "Class", __arg0);
                __builder.AddComponentParameter(__seq1, "Target", $.$box(__arg1, T));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(4295059363)
            
            static $h = 92067;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295059363),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        },
        {
          "n": "seq",
          "p": 655361
        },
        {
          "n": "__seq0",
          "p": 655361
        },
        {
          "n": "__arg0",
          "p": 1310721
        },
        {
          "n": "__seq1",
          "p": 655361
        },
        {
          "n": "__arg1",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreatePropertySheet_0",
      "d": 92067,
      "h": 4295059363,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295059363)
  ],
  "h": 92067
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `__Blazor.LivingThing.Core.IOT.Devices.CowVitals.Views.CowVitals.TypeInference`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `__Blazor${separator}LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Views${separator}CowVitals${separator}TypeInference`; }
        });
        //--TRIMMABLE-BOUNDARY-END(92067)
        
        

        //--TRIMMABLE-BOUNDARY-START(616355)
        $asm.$cls(`$ezfM.LCIDC.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180485539)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$sl.SL.Enumerable.Empty($.$$.S.String);
            }
            //--TRIMMABLE-BOUNDARY-END(17180485539)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295583651)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295583651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295583651)
            
            //--TRIMMABLE-BOUNDARY-START(4295583651)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295583651)
            
            static $h = 616355;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180485539),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885518243,
        "f": 50331649
      },
      "n": "Paths",
      "d": 616355,
      "h": 17180485539,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180485539)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295583651),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 616355,
      "h": 4295583651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295583651)
  ],
  "h": 616355
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(616355)
        
        

        //--TRIMMABLE-BOUNDARY-START(2320291)
        $asm.$cls(`$ezfM.LCIDC.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182189475)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$ezfM.LCIDCV.CowVitals.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$ezfM.LCIDCV.CowVitals().$ctor$6();
                    }, $HjvUIf ??= {"r":2752627,"n":"","d":2320291,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17182189475)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4297287587)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297287587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297287587)
            
            //--TRIMMABLE-BOUNDARY-START(4297287587)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297287587)
            
            static $h = 2320291;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182189475),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887222179,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 2320291,
      "h": 17182189475,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182189475)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297287587),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2320291,
      "h": 4297287587,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297287587)
  ],
  "h": 2320291
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2320291)
        
        

        //--TRIMMABLE-BOUNDARY-START(2451363)
        $asm.$cls(`$ezfM.LCIDC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592385955)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592385955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$ezfM.LCIDC.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ezfM.LCIDC.SmartCowVitalsDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$ezfM.LCIDC.SmartCowVitalsDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$ezfM.LCIDC.SmartCowVitalsDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ezfM.LCIDC.SmartCowVitalsDeviceFamily, x);
                }, $qJVlcj ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2451363,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ezfM.LCIDC.SmartCowVitalsDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ezfM.LCIDC.SmartCowVitalsDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $zvUUFc ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2451363,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ezfM.LCIDC.SmartCowVitalsDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ezfM.LCIDC.SmartCowVitalsDeviceFamily, x);
                }, $Ntleee ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$ezfM.LCIDC.SmartCowVitalsDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2451363,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ezfM.LCIDC.SmartCowVitalsDeviceFamily, x);
                }, $ylrGVd ??= {"r":$.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType).$h,"p":[{"n":"x","p":327718}],"n":"","d":2451363,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$ezfM.LCIDC.SmartCowVitalsDeviceFamily, x);
                }, $fvIwZb ??= {"r":$.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType).$h,"p":[{"n":"x","p":327718}],"n":"","d":2451363,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$ezfM.LCIDC.SmartCowVitalsDevice), $.$ezfM.LCIDCC.SmartCowVitalsDeviceCommands$$($.$ezfM.LCIDC.SmartCowVitalsDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, services);
                $.$sZVd.LCFCA.ClientApplicationExtension.AddApplication($.$ezfM.LCIDCV.CowVitals, services, (() =>
                {
                    //new $.$sZVd.LCFCA.ClientApplicationModel$$($.$ezfM.LCIDCV.CowVitals)()
                    const $t1 = $.$sZVd.LCFCA.ClientApplicationModel$$($.$ezfM.LCIDCV.CowVitals);
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Categories = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "IOT" ], null, null);
                    $i1.Name = "CowVitals";
                    $i1.Title = "Smart CowVitals";
                    $i1.Description = "Smart CowVitals with cloud connectivity";
                    $i1.Paths = $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "CowVitals" ], null, null);
                    $i1.Theme = $.$vWqU.LCFCC.ThemePack.op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFC.Theme()
                        const $t2 = $.$fPer.LCFC.Theme;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.BackgroundColor = "#00AEFF";
                        $i2.ForegroundColor = "#FFFFFF";
                        return $i2;
                    })());
                    $i1.Icon = $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-truck-cargo-container"/*MaterialDesignIconNames.TruckCargoContainer*/);
                    return $i1;
                })());
                $.$ezfM.LCIDC.FastAttributeStartupExtension.AddGeneratedFastAttributes(services);
                $.$ezfM.LCIDC.TypeDescriptorStartupExtension.AddGeneratedTypeDescriptors(services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592385955)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ezfM.LCIDC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297418659)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297418659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297418659)
            
            //--TRIMMABLE-BOUNDARY-START(4297418659)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297418659)
            
            static $h = 2451363;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592385955),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2451363,
      "h": 8592385955,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592385955)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297418659),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2451363,
      "h": 4297418659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297418659)
  ],
  "h": 2451363
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2451363)
        
        

        //--TRIMMABLE-BOUNDARY-START(4024227)
        $asm.$cls(`$ezfM.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298991523)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298991523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298991523)
            
            //--TRIMMABLE-BOUNDARY-START(4298991523)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298991523)
            
            static $h = 4024227;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298991523),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4024227,
      "h": 4298991523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298991523)
  ],
  "h": 4024227
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4024227)
        
        

        //--TRIMMABLE-BOUNDARY-START(4089763)
        $asm.$cls(`$ezfM.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299057059)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299057059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299057059)
            
            //--TRIMMABLE-BOUNDARY-START(4299057059)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299057059)
            
            static $h = 4089763;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299057059),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4089763,
      "h": 4299057059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299057059)
  ],
  "h": 4089763,
  "a": [
    {
      "t": 4024227,
      "c": 4298991523
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4089763)
        
        

        //--TRIMMABLE-BOUNDARY-START(1206179)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsStatusModel`, ($self) => class SmartCowVitalsStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(51540813731)
            /*float*/ AmbientTemperature = 0;
            //--TRIMMABLE-BOUNDARY-END(51540813731)
            
            //--TRIMMABLE-BOUNDARY-START(55835781027)
            /*float*/ BodyTemperature = 0;
            //--TRIMMABLE-BOUNDARY-END(55835781027)
            
            //--TRIMMABLE-BOUNDARY-START(253404276643)
            /*float*/ X = 0;
            //--TRIMMABLE-BOUNDARY-END(253404276643)
            
            //--TRIMMABLE-BOUNDARY-START(257699243939)
            /*float*/ Y = 0;
            //--TRIMMABLE-BOUNDARY-END(257699243939)
            
            //--TRIMMABLE-BOUNDARY-START(261994211235)
            /*float*/ Z = 0;
            //--TRIMMABLE-BOUNDARY-END(261994211235)
            
            //--TRIMMABLE-BOUNDARY-START(60130748323)
            /*int*/ BreathInterval = 0;
            //--TRIMMABLE-BOUNDARY-END(60130748323)
            
            //--TRIMMABLE-BOUNDARY-START(154620028835)
            /*float*/ Latitude = 0;
            //--TRIMMABLE-BOUNDARY-END(154620028835)
            
            //--TRIMMABLE-BOUNDARY-START(158914996131)
            /*float*/ Longitude = 0;
            //--TRIMMABLE-BOUNDARY-END(158914996131)
            
            //--TRIMMABLE-BOUNDARY-START(64425715619)
            /*float*/ Course = 0;
            //--TRIMMABLE-BOUNDARY-END(64425715619)
            
            //--TRIMMABLE-BOUNDARY-START(249109309347)
            /*float*/ Speed = 0;
            //--TRIMMABLE-BOUNDARY-END(249109309347)
            
            //--TRIMMABLE-BOUNDARY-START(47245846435)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245846435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245846435)
            
            //--TRIMMABLE-BOUNDARY-START(47245846435)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(47245846435)
            
            static $h = 1206179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540813731),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015650211,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504930723,
        "f": 83886081
      },
      "n": "AmbientTemperature",
      "d": 1206179,
      "h": 51540813731,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540813731),
//--TRIMMABLE-BOUNDARY-START(55835781027),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605584803,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094865315,
        "f": 83886081
      },
      "n": "BodyTemperature",
      "d": 1206179,
      "h": 55835781027,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835781027),
//--TRIMMABLE-BOUNDARY-START(253404276643),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145192355,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634472867,
        "f": 83886081
      },
      "n": "X",
      "d": 1206179,
      "h": 253404276643,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253404276643),
//--TRIMMABLE-BOUNDARY-START(257699243939),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735126947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224407459,
        "f": 83886081
      },
      "n": "Y",
      "d": 1206179,
      "h": 257699243939,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(257699243939),
//--TRIMMABLE-BOUNDARY-START(261994211235),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325061539,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814342051,
        "f": 83886081
      },
      "n": "Z",
      "d": 1206179,
      "h": 261994211235,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261994211235),
//--TRIMMABLE-BOUNDARY-START(60130748323),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195519395,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684799907,
        "f": 83886081
      },
      "n": "BreathInterval",
      "d": 1206179,
      "h": 60130748323,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130748323),
//--TRIMMABLE-BOUNDARY-START(154620028835),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375388579,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864669091,
        "f": 83886081
      },
      "n": "Latitude",
      "d": 1206179,
      "h": 154620028835,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 7,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620028835),
//--TRIMMABLE-BOUNDARY-START(158914996131),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965323171,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454603683,
        "f": 83886081
      },
      "n": "Longitude",
      "d": 1206179,
      "h": 158914996131,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 8,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914996131),
//--TRIMMABLE-BOUNDARY-START(64425715619),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785453987,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274734499,
        "f": 83886081
      },
      "n": "Course",
      "d": 1206179,
      "h": 64425715619,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 9,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425715619),
//--TRIMMABLE-BOUNDARY-START(249109309347),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555257763,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044538275,
        "f": 83886081
      },
      "n": "Speed",
      "d": 1206179,
      "h": 249109309347,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 10,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249109309347)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47245846435),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1206179,
      "h": 47245846435,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245846435)
  ],
  "h": 1206179
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1206179)
        
        

        //--TRIMMABLE-BOUNDARY-START(157603)
        $asm.$cls(`$ezfM.LCIDC._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590092195)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590092195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590092195)
            
            //--TRIMMABLE-BOUNDARY-START(4295124899)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295124899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295124899)
            
            //--TRIMMABLE-BOUNDARY-START(4295124899)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295124899)
            
            static $h = 157603;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590092195),
    {
      "r": 65537,
      "n": "Execute",
      "d": 157603,
      "h": 8590092195,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590092195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295124899),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 157603,
      "h": 4295124899,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295124899)
  ],
  "h": 157603
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(157603)
        
        

        //--TRIMMABLE-BOUNDARY-START(944035)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel`, ($self) => class SmartCowVitalsDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceSendDataModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295911331)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295911331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295911331)
            
            //--TRIMMABLE-BOUNDARY-START(4295911331)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295911331)
            
            static $h = 944035;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceSendDataModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295911331),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 944035,
      "h": 4295911331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295911331)
  ],
  "h": 944035
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(944035)
        
        

        //--TRIMMABLE-BOUNDARY-START(1337251)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor`, ($self) => class SmartCowVitalsStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296304547)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296304547);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor.GenerateProperties($.$ezfM.LCIDCD.SmartCowVitalsStatusModel, this, factory);
                    }, $YJlvia ??= {"r":65537,"n":"","d":1337251,"h":0,"f":17825794}), 0, "SmartCowVitalsStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.CowVitals\\Models_SmartCowVitalsStatusModel_LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModelTypeDescriptorBuilder.g.cs", "SmartCowVitalsStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296304547)
            
            //--TRIMMABLE-BOUNDARY-START(12886239139)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886239139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("AmbientTemperature"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, $.$discardRef(), "AmbientTemperature", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("AmbientTemperature")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "AmbientTemperature";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)).AmbientTemperature);
                        }, $knONGi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337251,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.AmbientTemperature = value.AsFloat();
                        }, $jKhEhl ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337251,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BodyTemperature"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, $.$discardRef(), "BodyTemperature", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BodyTemperature")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "BodyTemperature";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)).BodyTemperature);
                        }, $bhZBPi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337251,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BodyTemperature = value.AsFloat();
                        }, $nfizSa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337251,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("X"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, $.$discardRef(), "X", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("X")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "X";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)).X);
                        }, $VuErPa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337251,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.X = value.AsFloat();
                        }, $wYeaWe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337251,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Y"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, $.$discardRef(), "Y", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Y")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Y";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)).Y);
                        }, $SQgYdl ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337251,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Y = value.AsFloat();
                        }, $VYIVqb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337251,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Z"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, $.$discardRef(), "Z", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Z")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Z";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)).Z);
                        }, $uEiOGc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337251,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Z = value.AsFloat();
                        }, $hMxLtc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337251,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("BreathInterval"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, $.$discardRef(), "BreathInterval", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("BreathInterval")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "BreathInterval";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)).BreathInterval);
                        }, $bxAjGd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337251,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.BreathInterval = value.AsInt();
                        }, $LMsCVi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337251,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Latitude"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, $.$discardRef(), "Latitude", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Latitude")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "Latitude";
                        $i13.DelaredOn = "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)).Latitude);
                        }, $ZeAfik ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337251,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Latitude = value.AsFloat();
                        }, $CSHcWd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337251,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Longitude"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, $.$discardRef(), "Longitude", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Longitude")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "Longitude";
                        $i15.DelaredOn = "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)).Longitude);
                        }, $KsRBui ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337251,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Longitude = value.AsFloat();
                        }, $kSNtXg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337251,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Course"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, $.$discardRef(), "Course", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Course")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "Course";
                        $i17.DelaredOn = "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)).Course);
                        }, $FArDWc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337251,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Course = value.AsFloat();
                        }, $GPIZmi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337251,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Speed"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel.$type, $.$discardRef(), "Speed", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Speed")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Single, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t19 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i19 = new $t19();
                        $i19.$ctor$2();
                        $i19.Name = "Speed";
                        $i19.DelaredOn = "LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel";
                        $i19.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$9(($.$cast(target, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)).Speed);
                        }, $oJhECb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1337251,"h":0,"f":17825826});
                        $i19.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Speed = value.AsFloat();
                        }, $mZAkwk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1337251,"h":0,"f":17825826});
                        return $i19;
                    })()), schemas, null, factory);
                    let $en20 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en20.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en20.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886239139)
            
            //--TRIMMABLE-BOUNDARY-START(17181206435)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181206435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _AmbientTemperature = _target.AmbientTemperature;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("AmbientTemperature"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _AmbientTemperature, ($v) => _AmbientTemperature = $v, $.$$.S.Single)))
                    {
                        _target.AmbientTemperature = _AmbientTemperature;
                    }
                }
                {
                    /*var*/ let _BodyTemperature = _target.BodyTemperature;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BodyTemperature"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _BodyTemperature, ($v) => _BodyTemperature = $v, $.$$.S.Single)))
                    {
                        _target.BodyTemperature = _BodyTemperature;
                    }
                }
                {
                    /*var*/ let _X = _target.X;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("X"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _X, ($v) => _X = $v, $.$$.S.Single)))
                    {
                        _target.X = _X;
                    }
                }
                {
                    /*var*/ let _Y = _target.Y;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Y"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _Y, ($v) => _Y = $v, $.$$.S.Single)))
                    {
                        _target.Y = _Y;
                    }
                }
                {
                    /*var*/ let _Z = _target.Z;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Z"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _Z, ($v) => _Z = $v, $.$$.S.Single)))
                    {
                        _target.Z = _Z;
                    }
                }
                {
                    /*var*/ let _BreathInterval = _target.BreathInterval;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("BreathInterval"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _BreathInterval, ($v) => _BreathInterval = $v, $.$$.S.Int32)))
                    {
                        _target.BreathInterval = _BreathInterval;
                    }
                }
                {
                    /*var*/ let _Latitude = _target.Latitude;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Latitude"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _Latitude, ($v) => _Latitude = $v, $.$$.S.Single)))
                    {
                        _target.Latitude = _Latitude;
                    }
                }
                {
                    /*var*/ let _Longitude = _target.Longitude;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Longitude"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _Longitude, ($v) => _Longitude = $v, $.$$.S.Single)))
                    {
                        _target.Longitude = _Longitude;
                    }
                }
                {
                    /*var*/ let _Course = _target.Course;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Course"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _Course, ($v) => _Course = $v, $.$$.S.Single)))
                    {
                        _target.Course = _Course;
                    }
                }
                {
                    /*var*/ let _Speed = _target.Speed;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Speed"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Single));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Single, property, $.$ref(() => _Speed, ($v) => _Speed = $v, $.$$.S.Single)))
                    {
                        _target.Speed = _Speed;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181206435)
            
            //--TRIMMABLE-BOUNDARY-START(8591271843)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591271843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ezfM.LCIDCD.SmartCowVitalsStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)))
                {
                    /*var*/ let result = $.$ezfM.LCIDCD.SmartCowVitalsStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591271843)
            
            static $h = 1337251;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886239139),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1337251,
      "h": 12886239139,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886239139),
//--TRIMMABLE-BOUNDARY-START(17181206435),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1206179,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1337251,
      "h": 17181206435,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181206435),
//--TRIMMABLE-BOUNDARY-START(8591271843),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1206179,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1337251,
      "h": 8591271843,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591271843)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296304547),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1337251,
      "h": 4296304547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296304547)
  ],
  "h": 1337251
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1337251)
        
        

        //--TRIMMABLE-BOUNDARY-START(550819)
        $asm.$cls(`$ezfM.LCIDCC.SmartCowVitalsDeviceCommands<>`, (TDevice) => $asm.$gt(`$ezfM.LCIDCC.SmartCowVitalsDeviceCommands<>`, [TDevice], ($self) => class SmartCowVitalsDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12885452707)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885452707)
            
            //--TRIMMABLE-BOUNDARY-START(17180420003)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180420003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$ezfM.LCIDCC.SmartCowVitalsDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17180420003)
            
            //--TRIMMABLE-BOUNDARY-START(8590485411)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590485411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590485411)
            
            //--TRIMMABLE-BOUNDARY-START(8590485411)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590485411)
            
            //--TRIMMABLE-BOUNDARY-START(4295518115)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295518115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885452707)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885452707)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295518115)
            
            static $H = 550819;
            static $h = 550819;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180420003),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17180420003,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180420003)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885452707),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12885452707,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885452707)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590485411),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8590485411,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590485411)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 550819,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Commands.SmartCowVitalsDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Commands${separator}SmartCowVitalsDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(550819)
        
        

        //--TRIMMABLE-BOUNDARY-START(1075107)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModelTypeDescriptor`, ($self) => class SmartCowVitalsDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296042403)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296042403);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModelTypeDescriptor.GenerateProperties($.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, this, factory);
                    }, $AqDyqg ??= {"r":65537,"n":"","d":1075107,"h":0,"f":17825794}), 0, "SmartCowVitalsDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.CowVitals\\Models_SmartCowVitalsDeviceSendDataModel_LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SmartCowVitalsDeviceSendDataModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296042403)
            
            //--TRIMMABLE-BOUNDARY-START(12885976995)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885976995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885976995)
            
            //--TRIMMABLE-BOUNDARY-START(17180944291)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180944291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceSendDataModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceSendDataModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180944291)
            
            //--TRIMMABLE-BOUNDARY-START(8591009699)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591009699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591009699)
            
            static $h = 1075107;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885976995),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1075107,
      "h": 12885976995,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885976995),
//--TRIMMABLE-BOUNDARY-START(17180944291),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 944035,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1075107,
      "h": 17180944291,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180944291),
//--TRIMMABLE-BOUNDARY-START(8591009699),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 944035,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1075107,
      "h": 8591009699,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591009699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296042403),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1075107,
      "h": 4296042403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296042403)
  ],
  "h": 1075107
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1075107)
        
        

        //--TRIMMABLE-BOUNDARY-START(288675)
        $asm.$cls(`$ezfM.LCIDCC.SmartCowVitalsCommandsModel`, ($self) => class SmartCowVitalsCommandsModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295255971)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295255971);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295255971)
            
            //--TRIMMABLE-BOUNDARY-START(4295255971)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295255971)
            
            static $h = 288675;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295255971),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 288675,
      "h": 4295255971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295255971)
  ],
  "h": 288675
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Commands.SmartCowVitalsCommandsModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Commands${separator}SmartCowVitalsCommandsModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(288675)
        
        

        //--TRIMMABLE-BOUNDARY-START(681891)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel`, ($self) => class SmartCowVitalsDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$ezfM.LCIDCD.SmartCowVitalsStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295649187)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295649187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295649187)
            
            //--TRIMMABLE-BOUNDARY-START(4295649187)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295649187)
            
            static $h = 681891;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$ezfM.LCIDCD.SmartCowVitalsStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295649187),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 681891,
      "h": 4295649187,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295649187)
  ],
  "h": 681891
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(681891)
        
        

        //--TRIMMABLE-BOUNDARY-START(419747)
        $asm.$cls(`$ezfM.LCIDCC.SmartCowVitalsCommandsModelTypeDescriptor`, ($self) => class SmartCowVitalsCommandsModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCC.SmartCowVitalsCommandsModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295387043)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295387043);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ezfM.LCIDCC.SmartCowVitalsCommandsModelTypeDescriptor.GenerateProperties($.$ezfM.LCIDCC.SmartCowVitalsCommandsModel, this, factory);
                    }, $CyxBla ??= {"r":65537,"n":"","d":419747,"h":0,"f":17825794}), 0, "SmartCowVitalsCommandsModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.CowVitals\\Commands_SmartCowVitalsCommandsModel_LivingThing.Core.IOT.Devices.CowVitals.Commands.SmartCowVitalsCommandsModelTypeDescriptorBuilder.g.cs", "SmartCowVitalsCommandsModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295387043)
            
            //--TRIMMABLE-BOUNDARY-START(12885321635)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885321635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885321635)
            
            //--TRIMMABLE-BOUNDARY-START(17180288931)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Commands.SmartCowVitalsCommandsModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180288931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180288931)
            
            //--TRIMMABLE-BOUNDARY-START(8590354339)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Commands.SmartCowVitalsCommandsModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590354339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ezfM.LCIDCC.SmartCowVitalsCommandsModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ezfM.LCIDCC.SmartCowVitalsCommandsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCC.SmartCowVitalsCommandsModel)))
                {
                    /*var*/ let result = $.$ezfM.LCIDCC.SmartCowVitalsCommandsModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCC.SmartCowVitalsCommandsModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ezfM.LCIDCC.SmartCowVitalsCommandsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCC.SmartCowVitalsCommandsModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590354339)
            
            static $h = 419747;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCC.SmartCowVitalsCommandsModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885321635),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 419747,
      "h": 12885321635,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885321635),
//--TRIMMABLE-BOUNDARY-START(17180288931),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 288675,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 419747,
      "h": 17180288931,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180288931),
//--TRIMMABLE-BOUNDARY-START(8590354339),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 288675,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 419747,
      "h": 8590354339,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590354339)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295387043),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 419747,
      "h": 4295387043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295387043)
  ],
  "h": 419747
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ezfM.LCIDCC.SmartCowVitalsCommandsModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Commands.SmartCowVitalsCommandsModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Commands${separator}SmartCowVitalsCommandsModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(419747)
        
        

        //--TRIMMABLE-BOUNDARY-START(812963)
        $asm.$cls(`$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModelTypeDescriptor`, ($self) => class SmartCowVitalsDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295780259)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295780259);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, this, factory);
                    }, $bMhNSe ??= {"r":65537,"n":"","d":812963,"h":0,"f":17825794}), 0, "SmartCowVitalsDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.CowVitals\\Models_SmartCowVitalsDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SmartCowVitalsDeviceReceivedDataModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295780259)
            
            //--TRIMMABLE-BOUNDARY-START(12885714851)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885714851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885714851)
            
            //--TRIMMABLE-BOUNDARY-START(17180682147)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180682147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$ezfM.LCIDCD.SmartCowVitalsStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180682147)
            
            //--TRIMMABLE-BOUNDARY-START(8590747555)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590747555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590747555)
            
            static $h = 812963;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885714851),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 812963,
      "h": 12885714851,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885714851),
//--TRIMMABLE-BOUNDARY-START(17180682147),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 681891,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 812963,
      "h": 17180682147,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180682147),
//--TRIMMABLE-BOUNDARY-START(8590747555),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 681891,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 812963,
      "h": 8590747555,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590747555)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295780259),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 812963,
      "h": 4295780259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295780259)
  ],
  "h": 812963
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Data${separator}SmartCowVitalsDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(812963)
        
        

        //--TRIMMABLE-BOUNDARY-START(3237795)
        $asm.$cls(`$ezfM.LCIDC.SmartCowVitalsDataConverter`, ($self) => class SmartCowVitalsDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298205091)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298205091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298205091)
            
            //--TRIMMABLE-BOUNDARY-START(4298205091)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298205091)
            
            static $h = 3237795;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298205091),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3237795,
      "h": 4298205091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298205091)
  ],
  "h": 3237795
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.SmartCowVitalsDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}SmartCowVitalsDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3237795)
        
        

        //--TRIMMABLE-BOUNDARY-START(2582435)
        $asm.$cls(`$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler`, ($self) => class ISmartCowVitalsDeviceStatusHandler
        {
            static $h = 2582435;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2582435
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Services${separator}ISmartCowVitalsDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2582435)
        
        

        $asm.$typeProxy("$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel", "$ezfM.LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModel");
        $asm.$typeProxy("$ezfM.LCIDCM.SmartCowVitalsDeviceModel", "$ezfM.LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModel");
        $asm.$typeProxy("$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings", "$ezfM.LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettings");
        $asm.$typeProxy("$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings", "$ezfM.LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettings");
        $asm.$typeProxy("$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient", "$ezfM.LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceHubClient");
        $asm.$typeProxy("$ezfM.LCIDCS.ISmartCowVitalsRemoteService", "$ezfM.LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsRemoteService");
        //--TRIMMABLE-BOUNDARY-START(2058147)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsServiceModel`, ($self) => class SmartCowVitalsServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297025443)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297025443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297025443)
            
            //--TRIMMABLE-BOUNDARY-START(4297025443)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4297025443)
            
            static $h = 2058147;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297025443),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 2058147,
      "h": 4297025443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297025443)
  ],
  "h": 2058147
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2058147)
        
        

        //--TRIMMABLE-BOUNDARY-START(1533859)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsDeviceModel`, ($self) => class SmartCowVitalsDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296501155)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296501155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296501155)
            
            //--TRIMMABLE-BOUNDARY-START(4296501155)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296501155)
            
            static $h = 1533859;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296501155),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1533859,
      "h": 4296501155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296501155)
  ],
  "h": 1533859
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1533859)
        
        

        //--TRIMMABLE-BOUNDARY-START(2516899)
        $asm.$cls(`$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient`, ($self) => class ISmartCowVitalsDeviceHubClient
        {
            static $h = 2516899;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2516899
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Services${separator}ISmartCowVitalsDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2516899)
        
        

        //--TRIMMABLE-BOUNDARY-START(1796003)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel`, ($self) => class SmartCowVitalsDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296763299)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296763299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296763299)
            
            //--TRIMMABLE-BOUNDARY-START(4296763299)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296763299)
            
            static $h = 1796003;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296763299),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1796003,
      "h": 4296763299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296763299)
  ],
  "h": 1796003
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1796003)
        
        

        //--TRIMMABLE-BOUNDARY-START(2647971)
        $asm.$cls(`$ezfM.LCIDCS.ISmartCowVitalsRemoteService`, ($self) => class ISmartCowVitalsRemoteService
        {
            static $h = 2647971;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2647971
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Services${separator}ISmartCowVitalsRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2647971)
        
        

        //--TRIMMABLE-BOUNDARY-START(2713507)
        $asm.$cls(`$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings`, ($self) => class SmartCowVitalsDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297680803)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297680803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297680803)
            
            //--TRIMMABLE-BOUNDARY-START(4297680803)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297680803)
            
            static $h = 2713507;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297680803),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2713507,
      "h": 4297680803,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297680803)
  ],
  "h": 2713507
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Settings${separator}SmartCowVitalsDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2713507)
        
        

        //--TRIMMABLE-BOUNDARY-START(2975651)
        $asm.$cls(`$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings`, ($self) => class SmartCowVitalsDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $self, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297942947)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297942947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297942947)
            
            //--TRIMMABLE-BOUNDARY-START(4297942947)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297942947)
            
            static $h = 2975651;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297942947),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2975651,
      "h": 4297942947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297942947)
  ],
  "h": 2975651
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Settings${separator}SmartCowVitalsDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2975651)
        
        

        //--TRIMMABLE-BOUNDARY-START(3499939)
        $asm.$cls(`$ezfM.LCIDC.SmartCowVitalsDeviceModelDefinition`, ($self) => class SmartCowVitalsDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4298467235)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298467235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298467235)
            
            //--TRIMMABLE-BOUNDARY-START(4298467235)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298467235)
            
            static $h = 3499939;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298467235),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3499939,
      "h": 4298467235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298467235)
  ],
  "h": 3499939
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.SmartCowVitalsDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}SmartCowVitalsDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3499939)
        
        

        //--TRIMMABLE-BOUNDARY-START(2844579)
        $asm.$cls(`$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettingsTypeDescriptor`, ($self) => class SmartCowVitalsDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297811875)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297811875);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, this, factory);
                    }, $bhEowk ??= {"r":65537,"n":"","d":2844579,"h":0,"f":17825794}), 0, "SmartCowVitalsDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.CowVitals\\Settings_SmartCowVitalsDeviceHardwareSettings_LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SmartCowVitalsDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297811875)
            
            //--TRIMMABLE-BOUNDARY-START(12887746467)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887746467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887746467)
            
            //--TRIMMABLE-BOUNDARY-START(17182713763)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182713763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModel, LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettings, LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModel, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceStatusHandler, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceHubClient, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceHardwareSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182713763)
            
            //--TRIMMABLE-BOUNDARY-START(8592779171)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592779171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592779171)
            
            static $h = 2844579;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887746467),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2844579,
      "h": 12887746467,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887746467),
//--TRIMMABLE-BOUNDARY-START(17182713763),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2713507,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2844579,
      "h": 17182713763,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182713763),
//--TRIMMABLE-BOUNDARY-START(8592779171),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2713507,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2844579,
      "h": 8592779171,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592779171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297811875),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2844579,
      "h": 4297811875,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297811875)
  ],
  "h": 2844579
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Settings${separator}SmartCowVitalsDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2844579)
        
        

        //--TRIMMABLE-BOUNDARY-START(2189219)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsServiceModelTypeDescriptor`, ($self) => class SmartCowVitalsServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297156515)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297156515);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ezfM.LCIDCM.SmartCowVitalsServiceModelTypeDescriptor.GenerateProperties($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, this, factory);
                    }, $cJFomc ??= {"r":65537,"n":"","d":2189219,"h":0,"f":17825794}), 0, "SmartCowVitalsServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.CowVitals\\Models_SmartCowVitalsServiceModel_LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModelTypeDescriptorBuilder.g.cs", "SmartCowVitalsServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297156515)
            
            //--TRIMMABLE-BOUNDARY-START(12887091107)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887091107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887091107)
            
            //--TRIMMABLE-BOUNDARY-START(17182058403)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182058403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModel, LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettings, LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModel, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceStatusHandler, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceHubClient, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182058403)
            
            //--TRIMMABLE-BOUNDARY-START(8592123811)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592123811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ezfM.LCIDCM.SmartCowVitalsServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel)))
                {
                    /*var*/ let result = $.$ezfM.LCIDCM.SmartCowVitalsServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592123811)
            
            static $h = 2189219;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887091107),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2189219,
      "h": 12887091107,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887091107),
//--TRIMMABLE-BOUNDARY-START(17182058403),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2058147,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2189219,
      "h": 17182058403,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182058403),
//--TRIMMABLE-BOUNDARY-START(8592123811),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2058147,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2189219,
      "h": 8592123811,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592123811)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297156515),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2189219,
      "h": 4297156515,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297156515)
  ],
  "h": 2189219
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2189219)
        
        

        //--TRIMMABLE-BOUNDARY-START(1927075)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModelTypeDescriptor`, ($self) => class SmartCowVitalsDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296894371)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296894371);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModelTypeDescriptor.GenerateProperties($.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, this, factory);
                    }, $btmTZg ??= {"r":65537,"n":"","d":1927075,"h":0,"f":17825794}), 0, "SmartCowVitalsDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.CowVitals\\Models_SmartCowVitalsDeviceScopeModel_LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModelTypeDescriptorBuilder.g.cs", "SmartCowVitalsDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296894371)
            
            //--TRIMMABLE-BOUNDARY-START(12886828963)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886828963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886828963)
            
            //--TRIMMABLE-BOUNDARY-START(17181796259)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181796259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModel, LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettings, LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModel, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceStatusHandler, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceHubClient, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181796259)
            
            //--TRIMMABLE-BOUNDARY-START(8591861667)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591861667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel)))
                {
                    /*var*/ let result = $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591861667)
            
            static $h = 1927075;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886828963),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1927075,
      "h": 12886828963,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886828963),
//--TRIMMABLE-BOUNDARY-START(17181796259),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1796003,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1927075,
      "h": 17181796259,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181796259),
//--TRIMMABLE-BOUNDARY-START(8591861667),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1796003,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1927075,
      "h": 8591861667,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591861667)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296894371),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1927075,
      "h": 4296894371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296894371)
  ],
  "h": 1927075
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1927075)
        
        

        //--TRIMMABLE-BOUNDARY-START(1664931)
        $asm.$cls(`$ezfM.LCIDCM.SmartCowVitalsDeviceModelTypeDescriptor`, ($self) => class SmartCowVitalsDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCM.SmartCowVitalsDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296632227)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296632227);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ezfM.LCIDCM.SmartCowVitalsDeviceModelTypeDescriptor.GenerateProperties($.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, this, factory);
                    }, $OHMTCg ??= {"r":65537,"n":"","d":1664931,"h":0,"f":17825794}), 0, "SmartCowVitalsDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.CowVitals\\Models_SmartCowVitalsDeviceModel_LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModelTypeDescriptorBuilder.g.cs", "SmartCowVitalsDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296632227)
            
            //--TRIMMABLE-BOUNDARY-START(12886566819)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886566819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886566819)
            
            //--TRIMMABLE-BOUNDARY-START(17181534115)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181534115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModel, LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettings, LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModel, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceStatusHandler, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceHubClient, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181534115)
            
            //--TRIMMABLE-BOUNDARY-START(8591599523)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591599523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel)))
                {
                    /*var*/ let result = $.$ezfM.LCIDCM.SmartCowVitalsDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591599523)
            
            static $h = 1664931;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCM.SmartCowVitalsDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886566819),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1664931,
      "h": 12886566819,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886566819),
//--TRIMMABLE-BOUNDARY-START(17181534115),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1533859,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1664931,
      "h": 17181534115,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181534115),
//--TRIMMABLE-BOUNDARY-START(8591599523),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1533859,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1664931,
      "h": 8591599523,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591599523)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296632227),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1664931,
      "h": 4296632227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296632227)
  ],
  "h": 1664931
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ezfM.LCIDCM.SmartCowVitalsDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Models${separator}SmartCowVitalsDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1664931)
        
        

        //--TRIMMABLE-BOUNDARY-START(3106723)
        $asm.$cls(`$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettingsTypeDescriptor`, ($self) => class SmartCowVitalsDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298074019)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298074019);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettingsTypeDescriptor.GenerateProperties($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, this, factory);
                    }, $WJIoGb ??= {"r":65537,"n":"","d":3106723,"h":0,"f":17825794}), 0, "SmartCowVitalsDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.CowVitals\\Settings_SmartCowVitalsDeviceSettings_LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettingsTypeDescriptorBuilder.g.cs", "SmartCowVitalsDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298074019)
            
            //--TRIMMABLE-BOUNDARY-START(12888008611)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888008611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888008611)
            
            //--TRIMMABLE-BOUNDARY-START(17182975907)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182975907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.CowVitals.Models.SmartCowVitalsDeviceModel, LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettings, LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.CowVitals.Data.SmartCowVitalsDeviceSendDataModel, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceStatusHandler, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsDeviceHubClient, LivingThing.Core.IOT.Devices.CowVitals.Services.ISmartCowVitalsRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182975907)
            
            //--TRIMMABLE-BOUNDARY-START(8593041315)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593041315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings)))
                {
                    /*var*/ let result = $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593041315)
            
            static $h = 3106723;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888008611),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3106723,
      "h": 12888008611,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888008611),
//--TRIMMABLE-BOUNDARY-START(17182975907),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2975651,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3106723,
      "h": 17182975907,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182975907),
//--TRIMMABLE-BOUNDARY-START(8593041315),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2975651,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3106723,
      "h": 8593041315,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593041315)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298074019),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3106723,
      "h": 4298074019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298074019)
  ],
  "h": 3106723
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Settings.SmartCowVitalsDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Settings${separator}SmartCowVitalsDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3106723)
        
        

        //--TRIMMABLE-BOUNDARY-START(3303331)
        $asm.$cls(`$ezfM.LCIDC.SmartCowVitalsDevice`, ($self) => class SmartCowVitalsDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4298270627)
            $ctor$2(/*IIOTDeviceFamily<SmartCowVitalsDevice>*/ family, /*IIOTDeviceScope*/ scope, /*SmartCowVitalsDeviceModel*/ model)
            {
                super.$ctor$3(family, scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298270627);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298270627)
            
            static $h = 3303331;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298270627),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ezfM.LCIDC.SmartCowVitalsDevice).$h
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 1533859
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3303331,
      "h": 4298270627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298270627)
  ],
  "h": 3303331
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.SmartCowVitalsDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}SmartCowVitalsDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3303331)
        
        

        //--TRIMMABLE-BOUNDARY-START(3368867)
        $asm.$cls(`$ezfM.LCIDC.SmartCowVitalsDeviceDefinition`, ($self) => class SmartCowVitalsDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298336163)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298336163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298336163)
            
            //--TRIMMABLE-BOUNDARY-START(4298336163)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298336163)
            
            static $h = 3368867;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$ezfM.LCIDCD.SmartCowVitalsStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298336163),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3368867,
      "h": 4298336163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298336163)
  ],
  "h": 3368867
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.SmartCowVitalsDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}SmartCowVitalsDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3368867)
        
        

        //--TRIMMABLE-BOUNDARY-START(3434403)
        $asm.$cls(`$ezfM.LCIDC.SmartCowVitalsDeviceFamily`, ($self) => class SmartCowVitalsDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4298401699)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SmartCowVitalsDeviceReceivedDataModel, SmartCowVitalsDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SmartCowVitalsDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298401699);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298401699)
            
            //--TRIMMABLE-BOUNDARY-START(8593368995)
            /*IIOTDeviceFamilyFeatures */ get Features()
            {
                return super.Features | 1/*IIOTDeviceFamilyFeatures.NoDatabase*/;
            }
            //--TRIMMABLE-BOUNDARY-END(8593368995)
            
            static $h = 3434403;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593368995),
    {
      "p": 26842513,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183303587,
        "f": 50364417
      },
      "n": "Features",
      "d": 3434403,
      "h": 8593368995,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593368995)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298401699),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3434403,
      "h": 4298401699,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298401699)
  ],
  "h": 3434403
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$ezfM.LCIDC.SmartCowVitalsDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$ezfM.LCIDC.SmartCowVitalsDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.SmartCowVitalsDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}SmartCowVitalsDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3434403)
        
        

        $asm.$typeProxy("$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel", "$ezfM.LivingThing.Core.IOT.Devices.CowVitals.Views.SmartCowVitalsClientAppViewModel");
        $asm.$typeProxy("$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel", "$ezfM.LivingThing.Core.IOT.Devices.CowVitals.Views.SmartCowVitalsClientAppServiceViewModel");
        $asm.$typeProxy("$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel", "$ezfM.LivingThing.Core.IOT.Devices.CowVitals.Views.SmartCowVitalsClientAppDeviceViewModel");
        //--TRIMMABLE-BOUNDARY-START(3762083)
        $asm.$cls(`$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel`, ($self) => class SmartCowVitalsClientAppDeviceScopeViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel, $self, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298729379)
            $ctor$3(/*SmartCowVitalsClientAppServiceViewModel*/ service, /*SmartCowVitalsDeviceScopeModel*/ model, /*IEnumerable<SmartCowVitalsClientAppDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298729379);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298729379)
            
            static $h = 3762083;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298729379),
    {
      "p": [
        {
          "n": "service",
          "p": 3893155
        },
        {
          "n": "model",
          "p": 1796003
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3762083,
      "h": 4298729379,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298729379)
  ],
  "h": 3762083
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Views.SmartCowVitalsClientAppDeviceScopeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Views${separator}SmartCowVitalsClientAppDeviceScopeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3762083)
        
        

        //--TRIMMABLE-BOUNDARY-START(3893155)
        $asm.$cls(`$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel`, ($self) => class SmartCowVitalsClientAppServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $self, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298860451)
            $ctor$3(/*SmartCowVitalsClientAppViewModel*/ app, /*SmartCowVitalsServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298860451);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298860451)
            
            //--TRIMMABLE-BOUNDARY-START(12888795043)
            /*SmartCowVitalsClientAppDeviceViewModel */ GetDeviceViewModel(/*SmartCowVitalsDeviceModel*/ model, /*IEnumerable<SmartCowVitalsClientAppDeviceScopeViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888795043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12888795043)
            
            //--TRIMMABLE-BOUNDARY-START(8593827747)
            /*SmartCowVitalsClientAppDeviceScopeViewModel */ GetDeviceScopeViewModel(/*SmartCowVitalsDeviceScopeModel*/ model, /*IEnumerable<SmartCowVitalsClientAppDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593827747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8593827747)
            
            static $h = 3893155;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888795043),
    {
      "r": 3827619,
      "p": [
        {
          "n": "model",
          "p": 1533859
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 3893155,
      "h": 12888795043,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888795043),
//--TRIMMABLE-BOUNDARY-START(8593827747),
    {
      "r": 3762083,
      "p": [
        {
          "n": "model",
          "p": 1796003
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 3893155,
      "h": 8593827747,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8593827747)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298860451),
    {
      "p": [
        {
          "n": "app",
          "p": 3958691
        },
        {
          "n": "model",
          "p": 2058147
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3893155,
      "h": 4298860451,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298860451)
  ],
  "h": 3893155
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Views.SmartCowVitalsClientAppServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Views${separator}SmartCowVitalsClientAppServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3893155)
        
        

        //--TRIMMABLE-BOUNDARY-START(3827619)
        $asm.$cls(`$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel`, ($self) => class SmartCowVitalsClientAppDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel, $self, $.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298794915)
            $ctor$7(/*SmartCowVitalsClientAppServiceViewModel*/ service, /*SmartCowVitalsDeviceModel*/ model, /*IEnumerable<SmartCowVitalsClientAppDeviceScopeViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298794915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298794915)
            
            static $h = 3827619;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298794915),
    {
      "p": [
        {
          "n": "service",
          "p": 3893155
        },
        {
          "n": "model",
          "p": 1533859
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 3827619,
      "h": 4298794915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298794915)
  ],
  "h": 3827619
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Views.SmartCowVitalsClientAppDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Views${separator}SmartCowVitalsClientAppDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3827619)
        
        

        //--TRIMMABLE-BOUNDARY-START(3958691)
        $asm.$cls(`$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel`, ($self) => class SmartCowVitalsClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298925987)
            $ctor$5(/*IOTRootViewModel*/ root, /*SmartCowVitalsDeviceFamily*/ family, /*IHubConnector<ISmartCowVitalsDeviceHubClient>*/ hubConnector)
            {
                super.$ctor$5(root, family, hubConnector);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298925987);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298925987)
            
            //--TRIMMABLE-BOUNDARY-START(8593893283)
            /*bool */ get Authorize()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8593893283)
            
            //--TRIMMABLE-BOUNDARY-START(21478795171)
            /*SmartCowVitalsClientAppServiceViewModel */ GetServiceViewModel(/*SmartCowVitalsServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478795171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(21478795171)
            
            //--TRIMMABLE-BOUNDARY-START(25773762467)
            /*ValueTask<IEnumerable<UserServiceSubscriptionModel<SmartCowVitalsServiceModel>>> *//*async*/  LoadServices()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel))), $.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel)), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25773762467);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let services = ($t1 = this.LoadServicesFromJWT(null), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, services);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(25773762467)
            
            static $h = 3958691;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593893283),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183827875,
        "f": 50364417
      },
      "n": "Authorize",
      "d": 3958691,
      "h": 8593893283,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593893283)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478795171),
    {
      "r": 3893155,
      "p": [
        {
          "n": "model",
          "p": 2058147
        }
      ],
      "n": "GetServiceViewModel",
      "d": 3958691,
      "h": 21478795171,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21478795171),
//--TRIMMABLE-BOUNDARY-START(25773762467),
    {
      "r": $.$$.STT.ValueTask$$($.$$.SCG.IEnumerable$$($.$Iaui.LCFCM.UserServiceSubscriptionModel$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel))).$h,
      "n": "LoadServices",
      "d": 3958691,
      "h": 25773762467,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(25773762467)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298925987),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 3434403
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3958691,
      "h": 4298925987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298925987)
  ],
  "h": 3958691
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$ezfM.LCIDCM.SmartCowVitalsServiceModel), $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Views.SmartCowVitalsClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Views${separator}SmartCowVitalsClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3958691)
        
        

        //--TRIMMABLE-BOUNDARY-START(3696547)
        $asm.$cls(`$ezfM.LCIDCV.SmartCowVitalsClientAppDefinition`, ($self) => class SmartCowVitalsClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298663843)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298663843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298663843)
            
            //--TRIMMABLE-BOUNDARY-START(4298663843)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298663843)
            
            static $h = 3696547;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppServiceViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceScopeViewModel, $.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$ezfM.LCIDC.SmartCowVitalsDevice, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$ezfM.LCIDCM.SmartCowVitalsDeviceModel, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceSettings, $.$ezfM.LCIDCS$1.SmartCowVitalsDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceReceivedDataModel, $.$ezfM.LCIDCD.SmartCowVitalsDeviceSendDataModel, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceStatusHandler, $.$ezfM.LCIDCS.ISmartCowVitalsDeviceHubClient, $.$ezfM.LCIDCS.ISmartCowVitalsRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298663843),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3696547,
      "h": 4298663843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298663843)
  ],
  "h": 3696547
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Views.SmartCowVitalsClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Views${separator}SmartCowVitalsClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3696547)
        
        

        //--TRIMMABLE-BOUNDARY-START(3631011)
        $asm.$cls(`$ezfM.LCIDCV.CowVitals`, ($self) => class CowVitals extends $.$ntej.LCICS$2.JWTDashboard$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(55838205859)
            /*string */ get OptimizedComponentName()
            {
                return "cowvitals jwtdashboard";
            }
            //--TRIMMABLE-BOUNDARY-END(55838205859)
            
            //--TRIMMABLE-BOUNDARY-START(60133173155)
            /*string*/ static Route = null;
            //--TRIMMABLE-BOUNDARY-END(60133173155)
            
            //--TRIMMABLE-BOUNDARY-START(12888532899)
            /*string*/ static Description = null;
            //--TRIMMABLE-BOUNDARY-END(12888532899)
            
            //--TRIMMABLE-BOUNDARY-START(47248271267)
            /*string? */ get Name()
            {
                return "CowVitals";
            }
            //--TRIMMABLE-BOUNDARY-END(47248271267)
            
            //--TRIMMABLE-BOUNDARY-START(42953303971)
            /*LeafletMap?*/ map = null;
            //--TRIMMABLE-BOUNDARY-END(42953303971)
            
            //--TRIMMABLE-BOUNDARY-START(51543238563)
            /*ValueTask<bool> */ OnSelected(/*DataListSelection<SmartCowVitalsClientAppDeviceViewModel>*/ selection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543238563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.map !== null)
                {
                    /*var*/ let loca = (selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.Received$1?.Status?.Latitude ?? null) > 0 && (selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.Received$1?.Status?.Longitude ?? null) > 0 ? (() =>
                    {
                        //new $.$fPer.LCFCDG.GeoLocation()
                        const $t1 = $.$fPer.LCFCDG.GeoLocation;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Latitude = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.Received$1.Status.Latitude;
                        $i1.Longitude = selection.Item$1.LCFCCD$1$IDataListItemContext$$$Data.Received$1.Status.Longitude;
                        return $i1;
                    })() : null;
                    if (loca !== null)
                    {
                        this.map.Center = loca;
                    }
                }
                return $.$$.STT.ValueTask.FromResult($.$$.S.Boolean, true);
            }
            //--TRIMMABLE-BOUNDARY-END(51543238563)
            
            //--TRIMMABLE-BOUNDARY-START(8593565603)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593565603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*RenderFragment*/ let view = new $.$mac.MAC.RenderFragment().$ctor(this, super.BuildRenderTree);
                __builder.AddContent$1(0, view);
            }
            //--TRIMMABLE-BOUNDARY-END(8593565603)
            
            //--TRIMMABLE-BOUNDARY-START(64428140451)
            /*RenderFragment */ get View()
            {
                return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenElement(1, "div");
                    __builder2.AddAttribute$5(2, "class", "hv-10 stack");
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "class", "pd bg-card flex");
                    __builder2.OpenElement(5, "h2");
                    __builder2.AddAttribute$5(6, "class", "mgy-a fill");
                    __builder2.AddContent$4(7, this.ViewModel.SelectedServiceViewModel.Model.Title);
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(8, "\r\n            ");
                    __builder2.OpenElement(9, "button");
                    __builder2.AddAttribute$5(10, "class", "mgy-a bg-error mgl pdy-2 pdx-4 corner");
                    __builder2.AddAttribute$7($.$macw.MACW.MouseEventArgs, 11, "onclick", $.$hDPm.LCFCC$1.ComponentExtension.Create$2($.$macw.MACW.MouseEventArgs, $.$mac.MAC.EventCallback.Factory, this, new ($.$$.S.Func$$($.$$.STT.ValueTask))().$ctor(this, this.Reset)));
                    __builder2.AddContent$4(12, "Reset");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(13, "\r\n        ");
                    __builder2.OpenElement(14, "div");
                    __builder2.AddAttribute$5(15, "class", "fill");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCM.LeafletMap, 16);
                    __builder2.AddAttribute$3(17, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        if (this.ViewModel.SelectedServiceViewModel.Devices !== null)
                        {
                            let $en2 = this.ViewModel.SelectedServiceViewModel.Devices.SCG$IEnumerable$$$GetEnumerator();
                            while ($en2.SC$1$IEnumerator$MoveNext())
                            {
                                let dev = $en2.SCG$IEnumerator$$$Current;
                                {
                                    /*var*/ let loca = (dev.Received$1?.Status?.Latitude ?? null) > 0 && (dev.Received$1?.Status?.Longitude ?? null) > 0 ? (() =>
                                    {
                                        //new $.$fPer.LCFCDG.GeoLocation()
                                        const $t3 = $.$fPer.LCFCDG.GeoLocation;
                                        const $i3 = new $t3();
                                        $i3.$ctor$2();
                                        $i3.Latitude = dev.Received$1.Status.Latitude;
                                        $i3.Longitude = dev.Received$1.Status.Longitude;
                                        return $i3;
                                    })() : null;
                                    __builder3.OpenComponent$1($.$hDPm.LCFCCM.MapMarker, 18);
                                    __builder3.AddComponentParameter(19, "Location", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDG.GeoLocation, loca));
                                    __builder3.AddComponentParameter(20, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                                    __builder3.AddComponentParameter(21, "Width", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$typeNullable($.$$.S.Int32), 100), $.$$.S.Int32));
                                    __builder3.AddAttribute$3(22, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenElement(23, "img");
                                        __builder4.AddAttribute$5(24, "src", this.ResolvePath("_content/LivingThing.Core.IOT.Devices.CowVitals/img/cow-map.png", true, false, false));
                                        __builder4.AddAttribute$5(25, "class", "wx-1");
                                        __builder4.CloseElement();
                                    }), $DRVAQj ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3631011,"h":0,"f":17825794}));
                                    __builder3.AddAttribute$3(26, "Popup", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                    {
                                        if ((dev.Received$1?.Status ?? null) !== null)
                                        {
                                            __builder4.OpenElement(27, "div");
                                            __builder4.AddAttribute$5(28, "class", "grid colm-07 gap-1 miwx-25");
                                            __builder4.OpenElement(29, "div");
                                            __builder4.AddAttribute$5(30, "class", "stack pd bd corner bg-chart1-01");
                                            __builder4.OpenElement(31, "img");
                                            __builder4.AddAttribute$5(32, "src", this.ResolvePath("_content/LivingThing.Core.IOT.Devices.CowVitals/img/thermometer.svg", true, false, false));
                                            __builder4.AddAttribute$5(33, "class", "wx-05 mgx-a");
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(34, "\r\n                                ");
                                            __builder4.AddMarkupContent(35, "<span class=\"text-center\">Ambient</span>\r\n                                ");
                                            __builder4.OpenElement(36, "h2");
                                            __builder4.AddAttribute$5(37, "class", "mg-0 text-center");
                                            __builder4.AddContent$4(38, $.$$.S.Single.ToString$3.call(dev.Received$1.Status.AmbientTemperature, "0.##"));
                                            __builder4.AddMarkupContent(39, "\u00B0C");
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(40, "\r\n                            ");
                                            __builder4.OpenElement(41, "div");
                                            __builder4.AddAttribute$5(42, "class", "stack pd bd corner bg-chart1-01");
                                            __builder4.OpenElement(43, "img");
                                            __builder4.AddAttribute$5(44, "src", this.ResolvePath("_content/LivingThing.Core.IOT.Devices.CowVitals/img/thermometer.svg", true, false, false));
                                            __builder4.AddAttribute$5(45, "class", "wx-05 mgx-a");
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(46, "\r\n                                ");
                                            __builder4.AddMarkupContent(47, "<span class=\"text-center\">Body</span>\r\n                                ");
                                            __builder4.OpenElement(48, "h2");
                                            __builder4.AddAttribute$5(49, "class", "mg-0 text-center");
                                            __builder4.AddContent$4(50, $.$$.S.Single.ToString$3.call(dev.Received$1.Status.BodyTemperature, "0.##"));
                                            __builder4.AddMarkupContent(51, "\u00B0C");
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(52, "\r\n                            ");
                                            __builder4.OpenElement(53, "div");
                                            __builder4.AddAttribute$5(54, "class", "stack pd bd corner bg-chart1-01");
                                            /*var*/ let heading_radians = Math.atan2(dev.Received$1.Status.Y, dev.Received$1.Status.X);
                                            /*var*/ let heading_degrees = heading_radians * 180 / 3.141592653589793/*Math.PI*/;
                                            __builder4.OpenElement(55, "img");
                                            __builder4.AddAttribute$5(56, "src", this.ResolvePath("_content/LivingThing.Core.IOT.Devices.CowVitals/img/compass.svg", true, false, false));
                                            __builder4.AddAttribute$5(57, "class", "wx-05 mgx-a");
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(58, "\r\n                                ");
                                            __builder4.AddMarkupContent(59, "<span class=\"text-center\">Orientation</span>\r\n                                ");
                                            __builder4.OpenElement(60, "h2");
                                            __builder4.AddAttribute$5(61, "class", "mg-0 text-center");
                                            __builder4.AddContent$4(62, $.$$.S.Double.ToString$3.call(heading_degrees, "#.##"));
                                            __builder4.AddMarkupContent(63, "\u00B0");
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(64, "\r\n                            ");
                                            __builder4.OpenElement(65, "div");
                                            __builder4.AddAttribute$5(66, "class", "stack pd bd corner bg-chart1-01");
                                            __builder4.OpenElement(67, "img");
                                            __builder4.AddAttribute$5(68, "src", this.ResolvePath("_content/LivingThing.Core.IOT.Devices.CowVitals/img/lungs.svg", true, false, false));
                                            __builder4.AddAttribute$5(69, "class", "wx-05 mgx-a");
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(70, "\r\n                                ");
                                            __builder4.AddMarkupContent(71, "<span class=\"text-center\">Breath Rate</span>\r\n                                ");
                                            __builder4.OpenElement(72, "h2");
                                            __builder4.AddAttribute$5(73, "class", "mg-0 text-center");
                                            __builder4.AddContent$4(74, $.$$.S.Double.ToString$3.call((60000 / dev.Received$1.Status.BreathInterval), "0.#"));
                                            __builder4.AddContent$4(75, "BPM");
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(76, "\r\n                            ");
                                            __builder4.OpenElement(77, "div");
                                            __builder4.AddAttribute$5(78, "class", "stack pd bd corner bg-chart1-01");
                                            __builder4.OpenElement(79, "img");
                                            __builder4.AddAttribute$5(80, "src", this.ResolvePath("_content/LivingThing.Core.IOT.Devices.CowVitals/img/speedometer.svg", true, false, false));
                                            __builder4.AddAttribute$5(81, "class", "wx-05 mgx-a");
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(82, "\r\n                                ");
                                            __builder4.AddMarkupContent(83, "<span class=\"text-center\">Speed</span>\r\n                                ");
                                            __builder4.OpenElement(84, "h2");
                                            __builder4.AddAttribute$5(85, "class", "mg-0 text-center");
                                            __builder4.AddContent$4(86, $.$$.S.Single.ToString$3.call(dev.Received$1.Status.Speed, "0.#"));
                                            __builder4.AddContent$4(87, "mps");
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            __builder4.CloseElement();
                                            __builder4.AddMarkupContent(88, "\r\n                        ");
                                            $.$ezfM._LCIDCVC.TypeInference.CreatePropertySheet_0($.$ezfM.LCIDCD.SmartCowVitalsStatusModel, __builder4, 89, 90, "mgt-5", 91, (dev.Received$1?.Status ?? null));
                                        }
                                    }), $SimJhl ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":3631011,"h":0,"f":17825794}));
                                    __builder3.CloseComponent();
                                }
                            }
                        }
                    }), $bYaBXg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":3631011,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(92, "\r\n        ");
                    __builder2.OpenElement(93, "div");
                    __builder2.AddAttribute$5(94, "class", "hx-21 scroll bg-card");
                    __builder2.AddMarkupContent(95, "<div class=\"pd-1 bdb\"><h3 class=\"text-center mg-0\">Assets</h3></div>\r\n            ");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel), 96);
                    __builder2.AddComponentParameter(97, "Data", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel), this.ViewModel.SelectedServiceViewModel.Devices));
                    __builder2.AddComponentParameter(98, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 65536n | 8388608n), $.$hDPm.LCFCCD$1.DataListFeatures));
                    __builder2.AddComponentParameter(99, "Controller", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$vWqU.LCFCC.IViewController, this));
                    __builder2.AddComponentParameter(100, "li-class", "pd-2");
                    __builder2.AddAttribute$3(101, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel))))().$ctor(this, ( (/*device*/ device) =>
                    {
                        return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                        {
                            __builder3.OpenElement(102, "div");
                            __builder3.AddMultipleAttributes(103, $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$hDPm.LCFCC$1.ComponentExtension.Build($.$hDPm.LCFCC$1.ComponentExtension.AddProperty$1(this.OwnAttributes(null), $.$fPer.LCFC.Stringy.op_Implicit$3("class"), "row pd-1"))));
                            __builder3.OpenElement(104, "div");
                            __builder3.AddAttribute$5(105, "class", "col-a mgx-2");
                            if (device.Data.Model$1.Icon !== null)
                            {
                                __builder3.OpenElement(106, "div");
                                __builder3.AddAttribute$5(107, "class", "round clip mg-a");
                                __builder3.AddAttribute$5(108, "style", "max-height:50px;max-width:50px");
                                __builder3.OpenElement(109, "img");
                                __builder3.AddAttribute$5(110, "class", "mawp-10 mahp-10");
                                __builder3.AddAttribute$4(111, "src", device.Data.Icon);
                                __builder3.CloseElement();
                                __builder3.CloseElement();
                            }
                            else 
                            {
                                __builder3.AddMarkupContent(112, "<i class=\"fsz-45 hx-0 mdi mdi-cow cl-success mgy-a\"></i>");
                            }
                            __builder3.CloseElement();
                            __builder3.AddMarkupContent(113, "\r\n                    ");
                            __builder3.OpenElement(114, "div");
                            __builder3.AddAttribute$5(115, "class", "col-10 pdr-1 stack");
                            __builder3.OpenElement(116, "b");
                            __builder3.AddAttribute$5(117, "class", "d-block mgy-a fsz-small");
                            __builder3.AddContent$4(118, device.Data.Name);
                            __builder3.AddContent$4(119, " (");
                            __builder3.AddContent$4(120, device.Data.Model$1.UniqueId);
                            __builder3.AddMarkupContent(121, ")\r\n                        ");
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                            __builder3.CloseElement();
                        }, $AuzfYh ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":3631011,"h":0,"f":17825794});
                    }), $uhwkId ??= {"r":6881395,"p":[{"n":"device","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel)).$h}],"n":"","d":3631011,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                }, $lJTtPb ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3631011,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(64428140451)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4313208490)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Components.DataList.IDataListSelectableController<LivingThing.Core.IOT.Devices.CowVitals.Views.SmartCowVitalsClientAppDeviceViewModel>.OnSelected(LivingThing.Core.Frameworks.Client.Components.DataList.DataListSelection<LivingThing.Core.IOT.Devices.CowVitals.Views.SmartCowVitalsClientAppDeviceViewModel>)
            LCFCCD$1$IDataListSelectableController$LivingThing$Core$IOT$Devices$CowVitals$Views$SmartCowVitalsClientAppDeviceViewModel$OnSelected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4313208490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnSelected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4313208490)
            
            //--TRIMMABLE-BOUNDARY-START(4298598307)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298598307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298598307)
            
            //--TRIMMABLE-BOUNDARY-START(4298598307)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4298598307)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(60133173155)
                    this.Route = "/CowVitals";
                    //--TRIMMABLE-BOUNDARY-END(60133173155)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12888532899)
                    this.Description = "Cow Tracking and Vitals Monitoring";
                    //--TRIMMABLE-BOUNDARY-END(12888532899)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 3631011;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICS$2.JWTDashboard$$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppViewModel, $.$ezfM.LCIDCM.SmartCowVitalsServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55838205859),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068402083,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3631011,
      "h": 55838205859,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55838205859),
//--TRIMMABLE-BOUNDARY-START(47248271267),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478467491,
        "f": 50364420
      },
      "n": "Name",
      "d": 3631011,
      "h": 47248271267,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(47248271267),
//--TRIMMABLE-BOUNDARY-START(64428140451),
    {
      "p": 6881395,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658336675,
        "f": 50364420
      },
      "n": "View",
      "d": 3631011,
      "h": 64428140451,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(64428140451)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51543238563),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "selection",
          "p": $.$hDPm.LCFCCD$1.DataListSelection$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel).$h
        }
      ],
      "n": "OnSelected",
      "d": 3631011,
      "h": 51543238563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51543238563),
//--TRIMMABLE-BOUNDARY-START(8593565603),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3631011,
      "h": 8593565603,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8593565603)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60133173155),
    {
      "t": 1310721,
      "n": "Route",
      "d": 3631011,
      "h": 60133173155,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60133173155),
//--TRIMMABLE-BOUNDARY-START(12888532899),
    {
      "t": 1310721,
      "n": "Description",
      "d": 3631011,
      "h": 12888532899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888532899),
//--TRIMMABLE-BOUNDARY-START(42953303971),
    {
      "t": 32528042,
      "n": "map",
      "d": 3631011,
      "h": 42953303971,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42953303971)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298598307),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 3631011,
      "h": 4298598307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298598307)
  ],
  "h": 3631011,
  "a": [
    {
      "t": 30640470,
      "c": 25800444246,
      "n": [
        {
          "n": "OpenGraphTitle",
          "v": "Cow Tracking and Vitals Monitoring",
          "t": 1310721
        },
        {
          "n": "OpenGraphDescription",
          "v": "Cow Tracking and Vitals Monitoring",
          "t": 1310721
        },
        {
          "n": "OpenGraphPath",
          "v": "/CowVitals",
          "t": 1310721
        },
        {
          "n": "OpenGraphImage",
          "v": "_content/LivingThing.Core.IOT.Devices.CowVitals/img/cow.jpg",
          "t": 1310721
        },
        {
          "n": "OpenGraphType",
          "v": 2,
          "t": 30902614
        }
      ]
    },
    {
      "t": 4587635,
      "c": 8594522227,
      "a": [
        {
          "v": 68179626,
          "t": 188547073
        }
      ]
    },
    {
      "t": 9896051,
      "c": 8599830643,
      "a": [
        {
          "v": "/CowVitals",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent, $.$hDPm.LCFCCD$1.IDataListSelectableController$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel), $.$hDPm.LCFCCD$1.IDataEnumerableController$$($.$ezfM.LCIDCV.SmartCowVitalsClientAppDeviceViewModel), $.$hDPm.LCFCCD$1.IDataEnumerableController, $.$vWqU.LCFCC.IViewController ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.CowVitals.Views.CowVitals`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}CowVitals${separator}Views${separator}CowVitals`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3631011)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(26531)
