
//--TRIMMABLE-BOUNDARY-START(28323)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $HnZw, $mep, $meca, $mxdi, $mexla, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $meo, $mecm, $mecga, $mec, $mecb, $mefa, $mef, $sifw, $mefp, $mecf, $sipl, $stew, $stj, $mecj, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $slq, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $AWhY, $fPer, $Iaui, $GfYa, $fXpo, $zHIt, $uvJL, $KuVO, $lOHy, $kVHt, $UrvY, $vWqU, $JRhp, $DJRY, $tUcV, $nYKj, $AvdQ, $bMcF, $XBGm, $NXre) {
    "use strict";
    let _;
    let $Zailej;
    let $iJJfQf;
    let $cNDSyg;
    let $RdcIdk;
    let $lpvimd;
    let $pOdkel;
    let $VscFsh;
    let $CHGKJe;
    let $yODyel;
    let $OnJcje;
    let $GXtbGc;
    let $dnRjia;
    let $npDvGj;
    let $XlIHKi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.Custom", 
    {
  "h": 28323,
  "f": "LivingThing.Core.IOT.Devices.Custom",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Custom",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.Custom",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5DdXN0b20uQ3VzdG9tSU9URGV2aWNlIjogew0KICAgICAgIkNhdGVnb3JpZXMiOiBbICJTbWFydCBIb21lIiBdLA0KICAgICAgIk5hbWUiOiAiQ3VzdG9tIERldmljZSIsDQogICAgICAiRGVzY3JpcHRpb24iOiAiQ3VzdG9tIGRldmljZS4iLA0KICAgICAgIkZsYWdzIjogIlB1Ymxpc2hlZCIsDQogICAgICAiSWNvbiI6IHsgIk5hbWUiOiAibWRpIG1kaS1kZXZpY2VzIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiIzhhNmYzMCIsDQogICAgICAiU2VjdXJpdGllcyI6ICJDaGFsbGVuZ2VIYW5kU2hha2VBdXRoZW50aWNhdGlvblByb3RvY29sLEFkdmFuY2VkRW5jcnlwdGlvblN0YW5kYXJkLEVsbGlwdGljQ3VydmVGaXJtd2FyZVVwZGF0ZVNpZ25pbmciLA0KICAgICAgIlByb3RvY29sIjogew0KICAgICAgICAiU3RhdHVzZXMiOiBbDQogICAgICAgICAgew0KICAgICAgICAgICAgIk5hbWUiOiAiU3RhdHVzIiwNCiAgICAgICAgICAgICJQcmVmaXgiOiAyMjEzMCwNCiAgICAgICAgICAgICJEYXRhUG9pbnRzIjogWw0KICAgICAgICAgICAgICB7DQogICAgICAgICAgICAgICAgIk5hbWUiOiAiI1ByZWZpeCIsDQogICAgICAgICAgICAgICAgIlR5cGUiOiAidWludDE2X3QiLA0KICAgICAgICAgICAgICAgICJWYWx1ZSI6IDIyMTMwDQogICAgICAgICAgICAgIH0NCiAgICAgICAgICAgIF0NCiAgICAgICAgICB9DQogICAgICAgIF0NCiAgICAgIH0NCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(93859)
        $asm.$cls(`$LiyH.LCIDC.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179963043)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17179963043)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295061155)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295061155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295061155)
            
            //--TRIMMABLE-BOUNDARY-START(4295061155)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295061155)
            
            static $h = 93859;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179963043),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12884995747,
        "f": 50331649
      },
      "n": "Paths",
      "d": 93859,
      "h": 17179963043,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179963043)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295061155),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 93859,
      "h": 4295061155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295061155)
  ],
  "h": 93859
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Custom.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Custom${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(93859)
        
        

        //--TRIMMABLE-BOUNDARY-START(552611)
        $asm.$cls(`$LiyH.LCIDC.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590487203)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590487203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$LiyH.LCIDC.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$LiyH.LCIDC.CustomIOTDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$LiyH.LCIDC.DefaultCustomIOTDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*s*/ s) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$LiyH.LCIDC.DefaultCustomIOTDeviceFamily, s);
                }, $iJJfQf ??= {"r":26711441,"p":[{"n":"s","p":327718}],"n":"","d":552611,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$LiyH.LCIDC.CustomIOTDevice)))().$ctor(this,  (/**/ s) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$LiyH.LCIDC.DefaultCustomIOTDeviceFamily, s);
                }, $cNDSyg ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$LiyH.LCIDC.CustomIOTDevice).$h,"p":[{"n":"s","p":327718}],"n":"","d":552611,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$XBGm.LCICDC.ICustomIOTDeviceFamilyFactory, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$XBGm.LCICI.IIOTDeviceFamilyProvider, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$LiyH.LCIDC.CustomIOTDeviceFamilyFactory, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamilyProvider))().$ctor(this,  (/*s*/ s) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$LiyH.LCIDC.CustomIOTDeviceFamilyFactory, s);
                }, $RdcIdk ??= {"r":26973585,"p":[{"n":"s","p":327718}],"n":"","d":552611,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICDC.ICustomIOTDeviceFamilyFactory))().$ctor(this,  (/*s*/ s) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$LiyH.LCIDC.CustomIOTDeviceFamilyFactory, s);
                }, $lpvimd ??= {"r":5739921,"p":[{"n":"s","p":327718}],"n":"","d":552611,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$XBGm.LCICI.IIOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$LiyH.LCIDC.CustomIOTDeviceProtocolSelector, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$LiyH.LCIDC.CustomIOTDeviceProtocolSelector, x);
                }, $pOdkel ??= {"r":$.$XBGm.LCIP.IOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":552611,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$LiyH.LCIDC.CustomIOTDeviceProtocolSelector, x);
                }, $VscFsh ??= {"r":$.$XBGm.LCICI.IIOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":552611,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICDC.CustomIOTDeviceStatusModel), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDC.CustomIOTDeviceDataConverter, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICDC.CustomIOTDeviceStatusModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$XBGm.LCICDC.CustomIOTDeviceDataConverter, x);
                }, $CHGKJe ??= {"r":$.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICDC.CustomIOTDeviceStatusModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":552611,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$XBGm.LCICDC.CustomIOTDeviceDataConverter, x);
                }, $yODyel ??= {"r":$.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel).$h,"p":[{"n":"x","p":327718}],"n":"","d":552611,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICDi.iSmartDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICDi.CustomiSmartDeviceDataConverter, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8590487203)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$LiyH.LCIDC.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4295519907)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295519907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295519907)
            
            //--TRIMMABLE-BOUNDARY-START(4295519907)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295519907)
            
            static $h = 552611;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590487203),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 552611,
      "h": 8590487203,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590487203)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295519907),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 552611,
      "h": 4295519907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295519907)
  ],
  "h": 552611
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Custom.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Custom${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(552611)
        
        

        //--TRIMMABLE-BOUNDARY-START(421539)
        $asm.$cls(`$LiyH.LCIDC.CustomIOTDeviceProtocolSelector`, ($self) => class CustomIOTDeviceProtocolSelector extends $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(12885323427)
            /*CustomIOTDeviceFamilyFactory*/ Factory = null;
            //--TRIMMABLE-BOUNDARY-END(12885323427)
            
            //--TRIMMABLE-BOUNDARY-START(8590356131)
            $ctor$2(/*CustomIOTDeviceFamilyFactory*/ factory)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590356131);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Factory = factory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590356131)
            
            //--TRIMMABLE-BOUNDARY-START(38655127203)
            /*CustomIOTDeviceDescriptorProtocol */ GetProtocol(/*IConnectionClient?*/ client, /*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655127203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast($.$sl.SL.Enumerable.Single($.$LiyH.LCIDC.CustomIOTDeviceFamily, (this.Factory), new ($.$$.S.Func$$$($.$LiyH.LCIDC.CustomIOTDeviceFamily, $.$$.S.Boolean))().$ctor(this,  (/*f*/ f) =>
                {
                    return f.Name === (client?.LCFCC$IConnectionClient$Id.FamilyName ?? null) || f.Name === device.LCICI$IIOTDeviceModel$FamilyName;
                }, $Zailej ??= {"r":262145,"p":[{"n":"f","p":290467}],"n":"","d":421539,"h":0,"f":17825794})).Protocol, $.$XBGm.LCICDC.CustomIOTDeviceDescriptorProtocol);
            }
            //--TRIMMABLE-BOUNDARY-END(38655127203)
            
            //--TRIMMABLE-BOUNDARY-START(25770225315)
            /*IOTDeviceProtocolCommands */ GetCommands(/*IIOTDeviceModel*/ device)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770225315);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetProtocol(null, device).GetCommands(device);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770225315)
            
            //--TRIMMABLE-BOUNDARY-START(30065192611)
            /*IIOTDeviceProtocolDecoder<CustomIOTDeviceReceivedDataModel> */ GetDecoder(/*IConnectionClient*/ client)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065192611);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetProtocol(client, null).GetDecoder(client);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065192611)
            
            //--TRIMMABLE-BOUNDARY-START(34360159907)
            /*IIOTDeviceProtocolEncoder<CustomIOTDeviceSendDataModel> */ GetEncoder(/*IConnectionClient*/ client)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360159907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetProtocol(client, null).GetEncoder(client);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360159907)
            
            static $h = 421539;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885323427),
    {
      "p": 356003,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475258019,
        "f": 50331656
      },
      "n": "Factory",
      "d": 421539,
      "h": 12885323427,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(12885323427)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655127203),
    {
      "r": 2266513,
      "p": [
        {
          "n": "client",
          "p": 1568430,
          "f": 65
        },
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetProtocol",
      "d": 421539,
      "h": 38655127203,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655127203),
//--TRIMMABLE-BOUNDARY-START(25770225315),
    {
      "r": 61117841,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": 421539,
      "h": 25770225315,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770225315),
//--TRIMMABLE-BOUNDARY-START(30065192611),
    {
      "r": $.$XBGm.LCICI.IIOTDeviceProtocolDecoder$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel).$h,
      "p": [
        {
          "n": "client",
          "p": 1568430,
          "f": 65
        }
      ],
      "n": "GetDecoder",
      "d": 421539,
      "h": 30065192611,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065192611),
//--TRIMMABLE-BOUNDARY-START(34360159907),
    {
      "r": $.$XBGm.LCICI.IIOTDeviceProtocolEncoder$$($.$XBGm.LCICDC.CustomIOTDeviceSendDataModel).$h,
      "p": [
        {
          "n": "client",
          "p": 1568430,
          "f": 65
        }
      ],
      "n": "GetEncoder",
      "d": 421539,
      "h": 34360159907,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360159907)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590356131),
    {
      "p": [
        {
          "n": "factory",
          "p": 356003
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 421539,
      "h": 8590356131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590356131)
  ],
  "h": 421539
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceProtocol ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Custom.CustomIOTDeviceProtocolSelector`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Custom${separator}CustomIOTDeviceProtocolSelector`; }
        });
        //--TRIMMABLE-BOUNDARY-END(421539)
        
        

        //--TRIMMABLE-BOUNDARY-START(159395)
        $asm.$cls(`$LiyH.LCIDC.CustomIOTDevice`, ($self) => class CustomIOTDevice extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICDC.CustomIOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICDC.CustomIOTDeviceServiceSettings, $.$XBGm.LCICDC.CustomIOTDeviceServiceStates, $.$XBGm.LCICDC.CustomIOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICDC.CustomIOTDeviceModel, $.$XBGm.LCICDC.CustomIOTDeviceSettings, $.$XBGm.LCICDC.CustomIOTDeviceHardwareSettings, $.$XBGm.LCICDC.CustomIOTDeviceStates, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel, $.$XBGm.LCICDC.CustomIOTDeviceCommandModel, $.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel, $.$XBGm.LCICDC.ICustomIOTDeviceStatusHandler, $.$XBGm.LCICDC.ICustomIOTDeviceHubClient, $.$XBGm.LCICDC.ICustomIOTRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4295126691)
            $ctor$2(/*IIOTDeviceFamily<CustomIOTDevice>*/ family, /*IIOTDeviceScope*/ scope, /*CustomIOTDeviceModel*/ model)
            {
                super.$ctor$2(family, scope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295126691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295126691)
            
            static $h = 159395;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$LiyH.LCIDC.CustomIOTDevice, $.$XBGm.LCICDC.CustomIOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICDC.CustomIOTDeviceServiceSettings, $.$XBGm.LCICDC.CustomIOTDeviceServiceStates, $.$XBGm.LCICDC.CustomIOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICDC.CustomIOTDeviceModel, $.$XBGm.LCICDC.CustomIOTDeviceSettings, $.$XBGm.LCICDC.CustomIOTDeviceHardwareSettings, $.$XBGm.LCICDC.CustomIOTDeviceStates, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel, $.$XBGm.LCICDC.CustomIOTDeviceCommandModel, $.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel, $.$XBGm.LCICDC.ICustomIOTDeviceStatusHandler, $.$XBGm.LCICDC.ICustomIOTDeviceHubClient, $.$XBGm.LCICDC.ICustomIOTRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).SmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295126691),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$LiyH.LCIDC.CustomIOTDevice).$h
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 2987409
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 159395,
      "h": 4295126691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295126691)
  ],
  "h": 159395
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Custom.CustomIOTDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Custom${separator}CustomIOTDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(159395)
        
        

        //--TRIMMABLE-BOUNDARY-START(224931)
        $asm.$cls(`$LiyH.LCIDC.CustomIOTDeviceDefinition`, ($self) => class CustomIOTDeviceDefinition extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$LiyH.LCIDC.CustomIOTDevice, $.$XBGm.LCICDC.CustomIOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICDC.CustomIOTDeviceServiceSettings, $.$XBGm.LCICDC.CustomIOTDeviceServiceStates, $.$XBGm.LCICDC.CustomIOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICDC.CustomIOTDeviceModel, $.$XBGm.LCICDC.CustomIOTDeviceSettings, $.$XBGm.LCICDC.CustomIOTDeviceHardwareSettings, $.$XBGm.LCICDC.CustomIOTDeviceStates, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel, $.$XBGm.LCICDC.CustomIOTDeviceCommandModel, $.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel, $.$XBGm.LCICDC.ICustomIOTDeviceStatusHandler, $.$XBGm.LCICDC.ICustomIOTDeviceHubClient, $.$XBGm.LCICDC.ICustomIOTRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4295192227)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295192227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295192227)
            
            //--TRIMMABLE-BOUNDARY-START(4295192227)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295192227)
            
            static $h = 224931;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$LiyH.LCIDC.CustomIOTDevice, $.$XBGm.LCICDC.CustomIOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICDC.CustomIOTDeviceServiceSettings, $.$XBGm.LCICDC.CustomIOTDeviceServiceStates, $.$XBGm.LCICDC.CustomIOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICDC.CustomIOTDeviceModel, $.$XBGm.LCICDC.CustomIOTDeviceSettings, $.$XBGm.LCICDC.CustomIOTDeviceHardwareSettings, $.$XBGm.LCICDC.CustomIOTDeviceStates, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel, $.$XBGm.LCICDC.CustomIOTDeviceCommandModel, $.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel, $.$XBGm.LCICDC.ICustomIOTDeviceStatusHandler, $.$XBGm.LCICDC.ICustomIOTDeviceHubClient, $.$XBGm.LCICDC.ICustomIOTRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295192227),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 224931,
      "h": 4295192227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295192227)
  ],
  "h": 224931
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Custom.CustomIOTDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Custom${separator}CustomIOTDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(224931)
        
        

        //--TRIMMABLE-BOUNDARY-START(487075)
        $asm.$cls(`$LiyH.LCIDC.DefaultCustomIOTDeviceFamily`, ($self) => class DefaultCustomIOTDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$LiyH.LCIDC.CustomIOTDevice, $.$XBGm.LCICDC.CustomIOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICDC.CustomIOTDeviceServiceSettings, $.$XBGm.LCICDC.CustomIOTDeviceServiceStates, $.$XBGm.LCICDC.CustomIOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICDC.CustomIOTDeviceModel, $.$XBGm.LCICDC.CustomIOTDeviceSettings, $.$XBGm.LCICDC.CustomIOTDeviceHardwareSettings, $.$XBGm.LCICDC.CustomIOTDeviceStates, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel, $.$XBGm.LCICDC.CustomIOTDeviceCommandModel, $.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel, $.$XBGm.LCICDC.ICustomIOTDeviceStatusHandler, $.$XBGm.LCICDC.ICustomIOTDeviceHubClient, $.$XBGm.LCICDC.ICustomIOTRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4295454371)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<CustomIOTDeviceReceivedDataModel, CustomIOTDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<CustomIOTDeviceReceivedDataModel, CustomIOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295454371);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295454371)
            
            static $h = 487075;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$LiyH.LCIDC.CustomIOTDevice, $.$XBGm.LCICDC.CustomIOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICDC.CustomIOTDeviceServiceSettings, $.$XBGm.LCICDC.CustomIOTDeviceServiceStates, $.$XBGm.LCICDC.CustomIOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICDC.CustomIOTDeviceModel, $.$XBGm.LCICDC.CustomIOTDeviceSettings, $.$XBGm.LCICDC.CustomIOTDeviceHardwareSettings, $.$XBGm.LCICDC.CustomIOTDeviceStates, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel, $.$XBGm.LCICDC.CustomIOTDeviceCommandModel, $.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel, $.$XBGm.LCICDC.ICustomIOTDeviceStatusHandler, $.$XBGm.LCICDC.ICustomIOTDeviceHubClient, $.$XBGm.LCICDC.ICustomIOTRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295454371),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 487075,
      "h": 4295454371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295454371)
  ],
  "h": 487075
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$LiyH.LCIDC.CustomIOTDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$LiyH.LCIDC.CustomIOTDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Custom.DefaultCustomIOTDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Custom${separator}DefaultCustomIOTDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(487075)
        
        

        //--TRIMMABLE-BOUNDARY-START(290467)
        $asm.$cls(`$LiyH.LCIDC.CustomIOTDeviceFamily`, ($self) => class CustomIOTDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$LiyH.LCIDC.CustomIOTDevice, $.$XBGm.LCICDC.CustomIOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICDC.CustomIOTDeviceServiceSettings, $.$XBGm.LCICDC.CustomIOTDeviceServiceStates, $.$XBGm.LCICDC.CustomIOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICDC.CustomIOTDeviceModel, $.$XBGm.LCICDC.CustomIOTDeviceSettings, $.$XBGm.LCICDC.CustomIOTDeviceHardwareSettings, $.$XBGm.LCICDC.CustomIOTDeviceStates, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel, $.$XBGm.LCICDC.CustomIOTDeviceCommandModel, $.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel, $.$XBGm.LCICDC.ICustomIOTDeviceStatusHandler, $.$XBGm.LCICDC.ICustomIOTDeviceHubClient, $.$XBGm.LCICDC.ICustomIOTRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4295257763)
            $ctor$1(/*IOTDeviceDescriptor<IOTServiceTierType, IOTServiceFeatureType>*/ descriptor, /*IOTDeviceProtocol<CustomIOTDeviceReceivedDataModel, CustomIOTDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<CustomIOTDeviceReceivedDataModel, CustomIOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$2(descriptor, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295257763);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295257763)
            
            //--TRIMMABLE-BOUNDARY-START(8590225059)
            /*IOTCustomDeviceDescriptorModel */ get LCICDC$ICustomIODeviceFamily$DeviceDescriptor()
            {
                return $.$cast(super.DeviceDescriptor, $.$XBGm.LCICM.IOTCustomDeviceDescriptorModel);
            }
            //--TRIMMABLE-BOUNDARY-END(8590225059)
            
            static $h = 290467;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$LiyH.LCIDC.CustomIOTDevice, $.$XBGm.LCICDC.CustomIOTServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICDC.CustomIOTDeviceServiceSettings, $.$XBGm.LCICDC.CustomIOTDeviceServiceStates, $.$XBGm.LCICDC.CustomIOTDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$XBGm.LCICDC.CustomIOTDeviceModel, $.$XBGm.LCICDC.CustomIOTDeviceSettings, $.$XBGm.LCICDC.CustomIOTDeviceHardwareSettings, $.$XBGm.LCICDC.CustomIOTDeviceStates, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel, $.$XBGm.LCICDC.CustomIOTDeviceCommandModel, $.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel, $.$XBGm.LCICDC.ICustomIOTDeviceStatusHandler, $.$XBGm.LCICDC.ICustomIOTDeviceHubClient, $.$XBGm.LCICDC.ICustomIOTRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590225059),
    {
      "p": 34968977,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180159651,
        "f": 50331650
      },
      "n": "{5674385}.DeviceDescriptor",
      "o": "LCICDC$ICustomIODeviceFamily$DeviceDescriptor",
      "d": 290467,
      "h": 8590225059,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(8590225059)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295257763),
    {
      "p": [
        {
          "n": "descriptor",
          "p": $.$XBGm.LCICM.IOTDeviceDescriptor$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType).$h
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$XBGm.LCICDC.CustomIOTDeviceReceivedDataModel, $.$XBGm.LCICDC.CustomIOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 290467,
      "h": 4295257763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295257763)
  ],
  "h": 290467
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$LiyH.LCIDC.CustomIOTDevice), $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$LiyH.LCIDC.CustomIOTDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$XBGm.LCICDC.ICustomIODeviceFamily, $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Custom.CustomIOTDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Custom${separator}CustomIOTDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(290467)
        
        

        //--TRIMMABLE-BOUNDARY-START(356003)
        $asm.$cls(`$LiyH.LCIDC.CustomIOTDeviceFamilyFactory`, ($self) => class CustomIOTDeviceFamilyFactory extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42950028963)
            /*IEnumerable<IIOTDeviceProtocol>*/ Protocols = null;
            //--TRIMMABLE-BOUNDARY-END(42950028963)
            
            //--TRIMMABLE-BOUNDARY-START(8590290595)
            $ctor$1(/*IScopedServiceFactory*/ serviceFactory, /*IEnumerable<IIOTDeviceProtocol>*/ protocols)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590290595);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Protocols = protocols;
                    $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this,  () =>
                    {
                        return this.GetFamilies(serviceFactory, 0);
                    }, $OnJcje ??= {"r":178454529,"n":"","d":356003,"h":0,"f":17825794}));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590290595)
            
            //--TRIMMABLE-BOUNDARY-START(17180225187)
            /*List<CustomIOTDeviceFamily>*/ Families = null;
            //--TRIMMABLE-BOUNDARY-END(17180225187)
            
            //--TRIMMABLE-BOUNDARY-START(60129898147)
            /*IEnumerator<CustomIOTDeviceFamily> */ SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129898147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Families.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(60129898147)
            
            //--TRIMMABLE-BOUNDARY-START(55834930851)
            /*IEnumerator<IIOTDeviceFamily> */ SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834930851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.N.InterfaceVarianceStubHandler.Create(this.Families.GetEnumerator(), $.$$.SCG.IEnumerator$$($.$LiyH.LCIDC.CustomIOTDeviceFamily), $.$$.SCG.IEnumerator$$($.$XBGm.LCICI.IIOTDeviceFamily));
            }
            //--TRIMMABLE-BOUNDARY-END(55834930851)
            
            //--TRIMMABLE-BOUNDARY-START(64424865443)
            /*System.Collections.IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424865443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Families.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(64424865443)
            
            //--TRIMMABLE-BOUNDARY-START(34360094371)
            /*IEnumerator<ICustomIODeviceFamily> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360094371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.N.InterfaceVarianceStubHandler.Create(this.Families.GetEnumerator(), $.$$.SCG.IEnumerator$$($.$LiyH.LCIDC.CustomIOTDeviceFamily), $.$$.SCG.IEnumerator$$($.$XBGm.LCICDC.ICustomIODeviceFamily));
            }
            //--TRIMMABLE-BOUNDARY-END(34360094371)
            
            //--TRIMMABLE-BOUNDARY-START(30065127075)
            /*CustomIOTDeviceFamily? */ GetDefault()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065127075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.SingleOrDefault$1($.$LiyH.LCIDC.CustomIOTDeviceFamily, this.Families, new ($.$$.S.Func$$$($.$LiyH.LCIDC.CustomIOTDeviceFamily, $.$$.S.Boolean))().$ctor(this,  (/*f*/ f) =>
                {
                    return f.Name === "Default";
                }, $GXtbGc ??= {"r":262145,"p":[{"n":"f","p":290467}],"n":"","d":356003,"h":0,"f":17825794})) ?? $.$sl.SL.Enumerable.FirstOrDefault$3($.$LiyH.LCIDC.CustomIOTDeviceFamily, this.Families);
            }
            //--TRIMMABLE-BOUNDARY-END(30065127075)
            
            //--TRIMMABLE-BOUNDARY-START(12885257891)
            /*void */ AddFamilies(/*IEnumerable<IOTCustomDeviceDescriptorModel>*/ descriptors, /*IScopedServiceFactory*/ serviceFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885257891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en1 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let descriptor = $en1.SCG$IEnumerator$$$Current;
                    {
                        descriptor.Description$1 ??= "Custom Device";
                        /*var*/ let family = $.$sl.SL.Enumerable.SingleOrDefault$1($.$LiyH.LCIDC.CustomIOTDeviceFamily, this.Families, new ($.$$.S.Func$$$($.$LiyH.LCIDC.CustomIOTDeviceFamily, $.$$.S.Boolean))().$ctor(this,  (/*f*/ f) =>
                        {
                            return ($.$cast(f.DeviceDescriptor, $.$XBGm.LCICM.IOTCustomDeviceDescriptorModel)).Identifier.Equals$2(descriptor.Identifier);
                        }, $dnRjia ??= {"r":262145,"p":[{"n":"f","p":290467}],"n":"","d":356003,"h":0,"f":17825794}));
                        if (family !== null)
                        {
                            family.UpdateDescriptor(descriptor);
                            ($.$cast(family.Protocol, $.$XBGm.LCICDC.CustomIOTDeviceDescriptorProtocol)).UpdateDescriptor(descriptor);
                        }
                        else 
                        {
                            /*var*/ let protocol = new $.$XBGm.LCICDC.CustomIOTDeviceDescriptorProtocol().$ctor$2(descriptor, this.Protocols);
                            this.Families.Add(new $.$LiyH.LCIDC.CustomIOTDeviceFamily().$ctor$1(descriptor, protocol, serviceFactory.LCFCS$3$IScopedServiceFactory$ResolveRequired$1($.$XBGm.LCICDC.CustomIOTDeviceDataConverter, null, null)));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885257891)
            
            //--TRIMMABLE-BOUNDARY-START(38655061667)
            /*Task *//*async*/  GetFamilies(/*IScopedServiceFactory*/ serviceFactory, /*int*/ tries)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655061667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (tries > 3)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    try
                    {
                        /*var*/ let server = serviceFactory.LCFCS$3$IScopedServiceFactory$Resolve$1($.$uvJL.LCFCR.IServerRemoteService, null, null);
                        /*var*/ let context = serviceFactory.LCFCS$3$IScopedServiceFactory$Resolve$1($.$fPer.LCFC.IApplicationContextProvider, null, null);
                        /*IEnumerable<IOTCustomDeviceDescriptorModel>?*/ let fs = null;
                        if (context.LCFC$IApplicationContextProvider$IsMobile)
                        {
                            let $t2, $r2;
                            /*var*/ let localStorage = serviceFactory.LCFCS$3$IScopedServiceFactory$Resolve$1($.$fPer.LCFCS$5.IPersistentStorageService, null, null);
                            fs = (($t2 = $.$fPer.LCFCS$5.LocalStorageExtension.Refresh($.$fPer.LCFCD.WireTransportManyModel$$($.$XBGm.LCICM.IOTCustomDeviceDescriptorModel), localStorage, this, "families", new ($.$$.S.Func$$($.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$($.$XBGm.LCICM.IOTCustomDeviceDescriptorModel))))().$ctor(this,  () =>
                            {
                                return $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTCustomDeviceDescriptorModel, server, new $.$fPer.LCFCD.DataFilter().$ctor$1(), null);
                            }, $npDvGj ??= {"r":$.$$.STT.ValueTask$$($.$fPer.LCFCD.WireTransportManyModel$$($.$XBGm.LCICM.IOTCustomDeviceDescriptorModel)).$h,"n":"","d":356003,"h":0,"f":17825794}), new ($.$$.S.Action$$($.$fPer.LCFCD.WireTransportManyModel$$($.$XBGm.LCICM.IOTCustomDeviceDescriptorModel)))().$ctor(this,  (/*fs*/ fs) =>
                            {
                                this.AddFamilies(fs.AsEnumerable(), serviceFactory);
                                serviceFactory.S$IDisposable$Dispose();
                            }, $XlIHKi ??= {"r":65537,"p":[{"n":"fs","p":$.$fPer.LCFCD.WireTransportManyModel$$($.$XBGm.LCICM.IOTCustomDeviceDescriptorModel).$h}],"n":"","d":356003,"h":0,"f":17825794})), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)))).AsEnumerable();
                        }
                        else 
                        {
                            let $t3, $r3;
                            fs = (($t3 = $.$uvJL.LCFCR.ServerRemoteServiceExtension.ReadMany($.$XBGm.LCICM.IOTCustomDeviceDescriptorModel, server, new $.$fPer.LCFCD.DataFilter().$ctor$22("familyFactory", null, new $.$fPer.LCFCD.CompositeDataId(), null, null, null, null, null, new $.$fPer.LCFCD.Sorting(), null), null), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)))).AsEnumerable();
                        }
                        if (fs !== null)
                        {
                            this.AddFamilies(fs, serviceFactory);
                        }
                    }
                    catch(e)
                    {
                        let $t4, $r4;
                        $.$fPer.LCFCL.LoggingFactory.LogException(e, "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.Custom\\CustomIOTDeviceFamilyFactory.cs", "GetFamilies", 115);
                        ($t4 = $.$$.STT.Task.Delay$1(1000), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        _ = this.GetFamilies(serviceFactory, ((tries + 1) | 0));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38655061667)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<LivingThing.Core.IOT.Common.Devices.Custom.ICustomIODeviceFamily>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180225187)
                this.Families = new ($.$$.SCG.List$$($.$LiyH.LCIDC.CustomIOTDeviceFamily))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17180225187)
                
            }
            static $h = 356003;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180225187),
    {
      "p": $.$$.SCG.List$$($.$LiyH.LCIDC.CustomIOTDeviceFamily).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770159779,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51539963555,
        "f": 83886082
      },
      "n": "Families",
      "d": 356003,
      "h": 17180225187,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180225187)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360094371),
    {
      "r": $.$$.SCG.IEnumerator$$($.$XBGm.LCICDC.ICustomIODeviceFamily).$h,
      "n": "GetEnumerator",
      "d": 356003,
      "h": 34360094371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360094371),
//--TRIMMABLE-BOUNDARY-START(30065127075),
    {
      "r": 290467,
      "n": "GetDefault",
      "d": 356003,
      "h": 30065127075,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065127075),
//--TRIMMABLE-BOUNDARY-START(12885257891),
    {
      "r": 65537,
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICM.IOTCustomDeviceDescriptorModel).$h
        },
        {
          "n": "serviceFactory",
          "p": 61966678
        }
      ],
      "n": "AddFamilies",
      "d": 356003,
      "h": 12885257891,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885257891),
//--TRIMMABLE-BOUNDARY-START(38655061667),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serviceFactory",
          "p": 61966678
        },
        {
          "n": "tries",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetFamilies",
      "d": 356003,
      "h": 38655061667,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(38655061667)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950028963),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocol).$h,
      "n": "Protocols",
      "d": 356003,
      "h": 42950028963,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950028963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590290595),
    {
      "p": [
        {
          "n": "serviceFactory",
          "p": 61966678
        },
        {
          "n": "protocols",
          "p": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocol).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 356003,
      "h": 8590290595,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590290595)
  ],
  "h": 356003
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerable$$($.$LiyH.LCIDC.CustomIOTDeviceFamily), $.$XBGm.LCICDC.ICustomIOTDeviceFamilyFactory, $.$XBGm.LCICI.IIOTDeviceFamilyProvider, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceFamily), $.$$.SCG.IEnumerable$$($.$XBGm.LCICDC.ICustomIODeviceFamily), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.Custom.CustomIOTDeviceFamilyFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}Custom${separator}CustomIOTDeviceFamilyFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(356003)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.DynamicExpresso.Core", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Linq.Queryable", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Devices"));
})();
//--TRIMMABLE-BOUNDARY-END(28323)
