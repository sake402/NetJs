
//--TRIMMABLE-BOUNDARY-START(26748)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $bHuH, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $CKkmYg;
    let $xgkqwa;
    let $QYxHJd;
    let $wbOxYi;
    let $MywGda;
    let $WNiCfi;
    let $vAKMeg;
    let $YaJkTk;
    let $qwqCde;
    let $NeqOge;
    let $HjDFUk;
    let $Xanamc;
    let $wNPkMj;
    let $TxEwse;
    let $rwjpSk;
    let $LxWkff;
    let $NRLHAi;
    let $hRpAAg;
    let $GQTVog;
    let $uCtVWf;
    let $PSjqGc;
    let $sjXkal;
    let $tsZfxc;
    let $fabwBa;
    let $qCAYca;
    let $BJNtgh;
    let $MFznxg;
    let $zUIdQe;
    let $ceAAKc;
    let $QziUyh;
    let $wLQvEb;
    let $SxNuJa;
    let $ZMXOIa;
    let $rNkQLg;
    let $yhhgtc;
    let $clFtsc;
    let $eYVFWb;
    let $vqNdmf;
    let $sIJWXi;
    let $LIunTk;
    let $ZDeakf;
    let $zWMGKg;
    let $VrReVc;
    let $QnAXme;
    let $qrDcIa;
    let $InYyLd;
    let $iWOrzj;
    let $AHrbsg;
    let $xjUpbd;
    let $TTyIvd;
    let $HUzNGb;
    let $dwnUfj;
    let $quuLDh;
    let $tQPBgk;
    let $pvIPMd;
    let $QHoARe;
    let $eBDUOd;
    let $JaVpDa;
    let $wAcPKk;
    let $YnBLba;
    let $CxfPej;
    let $roDJsc;
    let $GTeHPf;
    let $GqieNk;
    let $KxSIyb;
    let $BWZGDe;
    let $mkdCUh;
    let $NYShGa;
    let $lrBXzf;
    let $kREauh;
    let $WmCZcb;
    let $BprDOa;
    let $dWYQAh;
    let $grhVie;
    let $htNekf;
    let $QtbShd;
    let $QmfUfi;
    let $UScoWj;
    let $uTsjlh;
    let $aPZzpg;
    let $GkKBEj;
    let $cZaypb;
    let $exkKie;
    let $JsnUFa;
    let $kSylqc;
    let $zKKlIb;
    let $wnIzLg;
    let $sGiyAb;
    let $yfchJc;
    let $NIDhEa;
    let $UwYkIg;
    let $hCRwHk;
    let $JeXFof;
    let $eHCkSk;
    let $KxBCqk;
    let $DNadAa;
    let $xuYtMk;
    let $vHfdrk;
    let $thaaBf;
    let $WazQFj;
    let $KABUwi;
    let $QjqkNk;
    let $pduarg;
    let $RbpOKb;
    let $IhqZeb;
    let $zbpBDg;
    let $Wsddnk;
    let $ThqCIg;
    let $rpGKok;
    let $DmQgqd;
    let $GmGjdh;
    let $yvsoXi;
    let $DUOLPb;
    let $ZmQDPk;
    let $xXeRUi;
    let $lqyuza;
    let $HVWJEh;
    let $ObRChk;
    let $fkpVxc;
    let $DeUCnk;
    let $igxeyg;
    let $lyBVbf;
    let $tQBHZb;
    let $UeCMna;
    let $ypKtTd;
    let $iCBLuj;
    let $vSYugk;
    let $XfkYOh;
    let $LKNxgf;
    let $mCNiAg;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.EagleEye", 
    {
  "h": 26748,
  "f": "LivingThing.Core.IOT.Devices.EagleEye",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.EagleEye",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.EagleEye",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5FYWdsZUV5ZS5FYWdsZUV5ZURldmljZSI6IHsNCiAgICAgICJDYXRlZ29yaWVzIjogWyAiU21hcnQgSG9tZSIgXSwNCiAgICAgICJOYW1lIjogIkVhZ2xlRXllIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJNaW5pYXR1cmUgY2FtZXJhIGZvciBzdXJ2ZWlsbGFuY2UiLA0KICAgICAgIlVuaXRDb3N0Ijogew0KICAgICAgICAiVmFsdWUiOiAxMDAwMCwNCiAgICAgICAgIlVuaXQiOiAiTmFpcmEiDQogICAgICB9LA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktY2FtZXJhIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q3N2JiYSIsDQogICAgICAiZkZsYWdzIjogIkZlYXR1cmVkLFB1Ymxpc2hlZCIsDQogICAgICAiU2VjdXJpdGllcyI6ICJDaGFsbGVuZ2VIYW5kU2hha2VBdXRoZW50aWNhdGlvblByb3RvY29sLEFkdmFuY2VkRW5jcnlwdGlvblN0YW5kYXJkLEVsbGlwdGljQ3VydmVGaXJtd2FyZVVwZGF0ZVNpZ25pbmciLA0KICAgICAgIlN0YXR1c05hbWVzIjogIlN0YXR1cy5TdGF0dXMiDQogICAgfQ0KICB9DQp9"
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(3958908)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeRecordingsResponseModelCustomAttributesProvider`, ($self) => class EagleEyeRecordingsResponseModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298926204)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298926204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandResponseModelCustomAttributesProvider$$($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298926204)
            
            static $h = 3958908;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298926204),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3958908,
      "h": 4298926204,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298926204)
  ],
  "h": 3958908
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeRecordingsResponseModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeRecordingsResponseModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3958908)
        
        

        //--TRIMMABLE-BOUNDARY-START(2123900)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceModelCustomAttributesProvider`, ($self) => class EagleEyeDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297091196)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297091196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297091196)
            
            static $h = 2123900;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297091196),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2123900,
      "h": 4297091196,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297091196)
  ],
  "h": 2123900
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2123900)
        
        

        //--TRIMMABLE-BOUNDARY-START(5990524)
        $asm.$cls(`$QPfZ.LCIDES$1.EagleEyeClickCommandCustomAttributesProvider`, ($self) => class EagleEyeClickCommandCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300957820)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300957820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4300957820)
            
            static $h = 5990524;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4300957820),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5990524,
      "h": 4300957820,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4300957820)
  ],
  "h": 5990524
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeClickCommandCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Settings${separator}EagleEyeClickCommandCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5990524)
        
        

        //--TRIMMABLE-BOUNDARY-START(1599612)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelCustomAttributesProvider`, ($self) => class EagleEyeRecordingsControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296566908)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296566908)
            
            //--TRIMMABLE-BOUNDARY-START(8591534204)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591534204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Start", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Count", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            $i4.ConvertType = ($.$$.S.Byte.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $CKkmYg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1599612,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $xgkqwa ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1599612,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591534204)
            
            static $h = 1599612;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591534204),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1599612,
      "h": 8591534204,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591534204)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296566908),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1599612,
      "h": 4296566908,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296566908)
  ],
  "h": 1599612
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeRecordingsControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1599612)
        
        

        //--TRIMMABLE-BOUNDARY-START(3827836)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeLogTypeCustomAttributesProvider`, ($self) => class EagleEyeLogTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298795132)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298795132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4298795132)
            
            static $h = 3827836;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298795132),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3827836,
      "h": 4298795132,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298795132)
  ],
  "h": 3827836
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeLogTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3827836)
        
        

        //--TRIMMABLE-BOUNDARY-START(2648188)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceScopeModelCustomAttributesProvider`, ($self) => class EagleEyeDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297615484)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297615484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297615484)
            
            static $h = 2648188;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297615484),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2648188,
      "h": 4297615484,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297615484)
  ],
  "h": 2648188
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2648188)
        
        

        //--TRIMMABLE-BOUNDARY-START(4483196)
        $asm.$cls(`$QPfZ.LCIDEM.EagleFramePerSecondCustomAttributesProvider`, ($self) => class EagleFramePerSecondCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299450492)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299450492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4299450492)
            
            static $h = 4483196;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299450492),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4483196,
      "h": 4299450492,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299450492)
  ],
  "h": 4483196
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleFramePerSecondCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleFramePerSecondCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4483196)
        
        

        //--TRIMMABLE-BOUNDARY-START(5138556)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeStatusModelCustomAttributesProvider`, ($self) => class EagleEyeStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4300105852)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4300105852)
            
            //--TRIMMABLE-BOUNDARY-START(8595073148)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595073148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEMS.EagleEyeStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("State", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Format=Bool(YES, NO)"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Fps", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.Byte.$type);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Format=Remove(^0$)", "Icon=Camera"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEMS.EagleEyeStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $QYxHJd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":5138556,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $wbOxYi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":5138556,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8595073148)
            
            static $h = 5138556;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595073148),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 5138556,
      "h": 8595073148,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595073148)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4300105852),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 5138556,
      "h": 4300105852,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4300105852)
  ],
  "h": 5138556
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5138556)
        
        

        //--TRIMMABLE-BOUNDARY-START(1992828)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeBroadcastPeerMessagesCustomAttributesProvider`, ($self) => class EagleEyeBroadcastPeerMessagesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296960124)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296960124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296960124)
            
            static $h = 1992828;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296960124),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1992828,
      "h": 4296960124,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296960124)
  ],
  "h": 1992828
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeBroadcastPeerMessagesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeBroadcastPeerMessagesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1992828)
        
        

        //--TRIMMABLE-BOUNDARY-START(1861756)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeActionsCustomAttributesProvider`, ($self) => class EagleEyeActionsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296829052)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296829052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296829052)
            
            static $h = 1861756;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296829052),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1861756,
      "h": 4296829052,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296829052)
  ],
  "h": 1861756
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeActionsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeActionsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1861756)
        
        

        //--TRIMMABLE-BOUNDARY-START(747644)
        $asm.$cls(`$QPfZ.LCIDE.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295714940)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295714940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEMC.EagleEyeCameraCommand.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEMC.EagleEyeCameraCommandCustomAttributesProvider, $.$QPfZ.LCIDEMC.EagleEyeCameraCommandCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEMC.EagleEyeCameraControlModelCustomAttributesProvider, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEMC.EagleEyeControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEMC.EagleEyeControlModelCustomAttributesProvider, $.$QPfZ.LCIDEMC.EagleEyeControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelCustomAttributesProvider, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeActions.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeActionsCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeActionsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeBroadcastPeerMessages.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeBroadcastPeerMessagesCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeBroadcastPeerMessagesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeDeviceModelCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModelCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeDeviceScopeModelCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeFeatures.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeFeaturesCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeFeaturesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeFlags.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeFlagsCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeFlagsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeFrameSize.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeFrameSizeCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeFrameSizeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeLogType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeLogTypeCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeLogTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeLogModelCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModelCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleEyeServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleEyeServiceModelCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleEyeServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEM.EagleFramePerSecond.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEM.EagleFramePerSecondCustomAttributesProvider, $.$QPfZ.LCIDEM.EagleFramePerSecondCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEMS.EagleEyeFileModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEMS.EagleEyeFileModelCustomAttributesProvider, $.$QPfZ.LCIDEMS.EagleEyeFileModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEMS.EagleEyeRecordingsModelCustomAttributesProvider, $.$QPfZ.LCIDEMS.EagleEyeRecordingsModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDEMS.EagleEyeStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDEMS.EagleEyeStatusModelCustomAttributesProvider, $.$QPfZ.LCIDEMS.EagleEyeStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsCustomAttributesProvider, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDES$1.EagleEyeClickCommand.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDES$1.EagleEyeClickCommandCustomAttributesProvider, $.$QPfZ.LCIDES$1.EagleEyeClickCommandCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$QPfZ.LCIDES$1.EagleEyeDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsCustomAttributesProvider, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295714940)
            
            static $h = 747644;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295714940),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 747644,
      "h": 4295714940,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295714940)
  ],
  "h": 747644
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(747644)
        
        

        //--TRIMMABLE-BOUNDARY-START(4221052)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeServiceModelCustomAttributesProvider`, ($self) => class EagleEyeServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299188348)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299188348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299188348)
            
            static $h = 4221052;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299188348),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4221052,
      "h": 4299188348,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299188348)
  ],
  "h": 4221052
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4221052)
        
        

        //--TRIMMABLE-BOUNDARY-START(3172476)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeFeaturesCustomAttributesProvider`, ($self) => class EagleEyeFeaturesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298139772)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298139772)
            
            //--TRIMMABLE-BOUNDARY-START(8593107068)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593107068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEM.EagleEyeFeaturesCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEM.EagleEyeFeaturesCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $MywGda ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3172476,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $WNiCfi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3172476,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593107068)
            
            static $h = 3172476;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593107068),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3172476,
      "h": 8593107068,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593107068)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298139772),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3172476,
      "h": 4298139772,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298139772)
  ],
  "h": 3172476
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeFeaturesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeFeaturesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3172476)
        
        

        //--TRIMMABLE-BOUNDARY-START(1337468)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeControlModelCustomAttributesProvider`, ($self) => class EagleEyeControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296304764)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296304764)
            
            //--TRIMMABLE-BOUNDARY-START(8591272060)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591272060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEMC.EagleEyeControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Set", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Flags", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LogTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (5);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEMC.EagleEyeControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $qwqCde ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1337468,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $NeqOge ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1337468,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591272060)
            
            static $h = 1337468;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591272060),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1337468,
      "h": 8591272060,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591272060)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296304764),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1337468,
      "h": 4296304764,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296304764)
  ],
  "h": 1337468
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1337468)
        
        

        //--TRIMMABLE-BOUNDARY-START(4876412)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeRecordingsModelCustomAttributesProvider`, ($self) => class EagleEyeRecordingsModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299843708)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299843708)
            
            //--TRIMMABLE-BOUNDARY-START(8594811004)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594811004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEMS.EagleEyeRecordingsModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Files", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.Flags = (65536);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEMS.EagleEyeRecordingsModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $vAKMeg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4876412,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $YaJkTk ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4876412,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594811004)
            
            static $h = 4876412;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594811004),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4876412,
      "h": 8594811004,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594811004)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299843708),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4876412,
      "h": 4299843708,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299843708)
  ],
  "h": 4876412
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeRecordingsModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeRecordingsModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4876412)
        
        

        //--TRIMMABLE-BOUNDARY-START(3303548)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeFlagsCustomAttributesProvider`, ($self) => class EagleEyeFlagsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298270844)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298270844)
            
            //--TRIMMABLE-BOUNDARY-START(8593238140)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593238140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEM.EagleEyeFlagsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$$.S.FlagsAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.FlagsAttribute), [(() =>
                        {
                            //new $.$$.S.FlagsAttribute()
                            const $t3 = $.$$.S.FlagsAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$2();
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$$.S.FlagsAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEM.EagleEyeFlagsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $HjDFUk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3303548,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $Xanamc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3303548,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593238140)
            
            static $h = 3303548;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593238140),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3303548,
      "h": 8593238140,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593238140)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298270844),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3303548,
      "h": 4298270844,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298270844)
  ],
  "h": 3303548
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeFlagsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeFlagsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3303548)
        
        

        //--TRIMMABLE-BOUNDARY-START(1075324)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeCameraControlModelCustomAttributesProvider`, ($self) => class EagleEyeCameraControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296042620)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296042620)
            
            //--TRIMMABLE-BOUNDARY-START(8591009916)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591009916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEMC.EagleEyeCameraControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Control", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (3);
                            $i3.ConvertType = ($.$$.S.Byte.$type);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Value", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (4);
                            $i4.ConvertType = ($.$$.S.Byte.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEMC.EagleEyeCameraControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $wNPkMj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1075324,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $TxEwse ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1075324,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591009916)
            
            static $h = 1075324;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591009916),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1075324,
      "h": 8591009916,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591009916)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296042620),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1075324,
      "h": 4296042620,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296042620)
  ],
  "h": 1075324
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeCameraControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1075324)
        
        

        //--TRIMMABLE-BOUNDARY-START(2910332)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelCustomAttributesProvider`, ($self) => class EagleEyeDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297877628)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297877628)
            
            //--TRIMMABLE-BOUNDARY-START(8592844924)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592844924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Camera", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (13432);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $uCtVWf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2910332,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $PSjqGc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2910332,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592844924)
            
            static $h = 2910332;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592844924),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2910332,
      "h": 8592844924,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592844924)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297877628),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2910332,
      "h": 4297877628,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297877628)
  ],
  "h": 2910332
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2910332)
        
        

        //--TRIMMABLE-BOUNDARY-START(157820)
        $asm.$cls(`$QPfZ.LCIDE._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295125116)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295125116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$QPfZ.LCIDE.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295125116)
            
            static $h = 157820;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295125116),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 157820,
      "h": 4295125116,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295125116)
  ],
  "h": 157820
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(157820)
        
        

        //--TRIMMABLE-BOUNDARY-START(813180)
        $asm.$cls(`$QPfZ.LCIDE.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295780476)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295780476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295780476)
            
            static $h = 813180;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295780476),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 813180,
      "h": 4295780476,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295780476)
  ],
  "h": 813180
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(813180)
        
        

        //--TRIMMABLE-BOUNDARY-START(6383740)
        $asm.$cls(`$QPfZ.LCIDES$1.EagleEyeDeviceSettingsCustomAttributesProvider`, ($self) => class EagleEyeDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301351036)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4301351036)
            
            //--TRIMMABLE-BOUNDARY-START(8596318332)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596318332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Invert", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (256);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("OnClick", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (257);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $hRpAAg ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":6383740,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $GQTVog ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":6383740,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8596318332)
            
            static $h = 6383740;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596318332),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6383740,
      "h": 8596318332,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596318332)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4301351036),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 6383740,
      "h": 4301351036,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4301351036)
  ],
  "h": 6383740
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Settings${separator}EagleEyeDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6383740)
        
        

        //--TRIMMABLE-BOUNDARY-START(5007484)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeRecordingsModelTypeDescriptorBuilder`, ($self) => class EagleEyeRecordingsModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594942076)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594942076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEMS.EagleEyeRecordingsModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEMS.EagleEyeRecordingsModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeRecordingsModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $BJNtgh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5007484,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594942076)
            
            //--TRIMMABLE-BOUNDARY-START(4299974780)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299974780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299974780)
            
            //--TRIMMABLE-BOUNDARY-START(4299974780)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299974780)
            
            static $h = 5007484;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594942076),
    {
      "r": 65537,
      "n": "Register",
      "d": 5007484,
      "h": 8594942076,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594942076)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299974780),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5007484,
      "h": 4299974780,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299974780)
  ],
  "h": 5007484
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeRecordingsModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeRecordingsModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5007484)
        
        

        //--TRIMMABLE-BOUNDARY-START(3696764)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptorBuilder`, ($self) => class EagleEyeLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593631356)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593631356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $kREauh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3696764,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEM.EagleEyeLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593631356)
            
            //--TRIMMABLE-BOUNDARY-START(4298664060)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298664060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298664060)
            
            //--TRIMMABLE-BOUNDARY-START(4298664060)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298664060)
            
            static $h = 3696764;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593631356),
    {
      "r": 65537,
      "n": "Register",
      "d": 3696764,
      "h": 8593631356,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593631356)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298664060),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3696764,
      "h": 4298664060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298664060)
  ],
  "h": 3696764
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3696764)
        
        

        //--TRIMMABLE-BOUNDARY-START(4614268)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeFileModelCustomAttributesProvider`, ($self) => class EagleEyeFileModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299581564)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4299581564)
            
            //--TRIMMABLE-BOUNDARY-START(8594548860)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594548860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEMS.EagleEyeFileModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Name", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Date", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.UInt32.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Size", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEMS.EagleEyeFileModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $sjXkal ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4614268,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $tsZfxc ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":4614268,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8594548860)
            
            static $h = 4614268;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594548860),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4614268,
      "h": 8594548860,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594548860)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299581564),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 4614268,
      "h": 4299581564,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4299581564)
  ],
  "h": 4614268
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeFileModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4614268)
        
        

        //--TRIMMABLE-BOUNDARY-START(944252)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeCameraCommandCustomAttributesProvider`, ($self) => class EagleEyeCameraCommandCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295911548)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295911548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4295911548)
            
            static $h = 944252;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295911548),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 944252,
      "h": 4295911548,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295911548)
  ],
  "h": 944252
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraCommandCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeCameraCommandCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(944252)
        
        

        //--TRIMMABLE-BOUNDARY-START(6514812)
        $asm.$cls(`$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptorBuilder`, ($self) => class EagleEyeDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596449404)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596449404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $sIJWXi ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6514812,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDES$1.EagleEyeDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596449404)
            
            //--TRIMMABLE-BOUNDARY-START(4301482108)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301482108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301482108)
            
            //--TRIMMABLE-BOUNDARY-START(4301482108)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301482108)
            
            static $h = 6514812;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596449404),
    {
      "r": 65537,
      "n": "Register",
      "d": 6514812,
      "h": 8596449404,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596449404)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301482108),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6514812,
      "h": 4301482108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301482108)
  ],
  "h": 6514812
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Settings${separator}EagleEyeDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6514812)
        
        

        //--TRIMMABLE-BOUNDARY-START(3565692)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeLogModelCustomAttributesProvider`, ($self) => class EagleEyeLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298532988)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298532988)
            
            //--TRIMMABLE-BOUNDARY-START(8593500284)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593500284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEM.EagleEyeLogModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Type", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (12);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Value", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (13);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEM.EagleEyeLogModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $fabwBa ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3565692,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $qCAYca ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3565692,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceLogModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593500284)
            
            static $h = 3565692;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593500284),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3565692,
      "h": 8593500284,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593500284)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298532988),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3565692,
      "h": 4298532988,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298532988)
  ],
  "h": 3565692
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3565692)
        
        

        //--TRIMMABLE-BOUNDARY-START(1468540)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptorBuilder`, ($self) => class EagleEyeControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591403132)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591403132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $GTeHPf ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1468540,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEMC.EagleEyeControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591403132)
            
            //--TRIMMABLE-BOUNDARY-START(4296435836)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296435836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296435836)
            
            //--TRIMMABLE-BOUNDARY-START(4296435836)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296435836)
            
            static $h = 1468540;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591403132),
    {
      "r": 65537,
      "n": "Register",
      "d": 1468540,
      "h": 8591403132,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591403132)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296435836),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1468540,
      "h": 4296435836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296435836)
  ],
  "h": 1468540
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1468540)
        
        

        //--TRIMMABLE-BOUNDARY-START(2254972)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceModelTypeDescriptorBuilder`, ($self) => class EagleEyeDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592189564)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592189564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEM.EagleEyeDeviceModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEM.EagleEyeDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eYVFWb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2254972,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEM.EagleEyeDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592189564)
            
            //--TRIMMABLE-BOUNDARY-START(4297222268)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297222268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297222268)
            
            //--TRIMMABLE-BOUNDARY-START(4297222268)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297222268)
            
            static $h = 2254972;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592189564),
    {
      "r": 65537,
      "n": "Register",
      "d": 2254972,
      "h": 8592189564,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592189564)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297222268),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2254972,
      "h": 4297222268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297222268)
  ],
  "h": 2254972
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2254972)
        
        

        //--TRIMMABLE-BOUNDARY-START(2517116)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class EagleEyeDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592451708)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592451708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QziUyh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2517116,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592451708)
            
            //--TRIMMABLE-BOUNDARY-START(4297484412)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297484412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297484412)
            
            //--TRIMMABLE-BOUNDARY-START(4297484412)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297484412)
            
            static $h = 2517116;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592451708),
    {
      "r": 65537,
      "n": "Register",
      "d": 2517116,
      "h": 8592451708,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592451708)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297484412),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2517116,
      "h": 4297484412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297484412)
  ],
  "h": 2517116
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2517116)
        
        

        //--TRIMMABLE-BOUNDARY-START(3041404)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class EagleEyeDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592975996)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592975996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $qrDcIa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3041404,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592975996)
            
            //--TRIMMABLE-BOUNDARY-START(4298008700)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298008700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298008700)
            
            //--TRIMMABLE-BOUNDARY-START(4298008700)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298008700)
            
            static $h = 3041404;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592975996),
    {
      "r": 65537,
      "n": "Register",
      "d": 3041404,
      "h": 8592975996,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592975996)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298008700),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3041404,
      "h": 4298008700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298008700)
  ],
  "h": 3041404
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3041404)
        
        

        //--TRIMMABLE-BOUNDARY-START(4745340)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptorBuilder`, ($self) => class EagleEyeFileModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594679932)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594679932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $pvIPMd ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4745340,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEMS.EagleEyeFileModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594679932)
            
            //--TRIMMABLE-BOUNDARY-START(4299712636)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299712636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299712636)
            
            //--TRIMMABLE-BOUNDARY-START(4299712636)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299712636)
            
            static $h = 4745340;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594679932),
    {
      "r": 65537,
      "n": "Register",
      "d": 4745340,
      "h": 8594679932,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594679932)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299712636),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4745340,
      "h": 4299712636,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299712636)
  ],
  "h": 4745340
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeFileModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4745340)
        
        

        //--TRIMMABLE-BOUNDARY-START(3434620)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeFrameSizeCustomAttributesProvider`, ($self) => class EagleEyeFrameSizeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298401916)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4298401916)
            
            //--TRIMMABLE-BOUNDARY-START(8593369212)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593369212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDEM.EagleEyeFrameSizeCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$3($.$scp.SC.DescriptionAttribute.$type), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(22, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("FRAMESIZE_96X96", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t3 = $.$scp.SC.DescriptionAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$3("96X96");
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_QQVGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t4 = $.$scp.SC.DescriptionAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$3("160x120");
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_QCIF", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t5 = $.$scp.SC.DescriptionAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$3("176x144");
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_HQVGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t6 = $.$scp.SC.DescriptionAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$3("96X96");
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_240X240", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t7 = $.$scp.SC.DescriptionAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$3("240x240");
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_QVGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t8 = $.$scp.SC.DescriptionAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$3("320x240");
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_CIF", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t9 = $.$scp.SC.DescriptionAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$3("400x296");
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_HVGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t10 = $.$scp.SC.DescriptionAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$3("480x320");
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_VGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t11 = $.$scp.SC.DescriptionAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$3("640x480");
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_SVGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t12 = $.$scp.SC.DescriptionAttribute;
                            const $i12 = new $t12();
                            $i12.$ctor$3("800x600");
                            return $i12;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_XGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t13 = $.$scp.SC.DescriptionAttribute;
                            const $i13 = new $t13();
                            $i13.$ctor$3("1024x768");
                            return $i13;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_HD", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t14 = $.$scp.SC.DescriptionAttribute;
                            const $i14 = new $t14();
                            $i14.$ctor$3("1280x720");
                            return $i14;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_SXGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t15 = $.$scp.SC.DescriptionAttribute;
                            const $i15 = new $t15();
                            $i15.$ctor$3("1280x1024");
                            return $i15;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_UXGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t16 = $.$scp.SC.DescriptionAttribute;
                            const $i16 = new $t16();
                            $i16.$ctor$3("1600x1200");
                            return $i16;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_FHD", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t17 = $.$scp.SC.DescriptionAttribute;
                            const $i17 = new $t17();
                            $i17.$ctor$3("1920x1080");
                            return $i17;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_P_HD", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t18 = $.$scp.SC.DescriptionAttribute;
                            const $i18 = new $t18();
                            $i18.$ctor$3("720x1280");
                            return $i18;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_P_3MP", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t19 = $.$scp.SC.DescriptionAttribute;
                            const $i19 = new $t19();
                            $i19.$ctor$3("864x1536");
                            return $i19;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_QXGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t20 = $.$scp.SC.DescriptionAttribute;
                            const $i20 = new $t20();
                            $i20.$ctor$3("2048x1536");
                            return $i20;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_QHD", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t21 = $.$scp.SC.DescriptionAttribute;
                            const $i21 = new $t21();
                            $i21.$ctor$3("2560x1440");
                            return $i21;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_WQXGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t22 = $.$scp.SC.DescriptionAttribute;
                            const $i22 = new $t22();
                            $i22.$ctor$3("2560x1600");
                            return $i22;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_P_FHD", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t23 = $.$scp.SC.DescriptionAttribute;
                            const $i23 = new $t23();
                            $i23.$ctor$3("1080x1920");
                            return $i23;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FRAMESIZE_QSXGA", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scp.SC.DescriptionAttribute), [(() =>
                        {
                            //new $.$scp.SC.DescriptionAttribute()
                            const $t24 = $.$scp.SC.DescriptionAttribute;
                            const $i24 = new $t24();
                            $i24.$ctor$3("2560x1920");
                            return $i24;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$scp.SC.DescriptionAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDEM.EagleEyeFrameSizeCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $xjUpbd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3434620,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $TTyIvd ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":3434620,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8593369212)
            
            static $h = 3434620;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593369212),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3434620,
      "h": 8593369212,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593369212)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298401916),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 3434620,
      "h": 4298401916,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298401916)
  ],
  "h": 3434620
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeFrameSizeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeFrameSizeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3434620)
        
        

        //--TRIMMABLE-BOUNDARY-START(1206396)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptorBuilder`, ($self) => class EagleEyeCameraControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591140988)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591140988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $aPZzpg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1206396,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591140988)
            
            //--TRIMMABLE-BOUNDARY-START(4296173692)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296173692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296173692)
            
            //--TRIMMABLE-BOUNDARY-START(4296173692)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296173692)
            
            static $h = 1206396;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591140988),
    {
      "r": 65537,
      "n": "Register",
      "d": 1206396,
      "h": 8591140988,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591140988)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296173692),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1206396,
      "h": 4296173692,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296173692)
  ],
  "h": 1206396
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeCameraControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1206396)
        
        

        //--TRIMMABLE-BOUNDARY-START(4089980)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeRecordingsResponseModelTypeDescriptorBuilder`, ($self) => class EagleEyeRecordingsResponseModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594024572)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594024572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeRecordingsResponseModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $HUzNGb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4089980,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594024572)
            
            //--TRIMMABLE-BOUNDARY-START(4299057276)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299057276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299057276)
            
            //--TRIMMABLE-BOUNDARY-START(4299057276)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299057276)
            
            static $h = 4089980;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594024572),
    {
      "r": 65537,
      "n": "Register",
      "d": 4089980,
      "h": 8594024572,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594024572)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299057276),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4089980,
      "h": 4299057276,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299057276)
  ],
  "h": 4089980
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeRecordingsResponseModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeRecordingsResponseModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4089980)
        
        

        //--TRIMMABLE-BOUNDARY-START(5269628)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptorBuilder`, ($self) => class EagleEyeStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595204220)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595204220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $sGiyAb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":5269628,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEMS.EagleEyeStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8595204220)
            
            //--TRIMMABLE-BOUNDARY-START(4300236924)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300236924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300236924)
            
            //--TRIMMABLE-BOUNDARY-START(4300236924)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300236924)
            
            static $h = 5269628;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595204220),
    {
      "r": 65537,
      "n": "Register",
      "d": 5269628,
      "h": 8595204220,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595204220)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300236924),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5269628,
      "h": 4300236924,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300236924)
  ],
  "h": 5269628
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5269628)
        
        

        //--TRIMMABLE-BOUNDARY-START(2779260)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceScopeModelTypeDescriptorBuilder`, ($self) => class EagleEyeDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592713852)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592713852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $quuLDh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2779260,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592713852)
            
            //--TRIMMABLE-BOUNDARY-START(4297746556)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297746556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297746556)
            
            //--TRIMMABLE-BOUNDARY-START(4297746556)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297746556)
            
            static $h = 2779260;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592713852),
    {
      "r": 65537,
      "n": "Register",
      "d": 2779260,
      "h": 8592713852,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592713852)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297746556),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2779260,
      "h": 4297746556,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297746556)
  ],
  "h": 2779260
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2779260)
        
        

        //--TRIMMABLE-BOUNDARY-START(1730684)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelTypeDescriptorBuilder`, ($self) => class EagleEyeRecordingsControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591665276)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591665276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $eHCkSk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1730684,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591665276)
            
            //--TRIMMABLE-BOUNDARY-START(4296697980)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296697980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296697980)
            
            //--TRIMMABLE-BOUNDARY-START(4296697980)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296697980)
            
            static $h = 1730684;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591665276),
    {
      "r": 65537,
      "n": "Register",
      "d": 1730684,
      "h": 8591665276,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591665276)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296697980),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1730684,
      "h": 4296697980,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296697980)
  ],
  "h": 1730684
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeRecordingsControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1730684)
        
        

        //--TRIMMABLE-BOUNDARY-START(4352124)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeServiceModelTypeDescriptorBuilder`, ($self) => class EagleEyeServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594286716)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594286716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDEM.EagleEyeServiceModelTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDEM.EagleEyeServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $zKKlIb ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4352124,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDEM.EagleEyeServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594286716)
            
            //--TRIMMABLE-BOUNDARY-START(4299319420)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299319420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299319420)
            
            //--TRIMMABLE-BOUNDARY-START(4299319420)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299319420)
            
            static $h = 4352124;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594286716),
    {
      "r": 65537,
      "n": "Register",
      "d": 4352124,
      "h": 8594286716,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594286716)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299319420),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4352124,
      "h": 4299319420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299319420)
  ],
  "h": 4352124
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4352124)
        
        

        //--TRIMMABLE-BOUNDARY-START(2386044)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class EagleEyeDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297353340)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297353340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$QPfZ.LCIDEMS.EagleEyeStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297353340)
            
            static $h = 2386044;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297353340),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2386044,
      "h": 4297353340,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297353340)
  ],
  "h": 2386044
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2386044)
        
        

        //--TRIMMABLE-BOUNDARY-START(6121596)
        $asm.$cls(`$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class EagleEyeDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4301088892)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4301088892)
            
            //--TRIMMABLE-BOUNDARY-START(8596056188)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596056188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(9, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("FrameSize", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "efs";
                            $i3.Order = (20);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("FrameQuality", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Key = "efq";
                            $i4.Order = (21);
                            $i4.InputType = $.$cast(6n, $.$fPer.LCFC.InputType);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Minimum=0", "Maximum=63"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Brightness", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Key = "eb";
                            $i5.Order = (23);
                            $i5.InputType = $.$cast(6n, $.$fPer.LCFC.InputType);
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Minimum=-10", "Maximum=10"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Contrast", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Key = "ec";
                            $i6.Order = (24);
                            $i6.InputType = $.$cast(6n, $.$fPer.LCFC.InputType);
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Minimum=-10", "Maximum=10"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Saturation", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Key = "es";
                            $i7.Order = (25);
                            $i7.InputType = $.$cast(6n, $.$fPer.LCFC.InputType);
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Minimum=-10", "Maximum=10"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("NotificationEmailFrom", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Key = "eef";
                            $i8.Order = (26);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("NotificationEmailAddresses", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t9 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i9 = new $t9();
                            $i9.$ctor$4();
                            $i9.Key = "eea";
                            $i9.Order = (27);
                            return $i9;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("NotificationEmailTitle", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t10 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i10 = new $t10();
                            $i10.$ctor$4();
                            $i10.Key = "eet";
                            $i10.Order = (28);
                            return $i10;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("NotificationEmailMessage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t11 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i11 = new $t11();
                            $i11.$ctor$4();
                            $i11.Key = "eem";
                            $i11.Order = (29);
                            return $i11;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $thaaBf ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":6121596,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $WazQFj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":6121596,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider$$($.$QPfZ.LCIDEM.EagleEyeActions).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8596056188)
            
            static $h = 6121596;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596056188),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 6121596,
      "h": 8596056188,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596056188)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4301088892),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 6121596,
      "h": 4301088892,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4301088892)
  ],
  "h": 6121596
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Settings${separator}EagleEyeDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6121596)
        
        

        //--TRIMMABLE-BOUNDARY-START(6252668)
        $asm.$cls(`$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class EagleEyeDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596187260)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596187260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $GmGjdh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":6252668,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8596187260)
            
            //--TRIMMABLE-BOUNDARY-START(4301219964)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301219964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301219964)
            
            //--TRIMMABLE-BOUNDARY-START(4301219964)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301219964)
            
            static $h = 6252668;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596187260),
    {
      "r": 65537,
      "n": "Register",
      "d": 6252668,
      "h": 8596187260,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8596187260)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301219964),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6252668,
      "h": 4301219964,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301219964)
  ],
  "h": 6252668
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Settings${separator}EagleEyeDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6252668)
        
        

        //--TRIMMABLE-BOUNDARY-START(6580348)
        $asm.$cls(`$QPfZ.LCIDE.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4301547644)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301547644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEM.EagleEyeDeviceModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEM.EagleEyeServiceModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEMS.EagleEyeRecordingsModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4301547644)
            
            static $h = 6580348;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4301547644),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 6580348,
      "h": 4301547644,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4301547644)
  ],
  "h": 6580348
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6580348)
        
        

        //--TRIMMABLE-BOUNDARY-START(223356)
        $asm.$cls(`$QPfZ.LCIDE.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180092540)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180092540)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295190652)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295190652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295190652)
            
            //--TRIMMABLE-BOUNDARY-START(4295190652)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295190652)
            
            static $h = 223356;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180092540),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885125244,
        "f": 50331649
      },
      "n": "Paths",
      "d": 223356,
      "h": 17180092540,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180092540)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295190652),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 223356,
      "h": 4295190652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295190652)
  ],
  "h": 223356
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(223356)
        
        

        //--TRIMMABLE-BOUNDARY-START(7235708)
        $asm.$cls(`$QPfZ.LCIDEV.StartupCameraServer`, ($self) => class StartupCameraServer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12892137596)
            /*EagleEyeFrameServer*/ server = null;
            //--TRIMMABLE-BOUNDARY-END(12892137596)
            
            //--TRIMMABLE-BOUNDARY-START(4302203004)
            $ctor$1(/*EagleEyeFrameServer*/ server)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4302203004);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.server = server;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4302203004)
            
            //--TRIMMABLE-BOUNDARY-START(8597170300)
            /*ValueTask */ BootExecute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8597170300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(8597170300)
            
            //--TRIMMABLE-BOUNDARY-START(4341074262)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IBootupTask.BootExecute()
            LCFC$IBootupTask$BootExecute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341074262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BootExecute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4341074262)
            
            static $h = 7235708;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8597170300),
    {
      "r": 181338113,
      "n": "BootExecute",
      "d": 7235708,
      "h": 8597170300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8597170300)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12892137596),
    {
      "t": 616572,
      "n": "server",
      "d": 7235708,
      "h": 12892137596,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12892137596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4302203004),
    {
      "p": [
        {
          "n": "server",
          "p": 616572
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 7235708,
      "h": 4302203004,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4302203004)
  ],
  "h": 7235708
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFC.IBootupTask ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Views.StartupCameraServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Views${separator}StartupCameraServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7235708)
        
        

        //--TRIMMABLE-BOUNDARY-START(4548732)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeFileModel`, ($self) => class EagleEyeFileModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51544156284)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(51544156284)
            
            //--TRIMMABLE-BOUNDARY-START(21479385212)
            /*DateTime*/ Date;
            //--TRIMMABLE-BOUNDARY-END(21479385212)
            
            //--TRIMMABLE-BOUNDARY-START(81608927356)
            /*int*/ Size = 0;
            //--TRIMMABLE-BOUNDARY-END(81608927356)
            
            //--TRIMMABLE-BOUNDARY-START(17184417916)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184417916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17184417916)
            
            //--TRIMMABLE-BOUNDARY-START(17184417916)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17184417916)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21479385212)
                this.Date = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(21479385212)
                
            }
            static $h = 4548732;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51544156284),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38659254396,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68724025468,
        "f": 83886081
      },
      "n": "Name",
      "d": 4548732,
      "h": 51544156284,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51544156284),
//--TRIMMABLE-BOUNDARY-START(21479385212),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069319804,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60134090876,
        "f": 83886081
      },
      "n": "Date",
      "d": 4548732,
      "h": 21479385212,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 720897,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21479385212),
//--TRIMMABLE-BOUNDARY-START(81608927356),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47249188988,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77313960060,
        "f": 83886081
      },
      "n": "Size",
      "d": 4548732,
      "h": 81608927356,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81608927356)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17184417916),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4548732,
      "h": 17184417916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17184417916)
  ],
  "h": 4548732
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeFileModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4548732)
        
        

        //--TRIMMABLE-BOUNDARY-START(4810876)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeRecordingsModel`, ($self) => class EagleEyeRecordingsModel extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12889712764)
            /*EagleEyeFileModel[]*/ Files = null;
            //--TRIMMABLE-BOUNDARY-END(12889712764)
            
            //--TRIMMABLE-BOUNDARY-START(8594745468)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594745468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594745468)
            
            //--TRIMMABLE-BOUNDARY-START(8594745468)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8594745468)
            
            static $h = 4810876;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12889712764),
    {
      "p": $.$typeArray($.$QPfZ.LCIDEMS.EagleEyeFileModel).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479647356,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30069581948,
        "f": 83886081
      },
      "n": "Files",
      "d": 4810876,
      "h": 12889712764,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Flags",
              "v": 65536,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12889712764)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594745468),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4810876,
      "h": 8594745468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594745468)
  ],
  "h": 4810876
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeRecordingsModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeRecordingsModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4810876)
        
        

        //--TRIMMABLE-BOUNDARY-START(6842492)
        $asm.$cls(`$QPfZ.LCIDEV.EagleEyeFrameWebServer`, ($self) => class EagleEyeFrameWebServer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596777084)
            /*EagleEyeFrameServer*/ FrameServer = null;
            //--TRIMMABLE-BOUNDARY-END(8596777084)
            
            //--TRIMMABLE-BOUNDARY-START(4301809788)
            $ctor$1(/*EagleEyeFrameServer*/ frameServer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301809788);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.FrameServer = frameServer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301809788)
            
            //--TRIMMABLE-BOUNDARY-START(25776646268)
            /*string */ get Scheme()
            {
                return "eagle";
            }
            //--TRIMMABLE-BOUNDARY-END(25776646268)
            
            //--TRIMMABLE-BOUNDARY-START(21481678972)
            /*Stream */ Handle(/*string*/ url, /*out string*/ contentType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21481678972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Uri*/ let uri = new $.$spu.S.Uri().$ctor$5(url);
                /*var*/ let clientId = $.$$.SI.Path.GetFileNameWithoutExtension$1($.$sl.SL.Enumerable.Last$1($.$$.S.String, $.$$.S.String.Split$1.call(uri.AbsolutePath, /*/*/ 47, 0)));
                /*var*/ let stream = this.FrameServer.Server.LCFCM$IMotionJPEGFrameServer$GetStream(clientId, false);
                /*MemoryStream*/ let dataStream = new $.$$.SI.MemoryStream().$ctor$3();
                if ((stream?.LCFCM$IMotionJPEGStream$LastFrame ?? null) !== null)
                {
                    dataStream.Write$1(stream.LCFCM$IMotionJPEGStream$LastFrame.Span);
                    dataStream.Position = 0n;
                }
                contentType.$v = "image/jpeg";
                return dataStream;
            }
            //--TRIMMABLE-BOUNDARY-END(21481678972)
            
            //--TRIMMABLE-BOUNDARY-START(8646396246)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Requests.IWebRequestHandler.Scheme.get
            get LCFCR$2$IWebRequestHandler$Scheme()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17236330838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Scheme;
            }
            //--TRIMMABLE-BOUNDARY-END(8646396246)
            
            //--TRIMMABLE-BOUNDARY-START(12941363542)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Requests.IWebRequestHandler.Handle(string, out string)
            LCFCR$2$IWebRequestHandler$Handle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12941363542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Handle(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12941363542)
            
            static $h = 6842492;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25776646268),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17186711676,
        "f": 50331649
      },
      "n": "Scheme",
      "d": 6842492,
      "h": 25776646268,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25776646268)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21481678972),
    {
      "r": 95748097,
      "p": [
        {
          "n": "url",
          "p": 1310721
        },
        {
          "n": "contentType",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "Handle",
      "d": 6842492,
      "h": 21481678972,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21481678972)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8596777084),
    {
      "t": 616572,
      "n": "FrameServer",
      "d": 6842492,
      "h": 8596777084,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8596777084)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301809788),
    {
      "p": [
        {
          "n": "frameServer",
          "p": 616572
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6842492,
      "h": 4301809788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301809788)
  ],
  "h": 6842492
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCR$2.IWebRequestHandler ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Views.EagleEyeFrameWebServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Views${separator}EagleEyeFrameWebServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6842492)
        
        

        //--TRIMMABLE-BOUNDARY-START(6908028)
        $asm.$cls(`$QPfZ.LCIDEV.EagleEyeLocalStreamFileProvider`, ($self) => class EagleEyeLocalStreamFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8596842620)
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ subpath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596842620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$QPfZ.LCIDEV.DirectoryContent().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8596842620)
            
            //--TRIMMABLE-BOUNDARY-START(12891809916)
            /*IFileInfo */ GetFileInfo(/*string*/ subpath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891809916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.Contains$3.call(subpath, "videoStream"))
                {
                    return new $.$QPfZ.LCIDEV.FileInfo().$ctor$1(subpath);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(12891809916)
            
            //--TRIMMABLE-BOUNDARY-START(17186777212)
            /*IChangeToken */ Watch(/*string*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186777212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(17186777212)
            
            //--TRIMMABLE-BOUNDARY-START(8590196835)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            MEF$IFileProvider$GetFileInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFileInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196835)
            
            //--TRIMMABLE-BOUNDARY-START(4295229539)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            MEF$IFileProvider$GetDirectoryContents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDirectoryContents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229539)
            
            //--TRIMMABLE-BOUNDARY-START(12885164131)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            MEF$IFileProvider$Watch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Watch(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164131)
            
            //--TRIMMABLE-BOUNDARY-START(4301875324)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301875324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301875324)
            
            //--TRIMMABLE-BOUNDARY-START(4301875324)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4301875324)
            
            static $h = 6908028;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596842620),
    {
      "r": 131171,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetDirectoryContents",
      "d": 6908028,
      "h": 8596842620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8596842620),
//--TRIMMABLE-BOUNDARY-START(12891809916),
    {
      "r": 196707,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetFileInfo",
      "d": 6908028,
      "h": 12891809916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12891809916),
//--TRIMMABLE-BOUNDARY-START(17186777212),
    {
      "r": 720981,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "Watch",
      "d": 6908028,
      "h": 17186777212,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17186777212)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301875324),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6908028,
      "h": 4301875324,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301875324)
  ],
  "h": 6908028
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Views.EagleEyeLocalStreamFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Views${separator}EagleEyeLocalStreamFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6908028)
        
        

        //--TRIMMABLE-BOUNDARY-START(5335164)
        $asm.$cls(`$QPfZ.LCIDE.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17185204348)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QPfZ.LCIDEV.EagleEyeDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QPfZ.LCIDEV.EagleEyeDeviceDetails().$ctor$4();
                    }, $rwjpSk ??= {"r":2752627,"n":"","d":5335164,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QPfZ.LCIDEV.EagleEyeLogView.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QPfZ.LCIDEV.EagleEyeLogView().$ctor$5();
                    }, $LxWkff ??= {"r":2752627,"n":"","d":5335164,"h":0,"f":17825794}));
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$QPfZ.LCIDEV.ImageStream.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$QPfZ.LCIDEV.ImageStream().$ctor$3();
                    }, $NRLHAi ??= {"r":2752627,"n":"","d":5335164,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17185204348)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4300302460)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300302460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300302460)
            
            //--TRIMMABLE-BOUNDARY-START(4300302460)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300302460)
            
            static $h = 5335164;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17185204348),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12890237052,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 5335164,
      "h": 17185204348,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17185204348)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300302460),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5335164,
      "h": 4300302460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300302460)
  ],
  "h": 5335164
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5335164)
        
        

        //--TRIMMABLE-BOUNDARY-START(5662844)
        $asm.$cls(`$QPfZ.LCIDE.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8595597436)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595597436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$QPfZ.LCIDE.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$QPfZ.LCIDE.EagleEyeDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$QPfZ.LCIDE.EagleEyeDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$QPfZ.LCIDE.EagleEyeDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$QPfZ.LCIDE.EagleEyeDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QPfZ.LCIDE.EagleEyeDeviceFamily, x);
                }, $SxNuJa ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":5662844,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QPfZ.LCIDE.EagleEyeDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$QPfZ.LCIDE.EagleEyeDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $ZMXOIa ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":5662844,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$QPfZ.LCIDE.EagleEyeDevice)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QPfZ.LCIDE.EagleEyeDeviceFamily, x);
                }, $rNkQLg ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$QPfZ.LCIDE.EagleEyeDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":5662844,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$QPfZ.LCIDE.EagleEyeDevice), $.$QPfZ.LCIDEPC.EagleEyeDeviceCommands$$($.$QPfZ.LCIDE.EagleEyeDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$fPer.LCFC.IBootupTask, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$bHuH.LCFCM.IMotionJPEGFrameParser, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$QPfZ.LCIDE.EagleEyeFrameServer, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$bHuH.LCFCM.IMotionJPEGFrameParser))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QPfZ.LCIDE.EagleEyeFrameServer, x);
                }, $yhhgtc ??= {"r":114685,"p":[{"n":"x","p":327718}],"n":"","d":5662844,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$fPer.LCFC.IBootupTask))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QPfZ.LCIDE.EagleEyeFrameServer, x);
                }, $clFtsc ??= {"r":46106966,"p":[{"n":"x","p":327718}],"n":"","d":5662844,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$QPfZ.LCIDE.EagleEyeDevice), $.$QPfZ.LCIDEV.EagleEyeViewRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFC.IBootupTask, $.$QPfZ.LCIDEV.StartupCameraServer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$fPer.LCFCR$2.IWebRequestHandler, $.$QPfZ.LCIDEV.EagleEyeFrameWebServer, services);
                $.$hDPm.LCFC.ParametererizedViewProviderExtension.AddParameterizedView($.$QPfZ.LCIDEM.EagleEyeLogModel, $.$QPfZ.LCIDEV.EagleEyeLogView, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8595597436)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$QPfZ.LCIDE.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4300630140)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300630140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300630140)
            
            //--TRIMMABLE-BOUNDARY-START(4300630140)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4300630140)
            
            static $h = 5662844;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8595597436),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 5662844,
      "h": 8595597436,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8595597436)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300630140),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 5662844,
      "h": 4300630140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300630140)
  ],
  "h": 5662844
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5662844)
        
        

        //--TRIMMABLE-BOUNDARY-START(616572)
        $asm.$cls(`$QPfZ.LCIDE.EagleEyeFrameServer`, ($self) => class EagleEyeFrameServer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(73015060604)
            /*ServiceFactory*/ services = null;
            //--TRIMMABLE-BOUNDARY-END(73015060604)
            
            //--TRIMMABLE-BOUNDARY-START(68720093308)
            /*IMotionJPEGFrameServer*/ Server = null;
            //--TRIMMABLE-BOUNDARY-END(68720093308)
            
            //--TRIMMABLE-BOUNDARY-START(60130158716)
            /*EagleEyeFrameServer*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(60130158716)
            
            //--TRIMMABLE-BOUNDARY-START(17180485756)
            $ctor$1(/*IMotionJPEGFrameServer*/ server, /*ServiceFactory*/ services)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180485756);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.services = services;
                    this.Server = server;
                    $.$QPfZ.LCIDE.EagleEyeFrameServer.Instance = this;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180485756)
            
            //--TRIMMABLE-BOUNDARY-START(90194929788)
            /*IMotionJPEGStream?*/ get_Item$1(/*string*/ id)
            {
                return this.Server.LCFCM$IMotionJPEGFrameServer$GetStream(id, false);
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(90194929788)
            
            //--TRIMMABLE-BOUNDARY-START(21475453052)
            /*Dictionary<string, bool>*/ allowedDevices = null;
            //--TRIMMABLE-BOUNDARY-END(21475453052)
            
            //--TRIMMABLE-BOUNDARY-START(682108)
            static $_DevicePacketFrameAssembly;
            static get DevicePacketFrameAssembly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(682108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$QPfZ.LCIDE.EagleEyeFrameServer;
                return $cls.$_DevicePacketFrameAssembly ??= $asm.$ncls(`$QPfZ.LCIDE.EagleEyeFrameServer.DevicePacketFrameAssembly`, ($self) => class DevicePacketFrameAssembly extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(73015126140)
                    /*int*/ SequenceNumber = 0;
                    //--TRIMMABLE-BOUNDARY-END(73015126140)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065453180)
                    /*int*/ Frames = 0;
                    //--TRIMMABLE-BOUNDARY-END(30065453180)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770485884)
                    /*Dictionary<int, ReadOnlyMemory<byte>>*/ frames = null;
                    //--TRIMMABLE-BOUNDARY-END(25770485884)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885583996)
                    $ctor$1(/*int*/ sequenceNumber, /*int*/ frames)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885583996);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.SequenceNumber = sequenceNumber;
                            this.Frames = frames;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885583996)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180551292)
                    /*void */ AddFrame(/*int*/ frameIndex, /*ReadOnlyMemory<byte>*/ span)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180551292);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.frames.Add(frameIndex, span);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180551292)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475518588)
                    /*bool */ get Completes()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655387772);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.frames.Count === this.Frames;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475518588)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720158844)
                    /*byte[] */ get Packet()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55835256956);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let len = 0;
                        let $en1 = this.frames.Values.GetEnumerator();
                        while ($en1.MoveNext())
                        {
                            let d = $en1.Current;
                            {
                                len += d.Length;
                            }
                        }
                        /*byte[]*/ let packet = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [len], null);
                        /*int*/ let start = 0;
                        let $en2 = this.frames.Values.GetEnumerator();
                        while ($en2.MoveNext())
                        {
                            let frame = $en2.Current;
                            {
                                $.$$.S.Array.Copy(frame.ToArray(), 0, packet, start, frame.Length);
                                start += frame.Length;
                            }
                        }
                        return packet;
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720158844)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(25770485884)
                        this.frames = new ($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.ReadOnlyMemory$$($.$$.S.Byte)))().$ctor$1();
                        //--TRIMMABLE-BOUNDARY-END(25770485884)
                        
                    }
                    static $h = 682108;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015126140),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425191548,
        "f": 50331649
      },
      "n": "SequenceNumber",
      "d": 682108,
      "h": 73015126140,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015126140),
//--TRIMMABLE-BOUNDARY-START(30065453180),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245322364,
        "f": 50331649
      },
      "n": "Frames",
      "d": 682108,
      "h": 30065453180,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065453180),
//--TRIMMABLE-BOUNDARY-START(21475518588),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655387772,
        "f": 50331649
      },
      "n": "Completes",
      "d": 682108,
      "h": 21475518588,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475518588),
//--TRIMMABLE-BOUNDARY-START(68720158844),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835256956,
        "f": 50331649
      },
      "n": "Packet",
      "d": 682108,
      "h": 68720158844,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720158844)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180551292),
    {
      "r": 65537,
      "p": [
        {
          "n": "frameIndex",
          "p": 655361
        },
        {
          "n": "span",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "AddFrame",
      "d": 682108,
      "h": 17180551292,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180551292)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770485884),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.ReadOnlyMemory$$($.$$.S.Byte)).$h,
      "n": "frames",
      "d": 682108,
      "h": 25770485884,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770485884)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885583996),
    {
      "p": [
        {
          "n": "sequenceNumber",
          "p": 655361
        },
        {
          "n": "frames",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 682108,
      "h": 12885583996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885583996)
  ],
  "d": 616572,
  "h": 682108
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.EagleEyeFrameServer+DevicePacketFrameAssembly`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}EagleEyeFrameServer${separator}DevicePacketFrameAssembly`; }
                }, $cls, ($v) => $cls.$_DevicePacketFrameAssembly = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(682108)
            
            //--TRIMMABLE-BOUNDARY-START(25770420348)
            /*Dictionary<string, DevicePacketFrameAssembly>*/ assemblies = null;
            //--TRIMMABLE-BOUNDARY-END(25770420348)
            
            //--TRIMMABLE-BOUNDARY-START(64425126012)
            /*Task<MotionJPEGFrameInfo> *//*async*/  ParseJPEGFrame(/*byte[]*/ buffer)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$bHuH.LCFCM.MotionJPEGFrameInfo), $.$bHuH.LCFCM.MotionJPEGFrameInfo, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425126012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.Array.$ReadT1.call(buffer, 0) === 255)
                    {
                        /*int*/ let seqNumber = $.$$.System.Array.$ReadT1.call(buffer, 1);
                        /*int*/ let frames = $.$$.System.Array.$ReadT1.call(buffer, 2);
                        /*int*/ let frameIndex = $.$$.System.Array.$ReadT1.call(buffer, 3);
                        /*int*/ let idLen = $.$$.System.Array.$ReadT1.call(buffer, 4);
                        /*var*/ let deviceId = $.$$.ST.Encoding.ASCII.GetString$3(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$6(buffer, 5, idLen));
                        /*DevicePacketFrameAssembly?*/ let assembly = null;
                        if (this.assemblies.ContainsKey(deviceId))
                        {
                            assembly = this.assemblies.get_Item(deviceId);
                            if (assembly.SequenceNumber !== seqNumber)
                            {
                                assembly = null;
                            }
                        }
                        if (assembly === null)
                        {
                            assembly = new $.$QPfZ.LCIDE.EagleEyeFrameServer.DevicePacketFrameAssembly().$ctor$1(seqNumber, frames);
                            this.assemblies.set_Item(deviceId, assembly);
                        }
                        /*var*/ let dataStart = ((5 + idLen) | 0);
                        /*var*/ let dataLen = ((buffer.length - dataStart) | 0);
                        /*var*/ let span = new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))().$ctor$4(buffer, dataStart, dataLen);
                        assembly.AddFrame(frameIndex, span);
                        if (assembly.Completes)
                        {
                            this.assemblies.Remove$1(deviceId);
                            /*ReadOnlyMemory<byte>*/ let data = new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))().$ctor$5(assembly.Packet);
                            return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                            {
                                //new $.$bHuH.LCFCM.MotionJPEGFrameInfo()
                                const $t3 = $.$bHuH.LCFCM.MotionJPEGFrameInfo;
                                const $i3 = new $t3();
                                $i3.$ctor$2();
                                $i3.Id = deviceId;
                                $i3.Frame = data;
                                return $i3;
                            })());
                        }
                    }
                    else 
                    {
                        /*int*/ let idLen = $.$$.System.Array.$ReadT1.call(buffer, 0);
                        /*var*/ let deviceId = $.$$.ST.Encoding.ASCII.GetString$3(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$6(buffer, 1, idLen));
                        /*ReadOnlyMemory<byte>*/ let data = new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))().$ctor$4(buffer, ((idLen + 1) | 0), ((((buffer.length - idLen) | 0) - 1) | 0));
                        return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                        {
                            //new $.$bHuH.LCFCM.MotionJPEGFrameInfo()
                            const $t4 = $.$bHuH.LCFCM.MotionJPEGFrameInfo;
                            const $i4 = new $t4();
                            $i4.$ctor$2();
                            $i4.Id = deviceId;
                            $i4.Frame = data;
                            return $i4;
                        })());
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, new $.$bHuH.LCFCM.MotionJPEGFrameInfo().$ctor$2());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64425126012)
            
            //--TRIMMABLE-BOUNDARY-START(85899962492)
            /*void */ Start(/*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899962492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Server.LCFCM$IMotionJPEGFrameServer$TryStart(3030, this, token);
            }
            //--TRIMMABLE-BOUNDARY-END(85899962492)
            
            //--TRIMMABLE-BOUNDARY-START(30065387644)
            /*ValueTask */ BootExecute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065387644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(30065387644)
            
            //--TRIMMABLE-BOUNDARY-START(4295081981)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.MotionJPEG.IMotionJPEGFrameParser.ParseJPEGFrame(byte[])
            LCFCM$IMotionJPEGFrameParser$ParseJPEGFrame()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295081981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ParseJPEGFrame(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295081981)
            
            //--TRIMMABLE-BOUNDARY-START(4341074262)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.IBootupTask.BootExecute()
            LCFC$IBootupTask$BootExecute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4341074262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BootExecute(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4341074262)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475453052)
                this.allowedDevices = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Boolean))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(21475453052)
                
                //--TRIMMABLE-BOUNDARY-START(25770420348)
                this.assemblies = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$QPfZ.LCIDE.EagleEyeFrameServer.DevicePacketFrameAssembly))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(25770420348)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12885518460)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885518460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(60130158716)
                    this.Instance = null;
                    //--TRIMMABLE-BOUNDARY-END(60130158716)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885518460)
            
            static $h = 616572;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720093308),
    {
      "p": 180221,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835191420,
        "f": 50331649
      },
      "n": "Server",
      "d": 616572,
      "h": 68720093308,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720093308),
//--TRIMMABLE-BOUNDARY-START(60130158716),
    {
      "p": 616572,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655322236,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604995196,
        "f": 83886114
      },
      "n": "Instance",
      "d": 616572,
      "h": 60130158716,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(60130158716),
//--TRIMMABLE-BOUNDARY-START(90194929788),
    {
      "p": 311293,
      "i": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245256828,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 616572,
      "h": 90194929788,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(90194929788)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425126012),
    {
      "r": $.$$.STT.Task$$($.$bHuH.LCFCM.MotionJPEGFrameInfo).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "ParseJPEGFrame",
      "d": 616572,
      "h": 64425126012,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(64425126012),
//--TRIMMABLE-BOUNDARY-START(85899962492),
    {
      "r": 65537,
      "p": [
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "Start",
      "d": 616572,
      "h": 85899962492,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899962492),
//--TRIMMABLE-BOUNDARY-START(30065387644),
    {
      "r": 181338113,
      "n": "BootExecute",
      "d": 616572,
      "h": 30065387644,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065387644)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015060604),
    {
      "t": 62949718,
      "n": "services",
      "d": 616572,
      "h": 73015060604,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015060604),
//--TRIMMABLE-BOUNDARY-START(21475453052),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Boolean).$h,
      "n": "allowedDevices",
      "d": 616572,
      "h": 21475453052,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475453052),
//--TRIMMABLE-BOUNDARY-START(25770420348),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$QPfZ.LCIDE.EagleEyeFrameServer.DevicePacketFrameAssembly).$h,
      "n": "assemblies",
      "d": 616572,
      "h": 25770420348,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770420348)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180485756),
    {
      "p": [
        {
          "n": "server",
          "p": 180221
        },
        {
          "n": "services",
          "p": 62949718
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 616572,
      "h": 17180485756,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180485756)
  ],
  "h": 616572
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$bHuH.LCFCM.IMotionJPEGFrameParser, $.$fPer.LCFC.IBootupTask ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$QPfZ.LCIDE.EagleEyeFrameServer.DevicePacketFrameAssembly ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.EagleEyeFrameServer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}EagleEyeFrameServer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(616572)
        
        

        //--TRIMMABLE-BOUNDARY-START(6645884)
        $asm.$cls(`$QPfZ.LCIDEV.DirectoryContent`, ($self) => class DirectoryContent extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12891547772)
            /*bool*/ Exists = false;
            //--TRIMMABLE-BOUNDARY-END(12891547772)
            
            //--TRIMMABLE-BOUNDARY-START(25776449660)
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25776449660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(25776449660)
            
            //--TRIMMABLE-BOUNDARY-START(30071416956)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30071416956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(30071416956)
            
            //--TRIMMABLE-BOUNDARY-START(12885033059)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get MEF$IDirectoryContents$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033059)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            //--TRIMMABLE-BOUNDARY-START(8596580476)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596580476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8596580476)
            
            //--TRIMMABLE-BOUNDARY-START(8596580476)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8596580476)
            
            static $h = 6645884;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12891547772),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21481482364,
        "f": 50331649
      },
      "n": "Exists",
      "d": 6645884,
      "h": 12891547772,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12891547772)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25776449660),
    {
      "r": $.$$.SCG.IEnumerator$$($.$mefa.MEF.IFileInfo).$h,
      "n": "GetEnumerator",
      "d": 6645884,
      "h": 25776449660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25776449660)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8596580476),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 6645884,
      "h": 8596580476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8596580476)
  ],
  "h": 6645884
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IDirectoryContents, $.$$.SCG.IEnumerable$$($.$mefa.MEF.IFileInfo), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Views.DirectoryContent`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Views${separator}DirectoryContent`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6645884)
        
        

        //--TRIMMABLE-BOUNDARY-START(7366780)
        $asm.$cls(`$QPfZ.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4302334076)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4302334076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4302334076)
            
            //--TRIMMABLE-BOUNDARY-START(4302334076)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4302334076)
            
            static $h = 7366780;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4302334076),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 7366780,
      "h": 4302334076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4302334076)
  ],
  "h": 7366780,
  "a": [
    {
      "t": 7301244,
      "c": 4302268540
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7366780)
        
        

        //--TRIMMABLE-BOUNDARY-START(7301244)
        $asm.$cls(`$QPfZ.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4302268540)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4302268540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4302268540)
            
            //--TRIMMABLE-BOUNDARY-START(4302268540)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4302268540)
            
            static $h = 7301244;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4302268540),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 7301244,
      "h": 4302268540,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4302268540)
  ],
  "h": 7301244
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7301244)
        
        

        //--TRIMMABLE-BOUNDARY-START(1534076)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel`, ($self) => class EagleEyeRecordingsControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(12886435964)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886435964);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886435964)
            
            //--TRIMMABLE-BOUNDARY-START(17181403260)
            $ctor$3(/*int*/ start, /*int*/ count)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181403260);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Start = start;
                    this.Count = count;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181403260)
            
            //--TRIMMABLE-BOUNDARY-START(21476370556)
            /*int */ get Command()
            {
                return ((128 + 3) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21476370556)
            
            //--TRIMMABLE-BOUNDARY-START(73015978108)
            /*int*/ Start = 0;
            //--TRIMMABLE-BOUNDARY-END(73015978108)
            
            //--TRIMMABLE-BOUNDARY-START(25771337852)
            /*int*/ Count = 0;
            //--TRIMMABLE-BOUNDARY-END(25771337852)
            
            //--TRIMMABLE-BOUNDARY-START(12886435964)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886435964)
            
            static $h = 1534076;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476370556),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361272444,
        "f": 50364417
      },
      "n": "Command",
      "d": 1534076,
      "h": 21476370556,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476370556),
//--TRIMMABLE-BOUNDARY-START(73015978108),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541141628,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68721010812,
        "f": 83886082
      },
      "n": "Start",
      "d": 1534076,
      "h": 73015978108,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015978108),
//--TRIMMABLE-BOUNDARY-START(25771337852),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951207036,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60131076220,
        "f": 83886082
      },
      "n": "Count",
      "d": 1534076,
      "h": 25771337852,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771337852)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886435964),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1534076,
      "h": 12886435964,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886435964),
//--TRIMMABLE-BOUNDARY-START(17181403260),
    {
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1534076,
      "h": 17181403260,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181403260)
  ],
  "h": 1534076
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeRecordingsControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1534076)
        
        

        //--TRIMMABLE-BOUNDARY-START(1009788)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeCameraControlModel`, ($self) => class EagleEyeCameraControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(12885911676)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885911676);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885911676)
            
            //--TRIMMABLE-BOUNDARY-START(17180878972)
            $ctor$3(/*EagleEyeCameraCommand*/ command, /*int*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180878972);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Control = command;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180878972)
            
            //--TRIMMABLE-BOUNDARY-START(21475846268)
            /*int */ get Command()
            {
                return ((128 + 2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(21475846268)
            
            //--TRIMMABLE-BOUNDARY-START(25770813564)
            /*EagleEyeCameraCommand*/ Control = 0;
            //--TRIMMABLE-BOUNDARY-END(25770813564)
            
            //--TRIMMABLE-BOUNDARY-START(73015453820)
            /*int*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(73015453820)
            
            //--TRIMMABLE-BOUNDARY-START(12885911676)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885911676)
            
            static $h = 1009788;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475846268),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360748156,
        "f": 50364417
      },
      "n": "Command",
      "d": 1009788,
      "h": 21475846268,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475846268),
//--TRIMMABLE-BOUNDARY-START(25770813564),
    {
      "p": 878716,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950682748,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130551932,
        "f": 83886081
      },
      "n": "Control",
      "d": 1009788,
      "h": 25770813564,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770813564),
//--TRIMMABLE-BOUNDARY-START(73015453820),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540617340,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720486524,
        "f": 83886082
      },
      "n": "Value",
      "d": 1009788,
      "h": 73015453820,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015453820)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885911676),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1009788,
      "h": 12885911676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885911676),
//--TRIMMABLE-BOUNDARY-START(17180878972),
    {
      "p": [
        {
          "n": "command",
          "p": 878716
        },
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1009788,
      "h": 17180878972,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180878972)
  ],
  "h": 1009788
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeCameraControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1009788)
        
        

        //--TRIMMABLE-BOUNDARY-START(1271932)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeControlModel`, ($self) => class EagleEyeControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(17181141116)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181141116);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181141116)
            
            //--TRIMMABLE-BOUNDARY-START(21476108412)
            $ctor$3(/*bool*/ set, /*EagleEyeFlags*/ flags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476108412);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Set = set;
                    this.Flags = flags;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476108412)
            
            //--TRIMMABLE-BOUNDARY-START(25771075708)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(25771075708)
            
            //--TRIMMABLE-BOUNDARY-START(73015715964)
            /*bool*/ Set = false;
            //--TRIMMABLE-BOUNDARY-END(73015715964)
            
            //--TRIMMABLE-BOUNDARY-START(30066043004)
            /*EagleEyeFlags*/ Flags = 0;
            //--TRIMMABLE-BOUNDARY-END(30066043004)
            
            //--TRIMMABLE-BOUNDARY-START(68720748668)
            /*uint*/ LogTime = 0;
            //--TRIMMABLE-BOUNDARY-END(68720748668)
            
            //--TRIMMABLE-BOUNDARY-START(17181141116)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17181141116)
            
            static $h = 1271932;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771075708),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655977596,
        "f": 50364417
      },
      "n": "Command",
      "d": 1271932,
      "h": 25771075708,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25771075708),
//--TRIMMABLE-BOUNDARY-START(73015715964),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425781372,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785519740,
        "f": 83886082
      },
      "n": "Set",
      "d": 1271932,
      "h": 73015715964,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015715964),
//--TRIMMABLE-BOUNDARY-START(30066043004),
    {
      "p": 3238012,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245912188,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605650556,
        "f": 83886082
      },
      "n": "Flags",
      "d": 1271932,
      "h": 30066043004,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066043004),
//--TRIMMABLE-BOUNDARY-START(68720748668),
    {
      "p": 720897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835846780,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195585148,
        "f": 83886081
      },
      "n": "LogTime",
      "d": 1271932,
      "h": 68720748668,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720748668)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181141116),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1271932,
      "h": 17181141116,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181141116),
//--TRIMMABLE-BOUNDARY-START(21476108412),
    {
      "p": [
        {
          "n": "set",
          "p": 262145
        },
        {
          "n": "flags",
          "p": 3238012
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1271932,
      "h": 21476108412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476108412)
  ],
  "h": 1271932
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1271932)
        
        

        //--TRIMMABLE-BOUNDARY-START(5073020)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeStatusModel`, ($self) => class EagleEyeStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(55839647868)
            /*EagleEyeFlags*/ State = 0;
            //--TRIMMABLE-BOUNDARY-END(55839647868)
            
            //--TRIMMABLE-BOUNDARY-START(17184942204)
            /*int*/ Fps = 0;
            //--TRIMMABLE-BOUNDARY-END(17184942204)
            
            //--TRIMMABLE-BOUNDARY-START(12889974908)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889974908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889974908)
            
            //--TRIMMABLE-BOUNDARY-START(12889974908)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12889974908)
            
            static $h = 5073020;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55839647868),
    {
      "p": 3238012,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364811388,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51544680572,
        "f": 83886081
      },
      "n": "State",
      "d": 5073020,
      "h": 55839647868,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "Format=Bool(YES, NO)"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55839647868),
//--TRIMMABLE-BOUNDARY-START(17184942204),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25774876796,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42954745980,
        "f": 83886081
      },
      "n": "Fps",
      "d": 5073020,
      "h": 17184942204,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "Format=Remove(^0$)",
                "Icon=Camera"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17184942204)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889974908),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 5073020,
      "h": 12889974908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889974908)
  ],
  "h": 5073020
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5073020)
        
        

        //--TRIMMABLE-BOUNDARY-START(3500156)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeLogModel`, ($self) => class EagleEyeLogModel extends $.$XBGm.LCICDi.iSmartDeviceLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(103082715260)
            /*EagleEyeLogType*/ Type = 0;
            //--TRIMMABLE-BOUNDARY-END(103082715260)
            
            //--TRIMMABLE-BOUNDARY-START(107377682556)
            /*int*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(107377682556)
            
            //--TRIMMABLE-BOUNDARY-START(98787747964)
            /*string */ get Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543107708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$fPer.LCFCS$6.StringExtension.CamelCaseToTitle($.$$.S.Enum.ToStringT($.$QPfZ.LCIDEM.EagleEyeLogType, $.$$.S.Byte, this.Type));
            }
            //--TRIMMABLE-BOUNDARY-END(98787747964)
            
            //--TRIMMABLE-BOUNDARY-START(17183369340)
            /*string */ get Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773303932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Type)
                {
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(17183369340)
            
            //--TRIMMABLE-BOUNDARY-START(73017944188)
            /*string */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363238524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Type)
                {
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(73017944188)
            
            //--TRIMMABLE-BOUNDARY-START(77312911484)
            /*bool */ get IsValid()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(77312911484)
            
            //--TRIMMABLE-BOUNDARY-START(12888402044)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888402044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888402044)
            
            //--TRIMMABLE-BOUNDARY-START(12888402044)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12888402044)
            
            static $h = 3500156;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103082715260),
    {
      "p": 3762300,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60133042300,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85902846076,
        "f": 83886081
      },
      "n": "Type",
      "d": 3500156,
      "h": 103082715260,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 12,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103082715260),
//--TRIMMABLE-BOUNDARY-START(107377682556),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68722976892,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94492780668,
        "f": 83886081
      },
      "n": "Value",
      "d": 3500156,
      "h": 107377682556,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107377682556),
//--TRIMMABLE-BOUNDARY-START(98787747964),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51543107708,
        "f": 50364417
      },
      "n": "Title",
      "d": 3500156,
      "h": 98787747964,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98787747964),
//--TRIMMABLE-BOUNDARY-START(17183369340),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773303932,
        "f": 50364417
      },
      "n": "Description",
      "d": 3500156,
      "h": 17183369340,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17183369340),
//--TRIMMABLE-BOUNDARY-START(73017944188),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363238524,
        "f": 50364417
      },
      "n": "Icon",
      "d": 3500156,
      "h": 73017944188,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73017944188),
//--TRIMMABLE-BOUNDARY-START(77312911484),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953173116,
        "f": 50364417
      },
      "n": "IsValid",
      "d": 3500156,
      "h": 77312911484,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77312911484)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888402044),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3500156,
      "h": 12888402044,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888402044)
  ],
  "h": 3500156
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3500156)
        
        

        //--TRIMMABLE-BOUNDARY-START(878716)
        $asm.$str(`$QPfZ.LCIDEMC.EagleEyeCameraCommand`, ($self) => class EagleEyeCameraCommand extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static None = 0;
            static FrameSize = 1;
            static PixelFormat = 2;
            static Quality = 3;
            static Contrast = 4;
            static Brightness = 5;
            static Saturation = 6;
            static Sharpneess = 7;
            static DeNoise = 8;
            static GainCeiling = 9;
            static ColorBar = 10;
            static WhiteBalance = 11;
            static GainControl = 12;
            static ExposureControl = 13;
            static HMirror = 14;
            static VFlip = 15;
            static AWBGain = 16;
            static AGCGain = 17;
            static AECValue = 18;
            static AEC2 = 19;
            static DCW = 20;
            static BPC = 21;
            static WPC = 22;
            static RawGamma = 23;
            static LenC = 24;
            static SpecialEffect = 25;
            static WBMode = 26;
            static AELevel = 27;
            static FPS = 50;
            static Flash = 51;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(878716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "FrameSize": 1n,
                    "PixelFormat": 2n,
                    "Quality": 3n,
                    "Contrast": 4n,
                    "Brightness": 5n,
                    "Saturation": 6n,
                    "Sharpneess": 7n,
                    "DeNoise": 8n,
                    "GainCeiling": 9n,
                    "ColorBar": 10n,
                    "WhiteBalance": 11n,
                    "GainControl": 12n,
                    "ExposureControl": 13n,
                    "HMirror": 14n,
                    "VFlip": 15n,
                    "AWBGain": 16n,
                    "AGCGain": 17n,
                    "AECValue": 18n,
                    "AEC2": 19n,
                    "DCW": 20n,
                    "BPC": 21n,
                    "WPC": 22n,
                    "RawGamma": 23n,
                    "LenC": 24n,
                    "SpecialEffect": 25n,
                    "WBMode": 26n,
                    "AELevel": 27n,
                    "FPS": 50n,
                    "Flash": 51n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295846012)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295846012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295846012)
            
            //--TRIMMABLE-BOUNDARY-START(4295846012)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295846012)
            
            static $h = 878716;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(90195191932),
    {
      "t": 878716,
      "n": "None",
      "d": 878716,
      "h": 90195191932,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195191932),
//--TRIMMABLE-BOUNDARY-START(68720355452),
    {
      "t": 878716,
      "n": "FrameSize",
      "d": 878716,
      "h": 68720355452,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720355452),
//--TRIMMABLE-BOUNDARY-START(94490159228),
    {
      "t": 878716,
      "n": "PixelFormat",
      "d": 878716,
      "h": 94490159228,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490159228),
//--TRIMMABLE-BOUNDARY-START(98785126524),
    {
      "t": 878716,
      "n": "Quality",
      "d": 878716,
      "h": 98785126524,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785126524),
//--TRIMMABLE-BOUNDARY-START(42950551676),
    {
      "t": 878716,
      "n": "Contrast",
      "d": 878716,
      "h": 42950551676,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950551676),
//--TRIMMABLE-BOUNDARY-START(34360617084),
    {
      "t": 878716,
      "n": "Brightness",
      "d": 878716,
      "h": 34360617084,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360617084),
//--TRIMMABLE-BOUNDARY-START(107375061116),
    {
      "t": 878716,
      "n": "Saturation",
      "d": 878716,
      "h": 107375061116,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107375061116),
//--TRIMMABLE-BOUNDARY-START(111670028412),
    {
      "t": 878716,
      "n": "Sharpneess",
      "d": 878716,
      "h": 111670028412,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670028412),
//--TRIMMABLE-BOUNDARY-START(51540486268),
    {
      "t": 878716,
      "n": "DeNoise",
      "d": 878716,
      "h": 51540486268,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540486268),
//--TRIMMABLE-BOUNDARY-START(73015322748),
    {
      "t": 878716,
      "n": "GainCeiling",
      "d": 878716,
      "h": 73015322748,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015322748),
//--TRIMMABLE-BOUNDARY-START(38655584380),
    {
      "t": 878716,
      "n": "ColorBar",
      "d": 878716,
      "h": 38655584380,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655584380),
//--TRIMMABLE-BOUNDARY-START(128849897596),
    {
      "t": 878716,
      "n": "WhiteBalance",
      "d": 878716,
      "h": 128849897596,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849897596),
//--TRIMMABLE-BOUNDARY-START(77310290044),
    {
      "t": 878716,
      "n": "GainControl",
      "d": 878716,
      "h": 77310290044,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310290044),
//--TRIMMABLE-BOUNDARY-START(55835453564),
    {
      "t": 878716,
      "n": "ExposureControl",
      "d": 878716,
      "h": 55835453564,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835453564),
//--TRIMMABLE-BOUNDARY-START(81605257340),
    {
      "t": 878716,
      "n": "HMirror",
      "d": 878716,
      "h": 81605257340,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605257340),
//--TRIMMABLE-BOUNDARY-START(120259963004),
    {
      "t": 878716,
      "n": "VFlip",
      "d": 878716,
      "h": 120259963004,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259963004),
//--TRIMMABLE-BOUNDARY-START(25770682492),
    {
      "t": 878716,
      "n": "AWBGain",
      "d": 878716,
      "h": 25770682492,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770682492),
//--TRIMMABLE-BOUNDARY-START(21475715196),
    {
      "t": 878716,
      "n": "AGCGain",
      "d": 878716,
      "h": 21475715196,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475715196),
//--TRIMMABLE-BOUNDARY-START(12885780604),
    {
      "t": 878716,
      "n": "AECValue",
      "d": 878716,
      "h": 12885780604,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885780604),
//--TRIMMABLE-BOUNDARY-START(8590813308),
    {
      "t": 878716,
      "n": "AEC2",
      "d": 878716,
      "h": 8590813308,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590813308),
//--TRIMMABLE-BOUNDARY-START(47245518972),
    {
      "t": 878716,
      "n": "DCW",
      "d": 878716,
      "h": 47245518972,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245518972),
//--TRIMMABLE-BOUNDARY-START(30065649788),
    {
      "t": 878716,
      "n": "BPC",
      "d": 878716,
      "h": 30065649788,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065649788),
//--TRIMMABLE-BOUNDARY-START(133144864892),
    {
      "t": 878716,
      "n": "WPC",
      "d": 878716,
      "h": 133144864892,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144864892),
//--TRIMMABLE-BOUNDARY-START(103080093820),
    {
      "t": 878716,
      "n": "RawGamma",
      "d": 878716,
      "h": 103080093820,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080093820),
//--TRIMMABLE-BOUNDARY-START(85900224636),
    {
      "t": 878716,
      "n": "LenC",
      "d": 878716,
      "h": 85900224636,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900224636),
//--TRIMMABLE-BOUNDARY-START(115964995708),
    {
      "t": 878716,
      "n": "SpecialEffect",
      "d": 878716,
      "h": 115964995708,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964995708),
//--TRIMMABLE-BOUNDARY-START(124554930300),
    {
      "t": 878716,
      "n": "WBMode",
      "d": 878716,
      "h": 124554930300,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554930300),
//--TRIMMABLE-BOUNDARY-START(17180747900),
    {
      "t": 878716,
      "n": "AELevel",
      "d": 878716,
      "h": 17180747900,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180747900),
//--TRIMMABLE-BOUNDARY-START(64425388156),
    {
      "t": 878716,
      "n": "FPS",
      "d": 878716,
      "h": 64425388156,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425388156),
//--TRIMMABLE-BOUNDARY-START(60130420860),
    {
      "t": 878716,
      "n": "Flash",
      "d": 878716,
      "h": 60130420860,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130420860)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295846012),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 878716,
      "h": 4295846012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295846012)
  ],
  "h": 878716
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeCameraCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(878716)
        
        

        //--TRIMMABLE-BOUNDARY-START(1927292)
        $asm.$str(`$QPfZ.LCIDEM.EagleEyeBroadcastPeerMessages`, ($self) => class EagleEyeBroadcastPeerMessages extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static State = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1927292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "State": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296894588)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296894588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296894588)
            
            //--TRIMMABLE-BOUNDARY-START(4296894588)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296894588)
            
            static $h = 1927292;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591861884),
    {
      "t": 1927292,
      "n": "None",
      "d": 1927292,
      "h": 8591861884,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591861884),
//--TRIMMABLE-BOUNDARY-START(12886829180),
    {
      "t": 1927292,
      "n": "State",
      "d": 1927292,
      "h": 12886829180,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886829180)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296894588),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1927292,
      "h": 4296894588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296894588)
  ],
  "h": 1927292
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeBroadcastPeerMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeBroadcastPeerMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1927292)
        
        

        //--TRIMMABLE-BOUNDARY-START(1796220)
        $asm.$str(`$QPfZ.LCIDEM.EagleEyeActions`, ($self) => class EagleEyeActions extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Off = 0;
            static On = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1796220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Off": 0n,
                    "On": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296763516)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296763516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296763516)
            
            //--TRIMMABLE-BOUNDARY-START(4296763516)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296763516)
            
            static $h = 1796220;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591730812),
    {
      "t": 1796220,
      "n": "Off",
      "d": 1796220,
      "h": 8591730812,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591730812),
//--TRIMMABLE-BOUNDARY-START(12886698108),
    {
      "t": 1796220,
      "n": "On",
      "d": 1796220,
      "h": 12886698108,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886698108)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296763516),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1796220,
      "h": 4296763516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296763516)
  ],
  "h": 1796220
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeActions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeActions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1796220)
        
        

        //--TRIMMABLE-BOUNDARY-START(4417660)
        $asm.$str(`$QPfZ.LCIDEM.EagleFramePerSecond`, ($self) => class EagleFramePerSecond extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Low = 0;
            static Medium = 1;
            static High = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4417660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Low": 0n,
                    "Medium": 1n,
                    "High": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4299384956)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299384956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299384956)
            
            //--TRIMMABLE-BOUNDARY-START(4299384956)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299384956)
            
            static $h = 4417660;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12889319548),
    {
      "t": 4417660,
      "n": "Low",
      "d": 4417660,
      "h": 12889319548,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889319548),
//--TRIMMABLE-BOUNDARY-START(17184286844),
    {
      "t": 4417660,
      "n": "Medium",
      "d": 4417660,
      "h": 17184286844,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184286844),
//--TRIMMABLE-BOUNDARY-START(8594352252),
    {
      "t": 4417660,
      "n": "High",
      "d": 4417660,
      "h": 8594352252,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594352252)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299384956),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4417660,
      "h": 4299384956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299384956)
  ],
  "h": 4417660
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleFramePerSecond`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleFramePerSecond`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4417660)
        
        

        //--TRIMMABLE-BOUNDARY-START(3238012)
        $asm.$str(`$QPfZ.LCIDEM.EagleEyeFlags`, ($self) => class EagleEyeFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static StreamingLocal = 1;
            static StreamingRemote = 2;
            static Armed = 4;
            static Motion = 8;
            static Recording = 16;
            static Listening = 32;
            static Capture = 64;
            static Flash = 128;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3238012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "StreamingLocal": 1n,
                    "StreamingRemote": 2n,
                    "Armed": 4n,
                    "Motion": 8n,
                    "Recording": 16n,
                    "Listening": 32n,
                    "Capture": 64n,
                    "Flash": 128n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298205308)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298205308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298205308)
            
            //--TRIMMABLE-BOUNDARY-START(4298205308)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298205308)
            
            static $h = 3238012;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30068009084),
    {
      "t": 3238012,
      "n": "None",
      "d": 3238012,
      "h": 30068009084,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30068009084),
//--TRIMMABLE-BOUNDARY-START(38657943676),
    {
      "t": 3238012,
      "n": "StreamingLocal",
      "d": 3238012,
      "h": 38657943676,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38657943676),
//--TRIMMABLE-BOUNDARY-START(42952910972),
    {
      "t": 3238012,
      "n": "StreamingRemote",
      "d": 3238012,
      "h": 42952910972,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42952910972),
//--TRIMMABLE-BOUNDARY-START(8593172604),
    {
      "t": 3238012,
      "n": "Armed",
      "d": 3238012,
      "h": 8593172604,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593172604),
//--TRIMMABLE-BOUNDARY-START(25773041788),
    {
      "t": 3238012,
      "n": "Motion",
      "d": 3238012,
      "h": 25773041788,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25773041788),
//--TRIMMABLE-BOUNDARY-START(34362976380),
    {
      "t": 3238012,
      "n": "Recording",
      "d": 3238012,
      "h": 34362976380,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34362976380),
//--TRIMMABLE-BOUNDARY-START(21478074492),
    {
      "t": 3238012,
      "n": "Listening",
      "d": 3238012,
      "h": 21478074492,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21478074492),
//--TRIMMABLE-BOUNDARY-START(12888139900),
    {
      "t": 3238012,
      "n": "Capture",
      "d": 3238012,
      "h": 12888139900,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888139900),
//--TRIMMABLE-BOUNDARY-START(17183107196),
    {
      "t": 3238012,
      "n": "Flash",
      "d": 3238012,
      "h": 17183107196,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183107196)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298205308),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3238012,
      "h": 4298205308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298205308)
  ],
  "h": 3238012,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3238012)
        
        

        //--TRIMMABLE-BOUNDARY-START(3106940)
        $asm.$str(`$QPfZ.LCIDEM.EagleEyeFeatures`, ($self) => class EagleEyeFeatures extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static MotionSensor = 65536;
            static SDCard = 131072;
            static Speaker = 262144;
            static Microphone = 524288;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3106940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "MotionSensor": 65536n,
                    "SDCard": 131072n,
                    "Speaker": 262144n,
                    "Microphone": 524288n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298074236)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298074236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298074236)
            
            //--TRIMMABLE-BOUNDARY-START(4298074236)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298074236)
            
            static $h = 3106940;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888008828),
    {
      "t": 3106940,
      "n": "MotionSensor",
      "d": 3106940,
      "h": 12888008828,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888008828),
//--TRIMMABLE-BOUNDARY-START(17182976124),
    {
      "t": 3106940,
      "n": "SDCard",
      "d": 3106940,
      "h": 17182976124,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182976124),
//--TRIMMABLE-BOUNDARY-START(21477943420),
    {
      "t": 3106940,
      "n": "Speaker",
      "d": 3106940,
      "h": 21477943420,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477943420),
//--TRIMMABLE-BOUNDARY-START(8593041532),
    {
      "t": 3106940,
      "n": "Microphone",
      "d": 3106940,
      "h": 8593041532,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593041532)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298074236),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3106940,
      "h": 4298074236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298074236)
  ],
  "h": 3106940,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeFeatures`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeFeatures`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3106940)
        
        

        //--TRIMMABLE-BOUNDARY-START(3762300)
        $asm.$str(`$QPfZ.LCIDEM.EagleEyeLogType`, ($self) => class EagleEyeLogType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static None = 0;
            static SetFlags = 1;
            static ClearFlags = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3762300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "SetFlags": 1n,
                    "ClearFlags": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298729596)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298729596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298729596)
            
            //--TRIMMABLE-BOUNDARY-START(4298729596)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298729596)
            
            static $h = 3762300;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888664188),
    {
      "t": 3762300,
      "n": "None",
      "d": 3762300,
      "h": 12888664188,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888664188),
//--TRIMMABLE-BOUNDARY-START(17183631484),
    {
      "t": 3762300,
      "n": "SetFlags",
      "d": 3762300,
      "h": 17183631484,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183631484),
//--TRIMMABLE-BOUNDARY-START(8593696892),
    {
      "t": 3762300,
      "n": "ClearFlags",
      "d": 3762300,
      "h": 8593696892,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8593696892)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298729596),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3762300,
      "h": 4298729596,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298729596)
  ],
  "h": 3762300
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeLogType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3762300)
        
        

        //--TRIMMABLE-BOUNDARY-START(5924988)
        $asm.$str(`$QPfZ.LCIDES$1.EagleEyeClickCommand`, ($self) => class EagleEyeClickCommand extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Toggle = 0;
            static CountDown = 1;
            static OnShot = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(5924988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Toggle": 0n,
                    "CountDown": 1n,
                    "OnShot": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4300892284)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300892284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300892284)
            
            //--TRIMMABLE-BOUNDARY-START(4300892284)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4300892284)
            
            static $h = 5924988;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17185794172),
    {
      "t": 5924988,
      "n": "Toggle",
      "d": 5924988,
      "h": 17185794172,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17185794172),
//--TRIMMABLE-BOUNDARY-START(8595859580),
    {
      "t": 5924988,
      "n": "CountDown",
      "d": 5924988,
      "h": 8595859580,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8595859580),
//--TRIMMABLE-BOUNDARY-START(12890826876),
    {
      "t": 5924988,
      "n": "OnShot",
      "d": 5924988,
      "h": 12890826876,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12890826876)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300892284),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 5924988,
      "h": 4300892284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300892284)
  ],
  "h": 5924988
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeClickCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Settings${separator}EagleEyeClickCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5924988)
        
        

        //--TRIMMABLE-BOUNDARY-START(3369084)
        $asm.$str(`$QPfZ.LCIDEM.EagleEyeFrameSize`, ($self) => class EagleEyeFrameSize extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static FRAMESIZE_96X96 = 0;
            static FRAMESIZE_QQVGA = 1;
            static FRAMESIZE_QCIF = 2;
            static FRAMESIZE_HQVGA = 3;
            static FRAMESIZE_240X240 = 4;
            static FRAMESIZE_QVGA = 5;
            static FRAMESIZE_CIF = 6;
            static FRAMESIZE_HVGA = 7;
            static FRAMESIZE_VGA = 8;
            static FRAMESIZE_SVGA = 9;
            static FRAMESIZE_XGA = 10;
            static FRAMESIZE_HD = 11;
            static FRAMESIZE_SXGA = 12;
            static FRAMESIZE_UXGA = 13;
            static FRAMESIZE_FHD = 14;
            static FRAMESIZE_P_HD = 15;
            static FRAMESIZE_P_3MP = 16;
            static FRAMESIZE_QXGA = 17;
            static FRAMESIZE_QHD = 18;
            static FRAMESIZE_WQXGA = 19;
            static FRAMESIZE_P_FHD = 20;
            static FRAMESIZE_QSXGA = 21;
            static FRAMESIZE_INVALID = 22;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3369084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FRAMESIZE_96X96": 0n,
                    "FRAMESIZE_QQVGA": 1n,
                    "FRAMESIZE_QCIF": 2n,
                    "FRAMESIZE_HQVGA": 3n,
                    "FRAMESIZE_240X240": 4n,
                    "FRAMESIZE_QVGA": 5n,
                    "FRAMESIZE_CIF": 6n,
                    "FRAMESIZE_HVGA": 7n,
                    "FRAMESIZE_VGA": 8n,
                    "FRAMESIZE_SVGA": 9n,
                    "FRAMESIZE_XGA": 10n,
                    "FRAMESIZE_HD": 11n,
                    "FRAMESIZE_SXGA": 12n,
                    "FRAMESIZE_UXGA": 13n,
                    "FRAMESIZE_FHD": 14n,
                    "FRAMESIZE_P_HD": 15n,
                    "FRAMESIZE_P_3MP": 16n,
                    "FRAMESIZE_QXGA": 17n,
                    "FRAMESIZE_QHD": 18n,
                    "FRAMESIZE_WQXGA": 19n,
                    "FRAMESIZE_P_FHD": 20n,
                    "FRAMESIZE_QSXGA": 21n,
                    "FRAMESIZE_INVALID": 22n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4298336380)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298336380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298336380)
            
            //--TRIMMABLE-BOUNDARY-START(4298336380)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298336380)
            
            static $h = 3369084;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888270972),
    {
      "t": 3369084,
      "n": "FRAMESIZE_96X96",
      "d": 3369084,
      "h": 12888270972,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "96X96",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12888270972),
//--TRIMMABLE-BOUNDARY-START(64427878524),
    {
      "t": 3369084,
      "n": "FRAMESIZE_QQVGA",
      "d": 3369084,
      "h": 64427878524,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "160x120",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427878524),
//--TRIMMABLE-BOUNDARY-START(55837943932),
    {
      "t": 3369084,
      "n": "FRAMESIZE_QCIF",
      "d": 3369084,
      "h": 55837943932,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "176x144",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55837943932),
//--TRIMMABLE-BOUNDARY-START(30068140156),
    {
      "t": 3369084,
      "n": "FRAMESIZE_HQVGA",
      "d": 3369084,
      "h": 30068140156,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "96X96",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30068140156),
//--TRIMMABLE-BOUNDARY-START(8593303676),
    {
      "t": 3369084,
      "n": "FRAMESIZE_240X240",
      "d": 3369084,
      "h": 8593303676,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "240x240",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8593303676),
//--TRIMMABLE-BOUNDARY-START(73017813116),
    {
      "t": 3369084,
      "n": "FRAMESIZE_QVGA",
      "d": 3369084,
      "h": 73017813116,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "320x240",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73017813116),
//--TRIMMABLE-BOUNDARY-START(17183238268),
    {
      "t": 3369084,
      "n": "FRAMESIZE_CIF",
      "d": 3369084,
      "h": 17183238268,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "400x296",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17183238268),
//--TRIMMABLE-BOUNDARY-START(34363107452),
    {
      "t": 3369084,
      "n": "FRAMESIZE_HVGA",
      "d": 3369084,
      "h": 34363107452,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "480x320",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34363107452),
//--TRIMMABLE-BOUNDARY-START(94492649596),
    {
      "t": 3369084,
      "n": "FRAMESIZE_VGA",
      "d": 3369084,
      "h": 94492649596,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "640x480",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94492649596),
//--TRIMMABLE-BOUNDARY-START(81607747708),
    {
      "t": 3369084,
      "n": "FRAMESIZE_SVGA",
      "d": 3369084,
      "h": 81607747708,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "800x600",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81607747708),
//--TRIMMABLE-BOUNDARY-START(103082584188),
    {
      "t": 3369084,
      "n": "FRAMESIZE_XGA",
      "d": 3369084,
      "h": 103082584188,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "1024x768",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103082584188),
//--TRIMMABLE-BOUNDARY-START(25773172860),
    {
      "t": 3369084,
      "n": "FRAMESIZE_HD",
      "d": 3369084,
      "h": 25773172860,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "1280x720",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25773172860),
//--TRIMMABLE-BOUNDARY-START(85902715004),
    {
      "t": 3369084,
      "n": "FRAMESIZE_SXGA",
      "d": 3369084,
      "h": 85902715004,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "1280x1024",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85902715004),
//--TRIMMABLE-BOUNDARY-START(90197682300),
    {
      "t": 3369084,
      "n": "FRAMESIZE_UXGA",
      "d": 3369084,
      "h": 90197682300,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "1600x1200",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90197682300),
//--TRIMMABLE-BOUNDARY-START(21478205564),
    {
      "t": 3369084,
      "n": "FRAMESIZE_FHD",
      "d": 3369084,
      "h": 21478205564,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "1920x1080",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478205564),
//--TRIMMABLE-BOUNDARY-START(51542976636),
    {
      "t": 3369084,
      "n": "FRAMESIZE_P_HD",
      "d": 3369084,
      "h": 51542976636,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "720x1280",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51542976636),
//--TRIMMABLE-BOUNDARY-START(42953042044),
    {
      "t": 3369084,
      "n": "FRAMESIZE_P_3MP",
      "d": 3369084,
      "h": 42953042044,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "864x1536",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42953042044),
//--TRIMMABLE-BOUNDARY-START(77312780412),
    {
      "t": 3369084,
      "n": "FRAMESIZE_QXGA",
      "d": 3369084,
      "h": 77312780412,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "2048x1536",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77312780412),
//--TRIMMABLE-BOUNDARY-START(60132911228),
    {
      "t": 3369084,
      "n": "FRAMESIZE_QHD",
      "d": 3369084,
      "h": 60132911228,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "2560x1440",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60132911228),
//--TRIMMABLE-BOUNDARY-START(98787616892),
    {
      "t": 3369084,
      "n": "FRAMESIZE_WQXGA",
      "d": 3369084,
      "h": 98787616892,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "2560x1600",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98787616892),
//--TRIMMABLE-BOUNDARY-START(47248009340),
    {
      "t": 3369084,
      "n": "FRAMESIZE_P_FHD",
      "d": 3369084,
      "h": 47248009340,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "1080x1920",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47248009340),
//--TRIMMABLE-BOUNDARY-START(68722845820),
    {
      "t": 3369084,
      "n": "FRAMESIZE_QSXGA",
      "d": 3369084,
      "h": 68722845820,
      "f": 4194337,
      "a": [
        {
          "t": 327720,
          "c": 17180196904,
          "a": [
            {
              "v": "2560x1920",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68722845820),
//--TRIMMABLE-BOUNDARY-START(38658074748),
    {
      "t": 3369084,
      "n": "FRAMESIZE_INVALID",
      "d": 3369084,
      "h": 38658074748,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38658074748)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298336380),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3369084,
      "h": 4298336380,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298336380)
  ],
  "h": 3369084
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeFrameSize`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeFrameSize`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3369084)
        
        

        //--TRIMMABLE-BOUNDARY-START(92284)
        $asm.$cls(`$QPfZ.LCIDE._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590026876)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590026876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590026876)
            
            //--TRIMMABLE-BOUNDARY-START(4295059580)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295059580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295059580)
            
            //--TRIMMABLE-BOUNDARY-START(4295059580)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295059580)
            
            static $h = 92284;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590026876),
    {
      "r": 65537,
      "n": "Execute",
      "d": 92284,
      "h": 8590026876,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590026876)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295059580),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 92284,
      "h": 4295059580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295059580)
  ],
  "h": 92284
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(92284)
        
        

        //--TRIMMABLE-BOUNDARY-START(6973564)
        $asm.$cls(`$QPfZ.LCIDEV.EagleEyeLogView`, ($self) => class EagleEyeLogView extends $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$QPfZ.LCIDEM.EagleEyeLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(21481810044)
            /*string */ get OptimizedComponentName()
            {
                return "eagleeyelogview";
            }
            //--TRIMMABLE-BOUNDARY-END(21481810044)
            
            //--TRIMMABLE-BOUNDARY-START(8596908156)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596908156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 0);
                __builder.AddComponentParameter(1, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.Title));
                __builder.AddComponentParameter(2, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.Description));
                __builder.AddComponentParameter(3, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, this.ViewModel.Time.ToString()));
                __builder.AddComponentParameter(4, "Icon", ` ${$.$strNN(this.ViewModel.Icon)} cl-fatal`);
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(8596908156)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(4301940860)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4301940860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301940860)
            
            //--TRIMMABLE-BOUNDARY-START(4301940860)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4301940860)
            
            static $h = 6973564;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseParameterizedComponent$$($.$QPfZ.LCIDEM.EagleEyeLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21481810044),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17186842748,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 6973564,
      "h": 21481810044,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21481810044)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596908156),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 6973564,
      "h": 8596908156,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8596908156)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301940860),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6973564,
      "h": 4301940860,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301940860)
  ],
  "h": 6973564
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Views.EagleEyeLogView`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Views${separator}EagleEyeLogView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6973564)
        
        

        //--TRIMMABLE-BOUNDARY-START(4941948)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeRecordingsModelTypeDescriptor`, ($self) => class EagleEyeRecordingsModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299909244)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299909244);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEMS.EagleEyeRecordingsModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel, this, factory);
                    }, $MFznxg ??= {"r":65537,"n":"","d":4941948,"h":0,"f":17825794}), 0, "EagleEyeRecordingsModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_Statuses_EagleEyeRecordingsModel_LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeRecordingsModelTypeDescriptorBuilder.g.cs", "EagleEyeRecordingsModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299909244)
            
            //--TRIMMABLE-BOUNDARY-START(12889843836)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889843836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Files"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMS.EagleEyeRecordingsModel.$type, $.$discardRef(), "Files", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Files")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$typeArray($.$QPfZ.LCIDEMS.EagleEyeFileModel), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Files";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeRecordingsModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeRecordingsModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$typeArray($.$QPfZ.LCIDEMS.EagleEyeFileModel), ($.$cast(target, $.$QPfZ.LCIDEMS.EagleEyeRecordingsModel)).Files);
                        }, $zUIdQe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4941948,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeRecordingsModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Files = value.AsReference($.$typeArray($.$QPfZ.LCIDEMS.EagleEyeFileModel));
                        }, $ceAAKc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4941948,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889843836)
            
            //--TRIMMABLE-BOUNDARY-START(17184811132)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeRecordingsModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184811132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Files = _target.Files;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Files"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$typeArray($.$QPfZ.LCIDEMS.EagleEyeFileModel)));
                    /*var*/ let enumerableTypeDescriptor = $.$cast(property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType, $.$fPer.LCFCD$1.IEnumerableTypeDesriptor$$$($.$typeArray($.$QPfZ.LCIDEMS.EagleEyeFileModel), $.$QPfZ.LCIDEMS.EagleEyeFileModel));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitArray, $.$typeArray($.$QPfZ.LCIDEMS.EagleEyeFileModel), $.$QPfZ.LCIDEMS.EagleEyeFileModel, property, $.$ref(() => _Files, ($v) => _Files = $v, $.$typeArray($.$QPfZ.LCIDEMS.EagleEyeFileModel))))
                    {
                        _target.Files = _Files;
                        if (_Files !== null)
                        {
                            let $i4 = 0;
                            let $arr4 = _Files;
                            while ($i4 < $arr4.length)
                            {
                                let item = $arr4[$i4++];
                                /*var*/ let _item = item;
                                if (enumerableTypeDescriptor.LCFCD$1$IEnumerableTypeDesriptor$$$$ElementType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _item, ($v) => _item = $v, $.$QPfZ.LCIDEMS.EagleEyeFileModel)))
                                {
                                }
                            }
                        }
                        $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitArray, $.$typeArray($.$QPfZ.LCIDEMS.EagleEyeFileModel), $.$QPfZ.LCIDEMS.EagleEyeFileModel, property, $.$ref(() => _Files, ($v) => _Files = $v, $.$typeArray($.$QPfZ.LCIDEMS.EagleEyeFileModel)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184811132)
            
            //--TRIMMABLE-BOUNDARY-START(8594876540)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeRecordingsModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594876540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEMS.EagleEyeRecordingsModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEMS.EagleEyeRecordingsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMS.EagleEyeRecordingsModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEMS.EagleEyeRecordingsModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMS.EagleEyeRecordingsModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEMS.EagleEyeRecordingsModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMS.EagleEyeRecordingsModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594876540)
            
            static $h = 4941948;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889843836),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4941948,
      "h": 12889843836,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889843836),
//--TRIMMABLE-BOUNDARY-START(17184811132),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4810876,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4941948,
      "h": 17184811132,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184811132),
//--TRIMMABLE-BOUNDARY-START(8594876540),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4810876,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4941948,
      "h": 8594876540,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594876540)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299909244),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4941948,
      "h": 4299909244,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299909244)
  ],
  "h": 4941948
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeRecordingsModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeRecordingsModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4941948)
        
        

        //--TRIMMABLE-BOUNDARY-START(4679804)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor`, ($self) => class EagleEyeFileModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeFileModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299647100)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299647100);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEMS.EagleEyeFileModel, this, factory);
                    }, $QHoARe ??= {"r":65537,"n":"","d":4679804,"h":0,"f":17825794}), 0, "EagleEyeFileModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_Statuses_EagleEyeRecordingsModel_LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModelTypeDescriptorBuilder.g.cs", "EagleEyeFileModelTypeDescriptor", 35);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299647100)
            
            //--TRIMMABLE-BOUNDARY-START(12889581692)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889581692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Name"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMS.EagleEyeFileModel.$type, $.$discardRef(), "Name", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Name")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Name";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$QPfZ.LCIDEMS.EagleEyeFileModel)).Name);
                        }, $eBDUOd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4679804,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Name = value.AsReference($.$$.S.String);
                        }, $JaVpDa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4679804,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Date"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMS.EagleEyeFileModel.$type, $.$discardRef(), "Date", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Date")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Date";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$QPfZ.LCIDEMS.EagleEyeFileModel)).Date);
                        }, $wAcPKk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4679804,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Date = value.AsDateTime();
                        }, $YnBLba ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4679804,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Size"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMS.EagleEyeFileModel.$type, $.$discardRef(), "Size", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Size")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Size";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$QPfZ.LCIDEMS.EagleEyeFileModel)).Size);
                        }, $CxfPej ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":4679804,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Size = value.AsInt();
                        }, $roDJsc ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":4679804,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889581692)
            
            //--TRIMMABLE-BOUNDARY-START(17184548988)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184548988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                {
                    /*var*/ let _Name = _target.Name;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Name"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Name, ($v) => _Name = $v, $.$$.S.String)))
                    {
                        _target.Name = _Name;
                    }
                }
                {
                    /*var*/ let _Date = _target.Date;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Date"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _Date, ($v) => _Date = $v, null, true)))
                    {
                        _target.Date = _Date;
                    }
                }
                {
                    /*var*/ let _Size = _target.Size;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Size"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Size, ($v) => _Size = $v, $.$$.S.Int32)))
                    {
                        _target.Size = _Size;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184548988)
            
            //--TRIMMABLE-BOUNDARY-START(8594614396)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594614396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEMS.EagleEyeFileModel().$ctor$1();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEMS.EagleEyeFileModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMS.EagleEyeFileModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEMS.EagleEyeFileModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMS.EagleEyeFileModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEMS.EagleEyeFileModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMS.EagleEyeFileModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594614396)
            
            static $h = 4679804;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeFileModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889581692),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4679804,
      "h": 12889581692,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889581692),
//--TRIMMABLE-BOUNDARY-START(17184548988),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4548732,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4679804,
      "h": 17184548988,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184548988),
//--TRIMMABLE-BOUNDARY-START(8594614396),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4548732,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4679804,
      "h": 8594614396,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594614396)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299647100),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4679804,
      "h": 4299647100,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299647100)
  ],
  "h": 4679804
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeFileModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeFileModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeFileModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4679804)
        
        

        //--TRIMMABLE-BOUNDARY-START(1403004)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptor`, ($self) => class EagleEyeControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296370300)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296370300);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEMC.EagleEyeControlModel, this, factory);
                    }, $GqieNk ??= {"r":65537,"n":"","d":1403004,"h":0,"f":17825794}), 0, "EagleEyeControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_Controls_EagleEyeControlModel_LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModelTypeDescriptorBuilder.g.cs", "EagleEyeControlModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296370300)
            
            //--TRIMMABLE-BOUNDARY-START(12886304892)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886304892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Set"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMC.EagleEyeControlModel.$type, $.$discardRef(), "Set", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Set")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Set";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$QPfZ.LCIDEMC.EagleEyeControlModel)).Set);
                        }, $KxSIyb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1403004,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Flags"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMC.EagleEyeControlModel.$type, $.$discardRef(), "Flags", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Flags")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$QPfZ.LCIDEM.EagleEyeFlags, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Flags";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$QPfZ.LCIDEM.EagleEyeFlags, ($.$cast(target, $.$QPfZ.LCIDEMC.EagleEyeControlModel)).Flags);
                        }, $BWZGDe ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1403004,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LogTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMC.EagleEyeControlModel.$type, $.$discardRef(), "LogTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LogTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.UInt32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "LogTime";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$13(($.$cast(target, $.$QPfZ.LCIDEMC.EagleEyeControlModel)).LogTime);
                        }, $mkdCUh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1403004,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LogTime = value.AsUInt();
                        }, $NYShGa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1403004,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMC.EagleEyeControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Command";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$QPfZ.LCIDEMC.EagleEyeControlModel)).Command);
                        }, $lrBXzf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1403004,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886304892)
            
            //--TRIMMABLE-BOUNDARY-START(17181272188)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181272188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Set = _target.Set;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Set"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Set, ($v) => _Set = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _Flags = _target.Flags;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Flags"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$QPfZ.LCIDEM.EagleEyeFlags));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$QPfZ.LCIDEM.EagleEyeFlags, () => _Flags, ($v) => _Flags = $v, null, true)))
                    {
                    }
                }
                {
                    /*var*/ let _LogTime = _target.LogTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LogTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.UInt32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.UInt32, property, $.$ref(() => _LogTime, ($v) => _LogTime = $v, $.$$.S.UInt32)))
                    {
                        _target.LogTime = _LogTime;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181272188)
            
            //--TRIMMABLE-BOUNDARY-START(8591337596)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591337596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEMC.EagleEyeControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEMC.EagleEyeControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMC.EagleEyeControlModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEMC.EagleEyeControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMC.EagleEyeControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEMC.EagleEyeControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMC.EagleEyeControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591337596)
            
            static $h = 1403004;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886304892),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1403004,
      "h": 12886304892,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886304892),
//--TRIMMABLE-BOUNDARY-START(17181272188),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1271932,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1403004,
      "h": 17181272188,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181272188),
//--TRIMMABLE-BOUNDARY-START(8591337596),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1271932,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1403004,
      "h": 8591337596,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591337596)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296370300),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1403004,
      "h": 4296370300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296370300)
  ],
  "h": 1403004
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1403004)
        
        

        //--TRIMMABLE-BOUNDARY-START(1140860)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptor`, ($self) => class EagleEyeCameraControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296108156)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296108156);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel, this, factory);
                    }, $GkKBEj ??= {"r":65537,"n":"","d":1140860,"h":0,"f":17825794}), 0, "EagleEyeCameraControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_Controls_EagleEyeCameraControlModel_LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModelTypeDescriptorBuilder.g.cs", "EagleEyeCameraControlModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296108156)
            
            //--TRIMMABLE-BOUNDARY-START(12886042748)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886042748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Control"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel.$type, $.$discardRef(), "Control", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Control")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$QPfZ.LCIDEMC.EagleEyeCameraCommand, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Control";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$QPfZ.LCIDEMC.EagleEyeCameraCommand, ($.$cast(target, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel)).Control);
                        }, $cZaypb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1140860,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Control = value.AsEnumValue($.$QPfZ.LCIDEMC.EagleEyeCameraCommand);
                        }, $exkKie ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1140860,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Value"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel.$type, $.$discardRef(), "Value", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Value")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Value";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel)).Value);
                        }, $JsnUFa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1140860,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Command";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel)).Command);
                        }, $kSylqc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1140860,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886042748)
            
            //--TRIMMABLE-BOUNDARY-START(17181010044)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181010044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Control = _target.Control;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Control"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeCameraCommand));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$QPfZ.LCIDEMC.EagleEyeCameraCommand, () => _Control, ($v) => _Control = $v, null, true)))
                    {
                        _target.Control = _Control;
                    }
                }
                {
                    /*var*/ let _Value = _target.Value;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Value"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Value, ($v) => _Value = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181010044)
            
            //--TRIMMABLE-BOUNDARY-START(8591075452)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591075452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEMC.EagleEyeCameraControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591075452)
            
            static $h = 1140860;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886042748),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1140860,
      "h": 12886042748,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886042748),
//--TRIMMABLE-BOUNDARY-START(17181010044),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1009788,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1140860,
      "h": 17181010044,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181010044),
//--TRIMMABLE-BOUNDARY-START(8591075452),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1009788,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1140860,
      "h": 8591075452,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591075452)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296108156),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1140860,
      "h": 4296108156,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296108156)
  ],
  "h": 1140860
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeCameraControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeCameraControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1140860)
        
        

        //--TRIMMABLE-BOUNDARY-START(5204092)
        $asm.$cls(`$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptor`, ($self) => class EagleEyeStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300171388)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300171388);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEMS.EagleEyeStatusModel, this, factory);
                    }, $yfchJc ??= {"r":65537,"n":"","d":5204092,"h":0,"f":17825794}), 0, "EagleEyeStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_Statuses_EagleEyeStatusModel_LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModelTypeDescriptorBuilder.g.cs", "EagleEyeStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300171388)
            
            //--TRIMMABLE-BOUNDARY-START(12890105980)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890105980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("State"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMS.EagleEyeStatusModel.$type, $.$discardRef(), "State", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("State")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$QPfZ.LCIDEM.EagleEyeFlags, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "State";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$QPfZ.LCIDEM.EagleEyeFlags, ($.$cast(target, $.$QPfZ.LCIDEMS.EagleEyeStatusModel)).State);
                        }, $NIDhEa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5204092,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.State = value.AsEnumValue($.$QPfZ.LCIDEM.EagleEyeFlags);
                        }, $UwYkIg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5204092,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Fps"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMS.EagleEyeStatusModel.$type, $.$discardRef(), "Fps", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Fps")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Fps";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$QPfZ.LCIDEMS.EagleEyeStatusModel)).Fps);
                        }, $hCRwHk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":5204092,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Fps = value.AsInt();
                        }, $JeXFof ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":5204092,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12890105980)
            
            //--TRIMMABLE-BOUNDARY-START(17185073276)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185073276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _State = _target.State;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("State"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$QPfZ.LCIDEM.EagleEyeFlags));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$QPfZ.LCIDEM.EagleEyeFlags, () => _State, ($v) => _State = $v, null, true)))
                    {
                        _target.State = _State;
                    }
                }
                {
                    /*var*/ let _Fps = _target.Fps;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Fps"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Fps, ($v) => _Fps = $v, $.$$.S.Int32)))
                    {
                        _target.Fps = _Fps;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17185073276)
            
            //--TRIMMABLE-BOUNDARY-START(8595138684)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595138684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEMS.EagleEyeStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEMS.EagleEyeStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMS.EagleEyeStatusModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEMS.EagleEyeStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMS.EagleEyeStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEMS.EagleEyeStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMS.EagleEyeStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8595138684)
            
            static $h = 5204092;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12890105980),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 5204092,
      "h": 12890105980,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12890105980),
//--TRIMMABLE-BOUNDARY-START(17185073276),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5073020,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 5204092,
      "h": 17185073276,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17185073276),
//--TRIMMABLE-BOUNDARY-START(8595138684),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 5073020,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 5204092,
      "h": 8595138684,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8595138684)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300171388),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5204092,
      "h": 4300171388,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300171388)
  ],
  "h": 5204092
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Statuses${separator}EagleEyeStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5204092)
        
        

        //--TRIMMABLE-BOUNDARY-START(1665148)
        $asm.$cls(`$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelTypeDescriptor`, ($self) => class EagleEyeRecordingsControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296632444)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296632444);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel, this, factory);
                    }, $KxBCqk ??= {"r":65537,"n":"","d":1665148,"h":0,"f":17825794}), 0, "EagleEyeRecordingsControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_Controls_EagleEyeRecordingsControlModel_LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModelTypeDescriptorBuilder.g.cs", "EagleEyeRecordingsControlModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296632444)
            
            //--TRIMMABLE-BOUNDARY-START(12886567036)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886567036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Start"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel.$type, $.$discardRef(), "Start", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Start")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Start";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel)).Start);
                        }, $DNadAa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1665148,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Count"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel.$type, $.$discardRef(), "Count", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Count")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Count";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel)).Count);
                        }, $xuYtMk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1665148,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Command";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel)).Command);
                        }, $vHfdrk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1665148,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886567036)
            
            //--TRIMMABLE-BOUNDARY-START(17181534332)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181534332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Start = _target.Start;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Start"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Start, ($v) => _Start = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _Count = _target.Count;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Count"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Count, ($v) => _Count = $v, $.$$.S.Int32)))
                    {
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181534332)
            
            //--TRIMMABLE-BOUNDARY-START(8591599740)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591599740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591599740)
            
            static $h = 1665148;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886567036),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1665148,
      "h": 12886567036,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886567036),
//--TRIMMABLE-BOUNDARY-START(17181534332),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1534076,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1665148,
      "h": 17181534332,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181534332),
//--TRIMMABLE-BOUNDARY-START(8591599740),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1534076,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1665148,
      "h": 8591599740,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591599740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296632444),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1665148,
      "h": 4296632444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296632444)
  ],
  "h": 1665148
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.Controls.EagleEyeRecordingsControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}Controls${separator}EagleEyeRecordingsControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1665148)
        
        

        //--TRIMMABLE-BOUNDARY-START(3631228)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor`, ($self) => class EagleEyeLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298598524)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298598524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEM.EagleEyeLogModel, this, factory);
                    }, $WmCZcb ??= {"r":65537,"n":"","d":3631228,"h":0,"f":17825794}), 0, "EagleEyeLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_EagleEyeLogModel_LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModelTypeDescriptorBuilder.g.cs", "EagleEyeLogModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298598524)
            
            //--TRIMMABLE-BOUNDARY-START(12888533116)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888533116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEM.EagleEyeLogModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$QPfZ.LCIDEM.EagleEyeLogType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$QPfZ.LCIDEM.EagleEyeLogType, ($.$cast(target, $.$QPfZ.LCIDEM.EagleEyeLogModel)).Type);
                        }, $BprDOa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3631228,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Type = value.AsEnumValue($.$QPfZ.LCIDEM.EagleEyeLogType);
                        }, $dWYQAh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3631228,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Value"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEM.EagleEyeLogModel.$type, $.$discardRef(), "Value", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Value")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Value";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$QPfZ.LCIDEM.EagleEyeLogModel)).Value);
                        }, $grhVie ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3631228,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Value = value.AsInt();
                        }, $htNekf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":3631228,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Title"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEM.EagleEyeLogModel.$type, $.$discardRef(), "Title", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Title")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Title";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$QPfZ.LCIDEM.EagleEyeLogModel)).Title);
                        }, $QtbShd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3631228,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Description"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEM.EagleEyeLogModel.$type, $.$discardRef(), "Description", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Description")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Description";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$QPfZ.LCIDEM.EagleEyeLogModel)).Description);
                        }, $QmfUfi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3631228,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Icon"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEM.EagleEyeLogModel.$type, $.$discardRef(), "Icon", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Icon")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.String, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Icon";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$$.S.String, ($.$cast(target, $.$QPfZ.LCIDEM.EagleEyeLogModel)).Icon);
                        }, $UScoWj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3631228,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("IsValid"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEM.EagleEyeLogModel.$type, $.$discardRef(), "IsValid", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("IsValid")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "IsValid";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$QPfZ.LCIDEM.EagleEyeLogModel)).IsValid);
                        }, $uTsjlh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":3631228,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888533116)
            
            //--TRIMMABLE-BOUNDARY-START(17183500412)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183500412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceLogModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceLogModel));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$QPfZ.LCIDEM.EagleEyeLogType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$QPfZ.LCIDEM.EagleEyeLogType, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _Value = _target.Value;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Value"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Value, ($v) => _Value = $v, $.$$.S.Int32)))
                    {
                        _target.Value = _Value;
                    }
                }
                {
                    /*var*/ let _Title = _target.Title;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Title"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Title, ($v) => _Title = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Description = _target.Description;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Description"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Description, ($v) => _Description = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _Icon = _target.Icon;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Icon"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.String));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.String, property, $.$ref(() => _Icon, ($v) => _Icon = $v, $.$$.S.String)))
                    {
                    }
                }
                {
                    /*var*/ let _IsValid = _target.IsValid;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("IsValid"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _IsValid, ($v) => _IsValid = $v, null, true)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183500412)
            
            //--TRIMMABLE-BOUNDARY-START(8593565820)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593565820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEM.EagleEyeLogModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEM.EagleEyeLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeLogModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEM.EagleEyeLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEM.EagleEyeLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593565820)
            
            static $h = 3631228;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888533116),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3631228,
      "h": 12888533116,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888533116),
//--TRIMMABLE-BOUNDARY-START(17183500412),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3500156,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3631228,
      "h": 17183500412,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183500412),
//--TRIMMABLE-BOUNDARY-START(8593565820),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3500156,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3631228,
      "h": 8593565820,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593565820)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298598524),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3631228,
      "h": 4298598524,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298598524)
  ],
  "h": 3631228
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3631228)
        
        

        //--TRIMMABLE-BOUNDARY-START(5531772)
        $asm.$cls(`$QPfZ.LCIDEPCV.EagleEyeControlCommand`, ($self) => class EagleEyeControlCommand extends $.$XBGm.LCICDiC.iSmartDeviceCommand$$($.$QPfZ.LCIDEMC.EagleEyeControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300499068)
            $ctor$5()
            {
                super.$ctor$4("Control", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300499068);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300499068)
            
            //--TRIMMABLE-BOUNDARY-START(17185400956)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-electric-switch"/*MaterialDesignIconNames.ElectricSwitch*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17185400956)
            
            //--TRIMMABLE-BOUNDARY-START(4300499068)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4300499068)
            
            static $h = 5531772;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceCommand$$($.$QPfZ.LCIDEMC.EagleEyeControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17185400956),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12890433660,
        "f": 50364417
      },
      "n": "Icon",
      "d": 5531772,
      "h": 17185400956,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17185400956)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300499068),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5531772,
      "h": 4300499068,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300499068)
  ],
  "h": 5531772
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Protocol.Commands.Variants.EagleEyeControlCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Protocol${separator}Commands${separator}Variants${separator}EagleEyeControlCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5531772)
        
        

        //--TRIMMABLE-BOUNDARY-START(5597308)
        $asm.$cls(`$QPfZ.LCIDEPCV.EagleEyeRecordingsCommand`, ($self) => class EagleEyeRecordingsCommand extends $.$XBGm.LCICDiC.iSmartDeviceCommand$$($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300564604)
            $ctor$5()
            {
                super.$ctor$4("Records", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300564604);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300564604)
            
            //--TRIMMABLE-BOUNDARY-START(17185466492)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-video"/*MaterialDesignIconNames.Video*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17185466492)
            
            //--TRIMMABLE-BOUNDARY-START(4300564604)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4300564604)
            
            static $h = 5597308;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceCommand$$($.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17185466492),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12890499196,
        "f": 50364417
      },
      "n": "Icon",
      "d": 5597308,
      "h": 17185466492,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17185466492)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300564604),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 5597308,
      "h": 4300564604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300564604)
  ],
  "h": 5597308
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Protocol.Commands.Variants.EagleEyeRecordingsCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Protocol${separator}Commands${separator}Variants${separator}EagleEyeRecordingsCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5597308)
        
        

        //--TRIMMABLE-BOUNDARY-START(5400700)
        $asm.$cls(`$QPfZ.LCIDEPC.EagleEyeDeviceCommands<>`, (TDevice) => $asm.$gt(`$QPfZ.LCIDEPC.EagleEyeDeviceCommands<>`, [TDevice], ($self) => class EagleEyeDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12890302588)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12890302588)
            
            //--TRIMMABLE-BOUNDARY-START(17185269884)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17185269884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$QPfZ.LCIDEPC.EagleEyeDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17185269884)
            
            //--TRIMMABLE-BOUNDARY-START(8595335292)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8595335292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8595335292)
            
            //--TRIMMABLE-BOUNDARY-START(8595335292)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8595335292)
            
            //--TRIMMABLE-BOUNDARY-START(4300367996)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300367996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12890302588)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$QPfZ.LCIDEPCV.EagleEyeControlCommand().$ctor$5(), new $.$QPfZ.LCIDEPCV.EagleEyeCameraControlCommand().$ctor$6(), new $.$QPfZ.LCIDEPCV.EagleEyeRecordingsCommand().$ctor$5()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12890302588)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4300367996)
            
            static $H = 5400700;
            static $h = 5400700;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17185269884),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17185269884,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17185269884)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12890302588),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12890302588,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12890302588)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8595335292),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8595335292,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8595335292)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 5400700,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Protocol.Commands.EagleEyeDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Protocol${separator}Commands${separator}EagleEyeDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(5400700)
        
        

        //--TRIMMABLE-BOUNDARY-START(5466236)
        $asm.$cls(`$QPfZ.LCIDEPCV.EagleEyeCameraControlCommand`, ($self) => class EagleEyeCameraControlCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4300433532)
            $ctor$6()
            {
                super.$ctor$5("Camera", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4300433532);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4300433532)
            
            //--TRIMMABLE-BOUNDARY-START(17185335420)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-camera"/*MaterialDesignIconNames.Camera*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17185335420)
            
            //--TRIMMABLE-BOUNDARY-START(4300433532)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4300433532)
            
            static $h = 5466236;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17185335420),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12890368124,
        "f": 50364417
      },
      "n": "Icon",
      "d": 5466236,
      "h": 17185335420,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17185335420)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4300433532),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 5466236,
      "h": 4300433532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4300433532)
  ],
  "h": 5466236
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Protocol.Commands.Variants.EagleEyeCameraControlCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Protocol${separator}Commands${separator}Variants${separator}EagleEyeCameraControlCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5466236)
        
        

        //--TRIMMABLE-BOUNDARY-START(7104636)
        $asm.$cls(`$QPfZ.LCIDEV.FileInfo`, ($self) => class FileInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115971221628)
            /*IMotionJPEGStream?*/ stream = null;
            //--TRIMMABLE-BOUNDARY-END(115971221628)
            
            //--TRIMMABLE-BOUNDARY-START(120266188924)
            /*IDisposable?*/ subscription = null;
            //--TRIMMABLE-BOUNDARY-END(120266188924)
            
            //--TRIMMABLE-BOUNDARY-START(12892006524)
            $ctor$1(/*string*/ path)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12892006524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = path;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12892006524)
            
            //--TRIMMABLE-BOUNDARY-START(21481941116)
            /*bool */ get Exists()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21481941116)
            
            //--TRIMMABLE-BOUNDARY-START(90201417852)
            /*long */ get Length()
            {
                return BigInt(-1);
            }
            //--TRIMMABLE-BOUNDARY-END(90201417852)
            
            //--TRIMMABLE-BOUNDARY-START(111676254332)
            /*string */ get PhysicalPath()
            {
                return "";
            }
            //--TRIMMABLE-BOUNDARY-END(111676254332)
            
            //--TRIMMABLE-BOUNDARY-START(94496385148)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(94496385148)
            
            //--TRIMMABLE-BOUNDARY-START(85906450556)
            /*DateTimeOffset*/ LastModified;
            //--TRIMMABLE-BOUNDARY-END(85906450556)
            
            //--TRIMMABLE-BOUNDARY-START(81611483260)
            /*bool */ get IsDirectory()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(81611483260)
            
            //--TRIMMABLE-BOUNDARY-START(25776908412)
            /*MemoryStream*/ fileStream = null;
            //--TRIMMABLE-BOUNDARY-END(25776908412)
            
            //--TRIMMABLE-BOUNDARY-START(17186973820)
            /*Stream */ CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186973820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.subscription?.S$IDisposable$Dispose();
                /*var*/ let clientId = $.$$.SI.Path.GetFileNameWithoutExtension$1($.$sl.SL.Enumerable.Last$1($.$$.S.String, $.$$.S.String.Split$1.call(this.Name, /*/*/ 47, 0)));
                this.stream = $.$QPfZ.LCIDE.EagleEyeFrameServer.Instance.Server.LCFCM$IMotionJPEGFrameServer$GetStream(clientId, false);
                this.subscription = (this.stream?.[`S$IObservable$System$ReadOnlyMemory$System$Byte$$Subscribe`](this) ?? null);
                if ((this.stream?.LCFCM$IMotionJPEGStream$LastFrame ?? null) !== null)
                {
                    this.fileStream.Write$1(this.stream.LCFCM$IMotionJPEGStream$LastFrame.Span);
                    this.fileStream.Position = 0n;
                }
                return this.fileStream;
            }
            //--TRIMMABLE-BOUNDARY-END(17186973820)
            
            //--TRIMMABLE-BOUNDARY-START(98791352444)
            /*void */ OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98791352444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(98791352444)
            
            //--TRIMMABLE-BOUNDARY-START(103086319740)
            /*void */ OnError(/*Exception*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103086319740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(103086319740)
            
            //--TRIMMABLE-BOUNDARY-START(107381287036)
            /*void */ OnNext(/*ReadOnlyMemory<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107381287036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    this.fileStream.Write$1($.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1(value.ToArray()));
                }
                catch(e)
                {
                    this.subscription?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107381287036)
            
            //--TRIMMABLE-BOUNDARY-START(17180065891)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get MEF$IFileInfo$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065891)
            
            //--TRIMMABLE-BOUNDARY-START(42949869667)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get MEF$IFileInfo$Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869667)
            
            //--TRIMMABLE-BOUNDARY-START(60129738851)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get MEF$IFileInfo$PhysicalPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhysicalPath;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738851)
            
            //--TRIMMABLE-BOUNDARY-START(51539804259)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get MEF$IFileInfo$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309608035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804259)
            
            //--TRIMMABLE-BOUNDARY-START(34359935075)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get MEF$IFileInfo$LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastModified;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935075)
            
            //--TRIMMABLE-BOUNDARY-START(25770000483)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get MEF$IFileInfo$IsDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsDirectory;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000483)
            
            //--TRIMMABLE-BOUNDARY-START(4295164003)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            MEF$IFileInfo$CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateReadStream(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164003)
            
            //--TRIMMABLE-BOUNDARY-START(12982091777)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnNext(System.ReadOnlyMemory<byte>)
            S$IObserver$$$OnNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12982091777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnNext(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12982091777)
            
            //--TRIMMABLE-BOUNDARY-START(8687124481)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnError(System.Exception)
            S$IObserver$$$OnError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8687124481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnError(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8687124481)
            
            //--TRIMMABLE-BOUNDARY-START(4392157185)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnCompleted()
            S$IObserver$$$OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392157185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnCompleted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392157185)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85906450556)
                this.LastModified = $.$default($.$$.S.DateTimeOffset);
                //--TRIMMABLE-BOUNDARY-END(85906450556)
                
                //--TRIMMABLE-BOUNDARY-START(25776908412)
                this.fileStream = new $.$$.SI.MemoryStream().$ctor$3();
                //--TRIMMABLE-BOUNDARY-END(25776908412)
                
            }
            static $h = 7104636;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21481941116),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34366843004,
        "f": 50331649
      },
      "n": "Exists",
      "d": 7104636,
      "h": 21481941116,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21481941116),
//--TRIMMABLE-BOUNDARY-START(90201417852),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60136646780,
        "f": 50331649
      },
      "n": "Length",
      "d": 7104636,
      "h": 90201417852,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90201417852),
//--TRIMMABLE-BOUNDARY-START(111676254332),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77316515964,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 7104636,
      "h": 111676254332,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111676254332),
//--TRIMMABLE-BOUNDARY-START(94496385148),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68726581372,
        "f": 50331649
      },
      "n": "Name",
      "d": 7104636,
      "h": 94496385148,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94496385148),
//--TRIMMABLE-BOUNDARY-START(85906450556),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51546712188,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 7104636,
      "h": 85906450556,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85906450556),
//--TRIMMABLE-BOUNDARY-START(81611483260),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42956777596,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 7104636,
      "h": 81611483260,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81611483260)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17186973820),
    {
      "r": 95748097,
      "n": "CreateReadStream",
      "d": 7104636,
      "h": 17186973820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17186973820),
//--TRIMMABLE-BOUNDARY-START(98791352444),
    {
      "r": 65537,
      "n": "OnCompleted",
      "d": 7104636,
      "h": 98791352444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98791352444),
//--TRIMMABLE-BOUNDARY-START(103086319740),
    {
      "r": 65537,
      "p": [
        {
          "n": "error",
          "p": 80805889
        }
      ],
      "n": "OnError",
      "d": 7104636,
      "h": 103086319740,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103086319740),
//--TRIMMABLE-BOUNDARY-START(107381287036),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "OnNext",
      "d": 7104636,
      "h": 107381287036,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107381287036)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(115971221628),
    {
      "t": 311293,
      "n": "stream",
      "d": 7104636,
      "h": 115971221628,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115971221628),
//--TRIMMABLE-BOUNDARY-START(120266188924),
    {
      "t": 91095041,
      "n": "subscription",
      "d": 7104636,
      "h": 120266188924,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120266188924),
//--TRIMMABLE-BOUNDARY-START(25776908412),
    {
      "t": 94568449,
      "n": "fileStream",
      "d": 7104636,
      "h": 25776908412,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25776908412)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12892006524),
    {
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 7104636,
      "h": 12892006524,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12892006524)
  ],
  "h": 7104636
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileInfo, $.$$.S.IObserver$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Views.FileInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Views${separator}FileInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7104636)
        
        

        //--TRIMMABLE-BOUNDARY-START(7170172)
        $asm.$cls(`$QPfZ.LCIDEV.ImageStream`, ($self) => class ImageStream extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(21482006652)
            /*string*/ DeviceId = null;
            //--TRIMMABLE-BOUNDARY-END(21482006652)
            
            //--TRIMMABLE-BOUNDARY-START(38661875836)
            /*EagleEyeFrameServer*/ FrameServer = null;
            //--TRIMMABLE-BOUNDARY-END(38661875836)
            
            //--TRIMMABLE-BOUNDARY-START(34366908540)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(34366908540)
            
            //--TRIMMABLE-BOUNDARY-START(30071941244)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30071941244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.tcs.Cancel();
                this.disposed = true;
                this.dispose?.S$IDisposable$Dispose();
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(30071941244)
            
            //--TRIMMABLE-BOUNDARY-START(124561221756)
            /*bool*/ static useInlineImg = true;
            //--TRIMMABLE-BOUNDARY-END(124561221756)
            
            //--TRIMMABLE-BOUNDARY-START(25776973948)
            /*IDisposable?*/ dispose = null;
            //--TRIMMABLE-BOUNDARY-END(25776973948)
            
            //--TRIMMABLE-BOUNDARY-START(115971287164)
            /*CancellationTokenSource*/ tcs = null;
            //--TRIMMABLE-BOUNDARY-END(115971287164)
            
            //--TRIMMABLE-BOUNDARY-START(85906516092)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85906516092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FrameServer.Start(this.tcs.Token);
                //if (useInlineImg)
                {
                    this.dispose = (this.FrameServer.Server.LCFCM$IMotionJPEGFrameServer$GetStream(this.DeviceId, true)?.[`S$IObservable$System$ReadOnlyMemory$System$Byte$$Subscribe`](this) ?? null);
                }
                //else { ... }
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(85906516092)
            
            //--TRIMMABLE-BOUNDARY-START(77316581500)
            /*void */ OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77316581500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(77316581500)
            
            //--TRIMMABLE-BOUNDARY-START(81611548796)
            /*void */ OnError(/*Exception*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81611548796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(81611548796)
            
            //--TRIMMABLE-BOUNDARY-START(73021614204)
            /*string?*/ inlineImage = null;
            //--TRIMMABLE-BOUNDARY-END(73021614204)
            
            //--TRIMMABLE-BOUNDARY-START(90201483388)
            /*void */ OnNext(/*ReadOnlyMemory<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90201483388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.inlineImage = $.$$.S.Convert.ToBase64String$4(value.Span, 0);
                this.InvokeAsync(new $.$$.S.Action().$ctor(this, this.StateHasChanged));
            }
            //--TRIMMABLE-BOUNDARY-END(90201483388)
            
            //--TRIMMABLE-BOUNDARY-START(94496450684)
            /*string */ get OptimizedComponentName()
            {
                return "imagestream";
            }
            //--TRIMMABLE-BOUNDARY-END(94496450684)
            
            //--TRIMMABLE-BOUNDARY-START(120266254460)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120266254460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "DeviceId":
                    this.DeviceId = $.$cast(parameter.Value, $.$$.S.String);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(120266254460)
            
            //--TRIMMABLE-BOUNDARY-START(68726646908)
            /*void */ InjectServices(/*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68726646908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.InjectServices(serviceProvider);
                this.FrameServer = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$QPfZ.LCIDE.EagleEyeFrameServer, serviceProvider);
            }
            //--TRIMMABLE-BOUNDARY-END(68726646908)
            
            //--TRIMMABLE-BOUNDARY-START(17187039356)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17187039356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (useInlineImg)
                {
                    __builder.OpenElement(0, "img");
                    __builder.AddAttribute$5(1, "class", "wp-100");
                    __builder.AddAttribute$5(2, "src", $.$strNN("data:image/jpeg;base64," + " ") + $.$strNN((this.inlineImage)));
                    __builder.AddAttribute$5(3, "style", this.Style);
                    __builder.CloseElement();
                }
                //else { ... }
            }
            //--TRIMMABLE-BOUNDARY-END(17187039356)
            
            //--TRIMMABLE-BOUNDARY-START(12982091777)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnNext(System.ReadOnlyMemory<byte>)
            S$IObserver$$$OnNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12982091777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnNext(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12982091777)
            
            //--TRIMMABLE-BOUNDARY-START(8687124481)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnError(System.Exception)
            S$IObserver$$$OnError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8687124481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnError(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8687124481)
            
            //--TRIMMABLE-BOUNDARY-START(4392157185)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnCompleted()
            S$IObserver$$$OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392157185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnCompleted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392157185)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(12892072060)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12892072060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12892072060)
            
            //--TRIMMABLE-BOUNDARY-START(12892072060)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12892072060)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21482006652)
                this.DeviceId = null;
                //--TRIMMABLE-BOUNDARY-END(21482006652)
                
                //--TRIMMABLE-BOUNDARY-START(38661875836)
                this.FrameServer = null;
                //--TRIMMABLE-BOUNDARY-END(38661875836)
                
                //--TRIMMABLE-BOUNDARY-START(115971287164)
                this.tcs = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(115971287164)
                
            }
            static $h = 7170172;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21482006652),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47251810428,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103086385276,
        "f": 83886081
      },
      "n": "DeviceId",
      "d": 7170172,
      "h": 21482006652,
      "f": 2097153,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21482006652),
//--TRIMMABLE-BOUNDARY-START(38661875836),
    {
      "p": 616572,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55841745020,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111676319868,
        "f": 83886081
      },
      "n": "FrameServer",
      "d": 7170172,
      "h": 38661875836,
      "f": 2097153,
      "a": [
        {
          "t": 44521130,
          "c": 4339488426
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38661875836),
//--TRIMMABLE-BOUNDARY-START(94496450684),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64431679612,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 7170172,
      "h": 94496450684,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(94496450684)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30071941244),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 7170172,
      "h": 30071941244,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30071941244),
//--TRIMMABLE-BOUNDARY-START(85906516092),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 7170172,
      "h": 85906516092,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(85906516092),
//--TRIMMABLE-BOUNDARY-START(77316581500),
    {
      "r": 65537,
      "n": "OnCompleted",
      "d": 7170172,
      "h": 77316581500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77316581500),
//--TRIMMABLE-BOUNDARY-START(81611548796),
    {
      "r": 65537,
      "p": [
        {
          "n": "error",
          "p": 80805889
        }
      ],
      "n": "OnError",
      "d": 7170172,
      "h": 81611548796,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81611548796),
//--TRIMMABLE-BOUNDARY-START(90201483388),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "OnNext",
      "d": 7170172,
      "h": 90201483388,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90201483388),
//--TRIMMABLE-BOUNDARY-START(120266254460),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 7170172,
      "h": 120266254460,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120266254460),
//--TRIMMABLE-BOUNDARY-START(68726646908),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "InjectServices",
      "d": 7170172,
      "h": 68726646908,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68726646908),
//--TRIMMABLE-BOUNDARY-START(17187039356),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 7170172,
      "h": 17187039356,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17187039356)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34366908540),
    {
      "t": 262145,
      "n": "disposed",
      "d": 7170172,
      "h": 34366908540,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34366908540),
//--TRIMMABLE-BOUNDARY-START(124561221756),
    {
      "t": 262145,
      "n": "useInlineImg",
      "d": 7170172,
      "h": 124561221756,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124561221756),
//--TRIMMABLE-BOUNDARY-START(25776973948),
    {
      "t": 91095041,
      "n": "dispose",
      "d": 7170172,
      "h": 25776973948,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25776973948),
//--TRIMMABLE-BOUNDARY-START(115971287164),
    {
      "t": 170983425,
      "n": "tcs",
      "d": 7170172,
      "h": 115971287164,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(115971287164),
//--TRIMMABLE-BOUNDARY-START(73021614204),
    {
      "t": 1310721,
      "n": "inlineImage",
      "d": 7170172,
      "h": 73021614204,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73021614204)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12892072060),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 7170172,
      "h": 12892072060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12892072060)
  ],
  "h": 7170172
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$$.S.IDisposable, $.$$.S.IObserver$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte)), $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Views.ImageStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Views${separator}ImageStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7170172)
        
        

        //--TRIMMABLE-BOUNDARY-START(3893372)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel`, ($self) => class EagleEyeRecordingsResponseModel extends $.$XBGm.LCICDi.iSmartDeviceCommandResponseModel$$($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298860668)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298860668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298860668)
            
            //--TRIMMABLE-BOUNDARY-START(4298860668)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298860668)
            
            static $h = 3893372;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandResponseModel$$($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298860668),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3893372,
      "h": 4298860668,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298860668)
  ],
  "h": 3893372
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeRecordingsResponseModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeRecordingsResponseModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3893372)
        
        

        //--TRIMMABLE-BOUNDARY-START(2844796)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel`, ($self) => class EagleEyeDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(8592779388)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592779388);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592779388)
            
            //--TRIMMABLE-BOUNDARY-START(12887746684)
            $ctor$5(/*EagleEyeCameraControlModel*/ camera)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887746684);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Camera = camera;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887746684)
            
            //--TRIMMABLE-BOUNDARY-START(17182713980)
            /*EagleEyeCameraControlModel?*/ Camera = null;
            //--TRIMMABLE-BOUNDARY-END(17182713980)
            
            //--TRIMMABLE-BOUNDARY-START(8592779388)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8592779388)
            
            static $h = 2844796;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182713980),
    {
      "p": 1009788,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772648572,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34362583164,
        "f": 83886081
      },
      "n": "Camera",
      "d": 2844796,
      "h": 17182713980,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13432,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17182713980)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592779388),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2844796,
      "h": 8592779388,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592779388),
//--TRIMMABLE-BOUNDARY-START(12887746684),
    {
      "p": [
        {
          "n": "camera",
          "p": 1009788
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2844796,
      "h": 12887746684,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887746684)
  ],
  "h": 2844796
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2844796)
        
        

        //--TRIMMABLE-BOUNDARY-START(4024444)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeRecordingsResponseModelTypeDescriptor`, ($self) => class EagleEyeRecordingsResponseModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298991740)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298991740);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel, this, factory);
                    }, $dwnUfj ??= {"r":65537,"n":"","d":4024444,"h":0,"f":17825794}), 0, "EagleEyeRecordingsResponseModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_EagleEyeRecordingsResponseModel_LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeRecordingsResponseModelTypeDescriptorBuilder.g.cs", "EagleEyeRecordingsResponseModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298991740)
            
            //--TRIMMABLE-BOUNDARY-START(12888926332)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888926332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceCommandResponseModelTypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888926332)
            
            //--TRIMMABLE-BOUNDARY-START(17183893628)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeRecordingsResponseModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183893628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandResponseModel<LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeRecordingsModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandResponseModelTypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandResponseModel$$($.$QPfZ.LCIDEMS.EagleEyeRecordingsModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183893628)
            
            //--TRIMMABLE-BOUNDARY-START(8593959036)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeRecordingsResponseModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593959036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593959036)
            
            static $h = 4024444;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888926332),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4024444,
      "h": 12888926332,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888926332),
//--TRIMMABLE-BOUNDARY-START(17183893628),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3893372,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4024444,
      "h": 17183893628,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183893628),
//--TRIMMABLE-BOUNDARY-START(8593959036),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3893372,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4024444,
      "h": 8593959036,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593959036)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298991740),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4024444,
      "h": 4298991740,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298991740)
  ],
  "h": 4024444
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeRecordingsResponseModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeRecordingsResponseModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4024444)
        
        

        //--TRIMMABLE-BOUNDARY-START(2320508)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel`, ($self) => class EagleEyeDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$QPfZ.LCIDEMS.EagleEyeStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297287804)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297287804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297287804)
            
            //--TRIMMABLE-BOUNDARY-START(4297287804)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297287804)
            
            static $h = 2320508;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$QPfZ.LCIDEMS.EagleEyeStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297287804),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2320508,
      "h": 4297287804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297287804)
  ],
  "h": 2320508
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2320508)
        
        

        //--TRIMMABLE-BOUNDARY-START(2975868)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelTypeDescriptor`, ($self) => class EagleEyeDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297943164)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297943164);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, this, factory);
                    }, $InYyLd ??= {"r":65537,"n":"","d":2975868,"h":0,"f":17825794}), 0, "EagleEyeDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_EagleEyeDeviceSendDataModel_LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModelTypeDescriptorBuilder.g.cs", "EagleEyeDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297943164)
            
            //--TRIMMABLE-BOUNDARY-START(12887877756)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887877756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Camera"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel.$type, $.$discardRef(), "Camera", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Camera")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Camera";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel, ($.$cast(target, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel)).Camera);
                        }, $iWOrzj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2975868,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Camera = value.AsReference($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel);
                        }, $AHrbsg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2975868,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887877756)
            
            //--TRIMMABLE-BOUNDARY-START(17182845052)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182845052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                {
                    /*var*/ let _Camera = _target.Camera;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Camera"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$QPfZ.LCIDEMC.EagleEyeCameraControlModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Camera, ($v) => _Camera = $v, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel)))
                    {
                        _target.Camera = _Camera;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182845052)
            
            //--TRIMMABLE-BOUNDARY-START(8592910460)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592910460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592910460)
            
            static $h = 2975868;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887877756),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2975868,
      "h": 12887877756,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887877756),
//--TRIMMABLE-BOUNDARY-START(17182845052),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2844796,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2975868,
      "h": 17182845052,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182845052),
//--TRIMMABLE-BOUNDARY-START(8592910460),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2844796,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2975868,
      "h": 8592910460,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592910460)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297943164),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2975868,
      "h": 4297943164,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297943164)
  ],
  "h": 2975868
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2975868)
        
        

        //--TRIMMABLE-BOUNDARY-START(2451580)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModelTypeDescriptor`, ($self) => class EagleEyeDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297418876)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297418876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, this, factory);
                    }, $wLQvEb ??= {"r":65537,"n":"","d":2451580,"h":0,"f":17825794}), 0, "EagleEyeDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_EagleEyeDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "EagleEyeDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297418876)
            
            //--TRIMMABLE-BOUNDARY-START(12887353468)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887353468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887353468)
            
            //--TRIMMABLE-BOUNDARY-START(17182320764)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182320764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$QPfZ.LCIDEMS.EagleEyeStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$QPfZ.LCIDEMS.EagleEyeStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182320764)
            
            //--TRIMMABLE-BOUNDARY-START(8592386172)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592386172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592386172)
            
            static $h = 2451580;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887353468),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2451580,
      "h": 12887353468,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887353468),
//--TRIMMABLE-BOUNDARY-START(17182320764),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2320508,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2451580,
      "h": 17182320764,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182320764),
//--TRIMMABLE-BOUNDARY-START(8592386172),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2320508,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2451580,
      "h": 8592386172,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592386172)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297418876),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2451580,
      "h": 4297418876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297418876)
  ],
  "h": 2451580
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2451580)
        
        

        //--TRIMMABLE-BOUNDARY-START(288892)
        $asm.$cls(`$QPfZ.LCIDE.EagleEyeDataConverter`, ($self) => class EagleEyeDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295256188)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295256188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295256188)
            
            //--TRIMMABLE-BOUNDARY-START(4295256188)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295256188)
            
            static $h = 288892;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295256188),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 288892,
      "h": 4295256188,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295256188)
  ],
  "h": 288892
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.EagleEyeDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}EagleEyeDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(288892)
        
        

        $asm.$typeProxy("$QPfZ.LCIDEM.EagleEyeDeviceScopeModel", "$QPfZ.LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModel");
        $asm.$typeProxy("$QPfZ.LCIDEM.EagleEyeDeviceModel", "$QPfZ.LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModel");
        $asm.$typeProxy("$QPfZ.LCIDES$1.EagleEyeDeviceSettings", "$QPfZ.LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings");
        $asm.$typeProxy("$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings", "$QPfZ.LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings");
        $asm.$typeProxy("$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler", "$QPfZ.LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceStatusHandler");
        $asm.$typeProxy("$QPfZ.LCIDES.IEagleEyeDeviceHubClient", "$QPfZ.LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceHubClient");
        $asm.$typeProxy("$QPfZ.LCIDES.IEagleEyeRemoteService", "$QPfZ.LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeRemoteService");
        //--TRIMMABLE-BOUNDARY-START(4155516)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeServiceModel`, ($self) => class EagleEyeServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299122812)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299122812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299122812)
            
            //--TRIMMABLE-BOUNDARY-START(4299122812)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4299122812)
            
            static $h = 4155516;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299122812),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 4155516,
      "h": 4299122812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299122812)
  ],
  "h": 4155516
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4155516)
        
        

        //--TRIMMABLE-BOUNDARY-START(2582652)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceScopeModel`, ($self) => class EagleEyeDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297549948)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297549948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297549948)
            
            //--TRIMMABLE-BOUNDARY-START(4297549948)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4297549948)
            
            static $h = 2582652;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297549948),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2582652,
      "h": 4297549948,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297549948)
  ],
  "h": 2582652
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2582652)
        
        

        //--TRIMMABLE-BOUNDARY-START(2058364)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceModel`, ($self) => class EagleEyeDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4297025660)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297025660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297025660)
            
            //--TRIMMABLE-BOUNDARY-START(4297025660)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4297025660)
            
            static $h = 2058364;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297025660),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2058364,
      "h": 4297025660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297025660)
  ],
  "h": 2058364
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2058364)
        
        

        //--TRIMMABLE-BOUNDARY-START(5793916)
        $asm.$cls(`$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler`, ($self) => class IEagleEyeDeviceStatusHandler
        {
            static $h = 5793916;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 5793916
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Services${separator}IEagleEyeDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5793916)
        
        

        //--TRIMMABLE-BOUNDARY-START(5859452)
        $asm.$cls(`$QPfZ.LCIDES.IEagleEyeRemoteService`, ($self) => class IEagleEyeRemoteService
        {
            static $h = 5859452;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 5859452
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$QPfZ.LCIDEM.EagleEyeServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$QPfZ.LCIDEM.EagleEyeServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$QPfZ.LCIDEM.EagleEyeServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$QPfZ.LCIDEM.EagleEyeServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$QPfZ.LCIDEM.EagleEyeServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$QPfZ.LCIDEM.EagleEyeServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$QPfZ.LCIDEM.EagleEyeServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$QPfZ.LCIDEM.EagleEyeServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Services${separator}IEagleEyeRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5859452)
        
        

        //--TRIMMABLE-BOUNDARY-START(5728380)
        $asm.$cls(`$QPfZ.LCIDES.IEagleEyeDeviceHubClient`, ($self) => class IEagleEyeDeviceHubClient
        {
            static $h = 5728380;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 5728380
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Services${separator}IEagleEyeDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(5728380)
        
        

        //--TRIMMABLE-BOUNDARY-START(6318204)
        $asm.$cls(`$QPfZ.LCIDES$1.EagleEyeDeviceSettings`, ($self) => class EagleEyeDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $self, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(34366056572)
            /*bool*/ Invert = false;
            //--TRIMMABLE-BOUNDARY-END(34366056572)
            
            //--TRIMMABLE-BOUNDARY-START(38661023868)
            /*EagleEyeClickCommand*/ OnClick = 0;
            //--TRIMMABLE-BOUNDARY-END(38661023868)
            
            //--TRIMMABLE-BOUNDARY-START(12891220092)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891220092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12891220092)
            
            //--TRIMMABLE-BOUNDARY-START(12891220092)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12891220092)
            
            static $h = 6318204;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34366056572),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21481154684,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47250958460,
        "f": 83886081
      },
      "n": "Invert",
      "d": 6318204,
      "h": 34366056572,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 256,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34366056572),
//--TRIMMABLE-BOUNDARY-START(38661023868),
    {
      "p": 5924988,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30071089276,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55840893052,
        "f": 83886081
      },
      "n": "OnClick",
      "d": 6318204,
      "h": 38661023868,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 257,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38661023868)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12891220092),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 6318204,
      "h": 12891220092,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12891220092)
  ],
  "h": 6318204
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Settings${separator}EagleEyeDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6318204)
        
        

        //--TRIMMABLE-BOUNDARY-START(6056060)
        $asm.$cls(`$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings`, ($self) => class EagleEyeDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceHardwareSettings$$($.$QPfZ.LCIDEM.EagleEyeActions)
        {
            //--TRIMMABLE-BOUNDARY-START(60135598204)
            /*IOTDeviceInternalConfiguration<EagleEyeFrameSize>?*/ FrameSize = null;
            //--TRIMMABLE-BOUNDARY-END(60135598204)
            
            //--TRIMMABLE-BOUNDARY-START(55840630908)
            /*IOTDeviceInternalConfiguration<byte>?*/ FrameQuality = null;
            //--TRIMMABLE-BOUNDARY-END(55840630908)
            
            //--TRIMMABLE-BOUNDARY-START(47250696316)
            /*IOTDeviceInternalConfiguration<sbyte>?*/ Brightness = null;
            //--TRIMMABLE-BOUNDARY-END(47250696316)
            
            //--TRIMMABLE-BOUNDARY-START(51545663612)
            /*IOTDeviceInternalConfiguration<sbyte>?*/ Contrast = null;
            //--TRIMMABLE-BOUNDARY-END(51545663612)
            
            //--TRIMMABLE-BOUNDARY-START(158919846012)
            /*IOTDeviceInternalConfiguration<sbyte>?*/ Saturation = null;
            //--TRIMMABLE-BOUNDARY-END(158919846012)
            
            //--TRIMMABLE-BOUNDARY-START(146034944124)
            /*IOTDeviceInternalConfiguration<string>?*/ NotificationEmailFrom = null;
            //--TRIMMABLE-BOUNDARY-END(146034944124)
            
            //--TRIMMABLE-BOUNDARY-START(141739976828)
            /*IOTDeviceInternalConfiguration<string>?*/ NotificationEmailAddresses = null;
            //--TRIMMABLE-BOUNDARY-END(141739976828)
            
            //--TRIMMABLE-BOUNDARY-START(154624878716)
            /*IOTDeviceInternalConfiguration<string>?*/ NotificationEmailTitle = null;
            //--TRIMMABLE-BOUNDARY-END(154624878716)
            
            //--TRIMMABLE-BOUNDARY-START(150329911420)
            /*IOTDeviceInternalConfiguration<string>?*/ NotificationEmailMessage = null;
            //--TRIMMABLE-BOUNDARY-END(150329911420)
            
            //--TRIMMABLE-BOUNDARY-START(42955729020)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42955729020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42955729020)
            
            //--TRIMMABLE-BOUNDARY-START(42955729020)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(42955729020)
            
            static $h = 6056060;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceHardwareSettings$$($.$QPfZ.LCIDEM.EagleEyeActions); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60135598204),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$QPfZ.LCIDEM.EagleEyeFrameSize).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94495336572,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193279584380,
        "f": 83886081
      },
      "n": "FrameSize",
      "d": 6056060,
      "h": 60135598204,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "efs",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60135598204),
//--TRIMMABLE-BOUNDARY-START(55840630908),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85905401980,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184689649788,
        "f": 83886081
      },
      "n": "FrameQuality",
      "d": 6056060,
      "h": 55840630908,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "efq",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 21,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 6,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "Minimum=0",
                "Maximum=63"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55840630908),
//--TRIMMABLE-BOUNDARY-START(47250696316),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68725532796,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167509780604,
        "f": 83886081
      },
      "n": "Brightness",
      "d": 6056060,
      "h": 47250696316,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "eb",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 23,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 6,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "Minimum=-10",
                "Maximum=10"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47250696316),
//--TRIMMABLE-BOUNDARY-START(51545663612),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77315467388,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176099715196,
        "f": 83886081
      },
      "n": "Contrast",
      "d": 6056060,
      "h": 51545663612,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "ec",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 24,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 6,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "Minimum=-10",
                "Maximum=10"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51545663612),
//--TRIMMABLE-BOUNDARY-START(158919846012),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137445009532,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236229257340,
        "f": 83886081
      },
      "n": "Saturation",
      "d": 6056060,
      "h": 158919846012,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "es",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 25,
              "t": 655361
            },
            {
              "n": "InputType",
              "v": 6,
              "t": 47614294
            },
            {
              "n": "Options",
              "v": [
                "Minimum=-10",
                "Maximum=10"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158919846012),
//--TRIMMABLE-BOUNDARY-START(146034944124),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111675205756,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210459453564,
        "f": 83886081
      },
      "n": "NotificationEmailFrom",
      "d": 6056060,
      "h": 146034944124,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "eef",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 26,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146034944124),
//--TRIMMABLE-BOUNDARY-START(141739976828),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103085271164,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201869518972,
        "f": 83886081
      },
      "n": "NotificationEmailAddresses",
      "d": 6056060,
      "h": 141739976828,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "eea",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 27,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141739976828),
//--TRIMMABLE-BOUNDARY-START(154624878716),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128855074940,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227639322748,
        "f": 83886081
      },
      "n": "NotificationEmailTitle",
      "d": 6056060,
      "h": 154624878716,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "eet",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 28,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154624878716),
//--TRIMMABLE-BOUNDARY-START(150329911420),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120265140348,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219049388156,
        "f": 83886081
      },
      "n": "NotificationEmailMessage",
      "d": 6056060,
      "h": 150329911420,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "eem",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 29,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150329911420)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42955729020),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 6056060,
      "h": 42955729020,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42955729020)
  ],
  "h": 6056060
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Settings${separator}EagleEyeDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6056060)
        
        

        //--TRIMMABLE-BOUNDARY-START(551036)
        $asm.$cls(`$QPfZ.LCIDE.EagleEyeDeviceModelDefinition`, ($self) => class EagleEyeDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4295518332)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295518332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295518332)
            
            //--TRIMMABLE-BOUNDARY-START(4295518332)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295518332)
            
            static $h = 551036;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295518332),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 551036,
      "h": 4295518332,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295518332)
  ],
  "h": 551036
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.EagleEyeDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}EagleEyeDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(551036)
        
        

        //--TRIMMABLE-BOUNDARY-START(6449276)
        $asm.$cls(`$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptor`, ($self) => class EagleEyeDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDES$1.EagleEyeDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4301416572)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301416572);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptor.GenerateProperties($.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, this, factory);
                    }, $LIunTk ??= {"r":65537,"n":"","d":6449276,"h":0,"f":17825794}), 0, "EagleEyeDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Settings_EagleEyeDeviceSettings_LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettingsTypeDescriptorBuilder.g.cs", "EagleEyeDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301416572)
            
            //--TRIMMABLE-BOUNDARY-START(12891351164)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891351164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Invert"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings.$type, $.$discardRef(), "Invert", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Invert")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Invert";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings)).Invert);
                        }, $ZDeakf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6449276,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Invert = value.AsBool();
                        }, $zWMGKg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6449276,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("OnClick"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings.$type, $.$discardRef(), "OnClick", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("OnClick")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$QPfZ.LCIDES$1.EagleEyeClickCommand, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "OnClick";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$QPfZ.LCIDES$1.EagleEyeClickCommand, ($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings)).OnClick);
                        }, $VrReVc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6449276,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.OnClick = value.AsEnumValue($.$QPfZ.LCIDES$1.EagleEyeClickCommand);
                        }, $QnAXme ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6449276,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12891351164)
            
            //--TRIMMABLE-BOUNDARY-START(17186318460)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186318460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModel, LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings, LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModel, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceStatusHandler, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceHubClient, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _Invert = _target.Invert;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Invert"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Invert, ($v) => _Invert = $v, null, true)))
                    {
                        _target.Invert = _Invert;
                    }
                }
                {
                    /*var*/ let _OnClick = _target.OnClick;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("OnClick"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$QPfZ.LCIDES$1.EagleEyeClickCommand));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$QPfZ.LCIDES$1.EagleEyeClickCommand, () => _OnClick, ($v) => _OnClick = $v, null, true)))
                    {
                        _target.OnClick = _OnClick;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186318460)
            
            //--TRIMMABLE-BOUNDARY-START(8596383868)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596383868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDES$1.EagleEyeDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596383868)
            
            static $h = 6449276;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDES$1.EagleEyeDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891351164),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6449276,
      "h": 12891351164,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891351164),
//--TRIMMABLE-BOUNDARY-START(17186318460),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6318204,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6449276,
      "h": 17186318460,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186318460),
//--TRIMMABLE-BOUNDARY-START(8596383868),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6318204,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6449276,
      "h": 8596383868,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596383868)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301416572),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6449276,
      "h": 4301416572,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301416572)
  ],
  "h": 6449276
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDES$1.EagleEyeDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Settings${separator}EagleEyeDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6449276)
        
        

        //--TRIMMABLE-BOUNDARY-START(2189436)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceModelTypeDescriptor`, ($self) => class EagleEyeDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297156732)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297156732);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEM.EagleEyeDeviceModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEM.EagleEyeDeviceModel, this, factory);
                    }, $vqNdmf ??= {"r":65537,"n":"","d":2189436,"h":0,"f":17825794}), 0, "EagleEyeDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_EagleEyeDeviceModel_LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModelTypeDescriptorBuilder.g.cs", "EagleEyeDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297156732)
            
            //--TRIMMABLE-BOUNDARY-START(12887091324)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887091324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887091324)
            
            //--TRIMMABLE-BOUNDARY-START(17182058620)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182058620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModel, LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings, LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModel, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceStatusHandler, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceHubClient, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182058620)
            
            //--TRIMMABLE-BOUNDARY-START(8592124028)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592124028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEM.EagleEyeDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEM.EagleEyeDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592124028)
            
            static $h = 2189436;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887091324),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2189436,
      "h": 12887091324,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887091324),
//--TRIMMABLE-BOUNDARY-START(17182058620),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2058364,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2189436,
      "h": 17182058620,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182058620),
//--TRIMMABLE-BOUNDARY-START(8592124028),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2058364,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2189436,
      "h": 8592124028,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592124028)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297156732),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2189436,
      "h": 4297156732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297156732)
  ],
  "h": 2189436
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2189436)
        
        

        //--TRIMMABLE-BOUNDARY-START(2713724)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeDeviceScopeModelTypeDescriptor`, ($self) => class EagleEyeDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297681020)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297681020);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, this, factory);
                    }, $tQPBgk ??= {"r":65537,"n":"","d":2713724,"h":0,"f":17825794}), 0, "EagleEyeDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_EagleEyeDeviceScopeModel_LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModelTypeDescriptorBuilder.g.cs", "EagleEyeDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297681020)
            
            //--TRIMMABLE-BOUNDARY-START(12887615612)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887615612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887615612)
            
            //--TRIMMABLE-BOUNDARY-START(17182582908)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182582908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModel, LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings, LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModel, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceStatusHandler, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceHubClient, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182582908)
            
            //--TRIMMABLE-BOUNDARY-START(8592648316)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592648316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592648316)
            
            static $h = 2713724;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887615612),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2713724,
      "h": 12887615612,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887615612),
//--TRIMMABLE-BOUNDARY-START(17182582908),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2582652,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2713724,
      "h": 17182582908,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182582908),
//--TRIMMABLE-BOUNDARY-START(8592648316),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2582652,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2713724,
      "h": 8592648316,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592648316)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297681020),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2713724,
      "h": 4297681020,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297681020)
  ],
  "h": 2713724
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2713724)
        
        

        //--TRIMMABLE-BOUNDARY-START(4286588)
        $asm.$cls(`$QPfZ.LCIDEM.EagleEyeServiceModelTypeDescriptor`, ($self) => class EagleEyeServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299253884)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299253884);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDEM.EagleEyeServiceModelTypeDescriptor.GenerateProperties($.$QPfZ.LCIDEM.EagleEyeServiceModel, this, factory);
                    }, $wnIzLg ??= {"r":65537,"n":"","d":4286588,"h":0,"f":17825794}), 0, "EagleEyeServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Models_EagleEyeServiceModel_LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModelTypeDescriptorBuilder.g.cs", "EagleEyeServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299253884)
            
            //--TRIMMABLE-BOUNDARY-START(12889188476)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889188476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889188476)
            
            //--TRIMMABLE-BOUNDARY-START(17184155772)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184155772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModel, LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings, LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModel, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceStatusHandler, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceHubClient, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184155772)
            
            //--TRIMMABLE-BOUNDARY-START(8594221180)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594221180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDEM.EagleEyeServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDEM.EagleEyeServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeServiceModel)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDEM.EagleEyeServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDEM.EagleEyeServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDEM.EagleEyeServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594221180)
            
            static $h = 4286588;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889188476),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4286588,
      "h": 12889188476,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889188476),
//--TRIMMABLE-BOUNDARY-START(17184155772),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4155516,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4286588,
      "h": 17184155772,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184155772),
//--TRIMMABLE-BOUNDARY-START(8594221180),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4155516,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4286588,
      "h": 8594221180,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594221180)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299253884),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4286588,
      "h": 4299253884,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299253884)
  ],
  "h": 4286588
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Models${separator}EagleEyeServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4286588)
        
        

        //--TRIMMABLE-BOUNDARY-START(6187132)
        $asm.$cls(`$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor`, ($self) => class EagleEyeDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4301154428)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301154428);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, this, factory);
                    }, $yvsoXi ??= {"r":65537,"n":"","d":6187132,"h":0,"f":17825794}), 0, "EagleEyeDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EagleEye\\Settings_EagleEyeDeviceHardwareSettings_LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "EagleEyeDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301154428)
            
            //--TRIMMABLE-BOUNDARY-START(12891089020)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12891089020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FrameSize"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, $.$discardRef(), "FrameSize", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FrameSize")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$QPfZ.LCIDEM.EagleEyeFrameSize), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "FrameSize";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$QPfZ.LCIDEM.EagleEyeFrameSize), ($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)).FrameSize);
                        }, $DUOLPb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6187132,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FrameSize = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$QPfZ.LCIDEM.EagleEyeFrameSize));
                        }, $ZmQDPk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6187132,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("FrameQuality"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, $.$discardRef(), "FrameQuality", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("FrameQuality")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "FrameQuality";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte), ($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)).FrameQuality);
                        }, $xXeRUi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6187132,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.FrameQuality = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte));
                        }, $lqyuza ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6187132,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Brightness"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, $.$discardRef(), "Brightness", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Brightness")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Brightness";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte), ($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)).Brightness);
                        }, $HVWJEh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6187132,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Brightness = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte));
                        }, $ObRChk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6187132,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Contrast"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, $.$discardRef(), "Contrast", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Contrast")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Contrast";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte), ($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)).Contrast);
                        }, $fkpVxc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6187132,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Contrast = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte));
                        }, $DeUCnk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6187132,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Saturation"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, $.$discardRef(), "Saturation", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Saturation")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Saturation";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte), ($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)).Saturation);
                        }, $igxeyg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6187132,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Saturation = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte));
                        }, $lyBVbf ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6187132,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NotificationEmailFrom"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, $.$discardRef(), "NotificationEmailFrom", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NotificationEmailFrom")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "NotificationEmailFrom";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), ($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)).NotificationEmailFrom);
                        }, $tQBHZb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6187132,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NotificationEmailFrom = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String));
                        }, $UeCMna ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6187132,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NotificationEmailAddresses"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, $.$discardRef(), "NotificationEmailAddresses", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NotificationEmailAddresses")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t13 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i13 = new $t13();
                        $i13.$ctor$2();
                        $i13.Name = "NotificationEmailAddresses";
                        $i13.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings";
                        $i13.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), ($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)).NotificationEmailAddresses);
                        }, $ypKtTd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6187132,"h":0,"f":17825826});
                        $i13.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NotificationEmailAddresses = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String));
                        }, $iCBLuj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6187132,"h":0,"f":17825826});
                        return $i13;
                    })()), schemas, null, factory);
                    let $en14 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en14.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NotificationEmailTitle"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, $.$discardRef(), "NotificationEmailTitle", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NotificationEmailTitle")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t15 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i15 = new $t15();
                        $i15.$ctor$2();
                        $i15.Name = "NotificationEmailTitle";
                        $i15.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings";
                        $i15.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), ($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)).NotificationEmailTitle);
                        }, $vSYugk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6187132,"h":0,"f":17825826});
                        $i15.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NotificationEmailTitle = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String));
                        }, $XfkYOh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6187132,"h":0,"f":17825826});
                        return $i15;
                    })()), schemas, null, factory);
                    let $en16 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en16.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en16.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("NotificationEmailMessage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings.$type, $.$discardRef(), "NotificationEmailMessage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("NotificationEmailMessage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t17 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i17 = new $t17();
                        $i17.$ctor$2();
                        $i17.Name = "NotificationEmailMessage";
                        $i17.DelaredOn = "LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings";
                        $i17.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), ($.$cast(target, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)).NotificationEmailMessage);
                        }, $LKNxgf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":6187132,"h":0,"f":17825826});
                        $i17.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.NotificationEmailMessage = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String));
                        }, $mCNiAg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":6187132,"h":0,"f":17825826});
                        return $i17;
                    })()), schemas, null, factory);
                    let $en18 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en18.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en18.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeActions).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12891089020)
            
            //--TRIMMABLE-BOUNDARY-START(17186056316)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186056316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceModel, LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceSettings, LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceSendDataModel, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceStatusHandler, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeDeviceHubClient, LivingThing.Core.IOT.Devices.EagleEye.Services.IEagleEyeRemoteService>.iSmartDeviceHardwareSettings<LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeActions>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$QPfZ.LCIDEM.EagleEyeActions).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService).iSmartDeviceHardwareSettings$$($.$QPfZ.LCIDEM.EagleEyeActions)));
                {
                    /*var*/ let _FrameSize = _target.FrameSize;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FrameSize"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$QPfZ.LCIDEM.EagleEyeFrameSize)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _FrameSize, ($v) => _FrameSize = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$QPfZ.LCIDEM.EagleEyeFrameSize))))
                    {
                        _target.FrameSize = _FrameSize;
                    }
                }
                {
                    /*var*/ let _FrameQuality = _target.FrameQuality;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("FrameQuality"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _FrameQuality, ($v) => _FrameQuality = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Byte))))
                    {
                        _target.FrameQuality = _FrameQuality;
                    }
                }
                {
                    /*var*/ let _Brightness = _target.Brightness;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Brightness"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Brightness, ($v) => _Brightness = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte))))
                    {
                        _target.Brightness = _Brightness;
                    }
                }
                {
                    /*var*/ let _Contrast = _target.Contrast;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Contrast"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Contrast, ($v) => _Contrast = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte))))
                    {
                        _target.Contrast = _Contrast;
                    }
                }
                {
                    /*var*/ let _Saturation = _target.Saturation;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Saturation"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Saturation, ($v) => _Saturation = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.SByte))))
                    {
                        _target.Saturation = _Saturation;
                    }
                }
                {
                    /*var*/ let _NotificationEmailFrom = _target.NotificationEmailFrom;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NotificationEmailFrom"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _NotificationEmailFrom, ($v) => _NotificationEmailFrom = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String))))
                    {
                        _target.NotificationEmailFrom = _NotificationEmailFrom;
                    }
                }
                {
                    /*var*/ let _NotificationEmailAddresses = _target.NotificationEmailAddresses;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NotificationEmailAddresses"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _NotificationEmailAddresses, ($v) => _NotificationEmailAddresses = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String))))
                    {
                        _target.NotificationEmailAddresses = _NotificationEmailAddresses;
                    }
                }
                {
                    /*var*/ let _NotificationEmailTitle = _target.NotificationEmailTitle;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NotificationEmailTitle"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _NotificationEmailTitle, ($v) => _NotificationEmailTitle = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String))))
                    {
                        _target.NotificationEmailTitle = _NotificationEmailTitle;
                    }
                }
                {
                    /*var*/ let _NotificationEmailMessage = _target.NotificationEmailMessage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("NotificationEmailMessage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _NotificationEmailMessage, ($v) => _NotificationEmailMessage = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String))))
                    {
                        _target.NotificationEmailMessage = _NotificationEmailMessage;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17186056316)
            
            //--TRIMMABLE-BOUNDARY-START(8596121724)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596121724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8596121724)
            
            static $h = 6187132;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12891089020),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 6187132,
      "h": 12891089020,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12891089020),
//--TRIMMABLE-BOUNDARY-START(17186056316),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6056060,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 6187132,
      "h": 17186056316,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17186056316),
//--TRIMMABLE-BOUNDARY-START(8596121724),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 6056060,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 6187132,
      "h": 8596121724,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8596121724)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301154428),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 6187132,
      "h": 4301154428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301154428)
  ],
  "h": 6187132
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Settings.EagleEyeDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Settings${separator}EagleEyeDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6187132)
        
        

        //--TRIMMABLE-BOUNDARY-START(354428)
        $asm.$cls(`$QPfZ.LCIDE.EagleEyeDevice`, ($self) => class EagleEyeDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$QPfZ.LCIDEMS.EagleEyeStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4295321724)
            $ctor$2(/*IIOTDeviceFamily<EagleEyeDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*EagleEyeDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295321724);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295321724)
            
            //--TRIMMABLE-BOUNDARY-START(51539961980)
            /*IconDescriptor */ get Icon()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770158204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let icon = super.Icon;
                return (() =>
                {
                    //new $.$fPer.LCFC.IconDescriptor()
                    const $t1 = $.$fPer.LCFC.IconDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Icon = this.Model$1.DeviceType !== 0/*IOTDeviceType.Others*/ ? $.$XBGm.LCIC.UtilityExtension.MaterialIcon(this.Model$1.DeviceType, this.On) : icon.Icon;
                    $i1.Theme = $.$with(icon.Theme, ($clone) =>
                    {
                        $clone.ForegroundColor = this.On ? "FFFF00" : "FFFFFF";
                    });
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(51539961980)
            
            //--TRIMMABLE-BOUNDARY-START(60129896572)
            /*bool */ get On()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360092796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca2__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ let __ca3__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca4__;
                /*var*/ let b = (((__ca1__ = this.Received) !== null ? ((__ca2__ = __ca1__.Status) !== null ? ((__ca2__.State & (1/*EagleEyeFlags.StreamingLocal*/)) == (1/*EagleEyeFlags.StreamingLocal*/)) : false) : false)) || (((__ca3__ = this.Received) !== null ? ((__ca4__ = __ca3__.Status) !== null ? ((__ca4__.State & (2/*EagleEyeFlags.StreamingRemote*/)) == (2/*EagleEyeFlags.StreamingRemote*/)) : false) : false));
                return b;
            }
            //--TRIMMABLE-BOUNDARY-END(60129896572)
            
            //--TRIMMABLE-BOUNDARY-START(94489634940)
            /*string */ get StatusText()
            {
                return this.On ? "ON" : "OFF";
            }
            //--TRIMMABLE-BOUNDARY-END(94489634940)
            
            //--TRIMMABLE-BOUNDARY-START(73014798460)
            /*Task */ SetFlags(/*EagleEyeFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014798460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$QPfZ.LCIDEPCV.EagleEyeControlCommand, $.$QPfZ.LCIDEMC.EagleEyeControlModel, this, new $.$QPfZ.LCIDEPCV.EagleEyeControlCommand().$ctor$5(), new $.$QPfZ.LCIDEMC.EagleEyeControlModel().$ctor$3(true, flags));
            }
            //--TRIMMABLE-BOUNDARY-END(73014798460)
            
            //--TRIMMABLE-BOUNDARY-START(12885256316)
            /*Task */ ClearFlags(/*EagleEyeFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885256316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$QPfZ.LCIDEPCV.EagleEyeControlCommand, $.$QPfZ.LCIDEMC.EagleEyeControlModel, this, new $.$QPfZ.LCIDEPCV.EagleEyeControlCommand().$ctor$5(), new $.$QPfZ.LCIDEMC.EagleEyeControlModel().$ctor$3(false, flags));
            }
            //--TRIMMABLE-BOUNDARY-END(12885256316)
            
            //--TRIMMABLE-BOUNDARY-START(81604733052)
            /*Task */ SetOnOffLocal(/*bool*/ on)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604733052);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return on ? this.SetFlags(1/*EagleEyeFlags.StreamingLocal*/) : this.ClearFlags(1/*EagleEyeFlags.StreamingLocal*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604733052)
            
            //--TRIMMABLE-BOUNDARY-START(85899700348)
            /*Task */ SetOnOffRemote(/*bool*/ on)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899700348);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return on ? this.SetFlags(2/*EagleEyeFlags.StreamingRemote*/) : this.ClearFlags(2/*EagleEyeFlags.StreamingRemote*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899700348)
            
            //--TRIMMABLE-BOUNDARY-START(68719831164)
            /*Task */ SetArmed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719831164);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.SetFlags(4/*EagleEyeFlags.Armed*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719831164)
            
            //--TRIMMABLE-BOUNDARY-START(124554406012)
            /*Task */ ToggleStreaming()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554406012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ let __ca5__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca6__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ let __ca7__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca8__;
                /*var*/ let streaming = (((__ca5__ = this.Received) !== null ? ((__ca6__ = __ca5__.Status) !== null ? ((__ca6__.State & (1/*EagleEyeFlags.StreamingLocal*/)) == (1/*EagleEyeFlags.StreamingLocal*/)) : false) : false)) || (((__ca7__ = this.Received) !== null ? ((__ca8__ = __ca7__.Status) !== null ? ((__ca8__.State & (2/*EagleEyeFlags.StreamingRemote*/)) == (2/*EagleEyeFlags.StreamingRemote*/)) : false) : false));
                return !streaming ? this.SetFlags(this.ConnectedLocally ? 1/*EagleEyeFlags.StreamingLocal*/ : 2/*EagleEyeFlags.StreamingRemote*/) : this.ClearFlags(1/*EagleEyeFlags.StreamingLocal*/ | 2/*EagleEyeFlags.StreamingRemote*/);
            }
            //--TRIMMABLE-BOUNDARY-END(124554406012)
            
            //--TRIMMABLE-BOUNDARY-START(111669504124)
            /*Task */ ToggleLocalStreaming()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669504124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca9__;
                return !(((__ca9__ = this.Received.Status) !== null ? ((__ca9__.State & (1/*EagleEyeFlags.StreamingLocal*/)) == (1/*EagleEyeFlags.StreamingLocal*/)) : false)) ? this.SetFlags(1/*EagleEyeFlags.StreamingLocal*/) : this.ClearFlags(1/*EagleEyeFlags.StreamingLocal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(111669504124)
            
            //--TRIMMABLE-BOUNDARY-START(120259438716)
            /*Task */ ToggleRemoteStreaming()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259438716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca10__;
                return !(((__ca10__ = this.Received.Status) !== null ? ((__ca10__.State & (1/*EagleEyeFlags.StreamingLocal*/)) == (1/*EagleEyeFlags.StreamingLocal*/)) : false)) ? this.SetFlags(1/*EagleEyeFlags.StreamingLocal*/) : this.ClearFlags(1/*EagleEyeFlags.StreamingLocal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(120259438716)
            
            //--TRIMMABLE-BOUNDARY-START(98784602236)
            /*Task */ ToggleArm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784602236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca11__;
                return !(((__ca11__ = this.Received.Status) !== null ? ((__ca11__.State & (4/*EagleEyeFlags.Armed*/)) == (4/*EagleEyeFlags.Armed*/)) : false)) ? this.SetFlags(4/*EagleEyeFlags.Armed*/) : this.ClearFlags(4/*EagleEyeFlags.Armed*/);
            }
            //--TRIMMABLE-BOUNDARY-END(98784602236)
            
            //--TRIMMABLE-BOUNDARY-START(115964471420)
            /*Task */ ToggleRecord()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964471420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca12__;
                return !(((__ca12__ = this.Received.Status) !== null ? ((__ca12__.State & (4/*EagleEyeFlags.Armed*/)) == (4/*EagleEyeFlags.Armed*/)) : false)) ? this.SetFlags(16/*EagleEyeFlags.Recording*/) : this.ClearFlags(16/*EagleEyeFlags.Recording*/);
            }
            //--TRIMMABLE-BOUNDARY-END(115964471420)
            
            //--TRIMMABLE-BOUNDARY-START(107374536828)
            /*Task */ ToggleListen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374536828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca13__;
                return !(((__ca13__ = this.Received.Status) !== null ? ((__ca13__.State & (4/*EagleEyeFlags.Armed*/)) == (4/*EagleEyeFlags.Armed*/)) : false)) ? this.SetFlags(32/*EagleEyeFlags.Listening*/) : this.ClearFlags(32/*EagleEyeFlags.Listening*/);
            }
            //--TRIMMABLE-BOUNDARY-END(107374536828)
            
            //--TRIMMABLE-BOUNDARY-START(8590289020)
            /*Task */ AdjustCamera(/*EagleEyeCameraCommand*/ command, /*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590289020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$QPfZ.LCIDEPCV.EagleEyeCameraControlCommand, $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel, this, new $.$QPfZ.LCIDEPCV.EagleEyeCameraControlCommand().$ctor$6(), new $.$QPfZ.LCIDEMC.EagleEyeCameraControlModel().$ctor$3(command, value));
            }
            //--TRIMMABLE-BOUNDARY-END(8590289020)
            
            //--TRIMMABLE-BOUNDARY-START(64424863868)
            /*Task */ OnFlash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424863868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AdjustCamera(51/*EagleEyeCameraCommand.Flash*/, 1);
            }
            //--TRIMMABLE-BOUNDARY-END(64424863868)
            
            //--TRIMMABLE-BOUNDARY-START(55834929276)
            /*Task */ OffFlash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834929276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AdjustCamera(51/*EagleEyeCameraCommand.Flash*/, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(55834929276)
            
            //--TRIMMABLE-BOUNDARY-START(103079569532)
            /*Task */ ToggleFlash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079569532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this.Received?.Status ?? null) === null)
                {
                    return $.$$.STT.Task.CompletedTask;
                }
                if (((this.Received.Status.State & (128/*EagleEyeFlags.Flash*/)) == (128/*EagleEyeFlags.Flash*/)))
                {
                    return this.OffFlash();
                }
                else 
                {
                    return this.OnFlash();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079569532)
            
            //--TRIMMABLE-BOUNDARY-START(77309765756)
            /*Task */ SetFPS(/*EagleFramePerSecond*/ fps)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309765756);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.AdjustCamera(50/*EagleEyeCameraCommand.FPS*/, $.$cast(fps, $.$$.S.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309765756)
            
            //--TRIMMABLE-BOUNDARY-START(47244994684)
            /*ValueTask<PagingDataResult<EagleEyeFileModel>> *//*async*/  GetRecordings(/*DataFilter*/ filter)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$QPfZ.LCIDEMS.EagleEyeFileModel)), $.$fPer.LCFCD.PagingDataResult$$($.$QPfZ.LCIDEMS.EagleEyeFileModel), async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244994684);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let request = new $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel().$ctor$3(filter.Skip, filter.Take);
                    /*var*/ let v = ($t2 = $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.SendCommand$2($.$QPfZ.LCIDEPCV.EagleEyeRecordingsCommand, $.$QPfZ.LCIDEMC.EagleEyeRecordingsControlModel, $.$QPfZ.LCIDEM.EagleEyeRecordingsResponseModel, this, new $.$QPfZ.LCIDEPCV.EagleEyeRecordingsCommand().$ctor$5(), request, null), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$fPer.LCFCD.Paging.AsPagingDataResult$1($.$QPfZ.LCIDEMS.EagleEyeFileModel, v.Data.Files));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47244994684)
            
            //--TRIMMABLE-BOUNDARY-START(17180223612)
            /*Task */ Clicked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180223612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.On)
                {
                    return this.ClearFlags(1/*EagleEyeFlags.StreamingLocal*/ | 2/*EagleEyeFlags.StreamingRemote*/);
                }
                else 
                {
                    return this.SetFlags(1/*EagleEyeFlags.StreamingLocal*/ | 2/*EagleEyeFlags.StreamingRemote*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180223612)
            
            //--TRIMMABLE-BOUNDARY-START(90194667644)
            /*void */ SetStatus(/*bool*/ enable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194667644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetOnOffLocal(enable);
            }
            //--TRIMMABLE-BOUNDARY-END(90194667644)
            
            static $h = 354428;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$QPfZ.LCIDEMS.EagleEyeStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51539961980),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770158204,
        "f": 50364417
      },
      "n": "Icon",
      "d": 354428,
      "h": 51539961980,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51539961980),
//--TRIMMABLE-BOUNDARY-START(60129896572),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360092796,
        "f": 50331649
      },
      "n": "On",
      "d": 354428,
      "h": 60129896572,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129896572),
//--TRIMMABLE-BOUNDARY-START(94489634940),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950027388,
        "f": 50364417
      },
      "n": "StatusText",
      "d": 354428,
      "h": 94489634940,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(94489634940)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73014798460),
    {
      "r": 178454529,
      "p": [
        {
          "n": "flags",
          "p": 3238012
        }
      ],
      "n": "SetFlags",
      "d": 354428,
      "h": 73014798460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014798460),
//--TRIMMABLE-BOUNDARY-START(12885256316),
    {
      "r": 178454529,
      "p": [
        {
          "n": "flags",
          "p": 3238012
        }
      ],
      "n": "ClearFlags",
      "d": 354428,
      "h": 12885256316,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885256316),
//--TRIMMABLE-BOUNDARY-START(81604733052),
    {
      "r": 178454529,
      "p": [
        {
          "n": "on",
          "p": 262145
        }
      ],
      "n": "SetOnOffLocal",
      "d": 354428,
      "h": 81604733052,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604733052),
//--TRIMMABLE-BOUNDARY-START(85899700348),
    {
      "r": 178454529,
      "p": [
        {
          "n": "on",
          "p": 262145
        }
      ],
      "n": "SetOnOffRemote",
      "d": 354428,
      "h": 85899700348,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899700348),
//--TRIMMABLE-BOUNDARY-START(68719831164),
    {
      "r": 178454529,
      "n": "SetArmed",
      "d": 354428,
      "h": 68719831164,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719831164),
//--TRIMMABLE-BOUNDARY-START(124554406012),
    {
      "r": 178454529,
      "n": "ToggleStreaming",
      "d": 354428,
      "h": 124554406012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554406012),
//--TRIMMABLE-BOUNDARY-START(111669504124),
    {
      "r": 178454529,
      "n": "ToggleLocalStreaming",
      "d": 354428,
      "h": 111669504124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669504124),
//--TRIMMABLE-BOUNDARY-START(120259438716),
    {
      "r": 178454529,
      "n": "ToggleRemoteStreaming",
      "d": 354428,
      "h": 120259438716,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120259438716),
//--TRIMMABLE-BOUNDARY-START(98784602236),
    {
      "r": 178454529,
      "n": "ToggleArm",
      "d": 354428,
      "h": 98784602236,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784602236),
//--TRIMMABLE-BOUNDARY-START(115964471420),
    {
      "r": 178454529,
      "n": "ToggleRecord",
      "d": 354428,
      "h": 115964471420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964471420),
//--TRIMMABLE-BOUNDARY-START(107374536828),
    {
      "r": 178454529,
      "n": "ToggleListen",
      "d": 354428,
      "h": 107374536828,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374536828),
//--TRIMMABLE-BOUNDARY-START(8590289020),
    {
      "r": 178454529,
      "p": [
        {
          "n": "command",
          "p": 878716
        },
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "AdjustCamera",
      "d": 354428,
      "h": 8590289020,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590289020),
//--TRIMMABLE-BOUNDARY-START(64424863868),
    {
      "r": 178454529,
      "n": "OnFlash",
      "d": 354428,
      "h": 64424863868,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424863868),
//--TRIMMABLE-BOUNDARY-START(55834929276),
    {
      "r": 178454529,
      "n": "OffFlash",
      "d": 354428,
      "h": 55834929276,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834929276),
//--TRIMMABLE-BOUNDARY-START(103079569532),
    {
      "r": 178454529,
      "n": "ToggleFlash",
      "d": 354428,
      "h": 103079569532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079569532),
//--TRIMMABLE-BOUNDARY-START(77309765756),
    {
      "r": 178454529,
      "p": [
        {
          "n": "fps",
          "p": 4417660
        }
      ],
      "n": "SetFPS",
      "d": 354428,
      "h": 77309765756,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309765756),
//--TRIMMABLE-BOUNDARY-START(47244994684),
    {
      "r": $.$$.STT.ValueTask$$($.$fPer.LCFCD.PagingDataResult$$($.$QPfZ.LCIDEMS.EagleEyeFileModel)).$h,
      "p": [
        {
          "n": "filter",
          "p": 9734486
        }
      ],
      "n": "GetRecordings",
      "d": 354428,
      "h": 47244994684,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(47244994684),
//--TRIMMABLE-BOUNDARY-START(17180223612),
    {
      "r": 178454529,
      "n": "Clicked",
      "d": 354428,
      "h": 17180223612,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180223612),
//--TRIMMABLE-BOUNDARY-START(90194667644),
    {
      "r": 65537,
      "p": [
        {
          "n": "enable",
          "p": 262145
        }
      ],
      "n": "SetStatus",
      "d": 354428,
      "h": 90194667644,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90194667644)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295321724),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$QPfZ.LCIDE.EagleEyeDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 2058364
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 354428,
      "h": 4295321724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295321724)
  ],
  "h": 354428
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.EagleEyeDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}EagleEyeDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(354428)
        
        

        //--TRIMMABLE-BOUNDARY-START(419964)
        $asm.$cls(`$QPfZ.LCIDE.EagleEyeDeviceDefinition`, ($self) => class EagleEyeDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$QPfZ.LCIDEMS.EagleEyeStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295387260)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295387260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295387260)
            
            //--TRIMMABLE-BOUNDARY-START(4295387260)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295387260)
            
            static $h = 419964;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$QPfZ.LCIDEMS.EagleEyeStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295387260),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 419964,
      "h": 4295387260,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295387260)
  ],
  "h": 419964
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.EagleEyeDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}EagleEyeDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(419964)
        
        

        //--TRIMMABLE-BOUNDARY-START(485500)
        $asm.$cls(`$QPfZ.LCIDE.EagleEyeDeviceFamily`, ($self) => class EagleEyeDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4295452796)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<EagleEyeDeviceReceivedDataModel, EagleEyeDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<EagleEyeDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295452796);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295452796)
            
            //--TRIMMABLE-BOUNDARY-START(8590420092)
            /*Type */ get DeviceBroadcastSendMessageEnumType()
            {
                return $.$QPfZ.LCIDEM.EagleEyeBroadcastPeerMessages.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8590420092)
            
            //--TRIMMABLE-BOUNDARY-START(12885387388)
            /*Type */ get DeviceLogType()
            {
                return $.$QPfZ.LCIDEM.EagleEyeLogModel.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(12885387388)
            
            static $h = 485500;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDEM.EagleEyeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$QPfZ.LCIDEM.EagleEyeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$QPfZ.LCIDEM.EagleEyeDeviceModel, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel, $.$QPfZ.LCIDES.IEagleEyeDeviceStatusHandler, $.$QPfZ.LCIDES.IEagleEyeDeviceHubClient, $.$QPfZ.LCIDES.IEagleEyeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590420092),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475321980,
        "f": 50364417
      },
      "n": "DeviceBroadcastSendMessageEnumType",
      "d": 485500,
      "h": 8590420092,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8590420092),
//--TRIMMABLE-BOUNDARY-START(12885387388),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065256572,
        "f": 50364417
      },
      "n": "DeviceLogType",
      "d": 485500,
      "h": 12885387388,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885387388)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295452796),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 485500,
      "h": 4295452796,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295452796)
  ],
  "h": 485500
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$QPfZ.LCIDE.EagleEyeDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.EagleEyeDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}EagleEyeDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(485500)
        
        

        //--TRIMMABLE-BOUNDARY-START(7039100)
        $asm.$cls(`$QPfZ.LCIDEV.EagleEyeViewRenderer`, ($self) => class EagleEyeViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4302006396)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4302006396);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4302006396)
            
            //--TRIMMABLE-BOUNDARY-START(8596973692)
            /*RenderFragment */ GetView(/*IClientUnitOfWork*/ ui, /*EagleEyeDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>*/ clicked, /*Func<Task>*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596973692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$QPfZ.LCIDEV.EagleEyeDeviceDetails, $.$QPfZ.LCIDEV.EagleEyeDetailsViewModel, new $.$QPfZ.LCIDEV.EagleEyeDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8596973692)
            
            static $h = 7039100;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8596973692),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 354428
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 7039100,
      "h": 8596973692,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8596973692)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4302006396),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 7039100,
      "h": 4302006396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4302006396)
  ],
  "h": 7039100
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$QPfZ.LCIDE.EagleEyeDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Views.EagleEyeViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Views${separator}EagleEyeViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(7039100)
        
        

        //--TRIMMABLE-BOUNDARY-START(6711420)
        $asm.$cls(`$QPfZ.LCIDEV.EagleEyeDetailsViewModel`, ($self) => class EagleEyeDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4301678716)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*EagleEyeDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4301678716);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4301678716)
            
            //--TRIMMABLE-BOUNDARY-START(34366449788)
            /*void */ OnPropertyChanged$1(/*object*/ sender, /*PropertyChangedEventArgs*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34366449788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sender === this.Device$1 && (args.PropertyName === "Status" || args.PropertyName === "ReceivedStatus"))
                {
                    this.RaisePropertyChanged$1("ButtonText");
                }
                super.OnPropertyChanged$1(sender, args);
            }
            //--TRIMMABLE-BOUNDARY-END(34366449788)
            
            //--TRIMMABLE-BOUNDARY-START(38661417084)
            /*string */ get Title()
            {
                return `${$.$strNN(this.Device$1.Model$1.Name)} (Smart Endpoint)`;
            }
            //--TRIMMABLE-BOUNDARY-END(38661417084)
            
            //--TRIMMABLE-BOUNDARY-START(8596646012)
            /*string */ get ButtonText()
            {
                return this.Device$1.On ? "OFF" : "ON";
            }
            //--TRIMMABLE-BOUNDARY-END(8596646012)
            
            //--TRIMMABLE-BOUNDARY-START(12891613308)
            /*Task *//*async*/  Click()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12891613308);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    try
                    {
                        let $t1, $r1;
                        ($t1 = this.Device$1.Clicked(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    catch($e)
                    {
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12891613308)
            
            static $h = 6711420;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$QPfZ.LCIDE.EagleEyeDevice, $.$QPfZ.LCIDES$1.EagleEyeDeviceSettings, $.$QPfZ.LCIDES$1.EagleEyeDeviceHardwareSettings, $.$QPfZ.LCIDEM.EagleEyeDeviceReceivedDataModel, $.$QPfZ.LCIDEM.EagleEyeDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38661417084),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30071482492,
        "f": 50331649
      },
      "n": "Title",
      "d": 6711420,
      "h": 38661417084,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38661417084),
//--TRIMMABLE-BOUNDARY-START(8596646012),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21481547900,
        "f": 50331649
      },
      "n": "ButtonText",
      "d": 6711420,
      "h": 8596646012,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8596646012)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34366449788),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "args",
          "p": 1310738
        }
      ],
      "n": "OnPropertyChanged",
      "o": "@$1",
      "d": 6711420,
      "h": 34366449788,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34366449788),
//--TRIMMABLE-BOUNDARY-START(12891613308),
    {
      "r": 178454529,
      "n": "Click",
      "d": 6711420,
      "h": 12891613308,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(12891613308)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4301678716),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 354428
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 6711420,
      "h": 4301678716,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4301678716)
  ],
  "h": 6711420
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Views.EagleEyeDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Views${separator}EagleEyeDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6711420)
        
        

        //--TRIMMABLE-BOUNDARY-START(6776956)
        $asm.$cls(`$QPfZ.LCIDEV.EagleEyeDeviceDetails`, ($self) => class EagleEyeDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$QPfZ.LCIDEV.EagleEyeDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(158920566908)
            /*EagleEyeDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(158920566908)
            
            //--TRIMMABLE-BOUNDARY-START(150330632316)
            /*bool */ get Streaming()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81611155580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca2__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ let __ca3__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca4__;
                return (((__ca1__ = this.ViewModel.Device$1.Received) !== null ? ((__ca2__ = __ca1__.Status) !== null ? ((__ca2__.State & (2/*EagleEyeFlags.StreamingRemote*/)) == (2/*EagleEyeFlags.StreamingRemote*/)) : false) : false)) || (((__ca3__ = this.ViewModel.Device$1.Received) !== null ? ((__ca4__ = __ca3__.Status) !== null ? ((__ca4__.State & (1/*EagleEyeFlags.StreamingLocal*/)) == (1/*EagleEyeFlags.StreamingLocal*/)) : false) : false));
            }
            //--TRIMMABLE-BOUNDARY-END(150330632316)
            
            //--TRIMMABLE-BOUNDARY-START(12891678844)
            /*bool */ get Armed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38661482620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ let __ca5__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca6__;
                return ((__ca5__ = this.ViewModel.Device$1.Received) !== null ? ((__ca6__ = __ca5__.Status) !== null ? ((__ca6__.State & (4/*EagleEyeFlags.Armed*/)) == (4/*EagleEyeFlags.Armed*/)) : false) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(12891678844)
            
            //--TRIMMABLE-BOUNDARY-START(128855795836)
            /*bool */ get Recoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73021220988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ let __ca7__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca8__;
                return ((__ca7__ = this.ViewModel.Device$1.Received) !== null ? ((__ca8__ = __ca7__.Status) !== null ? ((__ca8__.State & (16/*EagleEyeFlags.Recording*/)) == (16/*EagleEyeFlags.Recording*/)) : false) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(128855795836)
            
            //--TRIMMABLE-BOUNDARY-START(94496057468)
            /*bool */ get Listening()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55841351804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ let __ca9__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca10__;
                return ((__ca9__ = this.ViewModel.Device$1.Received) !== null ? ((__ca10__ = __ca9__.Status) !== null ? ((__ca10__.State & (32/*EagleEyeFlags.Listening*/)) == (32/*EagleEyeFlags.Listening*/)) : false) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(94496057468)
            
            //--TRIMMABLE-BOUNDARY-START(30071548028)
            /*bool */ get Flash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47251417212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.EagleEyeDeviceReceivedDataModel?*/ let __ca11__;
                /*LivingThing.Core.IOT.Devices.EagleEye.Models.Statuses.EagleEyeStatusModel?*/ let __ca12__;
                return ((__ca11__ = this.ViewModel.Device$1.Received) !== null ? ((__ca12__ = __ca11__.Status) !== null ? ((__ca12__.State & (128/*EagleEyeFlags.Flash*/)) == (128/*EagleEyeFlags.Flash*/)) : false) : false);
            }
            //--TRIMMABLE-BOUNDARY-END(30071548028)
            
            //--TRIMMABLE-BOUNDARY-START(137445730428)
            /*int*/ rotation = 0;
            //--TRIMMABLE-BOUNDARY-END(137445730428)
            
            //--TRIMMABLE-BOUNDARY-START(124560828540)
            /*Random*/ random = null;
            //--TRIMMABLE-BOUNDARY-END(124560828540)
            
            //--TRIMMABLE-BOUNDARY-START(133150763132)
            /*void */ Rotate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133150763132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.rotation += 90;
                if (this.rotation >= 360)
                {
                    this.rotation = 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133150763132)
            
            //--TRIMMABLE-BOUNDARY-START(111675926652)
            /*Task */ OnInitializedAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111675926652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return super.OnInitializedAsync();
            }
            //--TRIMMABLE-BOUNDARY-END(111675926652)
            
            //--TRIMMABLE-BOUNDARY-START(25776580732)
            /*bool*/ disposed = false;
            //--TRIMMABLE-BOUNDARY-END(25776580732)
            
            //--TRIMMABLE-BOUNDARY-START(107380959356)
            /*void */ OnInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107380959356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.STT.Task.Run$3(new ($.$$.S.Func$$($.$$.STT.Task))().$ctor(this, (/*async*/  () =>
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        while(!this.disposed)
                        {
                            let $t2, $r2;
                            if (this.Streaming)
                            {
                                try
                                {
                                    let $t1, $r1;
                                    ($t1 = this.ViewModel.Device$1.SetFlags((this.ViewModel.Device$1.Received.Status.State & (2/*EagleEyeFlags.StreamingRemote*/ | 1/*EagleEyeFlags.StreamingLocal*/))).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                                }
                                catch($e)
                                {
                                }
                            }
                            ($t2 = $.$$.STT.Task.Delay$1(15000).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                    });
                }), $KABUwi ??= {"r":178454529,"n":"","d":6776956,"h":0,"f":17829890}));
                super.OnInitialized();
            }
            //--TRIMMABLE-BOUNDARY-END(107380959356)
            
            //--TRIMMABLE-BOUNDARY-START(21481613436)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21481613436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.disposed = true;
                super.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(21481613436)
            
            //--TRIMMABLE-BOUNDARY-START(98791024764)
            /*void */ OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98791024764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(98791024764)
            
            //--TRIMMABLE-BOUNDARY-START(103085992060)
            /*void */ OnError(/*Exception*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103085992060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(103085992060)
            
            //--TRIMMABLE-BOUNDARY-START(115970893948)
            /*void */ OnNext(/*ReadOnlyMemory<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115970893948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(115970893948)
            
            //--TRIMMABLE-BOUNDARY-START(120265861244)
            /*string */ get OptimizedComponentName()
            {
                return "eagleeyedevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(120265861244)
            
            //--TRIMMABLE-BOUNDARY-START(154625599612)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154625599612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch3 = parameter.Name;
                switch($switch3)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$QPfZ.LCIDEV.EagleEyeDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(154625599612)
            
            //--TRIMMABLE-BOUNDARY-START(17186646140)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17186646140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$QPfZ.LCIDE.EagleEyeDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$QPfZ.LCIDE.EagleEyeDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    let $t4 = this.ViewModel.Device$1;
                    let $t5 = this.ViewModel.Device$1;
                    let $t6 = this.ViewModel.Device$1;
                    __builder2.OpenElement(3, "div");
                    __builder2.AddAttribute$5(4, "class", "pos-rel mihx-2 clip");
                    if (this.ViewModel.Device$1.ConnectedLocally)
                    {
                        __builder2.OpenComponent$1($.$QPfZ.LCIDEV.ImageStream, 5);
                        __builder2.AddComponentParameter(6, "Device", this.ViewModel.Device$1);
                        __builder2.AddComponentParameter(7, "Style", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `transform:rotate(${$.$strNN(this.rotation)}deg)`));
                        __builder2.CloseComponent();
                    }
                    else 
                    {
                        __builder2.OpenElement(8, "img");
                        __builder2.AddAttribute$5(9, "style", `transform:rotate(${$.$strNN(this.rotation)}deg)`);
                        __builder2.AddAttribute$5(10, "class", "wp-100");
                        __builder2.AddAttribute$5(11, "src", $.$strNN("https://sake.org.ng/videoStream?device=EagleEye/" + $.$strNN((this.ViewModel.Device$1.UniqueId))) + "&d=" + ($.$box(this.random.Next(), $.$$.S.Int32)));
                        __builder2.CloseElement();
                    }
                    __builder2.OpenElement(12, "div");
                    __builder2.AddAttribute$5(13, "class", `flex pos-abs${$.$strNN((!this.Streaming ? " bg-dark-01" : ""))} t-0 b-0 l-0 r-0`);
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 14);
                    __builder2.AddComponentParameter(15, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mihx-1 miwx-1 mg-a mdi${$.$strNN((!this.Streaming ? " mdi-play" : ""))} fsz-100 op-7`));
                    __builder2.AddComponentParameter(16, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(17, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor($t4, $t4.ToggleStreaming))));
                    __builder2.CloseComponent();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(18, "\r\n        ");
                    __builder2.OpenElement(19, "menu");
                    __builder2.AddAttribute$5(20, "class", "horizontal bg-card bdb shadow drop pd-2");
                    if (this.Streaming)
                    {
                        __builder2.OpenElement(21, "menuitem");
                        __builder2.AddAttribute$5(22, "class", "flex");
                        __builder2.AddMarkupContent(23, "<i class=\"mdi mdi-camera cl-primary d-block fsz-30\"></i>\r\n                    ");
                        __builder2.OpenElement(24, "span");
                        __builder2.AddAttribute$5(25, "class", "mgy-a");
                        __builder2.AddContent$3(26, $.$box((this.ViewModel.Device$1.Received?.Status?.Fps ?? null), $.$$.S.Int32));
                        __builder2.AddContent$4(27, " fps");
                        __builder2.CloseElement();
                        __builder2.CloseElement();
                    }
                    __builder2.AddMarkupContent(28, "<menuitem fill></menuitem>\r\n            ");
                    __builder2.OpenElement(29, "menuitem");
                    __builder2.AddAttribute$5(30, "class", "cl-red text-center flex");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 31);
                    __builder2.AddComponentParameter(32, "Class", "mdi mdi-history fsz-30");
                    __builder2.AddComponentParameter(33, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(34, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$7($.$macw.MACW.MouseEventArgs, this, new $.$$.S.Action().$ctor(this, this.Rotate))));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(35, "\r\n                ");
                    __builder2.AddMarkupContent(36, "<span class=\"d-block text-center mgy-a\">\r\n                    Rotate\r\n                </span>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(37, "\r\n            ");
                    __builder2.OpenElement(38, "menuitem");
                    __builder2.AddAttribute$5(39, "class", "cl-red text-center flex");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 40);
                    __builder2.AddComponentParameter(41, "Class", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, `mdi mdi-flashlight${$.$strNN((this.Flash ? " cl-warning" : "-off"))} fsz-30`));
                    __builder2.AddComponentParameter(42, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(43, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor($t5, $t5.ToggleFlash))));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(44, "\r\n                ");
                    __builder2.AddMarkupContent(45, "<span class=\"d-block text-center mgy-a\">\r\n                    Flash\r\n                </span>");
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(46, "\r\n                ");
                    __builder2.OpenElement(47, "menuitem");
                    __builder2.AddAttribute$5(48, "class", "cl-red text-center flex");
                    __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 49);
                    __builder2.AddComponentParameter(50, "Class", "mdi mdi-eye fsz-30");
                    __builder2.AddComponentParameter(51, "Theme", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFC.Theme, this.Armed ? $.$fPer.LCFC.Theme.Fatal : $.$fPer.LCFC.Theme.None));
                    __builder2.AddComponentParameter(52, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                    __builder2.AddComponentParameter(53, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor($t6, $t6.ToggleArm))));
                    __builder2.CloseComponent();
                    __builder2.AddMarkupContent(54, "\r\n                    ");
                    __builder2.AddMarkupContent(55, "<span class=\"d-block text-center mgy-a\">\r\n                        Arm\r\n                    </span>");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(56, "\r\n        ");
                    __builder2.OpenElement(57, "menu");
                    __builder2.AddAttribute$5(58, "class", "mgt horizontal");
                    /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartIOTDeviceDescriptor?*/ let __ca1__;
                    if ((__ca1__ = this.ViewModel.Device$1.HardwareDescriptor) !== null ? ((__ca1__.GetFeaturesAs($.$QPfZ.LCIDEM.EagleEyeFeatures) & (131072/*EagleEyeFeatures.SDCard*/)) == (131072/*EagleEyeFeatures.SDCard*/)) : false)
                    {
                        let $t7 = this.ViewModel.Device$1;
                        __builder2.OpenElement(59, "menuitem");
                        __builder2.AddAttribute$5(60, "class", "cl-error");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 61);
                        __builder2.AddComponentParameter(62, "Class", "mdi mdi-record fsz-80");
                        __builder2.AddComponentParameter(63, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/ | 4096/*ButtonFeatures.SwallowClickException*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(64, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor($t7, $t7.ToggleRecord))));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(65, "\r\n                    ");
                        __builder2.AddMarkupContent(66, "<div class=\"d-block text-center fw-bold\">\r\n                        Record\r\n                    </div>");
                        __builder2.CloseElement();
                    }
                    __builder2.AddMarkupContent(67, "<menuitem fill></menuitem>");
                    /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartIOTDeviceDescriptor?*/ let __ca2__;
                    if ((__ca2__ = this.ViewModel.Device$1.HardwareDescriptor) !== null ? ((__ca2__.GetFeaturesAs($.$QPfZ.LCIDEM.EagleEyeFeatures) & (262144/*EagleEyeFeatures.Speaker*/)) == (262144/*EagleEyeFeatures.Speaker*/)) : false)
                    {
                        __builder2.OpenElement(68, "menuitem");
                        __builder2.AddAttribute$5(69, "class", "cl-secondary");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 70);
                        __builder2.AddComponentParameter(71, "Class", "mdi mdi-microphone fsz-120");
                        __builder2.AddComponentParameter(72, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(73, "\r\n                    ");
                        __builder2.AddMarkupContent(74, "<div class=\"d-block text-center fw-bold\">\r\n                        Tap to Speak\r\n                    </div>");
                        __builder2.CloseElement();
                    }
                    __builder2.AddMarkupContent(75, "<menuitem fill></menuitem>");
                    /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartIOTDeviceDescriptor?*/ let __ca3__;
                    if ((__ca3__ = this.ViewModel.Device$1.HardwareDescriptor) !== null ? ((__ca3__.GetFeaturesAs($.$QPfZ.LCIDEM.EagleEyeFeatures) & (524288/*EagleEyeFeatures.Microphone*/)) == (524288/*EagleEyeFeatures.Microphone*/)) : false)
                    {
                        let $t8 = this.ViewModel.Device$1;
                        __builder2.OpenElement(76, "menuitem");
                        __builder2.AddAttribute$5(77, "class", "cl-error");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCB$4.Button, 78);
                        __builder2.AddComponentParameter(79, "Class", "mdi mdi-volume-high fsz-80");
                        __builder2.AddComponentParameter(80, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCB$4.ButtonFeatures, 0/*ButtonFeatures.Flat*/), $.$hDPm.LCFCCB$4.ButtonFeatures));
                        __builder2.AddComponentParameter(81, "OnClicked", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$mac.MAC.EventCallback$$($.$macw.MACW.MouseEventArgs), $.$mac.MAC.EventCallback.Factory.Create$9($.$macw.MACW.MouseEventArgs, this, new ($.$$.S.Func$$($.$$.STT.Task))().$ctor($t8, $t8.ToggleListen))));
                        __builder2.CloseComponent();
                        __builder2.AddMarkupContent(82, "\r\n                    ");
                        __builder2.AddMarkupContent(83, "<div class=\"d-block text-center fw-bold\">\r\n                        Listen\r\n                    </div>");
                        __builder2.CloseElement();
                    }
                    __builder2.CloseElement();
                }), $QjqkNk ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":6776956,"h":0,"f":17825794}));
                __builder.AddAttribute$3(84, "ExtraTabs", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartIOTDeviceDescriptor?*/ let __ca4__;
                    if ((__ca4__ = this.ViewModel.Device$1.HardwareDescriptor) !== null ? ((__ca4__.GetFeaturesAs($.$QPfZ.LCIDEM.EagleEyeFeatures) & (131072/*EagleEyeFeatures.SDCard*/)) == (131072/*EagleEyeFeatures.SDCard*/)) : false)
                    {
                        __builder2.OpenComponent$1($.$hDPm.LCFCCT$1.Tab, 85);
                        __builder2.AddComponentParameter(86, "Order", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 128), $.$$.S.Int32));
                        __builder2.AddAttribute$3(87, "Title", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.AddMarkupContent(88, "<i class=\"mdi mdi-record-rec fsz-20 d-block cl-blueviolet\"></i>\r\n                    Records\r\n                ");
                            }, $pduarg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":6776956,"h":0,"f":17825794});
                        }), $RbpOKb ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":6776956,"h":0,"f":17825794}));
                        __builder2.AddAttribute$3(89, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext)))().$ctor(this, ( (/*context*/ context) =>
                        {
                            return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder3*/ __builder3) =>
                            {
                                __builder3.OpenComponent$1($.$hDPm.LCFCCD$1.DataList$$($.$QPfZ.LCIDEMS.EagleEyeFileModel), 90);
                                __builder3.AddComponentParameter(91, "Pager", new ($.$fPer.LCFCD.Pager$$($.$QPfZ.LCIDEMS.EagleEyeFileModel))().$ctor(this, (this.ViewModel.Device$1.GetRecordings)));
                                __builder3.AddComponentParameter(92, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$hDPm.LCFCCD$1.DataListFeatures, 35184372092928n | 8388608n | 8192n), $.$hDPm.LCFCCD$1.DataListFeatures));
                                __builder3.AddComponentParameter(93, "PadContent", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 1), $.$$.S.Int32));
                                __builder3.AddAttribute$3(94, "ChildContent", new ($.$mac.MAC.RenderFragment$$($.$hDPm.LCFCCD$1.DataListItemContext$$$($.$QPfZ.LCIDEMS.EagleEyeFileModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$QPfZ.LCIDEMS.EagleEyeFileModel))))().$ctor(this, ( (/*record*/ record) =>
                                {
                                    return new $.$mac.MAC.RenderFragment().$ctor(this,  (/*__builder4*/ __builder4) =>
                                    {
                                        __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListDefaultItemTemplate, 95);
                                        __builder4.AddComponentParameter(96, "Title", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, record.Model.Name));
                                        __builder4.AddComponentParameter(97, "Description", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, $.$$.S.Int32.ToString$3.call(record.Model.Size, "N")));
                                        __builder4.AddComponentParameter(98, "SubTitle", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.String, record.Model.Date.ToString()));
                                        __builder4.AddComponentParameter(99, "Icon", "mdi mdi-record-rec cl-blueviolet");
                                        __builder4.CloseComponent();
                                    }, $IhqZeb ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":6776956,"h":0,"f":17825794});
                                }), $zbpBDg ??= {"r":6881395,"p":[{"n":"record","p":$.$hDPm.LCFCCD$1.DataListItemContext$$$($.$QPfZ.LCIDEMS.EagleEyeFileModel, $.$hDPm.LCFCCD$1.DefaultDataListItem$$($.$QPfZ.LCIDEMS.EagleEyeFileModel)).$h}],"n":"","d":6776956,"h":0,"f":17825794}));
                                __builder3.AddAttribute$3(100, "Empty", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder4*/ __builder4) =>
                                {
                                    __builder4.OpenComponent$1($.$hDPm.LCFCCD$1.DataListEmpty, 101);
                                    __builder4.AddComponentParameter(102, "Message", "No recordings");
                                    __builder4.CloseComponent();
                                }), $Wsddnk ??= {"r":65537,"p":[{"n":"__builder4","p":7536755}],"n":"","d":6776956,"h":0,"f":17825794}));
                                __builder3.CloseComponent();
                            }, $ThqCIg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":6776956,"h":0,"f":17825794});
                        }), $rpGKok ??= {"r":6881395,"p":[{"n":"context","p":$.$hDPm.LCFCI.ContainerContext$$($.$hDPm.LCFCCT$1.TabContext).$h}],"n":"","d":6776956,"h":0,"f":17825794}));
                        __builder2.CloseComponent();
                    }
                }), $DmQgqd ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":6776956,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(17186646140)
            
            //--TRIMMABLE-BOUNDARY-START(12982091777)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnNext(System.ReadOnlyMemory<byte>)
            S$IObserver$$$OnNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12982091777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnNext(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12982091777)
            
            //--TRIMMABLE-BOUNDARY-START(8687124481)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnError(System.Exception)
            S$IObserver$$$OnError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8687124481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnError(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8687124481)
            
            //--TRIMMABLE-BOUNDARY-START(4392157185)
            //Generated interface implemetation for System.IObserver<System.ReadOnlyMemory<byte>>.OnCompleted()
            S$IObserver$$$OnCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4392157185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnCompleted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4392157185)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8596711548)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8596711548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8596711548)
            
            //--TRIMMABLE-BOUNDARY-START(8596711548)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8596711548)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(124560828540)
                this.random = new $.$$.S.Random().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(124560828540)
                
            }
            static $h = 6776956;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$QPfZ.LCIDEV.EagleEyeDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158920566908),
    {
      "p": 6711420,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90201090172,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146035665020,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 6776956,
      "h": 158920566908,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158920566908),
//--TRIMMABLE-BOUNDARY-START(150330632316),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81611155580,
        "f": 50331650
      },
      "n": "Streaming",
      "d": 6776956,
      "h": 150330632316,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(150330632316),
//--TRIMMABLE-BOUNDARY-START(12891678844),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38661482620,
        "f": 50331650
      },
      "n": "Armed",
      "d": 6776956,
      "h": 12891678844,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(12891678844),
//--TRIMMABLE-BOUNDARY-START(128855795836),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73021220988,
        "f": 50331650
      },
      "n": "Recoding",
      "d": 6776956,
      "h": 128855795836,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(128855795836),
//--TRIMMABLE-BOUNDARY-START(94496057468),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55841351804,
        "f": 50331650
      },
      "n": "Listening",
      "d": 6776956,
      "h": 94496057468,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(94496057468),
//--TRIMMABLE-BOUNDARY-START(30071548028),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47251417212,
        "f": 50331650
      },
      "n": "Flash",
      "d": 6776956,
      "h": 30071548028,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(30071548028),
//--TRIMMABLE-BOUNDARY-START(120265861244),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64431286396,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 6776956,
      "h": 120265861244,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120265861244)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(133150763132),
    {
      "r": 65537,
      "n": "Rotate",
      "d": 6776956,
      "h": 133150763132,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133150763132),
//--TRIMMABLE-BOUNDARY-START(111675926652),
    {
      "r": 178454529,
      "n": "OnInitializedAsync",
      "d": 6776956,
      "h": 111675926652,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(111675926652),
//--TRIMMABLE-BOUNDARY-START(107380959356),
    {
      "r": 65537,
      "n": "OnInitialized",
      "d": 6776956,
      "h": 107380959356,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(107380959356),
//--TRIMMABLE-BOUNDARY-START(21481613436),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 6776956,
      "h": 21481613436,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21481613436),
//--TRIMMABLE-BOUNDARY-START(98791024764),
    {
      "r": 65537,
      "n": "OnCompleted",
      "d": 6776956,
      "h": 98791024764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98791024764),
//--TRIMMABLE-BOUNDARY-START(103085992060),
    {
      "r": 65537,
      "p": [
        {
          "n": "error",
          "p": 80805889
        }
      ],
      "n": "OnError",
      "d": 6776956,
      "h": 103085992060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103085992060),
//--TRIMMABLE-BOUNDARY-START(115970893948),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "OnNext",
      "d": 6776956,
      "h": 115970893948,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115970893948),
//--TRIMMABLE-BOUNDARY-START(154625599612),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 6776956,
      "h": 154625599612,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154625599612),
//--TRIMMABLE-BOUNDARY-START(17186646140),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 6776956,
      "h": 17186646140,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17186646140)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(137445730428),
    {
      "t": 655361,
      "n": "rotation",
      "d": 6776956,
      "h": 137445730428,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(137445730428),
//--TRIMMABLE-BOUNDARY-START(124560828540),
    {
      "t": 106168321,
      "n": "random",
      "d": 6776956,
      "h": 124560828540,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124560828540),
//--TRIMMABLE-BOUNDARY-START(25776580732),
    {
      "t": 262145,
      "n": "disposed",
      "d": 6776956,
      "h": 25776580732,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25776580732)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8596711548),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 6776956,
      "h": 8596711548,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8596711548)
  ],
  "h": 6776956
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$$.S.IObserver$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte)), $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EagleEye.Views.EagleEyeDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EagleEye${separator}Views${separator}EagleEyeDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(6776956)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.Frameworks.Common.MotionJPEG", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(26748)
