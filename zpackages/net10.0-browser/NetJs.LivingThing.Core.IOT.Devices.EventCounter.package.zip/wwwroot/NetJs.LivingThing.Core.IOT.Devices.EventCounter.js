
//--TRIMMABLE-BOUNDARY-START(41655)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $AXYryd;
    let $UXrQla;
    let $KurEzi;
    let $jXTiVg;
    let $uSJvJj;
    let $DZtynh;
    let $nPbmal;
    let $MvZAcd;
    let $JQxENj;
    let $LXooMe;
    let $ooSFfi;
    let $tPPSic;
    let $XBHdeh;
    let $tpnGpg;
    let $KpGRNj;
    let $UsGfMe;
    let $QUMxlk;
    let $WfOaDg;
    let $iiGgae;
    let $GKYuUg;
    let $sPhjSc;
    let $LBIuvc;
    let $sLpJei;
    let $UWqyMg;
    let $KKqKya;
    let $svceri;
    let $mkHaBi;
    let $KsvrVj;
    let $yJzspa;
    let $iBnApf;
    let $SQDWua;
    let $BwLfke;
    let $rVHMhf;
    let $pIBrkd;
    let $FJhCDj;
    let $rkXAza;
    let $mlKIsa;
    let $uflLYd;
    let $wOIJhj;
    let $WAqOyk;
    let $IPuIDk;
    let $NUCVdi;
    let $YlZWNj;
    let $Apogia;
    let $rSowvc;
    let $VrkOke;
    let $aEBQdi;
    let $pvDiti;
    let $hzhYzd;
    let $MEKHol;
    let $QlGyff;
    let $auoGPi;
    let $dsRfEe;
    let $nssdUi;
    let $mMhpxb;
    let $jCcQLh;
    let $gjBUbg;
    let $ZLWdPb;
    let $psiaBb;
    let $hxgWSh;
    let $VpldFg;
    let $kuJUDk;
    let $xbIEqb;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.EventCounter", 
    {
  "h": 41655,
  "f": "LivingThing.Core.IOT.Devices.EventCounter",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.EventCounter",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.EventCounter",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5FdmVudENvdW50ZXIuU21hcnRFdmVudENvdW50ZXJEZXZpY2UiOiB7DQogICAgICAiQ2F0ZWdvcmllcyI6IFsgIkF1dG9tYXRpb24iIF0sDQogICAgICAiTmFtZSI6ICJTbWFydCBFdmVudCBDb3VudGVyIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICJJbnRlZ3JhdGUgd2l0aCBpbmR1c3RyaWFsIGFuZCBidXNpbmVzcyBwcm9jZXNzZXMsIHB1dCB0aGVtIG9ubGluZSIsDQogICAgICAiQmFubmVySW1hZ2UiOiAifi9pbWcvYmFubmVyMS5qcGciLA0KICAgICAgIlVuaXRDb3N0Ijogew0KICAgICAgICAiVmFsdWUiOiAxNTAwMCwNCiAgICAgICAgIlVuaXQiOiAiTmFpcmEiDQogICAgICB9LA0KICAgICAgIkltYWdlcyI6IFsNCiAgICAgIF0sDQogICAgICAiSWNvbiI6IHsgIk5hbWUiOiAibWRpIG1kaS1jb3VudGVyIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q4N2I5YSIsDQogICAgICAiRmxhZ3MiOiAiRmVhdHVyZWQsUHVibGlzaGVkIiwNCiAgICAgICJTZWN1cml0aWVzIjogIkNoYWxsZW5nZUhhbmRTaGFrZUF1dGhlbnRpY2F0aW9uUHJvdG9jb2wsQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyIsDQogICAgICAiRmVhdHVyZXMiOiBbDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiUHVsc2UgQ291bnRpbmciLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJDb3VudHMgbnVtYmVyIG9mIHB1bHNlcyBnZW5lcmF0ZWQgYnkgYW4gaW5kdXN0cmlhbCBlcXVpcG1lbnQuIiwNCiAgICAgICAgICAiSWNvbiI6IHsgIkljb24iOiAiQ291bnRlciIgfQ0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIkh5dGVyZXNpcyBjb250cm9sIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiSGFuZGxlcyBhbmQgZmlsdGVycyBub2lzeSBzaWduYWwuIiwNCiAgICAgICAgICAiSWNvbiI6IHsgIkljb24iOiAiRmlsdGVyIiB9DQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiRGVib3VuY2UiLA0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJSZW1vdmUgcnVudCBwdWxzZXMuIiwNCiAgICAgICAgICAiSWNvbiI6IHsgIkljb24iOiAiRmlsdGVyIiB9DQogICAgICAgIH0NCiAgICAgIF0sDQogICAgICAiQmVuZWZpdHMiOiBbDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiUmVhbC10aW1lIEFjY2VzcyIsDQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIlN0YXkgY29ubmVjdGVkIHRvIHlvdXIgaW5kdXN0cmlhbCBhbmQgYnVzaW5lc3MgZXF1aW1lbnQiLA0KICAgICAgICAgICJJY29uIjogeyAiSWNvbiI6ICJDaGFydCIgfQ0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIlRpdGxlIjogIlNjaGVkdWxlIiwNCiAgICAgICAgICAiRGVzY3JpcHRpb24iOiAiS25vdyBob3cgbXVjaCB3b3JrIHlvdXIgZXF1aXBtZW50IGhhcyBkb25lIGRhaWx5IiwNCiAgICAgICAgICAiSWNvbiI6IHsgIkljb24iOiAiV29yayIgfQ0KICAgICAgICB9DQogICAgICBdLA0KICAgICAgIlVzZUNhc2VzIjogWw0KICAgICAgICB7DQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIkZpbGxpbmcgc3RhdGlvbiBwZXRyb2wgcHVtcCINCiAgICAgICAgfSwNCiAgICAgICAgew0KICAgICAgICAgICJEZXNjcmlwdGlvbiI6ICJJbmR1c3RyaWFsIHByaW50aW5nIG1hY2hpbmVzIg0KICAgICAgICB9LA0KICAgICAgICB7DQogICAgICAgICAgIkRlc2NyaXB0aW9uIjogIkNhcndhc2ggdHJhY2tpbmcgYW5kIG1vbml0b3JpbmciDQogICAgICAgIH0NCiAgICAgIF0sDQogICAgICAiU3BlY2lmaWNhdGlvbnMiOiBbDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiU3VwcGx5IFZvbHRhZ2UiLA0KICAgICAgICAgICJWYWx1ZSI6ICIxMlYiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiU3VwcGx5IEN1cnJlbnQiLA0KICAgICAgICAgICJWYWx1ZSI6ICJ\u002BMTAwbUEiDQogICAgICAgIH0sDQogICAgICAgIHsNCiAgICAgICAgICAiVGl0bGUiOiAiQ29ubmVjdGl2aXR5IiwNCiAgICAgICAgICAiVmFsdWUiOiAiV2lGaSwgSW50ZXJuZXQiDQogICAgICAgIH0NCiAgICAgIF0NCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2400951)
        $asm.$cls(`$WYlj.LCIDES$1.SmartEventCounterActionsCustomAttributesProvider`, ($self) => class SmartEventCounterActionsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297368247)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297368247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297368247)
            
            static $h = 2400951;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297368247),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2400951,
      "h": 4297368247,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297368247)
  ],
  "h": 2400951
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterActionsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterActionsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2400951)
        
        

        //--TRIMMABLE-BOUNDARY-START(369335)
        $asm.$cls(`$WYlj.LCIDE.FastEnumStartupExtension`, ($self) => class FastEnumStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295336631)
            static /*void */ AddGeneratedFastEnums(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295336631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(4295336631)
            
            static $h = 369335;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295336631),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastEnums",
      "d": 369335,
      "h": 4295336631,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295336631)
  ],
  "h": 369335
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.FastEnumStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}FastEnumStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(369335)
        
        

        //--TRIMMABLE-BOUNDARY-START(762551)
        $asm.$cls(`$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class SmartEventCounterDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295729847)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295729847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$$($.$WYlj.LCIDEMS.SmartEventCounterStatusModel, $.$WYlj.LCIDEMS.SmartEventCounterLogModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295729847)
            
            static $h = 762551;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295729847),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 762551,
      "h": 4295729847,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295729847)
  ],
  "h": 762551
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}SmartEventCounterDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(762551)
        
        

        //--TRIMMABLE-BOUNDARY-START(172727)
        $asm.$cls(`$WYlj.LCIDE._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295140023)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295140023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$WYlj.LCIDE.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295140023)
            
            static $h = 172727;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295140023),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 172727,
      "h": 4295140023,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295140023)
  ],
  "h": 172727
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(172727)
        
        

        //--TRIMMABLE-BOUNDARY-START(3449527)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceModelCustomAttributesProvider`, ($self) => class SmartEventCounterDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298416823)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298416823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298416823)
            
            static $h = 3449527;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298416823),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3449527,
      "h": 4298416823,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298416823)
  ],
  "h": 3449527
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3449527)
        
        

        //--TRIMMABLE-BOUNDARY-START(4104887)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterServiceModelCustomAttributesProvider`, ($self) => class SmartEventCounterServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4299072183)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299072183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4299072183)
            
            static $h = 4104887;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299072183),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 4104887,
      "h": 4299072183,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4299072183)
  ],
  "h": 4104887
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4104887)
        
        

        //--TRIMMABLE-BOUNDARY-START(2532023)
        $asm.$cls(`$WYlj.LCIDES$1.SmartEventCounterBroadcastPeerMessagesCustomAttributesProvider`, ($self) => class SmartEventCounterBroadcastPeerMessagesCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297499319)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297499319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4297499319)
            
            static $h = 2532023;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297499319),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2532023,
      "h": 4297499319,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297499319)
  ],
  "h": 2532023
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterBroadcastPeerMessagesCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterBroadcastPeerMessagesCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2532023)
        
        

        //--TRIMMABLE-BOUNDARY-START(4301495)
        $asm.$cls(`$WYlj.LCIDE.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4299268791)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299268791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelTypeDescriptorBuilder.Register();
                $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptorBuilder.Register();
                $.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptorBuilder.Register();
                $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettingsTypeDescriptorBuilder.Register();
                $.$WYlj.LCIDE.SmartEventCounterDeviceModelTypeDescriptorBuilder.Register();
                $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$WYlj.LCIDE.SmartEventCounterServiceModelTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4299268791)
            
            static $h = 4301495;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4299268791),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 4301495,
      "h": 4299268791,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4299268791)
  ],
  "h": 4301495
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4301495)
        
        

        //--TRIMMABLE-BOUNDARY-START(303799)
        $asm.$cls(`$WYlj.LCIDE.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295271095)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295271095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelCustomAttributesProvider, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModelCustomAttributesProvider, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelCustomAttributesProvider, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDEMS.SmartEventCounterLogType.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDEMS.SmartEventCounterLogTypeCustomAttributesProvider, $.$WYlj.LCIDEMS.SmartEventCounterLogTypeCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDEMS.SmartEventCounterLogModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDEMS.SmartEventCounterLogModelCustomAttributesProvider, $.$WYlj.LCIDEMS.SmartEventCounterLogModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDEMS.SmartEventCounterStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelCustomAttributesProvider, $.$WYlj.LCIDEMS.SmartEventCounterStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDES$1.SmartEventCounterBroadcastPeerMessages.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDES$1.SmartEventCounterBroadcastPeerMessagesCustomAttributesProvider, $.$WYlj.LCIDES$1.SmartEventCounterBroadcastPeerMessagesCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDES$1.SmartEventCounterActions.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDES$1.SmartEventCounterActionsCustomAttributesProvider, $.$WYlj.LCIDES$1.SmartEventCounterActionsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsCustomAttributesProvider, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDES$1.SmartEventCounterDeviceSettingsCustomAttributesProvider, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDE.SmartEventCounterDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDE.SmartEventCounterDeviceModelCustomAttributesProvider, $.$WYlj.LCIDE.SmartEventCounterDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDE.SmartEventCounterDeviceScopeModelCustomAttributesProvider, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$WYlj.LCIDE.SmartEventCounterServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$WYlj.LCIDE.SmartEventCounterServiceModelCustomAttributesProvider, $.$WYlj.LCIDE.SmartEventCounterServiceModelCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295271095)
            
            static $h = 303799;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295271095),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 303799,
      "h": 4295271095,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295271095)
  ],
  "h": 303799
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(303799)
        
        

        //--TRIMMABLE-BOUNDARY-START(1548983)
        $asm.$cls(`$WYlj.LCIDEMS.SmartEventCounterLogTypeCustomAttributesProvider`, ($self) => class SmartEventCounterLogTypeCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296516279)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296516279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(4296516279)
            
            static $h = 1548983;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296516279),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1548983,
      "h": 4296516279,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296516279)
  ],
  "h": 1548983
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogTypeCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Statuses${separator}SmartEventCounterLogTypeCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1548983)
        
        

        //--TRIMMABLE-BOUNDARY-START(3777207)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceScopeModelCustomAttributesProvider`, ($self) => class SmartEventCounterDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4298744503)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298744503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4298744503)
            
            static $h = 3777207;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298744503),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 3777207,
      "h": 4298744503,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298744503)
  ],
  "h": 3777207
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3777207)
        
        

        //--TRIMMABLE-BOUNDARY-START(2925239)
        $asm.$cls(`$WYlj.LCIDES$1.SmartEventCounterDeviceSettingsCustomAttributesProvider`, ($self) => class SmartEventCounterDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297892535)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297892535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297892535)
            
            static $h = 2925239;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297892535),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2925239,
      "h": 4297892535,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297892535)
  ],
  "h": 2925239
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2925239)
        
        

        //--TRIMMABLE-BOUNDARY-START(3056311)
        $asm.$cls(`$WYlj.LCIDES$1.SmartEventCounterDeviceSettingsTypeDescriptorBuilder`, ($self) => class SmartEventCounterDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592990903)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592990903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettingsTypeDescriptor()
                        const $t1 = $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $LXooMe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3056311,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592990903)
            
            //--TRIMMABLE-BOUNDARY-START(4298023607)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298023607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298023607)
            
            //--TRIMMABLE-BOUNDARY-START(4298023607)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298023607)
            
            static $h = 3056311;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592990903),
    {
      "r": 65537,
      "n": "Register",
      "d": 3056311,
      "h": 8592990903,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592990903)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298023607),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3056311,
      "h": 4298023607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298023607)
  ],
  "h": 3056311
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3056311)
        
        

        //--TRIMMABLE-BOUNDARY-START(1680055)
        $asm.$cls(`$WYlj.LCIDEMS.SmartEventCounterStatusModelCustomAttributesProvider`, ($self) => class SmartEventCounterStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296647351)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296647351)
            
            //--TRIMMABLE-BOUNDARY-START(8591614647)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591614647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$WYlj.LCIDEMS.SmartEventCounterStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(6, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Count", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            $i3.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["Icon=Counter"], [-1], null);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("UniqueSales", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("SystemTime", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            $i5.ConvertType = ($.$$.S.UInt32.$type);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("LastSaleAgo", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (4);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("MsPerLiter", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (5);
                            $i7.ConvertType = ($.$$.S.UInt16.$type);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Removed", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t8 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i8 = new $t8();
                            $i8.$ctor$4();
                            $i8.Order = (6);
                            return $i8;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$WYlj.LCIDEMS.SmartEventCounterStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $DZtynh ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1680055,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $nPbmal ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1680055,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591614647)
            
            static $h = 1680055;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591614647),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1680055,
      "h": 8591614647,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591614647)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296647351),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1680055,
      "h": 4296647351,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296647351)
  ],
  "h": 1680055
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Statuses${separator}SmartEventCounterStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1680055)
        
        

        //--TRIMMABLE-BOUNDARY-START(500407)
        $asm.$cls(`$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelCustomAttributesProvider`, ($self) => class SmartEventCounterResetQuotaControlModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295467703)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295467703)
            
            //--TRIMMABLE-BOUNDARY-START(8590434999)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590434999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Value", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (129);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $UXrQla ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":500407,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $KurEzi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":500407,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590434999)
            
            static $h = 500407;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590434999),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 500407,
      "h": 8590434999,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590434999)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295467703),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 500407,
      "h": 4295467703,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295467703)
  ],
  "h": 500407
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Controls.SmartEventCounterResetQuotaControlModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Controls${separator}SmartEventCounterResetQuotaControlModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(500407)
        
        

        //--TRIMMABLE-BOUNDARY-START(2794167)
        $asm.$cls(`$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class SmartEventCounterDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592728759)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592728759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $yJzspa ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2794167,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592728759)
            
            //--TRIMMABLE-BOUNDARY-START(4297761463)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297761463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297761463)
            
            //--TRIMMABLE-BOUNDARY-START(4297761463)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297761463)
            
            static $h = 2794167;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592728759),
    {
      "r": 65537,
      "n": "Register",
      "d": 2794167,
      "h": 8592728759,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592728759)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297761463),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2794167,
      "h": 4297761463,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297761463)
  ],
  "h": 2794167
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2794167)
        
        

        //--TRIMMABLE-BOUNDARY-START(1024695)
        $asm.$cls(`$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelCustomAttributesProvider`, ($self) => class SmartEventCounterDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295991991)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295991991)
            
            //--TRIMMABLE-BOUNDARY-START(8590959287)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590959287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Reset", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (26418);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $MvZAcd ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1024695,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $JQxENj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1024695,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8590959287)
            
            static $h = 1024695;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590959287),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1024695,
      "h": 8590959287,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590959287)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295991991),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1024695,
      "h": 4295991991,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295991991)
  ],
  "h": 1024695
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}SmartEventCounterDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1024695)
        
        

        //--TRIMMABLE-BOUNDARY-START(1417911)
        $asm.$cls(`$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptorBuilder`, ($self) => class SmartEventCounterLogModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591352503)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591352503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor()
                        const $t1 = $.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $FJhCDj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1417911,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WYlj.LCIDEMS.SmartEventCounterLogModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591352503)
            
            //--TRIMMABLE-BOUNDARY-START(4296385207)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296385207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296385207)
            
            //--TRIMMABLE-BOUNDARY-START(4296385207)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296385207)
            
            static $h = 1417911;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591352503),
    {
      "r": 65537,
      "n": "Register",
      "d": 1417911,
      "h": 8591352503,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591352503)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296385207),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1417911,
      "h": 4296385207,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296385207)
  ],
  "h": 1417911
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Statuses${separator}SmartEventCounterLogModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1417911)
        
        

        //--TRIMMABLE-BOUNDARY-START(1155767)
        $asm.$cls(`$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class SmartEventCounterDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591090359)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591090359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $sLpJei ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1155767,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591090359)
            
            //--TRIMMABLE-BOUNDARY-START(4296123063)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296123063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296123063)
            
            //--TRIMMABLE-BOUNDARY-START(4296123063)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296123063)
            
            static $h = 1155767;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591090359),
    {
      "r": 65537,
      "n": "Register",
      "d": 1155767,
      "h": 8591090359,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591090359)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296123063),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1155767,
      "h": 4296123063,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296123063)
  ],
  "h": 1155767
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}SmartEventCounterDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1155767)
        
        

        //--TRIMMABLE-BOUNDARY-START(1286839)
        $asm.$cls(`$WYlj.LCIDEMS.SmartEventCounterLogModelCustomAttributesProvider`, ($self) => class SmartEventCounterLogModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296254135)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296254135)
            
            //--TRIMMABLE-BOUNDARY-START(8591221431)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591221431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$WYlj.LCIDEMS.SmartEventCounterLogModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(3, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Type", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (12);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Delta", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (13);
                            $i4.ConvertType = ($.$$.S.UInt16.$type);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Count", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (14);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$WYlj.LCIDEMS.SmartEventCounterLogModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $KpGRNj ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1286839,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $UsGfMe ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":1286839,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceLogModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8591221431)
            
            static $h = 1286839;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591221431),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1286839,
      "h": 8591221431,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591221431)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296254135),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 1286839,
      "h": 4296254135,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296254135)
  ],
  "h": 1286839
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Statuses${separator}SmartEventCounterLogModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1286839)
        
        

        //--TRIMMABLE-BOUNDARY-START(893623)
        $asm.$cls(`$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class SmartEventCounterDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590828215)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590828215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $QUMxlk ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":893623,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590828215)
            
            //--TRIMMABLE-BOUNDARY-START(4295860919)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295860919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295860919)
            
            //--TRIMMABLE-BOUNDARY-START(4295860919)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295860919)
            
            static $h = 893623;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590828215),
    {
      "r": 65537,
      "n": "Register",
      "d": 893623,
      "h": 8590828215,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590828215)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295860919),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 893623,
      "h": 4295860919,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295860919)
  ],
  "h": 893623
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}SmartEventCounterDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(893623)
        
        

        //--TRIMMABLE-BOUNDARY-START(4235959)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterServiceModelTypeDescriptorBuilder`, ($self) => class SmartEventCounterServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8594170551)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594170551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WYlj.LCIDE.SmartEventCounterServiceModelTypeDescriptor()
                        const $t1 = $.$WYlj.LCIDE.SmartEventCounterServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $iiGgae ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":4235959,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WYlj.LCIDE.SmartEventCounterServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8594170551)
            
            //--TRIMMABLE-BOUNDARY-START(4299203255)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299203255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299203255)
            
            //--TRIMMABLE-BOUNDARY-START(4299203255)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4299203255)
            
            static $h = 4235959;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594170551),
    {
      "r": 65537,
      "n": "Register",
      "d": 4235959,
      "h": 8594170551,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8594170551)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299203255),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4235959,
      "h": 4299203255,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299203255)
  ],
  "h": 4235959
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4235959)
        
        

        //--TRIMMABLE-BOUNDARY-START(3646135)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceModelTypeDescriptorBuilder`, ($self) => class SmartEventCounterDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593580727)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593580727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WYlj.LCIDE.SmartEventCounterDeviceModelTypeDescriptor()
                        const $t1 = $.$WYlj.LCIDE.SmartEventCounterDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $sPhjSc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3646135,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WYlj.LCIDE.SmartEventCounterDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593580727)
            
            //--TRIMMABLE-BOUNDARY-START(4298613431)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298613431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298613431)
            
            //--TRIMMABLE-BOUNDARY-START(4298613431)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298613431)
            
            static $h = 3646135;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593580727),
    {
      "r": 65537,
      "n": "Register",
      "d": 3646135,
      "h": 8593580727,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593580727)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298613431),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3646135,
      "h": 4298613431,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298613431)
  ],
  "h": 3646135
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3646135)
        
        

        //--TRIMMABLE-BOUNDARY-START(2663095)
        $asm.$cls(`$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class SmartEventCounterDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297630391)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297630391)
            
            //--TRIMMABLE-BOUNDARY-START(8592597687)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592597687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(2, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Debounce", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "pcd";
                            $i3.Order = (20);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Usage", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Key = "pcu";
                            $i4.Order = (21);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/*e*/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $mkHaBi ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2663095,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $KsvrVj ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2663095,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider$$($.$WYlj.LCIDES$1.SmartEventCounterActions).GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592597687)
            
            static $h = 2663095;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592597687),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2663095,
      "h": 8592597687,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592597687)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297630391),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2663095,
      "h": 4297630391,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297630391)
  ],
  "h": 2663095
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2663095)
        
        

        //--TRIMMABLE-BOUNDARY-START(1811127)
        $asm.$cls(`$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptorBuilder`, ($self) => class SmartEventCounterStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591745719)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591745719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor()
                        const $t1 = $.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $MEKHol ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1811127,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WYlj.LCIDEMS.SmartEventCounterStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591745719)
            
            //--TRIMMABLE-BOUNDARY-START(4296778423)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296778423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296778423)
            
            //--TRIMMABLE-BOUNDARY-START(4296778423)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296778423)
            
            static $h = 1811127;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591745719),
    {
      "r": 65537,
      "n": "Register",
      "d": 1811127,
      "h": 8591745719,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591745719)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296778423),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1811127,
      "h": 4296778423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296778423)
  ],
  "h": 1811127
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Statuses${separator}SmartEventCounterStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1811127)
        
        

        //--TRIMMABLE-BOUNDARY-START(3908279)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceScopeModelTypeDescriptorBuilder`, ($self) => class SmartEventCounterDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593842871)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593842871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $YlZWNj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3908279,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8593842871)
            
            //--TRIMMABLE-BOUNDARY-START(4298875575)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298875575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298875575)
            
            //--TRIMMABLE-BOUNDARY-START(4298875575)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298875575)
            
            static $h = 3908279;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593842871),
    {
      "r": 65537,
      "n": "Register",
      "d": 3908279,
      "h": 8593842871,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593842871)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298875575),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3908279,
      "h": 4298875575,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298875575)
  ],
  "h": 3908279
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3908279)
        
        

        //--TRIMMABLE-BOUNDARY-START(631479)
        $asm.$cls(`$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelTypeDescriptorBuilder`, ($self) => class SmartEventCounterResetQuotaControlModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590566071)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590566071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelTypeDescriptor()
                        const $t1 = $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.EventCounter.Models.Controls.SmartEventCounterResetQuotaControlModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $rSowvc ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":631479,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590566071)
            
            //--TRIMMABLE-BOUNDARY-START(4295598775)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295598775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295598775)
            
            //--TRIMMABLE-BOUNDARY-START(4295598775)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295598775)
            
            static $h = 631479;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590566071),
    {
      "r": 65537,
      "n": "Register",
      "d": 631479,
      "h": 8590566071,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590566071)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295598775),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 631479,
      "h": 4295598775,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295598775)
  ],
  "h": 631479
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Controls.SmartEventCounterResetQuotaControlModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Controls${separator}SmartEventCounterResetQuotaControlModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(631479)
        
        

        //--TRIMMABLE-BOUNDARY-START(238263)
        $asm.$cls(`$WYlj.LCIDE.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180107447)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180107447)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295205559)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295205559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295205559)
            
            //--TRIMMABLE-BOUNDARY-START(4295205559)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295205559)
            
            static $h = 238263;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180107447),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885140151,
        "f": 50331649
      },
      "n": "Paths",
      "d": 238263,
      "h": 17180107447,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180107447)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295205559),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 238263,
      "h": 4295205559,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295205559)
  ],
  "h": 238263
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(238263)
        
        

        //--TRIMMABLE-BOUNDARY-START(1876663)
        $asm.$cls(`$WYlj.LCIDE.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181745847)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$WYlj.LCIDEV.SmartEventCounterDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$WYlj.LCIDEV.SmartEventCounterDeviceDetails().$ctor$4();
                    }, $AXYryd ??= {"r":2752627,"n":"","d":1876663,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17181745847)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4296843959)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296843959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296843959)
            
            //--TRIMMABLE-BOUNDARY-START(4296843959)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296843959)
            
            static $h = 1876663;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181745847),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886778551,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 1876663,
      "h": 17181745847,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181745847)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296843959),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1876663,
      "h": 4296843959,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296843959)
  ],
  "h": 1876663
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1876663)
        
        

        //--TRIMMABLE-BOUNDARY-START(2073271)
        $asm.$cls(`$WYlj.LCIDE.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592007863)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592007863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$WYlj.LCIDE.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$WYlj.LCIDE.SmartEventCounterDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$WYlj.LCIDE.SmartEventCounterDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$WYlj.LCIDE.SmartEventCounterDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$WYlj.LCIDE.SmartEventCounterDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$WYlj.LCIDE.SmartEventCounterDeviceFamily, x);
                }, $tPPSic ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2073271,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/*x*/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$WYlj.LCIDE.SmartEventCounterDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$WYlj.LCIDE.SmartEventCounterDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $XBHdeh ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2073271,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$WYlj.LCIDE.SmartEventCounterDevice)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$WYlj.LCIDE.SmartEventCounterDeviceFamily, x);
                }, $tpnGpg ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$WYlj.LCIDE.SmartEventCounterDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2073271,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$WYlj.LCIDE.SmartEventCounterDevice), $.$WYlj.LCIDEPC.SmartEventCounterDeviceCommands$$($.$WYlj.LCIDE.SmartEventCounterDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel), $.$WYlj.LCIDE.SmartEventCounterHandler, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$WYlj.LCIDE.SmartEventCounterDevice), $.$WYlj.LCIDEV.SmartEventCounterViewRenderer, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592007863)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$WYlj.LCIDE.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297040567)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297040567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297040567)
            
            //--TRIMMABLE-BOUNDARY-START(4297040567)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297040567)
            
            static $h = 2073271;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592007863),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2073271,
      "h": 8592007863,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592007863)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297040567),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2073271,
      "h": 4297040567,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297040567)
  ],
  "h": 2073271
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2073271)
        
        

        //--TRIMMABLE-BOUNDARY-START(4629175)
        $asm.$cls(`$WYlj.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299596471)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299596471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299596471)
            
            //--TRIMMABLE-BOUNDARY-START(4299596471)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299596471)
            
            static $h = 4629175;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299596471),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4629175,
      "h": 4299596471,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299596471)
  ],
  "h": 4629175,
  "a": [
    {
      "t": 4563639,
      "c": 4299530935
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4629175)
        
        

        //--TRIMMABLE-BOUNDARY-START(4563639)
        $asm.$cls(`$WYlj.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4299530935)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299530935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299530935)
            
            //--TRIMMABLE-BOUNDARY-START(4299530935)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4299530935)
            
            static $h = 4563639;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299530935),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4563639,
      "h": 4299530935,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299530935)
  ],
  "h": 4563639
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4563639)
        
        

        //--TRIMMABLE-BOUNDARY-START(434871)
        $asm.$cls(`$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel`, ($self) => class SmartEventCounterResetQuotaControlModel extends $.$XBGm.LCICDi.iSmartDeviceCommandModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590369463)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590369463);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590369463)
            
            //--TRIMMABLE-BOUNDARY-START(12885336759)
            /*int */ get Command()
            {
                return ((128 + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(12885336759)
            
            //--TRIMMABLE-BOUNDARY-START(42950107831)
            /*int*/ Value = 0;
            //--TRIMMABLE-BOUNDARY-END(42950107831)
            
            //--TRIMMABLE-BOUNDARY-START(8590369463)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590369463)
            
            static $h = 434871;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885336759),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475271351,
        "f": 50364417
      },
      "n": "Command",
      "d": 434871,
      "h": 12885336759,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885336759),
//--TRIMMABLE-BOUNDARY-START(42950107831),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065205943,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38655140535,
        "f": 83886081
      },
      "n": "Value",
      "d": 434871,
      "h": 42950107831,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 129,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950107831)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590369463),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 434871,
      "h": 8590369463,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590369463)
  ],
  "h": 434871
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Controls.SmartEventCounterResetQuotaControlModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Controls${separator}SmartEventCounterResetQuotaControlModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(434871)
        
        

        //--TRIMMABLE-BOUNDARY-START(1221303)
        $asm.$cls(`$WYlj.LCIDEMS.SmartEventCounterLogModel`, ($self) => class SmartEventCounterLogModel extends $.$XBGm.LCICDi.iSmartDeviceLogModel
        {
            //--TRIMMABLE-BOUNDARY-START(81605599927)
            /*SmartEventCounterLogType*/ Type = 0;
            //--TRIMMABLE-BOUNDARY-END(81605599927)
            
            //--TRIMMABLE-BOUNDARY-START(25771025079)
            /*int*/ Delta = 0;
            //--TRIMMABLE-BOUNDARY-END(25771025079)
            
            //--TRIMMABLE-BOUNDARY-START(21476057783)
            /*long*/ Count = 0n;
            //--TRIMMABLE-BOUNDARY-END(21476057783)
            
            //--TRIMMABLE-BOUNDARY-START(17181090487)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181090487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181090487)
            
            //--TRIMMABLE-BOUNDARY-START(17181090487)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17181090487)
            
            static $h = 1221303;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceLogModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605599927),
    {
      "p": 1483447,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540828855,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310632631,
        "f": 83886081
      },
      "n": "Type",
      "d": 1221303,
      "h": 81605599927,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 12,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605599927),
//--TRIMMABLE-BOUNDARY-START(25771025079),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950894263,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720698039,
        "f": 83886081
      },
      "n": "Delta",
      "d": 1221303,
      "h": 25771025079,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 13,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771025079),
//--TRIMMABLE-BOUNDARY-START(21476057783),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360959671,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130763447,
        "f": 83886081
      },
      "n": "Count",
      "d": 1221303,
      "h": 21476057783,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 14,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476057783)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181090487),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1221303,
      "h": 17181090487,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181090487)
  ],
  "h": 1221303
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceLog, $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Statuses${separator}SmartEventCounterLogModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1221303)
        
        

        //--TRIMMABLE-BOUNDARY-START(1614519)
        $asm.$cls(`$WYlj.LCIDEMS.SmartEventCounterStatusModel`, ($self) => class SmartEventCounterStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(34361352887)
            /*long*/ Count = 0n;
            //--TRIMMABLE-BOUNDARY-END(34361352887)
            
            //--TRIMMABLE-BOUNDARY-START(167505339063)
            /*uint*/ UniqueSales = 0;
            //--TRIMMABLE-BOUNDARY-END(167505339063)
            
            //--TRIMMABLE-BOUNDARY-START(163210371767)
            /*DateTime*/ SystemTime;
            //--TRIMMABLE-BOUNDARY-END(163210371767)
            
            //--TRIMMABLE-BOUNDARY-START(94490895031)
            /*uint*/ LastSaleAgo = 0;
            //--TRIMMABLE-BOUNDARY-END(94490895031)
            
            //--TRIMMABLE-BOUNDARY-START(98785862327)
            /*int*/ MsPerLiter = 0;
            //--TRIMMABLE-BOUNDARY-END(98785862327)
            
            //--TRIMMABLE-BOUNDARY-START(103080829623)
            /*bool*/ Removed = false;
            //--TRIMMABLE-BOUNDARY-END(103080829623)
            
            //--TRIMMABLE-BOUNDARY-START(90195927735)
            /*IEnumerator<IObservableDataDescriptor> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195927735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ($.$fPer.LCFCD$1.DataDescriptorExtensions.BindTo($.$fPer.LCFCD.DataDescriptorFactory.From($.$$.S.Object.GetType.call(this), null, true), this, 16777215/*SchemaType.All*/, null, false, false)).SCG$IEnumerable$$$GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(90195927735)
            
            //--TRIMMABLE-BOUNDARY-START(158915404471)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915404471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ($.$fPer.LCFCD$1.DataDescriptorExtensions.BindTo($.$fPer.LCFCD.DataDescriptorFactory.From($.$$.S.Object.GetType.call(this), null, true), this, 16777215/*SchemaType.All*/, null, false, false)).SCG$IEnumerable$$$GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(158915404471)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<LivingThing.Core.Frameworks.Common.DataDescriptor.IObservableDataDescriptor>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            //--TRIMMABLE-BOUNDARY-START(30066385591)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066385591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066385591)
            
            //--TRIMMABLE-BOUNDARY-START(30066385591)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(30066385591)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(163210371767)
                this.SystemTime = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(163210371767)
                
            }
            static $h = 1614519;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361352887),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951287479,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670764215,
        "f": 83886081
      },
      "n": "Count",
      "d": 1614519,
      "h": 34361352887,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            },
            {
              "n": "Options",
              "v": [
                "Icon=Counter"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361352887),
//--TRIMMABLE-BOUNDARY-START(167505339063),
    {
      "p": 720897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900960439,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154620437175,
        "f": 83886081
      },
      "n": "UniqueSales",
      "d": 1614519,
      "h": 167505339063,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167505339063),
//--TRIMMABLE-BOUNDARY-START(163210371767),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311025847,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030502583,
        "f": 83886081
      },
      "n": "SystemTime",
      "d": 1614519,
      "h": 163210371767,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 720897,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163210371767),
//--TRIMMABLE-BOUNDARY-START(94490895031),
    {
      "p": 720897,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541222071,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260698807,
        "f": 83886081
      },
      "n": "LastSaleAgo",
      "d": 1614519,
      "h": 94490895031,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490895031),
//--TRIMMABLE-BOUNDARY-START(98785862327),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131156663,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850633399,
        "f": 83886081
      },
      "n": "MsPerLiter",
      "d": 1614519,
      "h": 98785862327,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 589825,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785862327),
//--TRIMMABLE-BOUNDARY-START(103080829623),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721091255,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440567991,
        "f": 83886081
      },
      "n": "Removed",
      "d": 1614519,
      "h": 103080829623,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 6,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103080829623)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90195927735),
    {
      "r": $.$$.SCG.IEnumerator$$($.$fPer.LCFCD$1.IObservableDataDescriptor).$h,
      "n": "GetEnumerator",
      "d": 1614519,
      "h": 90195927735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195927735)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066385591),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1614519,
      "h": 30066385591,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066385591)
  ],
  "h": 1614519
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder, $.$$.SCG.IEnumerable$$($.$fPer.LCFCD$1.IObservableDataDescriptor), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Statuses${separator}SmartEventCounterStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1614519)
        
        

        //--TRIMMABLE-BOUNDARY-START(1483447)
        $asm.$str(`$WYlj.LCIDEMS.SmartEventCounterLogType`, ($self) => class SmartEventCounterLogType extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static Startup = 0;
            static Count = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1483447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Startup": 0n,
                    "Count": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296450743)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296450743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296450743)
            
            //--TRIMMABLE-BOUNDARY-START(4296450743)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296450743)
            
            static $h = 1483447;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886385335),
    {
      "t": 1483447,
      "n": "Startup",
      "d": 1483447,
      "h": 12886385335,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886385335),
//--TRIMMABLE-BOUNDARY-START(8591418039),
    {
      "t": 1483447,
      "n": "Count",
      "d": 1483447,
      "h": 8591418039,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591418039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296450743),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1483447,
      "h": 4296450743,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296450743)
  ],
  "h": 1483447
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Statuses${separator}SmartEventCounterLogType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1483447)
        
        

        //--TRIMMABLE-BOUNDARY-START(2466487)
        $asm.$str(`$WYlj.LCIDES$1.SmartEventCounterBroadcastPeerMessages`, ($self) => class SmartEventCounterBroadcastPeerMessages extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Count = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2466487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Count": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297433783)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297433783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297433783)
            
            //--TRIMMABLE-BOUNDARY-START(4297433783)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297433783)
            
            static $h = 2466487;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887368375),
    {
      "t": 2466487,
      "n": "None",
      "d": 2466487,
      "h": 12887368375,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887368375),
//--TRIMMABLE-BOUNDARY-START(8592401079),
    {
      "t": 2466487,
      "n": "Count",
      "d": 2466487,
      "h": 8592401079,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592401079)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297433783),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2466487,
      "h": 4297433783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297433783)
  ],
  "h": 2466487
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterBroadcastPeerMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterBroadcastPeerMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2466487)
        
        

        //--TRIMMABLE-BOUNDARY-START(2335415)
        $asm.$str(`$WYlj.LCIDES$1.SmartEventCounterActions`, ($self) => class SmartEventCounterActions extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2335415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
        
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297302711)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297302711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297302711)
            
            //--TRIMMABLE-BOUNDARY-START(4297302711)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297302711)
            
            static $h = 2335415;
            static $z = 1;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297302711),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2335415,
      "h": 4297302711,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297302711)
  ],
  "h": 2335415
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterActions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterActions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2335415)
        
        

        //--TRIMMABLE-BOUNDARY-START(107191)
        $asm.$cls(`$WYlj.LCIDE._Imports`, ($self) => class _Imports extends $.$hDPm.LCFCC$1.BaseComponent
        {
            //--TRIMMABLE-BOUNDARY-START(8590041783)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590041783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590041783)
            
            //--TRIMMABLE-BOUNDARY-START(4295074487)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295074487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295074487)
            
            //--TRIMMABLE-BOUNDARY-START(4295074487)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295074487)
            
            static $h = 107191;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590041783),
    {
      "r": 65537,
      "n": "Execute",
      "d": 107191,
      "h": 8590041783,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590041783)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295074487),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 107191,
      "h": 4295074487,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295074487)
  ],
  "h": 107191
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter._Imports`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}_Imports`; }
        });
        //--TRIMMABLE-BOUNDARY-END(107191)
        
        

        //--TRIMMABLE-BOUNDARY-START(565943)
        $asm.$cls(`$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelTypeDescriptor`, ($self) => class SmartEventCounterResetQuotaControlModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295533239)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295533239);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelTypeDescriptor.GenerateProperties($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel, this, factory);
                    }, $VrkOke ??= {"r":65537,"n":"","d":565943,"h":0,"f":17825794}), 0, "SmartEventCounterResetQuotaControlModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EventCounter\\Models_Controls_SmartEventCounterResetQuotaControlModel_LivingThing.Core.IOT.Devices.EventCounter.Models.Controls.SmartEventCounterResetQuotaControlModelTypeDescriptorBuilder.g.cs", "SmartEventCounterResetQuotaControlModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295533239)
            
            //--TRIMMABLE-BOUNDARY-START(12885467831)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885467831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Value"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel.$type, $.$discardRef(), "Value", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Value")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Value";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Controls.SmartEventCounterResetQuotaControlModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel)).Value);
                        }, $aEBQdi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":565943,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Value = value.AsInt();
                        }, $pvDiti ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":565943,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Command"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel.$type, $.$discardRef(), "Command", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Command")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Command";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Controls.SmartEventCounterResetQuotaControlModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel)).Command);
                        }, $hzhYzd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":565943,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885467831)
            
            //--TRIMMABLE-BOUNDARY-START(17180435127)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Models.Controls.SmartEventCounterResetQuotaControlModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180435127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandModel));
                {
                    /*var*/ let _Value = _target.Value;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Value"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Value, ($v) => _Value = $v, $.$$.S.Int32)))
                    {
                        _target.Value = _Value;
                    }
                }
                {
                    /*var*/ let _Command = _target.Command;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Command"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Command, ($v) => _Command = $v, $.$$.S.Int32)))
                    {
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180435127)
            
            //--TRIMMABLE-BOUNDARY-START(8590500535)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Models.Controls.SmartEventCounterResetQuotaControlModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590500535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel)))
                {
                    /*var*/ let result = $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590500535)
            
            static $h = 565943;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885467831),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 565943,
      "h": 12885467831,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885467831),
//--TRIMMABLE-BOUNDARY-START(17180435127),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 434871,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 565943,
      "h": 17180435127,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180435127),
//--TRIMMABLE-BOUNDARY-START(8590500535),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 434871,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 565943,
      "h": 8590500535,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590500535)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295533239),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 565943,
      "h": 4295533239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295533239)
  ],
  "h": 565943
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Controls.SmartEventCounterResetQuotaControlModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Controls${separator}SmartEventCounterResetQuotaControlModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(565943)
        
        

        //--TRIMMABLE-BOUNDARY-START(1352375)
        $asm.$cls(`$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor`, ($self) => class SmartEventCounterLogModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDEMS.SmartEventCounterLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296319671)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296319671);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor.GenerateProperties($.$WYlj.LCIDEMS.SmartEventCounterLogModel, this, factory);
                    }, $rkXAza ??= {"r":65537,"n":"","d":1352375,"h":0,"f":17825794}), 0, "SmartEventCounterLogModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EventCounter\\Models_Statuses_SmartEventCounterLogModel_LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModelTypeDescriptorBuilder.g.cs", "SmartEventCounterLogModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296319671)
            
            //--TRIMMABLE-BOUNDARY-START(12886254263)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886254263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Type"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMS.SmartEventCounterLogModel.$type, $.$discardRef(), "Type", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Type")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$WYlj.LCIDEMS.SmartEventCounterLogType, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Type";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromEnumValue($.$WYlj.LCIDEMS.SmartEventCounterLogType, ($.$cast(target, $.$WYlj.LCIDEMS.SmartEventCounterLogModel)).Type);
                        }, $mlKIsa ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1352375,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Type = value.AsEnumValue($.$WYlj.LCIDEMS.SmartEventCounterLogType);
                        }, $uflLYd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1352375,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Delta"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMS.SmartEventCounterLogModel.$type, $.$discardRef(), "Delta", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Delta")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Delta";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$WYlj.LCIDEMS.SmartEventCounterLogModel)).Delta);
                        }, $wOIJhj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1352375,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Delta = value.AsInt();
                        }, $WAqOyk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1352375,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Count"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMS.SmartEventCounterLogModel.$type, $.$discardRef(), "Count", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Count")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int64, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Count";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$8(($.$cast(target, $.$WYlj.LCIDEMS.SmartEventCounterLogModel)).Count);
                        }, $IPuIDk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1352375,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Count = value.AsLong();
                        }, $NUCVdi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1352375,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886254263)
            
            //--TRIMMABLE-BOUNDARY-START(17181221559)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181221559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceLogModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceLogModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceLogModel));
                {
                    /*var*/ let _Type = _target.Type;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Type"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$WYlj.LCIDEMS.SmartEventCounterLogType));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$WYlj.LCIDEMS.SmartEventCounterLogType, () => _Type, ($v) => _Type = $v, null, true)))
                    {
                        _target.Type = _Type;
                    }
                }
                {
                    /*var*/ let _Delta = _target.Delta;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Delta"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Delta, ($v) => _Delta = $v, $.$$.S.Int32)))
                    {
                        _target.Delta = _Delta;
                    }
                }
                {
                    /*var*/ let _Count = _target.Count;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Count"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int64));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int64, property, $.$ref(() => _Count, ($v) => _Count = $v, $.$$.S.Int64)))
                    {
                        _target.Count = _Count;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181221559)
            
            //--TRIMMABLE-BOUNDARY-START(8591286967)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591286967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WYlj.LCIDEMS.SmartEventCounterLogModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WYlj.LCIDEMS.SmartEventCounterLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEMS.SmartEventCounterLogModel)))
                {
                    /*var*/ let result = $.$WYlj.LCIDEMS.SmartEventCounterLogModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEMS.SmartEventCounterLogModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WYlj.LCIDEMS.SmartEventCounterLogModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEMS.SmartEventCounterLogModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591286967)
            
            static $h = 1352375;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDEMS.SmartEventCounterLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886254263),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1352375,
      "h": 12886254263,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886254263),
//--TRIMMABLE-BOUNDARY-START(17181221559),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1221303,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1352375,
      "h": 17181221559,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181221559),
//--TRIMMABLE-BOUNDARY-START(8591286967),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1221303,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1352375,
      "h": 8591286967,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591286967)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296319671),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1352375,
      "h": 4296319671,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296319671)
  ],
  "h": 1352375
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WYlj.LCIDEMS.SmartEventCounterLogModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Statuses${separator}SmartEventCounterLogModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1352375)
        
        

        //--TRIMMABLE-BOUNDARY-START(1745591)
        $asm.$cls(`$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor`, ($self) => class SmartEventCounterStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDEMS.SmartEventCounterStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296712887)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296712887);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor.GenerateProperties($.$WYlj.LCIDEMS.SmartEventCounterStatusModel, this, factory);
                    }, $QlGyff ??= {"r":65537,"n":"","d":1745591,"h":0,"f":17825794}), 0, "SmartEventCounterStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EventCounter\\Models_Statuses_SmartEventCounterStatusModel_LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModelTypeDescriptorBuilder.g.cs", "SmartEventCounterStatusModelTypeDescriptor", 37);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296712887)
            
            //--TRIMMABLE-BOUNDARY-START(12886647479)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886647479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Count"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel.$type, $.$discardRef(), "Count", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Count")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int64, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Count";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$8(($.$cast(target, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel)).Count);
                        }, $auoGPi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1745591,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Count = value.AsLong();
                        }, $dsRfEe ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1745591,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("UniqueSales"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel.$type, $.$discardRef(), "UniqueSales", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("UniqueSales")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.UInt32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "UniqueSales";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$13(($.$cast(target, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel)).UniqueSales);
                        }, $nssdUi ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1745591,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.UniqueSales = value.AsUInt();
                        }, $mMhpxb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1745591,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("SystemTime"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel.$type, $.$discardRef(), "SystemTime", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("SystemTime")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.DateTime, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "SystemTime";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$4(($.$cast(target, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel)).SystemTime);
                        }, $jCcQLh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1745591,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.SystemTime = value.AsDateTime();
                        }, $gjBUbg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1745591,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("LastSaleAgo"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel.$type, $.$discardRef(), "LastSaleAgo", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("LastSaleAgo")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.UInt32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "LastSaleAgo";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$13(($.$cast(target, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel)).LastSaleAgo);
                        }, $ZLWdPb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1745591,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.LastSaleAgo = value.AsUInt();
                        }, $psiaBb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1745591,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("MsPerLiter"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel.$type, $.$discardRef(), "MsPerLiter", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("MsPerLiter")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "MsPerLiter";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel)).MsPerLiter);
                        }, $hxgWSh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1745591,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.MsPerLiter = value.AsInt();
                        }, $VpldFg ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1745591,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Removed"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel.$type, $.$discardRef(), "Removed", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Removed")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Boolean, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t11 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i11 = new $t11();
                        $i11.$ctor$2();
                        $i11.Name = "Removed";
                        $i11.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel";
                        $i11.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue(($.$cast(target, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel)).Removed);
                        }, $kuJUDk ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1745591,"h":0,"f":17825826});
                        $i11.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Removed = value.AsBool();
                        }, $xbIEqb ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1745591,"h":0,"f":17825826});
                        return $i11;
                    })()), schemas, null, factory);
                    let $en12 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en12.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en12.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886647479)
            
            //--TRIMMABLE-BOUNDARY-START(17181614775)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181614775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Count = _target.Count;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Count"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int64));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int64, property, $.$ref(() => _Count, ($v) => _Count = $v, $.$$.S.Int64)))
                    {
                        _target.Count = _Count;
                    }
                }
                {
                    /*var*/ let _UniqueSales = _target.UniqueSales;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("UniqueSales"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.UInt32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.UInt32, property, $.$ref(() => _UniqueSales, ($v) => _UniqueSales = $v, $.$$.S.UInt32)))
                    {
                        _target.UniqueSales = _UniqueSales;
                    }
                }
                {
                    /*var*/ let _SystemTime = _target.SystemTime;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("SystemTime"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.DateTime));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.DateTime, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTime, () => _SystemTime, ($v) => _SystemTime = $v, null, true)))
                    {
                        _target.SystemTime = _SystemTime;
                    }
                }
                {
                    /*var*/ let _LastSaleAgo = _target.LastSaleAgo;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("LastSaleAgo"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.UInt32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.UInt32, property, $.$ref(() => _LastSaleAgo, ($v) => _LastSaleAgo = $v, $.$$.S.UInt32)))
                    {
                        _target.LastSaleAgo = _LastSaleAgo;
                    }
                }
                {
                    /*var*/ let _MsPerLiter = _target.MsPerLiter;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("MsPerLiter"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _MsPerLiter, ($v) => _MsPerLiter = $v, $.$$.S.Int32)))
                    {
                        _target.MsPerLiter = _MsPerLiter;
                    }
                }
                {
                    /*var*/ let _Removed = _target.Removed;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Removed"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Boolean));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Boolean, property, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => _Removed, ($v) => _Removed = $v, null, true)))
                    {
                        _target.Removed = _Removed;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181614775)
            
            //--TRIMMABLE-BOUNDARY-START(8591680183)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591680183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WYlj.LCIDEMS.SmartEventCounterStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel)))
                {
                    /*var*/ let result = $.$WYlj.LCIDEMS.SmartEventCounterStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591680183)
            
            static $h = 1745591;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDEMS.SmartEventCounterStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886647479),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1745591,
      "h": 12886647479,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886647479),
//--TRIMMABLE-BOUNDARY-START(17181614775),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1614519,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1745591,
      "h": 17181614775,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181614775),
//--TRIMMABLE-BOUNDARY-START(8591680183),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1614519,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1745591,
      "h": 8591680183,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591680183)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296712887),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1745591,
      "h": 4296712887,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296712887)
  ],
  "h": 1745591
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WYlj.LCIDEMS.SmartEventCounterStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}Statuses${separator}SmartEventCounterStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1745591)
        
        

        //--TRIMMABLE-BOUNDARY-START(1942199)
        $asm.$cls(`$WYlj.LCIDEPC.SmartEventCounterDeviceCommands<>`, (TDevice) => $asm.$gt(`$WYlj.LCIDEPC.SmartEventCounterDeviceCommands<>`, [TDevice], ($self) => class SmartEventCounterDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12886844087)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12886844087)
            
            //--TRIMMABLE-BOUNDARY-START(17181811383)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181811383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$WYlj.LCIDEPC.SmartEventCounterDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17181811383)
            
            //--TRIMMABLE-BOUNDARY-START(8591876791)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591876791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591876791)
            
            //--TRIMMABLE-BOUNDARY-START(8591876791)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8591876791)
            
            //--TRIMMABLE-BOUNDARY-START(4296909495)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296909495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12886844087)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [new $.$WYlj.LCIDEPCV.SmartEventCounterResetQuotaCommand().$ctor$6()], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12886844087)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296909495)
            
            static $H = 1942199;
            static $h = 1942199;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181811383),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17181811383,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181811383)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886844087),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12886844087,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886844087)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591876791),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8591876791,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591876791)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 1942199,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Protocol.Commands.SmartEventCounterDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Protocol${separator}Commands${separator}SmartEventCounterDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1942199)
        
        

        //--TRIMMABLE-BOUNDARY-START(2007735)
        $asm.$cls(`$WYlj.LCIDEPCV.SmartEventCounterResetQuotaCommand`, ($self) => class SmartEventCounterResetQuotaCommand extends $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296975031)
            $ctor$6()
            {
                super.$ctor$5("Reset Quota", null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296975031);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296975031)
            
            //--TRIMMABLE-BOUNDARY-START(17181876919)
            /*IconDescriptor */ get Icon()
            {
                return $.$fPer.LCFC.IconDescriptor.op_Implicit("mdi mdi-numeric-0-box"/*MaterialDesignIconNames.Numeric0Box*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17181876919)
            
            //--TRIMMABLE-BOUNDARY-START(4296975031)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4296975031)
            
            static $h = 2007735;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDevicePublicCommand$$($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181876919),
    {
      "p": 46238038,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886909623,
        "f": 50364417
      },
      "n": "Icon",
      "d": 2007735,
      "h": 17181876919,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181876919)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296975031),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2007735,
      "h": 4296975031,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296975031)
  ],
  "h": 2007735
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommand, $.$XBGm.LCICDiC.IiSmartDeviceCommand ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Protocol.Commands.Variants.SmartEventCounterResetQuotaCommand`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Protocol${separator}Commands${separator}Variants${separator}SmartEventCounterResetQuotaCommand`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2007735)
        
        

        //--TRIMMABLE-BOUNDARY-START(959159)
        $asm.$cls(`$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel`, ($self) => class SmartEventCounterDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(8590893751)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590893751);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590893751)
            
            //--TRIMMABLE-BOUNDARY-START(12885861047)
            $ctor$5(/*SmartEventCounterResetQuotaControlModel*/ reset)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885861047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Reset = reset;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885861047)
            
            //--TRIMMABLE-BOUNDARY-START(25770762935)
            /*SmartEventCounterResetQuotaControlModel?*/ Reset = null;
            //--TRIMMABLE-BOUNDARY-END(25770762935)
            
            //--TRIMMABLE-BOUNDARY-START(8590893751)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8590893751)
            
            static $h = 959159;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770762935),
    {
      "p": 434871,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475795639,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360697527,
        "f": 83886081
      },
      "n": "Reset",
      "d": 959159,
      "h": 25770762935,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 26418,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770762935)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590893751),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 959159,
      "h": 8590893751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590893751),
//--TRIMMABLE-BOUNDARY-START(12885861047),
    {
      "p": [
        {
          "n": "reset",
          "p": 434871
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 959159,
      "h": 12885861047,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885861047)
  ],
  "h": 959159
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}SmartEventCounterDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(959159)
        
        

        //--TRIMMABLE-BOUNDARY-START(1090231)
        $asm.$cls(`$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelTypeDescriptor`, ($self) => class SmartEventCounterDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296057527)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296057527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelTypeDescriptor.GenerateProperties($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, this, factory);
                    }, $UWqyMg ??= {"r":65537,"n":"","d":1090231,"h":0,"f":17825794}), 0, "SmartEventCounterDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EventCounter\\Models_SmartEventCounterDeviceSendDataModel_LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModelTypeDescriptorBuilder.g.cs", "SmartEventCounterDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296057527)
            
            //--TRIMMABLE-BOUNDARY-START(12885992119)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885992119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Reset"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel.$type, $.$discardRef(), "Reset", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Reset")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Reset";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel, ($.$cast(target, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel)).Reset);
                        }, $KKqKya ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":1090231,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Reset = value.AsReference($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel);
                        }, $svceri ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":1090231,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885992119)
            
            //--TRIMMABLE-BOUNDARY-START(17180959415)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180959415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                {
                    /*var*/ let _Reset = _target.Reset;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Reset"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Reset, ($v) => _Reset = $v, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel)))
                    {
                        _target.Reset = _Reset;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180959415)
            
            //--TRIMMABLE-BOUNDARY-START(8591024823)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591024823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591024823)
            
            static $h = 1090231;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885992119),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1090231,
      "h": 12885992119,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885992119),
//--TRIMMABLE-BOUNDARY-START(17180959415),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 959159,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1090231,
      "h": 17180959415,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180959415),
//--TRIMMABLE-BOUNDARY-START(8591024823),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 959159,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1090231,
      "h": 8591024823,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591024823)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296057527),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1090231,
      "h": 4296057527,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296057527)
  ],
  "h": 1090231
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}SmartEventCounterDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1090231)
        
        

        //--TRIMMABLE-BOUNDARY-START(697015)
        $asm.$cls(`$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel`, ($self) => class SmartEventCounterDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$WYlj.LCIDEMS.SmartEventCounterStatusModel, $.$WYlj.LCIDEMS.SmartEventCounterLogModel)
        {
            //--TRIMMABLE-BOUNDARY-START(12885598903)
            /*SmartEventCounterDeviceSendDataModel */ LogAck()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885598903);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel()
                        const $t1 = $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel;
                        const $i1 = new $t1();
                        $i1.$ctor$4();
                        $i1.LogAck = new $.$XBGm.LCICDi.iSmartDeviceLogAcknowledgeModel().$ctor$1();
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885598903)
            
            //--TRIMMABLE-BOUNDARY-START(8590631607)
            /*IOTDeviceSendDataModel? */ Ack()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590631607);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Log !== null ? this.LogAck() : null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590631607)
            
            //--TRIMMABLE-BOUNDARY-START(4295664311)
            //default constructor overload
            $ctor$6()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295664311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295664311)
            
            //--TRIMMABLE-BOUNDARY-START(4295664311)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$6();
            }
            //--TRIMMABLE-BOUNDARY-END(4295664311)
            
            static $h = 697015;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$WYlj.LCIDEMS.SmartEventCounterStatusModel, $.$WYlj.LCIDEMS.SmartEventCounterLogModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885598903),
    {
      "r": 959159,
      "n": "LogAck",
      "d": 697015,
      "h": 12885598903,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885598903),
//--TRIMMABLE-BOUNDARY-START(8590631607),
    {
      "r": 39425425,
      "n": "Ack",
      "d": 697015,
      "h": 8590631607,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590631607)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295664311),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 697015,
      "h": 4295664311,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295664311)
  ],
  "h": 697015
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}SmartEventCounterDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(697015)
        
        

        //--TRIMMABLE-BOUNDARY-START(828087)
        $asm.$cls(`$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModelTypeDescriptor`, ($self) => class SmartEventCounterDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295795383)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295795383);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, this, factory);
                    }, $WfOaDg ??= {"r":65537,"n":"","d":828087,"h":0,"f":17825794}), 0, "SmartEventCounterDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EventCounter\\Models_SmartEventCounterDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "SmartEventCounterDeviceReceivedDataModelTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295795383)
            
            //--TRIMMABLE-BOUNDARY-START(12885729975)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885729975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$WYlj.LCIDEMS.SmartEventCounterStatusModel, $.$WYlj.LCIDEMS.SmartEventCounterLogModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885729975)
            
            //--TRIMMABLE-BOUNDARY-START(17180697271)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180697271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel, LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterLogModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$$($.$WYlj.LCIDEMS.SmartEventCounterStatusModel, $.$WYlj.LCIDEMS.SmartEventCounterLogModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$$($.$WYlj.LCIDEMS.SmartEventCounterStatusModel, $.$WYlj.LCIDEMS.SmartEventCounterLogModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180697271)
            
            //--TRIMMABLE-BOUNDARY-START(8590762679)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590762679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel().$ctor$6();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590762679)
            
            static $h = 828087;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885729975),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 828087,
      "h": 12885729975,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885729975),
//--TRIMMABLE-BOUNDARY-START(17180697271),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 697015,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 828087,
      "h": 17180697271,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180697271),
//--TRIMMABLE-BOUNDARY-START(8590762679),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 697015,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 828087,
      "h": 8590762679,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590762679)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295795383),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 828087,
      "h": 4295795383,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295795383)
  ],
  "h": 828087
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Models${separator}SmartEventCounterDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(828087)
        
        

        //--TRIMMABLE-BOUNDARY-START(3121847)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDataConverter`, ($self) => class SmartEventCounterDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298089143)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298089143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298089143)
            
            //--TRIMMABLE-BOUNDARY-START(4298089143)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298089143)
            
            static $h = 3121847;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298089143),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3121847,
      "h": 4298089143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298089143)
  ],
  "h": 3121847
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3121847)
        
        

        $asm.$typeProxy("$WYlj.LCIDE.SmartEventCounterServiceModel", "$WYlj.LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModel");
        $asm.$typeProxy("$WYlj.LCIDE.SmartEventCounterDeviceScopeModel", "$WYlj.LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModel");
        $asm.$typeProxy("$WYlj.LCIDE.SmartEventCounterDeviceModel", "$WYlj.LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModel");
        $asm.$typeProxy("$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings", "$WYlj.LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings");
        $asm.$typeProxy("$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler", "$WYlj.LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceStatusHandler");
        $asm.$typeProxy("$WYlj.LCIDES.ISmartEventCounterDeviceHubClient", "$WYlj.LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceHubClient");
        $asm.$typeProxy("$WYlj.LCIDES.ISmartEventCounterRemoteService", "$WYlj.LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterRemoteService");
        //--TRIMMABLE-BOUNDARY-START(2859703)
        $asm.$cls(`$WYlj.LCIDES$1.SmartEventCounterDeviceSettings`, ($self) => class SmartEventCounterDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $self, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(4297826999)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297826999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297826999)
            
            //--TRIMMABLE-BOUNDARY-START(4297826999)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4297826999)
            
            static $h = 2859703;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297826999),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2859703,
      "h": 4297826999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297826999)
  ],
  "h": 2859703
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2859703)
        
        

        //--TRIMMABLE-BOUNDARY-START(2138807)
        $asm.$cls(`$WYlj.LCIDES.ISmartEventCounterDeviceHubClient`, ($self) => class ISmartEventCounterDeviceHubClient
        {
            static $h = 2138807;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2138807
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Services${separator}ISmartEventCounterDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2138807)
        
        

        //--TRIMMABLE-BOUNDARY-START(2204343)
        $asm.$cls(`$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler`, ($self) => class ISmartEventCounterDeviceStatusHandler
        {
            static $h = 2204343;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2204343
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Services${separator}ISmartEventCounterDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2204343)
        
        

        //--TRIMMABLE-BOUNDARY-START(3383991)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceModel`, ($self) => class SmartEventCounterDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298351287)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298351287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298351287)
            
            //--TRIMMABLE-BOUNDARY-START(4298351287)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4298351287)
            
            static $h = 3383991;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298351287),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 3383991,
      "h": 4298351287,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298351287)
  ],
  "h": 3383991
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3383991)
        
        

        //--TRIMMABLE-BOUNDARY-START(2269879)
        $asm.$cls(`$WYlj.LCIDES.ISmartEventCounterRemoteService`, ($self) => class ISmartEventCounterRemoteService
        {
            static $h = 2269879;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2269879
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$WYlj.LCIDE.SmartEventCounterServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$WYlj.LCIDE.SmartEventCounterServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$WYlj.LCIDE.SmartEventCounterServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$WYlj.LCIDE.SmartEventCounterServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$WYlj.LCIDE.SmartEventCounterServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$WYlj.LCIDE.SmartEventCounterServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$WYlj.LCIDE.SmartEventCounterServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$WYlj.LCIDE.SmartEventCounterServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Services${separator}ISmartEventCounterRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2269879)
        
        

        //--TRIMMABLE-BOUNDARY-START(3711671)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceScopeModel`, ($self) => class SmartEventCounterDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298678967)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298678967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298678967)
            
            //--TRIMMABLE-BOUNDARY-START(4298678967)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4298678967)
            
            static $h = 3711671;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298678967),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 3711671,
      "h": 4298678967,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298678967)
  ],
  "h": 3711671
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3711671)
        
        

        //--TRIMMABLE-BOUNDARY-START(2597559)
        $asm.$cls(`$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings`, ($self) => class SmartEventCounterDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceHardwareSettings$$($.$WYlj.LCIDES$1.SmartEventCounterActions)
        {
            //--TRIMMABLE-BOUNDARY-START(17182466743)
            /*IOTDeviceInternalConfiguration<int>*/ Debounce = null;
            //--TRIMMABLE-BOUNDARY-END(17182466743)
            
            //--TRIMMABLE-BOUNDARY-START(55837172407)
            /*IOTDeviceInternalConfiguration<string>*/ Usage = null;
            //--TRIMMABLE-BOUNDARY-END(55837172407)
            
            //--TRIMMABLE-BOUNDARY-START(12887499447)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887499447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887499447)
            
            //--TRIMMABLE-BOUNDARY-START(12887499447)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(12887499447)
            
            static $h = 2597559;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceHardwareSettings$$($.$WYlj.LCIDES$1.SmartEventCounterActions); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182466743),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772401335,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42952270519,
        "f": 83886081
      },
      "n": "Debounce",
      "d": 2597559,
      "h": 17182466743,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "pcd",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17182466743),
//--TRIMMABLE-BOUNDARY-START(55837172407),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362335927,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51542205111,
        "f": 83886081
      },
      "n": "Usage",
      "d": 2597559,
      "h": 55837172407,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "pcu",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 21,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55837172407)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887499447),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2597559,
      "h": 12887499447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887499447)
  ],
  "h": 2597559
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2597559)
        
        

        //--TRIMMABLE-BOUNDARY-START(4039351)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterServiceModel`, ($self) => class SmartEventCounterServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4299006647)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299006647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299006647)
            
            //--TRIMMABLE-BOUNDARY-START(4299006647)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4299006647)
            
            static $h = 4039351;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299006647),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 4039351,
      "h": 4299006647,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299006647)
  ],
  "h": 4039351
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4039351)
        
        

        //--TRIMMABLE-BOUNDARY-START(3515063)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceModelDefinition`, ($self) => class SmartEventCounterDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4298482359)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298482359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298482359)
            
            //--TRIMMABLE-BOUNDARY-START(4298482359)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298482359)
            
            static $h = 3515063;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298482359),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3515063,
      "h": 4298482359,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298482359)
  ],
  "h": 3515063
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3515063)
        
        

        //--TRIMMABLE-BOUNDARY-START(3973815)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterHandler`, ($self) => class SmartEventCounterHandler extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593908407)
            /*IDeviceStore*/ deviceStore = null;
            //--TRIMMABLE-BOUNDARY-END(8593908407)
            
            //--TRIMMABLE-BOUNDARY-START(25773777591)
            /*IDeviceStatusStore*/ statusStore = null;
            //--TRIMMABLE-BOUNDARY-END(25773777591)
            
            //--TRIMMABLE-BOUNDARY-START(4298941111)
            $ctor$1(/*IDeviceStore*/ deviceStore, /*IDeviceStatusStore*/ statusStore)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298941111);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.deviceStore = deviceStore;
                    this.statusStore = statusStore;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298941111)
            
            //--TRIMMABLE-BOUNDARY-START(12888875703)
            /*Task */ HandleConnected(/*IConnectionClient*/ client, /*object?*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888875703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12888875703)
            
            //--TRIMMABLE-BOUNDARY-START(17183842999)
            /*Task */ HandleDisconnected(/*IConnectionClient*/ client, /*object?*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183842999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(17183842999)
            
            //--TRIMMABLE-BOUNDARY-START(21478810295)
            /*Task<SmartEventCounterDeviceSendDataModel?> *//*async*/  HandleReceived(/*IConnectionMessage*/ message, /*SmartEventCounterDeviceReceivedDataModel*/ status, /*object?*/ arg)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel), $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478810295);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (status.Status !== null)
                    {
                        let $t1, $r1;
                        /*var*/ let device = ($t1 = this.deviceStore.LCICD$ISmartDataStoreReadSingle$LivingThing$Core$IOT$Common$Interface$IIOTDeviceModel$GetByIdAsync(message.LCFCC$IConnectionMessage$Client.LCFCC$IConnectionClient$Id.UniqueId).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        if (device !== null)
                        {
                            let $t2, $r2;
                            /*DateTime*/ let date;
                            /*var*/ let lastStatus = ($t2 = this.statusStore.LCICD$IDeviceStatusStore$GetLastAsync(device, $.$ref(() => date, ($v) => date = $v, $.$$.S.DateTime)).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            if (lastStatus === null || (lastStatus.SCG$IDictionary$$$$get_Item(1) - Number(status.Status.Count)) > 0)
                            {
                                let $t4, $r4;
                                ($t4 = this.statusStore.LCICD$IDeviceStatusStore$SaveAsync(device, (() =>
                                {
                                    //new $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Double)()
                                    const $t5 = $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$$.S.Double);
                                    const $i5 = new $t5();
                                    $i5.$ctor$1();
                                    $i5.set_Item(1, Number(status.Status.Count));
                                    return $i5;
                                })()).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                            }
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21478810295)
            
            //--TRIMMABLE-BOUNDARY-START(4323972497)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceStatusHandler<LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel>.HandleReceived(LivingThing.Core.Frameworks.Common.Connection.IConnectionMessage, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel, object?)
            LCICI$IIOTDeviceStatusHandler$$$$HandleReceived()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4323972497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleReceived(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4323972497)
            
            //--TRIMMABLE-BOUNDARY-START(8616056209)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceConnectionStatusHandler.HandleConnected(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, object?)
            LCICI$IIOTDeviceConnectionStatusHandler$HandleConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8616056209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleConnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8616056209)
            
            //--TRIMMABLE-BOUNDARY-START(12911023505)
            //Generated interface implemetation for LivingThing.Core.IOT.Common.Interface.IIOTDeviceConnectionStatusHandler.HandleDisconnected(LivingThing.Core.Frameworks.Common.Connection.IConnectionClient, object?)
            LCICI$IIOTDeviceConnectionStatusHandler$HandleDisconnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12911023505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HandleDisconnected(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12911023505)
            
            static $h = 3973815;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888875703),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "HandleConnected",
      "d": 3973815,
      "h": 12888875703,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888875703),
//--TRIMMABLE-BOUNDARY-START(17183842999),
    {
      "r": 178454529,
      "p": [
        {
          "n": "client",
          "p": 1568430
        },
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "HandleDisconnected",
      "d": 3973815,
      "h": 17183842999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183842999),
//--TRIMMABLE-BOUNDARY-START(21478810295),
    {
      "r": $.$$.STT.Task$$($.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel).$h,
      "p": [
        {
          "n": "message",
          "p": 1961646
        },
        {
          "n": "status",
          "p": 697015
        },
        {
          "n": "arg",
          "p": 131073
        }
      ],
      "n": "HandleReceived",
      "d": 3973815,
      "h": 21478810295,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21478810295)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593908407),
    {
      "t": 1283473,
      "n": "deviceStore",
      "d": 3973815,
      "h": 8593908407,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593908407),
//--TRIMMABLE-BOUNDARY-START(25773777591),
    {
      "t": 1152401,
      "n": "statusStore",
      "d": 3973815,
      "h": 25773777591,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25773777591)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298941111),
    {
      "p": [
        {
          "n": "deviceStore",
          "p": 1283473
        },
        {
          "n": "statusStore",
          "p": 1152401
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3973815,
      "h": 4298941111,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298941111)
  ],
  "h": 3973815
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3973815)
        
        

        //--TRIMMABLE-BOUNDARY-START(2990775)
        $asm.$cls(`$WYlj.LCIDES$1.SmartEventCounterDeviceSettingsTypeDescriptor`, ($self) => class SmartEventCounterDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297958071)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297958071);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettingsTypeDescriptor.GenerateProperties($.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, this, factory);
                    }, $ooSFfi ??= {"r":65537,"n":"","d":2990775,"h":0,"f":17825794}), 0, "SmartEventCounterDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EventCounter\\Settings_SmartEventCounterDeviceSettings_LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettingsTypeDescriptorBuilder.g.cs", "SmartEventCounterDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297958071)
            
            //--TRIMMABLE-BOUNDARY-START(12887892663)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887892663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887892663)
            
            //--TRIMMABLE-BOUNDARY-START(17182859959)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182859959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModel, LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettings, LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceStatusHandler, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceHubClient, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceSettings));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182859959)
            
            //--TRIMMABLE-BOUNDARY-START(8592925367)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592925367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings)))
                {
                    /*var*/ let result = $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592925367)
            
            static $h = 2990775;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887892663),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2990775,
      "h": 12887892663,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887892663),
//--TRIMMABLE-BOUNDARY-START(17182859959),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2859703,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2990775,
      "h": 17182859959,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182859959),
//--TRIMMABLE-BOUNDARY-START(8592925367),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2859703,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2990775,
      "h": 8592925367,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592925367)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297958071),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2990775,
      "h": 4297958071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297958071)
  ],
  "h": 2990775
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2990775)
        
        

        //--TRIMMABLE-BOUNDARY-START(2728631)
        $asm.$cls(`$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptor`, ($self) => class SmartEventCounterDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297695927)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297695927);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, this, factory);
                    }, $iBnApf ??= {"r":65537,"n":"","d":2728631,"h":0,"f":17825794}), 0, "SmartEventCounterDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EventCounter\\Settings_SmartEventCounterDeviceHardwareSettings_LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "SmartEventCounterDeviceHardwareSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297695927)
            
            //--TRIMMABLE-BOUNDARY-START(12887630519)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887630519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Debounce"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings.$type, $.$discardRef(), "Debounce", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Debounce")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Int32), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Debounce";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Int32), ($.$cast(target, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings)).Debounce);
                        }, $SQDWua ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2728631,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target, /**/ value) =>
                        {
                            return target.Debounce = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Int32));
                        }, $BwLfke ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2728631,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Usage"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings.$type, $.$discardRef(), "Usage", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Usage")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Usage";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String), ($.$cast(target, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings)).Usage);
                        }, $rVHMhf ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2728631,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Usage = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String));
                        }, $pIBrkd ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2728631,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$WYlj.LCIDES$1.SmartEventCounterActions).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887630519)
            
            //--TRIMMABLE-BOUNDARY-START(17182597815)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182597815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModel, LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettings, LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceStatusHandler, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceHubClient, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterRemoteService>.iSmartDeviceHardwareSettings<LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterActions>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor$$($.$WYlj.LCIDES$1.SmartEventCounterActions).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).iSmartDeviceHardwareSettings$$($.$WYlj.LCIDES$1.SmartEventCounterActions)));
                {
                    /*var*/ let _Debounce = _target.Debounce;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Debounce"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Int32)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Debounce, ($v) => _Debounce = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Int32))))
                    {
                        _target.Debounce = _Debounce;
                    }
                }
                {
                    /*var*/ let _Usage = _target.Usage;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Usage"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Usage, ($v) => _Usage = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.String))))
                    {
                        _target.Usage = _Usage;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182597815)
            
            //--TRIMMABLE-BOUNDARY-START(8592663223)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592663223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592663223)
            
            static $h = 2728631;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887630519),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2728631,
      "h": 12887630519,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887630519),
//--TRIMMABLE-BOUNDARY-START(17182597815),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2597559,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2728631,
      "h": 17182597815,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182597815),
//--TRIMMABLE-BOUNDARY-START(8592663223),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2597559,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2728631,
      "h": 8592663223,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592663223)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297695927),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2728631,
      "h": 4297695927,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297695927)
  ],
  "h": 2728631
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Settings${separator}SmartEventCounterDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2728631)
        
        

        //--TRIMMABLE-BOUNDARY-START(4170423)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterServiceModelTypeDescriptor`, ($self) => class SmartEventCounterServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDE.SmartEventCounterServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299137719)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299137719);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WYlj.LCIDE.SmartEventCounterServiceModelTypeDescriptor.GenerateProperties($.$WYlj.LCIDE.SmartEventCounterServiceModel, this, factory);
                    }, $GKYuUg ??= {"r":65537,"n":"","d":4170423,"h":0,"f":17825794}), 0, "SmartEventCounterServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EventCounter\\SmartEventCounterServiceModel_LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModelTypeDescriptorBuilder.g.cs", "SmartEventCounterServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299137719)
            
            //--TRIMMABLE-BOUNDARY-START(12889072311)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889072311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12889072311)
            
            //--TRIMMABLE-BOUNDARY-START(17184039607)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184039607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModel, LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettings, LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceStatusHandler, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceHubClient, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17184039607)
            
            //--TRIMMABLE-BOUNDARY-START(8594105015)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594105015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WYlj.LCIDE.SmartEventCounterServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WYlj.LCIDE.SmartEventCounterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDE.SmartEventCounterServiceModel)))
                {
                    /*var*/ let result = $.$WYlj.LCIDE.SmartEventCounterServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDE.SmartEventCounterServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WYlj.LCIDE.SmartEventCounterServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDE.SmartEventCounterServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8594105015)
            
            static $h = 4170423;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDE.SmartEventCounterServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12889072311),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 4170423,
      "h": 12889072311,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12889072311),
//--TRIMMABLE-BOUNDARY-START(17184039607),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4039351,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 4170423,
      "h": 17184039607,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17184039607),
//--TRIMMABLE-BOUNDARY-START(8594105015),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 4039351,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 4170423,
      "h": 8594105015,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8594105015)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299137719),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 4170423,
      "h": 4299137719,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299137719)
  ],
  "h": 4170423
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WYlj.LCIDE.SmartEventCounterServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4170423)
        
        

        //--TRIMMABLE-BOUNDARY-START(3580599)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceModelTypeDescriptor`, ($self) => class SmartEventCounterDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDE.SmartEventCounterDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298547895)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298547895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WYlj.LCIDE.SmartEventCounterDeviceModelTypeDescriptor.GenerateProperties($.$WYlj.LCIDE.SmartEventCounterDeviceModel, this, factory);
                    }, $LBIuvc ??= {"r":65537,"n":"","d":3580599,"h":0,"f":17825794}), 0, "SmartEventCounterDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EventCounter\\SmartEventCounterDeviceModel_LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModelTypeDescriptorBuilder.g.cs", "SmartEventCounterDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298547895)
            
            //--TRIMMABLE-BOUNDARY-START(12888482487)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888482487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888482487)
            
            //--TRIMMABLE-BOUNDARY-START(17183449783)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183449783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModel, LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettings, LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceStatusHandler, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceHubClient, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183449783)
            
            //--TRIMMABLE-BOUNDARY-START(8593515191)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593515191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WYlj.LCIDE.SmartEventCounterDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDE.SmartEventCounterDeviceModel)))
                {
                    /*var*/ let result = $.$WYlj.LCIDE.SmartEventCounterDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDE.SmartEventCounterDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDE.SmartEventCounterDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593515191)
            
            static $h = 3580599;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDE.SmartEventCounterDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888482487),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3580599,
      "h": 12888482487,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888482487),
//--TRIMMABLE-BOUNDARY-START(17183449783),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3383991,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3580599,
      "h": 17183449783,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183449783),
//--TRIMMABLE-BOUNDARY-START(8593515191),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3383991,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3580599,
      "h": 8593515191,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593515191)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298547895),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3580599,
      "h": 4298547895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298547895)
  ],
  "h": 3580599
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WYlj.LCIDE.SmartEventCounterDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3580599)
        
        

        //--TRIMMABLE-BOUNDARY-START(3842743)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceScopeModelTypeDescriptor`, ($self) => class SmartEventCounterDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298810039)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298810039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModelTypeDescriptor.GenerateProperties($.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, this, factory);
                    }, $Apogia ??= {"r":65537,"n":"","d":3842743,"h":0,"f":17825794}), 0, "SmartEventCounterDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.EventCounter\\SmartEventCounterDeviceScopeModel_LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModelTypeDescriptorBuilder.g.cs", "SmartEventCounterDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298810039)
            
            //--TRIMMABLE-BOUNDARY-START(12888744631)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888744631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12888744631)
            
            //--TRIMMABLE-BOUNDARY-START(17183711927)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183711927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceModel, LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceSettings, LivingThing.Core.IOT.Devices.EventCounter.Settings.SmartEventCounterDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceSendDataModel, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceStatusHandler, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterDeviceHubClient, LivingThing.Core.IOT.Devices.EventCounter.Services.ISmartEventCounterRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17183711927)
            
            //--TRIMMABLE-BOUNDARY-START(8593777335)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593777335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel)))
                {
                    /*var*/ let result = $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593777335)
            
            static $h = 3842743;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888744631),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 3842743,
      "h": 12888744631,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12888744631),
//--TRIMMABLE-BOUNDARY-START(17183711927),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3711671,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 3842743,
      "h": 17183711927,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17183711927),
//--TRIMMABLE-BOUNDARY-START(8593777335),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 3711671,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 3842743,
      "h": 8593777335,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8593777335)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298810039),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3842743,
      "h": 4298810039,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298810039)
  ],
  "h": 3842743
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3842743)
        
        

        //--TRIMMABLE-BOUNDARY-START(3187383)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDevice`, ($self) => class SmartEventCounterDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4298154679)
            $ctor$2(/*IIOTDeviceFamily<SmartEventCounterDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*SmartEventCounterDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298154679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298154679)
            
            //--TRIMMABLE-BOUNDARY-START(17183056567)
            /*Task */ ResetCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183056567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartIOTDeviceSendReceiveExtension.PublishCommand$2($.$WYlj.LCIDEPCV.SmartEventCounterResetQuotaCommand, $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel, this, new $.$WYlj.LCIDEPCV.SmartEventCounterResetQuotaCommand().$ctor$6(), new $.$WYlj.LCIDEMC.SmartEventCounterResetQuotaControlModel().$ctor$2());
            }
            //--TRIMMABLE-BOUNDARY-END(17183056567)
            
            //--TRIMMABLE-BOUNDARY-START(21478023863)
            /*string */ get StatusText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888089271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LivingThing.Core.IOT.Devices.EventCounter.Models.SmartEventCounterDeviceReceivedDataModel?*/ let __ca1__;
                /*LivingThing.Core.IOT.Devices.EventCounter.Models.Statuses.SmartEventCounterStatusModel?*/ let __ca2__;
                return ((__ca1__ = this.Received) !== null ? (((__ca2__ = __ca1__.Status) !== null ? ($.$$.S.Int64.ToString.call(__ca2__.Count) ?? "") : "") ?? "") : "");
            }
            //--TRIMMABLE-BOUNDARY-END(21478023863)
            
            static $h = 3187383;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478023863),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12888089271,
        "f": 50364417
      },
      "n": "StatusText",
      "d": 3187383,
      "h": 21478023863,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21478023863)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183056567),
    {
      "r": 178454529,
      "n": "ResetCount",
      "d": 3187383,
      "h": 17183056567,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183056567)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298154679),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$WYlj.LCIDE.SmartEventCounterDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 3383991
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3187383,
      "h": 4298154679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298154679)
  ],
  "h": 3187383
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3187383)
        
        

        //--TRIMMABLE-BOUNDARY-START(3252919)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceDefinition`, ($self) => class SmartEventCounterDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4298220215)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298220215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298220215)
            
            //--TRIMMABLE-BOUNDARY-START(4298220215)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4298220215)
            
            static $h = 3252919;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$WYlj.LCIDEMS.SmartEventCounterStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298220215),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3252919,
      "h": 4298220215,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298220215)
  ],
  "h": 3252919
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3252919)
        
        

        //--TRIMMABLE-BOUNDARY-START(3318455)
        $asm.$cls(`$WYlj.LCIDE.SmartEventCounterDeviceFamily`, ($self) => class SmartEventCounterDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4298285751)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<SmartEventCounterDeviceReceivedDataModel, SmartEventCounterDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<SmartEventCounterDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298285751);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298285751)
            
            //--TRIMMABLE-BOUNDARY-START(8593253047)
            /*Type */ get DeviceBroadcastSendMessageEnumType()
            {
                return $.$WYlj.LCIDES$1.SmartEventCounterBroadcastPeerMessages.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(8593253047)
            
            //--TRIMMABLE-BOUNDARY-START(12888220343)
            /*Type */ get DeviceLogType()
            {
                return $.$WYlj.LCIDEMS.SmartEventCounterLogModel.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(12888220343)
            
            static $h = 3318455;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDE.SmartEventCounterServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$WYlj.LCIDE.SmartEventCounterDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$WYlj.LCIDE.SmartEventCounterDeviceModel, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel, $.$WYlj.LCIDES.ISmartEventCounterDeviceStatusHandler, $.$WYlj.LCIDES.ISmartEventCounterDeviceHubClient, $.$WYlj.LCIDES.ISmartEventCounterRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593253047),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478154935,
        "f": 50364417
      },
      "n": "DeviceBroadcastSendMessageEnumType",
      "d": 3318455,
      "h": 8593253047,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593253047),
//--TRIMMABLE-BOUNDARY-START(12888220343),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068089527,
        "f": 50364417
      },
      "n": "DeviceLogType",
      "d": 3318455,
      "h": 12888220343,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12888220343)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298285751),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3318455,
      "h": 4298285751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298285751)
  ],
  "h": 3318455
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$WYlj.LCIDE.SmartEventCounterDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.SmartEventCounterDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}SmartEventCounterDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3318455)
        
        

        //--TRIMMABLE-BOUNDARY-START(4498103)
        $asm.$cls(`$WYlj.LCIDEV.SmartEventCounterViewRenderer`, ($self) => class SmartEventCounterViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299465399)
            $ctor$3(/*IOTRootViewModel*/ root)
            {
                super.$ctor$2(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299465399);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299465399)
            
            //--TRIMMABLE-BOUNDARY-START(8594432695)
            /*RenderFragment */ GetView(/*IClientUnitOfWork*/ ui, /*SmartEventCounterDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>*/ clicked, /*Func<Task>*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594432695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$WYlj.LCIDEV.SmartEventCounterDeviceDetails, $.$WYlj.LCIDEV.SmartEventCounterDetailsViewModel, new $.$WYlj.LCIDEV.SmartEventCounterDetailsViewModel().$ctor$9(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8594432695)
            
            static $h = 4498103;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8594432695),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 3187383
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 4498103,
      "h": 8594432695,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8594432695)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299465399),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4498103,
      "h": 4299465399,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299465399)
  ],
  "h": 4498103
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$WYlj.LCIDE.SmartEventCounterDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Views.SmartEventCounterViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Views${separator}SmartEventCounterViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4498103)
        
        

        //--TRIMMABLE-BOUNDARY-START(4367031)
        $asm.$cls(`$WYlj.LCIDEV.SmartEventCounterDetailsViewModel`, ($self) => class SmartEventCounterDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4299334327)
            $ctor$9(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*SmartEventCounterDevice*/ device)
            {
                super.$ctor$8(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4299334327);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299334327)
            
            //--TRIMMABLE-BOUNDARY-START(17184236215)
            /*string */ get Title()
            {
                return `${$.$strNN(this.Device$1.Model$1.Name)} (Smart EventCounter)`;
            }
            //--TRIMMABLE-BOUNDARY-END(17184236215)
            
            static $h = 4367031;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$($.$WYlj.LCIDE.SmartEventCounterDevice, $.$WYlj.LCIDES$1.SmartEventCounterDeviceSettings, $.$WYlj.LCIDES$1.SmartEventCounterDeviceHardwareSettings, $.$WYlj.LCIDEM.SmartEventCounterDeviceReceivedDataModel, $.$WYlj.LCIDEM.SmartEventCounterDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17184236215),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12889268919,
        "f": 50331649
      },
      "n": "Title",
      "d": 4367031,
      "h": 17184236215,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17184236215)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299334327),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 3187383
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 4367031,
      "h": 4299334327,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299334327)
  ],
  "h": 4367031
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Views.SmartEventCounterDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Views${separator}SmartEventCounterDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4367031)
        
        

        //--TRIMMABLE-BOUNDARY-START(4432567)
        $asm.$cls(`$WYlj.LCIDEV.SmartEventCounterDeviceDetails`, ($self) => class SmartEventCounterDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$WYlj.LCIDEV.SmartEventCounterDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51544040119)
            /*SmartEventCounterDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51544040119)
            
            //--TRIMMABLE-BOUNDARY-START(34364170935)
            /*string */ get OptimizedComponentName()
            {
                return "smarteventcounterdevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(34364170935)
            
            //--TRIMMABLE-BOUNDARY-START(47249072823)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47249072823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$WYlj.LCIDEV.SmartEventCounterDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47249072823)
            
            //--TRIMMABLE-BOUNDARY-START(12889334455)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889334455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$WYlj.LCIDE.SmartEventCounterDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$WYlj.LCIDE.SmartEventCounterDevice), this.ViewModel));
                __builder.AddAttribute$3(2, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    __builder2.OpenComponent$1($.$hDPm.LCFCCC$1.Card, 3);
                    __builder2.AddAttribute$3(4, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder3*/ __builder3) =>
                    {
                        __builder3.OpenComponent$1($.$hDPm.LCFCCG.SevenSegments, 5);
                        __builder3.AddComponentParameter(6, "Number", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, Number((this.ViewModel.Device$1.Received?.Status?.Count ?? null) ?? 0n)), $.$$.S.Double));
                        __builder3.AddComponentParameter(7, "Height", "100");
                        __builder3.AddComponentParameter(8, "Digits", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Int32, 6), $.$$.S.Int32));
                        __builder3.CloseComponent();
                    }), $jXTiVg ??= {"r":65537,"p":[{"n":"__builder3","p":7536755}],"n":"","d":4432567,"h":0,"f":17825794}));
                    __builder2.CloseComponent();
                }), $uSJvJj ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":4432567,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12889334455)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8594367159)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594367159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8594367159)
            
            //--TRIMMABLE-BOUNDARY-START(8594367159)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8594367159)
            
            static $h = 4432567;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$WYlj.LCIDEV.SmartEventCounterDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51544040119),
    {
      "p": 4367031,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30069203639,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42954105527,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 4432567,
      "h": 51544040119,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51544040119),
//--TRIMMABLE-BOUNDARY-START(34364170935),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21479269047,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 4432567,
      "h": 34364170935,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34364170935)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47249072823),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 4432567,
      "h": 47249072823,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47249072823),
//--TRIMMABLE-BOUNDARY-START(12889334455),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 4432567,
      "h": 12889334455,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12889334455)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8594367159),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 4432567,
      "h": 8594367159,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8594367159)
  ],
  "h": 4432567
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.EventCounter.Views.SmartEventCounterDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}EventCounter${separator}Views${separator}SmartEventCounterDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4432567)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(41655)
