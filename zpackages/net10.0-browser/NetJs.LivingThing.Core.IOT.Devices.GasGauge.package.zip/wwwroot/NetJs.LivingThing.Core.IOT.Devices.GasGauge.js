
//--TRIMMABLE-BOUNDARY-START(49057)
(async function () {
(function ($global, $, $$, $spu, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $sdts, $srn, $sfa, $sicb, $sre, $srei, $srel, $srp, $sle, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $srl, $str, $spx, $spxl, $mc, $ssa, $mwr, $sdp, $srw, $srsf, $sxxd, $sct, $sca, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $sifw, $sipl, $slq, $stew, $stj, $snhj, $snwh, $snr, $snw, $snws, $snwc, $srsp, $stec, $swh, $sxx, $sxxx, $PdqY, $HnZw, $DcMY, $iqft, $mam, $mep, $mecga, $mec, $mecb, $mxdi, $meo, $meda, $meoc, $mxdg, $mexla, $maa, $mac, $maca, $mev, $macf, $med, $mj, $macw, $meca, $mecm, $mefa, $mef, $mefp, $mecf, $mecj, $sih, $hqRR, $AWhY, $fPer, $Iaui, $GfYa, $zHIt, $kVHt, $uvJL, $UrvY, $vWqU, $ljzt, $TLYN, $hDPm, $yleQ, $nYKj, $AvdQ, $sZVd, $DJRY, $bMcF, $rfUg, $aElv, $yyXP, $wtdm, $lJUR, $eFOo, $fXpo, $KuVO, $lOHy, $JRhp, $tUcV, $XBGm, $xIHr, $NXre, $cDvV, $mVyz, $dgLE, $ntej) {
    "use strict";
    let _;
    let $PLYBkf;
    let $ybcoZj;
    let $MvdIRk;
    let $RNmyIg;
    let $cBRDyc;
    let $CXTZqj;
    let $Xqfujc;
    let $vRRPrb;
    let $NfJBdl;
    let $loTswe;
    let $JBsYmk;
    let $WOHPOe;
    let $LYVrok;
    let $iUWtxk;
    let $xpHClh;
    let $Zwocce;
    let $ZtJFkk;
    let $ztBlOg;
    let $rfgPll;
    let $LtDMWe;
    let $omzifg;
    let $QwJnae;
    let $ngLSBh;
    let $aRWlqh;
    let $TMCEHc;
    let $SMKxhe;
    let $jHRdHg;
    let $wiNFWc;
    let $vyTdxk;
    let $PKTZoh;
    let $oZmEQg;
    let $EiQAhb;
    let $Kpdwkl;
    let $DRqbFd;
    let $MmYXnj;
    let $jpiakj;
    let $ZMKLZa;
    let $IqznYb;
    let $ifMiRi;
    let $ZMmLZh;
    let $lHOoSi;
    
    
    
	$.$asm(
    "NetJs.LivingThing.Core.IOT.Devices.GasGauge", 
    {
  "h": 49057,
  "f": "LivingThing.Core.IOT.Devices.GasGauge",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B631ba11f6111396ec6c0779ebe5c4b7e9d068361",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.GasGauge",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "LivingThing.Core.IOT.Devices.GasGauge",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": [
    {
      "n": "appsettings.json",
      "d": "ew0KICAiRGV2aWNlcyI6IHsNCiAgICAiTGl2aW5nVGhpbmcuQ29yZS5JT1QuRGV2aWNlcy5HYXNHYXVnZS5HYXNHYXVnZURldmljZSI6IHsNCiAgICAgICJDYXRlZ29yaWVzIjogWyAiU21hcnQgSG9tZSIgXSwNCiAgICAgICJOYW1lIjogIkdhc0dhdWdlIiwNCiAgICAgICJEZXNjcmlwdGlvbiI6ICIiLA0KICAgICAgIkJhbm5lckltYWdlIjogIn4vR2FzR2F1Z2UvaW1nL2Jhbm5lci5qcGciLA0KICAgICAgIkljb24iOiB7ICJOYW1lIjogIm1kaSBtZGktZWxlY3RyaWMtc3dpdGNoIiB9LA0KICAgICAgIlRoZW1lQ29sb3IiOiAiI2Q3N2JiYSIsDQogICAgICAiRmxhZ3MiOiAiRmVhdHVyZWQsUHVibGlzaGVkIiwNCiAgICAgICJTZWN1cml0aWVzIjogIkNoYWxsZW5nZUhhbmRTaGFrZUF1dGhlbnRpY2F0aW9uUHJvdG9jb2wsQWR2YW5jZWRFbmNyeXB0aW9uU3RhbmRhcmQsRWxsaXB0aWNDdXJ2ZUZpcm13YXJlVXBkYXRlU2lnbmluZyINCiAgICB9DQogIH0NCn0="
    }
  ]
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1818529)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeServiceModelCustomAttributesProvider`, ($self) => class GasGaugeServiceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296785825)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296785825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTServiceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296785825)
            
            static $h = 1818529;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296785825),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1818529,
      "h": 4296785825,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296785825)
  ],
  "h": 1818529
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeServiceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1818529)
        
        

        //--TRIMMABLE-BOUNDARY-START(1032097)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModelCustomAttributesProvider`, ($self) => class GasGaugeDeviceReceivedDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295999393)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295999393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelCustomAttributesProvider$$($.$MmZc.LCIDGMS.GasGaugeStatusModel).GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295999393)
            
            static $h = 1032097;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295999393),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1032097,
      "h": 4295999393,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295999393)
  ],
  "h": 1032097
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceReceivedDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1032097)
        
        

        //--TRIMMABLE-BOUNDARY-START(114593)
        $asm.$cls(`$MmZc.LCIDG._Startup`, ($self) => class _Startup
        {
            //--TRIMMABLE-BOUNDARY-START(4295081889)
            static /*void */ AddGeneratedComponentOptimizers(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295081889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$4($.$hDPm.LCFCG.IModuleComponentInstantiatorProvider, $.$MmZc.LCIDG.ModuleComponentInstantiatorProvider, services);
            }
            //--TRIMMABLE-BOUNDARY-END(4295081889)
            
            static $h = 114593;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295081889),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedComponentOptimizers",
      "d": 114593,
      "h": 4295081889,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295081889)
  ],
  "h": 114593
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge._Startup`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}_Startup`; }
        });
        //--TRIMMABLE-BOUNDARY-END(114593)
        
        

        //--TRIMMABLE-BOUNDARY-START(1556385)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceSendDataModelCustomAttributesProvider`, ($self) => class GasGaugeDeviceSendDataModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296523681)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296523681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceCommandsModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296523681)
            
            static $h = 1556385;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296523681),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1556385,
      "h": 4296523681,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296523681)
  ],
  "h": 1556385
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceSendDataModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1556385)
        
        

        //--TRIMMABLE-BOUNDARY-START(2932641)
        $asm.$cls(`$MmZc.LCIDGS$1.GasGaugeDeviceSettingsCustomAttributesProvider`, ($self) => class GasGaugeDeviceSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297899937)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297899937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceSettingsCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4297899937)
            
            static $h = 2932641;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297899937),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2932641,
      "h": 4297899937,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297899937)
  ],
  "h": 2932641
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Settings${separator}GasGaugeDeviceSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2932641)
        
        

        //--TRIMMABLE-BOUNDARY-START(3129249)
        $asm.$cls(`$MmZc.LCIDG.TypeDescriptorStartupExtension`, ($self) => class TypeDescriptorStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4298096545)
            static /*void */ AddGeneratedTypeDescriptors(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298096545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$MmZc.LCIDGM.GasGaugeDeviceModelTypeDescriptorBuilder.Register();
                $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModelTypeDescriptorBuilder.Register();
                $.$MmZc.LCIDGM.GasGaugeDeviceScopeModelTypeDescriptorBuilder.Register();
                $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModelTypeDescriptorBuilder.Register();
                $.$MmZc.LCIDGM.GasGaugeServiceModelTypeDescriptorBuilder.Register();
                $.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptorBuilder.Register();
                $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsTypeDescriptorBuilder.Register();
                $.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptorBuilder.Register();
            }
            //--TRIMMABLE-BOUNDARY-END(4298096545)
            
            static $h = 3129249;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4298096545),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedTypeDescriptors",
      "d": 3129249,
      "h": 4298096545,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298096545)
  ],
  "h": 3129249
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.TypeDescriptorStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}TypeDescriptorStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3129249)
        
        

        //--TRIMMABLE-BOUNDARY-START(245665)
        $asm.$cls(`$MmZc.LCIDG.FastAttributeStartupExtension`, ($self) => class FastAttributeStartupExtension
        {
            //--TRIMMABLE-BOUNDARY-START(4295212961)
            static /*void */ AddGeneratedFastAttributes(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295212961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MmZc.LCIDGM.GasGaugeDeviceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MmZc.LCIDGM.GasGaugeDeviceModelCustomAttributesProvider, $.$MmZc.LCIDGM.GasGaugeDeviceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModelCustomAttributesProvider, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MmZc.LCIDGM.GasGaugeDeviceScopeModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MmZc.LCIDGM.GasGaugeDeviceScopeModelCustomAttributesProvider, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MmZc.LCIDGM.GasGaugeDeviceSendDataModelCustomAttributesProvider, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MmZc.LCIDGM.GasGaugeServiceModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MmZc.LCIDGM.GasGaugeServiceModelCustomAttributesProvider, $.$MmZc.LCIDGM.GasGaugeServiceModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MmZc.LCIDGMS.GasGaugeStatusModel.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelCustomAttributesProvider, $.$MmZc.LCIDGMS.GasGaugeStatusModelCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsCustomAttributesProvider, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsCustomAttributesProvider.GetAttributes));
                $.$fPer.LCFCF.FastAttributeRegistry.Register($.$MmZc.LCIDGS$1.GasGaugeDeviceSettings.$type, new $.$fPer.LCFCF.FastAttributeRegistry.AttributeProvider().$ctor($.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsCustomAttributesProvider, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsCustomAttributesProvider.GetAttributes));
            }
            //--TRIMMABLE-BOUNDARY-END(4295212961)
            
            static $h = 245665;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295212961),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddGeneratedFastAttributes",
      "d": 245665,
      "h": 4295212961,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295212961)
  ],
  "h": 245665
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.FastAttributeStartupExtension`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}FastAttributeStartupExtension`; }
        });
        //--TRIMMABLE-BOUNDARY-END(245665)
        
        

        //--TRIMMABLE-BOUNDARY-START(1294241)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceScopeModelCustomAttributesProvider`, ($self) => class GasGaugeDeviceScopeModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296261537)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296261537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceScopeModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4296261537)
            
            static $h = 1294241;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296261537),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 1294241,
      "h": 4296261537,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296261537)
  ],
  "h": 1294241
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceScopeModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1294241)
        
        

        //--TRIMMABLE-BOUNDARY-START(1425313)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceScopeModelTypeDescriptorBuilder`, ($self) => class GasGaugeDeviceScopeModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591359905)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591359905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MmZc.LCIDGM.GasGaugeDeviceScopeModelTypeDescriptor()
                        const $t1 = $.$MmZc.LCIDGM.GasGaugeDeviceScopeModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $WOHPOe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1425313,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MmZc.LCIDGM.GasGaugeDeviceScopeModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591359905)
            
            //--TRIMMABLE-BOUNDARY-START(4296392609)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296392609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296392609)
            
            //--TRIMMABLE-BOUNDARY-START(4296392609)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296392609)
            
            static $h = 1425313;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591359905),
    {
      "r": 65537,
      "n": "Register",
      "d": 1425313,
      "h": 8591359905,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591359905)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296392609),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1425313,
      "h": 4296392609,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296392609)
  ],
  "h": 1425313
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceScopeModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1425313)
        
        

        //--TRIMMABLE-BOUNDARY-START(1163169)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModelTypeDescriptorBuilder`, ($self) => class GasGaugeDeviceReceivedDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591097761)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591097761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModelTypeDescriptor()
                        const $t1 = $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $ybcoZj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1163169,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591097761)
            
            //--TRIMMABLE-BOUNDARY-START(4296130465)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296130465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296130465)
            
            //--TRIMMABLE-BOUNDARY-START(4296130465)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296130465)
            
            static $h = 1163169;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591097761),
    {
      "r": 65537,
      "n": "Register",
      "d": 1163169,
      "h": 8591097761,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591097761)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296130465),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1163169,
      "h": 4296130465,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296130465)
  ],
  "h": 1163169
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceReceivedDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1163169)
        
        

        //--TRIMMABLE-BOUNDARY-START(1687457)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceSendDataModelTypeDescriptorBuilder`, ($self) => class GasGaugeDeviceSendDataModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591622049)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591622049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModelTypeDescriptor()
                        const $t1 = $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $loTswe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1687457,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591622049)
            
            //--TRIMMABLE-BOUNDARY-START(4296654753)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296654753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296654753)
            
            //--TRIMMABLE-BOUNDARY-START(4296654753)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296654753)
            
            static $h = 1687457;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591622049),
    {
      "r": 65537,
      "n": "Register",
      "d": 1687457,
      "h": 8591622049,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591622049)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296654753),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1687457,
      "h": 4296654753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296654753)
  ],
  "h": 1687457
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceSendDataModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1687457)
        
        

        //--TRIMMABLE-BOUNDARY-START(901025)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceModelTypeDescriptorBuilder`, ($self) => class GasGaugeDeviceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590835617)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590835617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MmZc.LCIDGM.GasGaugeDeviceModelTypeDescriptor()
                        const $t1 = $.$MmZc.LCIDGM.GasGaugeDeviceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $RNmyIg ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":901025,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MmZc.LCIDGM.GasGaugeDeviceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590835617)
            
            //--TRIMMABLE-BOUNDARY-START(4295868321)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295868321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295868321)
            
            //--TRIMMABLE-BOUNDARY-START(4295868321)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295868321)
            
            static $h = 901025;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590835617),
    {
      "r": 65537,
      "n": "Register",
      "d": 901025,
      "h": 8590835617,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590835617)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295868321),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 901025,
      "h": 4295868321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295868321)
  ],
  "h": 901025
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(901025)
        
        

        //--TRIMMABLE-BOUNDARY-START(1949601)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeServiceModelTypeDescriptorBuilder`, ($self) => class GasGaugeServiceModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591884193)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591884193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MmZc.LCIDGM.GasGaugeServiceModelTypeDescriptor()
                        const $t1 = $.$MmZc.LCIDGM.GasGaugeServiceModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $CXTZqj ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":1949601,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MmZc.LCIDGM.GasGaugeServiceModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8591884193)
            
            //--TRIMMABLE-BOUNDARY-START(4296916897)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296916897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296916897)
            
            //--TRIMMABLE-BOUNDARY-START(4296916897)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296916897)
            
            static $h = 1949601;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591884193),
    {
      "r": 65537,
      "n": "Register",
      "d": 1949601,
      "h": 8591884193,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591884193)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296916897),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1949601,
      "h": 4296916897,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296916897)
  ],
  "h": 1949601
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeServiceModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1949601)
        
        

        //--TRIMMABLE-BOUNDARY-START(2670497)
        $asm.$cls(`$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsCustomAttributesProvider`, ($self) => class GasGaugeDeviceHardwareSettingsCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297637793)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297637793)
            
            //--TRIMMABLE-BOUNDARY-START(8592605089)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592605089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(1, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Calibration", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Key = "cal";
                            $i3.Order = (20);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $vRRPrb ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2670497,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/**/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $NfJBdl ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2670497,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceHardwareSettingsCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592605089)
            
            static $h = 2670497;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592605089),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2670497,
      "h": 8592605089,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592605089)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297637793),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2670497,
      "h": 4297637793,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297637793)
  ],
  "h": 2670497
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettingsCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Settings${separator}GasGaugeDeviceHardwareSettingsCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2670497)
        
        

        //--TRIMMABLE-BOUNDARY-START(2211745)
        $asm.$cls(`$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptorBuilder`, ($self) => class GasGaugeStatusModelTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592146337)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592146337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/**/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor()
                        const $t1 = $.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $PKTZoh ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2211745,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MmZc.LCIDGMS.GasGaugeStatusModel.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592146337)
            
            //--TRIMMABLE-BOUNDARY-START(4297179041)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297179041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297179041)
            
            //--TRIMMABLE-BOUNDARY-START(4297179041)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297179041)
            
            static $h = 2211745;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592146337),
    {
      "r": 65537,
      "n": "Register",
      "d": 2211745,
      "h": 8592146337,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592146337)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297179041),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2211745,
      "h": 4297179041,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297179041)
  ],
  "h": 2211745
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModelTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}Statuses${separator}GasGaugeStatusModelTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2211745)
        
        

        //--TRIMMABLE-BOUNDARY-START(769953)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceModelCustomAttributesProvider`, ($self) => class GasGaugeDeviceModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295737249)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295737249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceModelCustomAttributesProvider.GetAttributes(type, path);
            }
            //--TRIMMABLE-BOUNDARY-END(4295737249)
            
            static $h = 769953;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295737249),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 769953,
      "h": 4295737249,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295737249)
  ],
  "h": 769953
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(769953)
        
        

        //--TRIMMABLE-BOUNDARY-START(3063713)
        $asm.$cls(`$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptorBuilder`, ($self) => class GasGaugeDeviceSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592998305)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592998305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptor()
                        const $t1 = $.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $rfgPll ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":3063713,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MmZc.LCIDGS$1.GasGaugeDeviceSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592998305)
            
            //--TRIMMABLE-BOUNDARY-START(4298031009)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298031009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298031009)
            
            //--TRIMMABLE-BOUNDARY-START(4298031009)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4298031009)
            
            static $h = 3063713;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592998305),
    {
      "r": 65537,
      "n": "Register",
      "d": 3063713,
      "h": 8592998305,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592998305)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298031009),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3063713,
      "h": 4298031009,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298031009)
  ],
  "h": 3063713
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Settings${separator}GasGaugeDeviceSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3063713)
        
        

        //--TRIMMABLE-BOUNDARY-START(2080673)
        $asm.$cls(`$MmZc.LCIDGMS.GasGaugeStatusModelCustomAttributesProvider`, ($self) => class GasGaugeStatusModelCustomAttributesProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4297047969)
            /*Dictionary<AttributeTypes, Dictionary<string, IEnumerable<object>>>?*/ static compiledAttributes = null;
            //--TRIMMABLE-BOUNDARY-END(4297047969)
            
            //--TRIMMABLE-BOUNDARY-START(8592015265)
            static /*IEnumerable<object>? */ GetAttributes(/*Type*/ type, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592015265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<object>?*/ let atts = null;
                $.$MmZc.LCIDGMS.GasGaugeStatusModelCustomAttributesProvider.compiledAttributes ??= (() =>
                {
                    //new $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)))()
                    const $t1 = $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                    const $i1 = new $t1();
                    $i1.$ctor$8(1);
                    $i1.set_Item(new $.$fPer.LCFCF.AttributeTypes().$ctor$4($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ $.$fPer.LCFCA$1.SchemaAttribute.$type, $.$fPer.LCFCA$1.SchemaAttribute$$($.$$.S.Object).$type, $.$fPer.LCFCA$1.SchemaAttributeBase.$type ], null, null)), (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))()
                        const $t2 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$7(5, $.$$.S.StringComparer.InvariantCultureIgnoreCase);
                        $i2.set_Item("Sample", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t3 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i3 = new $t3();
                            $i3.$ctor$4();
                            $i3.Order = (1);
                            return $i3;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Weight", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t4 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i4 = new $t4();
                            $i4.$ctor$4();
                            $i4.Order = (2);
                            $i4.ConvertType = ($.$$.S.Single.$type);
                            $i4.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Class=1"], [-1], null);
                            return $i4;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Temperature", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t5 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i5 = new $t5();
                            $i5.$ctor$4();
                            $i5.Order = (3);
                            $i5.ConvertType = ($.$$.S.Single.$type);
                            $i5.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Class=2"], [-1], null);
                            return $i5;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Humidity", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t6 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i6 = new $t6();
                            $i6.$ctor$4();
                            $i6.Order = (4);
                            $i6.ConvertType = ($.$$.S.Single.$type);
                            $i6.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Class=3"], [-1], null);
                            return $i6;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        $i2.set_Item("Gas", $.$$.N.InterfaceVarianceStubHandler.Create($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [(() =>
                        {
                            //new $.$fPer.LCFCA$1.SchemaAttribute()
                            const $t7 = $.$fPer.LCFCA$1.SchemaAttribute;
                            const $i7 = new $t7();
                            $i7.$ctor$4();
                            $i7.Order = (5);
                            $i7.ConvertType = ($.$$.S.Byte.$type);
                            $i7.Options = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["//Class=4"], [-1], null);
                            return $i7;
                        })()], [-1], null), $.$$.SCG.IEnumerable$$($.$fPer.LCFCA$1.SchemaAttribute), $.$$.SCG.IEnumerable$$($.$$.S.Object)));
                        return $i2;
                    })());
                    return $i1;
                })();
                atts = $.$sl.SL.Enumerable.SelectMany$2($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Object, $.$sl.SL.Enumerable.Where($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$MmZc.LCIDGMS.GasGaugeStatusModelCustomAttributesProvider.compiledAttributes, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.S.Boolean))().$ctor(this,  (/**/ e) =>
                {
                    return e.Key.Equals$2(type);
                }, $ZtJFkk ??= {"r":262145,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2080673,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))), $.$$.SCG.IEnumerable$$($.$$.S.Object)))().$ctor(this,  (/*e*/ e) =>
                {
                    return $.$$.SCG.CollectionExtensions.GetValueOrDefault$1($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object), e.Value, path) ?? $.$sl.SL.Enumerable.Empty($.$$.S.Object);
                }, $ztBlOg ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.Object).$h,"p":[{"n":"e","p":$.$$.SCG.KeyValuePair$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h}],"n":"","d":2080673,"h":0,"f":17825794}));
                if (!$.$sl.SL.Enumerable.Any$1($.$$.S.Object, atts))
                {
                    atts = null;
                }
                if (atts === null)
                {
                    return $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelCustomAttributesProvider.GetAttributes(type, path);
                }
                return atts;
            }
            //--TRIMMABLE-BOUNDARY-END(8592015265)
            
            static $h = 2080673;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592015265),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetAttributes",
      "d": 2080673,
      "h": 8592015265,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592015265)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297047969),
    {
      "t": $.$$.SCG.Dictionary$$$($.$fPer.LCFCF.AttributeTypes, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.IEnumerable$$($.$$.S.Object))).$h,
      "n": "compiledAttributes",
      "d": 2080673,
      "h": 4297047969,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297047969)
  ],
  "h": 2080673
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModelCustomAttributesProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}Statuses${separator}GasGaugeStatusModelCustomAttributesProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2080673)
        
        

        //--TRIMMABLE-BOUNDARY-START(2801569)
        $asm.$cls(`$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsTypeDescriptorBuilder`, ($self) => class GasGaugeDeviceHardwareSettingsTypeDescriptorBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592736161)
            static /*void */ Register()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592736161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let lazyTypeDescriptor = new $.$fPer.LCFCD$1.LazyTypeDesriptor().$ctor$2(new ($.$$.S.Func$$$($.$fPer.LCFCS$3.ServiceFactory, $.$fPer.LCFCD$1.ITypeDescriptor))().$ctor(this,  (/*factory*/ factory) =>
                {
                    /*var*/ let typeDescriptor = (() =>
                    {
                        //new $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsTypeDescriptor()
                        const $t1 = $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsTypeDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$5(factory, 20/*LivingThing.Core.Frameworks.Common.Data.DataType.Object*/, "LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings");
                        return $i1;
                    })();
                    return typeDescriptor;
                }, $SMKxhe ??= {"r":41453910,"p":[{"n":"factory","p":62949718}],"n":"","d":2801569,"h":0,"f":17825794}));
                $.$fPer.LCFCD$1.SystemTypeDescriptor.TryAdd($.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings.$type, 0/*LivingThing.Core.Frameworks.Common.Data.DataType.None*/, lazyTypeDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(8592736161)
            
            //--TRIMMABLE-BOUNDARY-START(4297768865)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297768865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297768865)
            
            //--TRIMMABLE-BOUNDARY-START(4297768865)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297768865)
            
            static $h = 2801569;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592736161),
    {
      "r": 65537,
      "n": "Register",
      "d": 2801569,
      "h": 8592736161,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592736161)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297768865),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2801569,
      "h": 4297768865,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297768865)
  ],
  "h": 2801569
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettingsTypeDescriptorBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Settings${separator}GasGaugeDeviceHardwareSettingsTypeDescriptorBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2801569)
        
        

        //--TRIMMABLE-BOUNDARY-START(180129)
        $asm.$cls(`$MmZc.LCIDG.ConfigurationFileProvider`, ($self) => class ConfigurationFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180049313)
            /*IEnumerable<string> */ get Paths()
            {
                return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [], [-1], null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180049313)
            
            //--TRIMMABLE-BOUNDARY-START(8594819414)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Configurations.IConfigurationFileProvider.Paths.get
            get LCFCC$1$IConfigurationFileProvider$Paths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889786710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Paths;
            }
            //--TRIMMABLE-BOUNDARY-END(8594819414)
            
            //--TRIMMABLE-BOUNDARY-START(4295147425)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295147425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295147425)
            
            //--TRIMMABLE-BOUNDARY-START(4295147425)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295147425)
            
            static $h = 180129;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180049313),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885082017,
        "f": 50331649
      },
      "n": "Paths",
      "d": 180129,
      "h": 17180049313,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180049313)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295147425),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 180129,
      "h": 4295147425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295147425)
  ],
  "h": 180129
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCC$1.IConfigurationFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.ConfigurationFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}ConfigurationFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(180129)
        
        

        //--TRIMMABLE-BOUNDARY-START(2277281)
        $asm.$cls(`$MmZc.LCIDG.ModuleComponentInstantiatorProvider`, ($self) => class ModuleComponentInstantiatorProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182146465)
            /*IEnumerable<KeyValuePair<Type, ComponentInstantiator>> */ get Instantiators()
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)))().$ctor$1(function*()
                {
                    yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator))().$ctor$3($.$MmZc.LCIDGV$1.GasGaugeDeviceDetails.$type, new $.$hDPm.LCFCG.ComponentInstantiator().$ctor(this,  () =>
                    {
                        return new $.$MmZc.LCIDGV$1.GasGaugeDeviceDetails().$ctor$4();
                    }, $PLYBkf ??= {"r":2752627,"n":"","d":2277281,"h":0,"f":17825794}));
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17182146465)
            
            //--TRIMMABLE-BOUNDARY-START(8650839722)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IModuleComponentInstantiatorProvider.Instantiators.get
            get LCFCG$IModuleComponentInstantiatorProvider$Instantiators()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945807018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Instantiators;
            }
            //--TRIMMABLE-BOUNDARY-END(8650839722)
            
            //--TRIMMABLE-BOUNDARY-START(4297244577)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297244577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297244577)
            
            //--TRIMMABLE-BOUNDARY-START(4297244577)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297244577)
            
            static $h = 2277281;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182146465),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Type, $.$hDPm.LCFCG.ComponentInstantiator)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12887179169,
        "f": 50331649
      },
      "n": "Instantiators",
      "d": 2277281,
      "h": 17182146465,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182146465)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297244577),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2277281,
      "h": 4297244577,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297244577)
  ],
  "h": 2277281
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$hDPm.LCFCG.IModuleComponentInstantiatorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.ModuleComponentInstantiatorProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}ModuleComponentInstantiatorProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2277281)
        
        

        //--TRIMMABLE-BOUNDARY-START(2342817)
        $asm.$cls(`$MmZc.LCIDG.ServiceRegistrar`, ($self) => class ServiceRegistrar extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8592277409)
            static /*void */ Configure(/*IServiceCollection*/ services, /*IConfiguration*/ configuration, /*StartupOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592277409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$fPer.LCFCC$1.IConfigurationFileProvider, $.$MmZc.LCIDG.ConfigurationFileProvider, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$MmZc.LCIDG.GasGaugeDataConverter, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$MmZc.LCIDG.GasGaugeDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$MmZc.LCIDG.GasGaugeDevice), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase), $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$5($.$XBGm.LCICI.IIOTDeviceFamily, $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$MmZc.LCIDG.GasGaugeDeviceFamily, services), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MmZc.LCIDG.GasGaugeDeviceFamily, x);
                }, $iUWtxk ??= {"r":26711441,"p":[{"n":"x","p":327718}],"n":"","d":2342817,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$$.N.InterfaceVarianceStubHandler.Create($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MmZc.LCIDG.GasGaugeDeviceFamily, x), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$MmZc.LCIDG.GasGaugeDevice), $.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase));
                }, $xpHClh ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$NXre.LCID.SmartDeviceBase).$h,"p":[{"n":"x","p":327718}],"n":"","d":2342817,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$XBGm.LCICI.IIOTDeviceFamily$$($.$MmZc.LCIDG.GasGaugeDevice)))().$ctor(this,  (/**/ x) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$MmZc.LCIDG.GasGaugeDeviceFamily, x);
                }, $Zwocce ??= {"r":$.$XBGm.LCICI.IIOTDeviceFamily$$($.$MmZc.LCIDG.GasGaugeDevice).$h,"p":[{"n":"x","p":327718}],"n":"","d":2342817,"h":0,"f":17825794})));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCIP.IOTDeviceProtocol$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel), $.$XBGm.LCICDi.iSmartDeviceProtocol$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolDecoder$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$XBGm.LCICDi.iSmartDeviceProtocolEncoder$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$($.$MmZc.LCIDG.GasGaugeDevice), $.$MmZc.LCIDGMC.GasGaugeDeviceCommands$$($.$MmZc.LCIDG.GasGaugeDevice), services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$4($.$ntej.LCICD$1.IDeviceViewRenderer$$($.$MmZc.LCIDG.GasGaugeDevice), $.$MmZc.LCIDGV$1.GasGaugeViewRenderer, services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$6($.$MmZc.LCIDGV.GasGaugeClientAppViewModel, services);
            }
            //--TRIMMABLE-BOUNDARY-END(8592277409)
            
            //--TRIMMABLE-BOUNDARY-START(4356999510)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Common.Services.IServiceCollectionBuilder.Configure(Microsoft.Extensions.DependencyInjection.IServiceCollection, Microsoft.Extensions.Configuration.IConfiguration, LivingThing.Core.Frameworks.Common.Services.StartupOptions)
            static LCFCS$3$IServiceCollectionBuilder$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4356999510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$MmZc.LCIDG.ServiceRegistrar.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4356999510)
            
            //--TRIMMABLE-BOUNDARY-START(4297310113)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297310113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297310113)
            
            //--TRIMMABLE-BOUNDARY-START(4297310113)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297310113)
            
            static $h = 2342817;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592277409),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 63211862
        }
      ],
      "n": "Configure",
      "d": 2342817,
      "h": 8592277409,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592277409)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297310113),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2342817,
      "h": 4297310113,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297310113)
  ],
  "h": 2342817
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCS$3.IServiceCollectionBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.ServiceRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}ServiceRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2342817)
        
        

        //--TRIMMABLE-BOUNDARY-START(3784609)
        $asm.$cls(`$MmZc.MEVE.ValidatableTypeAttribute`, ($self) => class ValidatableTypeAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298751905)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298751905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298751905)
            
            //--TRIMMABLE-BOUNDARY-START(4298751905)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298751905)
            
            static $h = 3784609;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298751905),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3784609,
      "h": 4298751905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298751905)
  ],
  "h": 3784609,
  "a": [
    {
      "t": 3719073,
      "c": 4298686369
    },
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Validation.Embedded.ValidatableTypeAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Validation${separator}Embedded${separator}ValidatableTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3784609)
        
        

        //--TRIMMABLE-BOUNDARY-START(3719073)
        $asm.$cls(`$MmZc.MC.EmbeddedAttribute`, ($self) => class EmbeddedAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298686369)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298686369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298686369)
            
            //--TRIMMABLE-BOUNDARY-START(4298686369)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298686369)
            
            static $h = 3719073;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298686369),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3719073,
      "h": 4298686369,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298686369)
  ],
  "h": 3719073
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.CodeAnalysis.EmbeddedAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}CodeAnalysis${separator}EmbeddedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3719073)
        
        

        //--TRIMMABLE-BOUNDARY-START(2015137)
        $asm.$cls(`$MmZc.LCIDGMS.GasGaugeStatusModel`, ($self) => class GasGaugeStatusModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel
        {
            //--TRIMMABLE-BOUNDARY-START(81606393761)
            /*int*/ Sample = 0;
            //--TRIMMABLE-BOUNDARY-END(81606393761)
            
            //--TRIMMABLE-BOUNDARY-START(133146001313)
            /*double*/ Weight = 0;
            //--TRIMMABLE-BOUNDARY-END(133146001313)
            
            //--TRIMMABLE-BOUNDARY-START(128851034017)
            /*double*/ Temperature = 0;
            //--TRIMMABLE-BOUNDARY-END(128851034017)
            
            //--TRIMMABLE-BOUNDARY-START(77311426465)
            /*double*/ Humidity = 0;
            //--TRIMMABLE-BOUNDARY-END(77311426465)
            
            //--TRIMMABLE-BOUNDARY-START(30066786209)
            /*int*/ Gas = 0;
            //--TRIMMABLE-BOUNDARY-END(30066786209)
            
            //--TRIMMABLE-BOUNDARY-START(25771818913)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771818913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771818913)
            
            //--TRIMMABLE-BOUNDARY-START(25771818913)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(25771818913)
            
            static $h = 2015137;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81606393761),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836589985,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107376197537,
        "f": 83886081
      },
      "n": "Sample",
      "d": 2015137,
      "h": 81606393761,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81606393761),
//--TRIMMABLE-BOUNDARY-START(133146001313),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016459169,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124556066721,
        "f": 83886081
      },
      "n": "Weight",
      "d": 2015137,
      "h": 133146001313,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 2,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//Class=1"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133146001313),
//--TRIMMABLE-BOUNDARY-START(128851034017),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426524577,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115966132129,
        "f": 83886081
      },
      "n": "Temperature",
      "d": 2015137,
      "h": 128851034017,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 3,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//Class=2"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128851034017),
//--TRIMMABLE-BOUNDARY-START(77311426465),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246655393,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98786262945,
        "f": 83886081
      },
      "n": "Humidity",
      "d": 2015137,
      "h": 77311426465,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 4,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 1114113,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//Class=3"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77311426465),
//--TRIMMABLE-BOUNDARY-START(30066786209),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656720801,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196328353,
        "f": 83886081
      },
      "n": "Gas",
      "d": 2015137,
      "h": 30066786209,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Order",
              "v": 5,
              "t": 655361
            },
            {
              "n": "ConvertType",
              "v": 393217,
              "t": 188547073
            },
            {
              "n": "Options",
              "v": [
                "//Class=4"
              ],
              "t": $.$typeArray($.$$.S.String).$h
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066786209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771818913),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2015137,
      "h": 25771818913,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771818913)
  ],
  "h": 2015137
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IOrderedSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}Statuses${separator}GasGaugeStatusModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2015137)
        
        

        //--TRIMMABLE-BOUNDARY-START(2146209)
        $asm.$cls(`$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor`, ($self) => class GasGaugeStatusModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGMS.GasGaugeStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4297113505)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297113505);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor.GenerateProperties($.$MmZc.LCIDGMS.GasGaugeStatusModel, this, factory);
                    }, $oZmEQg ??= {"r":65537,"n":"","d":2146209,"h":0,"f":17825794}), 0, "GasGaugeStatusModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GasGauge\\Models_Statuses_GasGaugeStatusModel_LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModelTypeDescriptorBuilder.g.cs", "GasGaugeStatusModelTypeDescriptor", 36);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297113505)
            
            //--TRIMMABLE-BOUNDARY-START(12887048097)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887048097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Sample"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MmZc.LCIDGMS.GasGaugeStatusModel.$type, $.$discardRef(), "Sample", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Sample")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Sample";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$MmZc.LCIDGMS.GasGaugeStatusModel)).Sample);
                        }, $EiQAhb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2146209,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Sample = value.AsInt();
                        }, $Kpdwkl ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2146209,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Weight"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MmZc.LCIDGMS.GasGaugeStatusModel.$type, $.$discardRef(), "Weight", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Weight")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "Weight";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$MmZc.LCIDGMS.GasGaugeStatusModel)).Weight);
                        }, $DRqbFd ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2146209,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Weight = value.AsDouble();
                        }, $MmYXnj ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2146209,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Temperature"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MmZc.LCIDGMS.GasGaugeStatusModel.$type, $.$discardRef(), "Temperature", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Temperature")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t5 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i5 = new $t5();
                        $i5.$ctor$2();
                        $i5.Name = "Temperature";
                        $i5.DelaredOn = "LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel";
                        $i5.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$MmZc.LCIDGMS.GasGaugeStatusModel)).Temperature);
                        }, $jpiakj ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2146209,"h":0,"f":17825826});
                        $i5.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Temperature = value.AsDouble();
                        }, $ZMKLZa ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2146209,"h":0,"f":17825826});
                        return $i5;
                    })()), schemas, null, factory);
                    let $en6 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en6.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Humidity"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MmZc.LCIDGMS.GasGaugeStatusModel.$type, $.$discardRef(), "Humidity", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Humidity")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t7 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i7 = new $t7();
                        $i7.$ctor$2();
                        $i7.Name = "Humidity";
                        $i7.DelaredOn = "LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel";
                        $i7.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$MmZc.LCIDGMS.GasGaugeStatusModel)).Humidity);
                        }, $IqznYb ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2146209,"h":0,"f":17825826});
                        $i7.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor, /*static*/ (/**/ target, /*value*/ value) =>
                        {
                            return target.Humidity = value.AsDouble();
                        }, $ifMiRi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2146209,"h":0,"f":17825826});
                        return $i7;
                    })()), schemas, null, factory);
                    let $en8 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en8.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Gas"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MmZc.LCIDGMS.GasGaugeStatusModel.$type, $.$discardRef(), "Gas", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Gas")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Int32, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t9 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i9 = new $t9();
                        $i9.$ctor$2();
                        $i9.Name = "Gas";
                        $i9.DelaredOn = "LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel";
                        $i9.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$7(($.$cast(target, $.$MmZc.LCIDGMS.GasGaugeStatusModel)).Gas);
                        }, $ZMmLZh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2146209,"h":0,"f":17825826});
                        $i9.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Gas = value.AsInt();
                        }, $lHOoSi ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2146209,"h":0,"f":17825826});
                        return $i9;
                    })()), schemas, null, factory);
                    let $en10 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en10.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en10.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887048097)
            
            //--TRIMMABLE-BOUNDARY-START(17182015393)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182015393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedStatusModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedStatusModel));
                {
                    /*var*/ let _Sample = _target.Sample;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Sample"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Sample, ($v) => _Sample = $v, $.$$.S.Int32)))
                    {
                        _target.Sample = _Sample;
                    }
                }
                {
                    /*var*/ let _Weight = _target.Weight;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Weight"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Weight, ($v) => _Weight = $v, $.$$.S.Double)))
                    {
                        _target.Weight = _Weight;
                    }
                }
                {
                    /*var*/ let _Temperature = _target.Temperature;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Temperature"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Temperature, ($v) => _Temperature = $v, $.$$.S.Double)))
                    {
                        _target.Temperature = _Temperature;
                    }
                }
                {
                    /*var*/ let _Humidity = _target.Humidity;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Humidity"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _Humidity, ($v) => _Humidity = $v, $.$$.S.Double)))
                    {
                        _target.Humidity = _Humidity;
                    }
                }
                {
                    /*var*/ let _Gas = _target.Gas;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Gas"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Int32));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Int32, property, $.$ref(() => _Gas, ($v) => _Gas = $v, $.$$.S.Int32)))
                    {
                        _target.Gas = _Gas;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182015393)
            
            //--TRIMMABLE-BOUNDARY-START(8592080801)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592080801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MmZc.LCIDGMS.GasGaugeStatusModel().$ctor$2();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MmZc.LCIDGMS.GasGaugeStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGMS.GasGaugeStatusModel)))
                {
                    /*var*/ let result = $.$MmZc.LCIDGMS.GasGaugeStatusModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGMS.GasGaugeStatusModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MmZc.LCIDGMS.GasGaugeStatusModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGMS.GasGaugeStatusModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592080801)
            
            static $h = 2146209;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGMS.GasGaugeStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887048097),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2146209,
      "h": 12887048097,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887048097),
//--TRIMMABLE-BOUNDARY-START(17182015393),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2015137,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2146209,
      "h": 17182015393,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182015393),
//--TRIMMABLE-BOUNDARY-START(8592080801),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2015137,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2146209,
      "h": 8592080801,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592080801)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297113505),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2146209,
      "h": 4297113505,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297113505)
  ],
  "h": 2146209
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MmZc.LCIDGMS.GasGaugeStatusModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}Statuses${separator}GasGaugeStatusModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2146209)
        
        

        //--TRIMMABLE-BOUNDARY-START(638881)
        $asm.$cls(`$MmZc.LCIDGMC.GasGaugeDeviceCommands<>`, (TDevice) => $asm.$gt(`$MmZc.LCIDGMC.GasGaugeDeviceCommands<>`, [TDevice], ($self) => class GasGaugeDeviceCommands$$ extends $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice)
        {
            //--TRIMMABLE-BOUNDARY-START(12885540769)
            /*IEnumerable<IOTDeviceProtocolCommand>*/ static commands$1 = null;
            //--TRIMMABLE-BOUNDARY-END(12885540769)
            
            //--TRIMMABLE-BOUNDARY-START(17180508065)
            /*IEnumerable<IOTDeviceProtocolCommand> */ GetCommands(/*IIOTDeviceModel?*/ device)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180508065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.SL.Enumerable.Concat($.$XBGm.LCIP.IOTDeviceProtocolCommand, $.$MmZc.LCIDGMC.GasGaugeDeviceCommands$$(TDevice).commands$1, super.GetCommands(device));
            }
            //--TRIMMABLE-BOUNDARY-END(17180508065)
            
            //--TRIMMABLE-BOUNDARY-START(8590573473)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$1(null);
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590573473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590573473)
            
            //--TRIMMABLE-BOUNDARY-START(8590573473)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(8590573473)
            
            //--TRIMMABLE-BOUNDARY-START(4295606177)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295606177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885540769)
                    this.commands$1 = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$XBGm.LCIP.IOTDeviceProtocolCommand), [], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885540769)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295606177)
            
            static $H = 638881;
            static $h = 638881;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDiC.iSmartDeviceProtocolCommands$$(TDevice); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180508065),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "p": [
        {
          "n": "device",
          "p": 27432337,
          "f": 65
        }
      ],
      "n": "GetCommands",
      "d": this.$h,
      "H": 17180508065,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180508065)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885540769),
    {
      "t": $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand).$h,
      "n": "commands",
      "o": "@$1",
      "d": this.$h,
      "H": 12885540769,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885540769)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590573473),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 8590573473,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590573473)
  ],
  "s": [
    {
      "h": TDevice?.$h??1572864,
      "n": "TDevice"
    }
  ],
  "r": 1,
  "H": 638881,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceProtocolCommands, $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceProtocolCommand), $.$$.SCG.IEnumerable$$($.$XBGm.LCIP.IOTDeviceProtocolCommand), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.Commands.GasGaugeDeviceCommands<${TDevice?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}Commands${separator}GasGaugeDeviceCommands$${TDevice?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(638881)
        
        

        //--TRIMMABLE-BOUNDARY-START(1490849)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceSendDataModel`, ($self) => class GasGaugeDeviceSendDataModel extends $.$XBGm.LCICDi.iSmartDeviceCommandsModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296458145)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296458145);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296458145)
            
            //--TRIMMABLE-BOUNDARY-START(4296458145)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296458145)
            
            static $h = 1490849;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceCommandsModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296458145),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1490849,
      "h": 4296458145,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296458145)
  ],
  "h": 1490849
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceSendDataModel, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceSendDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1490849)
        
        

        //--TRIMMABLE-BOUNDARY-START(966561)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel`, ($self) => class GasGaugeDeviceReceivedDataModel extends $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$MmZc.LCIDGMS.GasGaugeStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(8590901153)
            /*IEnumerable<IIOTDeviceDataPointModel>? */ GetDataPoints(/*SchemaType*/ schemaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590901153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (schemaType === 32/*SchemaType.Database*/)
                {
                    return null;
                }
                return super.GetDataPoints(schemaType);
            }
            //--TRIMMABLE-BOUNDARY-END(8590901153)
            
            //--TRIMMABLE-BOUNDARY-START(4295933857)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295933857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295933857)
            
            //--TRIMMABLE-BOUNDARY-START(4295933857)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295933857)
            
            static $h = 966561;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$MmZc.LCIDGMS.GasGaugeStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590901153),
    {
      "r": $.$$.SCG.IEnumerable$$($.$XBGm.LCICI.IIOTDeviceDataPointModel).$h,
      "p": [
        {
          "n": "schemaType",
          "p": 2722134
        }
      ],
      "n": "GetDataPoints",
      "d": 966561,
      "h": 8590901153,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590901153)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295933857),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 966561,
      "h": 4295933857,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295933857)
  ],
  "h": 966561
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceReceivedDataModel, $.$XBGm.LCICI.IIOTDeviceStatusModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFCD.IChartableData, $.$fPer.LCFCD.IPeriodicData, $.$fPer.LCFCD.IIdSchemaPacketBuilder$$($.$$.S.UInt16), $.$fPer.LCFCD.IIdSchemaPacketBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceReceivedDataModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(966561)
        
        

        //--TRIMMABLE-BOUNDARY-START(1621921)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceSendDataModelTypeDescriptor`, ($self) => class GasGaugeDeviceSendDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296589217)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296589217);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModelTypeDescriptor.GenerateProperties($.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, this, factory);
                    }, $JBsYmk ??= {"r":65537,"n":"","d":1621921,"h":0,"f":17825794}), 0, "GasGaugeDeviceSendDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GasGauge\\Models_GasGaugeDeviceSendDataModel_LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModelTypeDescriptorBuilder.g.cs", "GasGaugeDeviceSendDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296589217)
            
            //--TRIMMABLE-BOUNDARY-START(12886523809)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886523809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886523809)
            
            //--TRIMMABLE-BOUNDARY-START(17181491105)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181491105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceCommandsModel?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceCommandsModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceCommandsModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181491105)
            
            //--TRIMMABLE-BOUNDARY-START(8591556513)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591556513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel)))
                {
                    /*var*/ let result = $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591556513)
            
            static $h = 1621921;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886523809),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1621921,
      "h": 12886523809,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886523809),
//--TRIMMABLE-BOUNDARY-START(17181491105),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1490849,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1621921,
      "h": 17181491105,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181491105),
//--TRIMMABLE-BOUNDARY-START(8591556513),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1490849,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1621921,
      "h": 8591556513,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591556513)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296589217),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1621921,
      "h": 4296589217,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296589217)
  ],
  "h": 1621921
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceSendDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1621921)
        
        

        //--TRIMMABLE-BOUNDARY-START(1097633)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModelTypeDescriptor`, ($self) => class GasGaugeDeviceReceivedDataModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296064929)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296064929);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModelTypeDescriptor.GenerateProperties($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, this, factory);
                    }, $MvdIRk ??= {"r":65537,"n":"","d":1097633,"h":0,"f":17825794}), 0, "GasGaugeDeviceReceivedDataModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GasGauge\\Models_GasGaugeDeviceReceivedDataModel_LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModelTypeDescriptorBuilder.g.cs", "GasGaugeDeviceReceivedDataModelTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296064929)
            
            //--TRIMMABLE-BOUNDARY-START(12885999521)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885999521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$MmZc.LCIDGMS.GasGaugeStatusModel).GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885999521)
            
            //--TRIMMABLE-BOUNDARY-START(17180966817)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180966817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceReceivedDataModel<LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel>?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceReceivedDataModelTypeDescriptor$$($.$MmZc.LCIDGMS.GasGaugeStatusModel).VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceReceivedDataModel$$($.$MmZc.LCIDGMS.GasGaugeStatusModel)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180966817)
            
            //--TRIMMABLE-BOUNDARY-START(8591032225)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591032225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel)))
                {
                    /*var*/ let result = $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591032225)
            
            static $h = 1097633;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885999521),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1097633,
      "h": 12885999521,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885999521),
//--TRIMMABLE-BOUNDARY-START(17180966817),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 966561,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1097633,
      "h": 17180966817,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180966817),
//--TRIMMABLE-BOUNDARY-START(8591032225),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 966561,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1097633,
      "h": 8591032225,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591032225)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296064929),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1097633,
      "h": 4296064929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296064929)
  ],
  "h": 1097633
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceReceivedDataModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1097633)
        
        

        //--TRIMMABLE-BOUNDARY-START(311201)
        $asm.$cls(`$MmZc.LCIDG.GasGaugeDataConverter`, ($self) => class GasGaugeDataConverter extends $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295278497)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295278497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295278497)
            
            //--TRIMMABLE-BOUNDARY-START(4295278497)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295278497)
            
            static $h = 311201;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICI.BaseDeviceDataConverter$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295278497),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 311201,
      "h": 4295278497,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295278497)
  ],
  "h": 311201
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataConverter, $.$fPer.LCFCD.IDataConverters$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICI.IIOTDeviceDataNormalizer$$($.$XBGm.LCICM.IOTDeviceStatusModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.GasGaugeDataConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}GasGaugeDataConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(311201)
        
        

        $asm.$typeProxy("$MmZc.LCIDGM.GasGaugeServiceModel", "$MmZc.LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModel");
        $asm.$typeProxy("$MmZc.LCIDGM.GasGaugeDeviceScopeModel", "$MmZc.LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModel");
        $asm.$typeProxy("$MmZc.LCIDGS$1.GasGaugeDeviceSettings", "$MmZc.LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings");
        $asm.$typeProxy("$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings", "$MmZc.LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings");
        $asm.$typeProxy("$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler", "$MmZc.LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceStatusHandler");
        $asm.$typeProxy("$MmZc.LCIDGS.IGasGaugeDeviceHubClient", "$MmZc.LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceHubClient");
        $asm.$typeProxy("$MmZc.LCIDGS.IGasGaugeRemoteService", "$MmZc.LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeRemoteService");
        //--TRIMMABLE-BOUNDARY-START(704417)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceModel`, ($self) => class GasGaugeDeviceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $self, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4295671713)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295671713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295671713)
            
            //--TRIMMABLE-BOUNDARY-START(4295671713)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4295671713)
            
            static $h = 704417;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295671713),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 704417,
      "h": 4295671713,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295671713)
  ],
  "h": 704417
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICI.IIOTDeviceModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(704417)
        
        

        //--TRIMMABLE-BOUNDARY-START(2408353)
        $asm.$cls(`$MmZc.LCIDGS.IGasGaugeDeviceHubClient`, ($self) => class IGasGaugeDeviceHubClient
        {
            static $h = 2408353;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2408353
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IIOTDeviceHubClient, $.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$XBGm.LCICH.IIOTDeviceHubClientBase, $.$kVHt.LCFCH.IComponentHubClient, $.$kVHt.LCFCH.IPluginHubClient ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceHubClient`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Services${separator}IGasGaugeDeviceHubClient`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2408353)
        
        

        //--TRIMMABLE-BOUNDARY-START(2473889)
        $asm.$cls(`$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler`, ($self) => class IGasGaugeDeviceStatusHandler
        {
            static $h = 2473889;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2473889
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IIOTDeviceStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel), $.$XBGm.LCICI.IIOTDeviceConnectionStatusHandler, $.$XBGm.LCICI.IIOTDeviceStatusObserver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceStatusHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Services${separator}IGasGaugeDeviceStatusHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2473889)
        
        

        //--TRIMMABLE-BOUNDARY-START(2539425)
        $asm.$cls(`$MmZc.LCIDGS.IGasGaugeRemoteService`, ($self) => class IGasGaugeRemoteService
        {
            static $h = 2539425;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2539425
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IIOTServicesRemoteService, $.$XBGm.LCICS$1.IIOTServicesRemoteService$$$$$$$$$$$$$$($.$XBGm.LCICM.IOTServiceTierType, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel), $.$vWqU.LCFCCR.ISubscriptionBasedRemoteService$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$uvJL.LCFCR.IServiceRemoteService$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType), $.$uvJL.LCFCR.ICRUDDataRemoteService$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$fPer.LCFCD.ICreateDataService$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$fPer.LCFCD.IReadDataService$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$fPer.LCFCD.IReadManyDataService$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$fPer.LCFCD.IReadSingleDataService$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$fPer.LCFCD.IUpdateDataService$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$fPer.LCFCD.IDeleteDataService$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$fPer.LCFC.IRemoteService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeRemoteService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Services${separator}IGasGaugeRemoteService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2539425)
        
        

        //--TRIMMABLE-BOUNDARY-START(1228705)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceScopeModel`, ($self) => class GasGaugeDeviceScopeModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $self, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceScopeModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296196001)
            //default constructor overload
            $ctor$8()
            {
                super.$ctor$8();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296196001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296196001)
            
            //--TRIMMABLE-BOUNDARY-START(4296196001)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$8();
            }
            //--TRIMMABLE-BOUNDARY-END(4296196001)
            
            static $h = 1228705;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceScopeModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296196001),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1228705,
      "h": 4296196001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296196001)
  ],
  "h": 1228705
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFCD.IOneToOneMapping ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceScopeModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1228705)
        
        

        //--TRIMMABLE-BOUNDARY-START(1752993)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeServiceModel`, ($self) => class GasGaugeServiceModel extends $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($self, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTServiceModel
        {
            //--TRIMMABLE-BOUNDARY-START(4296720289)
            //default constructor overload
            $ctor$10()
            {
                super.$ctor$10();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296720289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296720289)
            
            //--TRIMMABLE-BOUNDARY-START(4296720289)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(4296720289)
            
            static $h = 1752993;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTServiceModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296720289),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 1752993,
      "h": 4296720289,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296720289)
  ],
  "h": 1752993
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IDataHasProperties, $.$fPer.LCFCD.IJsonSerializableDataConvert, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCD.IServiceDataModel$$($.$XBGm.LCICM.IOTServiceTierType), $.$XBGm.LCICI.IIOTServiceModel, $.$XBGm.LCICM.IIOTDeviceScopeModel, $.$fPer.LCFCD.IOneToOneMapping, $.$fPer.LCFCD.IServiceDataModel, $.$fPer.LCFCD.IComponentDataModel, $.$fPer.LCFCD.IPluginDataModel, $.$fPer.LCFCD.IPluginData, $.$fPer.LCFCD.ISecurityIdentityDataModel, $.$fPer.LCFCD.IEntityDataModel, $.$fPer.LCFCD.IEntryDataModel, $.$fPer.LCFCD.IDataModel, $.$fPer.LCFCD.IIded, $.$fPer.LCFC.INamed, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeServiceModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1752993)
        
        

        //--TRIMMABLE-BOUNDARY-START(2604961)
        $asm.$cls(`$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings`, ($self) => class GasGaugeDeviceHardwareSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $self, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceHardwareSettings
        {
            //--TRIMMABLE-BOUNDARY-START(12887506849)
            /*IOTDeviceInternalConfiguration<float>*/ Calibration = null;
            //--TRIMMABLE-BOUNDARY-END(12887506849)
            
            //--TRIMMABLE-BOUNDARY-START(8592539553)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592539553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592539553)
            
            //--TRIMMABLE-BOUNDARY-START(8592539553)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8592539553)
            
            static $h = 2604961;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceHardwareSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887506849),
    {
      "p": $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477441441,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30067376033,
        "f": 83886081
      },
      "n": "Calibration",
      "d": 2604961,
      "h": 12887506849,
      "f": 2097153,
      "a": [
        {
          "t": 2197846,
          "c": 12887099734,
          "n": [
            {
              "n": "Key",
              "v": "cal",
              "t": 1310721
            },
            {
              "n": "Order",
              "v": 20,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887506849)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592539553),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2604961,
      "h": 8592539553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592539553)
  ],
  "h": 2604961
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceHardwareSettings, $.$fPer.LCFCD.IKeyedSchemaPacketBuilder, $.$fPer.LCFCD.IPacketBuilder, $.$fPer.LCFCD$1.IDataDescriptorPropertyConstructor, $.$fPer.LCFCD$1.IObservableDataDescriptorProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Settings${separator}GasGaugeDeviceHardwareSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2604961)
        
        

        //--TRIMMABLE-BOUNDARY-START(2867105)
        $asm.$cls(`$MmZc.LCIDGS$1.GasGaugeDeviceSettings`, ($self) => class GasGaugeDeviceSettings extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $self, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceSettings
        {
            //--TRIMMABLE-BOUNDARY-START(17182736289)
            /*double*/ CylinderBaseWeight = 0;
            //--TRIMMABLE-BOUNDARY-END(17182736289)
            
            //--TRIMMABLE-BOUNDARY-START(21477703585)
            /*double*/ CylinderGasWeight = 0;
            //--TRIMMABLE-BOUNDARY-END(21477703585)
            
            //--TRIMMABLE-BOUNDARY-START(12887768993)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$5();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887768993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887768993)
            
            //--TRIMMABLE-BOUNDARY-START(12887768993)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(12887768993)
            
            static $h = 2867105;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceSettings; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17182736289),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067638177,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247507361,
        "f": 83886081
      },
      "n": "CylinderBaseWeight",
      "d": 2867105,
      "h": 17182736289,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182736289),
//--TRIMMABLE-BOUNDARY-START(21477703585),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657572769,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837441953,
        "f": 83886081
      },
      "n": "CylinderGasWeight",
      "d": 2867105,
      "h": 21477703585,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477703585)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887768993),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2867105,
      "h": 12887768993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887768993)
  ],
  "h": 2867105
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD.IComponentSettings, $.$XBGm.LCICI.IIOTDeviceSettings, $.$fPer.LCFCD.ISettings, $.$XBGm.LCICSi.IiSmartDeviceSettings ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Settings${separator}GasGaugeDeviceSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2867105)
        
        

        //--TRIMMABLE-BOUNDARY-START(573345)
        $asm.$cls(`$MmZc.LCIDG.GasGaugeDeviceModelDefinition`, ($self) => class GasGaugeDeviceModelDefinition extends $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService)
        {
            //--TRIMMABLE-BOUNDARY-START(4295540641)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295540641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295540641)
            
            //--TRIMMABLE-BOUNDARY-START(4295540641)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295540641)
            
            static $h = 573345;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295540641),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 573345,
      "h": 4295540641,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295540641)
  ],
  "h": 573345
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.GasGaugeDeviceModelDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}GasGaugeDeviceModelDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(573345)
        
        

        //--TRIMMABLE-BOUNDARY-START(835489)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceModelTypeDescriptor`, ($self) => class GasGaugeDeviceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295802785)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295802785);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MmZc.LCIDGM.GasGaugeDeviceModelTypeDescriptor.GenerateProperties($.$MmZc.LCIDGM.GasGaugeDeviceModel, this, factory);
                    }, $cBRDyc ??= {"r":65537,"n":"","d":835489,"h":0,"f":17825794}), 0, "GasGaugeDeviceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GasGauge\\Models_GasGaugeDeviceModel_LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModelTypeDescriptorBuilder.g.cs", "GasGaugeDeviceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295802785)
            
            //--TRIMMABLE-BOUNDARY-START(12885737377)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885737377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885737377)
            
            //--TRIMMABLE-BOUNDARY-START(17180704673)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180704673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModel, LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings, LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModel, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceStatusHandler, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceHubClient, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeRemoteService>.IOTDeviceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180704673)
            
            //--TRIMMABLE-BOUNDARY-START(8590770081)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590770081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MmZc.LCIDGM.GasGaugeDeviceModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MmZc.LCIDGM.GasGaugeDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceModel)))
                {
                    /*var*/ let result = $.$MmZc.LCIDGM.GasGaugeDeviceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MmZc.LCIDGM.GasGaugeDeviceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8590770081)
            
            static $h = 835489;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885737377),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 835489,
      "h": 12885737377,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885737377),
//--TRIMMABLE-BOUNDARY-START(17180704673),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 704417,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 835489,
      "h": 17180704673,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180704673),
//--TRIMMABLE-BOUNDARY-START(8590770081),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 704417,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 835489,
      "h": 8590770081,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8590770081)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295802785),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 835489,
      "h": 4295802785,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295802785)
  ],
  "h": 835489
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(835489)
        
        

        //--TRIMMABLE-BOUNDARY-START(1884065)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeServiceModelTypeDescriptor`, ($self) => class GasGaugeServiceModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeServiceModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296851361)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296851361);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MmZc.LCIDGM.GasGaugeServiceModelTypeDescriptor.GenerateProperties($.$MmZc.LCIDGM.GasGaugeServiceModel, this, factory);
                    }, $Xqfujc ??= {"r":65537,"n":"","d":1884065,"h":0,"f":17825794}), 0, "GasGaugeServiceModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GasGauge\\Models_GasGaugeServiceModel_LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModelTypeDescriptorBuilder.g.cs", "GasGaugeServiceModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296851361)
            
            //--TRIMMABLE-BOUNDARY-START(12886785953)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886785953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTServiceModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886785953)
            
            //--TRIMMABLE-BOUNDARY-START(17181753249)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181753249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModel, LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings, LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModel, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceStatusHandler, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceHubClient, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeRemoteService>.IOTServiceModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTServiceModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTServiceModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181753249)
            
            //--TRIMMABLE-BOUNDARY-START(8591818657)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591818657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MmZc.LCIDGM.GasGaugeServiceModel().$ctor$10();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MmZc.LCIDGM.GasGaugeServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeServiceModel)))
                {
                    /*var*/ let result = $.$MmZc.LCIDGM.GasGaugeServiceModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeServiceModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MmZc.LCIDGM.GasGaugeServiceModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeServiceModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591818657)
            
            static $h = 1884065;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeServiceModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886785953),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1884065,
      "h": 12886785953,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886785953),
//--TRIMMABLE-BOUNDARY-START(17181753249),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1752993,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1884065,
      "h": 17181753249,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181753249),
//--TRIMMABLE-BOUNDARY-START(8591818657),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1752993,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1884065,
      "h": 8591818657,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591818657)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296851361),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1884065,
      "h": 4296851361,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296851361)
  ],
  "h": 1884065
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeServiceModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1884065)
        
        

        //--TRIMMABLE-BOUNDARY-START(1359777)
        $asm.$cls(`$MmZc.LCIDGM.GasGaugeDeviceScopeModelTypeDescriptor`, ($self) => class GasGaugeDeviceScopeModelTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceScopeModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4296327073)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296327073);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MmZc.LCIDGM.GasGaugeDeviceScopeModelTypeDescriptor.GenerateProperties($.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, this, factory);
                    }, $LYVrok ??= {"r":65537,"n":"","d":1359777,"h":0,"f":17825794}), 0, "GasGaugeDeviceScopeModelTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GasGauge\\Models_GasGaugeDeviceScopeModel_LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModelTypeDescriptorBuilder.g.cs", "GasGaugeDeviceScopeModelTypeDescriptor", 34);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296327073)
            
            //--TRIMMABLE-BOUNDARY-START(12886261665)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886261665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceScopeModelTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12886261665)
            
            //--TRIMMABLE-BOUNDARY-START(17181228961)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModel*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181228961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.IOTDeviceModelDefinition<LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModel, LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings, LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModel, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceStatusHandler, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceHubClient, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeRemoteService>.IOTDeviceScopeModel?*/ let targetBase = _target;
                $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCIC.IOTDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).IOTDeviceScopeModel));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17181228961)
            
            //--TRIMMABLE-BOUNDARY-START(8591294369)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModel?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591294369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel().$ctor$8();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel)))
                {
                    /*var*/ let result = $.$MmZc.LCIDGM.GasGaugeDeviceScopeModelTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591294369)
            
            static $h = 1359777;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceScopeModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886261665),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 1359777,
      "h": 12886261665,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886261665),
//--TRIMMABLE-BOUNDARY-START(17181228961),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1228705,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 1359777,
      "h": 17181228961,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181228961),
//--TRIMMABLE-BOUNDARY-START(8591294369),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 1228705,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 1359777,
      "h": 8591294369,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8591294369)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296327073),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1359777,
      "h": 4296327073,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296327073)
  ],
  "h": 1359777
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MmZc.LCIDGM.GasGaugeDeviceScopeModel), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModelTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Models${separator}GasGaugeDeviceScopeModelTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1359777)
        
        

        //--TRIMMABLE-BOUNDARY-START(2998177)
        $asm.$cls(`$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptor`, ($self) => class GasGaugeDeviceSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGS$1.GasGaugeDeviceSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297965473)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297965473);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptor.GenerateProperties($.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, this, factory);
                    }, $LtDMWe ??= {"r":65537,"n":"","d":2998177,"h":0,"f":17825794}), 0, "GasGaugeDeviceSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GasGauge\\Settings_GasGaugeDeviceSettings_LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettingsTypeDescriptorBuilder.g.cs", "GasGaugeDeviceSettingsTypeDescriptor", 38);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297965473)
            
            //--TRIMMABLE-BOUNDARY-START(12887900065)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887900065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CylinderBaseWeight"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings.$type, $.$discardRef(), "CylinderBaseWeight", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CylinderBaseWeight")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "CylinderBaseWeight";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptor, /*static*/ (/**/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings)).CylinderBaseWeight);
                        }, $omzifg ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2998177,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CylinderBaseWeight = value.AsDouble();
                        }, $QwJnae ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2998177,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("CylinderGasWeight"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings.$type, $.$discardRef(), "CylinderGasWeight", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("CylinderGasWeight")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$$.S.Double, typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t3 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Name = "CylinderGasWeight";
                        $i3.DelaredOn = "LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings";
                        $i3.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromValue$5(($.$cast(target, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings)).CylinderGasWeight);
                        }, $ngLSBh ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2998177,"h":0,"f":17825826});
                        $i3.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.CylinderGasWeight = value.AsDouble();
                        }, $aRWlqh ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2998177,"h":0,"f":17825826});
                        return $i3;
                    })()), schemas, null, factory);
                    let $en4 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en4.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887900065)
            
            //--TRIMMABLE-BOUNDARY-START(17182867361)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182867361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModel, LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings, LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModel, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceStatusHandler, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceHubClient, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeRemoteService>.iSmartDeviceSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceSettings));
                {
                    /*var*/ let _CylinderBaseWeight = _target.CylinderBaseWeight;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CylinderBaseWeight"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _CylinderBaseWeight, ($v) => _CylinderBaseWeight = $v, $.$$.S.Double)))
                    {
                        _target.CylinderBaseWeight = _CylinderBaseWeight;
                    }
                }
                {
                    /*var*/ let _CylinderGasWeight = _target.CylinderGasWeight;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("CylinderGasWeight"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$$.S.Double));
                    if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$VisitPrimitive, $.$$.S.Double, property, $.$ref(() => _CylinderGasWeight, ($v) => _CylinderGasWeight = $v, $.$$.S.Double)))
                    {
                        _target.CylinderGasWeight = _CylinderGasWeight;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182867361)
            
            //--TRIMMABLE-BOUNDARY-START(8592932769)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592932769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings().$ctor$4();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings)))
                {
                    /*var*/ let result = $.$MmZc.LCIDGS$1.GasGaugeDeviceSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592932769)
            
            static $h = 2998177;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGS$1.GasGaugeDeviceSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887900065),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2998177,
      "h": 12887900065,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887900065),
//--TRIMMABLE-BOUNDARY-START(17182867361),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2867105,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2998177,
      "h": 17182867361,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182867361),
//--TRIMMABLE-BOUNDARY-START(8592932769),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2867105,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2998177,
      "h": 8592932769,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592932769)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297965473),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2998177,
      "h": 4297965473,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297965473)
  ],
  "h": 2998177
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MmZc.LCIDGS$1.GasGaugeDeviceSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Settings${separator}GasGaugeDeviceSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2998177)
        
        

        //--TRIMMABLE-BOUNDARY-START(2736033)
        $asm.$cls(`$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsTypeDescriptor`, ($self) => class GasGaugeDeviceHardwareSettingsTypeDescriptor extends $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4297703329)
            $ctor$5(/*LivingThing.Core.Frameworks.Common.Services.ServiceFactory?*/ factory, /*LivingThing.Core.Frameworks.Common.Data.DataType*/ dataType, /*string*/ name)
            {
                super.$ctor$4(dataType, name, $.$sl.SL.Enumerable.Empty($.$fPer.LCFCD$1.IPropertyDescriptor));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297703329);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$fPer.LCFC.Performance.Measure(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsTypeDescriptor.GenerateProperties($.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, this, factory);
                    }, $jHRdHg ??= {"r":65537,"n":"","d":2736033,"h":0,"f":17825794}), 0, "GasGaugeDeviceHardwareSettingsTypeDescriptor.ctor", "C:\\Users\\User\\AppData\\Local\\Temp\\NetJs\\NetJs.LivingThing.Core.IOT.Devices.GasGauge\\Settings_GasGaugeDeviceHardwareSettings_LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettingsTypeDescriptorBuilder.g.cs", "GasGaugeDeviceHardwareSettingsTypeDescriptor", 39);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297703329)
            
            //--TRIMMABLE-BOUNDARY-START(12887637921)
            static /*void */ GenerateProperties(TTarget, /*SystemTypeDescriptor<TTarget>*/ typeDescriptor, /*ServiceFactory?*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887637921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!typeDescriptor.Properties.SCG$IReadOnlyDictionary$$$$ContainsKey("Calibration"))
                {
                    /*var*/ let schemas = $.$fPer.LCFCF.FastAttributeRegistry.GetCustomAttributesFast$5($.$fPer.LCFCA$1.SchemaAttribute, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings.$type, $.$discardRef(), "Calibration", false, true) ?? $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$fPer.LCFCA$1.SchemaAttribute), [$.$fPer.LCFCA$1.SchemaAttribute.GetPropertyDefault$1("Calibration")], null, null);
                    /*var*/ let descriptors = $.$fPer.LCFCD$1.DataDescriptorUtility.From($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single), typeDescriptor, $.$fPer.LCFCO.OneOf$$$($.$$.SR.PropertyInfo, $.$fPer.LCFCD.PropertyAccessor).op_Implicit$1((() =>
                    {
                        //new $.$fPer.LCFCD.PropertyAccessor()
                        const $t1 = $.$fPer.LCFCD.PropertyAccessor;
                        const $i1 = new $t1();
                        $i1.$ctor$2();
                        $i1.Name = "Calibration";
                        $i1.DelaredOn = "LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings";
                        $i1.Get = new ($.$$.S.Func$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target) =>
                        {
                            return $.$fPer.LCFCD.DataValue.FromReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single), ($.$cast(target, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings)).Calibration);
                        }, $wiNFWc ??= {"r":11503958,"p":[{"n":"target","p":131073}],"n":"","d":2736033,"h":0,"f":17825826});
                        $i1.Set = new ($.$$.S.Action$$$($.$$.S.Object, $.$fPer.LCFCD.DataValue))().$ctor($.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsTypeDescriptor, /*static*/ (/*target*/ target, /*value*/ value) =>
                        {
                            return target.Calibration = value.AsReference($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single));
                        }, $vyTdxk ??= {"r":65537,"p":[{"n":"target","p":131073},{"n":"value","p":11503958}],"n":"","d":2736033,"h":0,"f":17825826});
                        return $i1;
                    })()), schemas, null, factory);
                    let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let desc = $en2.SCG$IEnumerator$$$Current;
                        {
                            typeDescriptor.AddProperty(desc);
                        }
                    }
                }
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.GenerateProperties(TTarget, typeDescriptor, factory);
            }
            //--TRIMMABLE-BOUNDARY-END(12887637921)
            
            //--TRIMMABLE-BOUNDARY-START(17182605217)
            static /*bool */ VisitProperties(TVisitor, /*ITypeDescriptor*/ typeDescriptor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182605217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v;
                /*LivingThing.Core.IOT.Common.Devices.iSmart.iSmartDeviceModelDefinition<LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeServiceModel, LivingThing.Core.IOT.Common.Models.IOTServiceTierType, LivingThing.Core.IOT.Common.Models.IOTServiceFeatureType, LivingThing.Core.IOT.Common.Settings.IOTServiceSettings, LivingThing.Core.IOT.Common.States.IOTServiceStates, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceScopeModel, LivingThing.Core.IOT.Common.Settings.IOTDeviceScopeSettings, LivingThing.Core.IOT.Common.States.IOTDeviceScopeStates, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceModel, LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceSettings, LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings, LivingThing.Core.IOT.Common.States.IOTDeviceStates, LivingThing.Core.IOT.Common.Models.IOTDeviceStatusModel, LivingThing.Core.IOT.Common.Models.IOTDeviceCommandModel, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel, LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceSendDataModel, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceStatusHandler, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeDeviceHubClient, LivingThing.Core.IOT.Devices.GasGauge.Services.IGasGaugeRemoteService>.iSmartDeviceHardwareSettings?*/ let targetBase = _target;
                $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, typeDescriptor, visitor, $.$ref(() => targetBase, ($v) => targetBase = $v, $.$XBGm.LCICDi.iSmartDeviceModelDefinition$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService).iSmartDeviceHardwareSettings));
                {
                    /*var*/ let _Calibration = _target.Calibration;
                    /*var*/ let property = $.$cast(typeDescriptor.LCFCD$1$ITypeDescriptor$Properties.SCG$IReadOnlyDictionary$$$$get_Item("Calibration"), $.$fPer.LCFCD$1.ISystemPropertyDescriptor$$($.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single)));
                    if (property.LCFCD$1$ISystemPropertyDescriptor$$$ValueType.LCFCD$1$ITypeDescriptor$$$AcceptVisitor(TVisitor, visitor, $.$ref(() => _Calibration, ($v) => _Calibration = $v, $.$XBGm.LCICS$2.IOTDeviceInternalConfiguration$$($.$$.S.Single))))
                    {
                        _target.Calibration = _Calibration;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17182605217)
            
            //--TRIMMABLE-BOUNDARY-START(8592670625)
            /*bool */ AcceptVisitor$1(TVisitor, /*ref TVisitor*/ visitor, /*ref LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettings?*/ target)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592670625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let _target = target.$v ?? new $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings().$ctor$3();
                if ($.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$BeginVisitObject, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings)))
                {
                    /*var*/ let result = $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettingsTypeDescriptor.VisitProperties(TVisitor, this, visitor, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings));
                    $.$dsp(visitor.$v, TVisitor, ($t) => $t.LCFC$IVisitor$LivingThing$Core$Frameworks$Common$DataDescriptor$ISystemPropertyDescriptor$EndVisitObject, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, null, $.$ref(() => _target, ($v) => _target = $v, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings));
                    return result;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8592670625)
            
            static $h = 2736033;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$fPer.LCFCD$1.SystemTypeDescriptor$$($.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887637921),
    {
      "r": 65537,
      "p": [
        {
          "n": "typeDescriptor",
          "p": (TTarget) => $.$fPer.LCFCD$1.SystemTypeDescriptor$$(TTarget).$h
        },
        {
          "n": "factory",
          "p": 62949718
        }
      ],
      "g": [
        "TTarget"
      ],
      "n": "GenerateProperties",
      "d": 2736033,
      "h": 12887637921,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12887637921),
//--TRIMMABLE-BOUNDARY-START(17182605217),
    {
      "r": 262145,
      "p": [
        {
          "n": "typeDescriptor",
          "p": 41453910
        },
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2604961,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "VisitProperties",
      "d": 2736033,
      "h": 17182605217,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17182605217),
//--TRIMMABLE-BOUNDARY-START(8592670625),
    {
      "r": 262145,
      "p": [
        {
          "n": "visitor",
          "p": (TVisitor) => TVisitor.$h,
          "f": 4
        },
        {
          "n": "target",
          "p": 2604961,
          "f": 4
        }
      ],
      "g": [
        "TVisitor"
      ],
      "n": "AcceptVisitor",
      "o": "@$1",
      "d": 2736033,
      "h": 8592670625,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(8592670625)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297703329),
    {
      "p": [
        {
          "n": "factory",
          "p": 62949718
        },
        {
          "n": "dataType",
          "p": 11241814
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2736033,
      "h": 4297703329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297703329)
  ],
  "h": 2736033
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$fPer.LCFCD$1.ISystemTypeDescriptor, $.$fPer.LCFCD$1.ITypeDescriptor$$($.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings), $.$fPer.LCFCD$1.ITypeDescriptor ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Settings.GasGaugeDeviceHardwareSettingsTypeDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Settings${separator}GasGaugeDeviceHardwareSettingsTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2736033)
        
        

        //--TRIMMABLE-BOUNDARY-START(376737)
        $asm.$cls(`$MmZc.LCIDG.GasGaugeDevice`, ($self) => class GasGaugeDevice extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($self, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$MmZc.LCIDGMS.GasGaugeStatusModel).iSmartGenericDevice
        {
            //--TRIMMABLE-BOUNDARY-START(4295344033)
            $ctor$2(/*IIOTDeviceFamily<GasGaugeDevice>*/ family, /*IIOTDeviceScope*/ ownerScope, /*GasGaugeDeviceModel*/ model)
            {
                super.$ctor$3(family, ownerScope, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295344033);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295344033)
            
            static $h = 376737;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$MmZc.LCIDGMS.GasGaugeStatusModel).iSmartGenericDevice; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295344033),
    {
      "p": [
        {
          "n": "family",
          "p": $.$XBGm.LCICI.IIOTDeviceFamily$$($.$MmZc.LCIDG.GasGaugeDevice).$h
        },
        {
          "n": "ownerScope",
          "p": 28546449
        },
        {
          "n": "model",
          "p": 704417
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 376737,
      "h": 4295344033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295344033)
  ],
  "h": 376737
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICO.IUpdatableDevice, $.$XBGm.LCICI.IIOTDeviceConfigurationProvider, $.$XBGm.LCICDi.IiSmartWIFIIOTDevice, $.$XBGm.LCICDi.IiSmartIOTDevice, $.$XBGm.LCICI.IIOTDevice, $.$fPer.LCFCD.IPlugin, $.$XBGm.LCICI.IIOTAutomate, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.GasGaugeDevice`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}GasGaugeDevice`; }
        });
        //--TRIMMABLE-BOUNDARY-END(376737)
        
        

        //--TRIMMABLE-BOUNDARY-START(442273)
        $asm.$cls(`$MmZc.LCIDG.GasGaugeDeviceDefinition`, ($self) => class GasGaugeDeviceDefinition extends $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$MmZc.LCIDGMS.GasGaugeStatusModel)
        {
            //--TRIMMABLE-BOUNDARY-START(4295409569)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295409569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295409569)
            
            //--TRIMMABLE-BOUNDARY-START(4295409569)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295409569)
            
            static $h = 442273;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.iSmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings, $.$MmZc.LCIDGMS.GasGaugeStatusModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295409569),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 442273,
      "h": 4295409569,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295409569)
  ],
  "h": 442273
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.GasGaugeDeviceDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}GasGaugeDeviceDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(442273)
        
        

        //--TRIMMABLE-BOUNDARY-START(507809)
        $asm.$cls(`$MmZc.LCIDG.GasGaugeDeviceFamily`, ($self) => class GasGaugeDeviceFamily extends $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily
        {
            //--TRIMMABLE-BOUNDARY-START(4295475105)
            $ctor$1(/*IConfigurationParser*/ config, /*IOTDeviceProtocol<GasGaugeDeviceReceivedDataModel, GasGaugeDeviceSendDataModel>*/ protocol, /*IIOTDeviceDataConverter<GasGaugeDeviceReceivedDataModel, IOTDeviceStatusModel>*/ converter)
            {
                super.$ctor$1(config, protocol, converter);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295475105);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295475105)
            
            static $h = 507809;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$NXre.LCID.SmartGenericDeviceDefinition$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).ConfiguredDeviceFamily; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295475105),
    {
      "p": [
        {
          "n": "config",
          "p": 4950358
        },
        {
          "n": "protocol",
          "p": $.$XBGm.LCIP.IOTDeviceProtocol$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel).$h
        },
        {
          "n": "converter",
          "p": $.$XBGm.LCICI.IIOTDeviceDataConverter$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 507809,
      "h": 4295475105,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295475105)
  ],
  "h": 507809
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$XBGm.LCICI.IIOTDeviceFamily$$($.$MmZc.LCIDG.GasGaugeDevice), $.$XBGm.LCICI.IIOTDeviceFamily, $.$AvdQ.LCFCP.ICatalogueProvider$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider$$$($.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$AvdQ.LCFCP.ICatalogueProvider, $.$nYKj.LCFCP.IPaymentTierProvider, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$fPer.LCFC.INamed ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.GasGaugeDeviceFamily`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}GasGaugeDeviceFamily`; }
        });
        //--TRIMMABLE-BOUNDARY-END(507809)
        
        

        //--TRIMMABLE-BOUNDARY-START(3653537)
        $asm.$cls(`$MmZc.LCIDGV$1.GasGaugeViewRenderer`, ($self) => class GasGaugeViewRenderer extends $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$$$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel))
        {
            //--TRIMMABLE-BOUNDARY-START(4298620833)
            $ctor$2(/*IOTRootViewModel*/ root)
            {
                super.$ctor$1(root);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298620833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298620833)
            
            //--TRIMMABLE-BOUNDARY-START(8593588129)
            /*RenderFragment */ GetView(/*IClientUnitOfWork*/ ui, /*GasGaugeDevice*/ device, /*DeviceViewType*/ type, /*Func<int, Task>*/ clicked, /*Func<Task>*/ pressed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593588129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === 3/*DeviceViewType.Details*/)
                {
                    return $.$hDPm.LCFC.FragmentView.From$3($.$MmZc.LCIDGV$1.GasGaugeDeviceDetails, $.$MmZc.LCIDGV$1.GasGaugeDetailsViewModel, new $.$MmZc.LCIDGV$1.GasGaugeDetailsViewModel().$ctor$8(this.Root, device.OwnerScope, device), true, null);
                }
                return super.GetView(ui, device, type, clicked, pressed);
            }
            //--TRIMMABLE-BOUNDARY-END(8593588129)
            
            static $h = 3653537;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICD$1.DeviceViewRenderer$$$$$$$$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593588129),
    {
      "r": 6881395,
      "p": [
        {
          "n": "ui",
          "p": 63657642
        },
        {
          "n": "device",
          "p": 376737
        },
        {
          "n": "type",
          "p": 9143318
        },
        {
          "n": "clicked",
          "p": $.$$.S.Func$$$($.$$.S.Int32, $.$$.STT.Task).$h,
          "f": 65
        },
        {
          "n": "pressed",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h,
          "f": 65
        }
      ],
      "n": "GetView",
      "d": 3653537,
      "h": 8593588129,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593588129)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298620833),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3653537,
      "h": 4298620833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298620833)
  ],
  "h": 3653537
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$ntej.LCICD$1.IDeviceViewRenderer$$($.$MmZc.LCIDG.GasGaugeDevice), $.$ntej.LCICD$1.IDeviceViewRenderer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Views.GasGaugeViewRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Views${separator}GasGaugeViewRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3653537)
        
        

        //--TRIMMABLE-BOUNDARY-START(3522465)
        $asm.$cls(`$MmZc.LCIDGV$1.GasGaugeDetailsViewModel`, ($self) => class GasGaugeDetailsViewModel extends $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$$$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel))
        {
            //--TRIMMABLE-BOUNDARY-START(4298489761)
            $ctor$8(/*IOTRootViewModel*/ root, /*IIOTDeviceScope*/ scope, /*GasGaugeDevice*/ device)
            {
                super.$ctor$7(root, scope, device);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298489761);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298489761)
            
            static $h = 3522465;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICDV.IOTDeviceDetailsViewModel$$$$$$$$$$$($.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$XBGm.LCICI.IIOTDeviceStatusHandler$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel)); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298489761),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "scope",
          "p": 28546449
        },
        {
          "n": "device",
          "p": 376737
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 3522465,
      "h": 4298489761,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298489761)
  ],
  "h": 3522465
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICDV.IDeviceDetailsViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Views.GasGaugeDetailsViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Views${separator}GasGaugeDetailsViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3522465)
        
        

        //--TRIMMABLE-BOUNDARY-START(3588001)
        $asm.$cls(`$MmZc.LCIDGV$1.GasGaugeDeviceDetails`, ($self) => class GasGaugeDeviceDetails extends $.$hDPm.LCFCC$1.BaseComponent$$($.$MmZc.LCIDGV$1.GasGaugeDetailsViewModel)
        {
            //--TRIMMABLE-BOUNDARY-START(51543195553)
            /*GasGaugeDetailsViewModel*/ ViewModel = null;
            //--TRIMMABLE-BOUNDARY-END(51543195553)
            
            //--TRIMMABLE-BOUNDARY-START(34363326369)
            /*string */ get OptimizedComponentName()
            {
                return "gasgaugedevicedetails";
            }
            //--TRIMMABLE-BOUNDARY-END(34363326369)
            
            //--TRIMMABLE-BOUNDARY-START(47248228257)
            /*bool */ TrySetParameter(/*ParameterValue*/ parameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248228257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = parameter.Name;
                switch($switch1)
                {
                    case "ViewModel":
                    this.ViewModel = $.$cast(parameter.Value, $.$MmZc.LCIDGV$1.GasGaugeDetailsViewModel);
                    return true;
                }
                return super.TrySetParameter(parameter);
            }
            //--TRIMMABLE-BOUNDARY-END(47248228257)
            
            //--TRIMMABLE-BOUNDARY-START(12888489889)
            /*void */ BuildRenderTree(/*global::Microsoft.AspNetCore.Components.Rendering.RenderTreeBuilder*/ __builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888489889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                __builder.OpenComponent$1($.$ntej.LCICD$1.DeviceDetailsWrapper$$($.$MmZc.LCIDG.GasGaugeDevice), 0);
                __builder.AddComponentParameter(1, "ViewModel", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICV.DeviceViewModel$$($.$MmZc.LCIDG.GasGaugeDevice), this.ViewModel));
                __builder.AddComponentParameter(2, "Features", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$ntej.LCICD$1.DeviceDetailsFeatures, 479/*DeviceDetailsFeatures.Default*/ & ~256/*DeviceDetailsFeatures.IO*/), $.$ntej.LCICD$1.DeviceDetailsFeatures));
                __builder.AddAttribute$3(3, "ChildContent", new $.$mac.MAC.RenderFragment().$ctor(this, ( (/*__builder2*/ __builder2) =>
                {
                    /*var*/ let weight = (this.ViewModel.Device$1.Received?.Status?.Weight ?? null);
                    if (weight !== null)
                    {
                        weight = $.$$.S.Math.Abs$1($.$$.S.Nullable$$($.$$.S.Double).Value$get.call(weight));
                    }
                    /*var*/ let gasweight = weight - this.ViewModel.Device$1.Settings$1.CylinderBaseWeight;
                    if (gasweight !== null && gasweight < 0)
                    {
                        gasweight = 0;
                    }
                    __builder2.OpenElement(4, "div");
                    __builder2.AddAttribute$5(5, "class", "grid colm-15 gap-1 mgt");
                    __builder2.OpenElement(6, "div");
                    __builder2.AddAttribute$5(7, "class", "text-center pd bg-card");
                    __builder2.AddMarkupContent(8, "<span>Gas Left</span>\r\n            ");
                    __builder2.OpenElement(9, "h1");
                    __builder2.AddAttribute$5(10, "class", "cl-success");
                    /*double?*/ let __ca1__;
                    __builder2.AddContent$4(11, $.$strNN(((__ca1__ = gasweight) !== null ? $.$$.S.Double.ToString$3.call($.$$.S.Nullable$$($.$$.S.Double).Value$get.call(__ca1__), "#0.0") : null)) + "kg");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(12, "\r\n        ");
                    __builder2.OpenElement(13, "div");
                    __builder2.AddAttribute$5(14, "class", "text-center pd bg-card");
                    __builder2.AddMarkupContent(15, "<span>Leakage</span>\r\n            ");
                    __builder2.OpenElement(16, "h1");
                    __builder2.AddAttribute$5(17, "class", "cl-success");
                    __builder2.AddContent$4(18, (this.ViewModel.Device$1.Received?.Status?.Gas ?? null) === 0 ? "YES" : "NO");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(19, "\r\n        ");
                    __builder2.OpenElement(20, "div");
                    __builder2.AddAttribute$5(21, "class", "text-center pd bg-card");
                    __builder2.AddMarkupContent(22, "<span>Temperature</span>\r\n            ");
                    __builder2.OpenElement(23, "h1");
                    __builder2.AddAttribute$5(24, "class", "cl-success");
                    /*LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel?*/ let __ca2__;
                    /*LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel?*/ let __ca3__;
                    __builder2.AddContent$4(25, $.$strNN(((__ca2__ = this.ViewModel.Device$1.Received) !== null ? ((__ca3__ = __ca2__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca3__.Temperature, "#0.0") : null) : null)) + "\u00B0C");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.AddMarkupContent(26, "\r\n        ");
                    __builder2.OpenElement(27, "div");
                    __builder2.AddAttribute$5(28, "class", "text-center pd bg-card");
                    __builder2.AddMarkupContent(29, "<span>Humidity</span>\r\n            ");
                    __builder2.OpenElement(30, "h1");
                    __builder2.AddAttribute$5(31, "class", "cl-success");
                    /*LivingThing.Core.IOT.Devices.GasGauge.Models.GasGaugeDeviceReceivedDataModel?*/ let __ca4__;
                    /*LivingThing.Core.IOT.Devices.GasGauge.Models.Statuses.GasGaugeStatusModel?*/ let __ca5__;
                    __builder2.AddContent$4(32, $.$strNN(((__ca4__ = this.ViewModel.Device$1.Received) !== null ? ((__ca5__ = __ca4__.Status) !== null ? $.$$.S.Double.ToString$3.call(__ca5__.Humidity, "#0.0") : null) : null)) + "%");
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    __builder2.CloseElement();
                    if (gasweight !== null && this.ViewModel.Device$1.Settings$1.CylinderGasWeight > 0)
                    {
                        __builder2.OpenElement(33, "div");
                        __builder2.AddAttribute$5(34, "class", "mgt-10");
                        __builder2.OpenComponent$1($.$hDPm.LCFCCG.TankContainer, 35);
                        __builder2.AddComponentParameter(36, "Height", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Double, 200), $.$$.S.Double));
                        __builder2.AddComponentParameter(37, "Shape", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$fPer.LCFCDM.TankShapeTypes, 1/*Frameworks.Common.Data.Measurements.TankShapeTypes.VerticalCylinder*/), $.$fPer.LCFCDM.TankShapeTypes));
                        __builder2.AddComponentParameter(38, "ContentsHeight", $.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.SCG.IEnumerable$$($.$$.S.Double), $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.Double.$type, [ $.$$.S.Nullable$$($.$$.S.Double).Value$get.call(gasweight) / this.ViewModel.Device$1.Settings$1.CylinderGasWeight ], null, null)));
                        __builder2.AddComponentParameter(39, "UseCanvas", $.$box($.$mac.MACC.RuntimeHelpers.TypeCheck($.$$.S.Boolean, true), $.$$.S.Boolean));
                        __builder2.CloseComponent();
                        __builder2.CloseElement();
                    }
                }), $TMCEHc ??= {"r":65537,"p":[{"n":"__builder2","p":7536755}],"n":"","d":3588001,"h":0,"f":17825794}));
                __builder.CloseComponent();
            }
            //--TRIMMABLE-BOUNDARY-END(12888489889)
            
            //--TRIMMABLE-BOUNDARY-START(8650970794)
            //Generated interface implemetation for LivingThing.Core.Frameworks.Client.Generator.IOptimizedComponent.OptimizedComponentName.get
            get LCFCG$IOptimizedComponent$OptimizedComponentName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945938090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OptimizedComponentName;
            }
            //--TRIMMABLE-BOUNDARY-END(8650970794)
            
            //--TRIMMABLE-BOUNDARY-START(8593522593)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$3();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593522593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593522593)
            
            //--TRIMMABLE-BOUNDARY-START(8593522593)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8593522593)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51543195553)
                this.ViewModel = null;
                //--TRIMMABLE-BOUNDARY-END(51543195553)
                
            }
            static $h = 3588001;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$hDPm.LCFCC$1.BaseComponent$$($.$MmZc.LCIDGV$1.GasGaugeDetailsViewModel); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51543195553),
    {
      "p": 3522465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068359073,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42953260961,
        "f": 83918849
      },
      "n": "ViewModel",
      "d": 3588001,
      "h": 51543195553,
      "f": 2129921,
      "a": [
        {
          "t": 5636211,
          "c": 8595570803
        },
        {
          "t": 1835123,
          "c": 4296802419
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51543195553),
//--TRIMMABLE-BOUNDARY-START(34363326369),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21478424481,
        "f": 50364417
      },
      "n": "OptimizedComponentName",
      "d": 3588001,
      "h": 34363326369,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34363326369)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47248228257),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 5701747
        }
      ],
      "n": "TrySetParameter",
      "d": 3588001,
      "h": 47248228257,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47248228257),
//--TRIMMABLE-BOUNDARY-START(12888489889),
    {
      "r": 65537,
      "p": [
        {
          "n": "__builder",
          "p": 7536755
        }
      ],
      "n": "BuildRenderTree",
      "d": 3588001,
      "h": 12888489889,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888489889)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593522593),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3588001,
      "h": 8593522593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593522593)
  ],
  "h": 3588001
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IComponent, $.$hDPm.LCFCC$1.IBaseComponent, $.$mac.MAC.IHandleEvent, $.$mac.MAC.IHandleAfterRender, $.$fPer.LCFCD.IWorkspaceContainer, $.$hDPm.LCFCG.IComponentHasAttributes, $.$hDPm.LCFCG.IComponentHasWorkSpace, $.$$.S.IDisposable, $.$hDPm.LCFCG.IComponentHasServiceProvider, $.$hDPm.LCFCG.IOptimizedComponent ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.Views.GasGaugeDeviceDetails`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}Views${separator}GasGaugeDeviceDetails`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3588001)
        
        

        $asm.$typeProxy("$MmZc.LCIDGV.GasGaugeClientAppViewModel", "$MmZc.LivingThing.Core.IOT.Devices.GasGauge.ViewModels.GasGaugeClientAppViewModel");
        $asm.$typeProxy("$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel", "$MmZc.LivingThing.Core.IOT.Devices.GasGauge.ViewModels.GasGaugeClientAppServiceViewModel");
        $asm.$typeProxy("$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel", "$MmZc.LivingThing.Core.IOT.Devices.GasGauge.ViewModels.GasGaugeClientAppDeviceViewModel");
        //--TRIMMABLE-BOUNDARY-START(3260321)
        $asm.$cls(`$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel`, ($self) => class GasGaugeClientAppDeviceScopeViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGV.GasGaugeClientAppViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel, $self, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel, $.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298227617)
            $ctor$3(/*GasGaugeClientAppServiceViewModel*/ service, /*GasGaugeDeviceScopeModel*/ model, /*IEnumerable<GasGaugeClientAppDeviceViewModel>*/ devices)
            {
                super.$ctor$3(service, model, devices);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298227617);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298227617)
            
            static $h = 3260321;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGV.GasGaugeClientAppViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel, $.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceScopeViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298227617),
    {
      "p": [
        {
          "n": "service",
          "p": 3391393
        },
        {
          "n": "model",
          "p": 1228705
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3260321,
      "h": 4298227617,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298227617)
  ],
  "h": 3260321
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$vWqU.LCFCC.IViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTDeviceScopeViewModel$$$($.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.ViewModels.GasGaugeClientAppDeviceScopeViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}ViewModels${separator}GasGaugeClientAppDeviceScopeViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3260321)
        
        

        //--TRIMMABLE-BOUNDARY-START(3391393)
        $asm.$cls(`$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel`, ($self) => class GasGaugeClientAppServiceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGV.GasGaugeClientAppViewModel, $self, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel, $.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298358689)
            $ctor$3(/*GasGaugeClientAppViewModel*/ app, /*GasGaugeServiceModel*/ model)
            {
                super.$ctor$3(app, model);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298358689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298358689)
            
            //--TRIMMABLE-BOUNDARY-START(12888293281)
            /*GasGaugeClientAppDeviceViewModel */ GetDeviceViewModel(/*GasGaugeDeviceModel*/ model, /*IEnumerable<GasGaugeClientAppDeviceScopeViewModel>*/ scopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888293281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel().$ctor$7(this, model, scopes);
            }
            //--TRIMMABLE-BOUNDARY-END(12888293281)
            
            //--TRIMMABLE-BOUNDARY-START(8593325985)
            /*GasGaugeClientAppDeviceScopeViewModel */ GetDeviceScopeViewModel(/*GasGaugeDeviceScopeModel*/ model, /*IEnumerable<GasGaugeClientAppDeviceViewModel>*/ devices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593325985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel().$ctor$3(this, model, devices);
            }
            //--TRIMMABLE-BOUNDARY-END(8593325985)
            
            static $h = 3391393;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGV.GasGaugeClientAppViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel, $.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppServiceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888293281),
    {
      "r": 3325857,
      "p": [
        {
          "n": "model",
          "p": 704417
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": "GetDeviceViewModel",
      "d": 3391393,
      "h": 12888293281,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12888293281),
//--TRIMMABLE-BOUNDARY-START(8593325985),
    {
      "r": 3260321,
      "p": [
        {
          "n": "model",
          "p": 1228705
        },
        {
          "n": "devices",
          "p": $.$$.SCG.IEnumerable$$($.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel).$h
        }
      ],
      "n": "GetDeviceScopeViewModel",
      "d": 3391393,
      "h": 8593325985,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8593325985)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298358689),
    {
      "p": [
        {
          "n": "app",
          "p": 3456929
        },
        {
          "n": "model",
          "p": 1752993
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3391393,
      "h": 4298358689,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298358689)
  ],
  "h": 3391393
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$ntej.LCICV.IIOTApplicationServiceViewModel$$$$$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTApplicationServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.ViewModels.GasGaugeClientAppServiceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}ViewModels${separator}GasGaugeClientAppServiceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3391393)
        
        

        //--TRIMMABLE-BOUNDARY-START(3325857)
        $asm.$cls(`$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel`, ($self) => class GasGaugeClientAppDeviceViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGV.GasGaugeClientAppViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel, $self, $.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298293153)
            $ctor$7(/*GasGaugeClientAppServiceViewModel*/ service, /*GasGaugeDeviceModel*/ model, /*IEnumerable<GasGaugeClientAppDeviceScopeViewModel>*/ scopes)
            {
                super.$ctor$7(service, model, scopes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298293153);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298293153)
            
            static $h = 3325857;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGV.GasGaugeClientAppViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel, $.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppDeviceViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298293153),
    {
      "p": [
        {
          "n": "service",
          "p": 3391393
        },
        {
          "n": "model",
          "p": 704417
        },
        {
          "n": "scopes",
          "p": $.$$.SCG.IEnumerable$$($.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 3325857,
      "h": 4298293153,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298293153)
  ],
  "h": 3325857
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$vWqU.LCFCC.ILoadableViewModel, $.$$.S.IDisposable, $.$vWqU.LCFCC.IAwaitablePageViewModel$$($.$$.S.Object), $.$fPer.LCFCD.IChartable, $.$ntej.LCICV.IIOTDeviceViewModel$$$$($.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel), $.$ntej.LCICV.IIOTDeviceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$so.SC$1.INotifyPropertyChanged ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.ViewModels.GasGaugeClientAppDeviceViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}ViewModels${separator}GasGaugeClientAppDeviceViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3325857)
        
        

        //--TRIMMABLE-BOUNDARY-START(3456929)
        $asm.$cls(`$MmZc.LCIDGV.GasGaugeClientAppViewModel`, ($self) => class GasGaugeClientAppViewModel extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($self, $.$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel, $.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel
        {
            //--TRIMMABLE-BOUNDARY-START(4298424225)
            $ctor$5(/*IOTRootViewModel*/ root, /*GasGaugeDeviceFamily*/ family, /*IHubConnector<IIOTDeviceHubClientBase<GasGaugeDeviceReceivedDataModel, IOTDeviceStatusModel>>*/ hubConnector)
            {
                super.$ctor$5(root, family, $.$$.N.InterfaceVarianceStubHandler.Create(hubConnector, $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)), $.$kVHt.LCFCH.IHubConnector$$($.$MmZc.LCIDGS.IGasGaugeDeviceHubClient)));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298424225);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298424225)
            
            //--TRIMMABLE-BOUNDARY-START(8593391521)
            /*bool */ get Authorize()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8593391521)
            
            //--TRIMMABLE-BOUNDARY-START(21478293409)
            /*GasGaugeClientAppServiceViewModel */ GetServiceViewModel(/*GasGaugeServiceModel*/ model)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478293409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel().$ctor$3(this, model);
            }
            //--TRIMMABLE-BOUNDARY-END(21478293409)
            
            static $h = 3456929;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGV.GasGaugeClientAppViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel, $.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings).IOTClientAppViewModel; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8593391521),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183326113,
        "f": 50364417
      },
      "n": "Authorize",
      "d": 3456929,
      "h": 8593391521,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8593391521)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478293409),
    {
      "r": 3391393,
      "p": [
        {
          "n": "model",
          "p": 1752993
        }
      ],
      "n": "GetServiceViewModel",
      "d": 3456929,
      "h": 21478293409,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21478293409)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298424225),
    {
      "p": [
        {
          "n": "root",
          "p": 18711574
        },
        {
          "n": "family",
          "p": 507809
        },
        {
          "n": "hubConnector",
          "p": $.$kVHt.LCFCH.IHubConnector$$($.$XBGm.LCICH.IIOTDeviceHubClientBase$$$($.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$XBGm.LCICM.IOTDeviceStatusModel)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3456929,
      "h": 4298424225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298424225)
  ],
  "h": 3456929
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$ntej.LCICV.IIOTAppViewModel$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$ntej.LCICV.IIOTApplicationViewModel, $.$vWqU.LCFCC.IServiceViewModel$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$vWqU.LCFCC.IServiceViewModel, $.$hDPm.LCFCC$1.IComponentViewModel, $.$vWqU.LCFCC.IViewModel, $.$fPer.LCFCC.INotifyOnPropertyChanged, $.$yleQ.LCFCA.IApplicationService, $.$dgLE.LCPCSG.IServiceGuardViewModel$$$$($.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType), $.$vWqU.LCFCC.IServiceSubscriptionViewModel$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$vWqU.LCFCC.IServiceSubscriptionViewModel, $.$vWqU.LCFCC.ILoadableViewModel, $.$so.SC$1.INotifyPropertyChanged, $.$fPer.LCFC.IDisplayable, $.$fPer.LCFC.IDescribable, $.$vWqU.LCFCC.IClientRootService$$($.$MmZc.LCIDGM.GasGaugeServiceModel), $.$vWqU.LCFCC.IClientRootService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.ViewModels.GasGaugeClientAppViewModel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}ViewModels${separator}GasGaugeClientAppViewModel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3456929)
        
        

        //--TRIMMABLE-BOUNDARY-START(3194785)
        $asm.$cls(`$MmZc.LCIDGV.GasGaugeClientAppDefinition`, ($self) => class GasGaugeClientAppDefinition extends $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGV.GasGaugeClientAppViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel, $.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings)
        {
            //--TRIMMABLE-BOUNDARY-START(4298162081)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298162081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298162081)
            
            //--TRIMMABLE-BOUNDARY-START(4298162081)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4298162081)
            
            static $h = 3194785;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$ntej.LCICV.IOTClientAppDefinition$$$$$$$$$$$$$$$$$$$$$$$$$$($.$MmZc.LCIDGV.GasGaugeClientAppViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppServiceViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceScopeViewModel, $.$MmZc.LCIDGV.GasGaugeClientAppDeviceViewModel, $.$MmZc.LCIDG.GasGaugeDevice, $.$MmZc.LCIDGM.GasGaugeServiceModel, $.$XBGm.LCICM.IOTServiceTierType, $.$XBGm.LCICM.IOTServiceFeatureType, $.$XBGm.LCICS$2.IOTServiceSettings, $.$XBGm.LCICS$3.IOTServiceStates, $.$MmZc.LCIDGM.GasGaugeDeviceScopeModel, $.$XBGm.LCICS$2.IOTDeviceScopeSettings, $.$XBGm.LCICS$3.IOTDeviceScopeStates, $.$MmZc.LCIDGM.GasGaugeDeviceModel, $.$MmZc.LCIDGS$1.GasGaugeDeviceSettings, $.$MmZc.LCIDGS$1.GasGaugeDeviceHardwareSettings, $.$XBGm.LCICS$3.IOTDeviceStates, $.$XBGm.LCICM.IOTDeviceStatusModel, $.$XBGm.LCICM.IOTDeviceCommandModel, $.$MmZc.LCIDGM.GasGaugeDeviceReceivedDataModel, $.$MmZc.LCIDGM.GasGaugeDeviceSendDataModel, $.$MmZc.LCIDGS.IGasGaugeDeviceStatusHandler, $.$MmZc.LCIDGS.IGasGaugeDeviceHubClient, $.$MmZc.LCIDGS.IGasGaugeRemoteService, $.$XBGm.LCICS$2.IOTDeviceGlobalSettings); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298162081),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3194785,
      "h": 4298162081,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298162081)
  ],
  "h": 3194785
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `LivingThing.Core.IOT.Devices.GasGauge.ViewModels.GasGaugeClientAppDefinition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `LivingThing${separator}Core${separator}IOT${separator}Devices${separator}GasGauge${separator}ViewModels${separator}GasGaugeClientAppDefinition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3194785)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Runtime.Loader", "NetJs.System.Text.RegularExpressions", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.Microsoft.CSharp", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.IO.Pipelines", "NetJs.System.Linq.Queryable", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.System.Net.Http.Json", "NetJs.System.Net.WebHeaderCollection", "NetJs.System.Net.Requests", "NetJs.System.Net.WebProxy", "NetJs.System.Net.WebSockets", "NetJs.System.Net.WebSockets.Client", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.System.Text.Encoding.CodePages", "NetJs.System.Web.HttpUtility", "NetJs.System.Xml.XPath", "NetJs.System.Xml.XPath.XDocument", "NetJs.AngleSharp", "NetJs.DynamicExpresso.Core", "NetJs.HtmlAgilityPack", "NetJs.Markdig", "NetJs.Microsoft.AspNetCore.Metadata", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.AspNetCore.Authorization", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.AspNetCore.Components.Authorization", "NetJs.Microsoft.Extensions.Validation", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.Microsoft.Extensions.Caching.Memory", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.System.IO.Hashing", "NetJs.ReverseMarkdown", "NetJs.LivingThing.Core.Frameworks.Common.Icons", "NetJs.LivingThing.Core.Frameworks.Common", "NetJs.LivingThing.Core.Frameworks.Common.Models", "NetJs.LivingThing.Core.Frameworks.Common.Authentication", "NetJs.LivingThing.Core.Frameworks.Common.Mocking", "NetJs.LivingThing.Core.Frameworks.Common.Hub", "NetJs.LivingThing.Core.Frameworks.Common.RPC", "NetJs.LivingThing.Core.Frameworks.Common.Messaging", "NetJs.LivingThing.Core.Frameworks.Common.Client", "NetJs.LivingThing.Core.Frameworks.Common.Web", "NetJs.LivingThing.TSCS", "NetJs.LivingThing.Core.Frameworks.Client.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Application", "NetJs.LivingThing.Core.Frameworks.Common.Payment", "NetJs.LivingThing.Core.Frameworks.Common.Product", "NetJs.LivingThing.Core.Frameworks.Client.Application.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Dynamic", "NetJs.LivingThing.FluentUI.Core", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.FluentUI.Gauges.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.PageBuilder.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.Payment.Blazor", "NetJs.LivingThing.Core.Frameworks.Client.SPA.Blazor", "NetJs.LivingThing.Core.Frameworks.Common.Automation", "NetJs.LivingThing.Core.Frameworks.Common.Pipeline", "NetJs.LivingThing.Core.Frameworks.Common.Connection", "NetJs.LivingThing.Core.Frameworks.Common.Bluetooth", "NetJs.LivingThing.Core.Frameworks.Common.Cron", "NetJs.LivingThing.Core.Frameworks.Common.Mediator", "NetJs.LivingThing.Core.IOT.Common", "NetJs.LivingThing.Core.IOT.Automation", "NetJs.LivingThing.Core.IOT.Devices", "NetJs.LivingThing.Core.IOT.Services", "NetJs.LivingThing.Core.IOT.Services.Client", "NetJs.LivingThing.Core.ProductsServices.Client.Blazor", "NetJs.LivingThing.Core.IOT.Client.Blazor"));
})();
//--TRIMMABLE-BOUNDARY-END(49057)
